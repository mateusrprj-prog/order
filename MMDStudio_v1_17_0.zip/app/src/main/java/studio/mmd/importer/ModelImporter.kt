package studio.mmd.importer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import studio.mmd.mmd.GlbParser
import studio.mmd.mmd.ObjParser
import studio.mmd.mmd.PmdParser
import studio.mmd.mmd.XParser
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxParser
import java.io.IOException
import java.nio.charset.Charset
import java.util.zip.ZipInputStream

/** Importa .pmx isolado ou .zip (modelo + texturas) a partir do armazenamento do Android. */
object ModelImporter {
    class Result(val model: PmxModel, val textures: List<ByteArray?>, val sourceName: String)

    private val KEEP = setOf("pmx", "pmd", "x", "png", "jpg", "jpeg", "bmp", "tga", "spa", "sph", "gif", "glb", "gltf", "bin", "obj", "mtl", "webp")

    fun load(ctx: Context, uri: Uri): Result {
        val name = displayName(ctx, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "zip" -> fromZip(ctx, uri, name)
            "pmx" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = PmxParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            "x" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = XParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            "pmd" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = PmdParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            "glb", "gltf" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val g = GlbParser.parse(bytes)
                val extra = if (ext == "gltf" && g.model.textures.any { it.isNotEmpty() } && g.embedded.any { it == null }) listOf("arquivos externos do .gltf (.bin/imagens) não são lidos num arquivo solto; use um .zip ou um .glb") else emptyList()
                Result(withWarnings(g.model, extra), g.embedded, name)
            }
            "obj" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = ObjParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            else -> throw IOException("Formato não suportado: $name")
        }
    }

    private fun withWarnings(m: PmxModel, extra: List<String>): PmxModel {
        if (extra.isEmpty()) return m
        return PmxModel(m.name, m.version, m.positions, m.normals, m.uvs, m.boneIndices, m.boneWeights, m.indices, m.textures, m.materials, m.bones, m.morphs,
            warnings = m.warnings + extra)
    }

    private fun fromZip(ctx: Context, uri: Uri, name: String): Result {
        val files = try { readZip(ctx, uri, Charsets.UTF_8) } catch (e: IllegalArgumentException) { readZip(ctx, uri, Charset.forName("Shift_JIS")) }
        val pmxPath = files.keys.firstOrNull { it.lowercase().endsWith(".pmx") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".pmd") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".x") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".glb") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".gltf") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".obj") }
            ?: throw IOException("Nenhum .pmx, .pmd, .x, .glb, .gltf ou .obj encontrado dentro do zip")
        val dir = pmxPath.lowercase().substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        val lower = files.keys.associateBy { it.lowercase() }
        fun find(rel: String): ByteArray? {
            val n = rel.replace('\\', '/').lowercase().removePrefix("./")
            val key = lower[dir + n] ?: lower[n] ?: lower.entries.firstOrNull { it.key.substringAfterLast('/') == n.substringAfterLast('/') }?.value
            return key?.let { files[it] }
        }
        var embedded: List<ByteArray?>? = null
        val model = when {
            pmxPath.lowercase().endsWith(".pmd") -> PmdParser.parse(files.getValue(pmxPath))
            pmxPath.lowercase().endsWith(".x") -> XParser.parse(files.getValue(pmxPath))
            pmxPath.lowercase().endsWith(".glb") || pmxPath.lowercase().endsWith(".gltf") -> GlbParser.parse(files.getValue(pmxPath)) { find(it) }.also { embedded = it.embedded }.model
            pmxPath.lowercase().endsWith(".obj") -> ObjParser.parse(files.getValue(pmxPath)) { find(it) }
            else -> PmxParser.parse(files.getValue(pmxPath))
        }
        val textures = model.textures.mapIndexed { ti, t ->
            embedded?.getOrNull(ti)?.let { return@mapIndexed it }
            val n = t.replace('\\', '/').lowercase().removePrefix("./")
            val key = lower[dir + n] ?: lower[n] ?: lower.entries.firstOrNull { it.key.substringAfterLast('/') == n.substringAfterLast('/') }?.value
            key?.let { k -> val d = files[k]; if (d != null && k.lowercase().endsWith(".tga")) TgaDecoder.toPng(d) else d }
        }
        return Result(model, textures, pmxPath.substringAfterLast('/'))
    }

    /** Limites contra zips gigantes/maliciosos: bytes descompactados lidos para a memória e nº de entradas. */
    private const val MAX_TOTAL = 400L * 1024 * 1024
    private const val MAX_ENTRIES = 20_000

    private fun readLimited(z: ZipInputStream, limit: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(64 * 1024); var total = 0L
        while (true) {
            val n = z.read(buf); if (n < 0) break
            total += n
            if (total > limit) throw IOException("Zip grande demais (limite de ${MAX_TOTAL / 1048576} MB descompactado)")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun readZip(ctx: Context, uri: Uri, cs: Charset): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        var used = 0L; var entries = 0
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o zip")
        ins.use { s ->
            ZipInputStream(s.buffered(), cs).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    if (++entries > MAX_ENTRIES) throw IOException("Zip com entradas demais (limite $MAX_ENTRIES)")
                    val n = e.name.replace('\\', '/')
                    if (n.substringAfterLast('.', "").lowercase() in KEEP) { val d = readLimited(z, MAX_TOTAL - used); used += d.size; out[n] = d }
                }
            }
        }
        return out
    }

    fun readBytes(ctx: Context, uri: Uri): ByteArray =
        ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir o arquivo")

    fun displayName(ctx: Context, uri: Uri): String =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "arquivo"
}
