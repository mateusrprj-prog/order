package studio.mmd.mmd

import kotlin.math.acos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * SDEF (Spherical Deformation) de referência em CPU. O shader (SceneGLView.MODEL_VS) implementa a MESMA fórmula.
 * Fórmula comum da comunidade MMD (saba / nanoem), NÃO comparada com o MMD oficial:
 *   rw = R0*w0 + R1*w1;  r0' = C + R0 - rw;  r1' = C + R1 - rw;  cr0 = (C + r0')/2;  cr1 = (C + r1')/2
 *   q = slerp(q0, q1, w1) (caminho mais curto);  pos = R(q)*(p - C) + M0*cr0*w0 + M1*cr1*w1;  normal = R(q)*n
 * M0/M1 = matrizes de skinning dos dois ossos (global * inversa do repouso); q0/q1 = rotações globais dos ossos.
 * Tudo em coordenadas MMD (sem escala nem inversão de Z).
 */
object Sdef {
    /** Pré-cálculo estático por vértice: cr0 e cr1 (dependem só de C, R0, R1 e w0). c/r0/r1 lidos de [src] a partir de [o]. */
    fun prepare(src: FloatArray, o: Int, w0: Float, cr0: FloatArray, cr1: FloatArray) {
        val w1 = 1f - w0
        for (k in 0..2) {
            val c = src[o + k]; val a = src[o + 3 + k]; val b = src[o + 6 + k]
            val rw = a * w0 + b * w1
            val r0 = c + a - rw; val r1 = c + b - rw
            cr0[k] = (c + r0) * 0.5f; cr1[k] = (c + r1) * 0.5f
        }
    }

    /** Matriz de rotação (linha-maior, 9 floats) de um quaternion xyzw normalizado. */
    fun quatToMat(q: FloatArray, m: FloatArray) {
        val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
        m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - z * w); m[2] = 2 * (x * z + y * w)
        m[3] = 2 * (x * y + z * w); m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - x * w)
        m[6] = 2 * (x * z - y * w); m[7] = 2 * (y * z + x * w); m[8] = 1 - 2 * (x * x + y * y)
    }

    /** Slerp com caminho mais curto; perto de 0° usa nlerp (igual ao shader). Resultado normalizado em [out]. */
    fun slerp(a: FloatArray, b0: FloatArray, t: Float, out: FloatArray) {
        var d = a[0] * b0[0] + a[1] * b0[1] + a[2] * b0[2] + a[3] * b0[3]
        val sg = if (d < 0f) -1f else 1f
        d *= sg
        val bx = b0[0] * sg; val by = b0[1] * sg; val bz = b0[2] * sg; val bw = b0[3] * sg
        val ka: Float; val kb: Float
        if (d > 0.9995f) { ka = 1f - t; kb = t }
        else {
            val th = acos(d.coerceIn(-1f, 1f)); val s = sin(th)
            ka = sin((1f - t) * th) / s; kb = sin(t * th) / s
        }
        val x = a[0] * ka + bx * kb; val y = a[1] * ka + by * kb; val z = a[2] * ka + bz * kb; val w = a[3] * ka + bw * kb
        val l = sqrt(x * x + y * y + z * z + w * w).let { if (it < 1e-12f) 1f else it }
        out[0] = x / l; out[1] = y / l; out[2] = z / l; out[3] = w / l
    }

    /**
     * Deforma um vértice SDEF. [c] = C; [cr0]/[cr1] = de [prepare]; [q0]/[q1] = quaternions globais xyzw;
     * [t0]/[t1] = translação das matrizes de skinning (M(x) = R(q)*x + t). out[0..2] = posição, out[3..5] = normal.
     */
    fun skin(p: FloatArray, n: FloatArray, c: FloatArray, cr0: FloatArray, cr1: FloatArray, w0: Float,
             q0: FloatArray, t0: FloatArray, q1: FloatArray, t1: FloatArray, out: FloatArray) {
        val w1 = 1f - w0
        val q = FloatArray(4); slerp(q0, q1, w1, q)
        val r = FloatArray(9); quatToMat(q, r)
        val m0 = FloatArray(9); quatToMat(q0, m0); val m1 = FloatArray(9); quatToMat(q1, m1)
        val dx = p[0] - c[0]; val dy = p[1] - c[1]; val dz = p[2] - c[2]
        for (i in 0..2) {
            val rot = r[i * 3] * dx + r[i * 3 + 1] * dy + r[i * 3 + 2] * dz
            val a = m0[i * 3] * cr0[0] + m0[i * 3 + 1] * cr0[1] + m0[i * 3 + 2] * cr0[2] + t0[i]
            val b = m1[i * 3] * cr1[0] + m1[i * 3 + 1] * cr1[1] + m1[i * 3 + 2] * cr1[2] + t1[i]
            out[i] = rot + a * w0 + b * w1
            out[3 + i] = r[i * 3] * n[0] + r[i * 3 + 1] * n[1] + r[i * 3 + 2] * n[2]
        }
    }

    /**
     * Atributos estáticos para o shader: 10 floats por vértice = (Cx, Cy, Cz, flag, cr0xyz, cr1xyz).
     * flag = 1 só para vértices SDEF com os dois ossos válidos (senão o shader usa skinning linear). null = modelo sem SDEF.
     */
    fun buildAttributes(m: PmxModel): FloatArray? {
        val sd = m.sdef ?: return null
        val vc = m.vertexCount; val nb = m.bones.size
        if (m.weightTypes.size < vc || sd.size < vc * 9) return null
        var any = false
        val out = FloatArray(vc * 10)
        val cr0 = FloatArray(3); val cr1 = FloatArray(3)
        for (i in 0 until vc) {
            if (m.weightTypes[i].toInt() != 3) continue
            val b0 = m.boneIndices[i * 4]; val b1 = m.boneIndices[i * 4 + 1]
            if (b0 !in 0 until nb || b1 !in 0 until nb) continue
            prepare(sd, i * 9, m.boneWeights[i * 4], cr0, cr1)
            val o = i * 10
            out[o] = sd[i * 9]; out[o + 1] = sd[i * 9 + 1]; out[o + 2] = sd[i * 9 + 2]; out[o + 3] = 1f
            for (k in 0..2) { out[o + 4 + k] = cr0[k]; out[o + 7 + k] = cr1[k] }
            any = true
        }
        return if (any) out else null
    }
}
