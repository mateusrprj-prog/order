package studio.mmd

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.fail
import org.junit.Test
import studio.mmd.mmd.PmxFormatException
import studio.mmd.mmd.MorphResolver
import studio.mmd.mmd.MorphSink
import studio.mmd.mmd.MaterialMorphs
import studio.mmd.mmd.MaterialMorphState
import studio.mmd.mmd.MatMorphElem
import studio.mmd.mmd.Sdef
import studio.mmd.mmd.PmxMaterial
import studio.mmd.mmd.PmxMorph
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxWriter
import studio.mmd.mmd.PmxParser
import studio.mmd.mmd.VmdCamera
import studio.mmd.mmd.VmdParser
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Escritor binário little-endian para montar PMX/VMD sintéticos (sem arquivos protegidos). */
private class W {
    val o = ByteArrayOutputStream()
    fun u8(v: Int) = apply { o.write(v and 0xFF) }
    fun u16(v: Int) = apply { u8(v); u8(v shr 8) }
    fun i32(v: Int) = apply { u16(v and 0xFFFF); u16(v ushr 16) }
    fun f(v: Float) = i32(java.lang.Float.floatToIntBits(v))
    fun fs(vararg v: Float) = apply { v.forEach { f(it) } }
    fun txt(s: String) = apply { val b = s.toByteArray(Charsets.UTF_16LE); i32(b.size); o.write(b) }
    fun raw(b: ByteArray) = apply { o.write(b) }
    fun zeros(n: Int) = apply { o.write(ByteArray(n)) }
    fun fixed(s: String, n: Int, cs: java.nio.charset.Charset = Charsets.US_ASCII) = apply { val a = ByteArray(n); val e = s.toByteArray(cs); System.arraycopy(e, 0, a, 0, minOf(e.size, n)); o.write(a) }
    fun bytes() = o.toByteArray()
}

/** PMX mínimo: índices de 1 byte, UTF-16LE, 1 UV adicional; 3 vértices, 1 face, 1 textura, 1 material, 2 ossos, 3 morphs, 1 frame, 1 corpo, 1 junta. */
private fun pmx(version: Float = 2.0f, v0: (W) -> Unit = { it.u8(0).u8(0) }, softBody: Boolean = false, upTo: String = "fim"): ByteArray {
    val w = W()
    w.raw("PMX ".toByteArray()).f(version).u8(8).u8(0).u8(1).u8(1).u8(1).u8(1).u8(1).u8(1).u8(1)
    w.txt("Modelo").txt("Model").txt("comentário").txt("comment")
    w.i32(3)
    for (i in 0 until 3) {
        w.fs(i.toFloat(), 0f, 0f).fs(0f, 1f, 0f).fs(0f, 0f).fs(9f, 8f, 7f, 6f)   // pos, normal, uv, 1 uv adicional
        if (i == 0) v0(w) else { w.u8(0).u8(0) }                                       // BDEF1 osso 0
        w.f(1f)
    }
    w.i32(3).u8(0).u8(1).u8(2)
    w.i32(1).txt("tex.png")
    w.i32(1).txt("mat").txt("mat").fs(1f, 1f, 1f, 1f).fs(0f, 0f, 0f).f(5f).fs(0.5f, 0.5f, 0.5f)
        .u8(0x11).fs(0f, 0f, 0f, 1f).f(1f).u8(0).u8(255).u8(0).u8(1).u8(0).txt("memo do material").i32(3)
    w.i32(2)
    w.txt("center").txt("center").fs(0f, 0f, 0f).u8(255).i32(0).u16(0x0001 or 0x0002 or 0x0008 or 0x0010).u8(1)
    w.txt("腕").txt("arm").fs(1f, 0f, 0f).u8(0).i32(0).u16(0x0001 or 0x0400).u8(255).fs(0f, 0f, 1f)
    w.i32(3)
    w.txt("v").txt("v").u8(1).u8(1).i32(1).u8(0).fs(0f, 0.1f, 0f)
    w.txt("uv").txt("uv").u8(1).u8(3).i32(1).u8(0).fs(1f, 2f, 3f, 4f)
    w.txt("mat").txt("mat").u8(4).u8(8).i32(1).u8(0).zeros(113)
    if (upTo == "morphs") return w.bytes()
    w.i32(1).txt("Root").txt("Root").u8(1).i32(1).u8(0).u8(0)
    w.i32(1).txt("rb").txt("rb").u8(0).u8(1).u16(0xFFFF).u8(0).fs(1f, 1f, 1f).fs(0f, 0f, 0f).fs(0f, 0f, 0f).fs(1f, 0.5f, 0.5f, 0f, 0.5f).u8(1)
    if (upTo == "rigid-trunc") return w.bytes().copyOf(w.bytes().size - 30)
    w.i32(1).txt("j").txt("j").u8(0).u8(0).u8(0)
    for (k in 0 until 8) w.fs(0f, 0f, 0f)
    if (softBody) w.i32(0)
    return w.bytes()
}

class PmxParserTest {
    @Test fun parsesMinimalPmx20AndPreservesData() {
        val m = PmxParser.parse(pmx())
        assertEquals(3, m.vertexCount); assertEquals(2, m.bones.size); assertEquals(3, m.morphs.size)
        assertEquals("comentário", m.comment); assertEquals("comment", m.commentEn)
        assertEquals("memo do material", m.materials[0].memo)
        assertEquals(1, m.addUvCount); assertEquals(12, m.addUvs.size); assertEquals(9f, m.addUvs[0], 0f)
        assertEquals(1, m.displayFrames.size); assertEquals(1, m.rigidBodies.size); assertEquals(1, m.joints.size)
        assertNotNull(m.bones[1].fixedAxis); assertNull(m.bones[0].fixedAxis)
        assertEquals(1 * (1 + 16), m.morphs[1].raw!!.size); assertEquals(1 * (1 + 113), m.morphs[2].raw!!.size)
        assertTrue(m.warnings.any { "UV/impulso" in it }); assertTrue(m.warnings.any { "morphs de material" in it })
        assertTrue(m.warnings.none { "ilegível" in it || "bytes extras" in it })
    }

    @Test fun parsesPmx21WithEmptySoftBodyBlock() {
        val m = PmxParser.parse(pmx(version = 2.1f, softBody = true))
        assertTrue(m.warnings.none { "soft bodies" in it || "bytes extras" in it })
    }

    @Test fun trailingBytesAreReported() {
        val m = PmxParser.parse(pmx() + byteArrayOf(1, 2, 3))
        assertTrue(m.warnings.any { "bytes extras" in it })
    }

    @Test fun sdefIsPreservedAndWarned() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(3).u8(0).u8(1).f(0.25f).fs(1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f) }))
        assertNotNull(m.sdef); assertEquals(3f, m.sdef!![2], 0f); assertEquals(9f, m.sdef!![8], 0f)
        assertEquals(3, m.weightTypes[0].toInt()); assertEquals(0.25f, m.boneWeights[0], 1e-6f); assertEquals(0.75f, m.boneWeights[1], 1e-6f)
        assertTrue(m.warnings.any { "SDEF" in it })
    }

    @Test fun bdef4WeightsAreNormalized() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(2).u8(0).u8(1).u8(255).u8(255).fs(2f, 2f, 0f, 0f) }))
        assertEquals(0.5f, m.boneWeights[0], 1e-6f); assertEquals(0.5f, m.boneWeights[1], 1e-6f)
        assertTrue(m.warnings.any { "normalizados" in it })
    }

    @Test fun invalidBoneIndexInVertexIsZeroedWithWarning() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(0).u8(50) }))
        assertEquals(-1, m.boneIndices[0]); assertEquals(0f, m.boneWeights[0], 0f)
        assertTrue(m.warnings.any { "ossos inexistentes" in it })
    }

    @Test fun truncatedFileReportsSectionAndOffset() {
        val full = pmx(upTo = "morphs")
        try { PmxParser.parse(full.copyOf(full.size - 40)); fail("deveria falhar") }
        catch (e: PmxFormatException) { assertTrue(e.message!!, "seção" in e.message!! && "offset" in e.message!!) }
    }

    @Test fun brokenPhysicsSectionIsReportedNotSilent() {
        val m = PmxParser.parse(pmx(upTo = "rigid-trunc"))
        assertEquals(3, m.vertexCount); assertEquals(0, m.rigidBodies.size)
        assertTrue(m.warnings.any { "corpos rígidos" in it && "ilegível" in it })
        assertEquals(1, m.displayFrames.size)   // o que veio antes é mantido
    }

    @Test fun badSignatureIsRejected() {
        try { PmxParser.parse("NOPE0000000000".toByteArray()); fail("deveria falhar") }
        catch (e: PmxFormatException) { assertTrue("assinatura" in e.message!!) }
    }

    @Test fun absurdCountDoesNotAllocate() {
        val b = pmx(); val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        // contagem de vértices fica depois do cabeçalho e dos 4 textos
        var p = 4 + 4 + 1 + 8
        repeat(4) { p += 4 + bb.getInt(p) }
        bb.putInt(p, 40_000_000)
        try { PmxParser.parse(b); fail("deveria falhar") } catch (e: PmxFormatException) { assertTrue("vértices" in e.message!!) }
    }
}

class VmdParserTest {
    private fun vmd(build: (W) -> Unit): ByteArray { val w = W(); w.fixed("Vocaloid Motion Data 0002", 30).fixed("modelo", 20); build(w); return w.bytes() }
    private fun boneKey(w: W, name: String, frame: Int, x: Float) { w.fixed(name, 15).i32(frame).fs(x, 0f, 0f, 0f, 0f, 0f, 1f); w.zeros(64) }

    @Test fun duplicateFramesKeepLastAndWarn() {
        val d = vmd { w ->
            w.i32(3); boneKey(w, "center", 10, 1f); boneKey(w, "center", 0, 5f); boneKey(w, "center", 10, 2f)
            w.i32(0).i32(0).i32(0).i32(0).i32(0)
        }
        val m = VmdParser.parse(d)
        val t = m.bones.getValue("center")
        assertEquals(listOf(0, 10), t.frames.toList()); assertEquals(2f, t.v[7], 0f)
        assertTrue(m.warnings.any { "repetidas" in it })
    }

    @Test fun ignoredLightShadowAndIkSectionsAreReported() {
        val d = vmd { w ->
            w.i32(0).i32(0).i32(0)                       // ossos, morphs, câmera
            w.i32(1).zeros(28)                           // 1 key de luz
            w.i32(2).zeros(18)                           // 2 keys de sombra
            w.i32(1)                                     // 1 key de IK
        }
        val m = VmdParser.parse(d)
        assertTrue(m.warnings.any { "iluminação" in it }); assertTrue(m.warnings.any { "self-shadow" in it }); assertTrue(m.warnings.any { "IK" in it })
    }

    @Test fun truncatedBoneSectionFails() {
        val d = vmd { w -> w.i32(1000) }
        try { VmdParser.parse(d); fail("deveria falhar") } catch (e: IllegalArgumentException) { assertTrue("truncado" in e.message!!) }
    }

    @Test fun cameraBezierDiagonalIsLinear() {
        val ip = ByteArray(48)
        for (k in 0 until 2) for (c in 0 until 6) { ip[k * 24 + c * 4] = 20; ip[k * 24 + c * 4 + 1] = 107; ip[k * 24 + c * 4 + 2] = 20; ip[k * 24 + c * 4 + 3] = 107 }
        val cam = VmdCamera(intArrayOf(0, 10), floatArrayOf(0f, 10f), FloatArray(6), FloatArray(6), floatArrayOf(30f, 30f), ip)
        val out = FloatArray(8); cam.evaluate(5f, out)
        assertEquals(5f, out[0], 0.05f)
    }

    @Test fun cameraRoundTripReadsBack() {
        val d = vmd { w ->
            w.i32(0).i32(0)
            w.i32(1).i32(7).f(-30f).fs(1f, 2f, 3f).fs(0.1f, 0.2f, 0.3f).zeros(24).i32(45).u8(0)
            w.i32(0).i32(0).i32(0)
        }
        val c = VmdParser.parseCamera(d)!!
        assertEquals(7, c.frames[0]); assertEquals(-30f, c.dist[0], 0f); assertEquals(45f, c.fov[0], 0f)
    }
}

class PmxWriterTest {
    private fun roundTrip(src: ByteArray): ByteArray = PmxWriter.write(PmxParser.parse(src)).bytes

    @Test fun pmx20RoundTripIsByteIdentical() {
        val src = pmx()
        assertArrayEquals(src, roundTrip(src))
    }

    @Test fun pmx21RoundTripIsByteIdentical() {
        val src = pmx(version = 2.1f, softBody = true)
        assertArrayEquals(src, roundTrip(src))
    }

    @Test fun sdefRoundTripIsByteIdentical() {
        val src = pmx(v0 = { it.u8(3).u8(0).u8(1).f(0.25f).fs(1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f) })
        assertArrayEquals(src, roundTrip(src))
    }

    @Test fun softBodyBytesArePreserved() {
        val base = pmx(version = 2.1f, softBody = true)
        val extra = byteArrayOf(9, 8, 7, 6, 5, 4, 3, 2, 1, 0)
        val src = base.copyOf(base.size - 4) + byteArrayOf(1, 0, 0, 0) + extra     // troca a contagem 0 por 1 + 10 bytes
        val m = PmxParser.parse(src)
        assertEquals(1, m.softBodyCount); assertEquals(10, m.softBodyRaw!!.size)
        assertArrayEquals(src, PmxWriter.write(m).bytes)
    }

    @Test fun nonNormalizedBdef4IsStableAfterOneRoundTrip() {
        val src = pmx(v0 = { it.u8(2).u8(0).u8(1).u8(255).u8(255).fs(2f, 2f, 0f, 0f) })
        val a = PmxParser.parse(src)
        val b = PmxParser.parse(PmxWriter.write(a).bytes)
        assertArrayEquals(a.boneWeights, b.boneWeights, 0f)
        assertArrayEquals(a.boneIndices, b.boneIndices)
        assertArrayEquals(PmxWriter.write(a).bytes, PmxWriter.write(b).bytes)
    }

    @Test fun parsedFieldsSurviveRoundTrip() {
        val a = PmxParser.parse(pmx())
        val b = PmxParser.parse(PmxWriter.write(a).bytes)
        assertEquals(a.name, b.name); assertEquals(a.nameEn, b.nameEn); assertEquals(a.comment, b.comment); assertEquals(a.commentEn, b.commentEn)
        assertEquals("j", b.joints[0].nameEn)
        assertEquals(a.materials[0].memo, b.materials[0].memo)
        assertArrayEquals(a.addUvs, b.addUvs, 0f)
        assertEquals(a.morphs[1].raw!!.size, b.morphs[1].raw!!.size)
        assertArrayEquals(a.morphs[2].raw, b.morphs[2].raw)
        assertEquals(a.displayFrames.size, b.displayFrames.size)
        assertArrayEquals(a.bones[1].fixedAxis, b.bones[1].fixedAxis, 0f)
    }

    @Test fun modelWithoutBonesGetsRootBoneAndFrames() {
        val vc = 300
        val m = PmxModel("x", 1f, FloatArray(vc * 3), FloatArray(vc * 3), FloatArray(vc * 2), IntArray(0), FloatArray(0),
            intArrayOf(0, 1, 2, 297, 298, 299), emptyList(),
            listOf(PmxMaterial("m", "m", floatArrayOf(1f, 1f, 1f, 1f), FloatArray(3), 5f, FloatArray(3), 1, floatArrayOf(0f, 0f, 0f, 1f), 1f, -1, -1, 0, true, 0, 6)),
            emptyList(), emptyList())
        val out = PmxWriter.write(m)
        val r = PmxParser.parse(out.bytes)
        assertEquals(vc, r.vertexCount); assertEquals(1, r.bones.size); assertEquals(0, r.boneIndices[0]); assertEquals(1f, r.boneWeights[0], 0f)
        assertEquals(299, r.indices[5]); assertTrue(r.displayFrames.size >= 2)
        assertTrue(out.warnings.any { "osso raiz" in it })
    }

    @Test fun invalidFaceIndexIsRejected() {
        val m = PmxModel("x", 2f, FloatArray(9), FloatArray(9), FloatArray(6), IntArray(0), FloatArray(0), intArrayOf(0, 1, 7), emptyList(), emptyList(), emptyList(), emptyList())
        try { PmxWriter.write(m); fail("deveria falhar") } catch (e: IllegalArgumentException) { assertTrue(e.message!!, "fora do intervalo" in e.message!!) }
    }

    @Test fun textureNamesAreSanitizedConvertedAndUnique() {
        val png = byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 0)
        val n = PmxWriter.textureFileNames(listOf("tex\\a.tga", "..\\..\\evil.png", "a.png", "a.png", ""), listOf(png, null, null, null, null))
        assertEquals(listOf("tex/a.png", "evil.png", "a.png", "a_1.png", ""), n)
    }
}

class MorphResolverTest {
    private fun leafM(n: String) = PmxMorph(n, n, 1, 1, vertexIdx = IntArray(0), vertexDelta = FloatArray(0))
    private fun group(n: String, idx: IntArray, rate: FloatArray) = PmxMorph(n, n, 1, 0, groupIdx = idx, groupRate = rate, count = idx.size)
    private fun flip(n: String, idx: IntArray, rate: FloatArray) = PmxMorph(n, n, 1, 9, groupIdx = idx, groupRate = rate, count = idx.size)
    private class Rec : MorphSink { val got = ArrayList<Pair<Int, Float>>(); override fun leaf(index: Int, weight: Float) { got.add(index to weight) } }

    @Test fun leafPassesThrough() {
        val r = MorphResolver(listOf(leafM("a"))); val s = Rec(); r.resolve(0, 0.5f, s)
        assertEquals(listOf(0 to 0.5f), s.got)
    }

    @Test fun nestedGroupsMultiplyRatesBeyondOldDepthLimit() {
        // cadeia de 6 grupos (o limite antigo era 4) terminando em um morph folha
        val ms = ArrayList<PmxMorph>()
        for (i in 0 until 6) ms.add(group("g$i", intArrayOf(i + 1), floatArrayOf(0.5f)))
        ms.add(leafM("leaf"))
        val s = Rec(); MorphResolver(ms).resolve(0, 1f, s)
        assertEquals(1, s.got.size); assertEquals(6, s.got[0].first); assertEquals(1f / 64f, s.got[0].second, 1e-7f)
    }

    @Test fun sharedDependencyAccumulatesTwice() {
        val ms = listOf(group("g", intArrayOf(1, 2), floatArrayOf(1f, 1f)), group("a", intArrayOf(3), floatArrayOf(1f)), group("b", intArrayOf(3), floatArrayOf(0.5f)), leafM("x"))
        val s = Rec(); MorphResolver(ms).resolve(0, 1f, s)
        assertEquals(listOf(3 to 1f, 3 to 0.5f), s.got)
    }

    @Test fun cycleIsDetectedNotInfinite() {
        val ms = listOf(group("a", intArrayOf(1), floatArrayOf(1f)), group("b", intArrayOf(0, 2), floatArrayOf(1f, 1f)), leafM("x"))
        val r = MorphResolver(ms); val s = Rec(); r.resolve(0, 1f, s)
        assertEquals(listOf(2 to 1f), s.got); assertEquals(1, r.cycles)
        // estado limpo: uma segunda resolução dá o mesmo resultado
        val s2 = Rec(); r.resolve(0, 1f, s2); assertEquals(s.got, s2.got)
    }

    @Test fun invalidReferencesAndNonFiniteWeightsAreIgnored() {
        val ms = listOf(group("a", intArrayOf(9, -1, 1), floatArrayOf(1f, 1f, 1f)), leafM("x"))
        val r = MorphResolver(ms); val s = Rec(); r.resolve(0, 1f, s)
        assertEquals(listOf(1 to 1f), s.got); assertEquals(2, r.invalid)
        r.resolve(1, Float.NaN, s); assertEquals(1, s.got.size)
    }

    @Test fun flipPicksOneElementByWeightRange() {
        val ms = listOf(flip("f", intArrayOf(1, 2), floatArrayOf(1f, 0.8f)), leafM("a"), leafM("b"))
        val r = MorphResolver(ms)
        fun at(w: Float): List<Pair<Int, Float>> { val s = Rec(); r.resolve(0, w, s); return s.got }
        assertEquals(emptyList<Pair<Int, Float>>(), at(0f))
        assertEquals(listOf(1 to 1f), at(0.2f))
        assertEquals(listOf(1 to 1f), at(0.49f))
        assertEquals(listOf(2 to 0.8f), at(0.5f))
        assertEquals(listOf(2 to 0.8f), at(1f))
        assertEquals(listOf(2 to 0.8f), at(5f))     // acima de 1 continua no último elemento
    }

    @Test fun flipInsideGroupAndSelfReferenceAreSafe() {
        val ms = listOf(group("g", intArrayOf(1), floatArrayOf(1f)), flip("f", intArrayOf(2, 1), floatArrayOf(1f, 1f)), leafM("a"))
        val r = MorphResolver(ms); val s = Rec(); r.resolve(0, 0.4f, s)
        assertEquals(listOf(2 to 1f), s.got)
        val s2 = Rec(); r.resolve(0, 0.9f, s2)          // escolhe o elemento 1 (o próprio flip) -> ciclo
        assertTrue(s2.got.isEmpty()); assertEquals(1, r.cycles)
    }
}


class SdefTest {
    private val S = 0.70710678f
    private val ID = floatArrayOf(0f, 0f, 0f, 1f)
    private val Z90 = floatArrayOf(0f, 0f, S, S)      // 90° em torno de Z: (x,y,z) -> (-y,x,z)
    private val Y90 = floatArrayOf(0f, S, 0f, S)      // 90° em torno de Y: (x,y,z) -> (z,y,-x)
    private val ZERO = floatArrayOf(0f, 0f, 0f)

    private fun run(p: FloatArray, n: FloatArray, c: FloatArray, r0: FloatArray, r1: FloatArray, w0: Float,
                    q0: FloatArray, t0: FloatArray, q1: FloatArray, t1: FloatArray): FloatArray {
        val src = c + r0 + r1
        val cr0 = FloatArray(3); val cr1 = FloatArray(3)
        Sdef.prepare(src, 0, w0, cr0, cr1)
        val out = FloatArray(6)
        Sdef.skin(p, n, c, cr0, cr1, w0, q0, t0, q1, t1, out)
        return out
    }

    @Test fun identityPoseKeepsRestPosition() {
        val p = floatArrayOf(3f, -1f, 2f); val n = floatArrayOf(0f, 1f, 0f)
        val o = run(p, n, floatArrayOf(1f, 1f, 1f), floatArrayOf(2f, 3f, 4f), floatArrayOf(5f, 6f, 7f), 0.4f, ID, ZERO, ID, ZERO)
        assertArrayEquals(p, o.copyOfRange(0, 3), 1e-4f)
        assertArrayEquals(n, o.copyOfRange(3, 6), 1e-4f)
    }

    @Test fun sameRigidTransformEqualsLinear() {
        val t = floatArrayOf(1f, 2f, 3f)
        val o = run(floatArrayOf(3f, -1f, 2f), floatArrayOf(0f, 1f, 0f), floatArrayOf(1f, 1f, 1f),
            floatArrayOf(2f, 3f, 4f), floatArrayOf(5f, 6f, 7f), 0.3f, Z90, t, Z90, t)
        assertArrayEquals(floatArrayOf(2f, 5f, 5f), o.copyOfRange(0, 3), 1e-3f)
        assertArrayEquals(floatArrayOf(-1f, 0f, 0f), o.copyOfRange(3, 6), 1e-3f)
    }

    @Test fun weightOneEqualsFirstBoneSkin() {
        val o = run(floatArrayOf(3f, -1f, 2f), floatArrayOf(0f, 1f, 0f), floatArrayOf(1f, 1f, 1f),
            floatArrayOf(2f, 3f, 4f), floatArrayOf(5f, 6f, 7f), 1f, Z90, floatArrayOf(1f, 2f, 3f), ID, floatArrayOf(9f, 9f, 9f))
        assertArrayEquals(floatArrayOf(2f, 5f, 5f), o.copyOfRange(0, 3), 1e-3f)
        assertArrayEquals(floatArrayOf(-1f, 0f, 0f), o.copyOfRange(3, 6), 1e-3f)
    }

    @Test fun twistKeepsLengthWhileLinearBlendCollapses() {
        // osso 0 parado, osso 1 gira 90° em torno do eixo Y que passa por C = (0,10,0); vértice a 1 unidade de C, pesos 50/50
        val c = floatArrayOf(0f, 10f, 0f)
        val o = run(floatArrayOf(1f, 10f, 0f), floatArrayOf(1f, 0f, 0f), c, c, c, 0.5f, ID, ZERO, Y90, ZERO)
        // SDEF: rotação de 45° (sem encolher): C + (cos45, 0, -sin45)
        assertArrayEquals(floatArrayOf(S, 10f, -S), o.copyOfRange(0, 3), 1e-3f)
        assertArrayEquals(floatArrayOf(S, 0f, -S), o.copyOfRange(3, 6), 1e-3f)
        // linear daria (0.5, 10, -0.5): distância 0,707 de C (o "colapso" do pulso)
        val lin = floatArrayOf(0.5f, 10f, -0.5f)
        val dSdef = Math.sqrt((o[0] * o[0] + (o[1] - 10f) * (o[1] - 10f) + o[2] * o[2]).toDouble()).toFloat()
        val dLin = Math.sqrt((lin[0] * lin[0] + (lin[1] - 10f) * (lin[1] - 10f) + lin[2] * lin[2]).toDouble()).toFloat()
        assertEquals(1f, dSdef, 1e-3f); assertTrue(dLin < 0.8f)
    }

    @Test fun slerpTakesShortestPath() {
        val q = FloatArray(4)
        Sdef.slerp(ID, floatArrayOf(0f, -S, 0f, -S), 0.5f, q)      // -Y90 é a mesma rotação que Y90
        assertArrayEquals(floatArrayOf(0f, 0.38268343f, 0f, 0.92387953f), q, 1e-4f)
        Sdef.slerp(ID, ID, 0.7f, q)                                 // iguais: caminho nlerp
        assertArrayEquals(ID, q, 1e-6f)
    }

    @Test fun attributesOnlyForValidSdefVertices() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(3).u8(0).u8(1).f(0.25f).fs(1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f) }))
        val a = Sdef.buildAttributes(m)
        assertNotNull(a); assertEquals(30, a!!.size)
        assertArrayEquals(floatArrayOf(1f, 2f, 3f, 1f), a.copyOfRange(0, 4), 1e-6f)                    // C + flag
        assertArrayEquals(floatArrayOf(-0.125f, 0.875f, 1.875f), a.copyOfRange(4, 7), 1e-5f)         // cr0
        assertArrayEquals(floatArrayOf(1.375f, 2.375f, 3.375f), a.copyOfRange(7, 10), 1e-5f)         // cr1
        assertEquals(0f, a[13], 0f); assertEquals(0f, a[23], 0f)                                       // vértices 1 e 2: sem SDEF
        // invariante: w0*cr0 + w1*cr1 = C (o modelo em repouso não muda)
        for (k in 0..2) assertEquals(a[k], 0.25f * a[4 + k] + 0.75f * a[7 + k], 1e-5f)
        assertNull(Sdef.buildAttributes(PmxParser.parse(pmx())))                                       // sem SDEF
    }
}


class MaterialMorphTest {
    private fun mat(diffuse: FloatArray = floatArrayOf(1f, 0.5f, 0.25f, 1f), ambient: FloatArray = floatArrayOf(0.2f, 0.2f, 0.2f)) =
        PmxMaterial("m", "m", diffuse, floatArrayOf(0.1f, 0.1f, 0.1f), 5f, ambient, 0, floatArrayOf(0f, 0f, 0f, 1f), 1f, -1, -1, 0, true, 0, 3)

    /** v: 16 valores (difusa4, espec3, brilho, ambiente3, borda4, espessura). */
    private fun elem(mat: Int, add: Boolean, v: FloatArray) = MatMorphElem(mat, add, v)
    private fun vals(vararg kv: Pair<Int, Float>, base: Float): FloatArray { val a = FloatArray(16) { base }; for ((i, x) in kv) a[i] = x; return a }
    private fun fin(st: MaterialMorphState, mats: List<PmxMaterial>): FloatArray { val o = FloatArray(16 * mats.size); st.finalize(mats, o); return o }

    private fun rawElem(bb: java.nio.ByteBuffer, mS: Int, idx: Int, add: Int, alpha: Float) {
        when (mS) { 1 -> bb.put(idx.toByte()); 2 -> bb.putShort(idx.toShort()); else -> bb.putInt(idx) }
        bb.put(add.toByte())
        for (c in 0 until 28) bb.putFloat(if (c == 3) alpha else 1f)   // 16 valores usados + 12 coeficientes ignorados
    }

    @Test fun decodeReadsIndexModeAndValuesForEachIndexSize() {
        for (mS in intArrayOf(1, 2, 4)) {
            val bb = java.nio.ByteBuffer.allocate(2 * (mS + 113)).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            rawElem(bb, mS, -1, 0, 0.25f); rawElem(bb, mS, 3, 1, 0.5f)
            val es = MaterialMorphs.decode(PmxMorph("x", "x", 1, 8, raw = bb.array(), count = 2))
            assertEquals(2, es.size)
            assertEquals(-1, es[0].mat); assertEquals(false, es[0].add); assertEquals(0.25f, es[0].v[3], 0f); assertEquals(1f, es[0].v[0], 0f)
            assertEquals(3, es[1].mat); assertEquals(true, es[1].add); assertEquals(0.5f, es[1].v[3], 0f)
        }
        assertTrue(MaterialMorphs.decode(PmxMorph("x", "x", 1, 8, raw = ByteArray(50), count = 1)).isEmpty())   // tamanho inválido
    }

    @Test fun multiplyBlendsTowardFactorAndCanHideMaterial() {
        val mats = listOf(mat()); val st = MaterialMorphState(1)
        val hide = elem(0, false, vals(3 to 0f, base = 1f))      // alfa x0
        st.apply(hide, 0.5f); assertEquals(0.5f, fin(st, mats)[3], 1e-6f)
        st.reset(); st.apply(hide, 1f); assertEquals(0f, fin(st, mats)[3], 1e-6f)
        assertEquals(1f, fin(st, mats)[0], 1e-6f)                // outros canais intactos
    }

    @Test fun addAccumulatesWeightedAndClamps() {
        val mats = listOf(mat()); val st = MaterialMorphState(1)
        val blush = elem(0, true, vals(8 to 0.4f, base = 0f))
        st.apply(blush, 0.5f); assertEquals(0.4f, fin(st, mats)[8], 1e-6f)    // 0.2 + 0.4*0.5
        st.apply(blush, 1f); assertEquals(0.8f, fin(st, mats)[8], 1e-6f)      // 0.2 + 0.2 + 0.4
        st.apply(blush, 1f); assertEquals(1f, fin(st, mats)[8], 1e-6f)        // limitado a 1
    }

    @Test fun twoMultipliersMultiplyAndAllMaterialsIndexWorks() {
        val mats = listOf(mat(), mat(floatArrayOf(1f, 1f, 1f, 1f))); val st = MaterialMorphState(2)
        val half = elem(-1, false, vals(3 to 0.5f, base = 1f))
        st.apply(half, 1f); st.apply(half, 1f)
        val o = fin(st, mats)
        assertEquals(0.25f, o[3], 1e-6f); assertEquals(0.25f, o[16 + 3], 1e-6f)
    }

    @Test fun outOfRangeMaterialIsIgnoredAndResetRestoresBase() {
        val mats = listOf(mat()); val st = MaterialMorphState(1)
        st.apply(elem(5, true, vals(3 to -1f, base = 0f)), 1f)
        assertEquals(false, st.active)
        st.apply(elem(0, true, vals(3 to -1f, base = 0f)), 1f)
        assertEquals(true, st.active); assertEquals(0f, fin(st, mats)[3], 1e-6f)
        st.reset(); assertEquals(false, st.active); assertEquals(1f, fin(st, mats)[3], 1e-6f)
        st.apply(elem(0, false, vals(3 to 0f, base = 1f)), Float.NaN); assertEquals(false, st.active)
    }
}
