package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.fail
import org.junit.Test
import studio.mmd.mmd.PmxFormatException
import studio.mmd.mmd.PmxParser
import studio.mmd.mmd.VmdCamera
import studio.mmd.mmd.VmdParser
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Escritor binário little-endian para montar PMX/VMD sintéticos (sem arquivos protegidos). */
private class W {
    val o = ByteArrayOutputStream()
    fun u8(v: Int) = apply { o.write(v and 0xFF) }
    fun u16(v: Int) = apply { u8(v); u8(v shr 8) }
    fun i32(v: Int) = apply { u16(v and 0xFFFF); u16(v ushr 16) }
    fun f(v: Float) = i32(java.lang.Float.floatToIntBits(v))
    fun fs(vararg v: Float) = apply { v.forEach { f(it) } }
    fun txt(s: String) = apply { val b = s.toByteArray(Charsets.UTF_16LE); i32(b.size); o.write(b) }
    fun raw(b: ByteArray) = apply { o.write(b) }
    fun zeros(n: Int) = apply { o.write(ByteArray(n)) }
    fun fixed(s: String, n: Int, cs: java.nio.charset.Charset = Charsets.US_ASCII) = apply { val a = ByteArray(n); val e = s.toByteArray(cs); System.arraycopy(e, 0, a, 0, minOf(e.size, n)); o.write(a) }
    fun bytes() = o.toByteArray()
}

/** PMX mínimo: índices de 1 byte, UTF-16LE, 1 UV adicional; 3 vértices, 1 face, 1 textura, 1 material, 2 ossos, 3 morphs, 1 frame, 1 corpo, 1 junta. */
private fun pmx(version: Float = 2.0f, v0: (W) -> Unit = { it.u8(0).u8(0) }, softBody: Boolean = false, upTo: String = "fim"): ByteArray {
    val w = W()
    w.raw("PMX ".toByteArray()).f(version).u8(8).u8(0).u8(1).u8(1).u8(1).u8(1).u8(1).u8(1).u8(1)
    w.txt("Modelo").txt("Model").txt("comentário").txt("comment")
    w.i32(3)
    for (i in 0 until 3) {
        w.fs(i.toFloat(), 0f, 0f).fs(0f, 1f, 0f).fs(0f, 0f).fs(9f, 8f, 7f, 6f)   // pos, normal, uv, 1 uv adicional
        if (i == 0) v0(w) else { w.u8(0).u8(0) }                                       // BDEF1 osso 0
        w.f(1f)
    }
    w.i32(3).u8(0).u8(1).u8(2)
    w.i32(1).txt("tex.png")
    w.i32(1).txt("mat").txt("mat").fs(1f, 1f, 1f, 1f).fs(0f, 0f, 0f).f(5f).fs(0.5f, 0.5f, 0.5f)
        .u8(0x11).fs(0f, 0f, 0f, 1f).f(1f).u8(0).u8(255).u8(0).u8(1).u8(0).txt("memo do material").i32(3)
    w.i32(2)
    w.txt("center").txt("center").fs(0f, 0f, 0f).u8(255).i32(0).u16(0x0001 or 0x0002 or 0x0008 or 0x0010).u8(1)
    w.txt("腕").txt("arm").fs(1f, 0f, 0f).u8(0).i32(0).u16(0x0001 or 0x0400).u8(255).fs(0f, 0f, 1f)
    w.i32(3)
    w.txt("v").txt("v").u8(1).u8(1).i32(1).u8(0).fs(0f, 0.1f, 0f)
    w.txt("uv").txt("uv").u8(1).u8(3).i32(1).u8(0).fs(1f, 2f, 3f, 4f)
    w.txt("mat").txt("mat").u8(4).u8(8).i32(1).u8(0).zeros(113)
    if (upTo == "morphs") return w.bytes()
    w.i32(1).txt("Root").txt("Root").u8(1).i32(1).u8(0).u8(0)
    w.i32(1).txt("rb").txt("rb").u8(0).u8(1).u16(0xFFFF).u8(0).fs(1f, 1f, 1f).fs(0f, 0f, 0f).fs(0f, 0f, 0f).fs(1f, 0.5f, 0.5f, 0f, 0.5f).u8(1)
    if (upTo == "rigid-trunc") return w.bytes().copyOf(w.bytes().size - 30)
    w.i32(1).txt("j").txt("j").u8(0).u8(0).u8(0)
    for (k in 0 until 8) w.fs(0f, 0f, 0f)
    if (softBody) w.i32(0)
    return w.bytes()
}

class PmxParserTest {
    @Test fun parsesMinimalPmx20AndPreservesData() {
        val m = PmxParser.parse(pmx())
        assertEquals(3, m.vertexCount); assertEquals(2, m.bones.size); assertEquals(3, m.morphs.size)
        assertEquals("comentário", m.comment); assertEquals("comment", m.commentEn)
        assertEquals("memo do material", m.materials[0].memo)
        assertEquals(1, m.addUvCount); assertEquals(12, m.addUvs.size); assertEquals(9f, m.addUvs[0], 0f)
        assertEquals(1, m.displayFrames.size); assertEquals(1, m.rigidBodies.size); assertEquals(1, m.joints.size)
        assertNotNull(m.bones[1].fixedAxis); assertNull(m.bones[0].fixedAxis)
        assertEquals(1 * (1 + 16), m.morphs[1].raw!!.size); assertEquals(1 * (1 + 113), m.morphs[2].raw!!.size)
        assertTrue(m.warnings.any { "UV/material/impulso" in it })
        assertTrue(m.warnings.none { "ilegível" in it || "bytes extras" in it })
    }

    @Test fun parsesPmx21WithEmptySoftBodyBlock() {
        val m = PmxParser.parse(pmx(version = 2.1f, softBody = true))
        assertTrue(m.warnings.none { "soft bodies" in it || "bytes extras" in it })
    }

    @Test fun trailingBytesAreReported() {
        val m = PmxParser.parse(pmx() + byteArrayOf(1, 2, 3))
        assertTrue(m.warnings.any { "bytes extras" in it })
    }

    @Test fun sdefIsPreservedAndWarned() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(3).u8(0).u8(1).f(0.25f).fs(1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f) }))
        assertNotNull(m.sdef); assertEquals(3f, m.sdef!![2], 0f); assertEquals(9f, m.sdef!![8], 0f)
        assertEquals(3, m.weightTypes[0].toInt()); assertEquals(0.25f, m.boneWeights[0], 1e-6f); assertEquals(0.75f, m.boneWeights[1], 1e-6f)
        assertTrue(m.warnings.any { "SDEF" in it })
    }

    @Test fun bdef4WeightsAreNormalized() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(2).u8(0).u8(1).u8(255).u8(255).fs(2f, 2f, 0f, 0f) }))
        assertEquals(0.5f, m.boneWeights[0], 1e-6f); assertEquals(0.5f, m.boneWeights[1], 1e-6f)
        assertTrue(m.warnings.any { "normalizados" in it })
    }

    @Test fun invalidBoneIndexInVertexIsZeroedWithWarning() {
        val m = PmxParser.parse(pmx(v0 = { it.u8(0).u8(50) }))
        assertEquals(-1, m.boneIndices[0]); assertEquals(0f, m.boneWeights[0], 0f)
        assertTrue(m.warnings.any { "ossos inexistentes" in it })
    }

    @Test fun truncatedFileReportsSectionAndOffset() {
        val full = pmx(upTo = "morphs")
        try { PmxParser.parse(full.copyOf(full.size - 40)); fail("deveria falhar") }
        catch (e: PmxFormatException) { assertTrue(e.message!!, "seção" in e.message!! && "offset" in e.message!!) }
    }

    @Test fun brokenPhysicsSectionIsReportedNotSilent() {
        val m = PmxParser.parse(pmx(upTo = "rigid-trunc"))
        assertEquals(3, m.vertexCount); assertEquals(0, m.rigidBodies.size)
        assertTrue(m.warnings.any { "corpos rígidos" in it && "ilegível" in it })
        assertEquals(1, m.displayFrames.size)   // o que veio antes é mantido
    }

    @Test fun badSignatureIsRejected() {
        try { PmxParser.parse("NOPE0000000000".toByteArray()); fail("deveria falhar") }
        catch (e: PmxFormatException) { assertTrue("assinatura" in e.message!!) }
    }

    @Test fun absurdCountDoesNotAllocate() {
        val b = pmx(); val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        // contagem de vértices fica depois do cabeçalho e dos 4 textos
        var p = 4 + 4 + 1 + 8
        repeat(4) { p += 4 + bb.getInt(p) }
        bb.putInt(p, 40_000_000)
        try { PmxParser.parse(b); fail("deveria falhar") } catch (e: PmxFormatException) { assertTrue("vértices" in e.message!!) }
    }
}

class VmdParserTest {
    private fun vmd(build: (W) -> Unit): ByteArray { val w = W(); w.fixed("Vocaloid Motion Data 0002", 30).fixed("modelo", 20); build(w); return w.bytes() }
    private fun boneKey(w: W, name: String, frame: Int, x: Float) { w.fixed(name, 15).i32(frame).fs(x, 0f, 0f, 0f, 0f, 0f, 1f); w.zeros(64) }

    @Test fun duplicateFramesKeepLastAndWarn() {
        val d = vmd { w ->
            w.i32(3); boneKey(w, "center", 10, 1f); boneKey(w, "center", 0, 5f); boneKey(w, "center", 10, 2f)
            w.i32(0).i32(0).i32(0).i32(0).i32(0)
        }
        val m = VmdParser.parse(d)
        val t = m.bones.getValue("center")
        assertEquals(listOf(0, 10), t.frames.toList()); assertEquals(2f, t.v[7], 0f)
        assertTrue(m.warnings.any { "repetidas" in it })
    }

    @Test fun ignoredLightShadowAndIkSectionsAreReported() {
        val d = vmd { w ->
            w.i32(0).i32(0).i32(0)                       // ossos, morphs, câmera
            w.i32(1).zeros(28)                           // 1 key de luz
            w.i32(2).zeros(18)                           // 2 keys de sombra
            w.i32(1)                                     // 1 key de IK
        }
        val m = VmdParser.parse(d)
        assertTrue(m.warnings.any { "iluminação" in it }); assertTrue(m.warnings.any { "self-shadow" in it }); assertTrue(m.warnings.any { "IK" in it })
    }

    @Test fun truncatedBoneSectionFails() {
        val d = vmd { w -> w.i32(1000) }
        try { VmdParser.parse(d); fail("deveria falhar") } catch (e: IllegalArgumentException) { assertTrue("truncado" in e.message!!) }
    }

    @Test fun cameraBezierDiagonalIsLinear() {
        val ip = ByteArray(48)
        for (k in 0 until 2) for (c in 0 until 6) { ip[k * 24 + c * 4] = 20; ip[k * 24 + c * 4 + 1] = 107; ip[k * 24 + c * 4 + 2] = 20; ip[k * 24 + c * 4 + 3] = 107 }
        val cam = VmdCamera(intArrayOf(0, 10), floatArrayOf(0f, 10f), FloatArray(6), FloatArray(6), floatArrayOf(30f, 30f), ip)
        val out = FloatArray(8); cam.evaluate(5f, out)
        assertEquals(5f, out[0], 0.05f)
    }

    @Test fun cameraRoundTripReadsBack() {
        val d = vmd { w ->
            w.i32(0).i32(0)
            w.i32(1).i32(7).f(-30f).fs(1f, 2f, 3f).fs(0.1f, 0.2f, 0.3f).zeros(24).i32(45).u8(0)
            w.i32(0).i32(0).i32(0)
        }
        val c = VmdParser.parseCamera(d)!!
        assertEquals(7, c.frames[0]); assertEquals(-30f, c.dist[0], 0f); assertEquals(45f, c.fov[0], 0f)
    }
}
