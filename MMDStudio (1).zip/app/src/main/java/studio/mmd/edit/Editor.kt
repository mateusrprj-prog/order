package studio.mmd.edit

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Keyframe de osso: v = pos xyz + quat xyzw; ip = 16 bytes de Bézier. Imutável por convenção (troca-se o objeto, não os arrays). */
class BKey(val frame: Int, val v: FloatArray, val ip: ByteArray)
class MKey(val frame: Int, val w: Float)

/** Conversão Euler (graus) <-> quaternion. Ordem Y·X·Z (o Z é aplicado primeiro), como no MMD. */
object Euler {
    private fun mul(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
    )

    private fun axis(i: Int, deg: Float): FloatArray {
        val h = Math.toRadians(deg.toDouble()).toFloat() / 2f
        val s = sin(h); val c = cos(h)
        return when (i) {
            0 -> floatArrayOf(s, 0f, 0f, c)
            1 -> floatArrayOf(0f, s, 0f, c)
            else -> floatArrayOf(0f, 0f, s, c)
        }
    }

    fun quat(xDeg: Float, yDeg: Float, zDeg: Float): FloatArray {
        val q = mul(mul(axis(1, yDeg), axis(0, xDeg)), axis(2, zDeg))
        val l = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
        if (l < 1e-8f) return floatArrayOf(0f, 0f, 0f, 1f)
        for (i in 0..3) q[i] /= l
        return q
    }

    /** q = (x,y,z,w). Retorna (x,y,z) em graus. */
    fun euler(q: FloatArray): FloatArray {
        val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
        val r00 = 1 - 2 * (y * y + z * z)
        val r02 = 2 * (x * z + y * w)
        val r10 = 2 * (x * y + z * w)
        val r11 = 1 - 2 * (x * x + z * z)
        val r12 = 2 * (y * z - x * w)
        val r20 = 2 * (x * z - y * w)
        val r22 = 1 - 2 * (x * x + y * y)
        val ex = asin((-r12).coerceIn(-1f, 1f))
        val ey: Float
        val ez: Float
        if (abs(r12) < 0.99999f) { ey = atan2(r02, r22); ez = atan2(r10, r11) }
        else { ey = atan2(-r20, r00); ez = 0f }
        return floatArrayOf(
            Math.toDegrees(ex.toDouble()).toFloat(),
            Math.toDegrees(ey.toDouble()).toFloat(),
            Math.toDegrees(ez.toDouble()).toFloat()
        )
    }
}

/**
 * Dados editáveis da animação (keyframes de ossos e morphs) + desfazer/refazer.
 * Tudo roda na thread principal. A thread GL só recebe o VmdMotion imutável devolvido por [motion].
 *
 * Regra de edição: mexer num osso/morph num quadro cria ou atualiza o keyframe daquele quadro (auto-key).
 */
class Editor(val model: PmxModel) {
    /** Muda a cada edição (inclusive durante o arrasto de um slider). */
    var version by mutableIntStateOf(0)
        private set

    /** Muda só em comandos discretos (zerar, colar, desfazer, carregar VMD...). Os sliders relêem os valores quando isto muda. */
    var stamp by mutableIntStateOf(0)
        private set

    private val boneKeys = HashMap<String, ArrayList<BKey>>()
    private val morphKeys = HashMap<String, ArrayList<MKey>>()
    private val boneCache = HashMap<String, VmdTrack>()
    private val morphCache = HashMap<String, VmdMorphTrack>()
    private val dirtyB = HashSet<String>()
    private val dirtyM = HashSet<String>()
    private val boneNames: Set<String> = model.bones.map { it.name }.toHashSet()
    private var clip: Map<String, FloatArray>? = null

    val hasClip: Boolean get() = !clip.isNullOrEmpty()

    private companion object {
        val IDENT = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)
        val RX = Regex("(?<![A-Za-z])([LR])(?![a-z])")
        val RS = Regex("(?<=[a-z0-9])([LR])\$")

        /** Curva linear padrão do MMD (20,20)-(107,107) nos 4 canais. */
        fun linearIp(): ByteArray {
            val a = ByteArray(16)
            for (i in 0..3) { a[i] = 20; a[4 + i] = 20; a[8 + i] = 107; a[12 + i] = 107 }
            return a
        }

        fun isIdent(v: FloatArray) =
            abs(v[0]) < 1e-6f && abs(v[1]) < 1e-6f && abs(v[2]) < 1e-6f &&
                abs(v[3]) < 1e-6f && abs(v[4]) < 1e-6f && abs(v[5]) < 1e-6f && v[6] > 0.999999f

        /** Espelho no plano X=0: pos (-x,y,z), rotação (qx,-qy,-qz,qw). */
        fun mirrorV(v: FloatArray) = floatArrayOf(-v[0], v[1], v[2], v[3], -v[4], -v[5], v[6])

        fun bez(ip: ByteArray, i1: Int, i2: Int, i3: Int, i4: Int, s: Float): Float {
            val x1 = (ip[i1].toInt() and 0xFF) / 127f; val y1 = (ip[i2].toInt() and 0xFF) / 127f
            val x2 = (ip[i3].toInt() and 0xFF) / 127f; val y2 = (ip[i4].toInt() and 0xFF) / 127f
            if (x1 == y1 && x2 == y2) return s
            var lo = 0f; var hi = 1f; var t = s
            for (k in 0 until 18) {
                t = (lo + hi) / 2
                val u = 1 - t
                val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
                if (x < s) lo = t else hi = t
            }
            val u = 1 - t
            return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
        }

        /** Índice do keyframe em [frame] ou -(ponto de inserção)-1. */
        fun idxB(l: List<BKey>, frame: Int): Int {
            var lo = 0; var hi = l.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1; val f = l[mid].frame
                if (f == frame) return mid
                if (f < frame) lo = mid + 1 else hi = mid - 1
            }
            return -(lo + 1)
        }

        fun idxM(l: List<MKey>, frame: Int): Int {
            var lo = 0; var hi = l.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1; val f = l[mid].frame
                if (f == frame) return mid
                if (f < frame) lo = mid + 1 else hi = mid - 1
            }
            return -(lo + 1)
        }
    }

    // ---------------------------------------------------------------- consulta

    fun hasTrack(name: String) = boneKeys[name]?.isNotEmpty() == true
    fun hasMorphTrack(name: String) = morphKeys[name]?.isNotEmpty() == true
    fun hasKey(name: String, frame: Int): Boolean = boneKeys[name]?.let { idxB(it, frame) >= 0 } ?: false

    fun keyFramesOf(name: String): IntArray {
        val l = boneKeys[name] ?: return IntArray(0)
        return IntArray(l.size) { l[it].frame }
    }

    fun allKeyFrames(): IntArray {
        val s = HashSet<Int>()
        for (l in boneKeys.values) for (k in l) s.add(k.frame)
        for (l in morphKeys.values) for (k in l) s.add(k.frame)
        val a = s.toIntArray(); a.sort(); return a
    }

    /** Valor local do osso no quadro [f] (pos xyz + quat xyzw), interpolado como o Animator faz. */
    fun sampleBone(name: String, f: Float, o: FloatArray) {
        val l = boneKeys[name]
        if (l == null || l.isEmpty()) { IDENT.copyInto(o); return }
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) { l[0].v.copyInto(o); return }
        if (i == l.size - 1) { l[i].v.copyInto(o); return }
        val a = l[i]; val b = l[i + 1]
        val s = (f - a.frame) / (b.frame - a.frame)
        val sx = bez(b.ip, 0, 4, 8, 12, s); val sy = bez(b.ip, 1, 5, 9, 13, s)
        val sz = bez(b.ip, 2, 6, 10, 14, s); val sr = bez(b.ip, 3, 7, 11, 15, s)
        o[0] = a.v[0] + (b.v[0] - a.v[0]) * sx
        o[1] = a.v[1] + (b.v[1] - a.v[1]) * sy
        o[2] = a.v[2] + (b.v[2] - a.v[2]) * sz
        var dot = 0f
        for (c in 0..3) dot += a.v[3 + c] * b.v[3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val q = a.v[3 + c] * (1 - sr) + b.v[3 + c] * sg * sr; o[3 + c] = q; len += q * q }
        len = sqrt(len)
        if (len > 1e-8f) for (c in 0..3) o[3 + c] /= len
    }

    fun sampleMorph(name: String, f: Float): Float {
        val l = morphKeys[name]
        if (l == null || l.isEmpty()) return 0f
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) return l[0].w
        if (i == l.size - 1) return l[i].w
        val s = (f - l[i].frame) / (l[i + 1].frame - l[i].frame)
        return l[i].w + (l[i + 1].w - l[i].w) * s
    }

    // ---------------------------------------------------------------- escrita de baixo nível (sem undo)

    private fun putBone(name: String, frame: Int, v: FloatArray, ip: ByteArray?) {
        val l = boneKeys.getOrPut(name) { ArrayList() }
        val i = idxB(l, frame)
        if (i >= 0) l[i] = BKey(frame, v, ip ?: l[i].ip) else l.add(-(i + 1), BKey(frame, v, ip ?: linearIp()))
        dirtyB.add(name)
    }

    private fun removeBone(name: String, frame: Int): Boolean {
        val l = boneKeys[name] ?: return false
        val i = idxB(l, frame)
        if (i < 0) return false
        l.removeAt(i)
        if (l.isEmpty()) boneKeys.remove(name)
        dirtyB.add(name)
        return true
    }

    private fun putMorph(name: String, frame: Int, w: Float) {
        val l = morphKeys.getOrPut(name) { ArrayList() }
        val i = idxM(l, frame)
        if (i >= 0) l[i] = MKey(frame, w) else l.add(-(i + 1), MKey(frame, w))
        dirtyM.add(name)
    }

    private fun removeMorph(name: String, frame: Int): Boolean {
        val l = morphKeys[name] ?: return false
        val i = idxM(l, frame)
        if (i < 0) return false
        l.removeAt(i)
        if (l.isEmpty()) morphKeys.remove(name)
        dirtyM.add(name)
        return true
    }

    // ---------------------------------------------------------------- desfazer / refazer

    private class Snap(val b: Map<String, List<BKey>?>, val m: Map<String, List<MKey>?>)
    private class Entry(val before: Snap, val after: Snap)

    private val undoS = ArrayList<Entry>()
    private val redoS = ArrayList<Entry>()
    private var openBefore: Snap? = null
    private var openB: Set<String> = emptySet()
    private var openM: Set<String> = emptySet()

    val canUndo: Boolean get() = undoS.isNotEmpty() || openBefore != null
    val canRedo: Boolean get() = redoS.isNotEmpty()

    private fun snap(bn: Collection<String>, mn: Collection<String>): Snap =
        Snap(bn.associateWith { n -> boneKeys[n]?.let { ArrayList(it) } },
            mn.associateWith { n -> morphKeys[n]?.let { ArrayList(it) } })

    private fun restore(s: Snap) {
        for ((k, v) in s.b) { if (v == null) boneKeys.remove(k) else boneKeys[k] = ArrayList(v); dirtyB.add(k) }
        for ((k, v) in s.m) { if (v == null) morphKeys.remove(k) else morphKeys[k] = ArrayList(v); dirtyM.add(k) }
    }

    private fun bump(discrete: Boolean) { version++; if (discrete) stamp++ }

    private fun begin(bn: Collection<String>, mn: Collection<String> = emptyList()) {
        if (openBefore != null) {
            if (openB == bn.toSet() && openM == mn.toSet()) return
            commit()
        }
        openB = bn.toSet(); openM = mn.toSet()
        openBefore = snap(openB, openM)
    }

    private fun commit() {
        val b = openBefore ?: return
        openBefore = null
        undoS.add(Entry(b, snap(openB, openM)))
        redoS.clear()
        while (undoS.size > 100) undoS.removeAt(0)
    }

    private inline fun edit(bn: Collection<String>, mn: Collection<String> = emptyList(), block: () -> Unit) {
        begin(bn, mn); block(); commit(); bump(true)
    }

    /** Chamar quando o arrasto de um slider termina: fecha a transação (um único passo de desfazer). */
    fun finish() { commit(); version++ }

    fun undo(): Boolean {
        commit()
        if (undoS.isEmpty()) return false
        val e = undoS.removeAt(undoS.lastIndex)
        restore(e.before); redoS.add(e); bump(true)
        return true
    }

    fun redo(): Boolean {
        commit()
        if (redoS.isEmpty()) return false
        val e = redoS.removeAt(redoS.lastIndex)
        restore(e.after); undoS.add(e); bump(true)
        return true
    }

    // ---------------------------------------------------------------- edição de ossos

    /** Edição contínua (slider): cria/atualiza o keyframe de [name] no [frame]. Fechar com [finish]. */
    fun liveBone(name: String, frame: Int, rot: FloatArray?, pos: FloatArray?) {
        begin(listOf(name))
        val cur = FloatArray(7)
        sampleBone(name, frame.toFloat(), cur)
        if (rot != null) for (i in 0..3) cur[3 + i] = rot[i]
        if (pos != null) for (i in 0..2) cur[i] = pos[i]
        putBone(name, frame, cur, null)
        version++
    }

    /** Cria keyframe (valor atual interpolado) nos ossos que ainda não têm key no quadro. */
    fun keyBones(names: Collection<String>, frame: Int): Int {
        var c = 0
        edit(names) {
            for (n in names) {
                if (hasKey(n, frame)) continue
                val o = FloatArray(7); sampleBone(n, frame.toFloat(), o)
                putBone(n, frame, o, null); c++
            }
        }
        return c
    }

    fun deleteKeys(names: Collection<String>, frame: Int): Int {
        var c = 0
        edit(names) { for (n in names) if (removeBone(n, frame)) c++ }
        return c
    }

    fun zeroBones(names: Collection<String>, frame: Int) {
        edit(names) { for (n in names) putBone(n, frame, IDENT.copyOf(), null) }
    }

    fun mirrorBone(name: String, frame: Int): Boolean {
        val p = mirrorName(name) ?: return false
        val o = FloatArray(7); sampleBone(name, frame.toFloat(), o)
        edit(listOf(p)) { putBone(p, frame, mirrorV(o), null) }
        return true
    }

    // ---------------------------------------------------------------- pose inteira

    fun copyPose(frame: Int): Int {
        val m = HashMap<String, FloatArray>()
        for (n in boneNames) {
            val o = FloatArray(7); sampleBone(n, frame.toFloat(), o)
            if (boneKeys.containsKey(n) || !isIdent(o)) m[n] = o
        }
        clip = m
        bump(false)
        return m.size
    }

    fun pastePose(frame: Int): Int {
        val c = clip ?: return 0
        edit(c.keys.toList()) { for ((n, v) in c) putBone(n, frame, v.copyOf(), null) }
        return c.size
    }

    fun mirrorPose(frame: Int): Int {
        val cur = HashMap<String, FloatArray>()
        for (n in boneNames) { val o = FloatArray(7); sampleBone(n, frame.toFloat(), o); cur[n] = o }
        val out = HashMap<String, FloatArray>()
        for (n in boneNames) {
            val p = mirrorName(n)
            if (p != null) out[n] = mirrorV(cur.getValue(p))
            else if (!hasSide(n)) out[n] = mirrorV(cur.getValue(n))
        }
        var c = 0
        edit(out.keys.toList()) {
            for ((n, v) in out) if (boneKeys.containsKey(n) || !isIdent(v)) { putBone(n, frame, v, null); c++ }
        }
        return c
    }

    fun zeroPose(frame: Int): Int {
        val names = boneKeys.keys.toList()
        edit(names) { for (n in names) putBone(n, frame, IDENT.copyOf(), null) }
        return names.size
    }

    fun resetPose(frame: Int): Int {
        val names = boneKeys.keys.toList()
        var c = 0
        edit(names) { for (n in names) if (removeBone(n, frame)) c++ }
        return c
    }

    // ---------------------------------------------------------------- morphs

    fun liveMorph(name: String, frame: Int, w: Float) {
        begin(emptyList(), listOf(name))
        putMorph(name, frame, w)
        version++
    }

    fun zeroMorph(name: String, frame: Int) { edit(emptyList(), listOf(name)) { putMorph(name, frame, 0f) } }
    fun deleteMorphKey(name: String, frame: Int): Boolean {
        var ok = false
        edit(emptyList(), listOf(name)) { ok = removeMorph(name, frame) }
        return ok
    }

    // ---------------------------------------------------------------- lado esquerdo/direito

    private fun hasSide(n: String): Boolean =
        n.contains('左') || n.contains('右') || n.contains("Left") || n.contains("Right") ||
            n.contains("left") || n.contains("right") || RX.containsMatchIn(n) || RS.containsMatchIn(n)

    /** Nome do osso do outro lado (só se existir no modelo), ou null. */
    fun mirrorName(n: String): String? {
        val t = when {
            n.contains('左') -> n.replace('左', '右')
            n.contains('右') -> n.replace('右', '左')
            n.contains("Left") -> n.replace("Left", "Right")
            n.contains("Right") -> n.replace("Right", "Left")
            n.contains("left") -> n.replace("left", "right")
            n.contains("right") -> n.replace("right", "left")
            RX.containsMatchIn(n) -> RX.replace(n) { if (it.value == "L") "R" else "L" }
            RS.containsMatchIn(n) -> RS.replace(n) { if (it.value == "L") "R" else "L" }
            else -> return null
        }
        return if (t != n && t in boneNames) t else null
    }

    // ---------------------------------------------------------------- ligação com VMD / renderer

    /** Substitui toda a animação pelo conteúdo do VMD (só ossos/morphs que existem no modelo). Limpa o desfazer. */
    fun load(mo: VmdMotion) {
        boneKeys.clear(); morphKeys.clear(); boneCache.clear(); morphCache.clear()
        dirtyB.clear(); dirtyM.clear(); undoS.clear(); redoS.clear(); openBefore = null
        val mn = model.morphs.map { it.name }.toHashSet()
        for ((n, t) in mo.bones) {
            if (n !in boneNames) continue
            val l = ArrayList<BKey>(t.frames.size)
            for (i in t.frames.indices) l.add(BKey(t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
            boneKeys[n] = l; dirtyB.add(n)
        }
        for ((n, t) in mo.morphs) {
            if (n !in mn) continue
            val l = ArrayList<MKey>(t.frames.size)
            for (i in t.frames.indices) l.add(MKey(t.frames[i], t.w[i]))
            morphKeys[n] = l; dirtyM.add(n)
        }
        bump(true)
    }

    /** Monta o VmdMotion imutável para o Animator, reconstruindo só as trilhas alteradas. */
    fun motion(): VmdMotion {
        for (n in dirtyB) {
            val l = boneKeys[n]
            if (l == null || l.isEmpty()) { boneCache.remove(n); continue }
            val v = FloatArray(l.size * 7); val ip = ByteArray(l.size * 16)
            for (i in l.indices) { l[i].v.copyInto(v, i * 7); l[i].ip.copyInto(ip, i * 16) }
            boneCache[n] = VmdTrack(IntArray(l.size) { l[it].frame }, v, ip)
        }
        dirtyB.clear()
        for (n in dirtyM) {
            val l = morphKeys[n]
            if (l == null || l.isEmpty()) { morphCache.remove(n); continue }
            morphCache[n] = VmdMorphTrack(IntArray(l.size) { l[it].frame }, FloatArray(l.size) { l[it].w })
        }
        dirtyM.clear()
        var mx = 0
        for (t in boneCache.values) mx = max(mx, t.frames[t.frames.size - 1])
        for (t in morphCache.values) mx = max(mx, t.frames[t.frames.size - 1])
        return VmdMotion("editado", HashMap(boneCache), HashMap(morphCache), mx)
    }
}
