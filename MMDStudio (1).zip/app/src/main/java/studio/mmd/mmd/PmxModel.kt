package studio.mmd.mmd

/** Modelo PMX já interpretado (coordenadas originais do MMD, mão esquerda). */
class PmxModel(
    val name: String,
    val version: Float,
    val positions: FloatArray,      // 3 por vértice
    val normals: FloatArray,        // 3 por vértice
    val uvs: FloatArray,            // 2 por vértice
    val boneIndices: IntArray,      // 4 por vértice (-1 = vazio)
    val boneWeights: FloatArray,    // 4 por vértice
    val indices: IntArray,          // triângulos
    val textures: List<String>,
    val materials: List<PmxMaterial>,
    val bones: List<PmxBone>,
    val morphs: List<PmxMorph>
) {
    val vertexCount get() = positions.size / 3
}

class PmxMaterial(
    val name: String, val nameEn: String,
    val diffuse: FloatArray, val specular: FloatArray, val specularPower: Float, val ambient: FloatArray,
    val flags: Int, val edgeColor: FloatArray, val edgeSize: Float,
    val textureIndex: Int, val sphereIndex: Int, val sphereMode: Int,
    val toonShared: Boolean, val toonIndex: Int,
    val indexCount: Int
) { val doubleSided get() = flags and 1 != 0 }

class PmxIkLink(val bone: Int, val hasLimit: Boolean, val min: FloatArray?, val max: FloatArray?)
class PmxIk(val target: Int, val loopCount: Int, val limitAngle: Float, val links: List<PmxIkLink>)

class PmxBone(
    val name: String, val nameEn: String,
    val x: Float, val y: Float, val z: Float,
    val parent: Int, val layer: Int, val flags: Int,
    val tailBone: Int, val inheritParent: Int, val inheritWeight: Float,
    val ik: PmxIk?
)

/** type: 0 grupo, 1 vértice, 2 osso, 3-7 UV, 8 material, 9 flip, 10 impulso. Só 0/1/2/9 guardam dados por enquanto. */
class PmxMorph(
    val name: String, val nameEn: String, val panel: Int, val type: Int,
    val vertexIdx: IntArray? = null, val vertexDelta: FloatArray? = null,
    val boneIdx: IntArray? = null, val boneTrans: FloatArray? = null, val boneRot: FloatArray? = null,
    val groupIdx: IntArray? = null, val groupRate: FloatArray? = null
)
