package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/** Keyframes de um osso: 7 floats por key (pos xyz + quat xyzw) e 16 bytes de interpolação Bézier por key. */
class VmdTrack(val frames: IntArray, val v: FloatArray, val ip: ByteArray)
class VmdMorphTrack(val frames: IntArray, val w: FloatArray)

class VmdMotion(
    val modelName: String,
    val bones: Map<String, VmdTrack>,
    val morphs: Map<String, VmdMorphTrack>,
    val maxFrame: Int
)

/** Leitor de VMD (versões 1 e 2). Lê keyframes de ossos e morphs; câmera/luz/sombra/IK-switch são ignorados por ora. */
object VmdParser {
    private val SJIS: Charset = Charset.forName("Shift_JIS")

    private class BKey(val frame: Int, val v: FloatArray, val ip: ByteArray)

    fun parse(data: ByteArray): VmdMotion {
        if (data.size < 50) throw IllegalArgumentException("Arquivo VMD muito pequeno")
        if (!String(data, 0, 30, Charsets.US_ASCII).startsWith("Vocaloid Motion Data"))
            throw IllegalArgumentException("Não é um arquivo VMD (assinatura inválida)")
        val v2 = String(data, 0, 30, Charsets.US_ASCII).contains("0002")
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        b.position(30)
        val modelName = str(b, if (v2) 20 else 10)
        var maxFrame = 0

        val nb = b.int
        if (nb < 0 || nb.toLong() * 111 > b.remaining()) throw IllegalArgumentException("VMD truncado (ossos)")
        val boneKeys = HashMap<String, MutableList<BKey>>()
        repeat(nb) {
            val name = str(b, 15); val frame = b.int
            val v = FloatArray(7) { b.float }
            var len = Math.sqrt((v[3] * v[3] + v[4] * v[4] + v[5] * v[5] + v[6] * v[6]).toDouble()).toFloat()
            if (len < 1e-6f) { v[3] = 0f; v[4] = 0f; v[5] = 0f; v[6] = 1f; len = 1f }
            for (k in 3..6) v[k] /= len
            val ip = ByteArray(64); b.get(ip)
            if (frame > maxFrame) maxFrame = frame
            boneKeys.getOrPut(name) { ArrayList() }.add(BKey(frame, v, ip.copyOfRange(0, 16)))
        }
        val bones = boneKeys.mapValues { (_, list) ->
            list.sortBy { it.frame }
            val v = FloatArray(list.size * 7); val ip = ByteArray(list.size * 16)
            list.forEachIndexed { i, k -> k.v.copyInto(v, i * 7); k.ip.copyInto(ip, i * 16) }
            VmdTrack(IntArray(list.size) { list[it].frame }, v, ip)
        }

        val morphs = HashMap<String, VmdMorphTrack>()
        if (b.remaining() >= 4) {
            val nm = b.int
            if (nm < 0 || nm.toLong() * 23 > b.remaining()) throw IllegalArgumentException("VMD truncado (morphs)")
            val tmp = HashMap<String, MutableList<Pair<Int, Float>>>()
            repeat(nm) {
                val name = str(b, 15); val frame = b.int; val w = b.float
                if (frame > maxFrame) maxFrame = frame
                tmp.getOrPut(name) { ArrayList() }.add(frame to w)
            }
            for ((k, l) in tmp) { l.sortBy { it.first }; morphs[k] = VmdMorphTrack(IntArray(l.size) { l[it].first }, FloatArray(l.size) { l[it].second }) }
        }
        return VmdMotion(modelName, bones, morphs, maxFrame)
    }

    private fun str(b: ByteBuffer, n: Int): String {
        val a = ByteArray(n); b.get(a)
        var e = a.indexOf(0); if (e < 0) e = n
        return String(a, 0, e, SJIS)
    }
}
