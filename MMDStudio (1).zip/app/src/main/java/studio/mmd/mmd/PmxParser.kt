package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

class PmxFormatException(msg: String) : Exception(msg)

/** Leitor de PMX 2.0 / 2.1. Lê até os morphs (o restante — frames, rigid bodies, joints — será tratado depois). */
object PmxParser {
    private class R(bytes: ByteArray) {
        val b: ByteBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        fun u8() = b.get().toInt() and 0xFF
        fun u16() = b.short.toInt() and 0xFFFF
        fun i32() = b.int
        fun f() = b.float
        fun skip(n: Int) { b.position(b.position() + n) }
        fun bytes(n: Int) = ByteArray(n).also { b.get(it) }
        fun sidx(size: Int) = when (size) { 1 -> b.get().toInt(); 2 -> b.short.toInt(); else -> b.int }
        fun uidx(size: Int) = when (size) { 1 -> u8(); 2 -> u16(); else -> b.int }
        fun count(): Int { val n = i32(); if (n < 0 || n > 50_000_000) throw PmxFormatException("Contagem inválida: $n"); return n }
        fun text(enc: Int): String {
            val n = count()
            return String(bytes(n), if (enc == 0) Charsets.UTF_16LE else Charsets.UTF_8)
        }
        fun floats(n: Int) = FloatArray(n) { f() }
    }

    fun parse(data: ByteArray): PmxModel {
        try { return parseInternal(R(data)) }
        catch (e: PmxFormatException) { throw e }
        catch (e: Exception) { throw PmxFormatException("Arquivo PMX truncado ou inválido (${e.javaClass.simpleName})") }
    }

    private fun parseInternal(r: R): PmxModel {
        if (String(r.bytes(4), Charsets.US_ASCII) != "PMX ") throw PmxFormatException("Não é um arquivo PMX (assinatura inválida)")
        val version = r.f()
        val gc = r.u8()
        if (gc < 8) throw PmxFormatException("Cabeçalho PMX inválido")
        val g = IntArray(gc) { r.u8() }
        val enc = g[0]; val addUv = g[1]; val vS = g[2]; val tS = g[3]; val mS = g[4]; val bS = g[5]; val moS = g[6]
        val name = r.text(enc); r.text(enc); r.text(enc); r.text(enc)

        // Vértices
        val vc = r.count()
        val pos = FloatArray(vc * 3); val nrm = FloatArray(vc * 3); val uv = FloatArray(vc * 2)
        val bi = IntArray(vc * 4) { -1 }; val bw = FloatArray(vc * 4)
        for (i in 0 until vc) {
            for (k in 0..2) pos[i * 3 + k] = r.f()
            for (k in 0..2) nrm[i * 3 + k] = r.f()
            uv[i * 2] = r.f(); uv[i * 2 + 1] = r.f()
            r.skip(16 * addUv)
            when (val t = r.u8()) {
                0 -> { bi[i * 4] = r.sidx(bS); bw[i * 4] = 1f }
                1, 3 -> {
                    bi[i * 4] = r.sidx(bS); bi[i * 4 + 1] = r.sidx(bS)
                    val w = r.f(); bw[i * 4] = w; bw[i * 4 + 1] = 1f - w
                    if (t == 3) r.skip(36) // SDEF C, R0, R1 (tratado como BDEF2 por ora)
                }
                2, 4 -> {
                    for (k in 0..3) bi[i * 4 + k] = r.sidx(bS)
                    for (k in 0..3) bw[i * 4 + k] = r.f()
                }
                else -> throw PmxFormatException("Tipo de peso desconhecido: $t")
            }
            r.f() // edge scale
        }

        // Faces
        val fc = r.count()
        if (fc % 3 != 0) throw PmxFormatException("Número de índices não é múltiplo de 3")
        val indices = IntArray(fc) { r.uidx(vS) }
        for (ix in indices) if (ix < 0 || ix >= vc) throw PmxFormatException("Índice de vértice fora do intervalo")

        // Texturas
        val textures = List(r.count()) { r.text(enc) }

        // Materiais
        val materials = List(r.count()) {
            val n = r.text(enc); val ne = r.text(enc)
            val diffuse = r.floats(4); val spec = r.floats(3); val sp = r.f(); val amb = r.floats(3)
            val flags = r.u8(); val edgeC = r.floats(4); val edgeS = r.f()
            val tex = r.sidx(tS); val sph = r.sidx(tS); val sphMode = r.u8()
            val shared = r.u8() == 1
            val toon = if (shared) r.u8() else r.sidx(tS)
            r.text(enc) // memo
            PmxMaterial(n, ne, diffuse, spec, sp, amb, flags, edgeC, edgeS, tex, sph, sphMode, shared, toon, r.i32())
        }

        // Ossos
        val bones = List(r.count()) {
            val n = r.text(enc); val ne = r.text(enc)
            val x = r.f(); val y = r.f(); val z = r.f()
            val parent = r.sidx(bS); val layer = r.i32(); val flags = r.u16()
            var tail = -1
            if (flags and 0x0001 != 0) tail = r.sidx(bS) else r.skip(12)
            var ip = -1; var iw = 0f
            if (flags and 0x0300 != 0) { ip = r.sidx(bS); iw = r.f() }
            if (flags and 0x0400 != 0) r.skip(12)
            if (flags and 0x0800 != 0) r.skip(24)
            if (flags and 0x2000 != 0) r.skip(4)
            var ik: PmxIk? = null
            if (flags and 0x0020 != 0) {
                val target = r.sidx(bS); val loop = r.i32(); val lim = r.f()
                val links = List(r.count()) {
                    val lb = r.sidx(bS); val has = r.u8() == 1
                    if (has) PmxIkLink(lb, true, r.floats(3), r.floats(3)) else PmxIkLink(lb, false, null, null)
                }
                ik = PmxIk(target, loop, lim, links)
            }
            PmxBone(n, ne, x, y, z, parent, layer, flags, tail, ip, iw, ik)
        }

        // Morphs
        val morphs = List(r.count()) {
            val n = r.text(enc); val ne = r.text(enc); val panel = r.u8(); val type = r.u8()
            val cnt = r.count()
            when (type) {
                0, 9 -> {
                    val idx = IntArray(cnt); val rate = FloatArray(cnt)
                    for (k in 0 until cnt) { idx[k] = r.sidx(moS); rate[k] = r.f() }
                    PmxMorph(n, ne, panel, type, groupIdx = idx, groupRate = rate)
                }
                1 -> {
                    val idx = IntArray(cnt); val d = FloatArray(cnt * 3)
                    for (k in 0 until cnt) { idx[k] = r.uidx(vS); for (c in 0..2) d[k * 3 + c] = r.f() }
                    PmxMorph(n, ne, panel, type, vertexIdx = idx, vertexDelta = d)
                }
                2 -> {
                    val idx = IntArray(cnt); val t = FloatArray(cnt * 3); val q = FloatArray(cnt * 4)
                    for (k in 0 until cnt) {
                        idx[k] = r.sidx(bS)
                        for (c in 0..2) t[k * 3 + c] = r.f()
                        for (c in 0..3) q[k * 4 + c] = r.f()
                    }
                    PmxMorph(n, ne, panel, type, boneIdx = idx, boneTrans = t, boneRot = q)
                }
                3, 4, 5, 6, 7 -> { r.skip(cnt * (vS + 16)); PmxMorph(n, ne, panel, type) }
                8 -> { r.skip(cnt * (mS + 113)); PmxMorph(n, ne, panel, type) }
                10 -> { r.skip(cnt * (g[7] + 25)); PmxMorph(n, ne, panel, type) }
                else -> throw PmxFormatException("Tipo de morph desconhecido: $type")
            }
        }
        return PmxModel(name, version, pos, nrm, uv, bi, bw, indices, textures, materials, bones, morphs)
    }
}
