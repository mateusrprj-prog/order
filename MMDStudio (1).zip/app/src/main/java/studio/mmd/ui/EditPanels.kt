package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.edit.Editor
import studio.mmd.edit.Euler
import studio.mmd.mmd.PmxBone
import kotlin.math.min

/** Painel do modo Esqueleto: abas Ossos / Osso / Pose / Morphs. */
@Composable
fun SkeletonPanel(
    ed: Editor, frame: Int,
    tab: Int, onTab: (Int) -> Unit,
    selBone: Int, onSelBone: (Int) -> Unit,
    selMorph: Int, onSelMorph: (Int) -> Unit,
    note: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val titles = listOf("Ossos", "Osso", "Pose", "Morphs")
    Column(modifier.background(Panel, RoundedCornerShape(8.dp))) {
        Row(Modifier.fillMaxWidth()) {
            titles.forEachIndexed { i, t ->
                Column(Modifier.weight(1f).clickable { onTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(t, color = if (i == tab) Color.White else Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(if (i == tab) Accent else Color.Transparent))
                }
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp)) {
            when (tab) {
                0 -> BonesTab(ed, selBone, onSelBone)
                1 -> BoneTab(ed, frame, selBone, note)
                2 -> PoseTab(ed, frame, note)
                else -> MorphTab(ed, frame, selMorph, onSelMorph)
            }
        }
    }
}

// ------------------------------------------------------------------ componentes pequenos

@Composable
private fun SearchBox(q: String, hint: String, onChange: (String) -> Unit) {
    BasicTextField(
        value = q, onValueChange = onChange, singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Accent),
        modifier = Modifier.fillMaxWidth().background(Color(0xFF101114), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 8.dp),
        decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Muted, fontSize = 13.sp); inner() } }
    )
}

@Composable
private fun RowScope.Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled) { onClick() }.padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (enabled) Color.White else Color(0xFF5A5C62), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, digits: Int,
    onChange: (Float) -> Unit, onDone: () -> Unit
) {
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        if (label.isNotEmpty()) Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(16.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange,
            onValueChangeFinished = onDone, valueRange = range, modifier = Modifier.weight(1f)
        )
        Text("%.${digits}f%s".format(value, unit), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(58.dp))
    }
}

// ------------------------------------------------------------------ aba Ossos

private class BRow(val idx: Int, val depth: Int, val kids: Boolean)

private fun buildRows(bones: List<PmxBone>, q: String, collapsed: List<Int>): List<BRow> {
    val n = bones.size
    if (q.isNotBlank()) {
        val s = q.trim().lowercase()
        return bones.indices.filter { bones[it].name.lowercase().contains(s) || bones[it].nameEn.lowercase().contains(s) }.map { BRow(it, 0, false) }
    }
    val kids = Array(n) { ArrayList<Int>() }
    val roots = ArrayList<Int>()
    for (i in 0 until n) { val p = bones[i].parent; if (p in 0 until n && p != i) kids[p].add(i) else roots.add(i) }
    val out = ArrayList<BRow>(n)
    val seen = BooleanArray(n)
    fun walk(i: Int, d: Int) {
        if (seen[i]) return
        seen[i] = true
        out.add(BRow(i, d, kids[i].isNotEmpty()))
        if (i in collapsed) return
        for (c in kids[i]) walk(c, d + 1)
    }
    for (r in roots) walk(r, 0)
    return out
}

@Composable
private fun BonesTab(ed: Editor, sel: Int, onSel: (Int) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val bones = ed.model.bones
    var q by remember { mutableStateOf("") }
    val collapsed = remember { mutableStateListOf<Int>() }
    val rows = remember(ed, q, collapsed.toList()) { buildRows(bones, q, collapsed.toList()) }
    Column(Modifier.fillMaxSize()) {
        SearchBox(q, "Buscar osso") { q = it }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(rows, key = { it.idx }) { r ->
                val b = bones[r.idx]
                Row(
                    Modifier.fillMaxWidth().background(if (r.idx == sel) Accent.copy(alpha = .35f) else Color.Transparent)
                        .clickable { onSel(r.idx) }.padding(start = (min(r.depth, 12) * 10).dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (r.kids) (if (r.idx in collapsed) "▸" else "▾") else "·", color = Muted, fontSize = 14.sp,
                        modifier = Modifier.clickable(enabled = r.kids) { if (r.idx in collapsed) collapsed.remove(r.idx) else collapsed.add(r.idx) }
                            .padding(horizontal = 6.dp, vertical = 6.dp).width(16.dp)
                    )
                    Text(b.name.ifBlank { "osso ${r.idx}" }, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (b.nameEn.isNotBlank() && b.nameEn != b.name)
                        Text("  ${b.nameEn}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (ed.hasTrack(b.name)) Text("  ◆", color = Accent, fontSize = 11.sp)
                    Spacer(Modifier.width(6.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ aba Osso

@Composable
private fun BoneTab(ed: Editor, frame: Int, sel: Int, note: (String) -> Unit) {
    if (sel !in ed.model.bones.indices) {
        Text("Toque num osso no modelo ou escolha na aba Ossos.", color = Muted, fontSize = 12.sp)
        return
    }
    val b = ed.model.bones[sel]
    val name = b.name
    val rotatable = b.flags and 0x0002 != 0
    val movable = b.flags and 0x0004 != 0
    val showRot = rotatable || !movable
    val showMove = movable || !rotatable
    val stamp = ed.stamp
    val cur = remember(name, frame, stamp) { FloatArray(7).also { ed.sampleBone(name, frame.toFloat(), it) } }
    var eul by remember(name, frame, stamp) { mutableStateOf(Euler.euler(cur.copyOfRange(3, 7))) }
    var pos by remember(name, frame, stamp) { mutableStateOf(cur.copyOfRange(0, 3)) }
    val hasKey = ed.hasKey(name, frame)

    fun rot(e: FloatArray) { eul = e; ed.liveBone(name, frame, Euler.quat(e[0], e[1], e[2]), null) }
    fun move(p: FloatArray) { pos = p; ed.liveBone(name, frame, null, p) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text(name.ifBlank { "osso $sel" } + if (hasKey) "   ◆ keyframe neste quadro" else "", color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (showRot) {
            Text("Rotação (graus)", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            SliderRow("X", eul[0], -180f..180f, "°", 1, { rot(floatArrayOf(it, eul[1], eul[2])) }, { ed.finish() })
            SliderRow("Y", eul[1], -180f..180f, "°", 1, { rot(floatArrayOf(eul[0], it, eul[2])) }, { ed.finish() })
            SliderRow("Z", eul[2], -180f..180f, "°", 1, { rot(floatArrayOf(eul[0], eul[1], it)) }, { ed.finish() })
        }
        if (showMove) {
            Text("Posição", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            SliderRow("X", pos[0], -30f..30f, "", 2, { move(floatArrayOf(it, pos[1], pos[2])) }, { ed.finish() })
            SliderRow("Y", pos[1], -30f..30f, "", 2, { move(floatArrayOf(pos[0], it, pos[2])) }, { ed.finish() })
            SliderRow("Z", pos[2], -30f..30f, "", 2, { move(floatArrayOf(pos[0], pos[1], it)) }, { ed.finish() })
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Zerar osso") { ed.zeroBones(listOf(name), frame); note("Osso zerado no quadro $frame") }
            Btn("Espelhar") { note(if (ed.mirrorBone(name, frame)) "Copiado espelhado para o outro lado" else "Esse osso não tem par esquerdo/direito") }
            Btn("Resetar osso", enabled = hasKey) { ed.deleteKeys(listOf(name), frame); note("Keyframe removido") }
        }
        Text("Mexer nos valores cria ou atualiza o keyframe deste osso no quadro atual.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

// ------------------------------------------------------------------ aba Pose

@Composable
private fun PoseTab(ed: Editor, frame: Int, note: (String) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val all = remember(ed) { ed.model.bones.map { it.name }.distinct() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Keyframe de todos") { note("Keyframe em ${ed.keyBones(all, frame)} ossos (quadro $frame)") }
            Btn("Copiar pose") { note("Pose copiada (${ed.copyPose(frame)} ossos)") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Colar pose", enabled = ed.hasClip) { note("Pose colada em ${ed.pastePose(frame)} ossos") }
            Btn("Espelhar pose") { note("Pose espelhada (${ed.mirrorPose(frame)} ossos)") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Zerar pose") { note(if (ed.zeroPose(frame) == 0) "Nenhum osso animado ainda" else "Pose zerada no quadro $frame") }
            Btn("Resetar pose") { note("${ed.resetPose(frame)} keyframes removidos do quadro $frame") }
        }
        Text(
            "Zerar: grava rotação/posição neutras. Resetar: remove os keyframes deste quadro. " +
                "Espelhar: troca esquerda/direita e inverte o eixo X.",
            color = Muted, fontSize = 10.sp
        )
    }
}

// ------------------------------------------------------------------ aba Morphs

@Composable
private fun MorphTab(ed: Editor, frame: Int, sel: Int, onSel: (Int) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val stamp = ed.stamp
    val morphs = ed.model.morphs
    var q by remember { mutableStateOf("") }
    // só os tipos que o Animator aplica hoje: grupo, vértice e osso
    val list = remember(ed, q) {
        val s = q.trim().lowercase()
        morphs.indices.filter { i ->
            val m = morphs[i]
            m.type in 0..2 && (s.isEmpty() || m.name.lowercase().contains(s) || m.nameEn.lowercase().contains(s))
        }
    }
    Column(Modifier.fillMaxSize()) {
        SearchBox(q, "Buscar morph") { q = it }
        if (sel in morphs.indices) {
            val name = morphs[sel].name
            var w by remember(name, frame, stamp) { mutableFloatStateOf(ed.sampleMorph(name, frame.toFloat())) }
            Text(name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
            SliderRow("", w, 0f..1f, "", 2, { w = it; ed.liveMorph(name, frame, it) }, { ed.finish() })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("Zerar") { w = 0f; ed.zeroMorph(name, frame) }
                Btn("Remover key", enabled = ed.hasMorphTrack(name)) { ed.deleteMorphKey(name, frame) }
            }
            Spacer(Modifier.height(4.dp))
        } else Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(list, key = { it }) { i ->
                val m = morphs[i]
                Row(
                    Modifier.fillMaxWidth().background(if (i == sel) Accent.copy(alpha = .35f) else Color.Transparent)
                        .clickable { onSel(i) }.padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(m.name.ifBlank { "morph $i" }, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (m.nameEn.isNotBlank() && m.nameEn != m.name)
                        Text("  ${m.nameEn}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (ed.hasMorphTrack(m.name)) Text("  ◆", color = Accent, fontSize = 11.sp)
                }
            }
        }
    }
}
