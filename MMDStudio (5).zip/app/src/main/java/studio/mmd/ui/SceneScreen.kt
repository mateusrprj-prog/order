package studio.mmd.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import android.media.MediaPlayer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.edit.Editor
import studio.mmd.importer.ModelImporter
import studio.mmd.mmd.VmdParser
import studio.mmd.render.SceneGLView
import studio.mmd.render.TouchMode
import studio.mmd.render.ViewPreset

val Bg = Color(0xFF0A0A0B); val Panel = Color(0xFF17181B); val Accent = Color(0xFF2F7BFF)
val Muted = Color(0xFF8A8D94)
const val FPS = 30; const val DEFAULT_FRAMES = 300

@Composable
fun SceneScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val gl = remember { SceneGLView(ctx) }
    var mode by remember { mutableStateOf(TouchMode.ORBIT) }
    var menu by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(DEFAULT_FRAMES) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var editor by remember { mutableStateOf<Editor?>(null) }
    var skeleton by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var selBone by remember { mutableIntStateOf(-1) }
    var selMorph by remember { mutableIntStateOf(-1) }
    val ed = editor
    val ver = ed?.version ?: 0
    var audio by remember { mutableStateOf<MediaPlayer?>(null) }
    fun note(t: String) { toast = t }
    val scope = rememberCoroutineScope()

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val bytes = e.toVmd(); val n = e.keyCount()
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(bytes) }
                    }
                    isError = false; status = "VMD salvo\n$n keyframes · ${bytes.size / 1024} KB"
                } catch (ex: Throwable) { isError = true; status = "Erro ao salvar: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in setOf("mp3", "wav", "ogg", "m4a", "aac", "flac")) {
                    val mp = withContext(Dispatchers.IO) { MediaPlayer().apply { setDataSource(ctx, uri); prepare() } }
                    audio?.release(); audio = mp
                    status = "$name\náudio: %.1fs (toca junto com o play)".format(mp.duration / 1000f)
                } else if (ext == "vmd") {
                    val e = editor ?: throw IllegalStateException("Importe um modelo (.pmx/.zip) antes do movimento")
                    val m = e.model
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(ModelImporter.readBytes(ctx, uri)) }
                    val boneNames = m.bones.map { it.name }.toHashSet(); val morphNames = m.morphs.map { it.name }.toHashSet()
                    val bm = mo.bones.keys.count { it in boneNames }; val mm = mo.morphs.keys.count { it in morphNames }
                    playing = false; frame = 0; total = mo.maxFrame + 1
                    e.load(mo); gl.setFrame(0)
                    status = "$name\n${total} frames (%.1fs a $FPS fps)\nossos casados: $bm/${mo.bones.size}\nmorphs casados: $mm/${mo.morphs.size}".format(total / FPS.toFloat()) +
                        if (bm == 0) "\nATENÇÃO: nenhum osso casou; o modelo não vai se mover" else ""
                    if (bm == 0) isError = true
                } else {
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, uri) }
                    val m = r.model
                    editor = Editor(m); selBone = -1; selMorph = -1; playing = false; frame = 0; total = DEFAULT_FRAMES
                    gl.loadModel(m, r.textures)
                    status = "${m.name.ifBlank { r.sourceName }}\n${m.vertexCount} vértices · ${m.indices.size / 3} triângulos\n" +
                        "${m.materials.size} materiais · ${m.bones.size} ossos · ${m.morphs.size} morphs\n" +
                        "texturas: ${r.textures.count { it != null }}/${m.textures.size}"
                }
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    LaunchedEffect(playing, total, audio) {
        val a = audio
        if (playing && a != null) { try { a.seekTo((frame * 1000L / FPS).toInt()); a.start() } catch (ignored: Throwable) {} }
        while (playing) {
            delay(1000L / FPS)
            val nf = if (a != null && a.isPlaying) (a.currentPosition.toLong() * FPS / 1000).toInt() else frame + 1
            frame = if (nf >= total) 0 else nf
            if (frame == 0 && a != null) { try { a.seekTo(0); if (!a.isPlaying) a.start() } catch (ignored: Throwable) {} }
        }
        if (a != null) { try { if (a.isPlaying) a.pause() } catch (ignored: Throwable) {} }
    }
    DisposableEffect(Unit) { onDispose { audio?.release(); audio = null } }
    LaunchedEffect(frame) { gl.setFrame(frame) }
    // toda edição gera um VmdMotion novo para a thread GL
    LaunchedEffect(ed, ver) { ed?.let { gl.setMotion(it.motion()) } }
    LaunchedEffect(skeleton, selBone) { gl.setOverlay(skeleton, selBone); gl.dragBone = if (skeleton) selBone else -1 }
    LaunchedEffect(skeleton) { if (!skeleton && (mode == TouchMode.ROTATE || mode == TouchMode.MOVE)) { mode = TouchMode.ORBIT; gl.touchMode = mode } }
    LaunchedEffect(toast) { if (toast != null) { delay(2200); toast = null } }
    // painel de status some sozinho (erros ficam até tocar neles)
    LaunchedEffect(status, isError) { if (status != null && !isError) { delay(6000); status = null } }
    SideEffect {
        gl.onTap = { x, y ->
            if (skeleton && editor != null) gl.pickBone(x, y) { idx -> selBone = idx; if (idx >= 0) tab = 1 }
        }
        gl.onBoneDrag = { rotate, v ->
            val e = editor; val b = e?.model?.bones?.getOrNull(selBone)
            if (e != null && b != null) {
                if (rotate) { if (b.flags and 0x0002 != 0) e.nudgeBone(b.name, frame, v, null) else note("Este osso não pode girar") }
                else { if (b.flags and 0x0004 != 0) e.nudgeBone(b.name, frame, null, v) else note("Este osso não pode mover") }
            }
        }
        gl.onBoneDragEnd = { editor?.finishDrag() }
    }
    val selName = ed?.model?.bones?.getOrNull(selBone)?.name
    val hasKey = ed != null && selName != null && ed.hasKey(selName, frame)
    val keys = remember(ed, ver, selName, skeleton) {
        if (ed == null) IntArray(0) else if (skeleton && selName != null) ed.keyFramesOf(selName) else ed.allKeyFrames()
    }
    DisposableEffect(Unit) { gl.onResume(); onDispose { gl.onPause() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowBackIosNew, null, Modifier.clickable { onClose() }.padding(8.dp).size(18.dp), tint = Color.White)
                Icon(Icons.Default.ViewInAr, null, Modifier.padding(start = 4.dp).size(18.dp), tint = Color.White)
                Text("Scene 3D", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Icon(Icons.Default.Save, null, Modifier.clickable {
                    val e = editor
                    if (e == null) note("Importe um modelo antes") else if (e.keyCount() == 0) note("Nenhum keyframe para salvar")
                    else saver.launch("animacao.vmd")
                }.padding(8.dp).size(22.dp), tint = Color.White)
                Icon(Icons.Default.FolderOpen, null, Modifier.clickable { picker.launch(arrayOf("*/*")) }.padding(8.dp).size(22.dp), tint = Color.White)
                Icon(Icons.Default.Close, null, Modifier.clickable { onClose() }.padding(8.dp).size(20.dp), tint = Color.White)
            }
            Box(Modifier.padding(horizontal = 8.dp)) {
                Row(Modifier.clickable { menu = true }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Viewport de Edição", color = Color.White, fontSize = 12.sp)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Enquadrar tudo") }, onClick = { gl.frameAll(); menu = false })
                    listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esquerda" to ViewPreset.LEFT,
                        "Direita" to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { gl.applyPreset(p); menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(4.dp))) {
                AndroidView(factory = { gl }, modifier = Modifier.fillMaxSize())
                status?.let { Text(it, color = if (isError) Color(0xFFFF6B6B) else Color.White, fontSize = 9.sp, lineHeight = 12.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).widthIn(max = 200.dp).clip(RoundedCornerShape(6.dp))
                        .clickable { status = null }.background(Panel.copy(alpha = .75f)).padding(horizontal = 6.dp, vertical = 4.dp)) }
                toast?.let { Text(it, color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp).background(Panel.copy(alpha = .9f), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) }
                Column(Modifier.align(Alignment.CenterStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha = .85f))) {
                    ToolButton(Icons.Default.OpenWith, mode == TouchMode.ORBIT) { mode = TouchMode.ORBIT; gl.touchMode = mode }
                    ToolButton(Icons.Default.PanTool, mode == TouchMode.PAN) { mode = TouchMode.PAN; gl.touchMode = mode }
                    if (skeleton && ed != null) {
                        ToolButton(Icons.Default.Sync, mode == TouchMode.ROTATE) { mode = TouchMode.ROTATE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para girar") }
                        ToolButton(Icons.Default.ControlCamera, mode == TouchMode.MOVE) { mode = TouchMode.MOVE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para mover") }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ModeChip("Animação", !skeleton) { skeleton = false }
                ModeChip("Esqueleto", skeleton) { if (ed == null) note("Importe um modelo antes") else skeleton = true }
                Spacer(Modifier.weight(1f))
                Text("%d / %d".format(frame, total - 1), color = Muted, fontSize = 11.sp)
            }
            if (skeleton && ed != null) {
                SkeletonPanel(ed, frame, tab, { tab = it }, selBone, { selBone = it }, selMorph, { selMorph = it }, { note(it) }, { frame = it },
                    Modifier.fillMaxWidth().height(if (tab >= 3) 270.dp else 230.dp).padding(horizontal = 8.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.clickable { playing = !playing }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame - 1).coerceAtLeast(0) }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipNext, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame + 1).coerceAtMost(total - 1) }.padding(8.dp).size(22.dp))
                Spacer(Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.Undo, null, tint = if (ed?.canUndo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ed?.undo() != true) note("Nada para desfazer") }.padding(8.dp).size(22.dp))
                Icon(Icons.AutoMirrored.Filled.Redo, null, tint = if (ed?.canRedo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ed?.redo() != true) note("Nada para refazer") }.padding(8.dp).size(22.dp))
                KeyButton(hasKey, selName != null) {
                    if (ed == null) note("Importe um modelo antes")
                    else if (selName == null) note("Selecione um osso (modo Esqueleto)")
                    else if (hasKey) { ed.deleteKeys(listOf(selName), frame); note("Keyframe removido") }
                    else { ed.keyBones(listOf(selName), frame); note("Keyframe inserido") }
                }
                Text("+1s", color = Muted, fontSize = 12.sp, modifier = Modifier.clickable { total += FPS }.padding(8.dp))
            }
            Timeline(frame, total, keys, Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp, vertical = 4.dp)) { frame = it }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(3.dp).size(34.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Accent else Color.Transparent).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean, onClick: () -> Unit) {
    Text(text, color = if (active) Color.White else Muted, fontSize = 12.sp,
        modifier = Modifier.padding(end = 8.dp).clip(RoundedCornerShape(14.dp))
            .background(if (active) Accent else Panel).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 5.dp))
}

/** Losango de keyframe: cheio = o osso selecionado já tem key neste quadro. */
@Composable
private fun KeyButton(active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Canvas(Modifier.clickable { onClick() }.padding(8.dp).size(22.dp)) {
        val c = center; val r = size.minDimension / 2f * 0.85f
        val p = Path().apply { moveTo(c.x, c.y - r); lineTo(c.x + r, c.y); lineTo(c.x, c.y + r); lineTo(c.x - r, c.y); close() }
        val col = if (enabled) Accent else Muted
        if (active) drawPath(p, col) else drawPath(p, col, style = Stroke(width = 3f))
    }
}

/** Régua de frames com playhead arrastável (um traço por segundo) e losangos nos keyframes. */
@Composable
private fun Timeline(frame: Int, total: Int, keys: IntArray, modifier: Modifier, onSeek: (Int) -> Unit) {
    val last = (total - 1).coerceAtLeast(1)
    Canvas(modifier.background(Color(0xFF101114)).pointerInput(total) {
        detectTapGestures { onSeek((it.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }.pointerInput(total) {
        detectDragGestures { c, _ -> onSeek((c.position.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }) {
        val secs = (last / FPS).coerceAtLeast(1)
        val step = size.width * FPS / last
        for (s in 0..secs) drawLine(Color(0xFF3A3C42), Offset(s * step, 0f), Offset(s * step, 28f), 2f)
        val cy = size.height * 0.6f; val r = 7f
        val diamonds = keys.size <= 800
        for (k in keys) {
            if (k > last) continue
            val kx = k.toFloat() / last * size.width
            if (diamonds) {
                val p = Path().apply { moveTo(kx, cy - r); lineTo(kx + r, cy); lineTo(kx, cy + r); lineTo(kx - r, cy); close() }
                drawPath(p, Color(0xFFFFC857))
            } else drawLine(Color(0xFFFFC857), Offset(kx, cy - r), Offset(kx, cy + r), 2f)
        }
        val x = frame.toFloat() / last * size.width
        drawLine(Accent, Offset(x, 0f), Offset(x, size.height), 3f)
    }
}
