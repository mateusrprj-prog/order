# Contexto do projeto — MMD Studio v2.2.0 (23/11/2026)

Marco atual: **Animated Cloth + IK Assist + Shader Graph + VFX Expansion**. No bake XPBD, o `Animator` avalia as poses anterior/atual sem GL; a roupa parte do referencial anterior, recebe colisão da superfície corporal deformada por skinning/morphs e de rigid bodies PMX ligados a osso (modo 0), depois retorna ao cache local pré-skinning. Rig Studio inclui IK Assist com cadeia PMX inicial, solver geométrico de dois segmentos, pole vector, limites de dobra e gravação de alvo no controlador para o CCD nativo. Material Studio inclui avaliador de Shader Graph DAG (Color/Value/Multiply/Mix/Principled/Output) e bake dos canais que PMX suporta. VFX Studio oferece 13 estilos procedurais, incluindo EXPLOSION (dispersão radial) e VORTEX (hélice), reproduzíveis por quadro/seed.

Validação 2.2.0: compilação Kotlin/JVM do núcleo de material/IK/tecido/UV/malha/VFX aprovada; smoke harness dedicado 12/12; runner local compatível executou 19/19 métodos (10 UV/Mesh + 9 novos); Kotlin PSI 12/12 arquivos verificados sem erros sintáticos. Os testes da release 2.1.0 (UV/mesh 10/10 e round-trip PMX) continuam registrados no relatório anterior, mas não foram repetidos neste ciclo. Os testes JUnit foram compilados/executados via runner local compatível; o runtime oficial Gradle/JUnit não foi executado. Android/Compose/Gradle/APK/GPU/aparelho não validados.

Limites 2.2.0: Cloth Studio permanece bake CPU/offline; modos de rigid body PMX 1/2 não são re-simulados pelo bake animado; modo dinâmico exige superfície corporal ativa; cache salvo em espaço local pré-skinning. IK Assist é preview geométrico para dois segmentos e keyframing do controlador, enquanto o Animator usa CCD do PMX. Shader Graph faz bake das propriedades compatíveis com PMX, não executa shaders arbitrários/nós GPU; metallic é aproximado pelo especular. Explosão/vórtice VFX são linhas/sprites estilizados, não simulação volumétrica ou colisões físicas. Ver `docs/REL_2_2_0.md` e `docs/REL_2_2_0_TEST_RESULTS.txt`.

---

# Contexto histórico da release MMD Studio v2.1.0 (anterior)

Marco atual (23/11/2026): **UV Studio + Mesh Editing**. A bancada UV implementa seams por ângulo diedro/material, componentes/chart, solver LSCM sparse via gradiente conjugado, fallback planar, atlas por ilha, split de vértices compartilhados e remapeamento de pesos/SDEF/UVs adicionais/edge scale/morphs de vértice. Mesh Editing permite apagar, extrudar e aplicar inset em faces selecionadas, inverter winding com recálculo de normais e remover triângulos degenerados, preservando ranges de material e vértices para morphs.

Validação 2.1.0: core Kotlin/JVM compilado; regressão v2.0.0 6/6; testes de UV/mesh 10/10 no harness local; round-trip PmxWriter/PmxParser aprovado para unwrap com duas ilhas e extrusão/inset; PSI sintático dos quatro arquivos alterados 4/4. Android/Compose/APK/GPU/aparelho e runtime Gradle/JUnit oficial não validados. Morphs UV PMX tipos 3–7 são preservados como raw e recebem aviso, mas seus índices internos ainda não são expandidos ao dividir vértices. Ver `docs/REL_2_1_0.md`.

# Contexto do projeto — MMD Studio v2.0.0

Marco 2.0.0 (23/11/2026): Weight Paint por toque na viewport com stroke em uma operação Undo; pincel espacial de escultura Inflate/Smooth/Pinch/Move com XYZ configurável; Post Studio salvo por projeto e aplicado aos exports PNG/MP4/sequência; cache de sequência PNG retomável com CRC por quadro e assinatura incluindo geometria, animação, cena, câmera e aparência; novos VFX FIRE/SMOKE.

Validação: núcleo Kotlin/JVM compilado; smoke v2.0.0 6/6; regressão avançada v1.42 12/12; PSI sintático 4/4 nos arquivos alterados. 10 métodos de teste adicionados, não executados via Gradle. Android SDK/Gradle, APK, Compose runtime e GPU real não validados. Limitações da versão atual documentadas em `docs/REL_2_1_0.md`.

---

# MMD Studio — contexto atual v1.42.0 (23/11/2026)

## Resumo desta atualização
- XPBD: região de tecido por influência de osso além de intervalo/material; colisores PMX esféricos, cápsulas e caixas orientadas; colisão com triângulos estáticos da superfície do corpo via broadphase espacial; espessura configurável; bake até 240 quadros; cache com assinatura de geometria/topologia e FPS. A superfície corporal é estática no pose de repouso durante o bake.
- Model Studio: diagnóstico topológico (bordas, non-manifold, orientação, componentes, vértices isolados/duplicados e área UV zero); relaxamento Laplaciano de UV com fronteira fixa; atlas projetado por material, sem divisão de vértices/costuras.
- Weight Paint: pincel de coordenadas locais, pintura em seleção, normalização, poda, suavização, espelhamento e novo fluxo UI para importar um PMX de origem e transferir pesos ao modelo atual usando KD-tree, vizinhos próximos e mapeamento de ossos por nome. Transferência entra numa única operação Undo/Redo; exige escala/orientação espacial compatíveis.
- VFX: nove estilos procedurais (faíscas, chuva, neve, aura, confete, bolhas, órbita, raio e magia), trilhas aditivas e sprites suaves GL_POINTS; determinísticos por frame/seed e desenhados antes da captura.
- Versão Gradle: `versionCode 85`, `versionName 1.42.0`.

## Validação desta sessão
- 12/12 grupos de smoke tests da base anterior aprovados.
- 6/6 grupos de smoke tests novos aprovados (VFX, diagnóstico topológico, UV relax, atlas por material, transferência de pesos, colisão em caixa/superfície).
- Teste adicional de transferência via WeightPaintSession e Undo incluído no harness, reexecutado junto com os seis grupos.
- Android Compose/Gradle/APK e execução GL em aparelho continuam sem validação neste ambiente; ver `docs/REL_1_42_0_TEST_RESULTS.txt`.

## Limites importantes
- A colisão por superfície usa triângulos estáticos do corpo no pose de repouso; não acompanha a deformação animada do corpo durante o bake. Caixas orientadas usam Euler PMX no espaço local. Colisões com superfícies dinâmicas e autocolisão de alta densidade permanecem futuras etapas.
- Auto-colisão é limitada a 2.048 vértices, bake até 20.000 vértices e 240 quadros.
- Atlas UV é projeção automática por material e preserva vértices compartilhados; não é LSCM/ABF nem cria seams ou duplica vértices.
- O pincel de pesos atua por coordenadas locais e seleção de vértices; não está ligado a um raycast de toque diretamente na viewport.
- Transferência de pesos requer geometria na mesma escala, orientação e espaço local; ossos sem nome correspondente caem no fallback de raiz.
- VFX usa linhas e sprites suaves, não fumaça/fogo volumétricos, colisões, compositor ou shading físico.
- Os relatórios de smoke test não substituem teste de compatibilidade com PMX reais de diferentes autores.

# MMD Studio — Contexto técnico da entrega v1.41.0

## Identificação
- Projeto: MMD Studio para Android, Kotlin + Jetpack Compose + OpenGL ES.
- Versão Gradle: **1.41.0** (`versionCode 84`).
- Base de trabalho: fontes atualizados em camadas sobre a v1.37.0, preservando Scene/Transform, elenco, editor de partes, física PMX, timeline e lipsync.
- Objetivo da revisão: avançar a bancada Model Studio, habilitar seleção e escultura local, operações UV e pesos por seleção, ampliar Material Studio e disponibilizar VFX procedural persistente sincronizado à timeline.

## Entrega v1.41.0 — Cloth Studio XPBD integrado
Ver `docs/REL_1_41_0.md`. O painel Tecido faz bake CPU por quadro com seleção por material PMX ou intervalo de vértices; prende os vértices fora da região, utiliza colisores PMX de esfera/cápsula, armazena cache XPBD versionado com CRC e assinatura geométrica/FPS, aplica offsets interpolados antes do skinning GPU e recalcula normais em VBO dinâmico. Cache é recuperado ao reabrir, mas invalidado quando a geometria ou FPS não conferem. 12/12 smoke-check groups Kotlin/JVM passaram, incluindo cache legado v1. Build Android/Compose/APK/dispositivo e renderer GL real não validados.

## Entrega v1.40.0 — Model Studio + VFX
Ver `docs/REL_1_40_0.md`. A bancada inclui seleção por material/osso/caixa/intervalo, expansão/contração por adjacência, fronteiras, transformação localizada, suavização Laplaciana, inflação, UV cilíndrico/esférico, normalização UV selecionada, pintura/normalização/poda/suavização/espelhamento de pesos sobre vértices selecionados, reatribuição de slots de textura e propriedades PMX, diagnóstico e salvamento PMX com texturas. VFX procedural tem cinco estilos, parâmetros e cor, reproduz-se deterministicamente pelo frame/FPS do projeto e é desenhado antes da captura PNG/vídeo; `vfx.json` salva com backup e recuperação.

Validação: Kotlin/JVM puro e 8/8 smoke checks, incluindo round-trip `PmxWriter`/`PmxParser` depois de editar geometria e material. UI Compose/build Android/APK/aparelho NÃO validados nesta sessão. Limites: seleção/pintura são pelo painel (não por toque/pincel na superfície da viewport); UV cilíndrico/esférico não divide vértices nem faz costura/ilhas/unwarp; VFX é desenhado como segmentos simples GL_LINES, sem colisões, fumaça volumétrica ou compositor; XPBD permanece motor/cache independente, ainda sem deformação dinâmica integrada ao buffer da viewport/timeline.

## Entrega v1.39.0 — Bancada de modelo
Ver `docs/REL_1_39_0.md` e `CHANGELOG.md`. Novo modo Modelo integrado à cena: transforma malha/rig/morphs/corpos/juntas, recalcula normais, gera e ajusta UVs, edita materiais e diagnostica o PMX; salvamento reescreve PMX com texturas e atualiza a viewport preservando o frame e trilhas válidas. Core Kotlin + PMX reader/writer compilados isoladamente; 8/8 smoke checks em JVM. UI Compose/Android/APK/aparelho não validados nesta sessão.

## Entrega v1.35.0 — ajuste de tamanho dos colisores
Slider por colisor (`PhysConfig.colliderScale`, 0,5–1,6), aplicado no `PhysEngine`; 28 testes JVM executados; APK/aparelho não validados.

## Entrega v1.34.0 — colisores corporais (P2 2.2)
Ver CHANGELOG. `rig/BodyColliders.kt` gera cápsulas de quadril/coxas/panturrilhas a partir do esqueleto (raio medido nos vértices), integradas ao `PhysEngine` como corpos cinemáticos extras; chave `PhysConfig.bodyColliders` (padrão desligada). 26 testes JVM executados (17 partes + 9 colisores); APK e aparelho NÃO validados.

## Entrega v1.33.0 — grupos de nome livre (ESCRITA, NÃO COMPILADA)
Na aba Partes agora há campo de nome de grupo: nomear a parte inteira, tirar do grupo ou mover só um elemento. Cada grupo é uma parte própria com chave de Física e grupo `part:<categoria>|<nome>` no movimento secundário. `sanitizeGroup` remove "|" e ":" e limita a 24 caracteres. Teste novo (17 no total), não executado. Pendente: destaque de materiais no viewport, colisores corporais, tecido.

## Entrega v1.32.0 — Editor de Partes do Modelo (P1 1.1/1.2) — ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO

### Por que esta fatia
O roadmap manda consolidar o fluxo Outliner → personagem → painel → edição real → salvar/reabrir (P0: implementado no código em 1.31.0, ainda sem build validado) e, em seguida, o **Editor de Partes**, porque a física de tecido/colisão corpo–saia (P2) não deve ser construída sobre grupos errados. Esta versão entrega o reconhecimento com confiança + correção manual persistente + ligação real com o movimento secundário.

### Implementado no código-fonte
1. `rig/PartRecognizer.kt` (lógica pura, sem Android)
   - `PartRecognizer.analyze(model)`: reconhecimento automático (caro; roda fora da UI). Sinais: nome do osso, nome do corpo rígido, corpo rígido dinâmico (só corrobora o que o nome já sugeriu), herança pela hierarquia, nome do material (teto 0,40: nunca "alta" sozinho) e pesos dos vértices por material (≥50% dos pesos em ossos de uma categoria). Confiança = 1 − Π(1 − força) das fontes que concordam, com penalidade quando outra categoria de OUTRA família concorre (ex.: "髪飾り"). Franja/cabelo/rabo são da mesma família (não conflitam).
   - Palavras ASCII curtas só casam como palavra inteira (`chair` não vira cabelo; `ponytail` não vira "tail"/cauda). Ossos-padrão do corpo nunca viram parte nem repassam categoria aos filhos.
   - `PartRecognizer.build(analysis, overrides)`: aplica as correções (barato) e agrupa em partes `categoria|grupo`. Confiança da parte = a do elemento mais incerto.
   - `PartOverrides` (assign por elemento, confirmed, physics por parte) + `PartOverridesIo` (JSON versionado, nunca lança). Chaves: `bone:<nome>`, `mat:<índice>:<nome>`, `rigid:<índice>:<nome>`; chave que não bate com o modelo atual é ignorada e contada como órfã.
   - `splitPart` (esq./dir. pelo eixo X, frente/trás pelo eixo Z; +X = esquerda do personagem, frente = −Z) e `applyToSecondary` (grupos `part:<id>`).
2. `rig/Constraints.kt`: `RigConfig.parts` (por personagem). `rig/CharacterRigProfile.kt`: campo opcional `parts` (formatVersion continua 1).
3. `project/Project.kt`: `loadParts/saveParts` (`parts.json`, escrita atômica; apaga o arquivo quando vazio).
4. `ui/PartsPanel.kt` (novo) + `ui/EditPanels.kt` (4ª sub-aba "Partes" em Rig) + `ui/SceneScreen.kt` (estado `partsMain`, carga/salvamento com debounce, snapshot do perfil dos extras com `parts`, painel Rig 310 dp).
5. Teste: `PartRecognizerTest` (16 casos).

### Como usar (após compilar)
Esqueleto → Rig → **Partes**. Escolha o personagem no Outliner antes (a aba edita o personagem ativo). Toque numa parte para ver ossos/materiais/corpos rígidos; toque num elemento para ver os indícios e movê-lo para outra categoria ou removê-lo. "Aplicar física às partes" cria os grupos em Secundário (aba vizinha), onde os sliders continuam valendo.

### Limites conhecidos (não afirmar o contrário)
- Destaque visual no viewport existe só para ossos ("Selecionar osso"); materiais ainda não são destacados.
- Não há colisão por parte, colisores corporais, tecido nem Soft Body: nada disso foi implementado.
- Uma parte só com materiais (sem ossos) não gera movimento secundário.
- Heurísticas de nomes cobrem os padrões JP/EN comuns; modelos com nomes genéricos dependem da correção manual e dos pesos.
- Testes JVM, build Android e teste no POCO X7 Pro NÃO executados.

### Próxima prioridade recomendada
1) Rodar o workflow de build e testar a aba Partes com 2–3 modelos PMX reais (nomes JP, nomes genéricos, sem corpos rígidos). 2) Destacar a parte selecionada no viewport (materiais). 3) Só então colisores corporais (P2 2.2).


---

# Histórico anterior (v1.31.0 e antes)

## Problema reproduzido no vídeo
O usuário importou um palco de música em Cena. O palco aparece na lista `Cenário e acessórios`, mas o seletor `Transformar → Alvo` mostrava apenas `Personagem principal` e personagens extras. Assim o palco não podia ser escolhido no painel de transformação. O vídeo também mostra que a aba Cena oferecia sliders X/Y/Z de posição e escala, sem oferecer o mesmo controle completo XYZ de rotação do painel Transformar.

## O que mudou em v1.30.2
1. `ui/SceneScreen.kt`
   - O seletor Transformar agora monta os alvos a partir de personagem principal (`model`), extras (`char:<id>`) e todos os itens importados de Cena (`prop:<id>`).
   - Ao clicar num item na lista Cena, o `layerSel` passa a apontar para esse `prop:<id>`. Selecionar no dropdown também atualiza o item selecionado na lista Cena.
   - `updateRootTransform()` agora sincroniza objetos `prop:` com o estado de transformação persistente e com `SceneGLView.setProp()`.
   - `applyRootTransformsAt()` aplica no quadro atual as transformações amostradas de cada objeto Cena, incluindo posição, rotação, escala e o vínculo opcional a osso. `setPropTransforms()` envia o conjunto em lote à thread GL. Isso alcança prévia e rotinas de captura/exportação que já usam o método.
   - Projetos existentes inicializam tracks ausentes com os valores antigos de `props.json`; as tracks são preservadas por ID.
   - Duplicar um prop duplica também sua track para um ID independente; remover um prop remove a track antiga.
   - `props.json` é sincronizado e salvo com debounce e no salvamento/fechamento do projeto.
2. `render/SceneGLView.kt`
   - Corrigido o caminho de renderização de props soltos: agora aplica `T * Ry * Rx * Rz * S`. Antes, a rotação só era aplicada no caminho de objetos anexados a ossos.
   - Objetos anexados continuam recebendo rotação local do osso e offset, sem mudar o sistema da câmera.
3. `ui/TransformPanel.kt`
   - Título e texto mudam conforme o alvo: personagem principal, personagem ou objeto da cena.
   - A UI deixa explícito que rotação XYZ, posição e escala pertencem ao item selecionado.
4. `ui/ScenePanel.kt` e `scene/RootTransform.kt`
   - Documentação interna atualizada para refletir o vínculo com o painel Transformar e o suporte de IDs `prop:<id>`.
5. `app/src/test/java/studio/mmd/RootTransformTest.kt`
   - Novo teste cobre transformação independente, keyframes, interpolação e codec para `prop:music-stage`.

## Como usar após instalar a versão compilada
1. Importe o palco em **Cena → + Adicionar**.
2. Toque no nome dele na lista **Cenário e acessórios** ou abra **Transformar**.
3. Em **Alvo**, escolha `Cena · <nome do objeto>`.
4. Ajuste rotação X/Y/Z nos campos numéricos (ou X/Y no controle circular), posição e escala.
5. Use Criar keyframe no quadro desejado para animar aquele objeto independentemente.

## Escopo e limites
- Inclui qualquer elemento importado que seja adicionado à lista Cena e renderizado pelo fluxo de `PropMeta`/`SceneGLView` (ex.: PMX, PMD, X, ZIP, GLB, glTF e OBJ, conforme o importador aceitar o arquivo).
- Cada item é transformado individualmente. Esta entrega **não** cria um controle global para girar todos os objetos/personagens da cena em conjunto.
- Luz e câmera continuam sendo alvos dos painéis próprios; não são `PropMeta` da lista Cena.
- O SceneGraph genérico legado ainda não substitui os dados reais de `PropMeta` nesta integração.
- Transformações de props são aplicadas na prévia/captura/exportação que já chama `applyRootTransformsAt()`. A conversão/bake destas tracks para arquivos VMD/GLB/FBX não faz parte desta entrega.

## Estado de validação
- Código-fonte alterado: SIM.
- ZIP criado e integridade testada: SIM (ver arquivo de entrega).
- Teste novo escrito: SIM.
- Testes JVM executados: NÃO.
- Build Android executado: NÃO.
- Teste no dispositivo: NÃO.

Motivo: este ambiente não contém Gradle, Gradle Wrapper ou Android SDK. O passo obrigatório seguinte é executar o workflow **Build Android APK** no GitHub Actions, corrigir eventuais erros de compilação e testar no POCO X7 Pro os critérios de aceitação descritos na nota v1.30.2 dos roadmaps.

## Histórico imediato
- **v1.30.1:** transformação da personagem inteira: rotação XYZ, posição, escala, painel circular, keyframes e persistência em `root_transforms.json`. Não compilada/testada neste ambiente.
- **v1.30.0:** navegação de viewport (orbit/pan/zoom/foco/gizmo); não compilada/testada neste ambiente.

## Nova prioridade P0 — física real de roupas/colisão corpo–tecido (20/11/2026)
Vídeo de referência: `1000243628.mp4`. Durante movimentos de dança com elevação/cruzamento das pernas, a saia não reage o suficiente e a perna atravessa visualmente a roupa.

Auditoria estática do código v1.30.2:
- `rig/Physics.kt`: `PhysEngine` simula rigid bodies/juntas PMX e colisões aproximadas entre rigid bodies; não há colisão entre vértices da roupa e superfície corporal.
- `rig/Constraints.kt`: `Secondary` é mola/amortecimento sobre rotações globais de ossos, não é simulação de tecido.
- `rig/AutoPhysics.kt`: reconhece grupos como saia/roupa/cabelo e cria grupos `Secondary`; não cria colisores nem tecido físico.
- `mmd/PmxModel.kt`: `softBodyCount`/`softBodyRaw` são dados PMX 2.1 preservados como bytes; o simulador não os interpreta.
- `rig/PhysCache.kt`: bake guarda pose de ossos, não estado por vértice de roupa.

Conclusão: não tentar resolver a saia apenas aumentando gravidade, rigidez ou atraso. O próximo sistema deve separar: (1) física MMD rígida existente; (2) colisores cinemáticos do corpo, inicialmente pelve/coxas/joelhos/panturrilhas; (3) solver de roupa PBD/XPBD com vértices, restrições, âncoras e colisão tecido–corpo. A roupa se afasta do corpo; o solver não altera o esqueleto nem os keyframes da perna. Incluir subpassos/anti-tunneling, cache determinístico, persistência e integração no render/export.

Ordem: P0-A debug e colisores; P0-B saia/roupa com colisão; P0-C bake/persistência/export; P1 interpretar PMX 2.1 Soft Body e melhorar detecção; P2 auto-colisão e qualidade avançada. Critérios completos em `docs/P0_Fisica_Roupas_Colisoes.md` e seção 13.11 do roadmap.

**Estado:** planejamento/especificação apenas; nenhuma física de tecido foi implementada e a versão continua 1.30.2. Não afirmar que as roupas já colidem com o corpo. Próximo build deve testar a saia com caminhada, chute frontal/lateral, pernas cruzadas e agachamento, comparando prévia, scrub, bake e exportação no POCO X7 Pro.


## Entrega v1.31.0 — Outliner + seleção e física por personagem

### Objetivo do usuário
A referência enviada em 20/11/2026 mostra o Outliner do Blender (Collection contendo Camera, Cube e Light). O problema relatado é não conseguir escolher separadamente qual modelo do Elenco está sendo editado nem manter configuração de física independente por personagem.

### Implementado no código-fonte
1. **Outliner no viewport**
   - `ui/SceneScreen.kt`: `layersOpen` inicia `true`; o painel permanece no canto superior direito do viewport e pode ser ocultado/reaberto pelo ícone Layers.
   - Lista: modelo principal, props importados em Cena, personagens extras do Elenco, luz, câmera e áudio.
   - A seleção de `model` ou `char:<id>` muda o personagem ativo e abre Esqueleto → Rig; grupo, visibilidade, bloqueio, renomeação e ordenação existentes foram preservados.
   - Props continuam selecionáveis e ligados a Cena/Transformar. Luz, câmera e áudio abrem seus painéis próprios; não recebem perfil de física de personagem.
   - É um Outliner mobile com lista e agrupamento do sistema atual, não a implementação integral do sistema de coleções/parenting do Blender.
2. **Perfil de rig e física por personagem extra**
   - Novo `rig/CharacterRigProfile.kt`: codec versionado para restrições, movimento secundário e `PhysConfig`.
   - `project/Project.kt`: salva em `cast/<id>.rig.json`, carrega com fallback seguro, exclui ao remover e copia ao duplicar personagem.
   - `SceneScreen.kt`: mantém mapa `castRigConfigs` por ID; abre o perfil correto ao selecionar um extra, passa valores para `SkeletonPanel`, salva ao editar, no salvar/fechar e ao exportar o projeto.
   - O principal segue usando `RigState.main` e os arquivos legados `rig.json`, `secondary.json` e `physics.json`, preservando compatibilidade.
3. **Renderer e ferramentas**
   - `render/SceneGLView.kt`: `addCharacter` recebe `RigConfig`; cada `CharacterInstance` mantém referência ao próprio perfil. `setCharacterRigConfig` atualiza somente o Animator daquele extra e reinicializa a dinâmica; a reconstrução de contexto GL reutiliza o perfil.
   - `mmd/Animator.kt`: `resetDynamics()` reinicia o estado temporal de movimento secundário/física sem compartilhar estado entre personagens.
   - `rig/Baker.kt`: `Baker.compute` aceita `RigConfig`; `PhysBake.run` já recebe o perfil em uso, agora chamado com o perfil ativo na UI.
   - `ui/EditPanels.kt`: cabeçalho exibe o dono do perfil e a subaba abre em “Física real”; os controles e bake recebem o `RigConfig` escolhido.
   - `ui/SceneScreen.kt`: selecionar em Outliner, tocar em personagem na viewport, ou usar “Editar este personagem” no painel Elenco escolhe o mesmo alvo de edição; selecionar “Editar personagem principal” volta ao perfil principal.
4. **Visibilidade de status**
   - O Outliner informa, por personagem, Física real ON/off e quantidade de grupos de movimento secundário.
   - O painel Rig mostra `CONFIGURAÇÃO DE RIG · <nome>`, para evitar editar o personagem errado sem perceber.
5. **Teste escrito**
   - `app/src/test/java/studio/mmd/CharacterRigProfileTest.kt`: três testes para round-trip, independência de instâncias e fallback para formato futuro.

### Como usar
1. Abrir a cena: o Outliner aparece por padrão no canto direito do viewport. O ícone de camadas no topo recolhe/mostra a lista.
2. Tocar no nome do personagem principal ou de um extra do Elenco. Esse personagem passa a ser o ativo e o painel de Esqueleto/Rig abre com o nome no cabeçalho.
3. Em Rig, selecionar Física real, ajustar os controles e/ou calcular o cache. Repetir para outro personagem: cada um mantém perfil independente.
4. Para trocar rapidamente, tocar em outro personagem no Outliner. Para voltar ao principal, tocar no item do modelo principal ou usar “Editar personagem principal” no painel Elenco.
5. Salvar/fechar ou exportar o projeto para manter os perfis; o cache de física continua transitório e precisa ser recalculado depois de reabrir.

### Escopo e limites
- Perfis independentes abrangem restrições, movimento secundário e controles de física rígida/juntas PMX. Isso não adiciona colisão de malha corpo–saia nem solver de tecido.
- `PhysCache` de cada personagem permanece apenas em memória, como o cache principal; o perfil de parâmetros é persistente.
- Perfis por personagem extra não mudam o comportamento do personagem principal nem o formato dos arquivos legados.
- Outliner usa entidades de cena atuais (`model`, `prop:<id>`, `char:<id>`, `light`, `camera`, `audio`). Não converte o SceneGraph legado em uma estrutura genérica de objetos totalmente editável.
- Não implementar “Física” em props/câmera/luz, pois o sistema de rig/física atual é relacionado a modelos de personagem PMX.

### Estado de validação
- Código-fonte alterado: SIM.
- Novo teste escrito: SIM (3 casos).
- Testes JVM executados: NÃO.
- Build Android executado: NÃO.
- Teste no dispositivo: NÃO.
- ZIP de entrega: `MMDStudio_v1_31_0_OUTLINER_FISICA_POR_PERSONAGEM.zip`.

Motivo da validação pendente: este ambiente não contém Gradle, Gradle Wrapper nem Android SDK. Executar **Build Android APK** no GitHub Actions e validar no POCO X7 Pro antes de considerar o recurso aprovado.

### Próximos passos P0
1. Confirmar Outliner e seleção do ativo em tela paisagem e retrato.
2. Importar pelo menos dois personagens extras; configurar gravidade, mola, amortecimento, vento, colisão e chão de forma diferente em cada um; alternar várias vezes e verificar que nada vaza entre perfis.
3. Salvar, fechar, reabrir e confirmar `cast/<id>.rig.json` para todos os extras.
4. Duplicar e excluir personagens; conferir cópia/exclusão do perfil sem alterar os demais.
5. Calcular cache para cada personagem e checar que o cache de outro modelo não é usado indevidamente.
6. Testar movimento secundário/bake em extras com e sem VMD e monitorar FPS/memória no aparelho.
7. Manter a P0 de colisão corpo–tecido como trabalho separado; a saia ainda pode atravessar pernas nesta versão.

## 19.7 v1.35.1 — correção em fatias (painel + saia)
Painel Rig com "⛶ Tela cheia" (lista de Partes utilizável) e colisão dos ossos de movimento secundário (saia) contra os colisores do corpo, ligada por "Colisores do corpo". 29 testes JVM executados; APK e aparelho NÃO validados. Pendente: testar no aparelho (UI Compose nunca compilada), tecido real, visualização dos colisores, torso/braços.

## 19.8 v1.36.0 — lipsync automático por áudio
`ai/LipSync.kt` (LPC → F1/F2 → vogal; energia → abertura) + diálogo em Áudio → "Lipsync automático", gravando keys nos morphs あ い う え お do personagem principal com um desfazer. 38 testes JVM executados (sintéticos); decodificação de áudio, UI e resultado visual NÃO validados no aparelho. Pendente: testar com voz real, personagens do elenco, consoantes (m/b/p), ajuste por vogal.


## 19.10 v1.38.0 — Câmera VMD, Weight Paint, mocap e motor de tecido XPBD
- `CameraMotionTools`: edição, inserção, remoção, linearização, suavização frame-aware, inversão e serialização de keys da câmera em VMD; painel Câmera com FOV, centro, distância e rotação XYZ.
- `edit/WeightPaint.kt`: pincéis esfera/cápsula, REPLACE/ADD/SUBTRACT, normalização, poda, suavização topológica, espelhamento X JP/EN, consultas de influência e histórico local Undo/Redo. UI Esqueleto → Pesos; aplicação ao PMX principal salva `model_editado.zip` + texturas e backup ZIP.
- `MotionCleanup`: polimento final de mocap com filtragem de posição, slerp de quaternion, continuidade de hemisfério, spike guard e interpolação respeitando frames irregulares; slider no diálogo de mocap.
- `rig/ClothXpbd.kt`: solver XPBD CPU com constraints de estiramento/dobra, pins móveis, massa individual, gravidade, vento, damping, chão, esfera/cápsula, auto-colisão com grade espacial, bake em memória e streaming.
- `rig/ClothCacheCodec.kt` + `ProjectStore`: cache versionado de tecidos, CRC32, limites, write temporário+fsync+backup e métodos save/load em `cloth_cache/`.
- Recuperação: PMX editado tenta backup ZIP e depois o modelo original; câmera tenta `camera.vmd.bak` também quando o principal sumiu.
- Validação executada: `ProfessionalSystemsTest` 16/16 em compilação Kotlin/JVM isolada (câmera, pesos, solver/colliders/cache e mocap). Build Android/APK e aparelho não foram executados.
- Limites que permanecem: Weight Paint usa pincel espacial ancorado e ainda não recebe strokes por toque na viewport nem grava personagem extra; XPBD/cache são motor e infraestrutura, não estão ligados ao buffer dinâmico do renderer nem a controles visuais/timeline de bake. Editor de malha/UV, VFX/compositor e render offline continuam pendentes.

## 19.9 v1.37.0 — Ferramentas de produção e recuperação de animação
- `Editor.rippleDeleteRange`: apaga keys no intervalo e fecha o espaço deslocando para trás as keys seguintes das trilhas afetadas; Undo/Redo único.
- `Editor.reverseRange`: inverte no tempo keys de ossos e morphs; inverte as curvas Bézier dos segmentos internos; Undo/Redo como operação única.
- `Editor.repeatRange`: repete intervalo em ciclos, deslocando keys seguintes nas mesmas trilhas; suporta ossos e morphs e é uma única operação no histórico.
- `Editor.smoothRange`: suaviza posições, rotações por quaternion e morphs sem alterar os quadros das keys, mantendo as extremidades fixas; intensidade e passes limitados.
- UI em Esqueleto → Keys → Trecho, incluindo presets Bézier em lote para trilhas ósseas.
- `ProjectStore.saveAnim`: gravação temporária sincronizada e backup único anterior; a abertura tenta recuperar `.bak` se o VMD principal não passar no parse.
- Teste novo: `AnimationProductionToolsTest` (5 casos), executado em JVM isolada com stubs mínimos para a camada Compose e dependência de IK. Isso verifica a lógica de edição, não o Android.
- Pendente: build completo Gradle/AGP, APK e validação em aparelho; revisar loops com diferentes cadências, reversão de intervalos parciais e suavização em animações de contato/impacto. Weight Paint, editor de mesh, tecido XPBD, VFX/compositor e render offline continuam não implementados.
