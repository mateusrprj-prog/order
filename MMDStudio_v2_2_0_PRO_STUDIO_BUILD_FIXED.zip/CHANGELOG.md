## [2.2.0] — 2026-11-23 — Animated Cloth + IK Assist + Shader Graph

### Cloth Studio: colisão animada e inércia entre poses
- `Animator` agora expõe avaliação de pose sem buffers GL, transformação de pontos/vetores pelo skinning blended e conversões entre espaço global deformado e espaço local pré-skinning.
- O bake prepara pose atual e pose anterior por quadro. A posição/velocidade do tecido parte da pose anterior; superfície corporal, âncoras e colisores são avaliados na pose atual. Ao final, o cache é convertido de volta para o espaço local pré-skinning, mantendo a integração com o renderer existente.
- Triângulos da superfície corporal são deformados por morphs e skinning a cada quadro, excluindo a região de roupa simulada. A broadphase espacial do XPBD é reconstruída por quadro para a superfície animada.
- Esferas, cápsulas e caixas de rigid bodies PMX ligados a osso (modo 0) acompanham a transformação do osso; caixas respeitam rotação composta. O painel explica os modos que ainda não são re-simulados.
- O modo segue animação exige colisão de superfície ativa; caso contrário permanece a simulação local estática. O bake segue offline/CPU e o cache continua local pré-skinning.

### Rig Studio: IK Assist
- Nova aba `IK Assist` em Rig, com seleção de controlador, raiz, intermediário e ponta. Ao escolher um controlador PMX IK, a cadeia inicial usa o alvo e os links declarados no PMX (primeiro link como intermediário e último como raiz).
- Solver analítico de dois segmentos com pole vector, limites mínimo/máximo de dobra, alcance mínimo/máximo, tratamento de alvo inalcançável e preservação dos comprimentos dos segmentos.
- A prévia valida a hierarquia raiz → intermediário → ponta. O botão grava um keyframe de posição no controlador IK; o Animator existente continua executando o CCD e limites nativos do PMX.
- O solver de dois segmentos é uma ferramenta assistiva de prévia; não substitui o CCD do PMX nem tenta modificar diretamente a rotação dos elos.

### Material Studio: Shader Graph PMX
- Novo avaliador DAG com nós Color, Value, Multiply, Mix, Principled e Output, sockets de entrada, detecção de IDs duplicados, links ausentes e ciclos inclusive em ramos não conectados à saída.
- A UI permite construir uma cadeia de cor com Multiply/Mix, escolher tint e ajustar metallic/roughness, aplicando o resultado ao material PMX selecionado.
- O compilador converte o surface em diffuse/specular/specularPower/ambient PMX e preserva textura, esfera, flags, toon e metadados do material. Metallic é aproximado pelo especular porque PMX não possui canal metallic nativo.
- Isto é um bake de grafo de material compatível com PMX, não um interpretador de nós GPU: normal maps e efeitos de superfície avançados continuam limitados pelo renderer PMX.

### VFX Studio: explosão e vórtice
- Acrescentados `EXPLOSION` e `VORTEX` ao gerador procedural determinístico de partículas. Explosão usa dispersão radial esférica com expansão, desaceleração artística e queda; vórtice organiza partículas em hélice com oscilação radial.
- Os dois efeitos aparecem no painel e utilizam o renderer/captura existente. São linhas/sprites estilizados, sem solver volumétrico ou colisões físicas.
- Smoke tests cobrem ambos individualmente e verificam os 13 estilos completos.

### Versão e validação
- Gradle: `versionCode 102`, `versionName "2.2.0"`.
- Core Kotlin/JVM compilado para Shader Graph, IK Solver, Cloth XPBD, UV/Mesh, VFX e PMX Writer/Parser; smoke harness 12/12; 19/19 métodos JUnit compatíveis (10 UV/Mesh + 9 novos); PSI sintático 12/12 arquivos Kotlin verificados.
- Os testes JUnit foram compilados e executados com um runner local de compatibilidade (não é o runtime oficial Gradle/JUnit). Build Android/Compose, APK, OpenGL real e teste em aparelho não foram executados neste ambiente.

---

## [2.1.0] — 2026-11-23 — UV Studio LSCM + Mesh Editing

- Novo `edit/UvUnwrapper.kt`: detecção de seams por ângulo diedro e fronteiras de materiais, charts por conectividade, parametrização LSCM com solver sparse/gradiente conjugado, fallback planar determinístico e packing de ilhas com padding.
- O unwrap duplica vértices PMX que pertencem a charts distintos, remapeia índices e preserva posição/normal, pesos, bones, weight type, SDEF, UVs adicionais, edge scale e morphs de vértice; atualiza o tamanho do índice PMX quando necessário.
- Novo `edit/MeshEditing.kt`: apagar faces dentro da seleção, extrudar/inset patches, inverter winding com recálculo de normais e remover triângulos degenerados; atualiza `indexCount` por material e mantém vértices órfãos para não quebrar morphs.
- `ModelToolsPanel.kt`: controles de costura/unwrap assíncrono no UV Studio e operações de faces na aba Seleção.
- Dez testes JUnit adicionados em `MeshUvStudioTest.kt` e executados via harness local compatível de asserções (10/10); core compile, smoke harness 2.0 regressão e PSI sintático 4/4 aprovados. Round-trip `PmxWriter`/`PmxParser` aprovado para unwrap com seams e extrusão/inset. O runtime Gradle/JUnit não foi executado.
- Android `versionCode 101`, `versionName 2.1.0`.
- Limites: morphs UV PMX tipos 3–7 preservados em formato bruto sem duplicar os índices internos; ainda não existe desenho/edição visual de seams no viewport, seleção de faces por raycast, bevel, loop-cut ou bridge. Gradle/SDK, APK e aparelho não validados.

# MMD Studio — CHANGELOG

## [2.0.0] — 2026-11-23 — Studio Milestone: viewport paint + post pipeline + resumable rendering

### Weight Paint na viewport
- Novo modo de toque `WEIGHT_PAINT` em `SceneGLView`: arrastar na viewport amostra vértices projetados do PMX principal e entrega posições locais para `WeightPaintSession`.
- Novo `paintStroke(...)` acumula amostras de um gesto e registra um único checkpoint; um gesto completo vira uma operação Undo/Redo. O painel expõe liga/desliga da pintura, osso, peso alvo, intensidade, raio local e modo Replace/Add/Subtract.
- Seleção usa projeção CPU de vértices no raio do toque, priorizando profundidade NDC frontal. Não é raycast de triângulo nem leitura de depth buffer: malhas sobrepostas/poses deformadas podem selecionar vértice aproximado.

### Mesh / escultura
- O pincel de escultura espacial oferece Inflate, Smooth, Pinch e Move; centro e raio são definidos localmente e o modo Move agora possui deslocamento XYZ configurável na UI.
- Cada aplicação cria um checkpoint único; recálculo de normais permanece integrado ao ModelToolsSession.

### Post Studio / compositor de exportação
- Novo `PixelCompositor` determinístico com exposição, contraste, saturação, ACES tone mapping, vinheta, grão e aberração cromática. Configuração sanitizada e alpha preservado.
- Novo painel `PostPanel`, com preset Cinema/Original e persistência atômica por projeto em `post_fx.json` + backup.
- Pós-produção aplicada a exportação PNG, sequência PNG e MP4 capturado pelo renderer. A viewport de edição permanece sem alteração destrutiva.

### Render sequence resumível
- Novo `FrameSequenceCache`: quadro PNG temporário/atômico com CRC32, arquivo sidecar de integridade e assinatura de job. Quadros íntegros são reutilizados na nova tentativa; quadros ausentes/corrompidos são refeitos.
- Cache invalidado quando assinatura muda. A assinatura considera projeto, range, FPS, aspect/resolução, geometria/topologia, VMD, transformações/cena, câmera livre, aparência do renderer, VFX, tecido e pós-efeitos.
- ZIP final inclui `render_manifest.txt`; cache é removido após exportação concluída e preservado quando a operação falha. O cache fica em `cacheDir` do Android, portanto limpeza de armazenamento/cache pelo sistema pode eliminá-lo.

### VFX / versão
- Novos estilos determinísticos `FIRE` e `SMOKE`, integrados ao renderer de partículas já usado nas capturas. São partículas estilizadas em GL, não simulação volumétrica de fogo/fumaça.
- Versão Android atualizada para `versionCode 100`, `versionName 2.0.0`.

### Verificação e limites
- Compilação isolada Kotlin/JVM dos módulos de modelo, edição de malha, topologia, transferência/pintura de pesos, VFX, compositor e cache: OK.
- Smoke harness executado: **6/6 grupos PASS**; inclui escultura e Undo, stroke Weight Paint com Undo, compositor determinístico/alpha, validação/invalidação CRC de cache e partículas FIRE/SMOKE finitas/determinísticas.
- 7 testes JUnit adicionados em `ProductionV200Test.kt`, mas não executados via Gradle neste ambiente.
- Não executados: Gradle Android/Compose, APK, testes instrumentados, validação da tela em dispositivo e renderização GL em hardware.
- Limitações: Weight Paint viewport é aproximação por vértice projetado sobre posições base do PMX principal, sem raycast/depth buffer e sem resolver a pose/skinning real do vértice; não pinta personagens extras. O Post Studio atua nos exports PNG/MP4/sequência, não na prévia viewport. O resume é best-effort em cache privado de app. A exportação de sequência usa captura do renderer já existente e não é render offline independente.

---

# Changelog — MMD Studio

## [1.42.0] — 2026-11-23 — Studio Expansion

### Cloth Studio / XPBD
- Seleção da região simulada por influência de osso (threshold configurável), além de intervalo e material.
- Colisores PMX caixa orientada, esfera e cápsula.
- Colisão com superfície corporal triangular estática no pose de repouso, acelerada por grade espacial/broadphase; espessura configurável.
- Bake ampliado para 240 quadros e parâmetros de colisão na interface. As colisões por superfície não acompanham deformação animada do corpo durante o bake.

### Weight Paint / transferência entre rigs
- Nova importação de PMX de origem no painel Pesos por seletor Android; o arquivo é apenas referência de pesos e não substitui o modelo aberto.
- Transferência de pesos por KD-tree/k-NN e distância inversa, mapeando ossos por nome normalizado; opção de vizinhos e limite de distância.
- Integração com `WeightPaintSession` como uma operação Undo/Redo; geometria, materiais, morphs e física do modelo alvo são preservados.
- Mantido pincel espacial local, paint por seleção, normalização, poda, suavização, espelhamento e modos Replace/Add/Subtract.

### Mesh / UV / diagnóstico
- `MeshTopologyAnalyzer`: bordas abertas, arestas non-manifold, orientação inconsistente, componentes conectados, isolados, posições duplicadas, triângulos de área UV nula e registros inválidos.
- Relaxamento Laplaciano UV com fronteira da seleção fixa.
- Atlas projetado por material com preservação de vértices compartilhados; não divide vértices nem cria seams reais.

### VFX
- Estilos novos: bolhas, órbita, raio e magia; nove estilos totais.
- `GL_POINTS` com sprite circular suave e mistura aditiva, além das trilhas existentes; sincronizados à timeline/captura.

### Versão e validação
- `versionCode 85`, `versionName 1.42.0`.
- 12/12 grupos de regressão anteriores e 6/6 grupos novos de smoke tests Kotlin/JVM passaram; ver `docs/REL_1_42_0_TEST_RESULTS.txt`.
- Build Android/Compose, JUnit via Gradle, APK e renderer GL em hardware continuam pendentes de validação.

### Limites conhecidos
- Colisão triangular do corpo usa pose estático/rest; sem collision geometry animada por quadro.
- Auto-colisão até 2.048 vértices; região do bake até 20.000 vértices e 240 quadros.
- Transferência de pesos exige modelos alinhados no mesmo espaço local/escala; ossos sem correspondência podem cair no osso raiz fallback.
- Weight Paint ainda não recebe strokes de raycast/toque da viewport.
- Atlas UV é projeção por tile, não unwrap LSCM/ABF nem criação automática de seams.
- VFX não são volumétricos e não têm física/colisão de partículas.

## [1.41.0] — 2026-11-23 — Cloth Studio XPBD integrado à cena e ao renderer

### Simulação de tecido ligada à timeline
- Novo painel **Tecido** no SceneScreen, com bake CPU por quadro, seleção por intervalo de vértices ou por material PMX, frames (1–120), gravidade, vento XYZ, subpassos, iterações e auto-colisão limitada a 2.048 vértices.
- Vértices fora da região selecionada tornam-se âncoras; na seleção por material, a região ativa é extraída dos índices dos triângulos pertencentes ao range daquele material, e não de uma aproximação pelo nome.
- O bake usa `ClothXpbd.fromMesh`, constraints de estiramento/dobra, âncoras, massas e colisores PMX esféricos/cápsulas. Cápsulas são aproximadas pelo eixo local Y e rotação Euler PMX; colisores caixa não entram no solver ainda.
- A viewport aplica o deslocamento XPBD interpolado pelo frame sobre posições base/morph antes do skinning GPU. Isso preserva o movimento dos ossos e faz o tecido acompanhar playback, captura PNG, sequência de frames e render MP4 do mesmo renderer.
- Normais são recalculadas para a geometria deformada e enviadas por VBO dinâmico enquanto o bake está ativo; ao limpar/inutilizar o cache, o renderer restaura posições base e normais originais.
- Cache `cloth_cache/main.clothcache` é salvo no diretório do projeto via temporário + fsync + backup e acompanha a pasta exportada do projeto. A tela tenta restaurá-lo ao reabrir.

### Segurança e compatibilidade do cache
- Formato binário XPBD v2 inclui assinatura CRC32 de posições e índices do PMX, além do CRC do arquivo. O app invalida cache se assinatura geométrica/topológica, contagem de vértices ou FPS não conferirem.
- Codec continua lendo arquivos v1 antigos (sem assinatura); como esses arquivos não provam qual geometria originou o cache, a UI os rejeita para reprodução e solicita novo bake.
- Ao salvar uma malha transformada, o bake antigo é apagado para evitar aplicar deslocamentos de uma geometria anterior.
- `GlModel` possui VBO dinâmico de normais da roupa; o buffer é liberado junto com o restante dos recursos GL.
- `versionCode 84`, `versionName 1.41.0`.

### Validação e limites
- Compilação isolada de Kotlin/JVM puro (`PmxModel`, parser/writer PMX, ModelTools, WeightPaint, ParticleFx, ClothXpbd e ClothCacheCodec): OK.
- **12/12 smoke-check groups** em JVM: seleção/topologia, escultura + Undo, suavização/inflação, UV, Weight Paint, slots de textura, VFX determinístico, round-trip PMX, solver XPBD com âncoras, cache v2 + CRC/assinatura, leitura legada v1 e cinco estilos VFX finitos.
- **12 testes JUnit definidos** em `AdvancedStudioToolsTest.kt`; a suíte JUnit via Gradle não foi executada.
- Não validado nesta sessão: build Android/Compose, APK, execução em dispositivo e shader/renderer GL em hardware real.
- Limites: seleção por material ou faixa de índices (sem pintar a região do tecido por toque); colisores esfera/cápsula apenas, sem caixas; cápsula aproximada no eixo Y; auto-colisão desligada por padrão e limitada a 2.048 vértices; bake limitado a 20.000 vértices e 120 quadros; sem simulação interativa em tempo real. A UI não oferece barra de progresso/cancelamento do bake.

## [1.40.0] — 2026-11-23 — Model Studio + VFX procedural

### Bancada de modelo e edição
- `ModelToolsSession`: seleção por material, osso, intervalo e caixa espacial; selecionar tudo/inverter/limpar, crescer/encolher por adjacência e selecionar bordas abertas.
- Escultura localizada: transformar em torno do centroide, inflar por normal e suavização Laplaciana; Undo/Redo preserva histórico das edições.
- UV: UI para projeção planar, cilíndrica e esférica, espelhar, transformar e normalizar a região UV selecionada. Projeções cilíndrica/esférica não criam seam/ilhas nem duplicam vértices.
- Weight Paint na aba Pesos: aplicar replace/add/subtract a vértices selecionados, normalizar, podar influências, suavizar, espelhar X e Undo/Redo. A seleção atual é por comandos de painel; não é um pincel direto por toque na superfície.
- Material Studio PMX: reassociar textura base/esfera e modo de esfera; editar diffuse/specular/ambient, brilho especular, contorno e flags de duas faces. Preserva nome/contagem e demais dados do material.
- Diagnóstico: índices, triângulos degenerados, normais, UVs, pesos, posições e contagem por material. Salvamento recompõe PMX, texturas e pesos e atualiza viewport/motion.

### VFX e projetos
- Novo `fx/ParticleFx.kt`: efeitos procedurais determinísticos (faíscas, chuva, neve, aura, confete) com origem, propagação, velocidade, gravidade, vida, tamanho, opacidade, cor e seed.
- `SceneGLView` desenha os segmentos GL_LINES no mundo da cena usando o frame/FPS do projeto. A renderização ocorre antes da captura, portanto o VFX aparece em PNG, sequência de frames e MP4 capturado pelo mesmo renderer.
- Novo painel VFX; `vfx.json` por projeto, escrita temporária + fsync + backup e recuperação de backup se o principal estiver inválido. Salvamento explícito no autosave/fechamento e antes da exportação do ZIP.
- `versionCode 83`, `versionName 1.40.0`.

### Verificação e limites
- Compilação isolada de `PmxModel`, `PmxParser`, `PmxWriter`, `ModelTools`, `WeightPaint` e `ParticleFx` com `kotlinc`: OK.
- 8/8 smoke checks: seleção/topologia, escultura+Undo, suavização/inflação, UV, Weight Paint+normalização+Undo, slots de textura+Undo, cinco estilos VFX finitos/determinísticos e round-trip PMX após editar geometria/material.
- 9 testes JUnit definidos em `AdvancedStudioToolsTest.kt`; a suíte Gradle completa não foi executada.
- Não validado: build Compose/Android, instalação em aparelho, toque para pintar/selecionar vértices na superfície, unwrap UV por ilhas, tecido XPBD integrado à deformação da viewport, Shader Graph, VFX volumétrico/compositor e render offline. O VFX desta versão usa segmentos GL_LINES, não partículas volumétricas.

## 1.39.0 — BANCADA DE MODELO: malha, UV, materiais e diagnóstico (núcleo JVM verificado; UI Android pendente)
- Novo modo **Modelo** no SceneScreen com abas Malha, UV, Materiais e Diagnóstico.
- Malha: escala XYZ e rotação XYZ em torno do centro da bounding box; atualização correspondente das posições dos ossos, tail offsets, eixos locais, morphs de vértice, corpos rígidos e juntas; recálculo de normais ponderado por área. Rotações de corpos/juntas compostas via quaternion e serializadas em radianos PMX.
- UV: projeção planar XZ/XY/ZY; espelhamento U/V; escala e offset de UV para tiling.
- Materiais: edição diffuse RGBA, especular/ambiente RGB, brilho, contorno, duas faces e flag de contorno, preservando referências de textura e ranges dos materiais.
- Diagnóstico: índices inválidos, faces degeneradas, normais, UVs fora de 0..1, pesos/índices de ossos e consistência de contagem por material.
- Aplicação usa PmxWriter + ProjectStore.saveEditedModel para PMX/texturas; Editor.replaceModel conserva tracks VMD com nomes de ossos válidos e renderer recarrega mantendo viewport/frame.
- `ModelTools.kt`, `PmxModel.kt`, `PmxWriter.kt` e `PmxParser.kt` compilados isoladamente com kotlinc; **8/8 smoke checks JVM passaram**, incluindo round-trip PMX, quaternion/radianos para rigid bodies/juntas, UV tiling e validação de posição não finita. Sete testes JUnit estão em `ModelToolsTest.kt`, mas não foram executados via Gradle.
- **Pendente:** build Android/Compose, render GL e validação em aparelho; viewport UV por ilhas/seams, edição topológica, pincel direto sobre viewport, tecido XPBD ligado à malha dinâmica, shader graph/VFX e render offline.

# Changelog

## [1.38.0] — 2026-11-23 — Câmera VMD, Weight Paint PMX, limpeza mocap e motor XPBD. FONTES ALTERADOS; 16 TESTES JVM PASSARAM; build Android/APK não executados
- **Editor de câmera VMD** no painel Câmera: keys no quadro atual, distância, centro XYZ, rotação XYZ, FOV, exclusão, linearização, suavização frame-aware e inversão temporal. Persiste em `camera.vmd` separado da animação de personagem.
- **Weight Paint PMX** em Esqueleto → Pesos: modos substituir/adicionar/subtrair, pincel esférico, API de stroke em cápsula, normalizar, podar, suavizar por vizinhança, espelhar X JP/EN, consultas de influência e Undo/Redo local. Aplicar no personagem principal grava `model_editado.zip` com texturas e mantém backup `.zip` reconhecido pelo importador.
- **Polimento de Motion Capture** no diálogo de vídeo: filtro de posição, quaternion, continuidade de hemisfério e redução de picos; interpola pela distância real entre frames.
- **Motor XPBD de tecido** em `rig/ClothXpbd.kt`: constraints stretch/bend, pins móveis, massa individual, gravidade/vento, amortecimento, chão, colisores esfera/cápsula, auto-colisão espacial opcional, bake em memória e streaming CPU.
- **Cache XPBD versionado** em `rig/ClothCacheCodec.kt`: payload XYZ/frame, CRC32, limites de tamanho, gravação temporária + fsync + backup; `ProjectStore` oferece save/load em `cloth_cache/`.
- **Recuperação de projeto**: modelo PMX editado tenta backup ZIP e, em último caso, o original importado; câmera tenta backup mesmo se o principal estiver ausente.
- `ProfessionalSystemsTest`: 16 testes JVM isolados passaram, incluindo câmera irregular/wrap, stroke de peso, self-collision, CRC/backup e mocap.
- Limites: Weight Paint não tem pintura direta sob o dedo na viewport nem persistência de personagens extras; XPBD ainda não está conectado ao buffer dinâmico da viewport/timeline e precisa de UI/bake integrado; editor de mesh/UV, VFX/compositor e render offline continuam pendentes. Sem Gradle/Android SDK neste ambiente, Compose/APK/aparelho não foram validados.

## [1.37.0] — 2026-11-23 — Ferramentas de produção de animação e recuperação de autosave. CÓDIGO ALTERADO; build Android ainda não executado neste ambiente
- **Presets Bézier em lote**: aplica Linear, Início suave, Fim suave, Suave, Forte, Segurar e Pulo aos quatro canais das keys ósseas de todas as trilhas selecionadas no intervalo, em uma operação de Undo.
- **Excluir + fechar (ripple delete)**: apaga as keys do intervalo e desloca as keys posteriores para trás pelo comprimento do trecho, apenas nas trilhas que tinham keys dentro do intervalo. Uma operação de Undo/Redo.
- **Reverter tempo**: inverte as keys selecionadas de ossos e morphs dentro do intervalo, mantendo a duração e invertendo também os segmentos Bézier internos para preservar a forma temporal. Uma única operação de Undo/Redo.
- **Repetir trecho / criar ciclos** na aba Esqueleto → Keys → Trecho: duplica um intervalo por N ciclos (1–20), preserva os dados de osso e morph e empurra as keys posteriores das mesmas trilhas para abrir espaço. A operação inteira é um passo de Undo/Redo; limites de frame e intervalos vazios são recusados.
- **Suavizar movimento** na mesma aba: filtro determinístico para keys existentes, preserva os quadros e as keys extremas; posições/morphs usam média linear e rotações usam média de quaternion com alinhamento de hemisfério. Intensidade e passes configuráveis (1–8), um único passo de Undo.
- **Autosave VMD mais resistente**: gravação por arquivo temporário + sync + substituição, mantendo um backup anterior. Na abertura, se o VMD principal estiver inválido, tenta recuperar o backup e informa o usuário. Salvar uma animação vazia apaga também o backup para respeitar a intenção de limpar.
- Novo `AnimationProductionToolsTest` (9 casos) com cenários de repetição multi-trilha, deslocamento das keys seguintes, inversão de valores e curvas Bézier, aplicação em lote de presets, isolamento de outras trilhas, Undo, smoothing de posição/morph e limites.
- Verificação pendente: não há Gradle/Android SDK wrapper disponível neste ambiente; Compose, AGP, APK e comportamento no aparelho ainda precisam de build/teste. As alterações são código implementado, não uma declaração de validação final.

## [1.36.0] — 2026-11-20 — Lipsync automático por áudio. ESCRITO; JVM EXECUTADO (38 testes); APK/aparelho NÃO validados
- `ai/LipSync.kt` (lógica pura): para cada quadro da timeline analisa ~32 ms do áudio (mono, até 16 kHz) por **LPC**, extrai F1/F2 do envelope espectral e escolhe a vogal japonesa mais próxima (あ い う え お); a abertura da boca vem da energia (dB) relativa ao trecho mais forte, com porta de ruído regulada pela **sensibilidade**; sons tipo "s/f" (muitos cruzamentos por zero) viram boca quase fechada; filtro de moda e suavização evitam tremedeira; saída esparsa (só keys que mudam a curva). Respeita o **atraso** do painel Áudio. Funciona em qualquer idioma (segue o som, não reconhece palavras).
- Mapeamento automático das vogais para os morphs do modelo (nomes JP あ/い/う/え/お e EN a/i/u/e/o, vowel_a, mouth_a…); mostra no diálogo quais foram achados e quais faltam.
- UI: painel **Áudio → "Lipsync automático"** abre o diálogo (sensibilidade, abertura da boca). Grava no personagem principal num **único passo de desfazer**, substituindo as keys dos morphs de vogal dentro do trecho do áudio (`Editor.applyAnim`). `AudioMux.decodePcm` expõe a decodificação (máx. 3 min).
- Testes (`LipSyncTest`, 9): vogais sintéticas em sequência (pulsos + ressonadores F1/F2/F3), silêncio, volume menor abre menos, intensidade limitada a 1, offset, keys esparsas, downmix/decimação, nomes de morph. Executados com 29 existentes = 38 passam (kotlinc 2.0.21 + stub de org.json). NÃO cobrem Compose/MediaCodec/APK/aparelho nem áudio real de voz.
- Limites: aproximação acústica (não é reconhecimento de fala); música alta por cima do vocal gera vogais falsas; só personagem principal; sem morphs de consoante (m/b/p fecham a boca só pela energia); sem ajuste fino por vogal.

## [1.35.1] — 2026-11-20 — Correção em fatias: painel Partes utilizável + saia contra colisores do corpo. ESCRITO; JVM EXECUTADO (29 testes); APK/aparelho NÃO validados
Origem: vídeos do usuário no POCO X7 Pro — (1) o painel Rig → Partes ficava espremido (só sobrava ~1 linha para a lista) e (2) a saia ainda atravessava as pernas.
### Fatia 1 — painel (`ui/EditPanels.kt`, `ui/PartsPanel.kt`)
- Botão **"⛶ Tela cheia"** no cabeçalho do Rig: abre as 4 sub-abas (Restrições/Secundário/Física/Partes) num diálogo de tela inteira, com o mesmo estado; "✕ Fechar" volta. No painel pequeno o texto de ajuda longo das Partes some (`compact`) para sobrar espaço à lista.
### Fatia 2 — saia (`mmd/Animator.kt`, `rig/BodyColliders.kt`)
- O movimento secundário (ossos da saia) era só mola de rotação, sem colisão: os colisores da v1.34/v1.35 só afetavam corpos rígidos. Agora, com **"Colisores do corpo" + "Colisão entre corpos"** ligados, uma 2ª passada na pose (pernas já finais) testa o meio e a ponta de cada osso secundário contra as cápsulas (quadril/coxas/panturrilhas, respeitando o ajuste de raio) e gira o osso em torno da própria raiz até sair (máx. ~1 rad, comprimento preservado). Não altera a perna, a animação, o estado da mola nem o PMX; sem estado, logo determinístico.
- `BodyCollider` ganhou `a`/`b` (pontas em repouso).
- Teste novo `skirtBoneIsPushedOutOfThighOnlyWhenBodyCollidersOn`. Executados: 29 (17 partes + 12 colisores) passam compilando `mmd/*` e `rig/*` com kotlinc 2.0.21 + stub de org.json. Compose/GL/Gradle/APK/aparelho NÃO cobertos.
- Limites: só ossos de movimento secundário (a saia por corpos rígidos segue com o motor de física); amostra meio+ponta (saia muito larga entre ossos ainda pode vazar); sem tecido.

## [1.35.0] — 2026-11-20 — Ajuste manual dos colisores corporais (P2 2.2). ESCRITO; JVM EXECUTADO (28 testes); APK/aparelho NÃO validados
- `PhysConfig.colliderScale` (mapa chave→multiplicador de raio, 0,5–1,6, JSON `bs`, limitado ao ler; entra no hash do cache). Por personagem, salvo no projeto; projetos antigos abrem sem ajustes.
- `PhysEngine` aplica o multiplicador ao raio de cada colisor gerado a cada passo (o trecho reto não muda). Só vale com "Colisores do corpo" ligado.
- UI (Rig → Física): um slider por colisor (Quadril, Coxa esq./dir., Panturrilha esq./dir.) quando a chave está ligada.
- Testes novos em `BodyCollidersTest` (11 no total): maior/menor escala empurra mais/menos a saia no motor, outro colisor não interfere, codec e limites. Executados: 17 + 11 = 28 passam (mesmo método da v1.34.0; Compose/GL/Gradle/APK/aparelho não cobertos).
- Pendente: ajuste de posição/deslocamento, torso/braços, visualização dos colisores no viewport, tecido.

## [1.34.0] — 2026-11-20 — Colisores corporais gerados do esqueleto (P2 2.2). ESCRITO; JVM PARCIAL EXECUTADO; APK NÃO COMPILADO, NÃO TESTADO NO APARELHO
### Adicionado
- `rig/BodyColliders.kt` (lógica pura): gera cápsulas cinemáticas para **quadril** (ligando as raízes das coxas, presa ao 下半身), **coxas** (足→ひざ) e **panturrilhas** (ひざ→足首), esquerda e direita. Ossos por nome JP (左足/左ひざ/左足首/下半身) e EN (`thigh_L`, `Right Knee`, `lowerbody`…); ossos IK, "D", twist (捩) nunca são usados.
- Raio **medido nos vértices** (mediana da distância ao eixo dos vértices com >50% de peso no osso, projeção dentro do trecho); com menos de 24 vértices usa proporção do comprimento e marca "não medido". Limites de raio por proporção do segmento.
- Elementos já cobertos pelo modelo (corpo rígido cinemático preso ao mesmo osso) são **pulados**; o grupo de colisão herda o grupo mais usado pelos corpos cinemáticos do corpo do próprio modelo (respeita o filtro/máscara do PMX).
- `PhysConfig.bodyColliders` (padrão **desligado**; projetos antigos não mudam; JSON `bc`; entra no hash do cache de física, então ligar/desligar invalida o bake). Por personagem (cada `PhysConfig` já é por personagem).
- `PhysEngine`: os colisores entram como corpos rígidos cinemáticos extras (índices depois dos do modelo), só participam da colisão quando a opção está ligada. Não alteram o `PmxModel`, o PMX exportado nem a animação.
- UI (Rig → Física): chave "Colisores do corpo (quadril/pernas)" com resumo (quantos gerados, quais já cobertos/ausentes). Depende de "Colisão entre corpos".
### Testes
- `BodyCollidersTest` (9 casos): geração e raio medido, ossos IK/D ignorados, nomes EN, elementos cobertos pulados + herança de grupo, alinhamento do eixo da cápsula (Euler), corpos cinemáticos gerados, cache/modelo vazio, **motor: corpo dinâmico que começa dentro da coxa só é empurrado para fora quando a opção está ligada**, codec/compatibilidade do `PhysConfig`.
- **Executados de verdade** nesta entrega: `PartRecognizerTest` (17) + `BodyCollidersTest` (9) = **26 passam**, compilando com o kotlinc 2.0.21 do Gradle sobre os fontes não-Android (`mmd/*` e `rig/*`, exceto Glb/Gltf) e um stub mínimo de `org.json`. Isso valida lógica e o motor; **não** valida Compose, GL, Gradle/AGP nem o APK.
### Limites conhecidos
- Colisão aproximada por cápsulas uniformes (coxa não afunila). Não é tecido: a saia ainda é corpo rígido/movimento secundário; só deixa de atravessar quadril/pernas quando há corpos dinâmicos de saia. Corpos de saia ancorados dentro do raio do quadril serão empurrados: pode exigir ajuste fino no aparelho.
- Sem ajuste manual de tamanho/posição dos colisores (próxima fatia), sem torso/braços, sem visualização dos colisores no viewport.

## [1.33.0] — 2026-11-20 — Editor de Partes: grupos de nome livre (P1 1.2). ESCRITO; NÃO COMPILADO, NÃO TESTADO NO APARELHO
- Aba Partes: campo "Nome do grupo" + botões para nomear o grupo da parte inteira, tirar do grupo, ou mover só um elemento para o grupo (ex.: "Barra da saia"). O grupo vira uma parte própria (`categoria|nome`), com chave de Física própria e grupo de movimento secundário próprio (`part:categoria|nome`) ao aplicar.
- `PartRecognizer.sanitizeGroup` (sem "|" e ":", até 24 caracteres). Persistência já existente (`parts.json` / `cast/<id>.rig.json`); nenhum formato mudou.
- Teste novo `freeNamedGroupSplitsPartAndFeedsSecondary` (17 no total em `PartRecognizerTest`), NÃO executado.
- Continua pendente: destaque de materiais no viewport (exige mexer no renderer GL; fica para depois de um build real), colisores corporais, tecido.

## [1.32.0] — 2026-11-20 — Editor de Partes do Modelo (P1 1.1/1.2). ESCRITO; NÃO COMPILADO, NÃO TESTADO NO APARELHO

### Adicionado
- **Reconhecimento de partes por evidência combinada** (`rig/PartRecognizer.kt`, lógica pura): nome do osso (JP/EN), nome do corpo rígido, corpo rígido com física (só corrobora), herança pela hierarquia do esqueleto, nome do material e pesos dos vértices por material. Cada elemento (osso, material, corpo rígido) recebe uma confiança (alta / média / baixa / revisar) e a lista do "porquê". Nome de material sozinho nunca chega a "alta"; ossos-padrão do corpo (センター, 頭, 左腕, Neck…) nunca viram parte.
- Categorias: cabelo, franja, tranças e rabos, saia, mangas, casacos/partes soltas, gravatas/fitas/laços, cauda e orelhas, acessórios, roupa superior, roupa inferior, calçados/meias, peito/partes secundárias, corpo e rosto, desconhecida. Cauda/orelha, mangas, calçados e peito se dividem automaticamente por lado (Esquerda/Direita) quando o nome indica.
- **Aba "Partes"** em Esqueleto → Rig (`ui/PartsPanel.kt`): lista as partes com confiança; ao tocar mostra ossos (O), materiais (M) e corpos rígidos (C); por elemento: ver os indícios, "Selecionar osso" (destaca no viewport), confirmar, restaurar, **mover para outra categoria** ou **remover das partes**; por parte: confirmar, dividir esq./dir., dividir frente/trás (usa posição de ossos/corpos rígidos/centróide do material), restaurar automático. Chave "Física" por parte.
- **Efeito real**: "Aplicar física às partes" cria um grupo de movimento secundário por parte com a física ligada e com ossos (id fixo `part:<parte>`; reaplicar substitui só esses grupos e preserva os ajustes de sliders; não toca nos grupos manuais nem nos do "Auto"). Parte só com materiais (sem ossos) é ignorada e a nota informa.
- **Correções persistentes e por personagem** (`PartOverrides`): principal em `parts.json`; extras dentro de `cast/<id>.rig.json` (campo opcional `parts`; arquivos da v1.31.0 continuam abrindo). Correção manual sempre prevalece sobre o automático; correção feita para outro modelo (índice/nome não bate) é ignorada e contada.
- `RigConfig.parts`: duplicar personagem copia as correções; excluir remove junto com o perfil.

### Testes / validação
- `PartRecognizerTest` com 16 casos (17 a partir da v1.33.0) (evidências combinadas, herança, teto do nome de material, desconhecido com física, ossos-padrão, lados, palavras em inglês sem falso positivo, correção manual, elemento adicionado, remoção, codec e fallbacks, correções órfãs, divisão frente/trás, aplicação ao movimento secundário). **Escritos e conferidos à mão; NÃO executados** (sem Gradle/Kotlin neste ambiente). Build Android e teste no aparelho continuam pendentes.
- Não faz parte desta versão: destaque visual de MATERIAL no viewport, colisores corporais, colisão corpo/roupa, tecido, "participa de colisões" por parte (o motor ainda não tem colisão por parte; por isso não há controle falso). Física de tecido continua planejada (P2).

## [1.31.0] — 2026-11-20

### Adicionado
- Outliner da Cena aberto por padrão ao entrar no viewport, inspirado no seletor hierárquico do Blender. Reúne modelo principal, objetos importados em Cena, personagens do Elenco, luz, câmera e áudio; mantém seleção destacada e ações existentes de grupos, visibilidade e bloqueio.
- Selecionar um personagem no Outliner ativa a sessão de edição correspondente e abre o painel Rig desse personagem. O cabeçalho identifica explicitamente o dono da configuração (`CONFIGURAÇÃO DE RIG · <nome>`).
- Perfil independente de rig/física para cada personagem extra (`cast/<id>.rig.json`): restrições, movimento secundário e configuração de física real PMX. O personagem principal continua compatível com seus arquivos legados.
- Duplicar personagem copia o perfil para um novo ID; excluir personagem remove somente o seu perfil.
- Status resumido por personagem no Outliner (física real ligada/desligada e número de grupos de movimento secundário).

### Corrigido
- O renderer agora recebe e conserva o `RigConfig` próprio de cada personagem extra ao criar/recriar a instância; alteração de perfil atualiza somente o Animator correspondente e reinicia a dinâmica daquele personagem.
- Bake do movimento secundário e bake da física real aceitam o perfil ativo, sem cair no `RigState.main` para personagens do Elenco.
- Ações “Editar este personagem” e “Editar personagem principal” do painel Elenco agora atualizam seleção do Outliner, alvo ativo e painel Rig de forma consistente.

### Testes / validação
- Adicionado `CharacterRigProfileTest` com 3 casos: round-trip de dados, independência entre dois perfis e fallback seguro de versão desconhecida.
- Testes JVM e build Android NÃO executados neste ambiente; requer workflow GitHub Actions e teste no aparelho.
- Física de tecido/colisão corpo–saia NÃO faz parte desta versão e continua planejada separadamente.


## 1.30.2 — P0 URGENTE: transformar qualquer objeto adicionado em Cena (código-fonte atualizado; build não executado)
- O seletor de **Transformar** agora lista o personagem principal, personagens extras do Elenco e todos os objetos importados na aba **Cena** (`prop:<id>`), identificados como `Cena · <nome>`.
- Ao selecionar um item na lista de Cena, ele também passa a ser o alvo ativo do painel Transformar. Selecionar um objeto no menu Alvo atualiza a seleção correspondente da aba Cena.
- Objetos de Cena recebem transformação independente: posição X/Y/Z, rotação X/Y/Z, escala uniforme e keyframes interpolados na mesma timeline; cada objeto usa sua própria chave persistente `prop:<id>` em `root_transforms.json`.
- Projetos antigos são migrados automaticamente usando os valores já salvos em `props.json`. Ao duplicar um objeto, a trilha de transformação é duplicada com ID independente; ao excluir, sua trilha é removida.
- `applyRootTransformsAt()` agora aplica as transformações de todos os objetos de Cena na prévia e nos caminhos de captura/exportação que já chamam esse método; `setPropTransforms()` envia todos os props em um único evento para a thread GL por quadro.
- Corrigido `SceneGLView`: a rotação RX/RY/RZ agora também é aplicada a objetos soltos no mundo. Antes, o renderer aplicava esses ângulos apenas no caminho de objetos presos a ossos.
- Atualizados `TransformPanel`, `ScenePanel`, `SceneScreen`, `RootTransform` e testes de transformação.
- Validação: revisão estática e integridade do ZIP; testes JVM e build Android NÃO executados neste ambiente (sem Gradle, Gradle Wrapper e Android SDK). Teste em dispositivo ainda necessário.

# CHANGELOG
Estados: implementado / parcial / planejado / validado (escala 0–5 no roadmap, seção 13.1). Só 'validado' com build + teste no aparelho.

## 1.30.1 — P0 URGENTE: Transformação/rotação da personagem inteira. IMPLEMENTADA NO CÓDIGO-FONTE; BUILD ANDROID NÃO EXECUTADO
- Novo `scene/RootTransform.kt`: transformação raiz por alvo (personagem principal `model` ou extra `char:<id>`), com posição X/Y/Z, rotação X/Y/Z e escala; dados persistidos em `root_transforms.json` por projeto.
- Novo painel **Transformar** no SceneScreen: seletor de personagem, controle circular de rotação, campos numéricos de graus X/Y/Z, posição, escala, zerar rotação e criação/remoção de keyframes no quadro atual.
- O renderer agora aplica matriz de raiz `T * Rz * Ry * Rx * S` antes da projeção, tanto no principal quanto nos extras. Skinning/animação dos ossos continua separado; a câmera de viewport e a câmera VMD não são alteradas.
- A transformação é amostrada pela timeline e aplicada antes das capturas/exportações PNG, sequência e MP4; transformações dos extras sincronizam os valores legados de posição/giro/escala no `cast.json` para compatibilidade.
- Ângulos permanecem contínuos (ex.: 350° → 710°), permitindo giros completos animados; não são truncados para ±180°.
- Teste JVM adicionado/ajustado: `RootTransformTest` (codec round-trip, interpolação contínua, edição de keyframe). **Não executado neste ambiente.**
- **Status honesto:** código-fonte e documentação atualizados; não há Gradle wrapper, Gradle instalado nem Android SDK neste ambiente. Portanto, não foi possível compilar, executar testes JUnit Android/JVM completos nem validar o toque/render no aparelho. Verificar no GitHub Actions antes de instalar.
- Limites conhecidos: o controle circular manipula X/Y; Z é ajustado numericamente. Duplicar extra copia base e keyframes da transformação; remover extra limpa sua trilha. Não existe ainda rotação relativa à câmera, gizmo de anel 3D no viewport, Undo/Redo próprio, nem bake da transformação raiz para exportação VMD/GLB/FBX.

## 1.30.0 — P0 URGENTE: Navegação Livre da Viewport (Free Orbit Camera). ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO
- **Câmera de viewport extraída** para `render/OrbitCamera.kt` (matemática pura, sem Android): orbit, pan em espaço de câmera, zoom com limites (0,3–400), foco, enquadrar esfera/caixa, `presetLabel`. Não toca em modelo, osso, keyframe, IK nem Undo.
- **Orbit livre**: 1 dedo gira em qualquer ângulo (yaw sem limite, pitch ±89° sem inversão). Nas ferramentas Girar/Mover o dedo só edita o osso se o toque COMEÇAR a ≤56 dp do osso selecionado; fora disso orbita (antes ficava preso editando o osso).
- **Pan corrigido**: 2 dedos movem o foco no plano da câmera (antes ignorava a elevação) e a velocidade acompanha a distância/FOV.
- **Zoom por pinça** via `OrbitCamera.zoom` (limites seguros, ignora NaN/≤0).
- **Foco**: menu do viewport ganhou "Focar personagem ativo" e "Focar item selecionado"; "Enquadrar tudo" agora enquadra a caixa real da cena (extras e acessórios) em vez de só resetar. Mantém yaw/pitch e passa a orbitar o novo ponto.
- **Gizmo de orientação** (`ui/OrientationGizmo.kt`, canto superior direito): eixos ±X/±Y/±Z projetados pela câmera; tocar num eixo vai para Direita/Esquerda/Topo/Base/Frente/Trás e continua orbitável. Presets do menu/Outliner mantidos (viram atalhos).
- Testes JVM novos: `ViewportNavigationTest` (20 testes: base ortonormal, pitch/yaw, distância constante na órbita, pan sem andar na visada, zoom limitado, foco, enquadrar caixa com pivô distante, presets, gizmo). **Não executados aqui (sem Gradle/kotlinc no ambiente).**
- Pendente (P2): sensibilidade configurável, inércia, persistência da vista no projeto, ponto de órbita escolhido por toque.
## 1.29.13 — 8.3d-B3: renderer no personagem ativo (esqueleto desenhado, seleção e arrasto de ossos no extra; escrita, NÃO compilada). Fecha a 8.3d-B
## 1.29.12 — 8.3d-B2: personagem ativo editável pela UI (botão "Editar este personagem" no Elenco; Esqueleto/Keys/Dope Sheet/Desfazer/Key apontam para o ativo; salva em cast/<id>.vmd; escrita, NÃO compilada)
## 1.29.11 — 8.3d-B1: base lógica do personagem ativo (ActiveCharacter + EditSessions; 5 testes JVM OK; sem mudança de UI)
## 1.29.10 — 8.3d-C: exportar todos os personagens em .zip (CastExport; 3 testes JVM OK; UI NÃO compilada)
## 1.29.9 — 8.3d-A: copiar/colar poses entre personagens (PoseTransfer; 6 testes JVM OK; UI NÃO compilada)
## 1.29.8 — 8.4b final: Outliner lê a hierarquia do Scene Graph (SceneHierarchy; 7 testes JVM OK; UI NÃO compilada)
## 1.29.7 — Seleção por toque na viewport (8.4b; escrita, NÃO compilada)
## 1.29.6 — Cartoon: sinais de eixo corrigidos + IK das pernas desligado no trecho (30 testes JVM OK; UI NÃO compilada)
## 1.29.5 — Cartoon: editor acima da lista, barra de prévia, nomes sem corte, painel 380 dp; GLB: lista de animações volta ao reabrir (escrita, NÃO compilada)
## 1.29.4 — correção de build: `import java.util.Properties` no build.gradle.kts (erro 'Unresolved reference: util/load' no CI, vindo da v1.28.2)
## 1.29.3 — Outliner: seleção múltipla + agrupar (8.4b; escrita, NÃO compilada)
## 1.29.2 — Cartoon em personagens extras (escrita; UI NÃO compilada; lógica pura testada em JVM)
- Alvo "Aplicar em" no painel Cartoon; prévia e aplicar no extra; `CartoonMerge` (mescla + grava VMD); "Desfazer no extra" (até 20 passos). 21/21 testes JVM (CartoonMerge 7 + Cartoon 14) executados.
## 1.29.1 — Undo/Redo do Outliner (8.4b-1; escrita, NÃO compilada)
- `History<T>` + botões desfazer/refazer no painel Layers; snapshot de organização + nomes de props/extras. Excluir/duplicar fora do histórico.
## 1.29.0 — Outliner funcional, fatia 8.4a (escrita, NÃO compilada, NÃO testada no aparelho)
- Renomear, mover, bloquear, visível no render, grupos, duplicar, excluir; persistência em `outliner.json`. Nível 3 (interface) no papel; 4 (persistência) só após teste. Sem Undo/Redo; Scene Graph ainda não ligado.
## 1.28.2 — segurança/documentação (escrita, NÃO compilada)
- Senhas de assinatura removidas do Gradle; `.jks` fora do zip; `.gitignore`; este changelog.
## 1.28.1 — correção de crash na Cartoon (texto com '100%' em format). Não validada.
## 1.28.0 — Cartoon Motion Library P1–P3 (nível 2–3; sem build confirmado).
## 1.27.0 — Elenco (8.3c) (nível 2; sem build confirmado).
## 1.26.0 / 1.25.0 — RigConfig por personagem / renderer por instância (sem build confirmado).
## 1.24.2 — correção visual do painel Luz (visto em print do aparelho).
## 1.24.1 — correção de build (`mainChar.shBone`); primeiro build que abriu no aparelho.
## 1.24.0 — troca de clip GLB desfazível.
## 1.14.0–1.23.0 — D/G (física/importação), Releases 5, 7, 8.1–8.2, 9.1–9.4. Compilaram e abriram (v1.24.1); funções sem teste explícito.
## Até 1.12.x — ver seção 6 do md de contexto (várias confirmadas no aparelho).

## Nota de planejamento — Física de roupas (20/11/2026; sem mudança de versão/código)
- Auditada a física da v1.30.2 diante do vídeo `1000243628.mp4`.
- Confirmado: colisões atuais são entre corpos rígidos PMX; movimento secundário aplica molas às rotações dos ossos; dados Soft Body PMX 2.1 são preservados sem simulação; cache guarda poses de ossos, não estado do tecido.
- Criada especificação P0 para colisores corporais cinemáticos + simulação de roupa PBD/XPBD + bake determinístico, começando pela saia e pernas.
- **Esta nota não implementa física de tecido e não altera a versão 1.30.2.** Ver `docs/P0_Fisica_Roupas_Colisoes.md`.
