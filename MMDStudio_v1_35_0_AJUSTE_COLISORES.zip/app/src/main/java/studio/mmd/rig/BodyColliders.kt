package studio.mmd.rig

import studio.mmd.edit.Euler
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxRigid
import java.util.Collections
import java.util.WeakHashMap
import kotlin.math.sqrt

/**
 * v1.34.0 — colisores corporais gerados do esqueleto (P2 2.2). Lógica pura (sem Android).
 *
 * Problema: modelos sem corpos rígidos cinemáticos nas pernas/quadril deixam a saia (corpos rígidos dinâmicos) atravessar o corpo.
 * Aqui criamos cápsulas cinemáticas presas aos ossos (quadril, coxas, panturrilhas) que seguem a animação, com raio medido nos
 * vértices pesados ao osso. O motor ([PhysEngine]) as trata como corpos rígidos cinemáticos extras: não alteram o modelo, o PMX
 * salvo, nem a animação; só empurram corpos dinâmicos. Elementos que o próprio modelo já cobre (corpo cinemático preso ao mesmo osso) são pulados.
 */
class BodyCollider(
    val key: String, val label: String, val bone: Int,
    /** Raio e comprimento do trecho reto (distância entre os centros das pontas), em unidades MMD. */
    val radius: Float, val length: Float,
    /** Centro (mundo, pose de repouso) e rotação Euler (radianos, ordem do PMX) da cápsula. */
    val center: FloatArray, val rot: FloatArray,
    /** Raio vindo dos vértices (true) ou proporção do comprimento (false: poucos vértices). */
    val measured: Boolean
)

class BodyColliderPlan(val colliders: List<BodyCollider>, val covered: List<String>, val missing: List<String>, val group: Int) {
    /** Corpos rígidos cinemáticos (modo 0) equivalentes, prontos para o motor. */
    fun rigids(): List<PmxRigid> = colliders.map {
        PmxRigid(
            name = "BodyCollider:" + it.key, nameEn = "BodyCollider:" + it.key, bone = it.bone, group = group, shape = 2,
            mass = 1f, linearDamping = 0f, angularDamping = 0f, mode = 0, mask = 0,
            size = floatArrayOf(it.radius, it.length, 0f), pos = it.center.copyOf(), rot = it.rot.copyOf()
        )
    }

    val summary: String get() = when {
        colliders.isEmpty() && covered.isEmpty() -> "Esqueleto sem quadril/pernas reconhecíveis: nenhum colisor gerado."
        colliders.isEmpty() -> "O modelo já tem colisores em: ${covered.joinToString()}. Nada a gerar."
        else -> "${colliders.size} colisores gerados (${colliders.joinToString { it.label }})" +
            (if (covered.isNotEmpty()) "; já cobertos pelo modelo: ${covered.joinToString()}" else "") +
            (if (missing.isNotEmpty()) "; não encontrado: ${missing.joinToString()}" else "")
    }

    companion object { val EMPTY = BodyColliderPlan(emptyList(), emptyList(), emptyList(), 0) }
}

object BodyColliders {
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private val thighJp = setOf("足")
    private val kneeJp = setOf("ひざ", "膝")
    private val ankleJp = setOf("足首")
    private val pelvisJp = setOf("下半身")
    private val thighEn = setOf("thigh", "upperleg", "upleg", "legupper")
    private val kneeEn = setOf("knee", "calf", "shin", "lowerleg", "loleg", "leglower")
    private val ankleEn = setOf("ankle", "foot")

    private val enPrefix = Regex("^(left|right)[ _.\\-]?(.+)$")
    private val enSuffix = Regex("^(.+?)[ _.\\-](l|r|left|right)$")

    /** Nome inglês -> (núcleo sem lado, lado "E"/"D") ou null. */
    private fun enSplit(nameEn: String): Pair<String, String>? {
        val t = nameEn.trim().lowercase()
        enPrefix.matchEntire(t)?.let { return norm(it.groupValues[2]) to (if (it.groupValues[1] == "left") "E" else "D") }
        enSuffix.matchEntire(t)?.let { return norm(it.groupValues[1]) to (if (it.groupValues[2].startsWith("l")) "E" else "D") }
        return null
    }

    /** Classifica um osso como (papel, lado) ou null. Nomes IK, twist e variantes de deformação ("D") nunca casam. */
    internal fun roleOf(name: String, nameEn: String): Pair<String, String>? {
        val n = name.trim()
        val lower = (n + " " + nameEn).lowercase()
        if (n.endsWith("ＩＫ") || n.endsWith("IK") || Regex("(^|[ _.\\-])ik($|[ _.\\-])").containsMatchIn(lower) || lower.contains("twist") || n.contains("捩")) return null
        if (n.startsWith("左") || n.startsWith("右")) {
            val side = if (n.startsWith("左")) "E" else "D"
            val core = n.drop(1)
            if (core in thighJp) return "thigh" to side
            if (core in kneeJp) return "knee" to side
            if (core in ankleJp) return "ankle" to side
        }
        if (n in pelvisJp) return "pelvis" to ""
        val e = norm(nameEn)
        if (e == "lowerbody" || e == "pelvis" || e == "hips") return "pelvis" to ""
        val sp = enSplit(nameEn) ?: return null
        return when (sp.first) {
            in thighEn -> "thigh" to sp.second
            in kneeEn -> "knee" to sp.second
            in ankleEn -> "ankle" to sp.second
            else -> null
        }
    }

    private val cache: MutableMap<PmxModel, BodyColliderPlan> = Collections.synchronizedMap(WeakHashMap())

    /** Plano por modelo, em cache (o motor de física pergunta a cada criação do Animator). */
    fun plan(model: PmxModel): BodyColliderPlan = cache.getOrPut(model) { try { generate(model) } catch (_: Throwable) { BodyColliderPlan.EMPTY } }

    fun generate(model: PmxModel): BodyColliderPlan {
        val bones = model.bones
        // escolhe o primeiro osso de cada papel/lado (nomes duplicados: vale o de menor índice)
        val found = HashMap<String, Int>()
        for (i in bones.indices) { val r = roleOf(bones[i].name, bones[i].nameEn) ?: continue; found.putIfAbsent(r.first + "|" + r.second, i) }
        val covered = ArrayList<String>(); val missing = ArrayList<String>()
        val out = ArrayList<BodyCollider>()
        val kinBones = HashSet<Int>()
        for (r in model.rigidBodies) if (r.mode == 0 && r.bone in bones.indices) kinBones.add(r.bone)

        fun pos(i: Int) = floatArrayOf(bones[i].x, bones[i].y, bones[i].z)
        fun add(key: String, label: String, bone: Int, a: FloatArray, b: FloatArray, minR: Float, maxR: Float, fallbackR: Float) {
            if (bone in kinBones) { covered.add(label); return }
            val len = dist(a, b)
            if (len < 1e-3f) { missing.add(label); return }
            val m = measureRadius(model, bone, a, b)
            val radius = (m ?: fallbackR).coerceIn(minR, maxR)
            val center = floatArrayOf((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2)
            // cápsula do motor: trecho reto entre os centros das pontas; com as duas pontas (raio) cobre exatamente a→b
            val straight = (len - 2f * radius).coerceAtLeast(0f)
            out.add(BodyCollider(key, label, bone, radius, straight, center, alignY(b[0] - a[0], b[1] - a[1], b[2] - a[2]), m != null))
        }

        for (s in listOf("E" to "esq.", "D" to "dir.")) {
            val th = found["thigh|${s.first}"]; val kn = found["knee|${s.first}"]; val an = found["ankle|${s.first}"]
            if (th == null || kn == null) { missing.add("Coxa ${s.second}"); } else {
                val len = dist(pos(th), pos(kn))
                add("thigh_${s.first}", "Coxa ${s.second}", th, pos(th), pos(kn), len * 0.12f, len * 0.32f, len * 0.20f)
            }
            if (kn == null || an == null) { missing.add("Panturrilha ${s.second}") } else {
                val len = dist(pos(kn), pos(an))
                add("calf_${s.first}", "Panturrilha ${s.second}", kn, pos(kn), pos(an), len * 0.10f, len * 0.26f, len * 0.16f)
            }
        }
        // quadril: cápsula horizontal ligando as raízes das duas coxas, presa ao osso 下半身 (ou, na falta, ao pai da coxa)
        val tl = found["thigh|E"]; val tr = found["thigh|D"]
        if (tl != null && tr != null) {
            val bone = found["pelvis|"] ?: bones[tl].parent.takeIf { it in bones.indices } ?: tl
            val w = dist(pos(tl), pos(tr))
            // distância entre as raízes das coxas: o raio do quadril cobre a largura, mas as pontas já passam sobre as coxas
            add("pelvis", "Quadril", bone, pos(tl), pos(tr), w * 0.30f, w * 0.75f, w * 0.50f)
        } else missing.add("Quadril")

        val group = commonGroup(model, found.values)
        return BodyColliderPlan(out, covered, missing, group)
    }

    /** Grupo de colisão mais usado pelos corpos cinemáticos já ligados a ossos do corpo (herda o filtro do próprio modelo). */
    private fun commonGroup(model: PmxModel, bodyBones: Collection<Int>): Int {
        val set = bodyBones.toHashSet()
        val count = IntArray(16)
        for (r in model.rigidBodies) if (r.mode == 0 && r.bone in set && r.group in 0..15) count[r.group]++
        var best = 0; for (g in 1..15) if (count[g] > count[best]) best = g
        return best
    }

    private fun dist(a: FloatArray, b: FloatArray): Float {
        val x = a[0] - b[0]; val y = a[1] - b[1]; val z = a[2] - b[2]
        return sqrt(x * x + y * y + z * z)
    }

    /**
     * Mediana da distância ao eixo a→b dos vértices com peso dominante (> 0,5) no osso e projeção dentro do trecho.
     * Null com menos de 24 vértices (então usa-se a proporção do comprimento). Mediana: resiste a roupas largas ponderadas na perna.
     */
    internal fun measureRadius(model: PmxModel, bone: Int, a: FloatArray, b: FloatArray): Float? {
        val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]
        val l2 = dx * dx + dy * dy + dz * dz
        if (l2 < 1e-8f) return null
        val bi = model.boneIndices; val bw = model.boneWeights; val p = model.positions
        val nv = model.positions.size / 3
        if (bi.size < nv * 4 || bw.size < nv * 4) return null
        val ds = ArrayList<Float>()
        for (v in 0 until nv) {
            var w = 0f
            for (k in 0..3) if (bi[v * 4 + k] == bone) w += bw[v * 4 + k]
            if (w <= 0.5f) continue
            val rx = p[v * 3] - a[0]; val ry = p[v * 3 + 1] - a[1]; val rz = p[v * 3 + 2] - a[2]
            val t = (rx * dx + ry * dy + rz * dz) / l2
            if (t < 0.05f || t > 0.95f) continue
            val px = rx - dx * t; val py = ry - dy * t; val pz = rz - dz * t
            ds.add(sqrt(px * px + py * py + pz * pz))
        }
        if (ds.size < 24) return null
        ds.sort()
        return ds[ds.size / 2]
    }

    /** Euler (radianos, ordem do PMX) que leva o eixo Y local da cápsula até a direção dada (cápsula é simétrica: o sentido não importa). */
    internal fun alignY(dx: Float, dy: Float, dz: Float): FloatArray {
        val l = sqrt(dx * dx + dy * dy + dz * dz)
        if (l < 1e-6f) return floatArrayOf(0f, 0f, 0f)
        var x = dx / l; var y = dy / l; var z = dz / l
        if (y < 0f) { x = -x; y = -y; z = -z }          // usa o sentido +Y (equivalente para cápsula simétrica)
        if (y > 0.99999f) return floatArrayOf(0f, 0f, 0f)
        // arco mais curto de (0,1,0) até (x,y,z): eixo = (0,1,0)×d = (z, 0, -x); w = 1 + y
        var qx = z; var qy = 0f; var qz = -x; var qw = 1f + y
        val n = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
        qx /= n; qy /= n; qz /= n; qw /= n
        val e = Euler.euler(floatArrayOf(qx, qy, qz, qw))
        return floatArrayOf(Math.toRadians(e[0].toDouble()).toFloat(), Math.toRadians(e[1].toDouble()).toFloat(), Math.toRadians(e[2].toDouble()).toFloat())
    }
}
