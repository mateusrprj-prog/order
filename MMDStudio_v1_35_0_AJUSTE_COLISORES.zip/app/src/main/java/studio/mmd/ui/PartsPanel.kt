package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import studio.mmd.edit.Editor
import studio.mmd.rig.ModelPart
import studio.mmd.rig.PartAnalysis
import studio.mmd.rig.PartAssign
import studio.mmd.rig.PartCat
import studio.mmd.rig.PartElement
import studio.mmd.rig.PartKind
import studio.mmd.rig.PartLevel
import studio.mmd.rig.PartOverrides
import studio.mmd.rig.PartRecognizer
import studio.mmd.rig.Secondary

private fun levelColor(l: PartLevel) = when (l) {
    PartLevel.CONFIRMED -> Color(0xFF4CAF50)
    PartLevel.HIGH -> Color(0xFF8BC34A)
    PartLevel.MEDIUM -> Color(0xFFFFC107)
    PartLevel.LOW -> Color(0xFFFF9800)
    PartLevel.REVIEW -> Color(0xFFEF5350)
}

private class ActionsRow(val part: ModelPart)
private class EditorRow(val e: PartElement)

@Composable
private fun PartBtn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Text(text, color = if (enabled) Color.White else Color(0xFF5A5C62), fontSize = 11.sp, maxLines = 1,
        modifier = Modifier.padding(end = 6.dp).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled) { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp))
}

private fun kindLetter(k: PartKind) = when (k) { PartKind.BONE -> "O"; PartKind.MATERIAL -> "M"; PartKind.RIGID -> "C" }

private fun boneIndexOf(model: studio.mmd.mmd.PmxModel, e: PartElement): Int = when (e.kind) {
    PartKind.BONE -> e.index
    PartKind.RIGID -> model.rigidBodies.getOrNull(e.index)?.bone ?: -1
    PartKind.MATERIAL -> -1
}

/**
 * Aba "Partes" do painel Rig: lista as partes reconhecidas do personagem ativo com nível de confiança, deixa o usuário
 * confirmar, reclassificar, remover, dividir (lados / frente–trás) e ligar a física por parte. As correções ficam em
 * [PartOverrides] (por personagem, salvas no projeto) e prevalecem sobre o reconhecimento automático.
 */
@Composable
fun PartsView(
    ed: Editor, parts: PartOverrides, onParts: (PartOverrides) -> Unit,
    sec: List<Secondary>, onSec: (List<Secondary>) -> Unit,
    onSelBone: (Int) -> Unit, note: (String) -> Unit
) {
    val model = ed.model
    // a análise (pesos de vértices) é cara: roda uma vez por modelo, fora da thread de UI
    val state by produceState<Any?>(null, model) {
        value = null
        value = try { withContext(Dispatchers.Default) { PartRecognizer.analyze(model) } } catch (ex: Throwable) { "Erro ao analisar: ${ex.message ?: ex.javaClass.simpleName}" }
    }
    val st = state
    if (st == null) { Text("Analisando o modelo…", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(6.dp)); return }
    if (st is String) { Text(st, color = Color(0xFFFFC36A), fontSize = 12.sp, modifier = Modifier.padding(6.dp)); return }
    val analysis = st as PartAnalysis
    val report = remember(analysis, parts) { PartRecognizer.build(analysis, parts) }
    var expanded by remember(model) { mutableStateOf<String?>(null) }
    var editing by remember(model) { mutableStateOf<String?>(null) }
    var groupText by remember(model) { mutableStateOf("") }

    val rows = remember(report, expanded, editing) {
        val out = ArrayList<Any>()
        for (p in report.parts) {
            out.add(p)
            if (expanded == p.id) {
                out.add(ActionsRow(p))
                for (e in p.elements) { out.add(e); if (editing == e.key) out.add(EditorRow(e)) }
            }
        }
        out
    }

    Column(Modifier.fillMaxSize()) {
        Text(report.summary, color = Color.White, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            PartBtn("Aplicar física às partes") {
                val (list, msg) = PartRecognizer.applyToSecondary(model, report, sec)
                onSec(list); note(msg)
            }
            PartBtn("Restaurar tudo", enabled = !parts.isEmpty) { onParts(PartOverrides()); expanded = null; editing = null }
        }
        if (report.parts.isEmpty()) {
            Text("Nada reconhecido neste modelo. Elementos que você atribuir aparecem aqui.", color = Muted, fontSize = 12.sp)
        } else Text("Toque numa parte para ver ossos (O), materiais (M) e corpos rígidos (C). A confiança da parte é a do elemento mais incerto; o que você corrigir vira \"confirmada\" e nunca é sobrescrito pelo automático.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 4.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(rows) { r ->
                when (r) {
                    is ModelPart -> {
                        val open = expanded == r.id
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp).background(if (open) Color(0xFF23252A) else Color(0xFF1E2024), RoundedCornerShape(8.dp))
                            .clickable { expanded = if (open) null else r.id; editing = null }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.label, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val lv = r.level
                                Text("${lv.label}${if (lv != PartLevel.CONFIRMED) " ${(r.confidence * 100).toInt()}%" else ""} · ${r.bones.size} ossos · ${r.materials.size} mat. · ${r.rigids.size} corpos",
                                    color = if (r.category == PartCat.NONE) Muted else levelColor(lv), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (r.category != PartCat.NONE && r.category != PartCat.UNKNOWN) {
                                Text("Física", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(end = 4.dp))
                                Switch(checked = r.physics, onCheckedChange = { v -> onParts(parts.withPhysics(r.id, v)) })
                            }
                        }
                    }
                    is ActionsRow -> {
                        val p = r.part
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 8.dp, top = 4.dp)) {
                            PartBtn("Confirmar parte") { onParts(parts.withConfirmed(p.elements.map { it.key })) }
                            PartBtn("Dividir esq./dir.", enabled = p.category != PartCat.NONE) { onParts(PartRecognizer.splitPart(model, p, 0, parts)); expanded = null }
                            PartBtn("Dividir frente/trás", enabled = p.category != PartCat.NONE) { onParts(PartRecognizer.splitPart(model, p, 2, parts)); expanded = null }
                            PartBtn("Restaurar automático") { onParts(parts.without(p.elements.map { it.key })); expanded = null }
                        }
                        if (p.category != PartCat.NONE) {
                            Column(Modifier.fillMaxWidth().padding(start = 8.dp, top = 4.dp)) {
                                SearchBox(groupText, "Nome do grupo (ex.: Barra da saia)") { groupText = it }
                                val g = PartRecognizer.sanitizeGroup(groupText)
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
                                    PartBtn("Nomear grupo da parte inteira", enabled = g.isNotEmpty()) {
                                        onParts(parts.withAssign(p.elements.map { it.key }, PartAssign(p.category, g))); expanded = null
                                    }
                                    PartBtn("Tirar do grupo (parte inteira)", enabled = p.group.isNotEmpty()) {
                                        onParts(parts.withAssign(p.elements.map { it.key }, PartAssign(p.category, ""))); expanded = null
                                    }
                                }
                            }
                        }
                    }
                    is PartElement -> {
                        val open = editing == r.key
                        Row(Modifier.fillMaxWidth().padding(start = 12.dp).clickable { editing = if (open) null else r.key }.padding(vertical = 6.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(kindLetter(r.kind), color = Muted, fontSize = 11.sp, modifier = Modifier.width(18.dp))
                            Text(r.name.ifEmpty { "(sem nome)" }, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(if (r.manual || r.confirmed) "✓" else "${(r.confidence * 100).toInt()}%", color = levelColor(r.level), fontSize = 11.sp)
                        }
                    }
                    is EditorRow -> {
                        val e = r.e
                        Column(Modifier.fillMaxWidth().padding(start = 16.dp, bottom = 4.dp).background(Color(0xFF17181B), RoundedCornerShape(6.dp)).padding(8.dp)) {
                            Text("Por quê: " + e.evidence.joinToString("; ").ifEmpty { "sem indícios" }, color = Muted, fontSize = 10.sp)
                            if (e.alternatives.isNotEmpty()) Text("Também parece: " + e.alternatives.joinToString { PartCat.label(it) }, color = Color(0xFFFFC36A), fontSize = 10.sp)
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp)) {
                                val bi = boneIndexOf(model, e)
                                if (bi in model.bones.indices) PartBtn("Selecionar osso") { onSelBone(bi) }
                                PartBtn("Confirmar") { onParts(parts.withConfirmed(listOf(e.key))) }
                                PartBtn("Restaurar") { onParts(parts.without(listOf(e.key))) }
                                val g = PartRecognizer.sanitizeGroup(groupText)
                                if (g.isNotEmpty() && e.category != PartCat.NONE) PartBtn("Só este → grupo \"$g\"") { onParts(parts.withAssign(listOf(e.key), PartAssign(e.category, g))) }
                            }
                            Text("Mover para:", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (c in PartCat.choosable) {
                                    val sel = c == e.category
                                    Text(PartCat.label(c), color = if (sel) Color.White else Muted, fontSize = 11.sp, maxLines = 1,
                                        modifier = Modifier.background(if (sel) Accent else Color(0xFF26282D), RoundedCornerShape(6.dp))
                                            .clickable {
                                                val def = PartCat.def(c)
                                                val grp = if (def != null && def.sided) PartRecognizer.sideOf(e.name) else ""
                                                onParts(parts.withAssign(listOf(e.key), PartAssign(c, grp)))
                                            }.padding(horizontal = 10.dp, vertical = 5.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
