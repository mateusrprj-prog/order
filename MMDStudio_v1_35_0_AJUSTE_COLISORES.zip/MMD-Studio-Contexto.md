# MMD Studio — Contexto técnico da entrega v1.32.0

## Identificação
- Projeto: MMD Studio para Android, Kotlin + Jetpack Compose + OpenGL ES.
- Versão Gradle: **1.35.0** (`versionCode 77`).
- Base de trabalho: código-fonte v1.30.2 com integração de Scene/Transform e nota P0 de física de roupas já incorporadas.
- Objetivo da revisão: Outliner acessível como lista de cena e perfis independentes de rig/física para o personagem principal e cada personagem extra do Elenco, além de preservar a integração de Transformar da v1.30.2.

## Entrega v1.35.0 — ajuste de tamanho dos colisores
Slider por colisor (`PhysConfig.colliderScale`, 0,5–1,6), aplicado no `PhysEngine`; 28 testes JVM executados; APK/aparelho não validados.

## Entrega v1.34.0 — colisores corporais (P2 2.2)
Ver CHANGELOG. `rig/BodyColliders.kt` gera cápsulas de quadril/coxas/panturrilhas a partir do esqueleto (raio medido nos vértices), integradas ao `PhysEngine` como corpos cinemáticos extras; chave `PhysConfig.bodyColliders` (padrão desligada). 26 testes JVM executados (17 partes + 9 colisores); APK e aparelho NÃO validados.

## Entrega v1.33.0 — grupos de nome livre (ESCRITA, NÃO COMPILADA)
Na aba Partes agora há campo de nome de grupo: nomear a parte inteira, tirar do grupo ou mover só um elemento. Cada grupo é uma parte própria com chave de Física e grupo `part:<categoria>|<nome>` no movimento secundário. `sanitizeGroup` remove "|" e ":" e limita a 24 caracteres. Teste novo (17 no total), não executado. Pendente: destaque de materiais no viewport, colisores corporais, tecido.

## Entrega v1.32.0 — Editor de Partes do Modelo (P1 1.1/1.2) — ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO

### Por que esta fatia
O roadmap manda consolidar o fluxo Outliner → personagem → painel → edição real → salvar/reabrir (P0: implementado no código em 1.31.0, ainda sem build validado) e, em seguida, o **Editor de Partes**, porque a física de tecido/colisão corpo–saia (P2) não deve ser construída sobre grupos errados. Esta versão entrega o reconhecimento com confiança + correção manual persistente + ligação real com o movimento secundário.

### Implementado no código-fonte
1. `rig/PartRecognizer.kt` (lógica pura, sem Android)
   - `PartRecognizer.analyze(model)`: reconhecimento automático (caro; roda fora da UI). Sinais: nome do osso, nome do corpo rígido, corpo rígido dinâmico (só corrobora o que o nome já sugeriu), herança pela hierarquia, nome do material (teto 0,40: nunca "alta" sozinho) e pesos dos vértices por material (≥50% dos pesos em ossos de uma categoria). Confiança = 1 − Π(1 − força) das fontes que concordam, com penalidade quando outra categoria de OUTRA família concorre (ex.: "髪飾り"). Franja/cabelo/rabo são da mesma família (não conflitam).
   - Palavras ASCII curtas só casam como palavra inteira (`chair` não vira cabelo; `ponytail` não vira "tail"/cauda). Ossos-padrão do corpo nunca viram parte nem repassam categoria aos filhos.
   - `PartRecognizer.build(analysis, overrides)`: aplica as correções (barato) e agrupa em partes `categoria|grupo`. Confiança da parte = a do elemento mais incerto.
   - `PartOverrides` (assign por elemento, confirmed, physics por parte) + `PartOverridesIo` (JSON versionado, nunca lança). Chaves: `bone:<nome>`, `mat:<índice>:<nome>`, `rigid:<índice>:<nome>`; chave que não bate com o modelo atual é ignorada e contada como órfã.
   - `splitPart` (esq./dir. pelo eixo X, frente/trás pelo eixo Z; +X = esquerda do personagem, frente = −Z) e `applyToSecondary` (grupos `part:<id>`).
2. `rig/Constraints.kt`: `RigConfig.parts` (por personagem). `rig/CharacterRigProfile.kt`: campo opcional `parts` (formatVersion continua 1).
3. `project/Project.kt`: `loadParts/saveParts` (`parts.json`, escrita atômica; apaga o arquivo quando vazio).
4. `ui/PartsPanel.kt` (novo) + `ui/EditPanels.kt` (4ª sub-aba "Partes" em Rig) + `ui/SceneScreen.kt` (estado `partsMain`, carga/salvamento com debounce, snapshot do perfil dos extras com `parts`, painel Rig 310 dp).
5. Teste: `PartRecognizerTest` (16 casos).

### Como usar (após compilar)
Esqueleto → Rig → **Partes**. Escolha o personagem no Outliner antes (a aba edita o personagem ativo). Toque numa parte para ver ossos/materiais/corpos rígidos; toque num elemento para ver os indícios e movê-lo para outra categoria ou removê-lo. "Aplicar física às partes" cria os grupos em Secundário (aba vizinha), onde os sliders continuam valendo.

### Limites conhecidos (não afirmar o contrário)
- Destaque visual no viewport existe só para ossos ("Selecionar osso"); materiais ainda não são destacados.
- Não há colisão por parte, colisores corporais, tecido nem Soft Body: nada disso foi implementado.
- Uma parte só com materiais (sem ossos) não gera movimento secundário.
- Heurísticas de nomes cobrem os padrões JP/EN comuns; modelos com nomes genéricos dependem da correção manual e dos pesos.
- Testes JVM, build Android e teste no POCO X7 Pro NÃO executados.

### Próxima prioridade recomendada
1) Rodar o workflow de build e testar a aba Partes com 2–3 modelos PMX reais (nomes JP, nomes genéricos, sem corpos rígidos). 2) Destacar a parte selecionada no viewport (materiais). 3) Só então colisores corporais (P2 2.2).


---

# Histórico anterior (v1.31.0 e antes)

## Problema reproduzido no vídeo
O usuário importou um palco de música em Cena. O palco aparece na lista `Cenário e acessórios`, mas o seletor `Transformar → Alvo` mostrava apenas `Personagem principal` e personagens extras. Assim o palco não podia ser escolhido no painel de transformação. O vídeo também mostra que a aba Cena oferecia sliders X/Y/Z de posição e escala, sem oferecer o mesmo controle completo XYZ de rotação do painel Transformar.

## O que mudou em v1.30.2
1. `ui/SceneScreen.kt`
   - O seletor Transformar agora monta os alvos a partir de personagem principal (`model`), extras (`char:<id>`) e todos os itens importados de Cena (`prop:<id>`).
   - Ao clicar num item na lista Cena, o `layerSel` passa a apontar para esse `prop:<id>`. Selecionar no dropdown também atualiza o item selecionado na lista Cena.
   - `updateRootTransform()` agora sincroniza objetos `prop:` com o estado de transformação persistente e com `SceneGLView.setProp()`.
   - `applyRootTransformsAt()` aplica no quadro atual as transformações amostradas de cada objeto Cena, incluindo posição, rotação, escala e o vínculo opcional a osso. `setPropTransforms()` envia o conjunto em lote à thread GL. Isso alcança prévia e rotinas de captura/exportação que já usam o método.
   - Projetos existentes inicializam tracks ausentes com os valores antigos de `props.json`; as tracks são preservadas por ID.
   - Duplicar um prop duplica também sua track para um ID independente; remover um prop remove a track antiga.
   - `props.json` é sincronizado e salvo com debounce e no salvamento/fechamento do projeto.
2. `render/SceneGLView.kt`
   - Corrigido o caminho de renderização de props soltos: agora aplica `T * Ry * Rx * Rz * S`. Antes, a rotação só era aplicada no caminho de objetos anexados a ossos.
   - Objetos anexados continuam recebendo rotação local do osso e offset, sem mudar o sistema da câmera.
3. `ui/TransformPanel.kt`
   - Título e texto mudam conforme o alvo: personagem principal, personagem ou objeto da cena.
   - A UI deixa explícito que rotação XYZ, posição e escala pertencem ao item selecionado.
4. `ui/ScenePanel.kt` e `scene/RootTransform.kt`
   - Documentação interna atualizada para refletir o vínculo com o painel Transformar e o suporte de IDs `prop:<id>`.
5. `app/src/test/java/studio/mmd/RootTransformTest.kt`
   - Novo teste cobre transformação independente, keyframes, interpolação e codec para `prop:music-stage`.

## Como usar após instalar a versão compilada
1. Importe o palco em **Cena → + Adicionar**.
2. Toque no nome dele na lista **Cenário e acessórios** ou abra **Transformar**.
3. Em **Alvo**, escolha `Cena · <nome do objeto>`.
4. Ajuste rotação X/Y/Z nos campos numéricos (ou X/Y no controle circular), posição e escala.
5. Use Criar keyframe no quadro desejado para animar aquele objeto independentemente.

## Escopo e limites
- Inclui qualquer elemento importado que seja adicionado à lista Cena e renderizado pelo fluxo de `PropMeta`/`SceneGLView` (ex.: PMX, PMD, X, ZIP, GLB, glTF e OBJ, conforme o importador aceitar o arquivo).
- Cada item é transformado individualmente. Esta entrega **não** cria um controle global para girar todos os objetos/personagens da cena em conjunto.
- Luz e câmera continuam sendo alvos dos painéis próprios; não são `PropMeta` da lista Cena.
- O SceneGraph genérico legado ainda não substitui os dados reais de `PropMeta` nesta integração.
- Transformações de props são aplicadas na prévia/captura/exportação que já chama `applyRootTransformsAt()`. A conversão/bake destas tracks para arquivos VMD/GLB/FBX não faz parte desta entrega.

## Estado de validação
- Código-fonte alterado: SIM.
- ZIP criado e integridade testada: SIM (ver arquivo de entrega).
- Teste novo escrito: SIM.
- Testes JVM executados: NÃO.
- Build Android executado: NÃO.
- Teste no dispositivo: NÃO.

Motivo: este ambiente não contém Gradle, Gradle Wrapper ou Android SDK. O passo obrigatório seguinte é executar o workflow **Build Android APK** no GitHub Actions, corrigir eventuais erros de compilação e testar no POCO X7 Pro os critérios de aceitação descritos na nota v1.30.2 dos roadmaps.

## Histórico imediato
- **v1.30.1:** transformação da personagem inteira: rotação XYZ, posição, escala, painel circular, keyframes e persistência em `root_transforms.json`. Não compilada/testada neste ambiente.
- **v1.30.0:** navegação de viewport (orbit/pan/zoom/foco/gizmo); não compilada/testada neste ambiente.

## Nova prioridade P0 — física real de roupas/colisão corpo–tecido (20/11/2026)
Vídeo de referência: `1000243628.mp4`. Durante movimentos de dança com elevação/cruzamento das pernas, a saia não reage o suficiente e a perna atravessa visualmente a roupa.

Auditoria estática do código v1.30.2:
- `rig/Physics.kt`: `PhysEngine` simula rigid bodies/juntas PMX e colisões aproximadas entre rigid bodies; não há colisão entre vértices da roupa e superfície corporal.
- `rig/Constraints.kt`: `Secondary` é mola/amortecimento sobre rotações globais de ossos, não é simulação de tecido.
- `rig/AutoPhysics.kt`: reconhece grupos como saia/roupa/cabelo e cria grupos `Secondary`; não cria colisores nem tecido físico.
- `mmd/PmxModel.kt`: `softBodyCount`/`softBodyRaw` são dados PMX 2.1 preservados como bytes; o simulador não os interpreta.
- `rig/PhysCache.kt`: bake guarda pose de ossos, não estado por vértice de roupa.

Conclusão: não tentar resolver a saia apenas aumentando gravidade, rigidez ou atraso. O próximo sistema deve separar: (1) física MMD rígida existente; (2) colisores cinemáticos do corpo, inicialmente pelve/coxas/joelhos/panturrilhas; (3) solver de roupa PBD/XPBD com vértices, restrições, âncoras e colisão tecido–corpo. A roupa se afasta do corpo; o solver não altera o esqueleto nem os keyframes da perna. Incluir subpassos/anti-tunneling, cache determinístico, persistência e integração no render/export.

Ordem: P0-A debug e colisores; P0-B saia/roupa com colisão; P0-C bake/persistência/export; P1 interpretar PMX 2.1 Soft Body e melhorar detecção; P2 auto-colisão e qualidade avançada. Critérios completos em `docs/P0_Fisica_Roupas_Colisoes.md` e seção 13.11 do roadmap.

**Estado:** planejamento/especificação apenas; nenhuma física de tecido foi implementada e a versão continua 1.30.2. Não afirmar que as roupas já colidem com o corpo. Próximo build deve testar a saia com caminhada, chute frontal/lateral, pernas cruzadas e agachamento, comparando prévia, scrub, bake e exportação no POCO X7 Pro.


## Entrega v1.31.0 — Outliner + seleção e física por personagem

### Objetivo do usuário
A referência enviada em 20/11/2026 mostra o Outliner do Blender (Collection contendo Camera, Cube e Light). O problema relatado é não conseguir escolher separadamente qual modelo do Elenco está sendo editado nem manter configuração de física independente por personagem.

### Implementado no código-fonte
1. **Outliner no viewport**
   - `ui/SceneScreen.kt`: `layersOpen` inicia `true`; o painel permanece no canto superior direito do viewport e pode ser ocultado/reaberto pelo ícone Layers.
   - Lista: modelo principal, props importados em Cena, personagens extras do Elenco, luz, câmera e áudio.
   - A seleção de `model` ou `char:<id>` muda o personagem ativo e abre Esqueleto → Rig; grupo, visibilidade, bloqueio, renomeação e ordenação existentes foram preservados.
   - Props continuam selecionáveis e ligados a Cena/Transformar. Luz, câmera e áudio abrem seus painéis próprios; não recebem perfil de física de personagem.
   - É um Outliner mobile com lista e agrupamento do sistema atual, não a implementação integral do sistema de coleções/parenting do Blender.
2. **Perfil de rig e física por personagem extra**
   - Novo `rig/CharacterRigProfile.kt`: codec versionado para restrições, movimento secundário e `PhysConfig`.
   - `project/Project.kt`: salva em `cast/<id>.rig.json`, carrega com fallback seguro, exclui ao remover e copia ao duplicar personagem.
   - `SceneScreen.kt`: mantém mapa `castRigConfigs` por ID; abre o perfil correto ao selecionar um extra, passa valores para `SkeletonPanel`, salva ao editar, no salvar/fechar e ao exportar o projeto.
   - O principal segue usando `RigState.main` e os arquivos legados `rig.json`, `secondary.json` e `physics.json`, preservando compatibilidade.
3. **Renderer e ferramentas**
   - `render/SceneGLView.kt`: `addCharacter` recebe `RigConfig`; cada `CharacterInstance` mantém referência ao próprio perfil. `setCharacterRigConfig` atualiza somente o Animator daquele extra e reinicializa a dinâmica; a reconstrução de contexto GL reutiliza o perfil.
   - `mmd/Animator.kt`: `resetDynamics()` reinicia o estado temporal de movimento secundário/física sem compartilhar estado entre personagens.
   - `rig/Baker.kt`: `Baker.compute` aceita `RigConfig`; `PhysBake.run` já recebe o perfil em uso, agora chamado com o perfil ativo na UI.
   - `ui/EditPanels.kt`: cabeçalho exibe o dono do perfil e a subaba abre em “Física real”; os controles e bake recebem o `RigConfig` escolhido.
   - `ui/SceneScreen.kt`: selecionar em Outliner, tocar em personagem na viewport, ou usar “Editar este personagem” no painel Elenco escolhe o mesmo alvo de edição; selecionar “Editar personagem principal” volta ao perfil principal.
4. **Visibilidade de status**
   - O Outliner informa, por personagem, Física real ON/off e quantidade de grupos de movimento secundário.
   - O painel Rig mostra `CONFIGURAÇÃO DE RIG · <nome>`, para evitar editar o personagem errado sem perceber.
5. **Teste escrito**
   - `app/src/test/java/studio/mmd/CharacterRigProfileTest.kt`: três testes para round-trip, independência de instâncias e fallback para formato futuro.

### Como usar
1. Abrir a cena: o Outliner aparece por padrão no canto direito do viewport. O ícone de camadas no topo recolhe/mostra a lista.
2. Tocar no nome do personagem principal ou de um extra do Elenco. Esse personagem passa a ser o ativo e o painel de Esqueleto/Rig abre com o nome no cabeçalho.
3. Em Rig, selecionar Física real, ajustar os controles e/ou calcular o cache. Repetir para outro personagem: cada um mantém perfil independente.
4. Para trocar rapidamente, tocar em outro personagem no Outliner. Para voltar ao principal, tocar no item do modelo principal ou usar “Editar personagem principal” no painel Elenco.
5. Salvar/fechar ou exportar o projeto para manter os perfis; o cache de física continua transitório e precisa ser recalculado depois de reabrir.

### Escopo e limites
- Perfis independentes abrangem restrições, movimento secundário e controles de física rígida/juntas PMX. Isso não adiciona colisão de malha corpo–saia nem solver de tecido.
- `PhysCache` de cada personagem permanece apenas em memória, como o cache principal; o perfil de parâmetros é persistente.
- Perfis por personagem extra não mudam o comportamento do personagem principal nem o formato dos arquivos legados.
- Outliner usa entidades de cena atuais (`model`, `prop:<id>`, `char:<id>`, `light`, `camera`, `audio`). Não converte o SceneGraph legado em uma estrutura genérica de objetos totalmente editável.
- Não implementar “Física” em props/câmera/luz, pois o sistema de rig/física atual é relacionado a modelos de personagem PMX.

### Estado de validação
- Código-fonte alterado: SIM.
- Novo teste escrito: SIM (3 casos).
- Testes JVM executados: NÃO.
- Build Android executado: NÃO.
- Teste no dispositivo: NÃO.
- ZIP de entrega: `MMDStudio_v1_31_0_OUTLINER_FISICA_POR_PERSONAGEM.zip`.

Motivo da validação pendente: este ambiente não contém Gradle, Gradle Wrapper nem Android SDK. Executar **Build Android APK** no GitHub Actions e validar no POCO X7 Pro antes de considerar o recurso aprovado.

### Próximos passos P0
1. Confirmar Outliner e seleção do ativo em tela paisagem e retrato.
2. Importar pelo menos dois personagens extras; configurar gravidade, mola, amortecimento, vento, colisão e chão de forma diferente em cada um; alternar várias vezes e verificar que nada vaza entre perfis.
3. Salvar, fechar, reabrir e confirmar `cast/<id>.rig.json` para todos os extras.
4. Duplicar e excluir personagens; conferir cópia/exclusão do perfil sem alterar os demais.
5. Calcular cache para cada personagem e checar que o cache de outro modelo não é usado indevidamente.
6. Testar movimento secundário/bake em extras com e sem VMD e monitorar FPS/memória no aparelho.
7. Manter a P0 de colisão corpo–tecido como trabalho separado; a saia ainda pode atravessar pernas nesta versão.
