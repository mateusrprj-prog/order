# MMD Studio — Roadmap Master de Produção 3D, Animação, Motion Graphics e VFX
## Documento de direção técnica para Claude

**Base de trabalho:** `MMDStudio_v1_17_0.zip`  
**Referências visuais:** quatro vídeos enviados pelo usuário (`1000243160.mp4`, `1000243161.mp4`, `1000243162.mp4`, `1000243163.mp4`)  
**Plataforma-alvo:** Android, com prioridade para uso em aparelhos móveis  
**Regra principal:** evoluir o projeto existente. Não reescrever o app do zero e não substituir funcionalidades reais por telas demonstrativas.

---

# 1. Objetivo do projeto

Evoluir o MMD Studio de um editor de modelos/animação MMD para um **estúdio móvel de produção 3D, animação de personagens, motion graphics, VFX e composição cinematográfica**.

O aplicativo deve permitir criar projetos completos diretamente no Android, desde a montagem da cena e animação dos personagens até a composição dos efeitos e renderização final.

O objetivo não é copiar a interface ou o código de Blender, MMD, After Effects ou qualquer outro software. É construir sistemas próprios, adequados à arquitetura e às limitações do Android, mas com profundidade funcional de ferramenta de produção.

## Resultados que o app deverá conseguir produzir

1. Animações de personagens com corrida, saltos, perseguições, lutas coreografadas, poses e movimentos secundários.
2. Cenas com vários personagens independentes, cada um com rig, animação, materiais e transformações próprios.
3. Cenas estilizadas com cores fortes, formas geométricas, portais, corredores, painéis, objetos animados e câmeras dinâmicas.
4. Vídeos cinematográficos com cenários detalhados, iluminação dramática, close-ups, planos abertos, profundidade e efeitos.
5. Edições com textos, gráficos, máscaras, trilhas visuais, efeitos de impacto e sincronização com música.
6. Renderização final previsível, com qualidade e configurações controláveis, sem depender da aparência da prévia em tempo real.

---

# 2. Leitura das referências visuais

As referências devem ser tratadas como requisitos visuais, não como instruções para reproduzir personagens, marcas d'água, músicas ou obras protegidas.

## Referência 1 — `1000243160.mp4`

O vídeo apresenta uma cena estilizada de personagem 3D em movimento, com:
- personagem em escala pequena e depois em enquadramento próximo;
- corrida e poses de ação;
- cenário minimalista com planos e obstáculos geométricos;
- objetos grandes posicionados no caminho;
- efeito energético luminoso atravessando a cena;
- câmera que alterna entre leitura ampla da ação e acompanhamento mais próximo.

**Capacidades necessárias:** multiobjetos, animação corporal, root motion, obstáculos, VFX de energia, câmera animada, luz emissiva e composição de cena.

## Referência 2 — `1000243161.mp4`

O vídeo alterna entre uma apresentação de personagem/modelo em visual neutro e tomadas de ação cinematográfica em ambiente escuro.
Elementos observados:
- personagem humanoide com roupa e acessórios;
- visual de estudo/modelagem em tons neutros;
- mudança para cenas com iluminação baixa e fontes luminosas no ambiente;
- enquadramentos próximos e cortes de ação;
- sensação de movimento rápido, com desfoque e câmera dinâmica.

**Capacidades necessárias:** materiais, iluminação, ambiente, câmera, edição de planos, motion blur e pipeline de renderização.

## Referência 3 — `1000243162.mp4`

O vídeo mostra uma linguagem visual gráfica e estilizada:
- paleta muito saturada e contrastante;
- cenário geométrico e arquitetônico;
- grandes painéis e molduras coloridas;
- personagem estilizado em silhueta/alto contraste;
- elementos gráficos no espaço 3D;
- corredor com perspectiva forte;
- distorção/zoom radial e composição de impacto;
- textos de aviso integrados à composição.

**Capacidades necessárias:** materiais não realistas, paletas e color grading, objetos geométricos, texto no espaço 3D, deformações/distorções de imagem, câmera animada, composição e efeitos sincronizáveis.

## Referência 4 — `1000243163.mp4`

O vídeo contrasta o resultado final com a visão de trabalho de animadores:
- personagem robótico/estilizado em ambiente dramático;
- brilho intenso de uma fonte de energia;
- efeitos luminosos, rastros e linhas de movimento;
- planos próximos de partes do personagem e da ação;
- tomada ampla de cenário arquitetônico;
- visão de bastidores com vários rigs/personagens e controles visíveis;
- cena com escala ampla, na qual os personagens ocupam pequena parte do ambiente.

**Capacidades necessárias:** rigs e controles de animação, múltiplos personagens, organização de cena, cenários grandes, iluminação emissiva, VFX, câmeras com diferentes escalas de enquadramento e renderização cinematográfica.

## Conclusão das referências

Os vídeos não representam apenas “animação de osso”. Eles exigem quatro áreas integradas:

1. **Character Animation:** corpo, rosto, rig, IK, movimento e acting.
2. **Scene & Camera Direction:** personagens, objetos, cenários, luzes e câmeras.
3. **Motion Graphics & VFX:** formas, energia, partículas, rastros, textos e distorções.
4. **Compositing & Rendering:** planos, camadas, efeitos finais, áudio e exportação.

---

# 3. Auditoria de base: v1.17.0

A auditoria abaixo é estática, baseada no ZIP e no README/código-fonte. Não significa que o APK foi executado ou que o build foi validado nesta análise. Antes de alterar qualquer sistema, Claude deve confirmar o estado atual do repositório e executar os testes disponíveis.

## 3.1 Tecnologias e estrutura observadas

- Kotlin nativo e Jetpack Compose.
- OpenGL ES 3 com shaders GLSL ES 3.00.
- Parser e modelo PMX próprios.
- Importação PMX, PMD, X, GLB, glTF e OBJ.
- Importação de modelos soltos ou compactados em ZIP.
- Animator próprio, FK, IK e skinning na GPU.
- SDEF e QDEF no shader.
- Morphs de vértice, osso, UV e material.
- VMD para animação de ossos/morphs e leitura de câmera.
- Dope Sheet visual com seleção e arrasto de keyframes.
- Curvas Bézier e edição de keyframes.
- Física própria com passo fixo e cache/bake.
- Mocap por vídeo e retargeting.
- Constraints.
- Acessórios/objetos associados ao modelo.
- Áudio, exportação de mídia e exportadores GLB/FBX/VMD/VPD/PMX, conforme o estado de cada caminho.

## 3.2 Sistemas que já existem e devem ser preservados

| Área | Evidência na v1.17 | Diretriz |
|---|---|---|
| Importação PMX/PMD/X | Parsers próprios | Preservar e ampliar compatibilidade |
| Importação GLB/glTF/OBJ | `GlbParser` e `ObjParser` | Adicionar animações GLB sem quebrar malhas/texturas |
| Exportação PMX | `PmxWriter` | Preservar round-trip |
| Animator | `Animator.kt` | Evoluir sem duplicar motor |
| Skinning | GPU, SDEF e QDEF | Preservar caminhos já testados |
| Morphs | Vértice, osso, UV e material | Completar tipos e validar comportamento |
| Timeline | Dope Sheet e key editing | Evoluir para timeline multi-track |
| Câmera | Orbit camera e importação de câmera VMD | Criar câmera nativa animável |
| Luz | `LightCfg` com luz direcional e ajustes visuais | Expandir para sistema de luzes |
| Física | `Physics`, `AutoPhysics`, `Baker`, `PhysCache` | Expandir e manter determinismo |
| Mocap | `MocapEngine`, biblioteca e retargeting | Melhorar retarget e integração |
| Render | `SceneGLView.kt` | Evoluir de forma incremental |

## 3.3 Limitações explicitamente documentadas na v1.17

- Importação GLB/glTF ainda não importa animações embutidas.
- FBX e debug visual da física/cache no projeto foram listados como pendentes na documentação da versão.
- A câmera VMD pode ser importada/reproduzida, mas isso não é um editor nativo completo de câmera.
- A luz observada no código é uma configuração direcional (`LightCfg`), não um sistema completo de múltiplas luzes.
- A prévia OpenGL não equivale a um renderizador cinematográfico com composição e pós-processamento completo.
- O app possui áudio e exportação de mídia, mas não foi identificada uma suíte completa de composição multicamada de vídeo/VFX.
- A cena e o fluxo de edição ainda precisam ser avaliados para confirmar suporte real a múltiplas instâncias independentes de personagens, cada uma com Animator próprio.

**Não declarar recursos como concluídos apenas porque há uma aba, classe, botão, modelo de dados ou opção visual.** Validar o fluxo completo: criar/importar → editar → salvar → reabrir → reproduzir → exportar.

---

# 4. Arquitetura-alvo

O produto deve ter três ambientes de trabalho integrados, compartilhando o mesmo projeto, relógio, dados de cena e renderização.

## 4.1 Character Studio

Responsável por:
- importação e gerenciamento de personagens;
- rig e hierarquia de ossos;
- FK/IK e constraints;
- poses e biblioteca de poses;
- animação corporal;
- animação facial e morphs;
- camadas de animação;
- retargeting;
- física secundária;
- clips de animação.

## 4.2 Scene & Motion Studio

Responsável por:
- cena com várias instâncias de modelos;
- cenários, objetos e coleções;
- transformações de objetos;
- câmeras e cortes;
- luzes;
- materiais;
- caminhos e trajetórias;
- motion graphics 3D;
- organização e hierarquia da cena.

## 4.3 VFX & Compositor

Responsável por:
- camadas de vídeo/imagem/texto;
- máscaras;
- efeitos 2D e 3D;
- partículas;
- rastros e efeitos de energia;
- distorções;
- transições;
- color grading;
- composição de passes de render;
- áudio e sincronização.

## 4.4 Núcleo compartilhado obrigatório

Criar ou consolidar serviços compartilhados para:
- `Project/Scene Graph`: estado persistente da cena.
- `Animation Clock`: tempo e frame rate globais.
- `Animation Evaluation`: avaliação determinística de todos os canais.
- `Asset Registry`: modelos, texturas, vídeos, áudios, materiais e caches.
- `Render Graph`: dependências e ordem dos passes.
- `Undo/Redo`: comandos de edição de cena, timeline e compositor.
- `Serialization`: versão do projeto, migrações e validação.
- `Export Pipeline`: render por frame e codificação de mídia.

Os nomes acima são nomes conceituais. Reutilize nomes/estruturas existentes se já cumprirem a função. Não crie sistemas duplicados sem justificar.

---

# 5. Roadmap de desenvolvimento

## RELEASE 8 — Scene Graph & Multi-Character Foundation

> **PRIORIDADE P0 — fundação (nota de prioridades, 19/11/2026).** Scene Graph persistente, Outliner funcional e múltiplos personagens independentes bloqueiam câmeras, luzes, VFX e render. Tipo: implementação nova sobre base já escrita (8.1/8.2), precedida de auditoria.

**Prioridade: crítica**

### Objetivo
Transformar a cena de um único modelo editado em uma cena real com múltiplas instâncias independentes.

### Implementar
- Scene Graph hierárquico com nós.
- Tipos de nó: personagem, mesh/objeto, câmera, luz, grupo, áudio e efeito.
- Instâncias independentes de modelos.
- Animator independente por personagem.
- Transformação local e global.
- Parent/child para objetos presos a ossos ou a outros objetos.
- Outliner com seleção, ocultar, bloquear, renomear e agrupar.
- Duplicar, excluir, mover e reordenar nós.
- Salvar e restaurar todas as instâncias.
- Importação repetida do mesmo asset sem compartilhar estado mutável indevidamente.
- Seleção de personagem ativo sem interromper os demais.
- Reprodução simultânea com relógio global.

### Critérios de aceitação
- Uma cena contém ao menos três personagens diferentes.
- Cada personagem pode ter animação e pose próprias.
- Reproduzir a timeline atualiza todos simultaneamente.
- Transformar um personagem não modifica os outros.
- Salvar, fechar e reabrir preserva cena, hierarquia e animações.
- Não há vazamento de recursos OpenGL ao remover ou substituir instâncias.

---

## RELEASE 9 — GLB Animation Import & Animation System Pro

> **PRIORIDADE P0 (importação GLB, clips, relógio) + P0/P1 (ferramentas manuais).** Ordem interna: seleção/edição de keys, graph editor, easing, layers com pesos, IK de mãos/pés, foot lock básico e Root Motion = P0/P1; retargeting avançado, pole vectors e limites articulares = P2. Nunca destruir keyframes ao aplicar um clip (v1.24.0: troca de clip desfazível).

**Prioridade: crítica**

### Objetivo
Permitir usar animações externas e criar movimentos mais convincentes dentro do app.

### Importação GLB/glTF
- Ler animation samplers e channels.
- Suportar translation, rotation, scale e morph weights quando presentes.
- Interpolar STEP, LINEAR e CUBICSPLINE corretamente.
- Resolver nós/alvos por índice e hierarquia.
- Validar skin joints e inverse bind matrices.
- Tratar arquivos com várias animações.
- Exibir lista de clips importados.
- Não perder texturas, materiais ou skinning já suportados.
- Reportar canais incompatíveis sem falha silenciosa.

### Ferramentas de animação
- Animation Clips independentes.
- Trim de início/fim.
- Loop, ping-pong e retiming.
- Blend entre clips.
- Camadas de animação com pesos.
- Override e additive layers quando matematicamente apropriado.
- Root motion separado do movimento in-place.
- Retargeting entre esqueletos com mapeamento editável.
- Biblioteca de ciclos: idle, walk, run e outras ações genéricas.
- Foot lock/planting para reduzir deslizamento dos pés.
- IK de mãos e pés com alvos no espaço da cena.
- Controles de pole vector e limites articulares.
- Pose mirroring e pose library.
- Editor de curvas com tangentes e interpolação por canal.

### Critérios de aceitação
- Importar um GLB com pelo menos uma animação e reproduzi-la corretamente.
- Alternar clips sem saltos indevidos.
- Misturar dois clips com transição controlada.
- Root motion pode ser aplicado ou removido.
- Animação e pose permanecem corretas ao salvar/reabrir.
- Retargeting informa ossos sem correspondência e não os descarta silenciosamente.

---

## RELEASE 10 — Camera Director

> **PRIORIDADE P1** (estrutura básica de câmera como nó do Scene Graph antecipada em P0; follow/look-at, path, shake e cortes = P1). Depende de Scene Graph + Animation Clock.

**Prioridade: crítica**

### Objetivo
Transformar a câmera de visualização em um objeto de cena que possa ser dirigido e animado.

### Implementar
- Câmeras persistentes como nós do Scene Graph.
- Múltiplas câmeras por cena.
- Câmera ativa selecionável.
- Keyframes de posição, rotação, alvo e FOV.
- Perspectiva e ortográfica.
- Distância focal e parâmetros de lente.
- Look-at/target tracking.
- Follow camera com offset.
- Path camera com curva editável.
- Camera shake com intensidade, frequência, duração e seed.
- Dolly, pan, tilt, orbit, zoom e truck.
- Foco manual e foco em objeto.
- Depth of Field quando suportado pelo pipeline.
- Marcadores de corte e shot list na timeline.
- Transições entre câmeras.
- Preview da câmera ativa e safe frame.
- Importação VMD de câmera mantida como recurso adicional.

### Critérios de aceitação
- Criar duas câmeras e alternar entre elas por marcadores de corte.
- Animar posição, rotação e FOV com curvas.
- Fazer câmera seguir um personagem sem alterar sua animação.
- Salvar/reabrir mantendo câmeras, keyframes e cortes.
- Render final respeita a câmera e os cortes definidos.

---

## RELEASE 11 — Motion Graphics 3D

> **PRIORIDADE P1.** Primitivas, texto 3D, pivot/parent, keyframes e materiais unlit/emissive primeiro; paths/arrays = P1/P2. Depende de Scene Graph.

**Prioridade: alta**

### Objetivo
Permitir criar composições abstratas e gráficas dentro do espaço 3D, como as referências com corredores, painéis, molduras, formas e portais.

### Primitivas
- Cubo, esfera, plano, cilindro, cone, torus e linhas.
- Plano com subdivisão e malha simples editável.
- Texto 3D e texto billboard.
- Curvas e paths.
- Objetos importados como elementos de composição.

### Transformação e animação
- Keyframes de posição, rotação, escala e visibilidade.
- Pivot editável.
- Parent/child.
- Follow path.
- Look-at.
- Instancing para repetição eficiente.
- Arrays e distribuição em linha/radial.
- Deformadores simples: bend, twist, taper e wave, conforme viabilidade.
- Animação procedural baseada em tempo.
- Controles de parâmetros expostos na timeline.

### Aparência
- Materiais unlit/emissive.
- Paletas e presets de cores.
- Transparência e blend modes suportados.
- Contorno e estilos toon.
- Gradientes por shader quando viável.
- Controle de face/culling e double-sided.

### Critérios de aceitação
- Criar corredor com painéis e formas geométricas sem sair do app.
- Animar cada objeto individualmente ou em grupo.
- Duplicar centenas de instâncias sem criar centenas de draw calls desnecessárias.
- Salvar e reabrir todos os objetos e animações.

---

## RELEASE 12 — Lighting & Material Studio

> **PRIORIDADE P1.** Luzes direcionais/pontuais/spot, rim/emissive e PBR/toon básicos primeiro, com orçamento de desempenho; luz de área e técnicas caras = P3.

**Prioridade: alta**

### Objetivo
Sair de uma configuração de luz direcional única para uma iluminação de cena mais expressiva.

### Luzes
- Directional.
- Point.
- Spot.
- Área/emulação de área se o renderer permitir.
- Cor, intensidade, alcance, cone e atenuação.
- Sombras por luz com orçamento configurável.
- Luz emissiva em materiais.
- Luz de borda/rim light.
- Presets de iluminação.
- Controle de ambiente e exposição.

### Materiais
- PBR metallic/roughness.
- Base color, metallic, roughness, normal, AO e emissive.
- Texturas e UV sets.
- Toon/cel shading.
- Unlit e materiais gráficos.
- Transparência com modos documentados.
- Two-sided.
- Parâmetros animáveis quando apropriado.
- Compatibilidade com materiais PMX existentes.

### Critérios de aceitação
- Múltiplas luzes aparecem corretamente na prévia e no render.
- Materiais PBR e toon podem coexistir na mesma cena.
- Luzes e materiais são persistidos no projeto.
- O renderer mantém desempenho aceitável em cenas de teste no Android.
- Não quebrar aparência de modelos PMX que já funcionam.

---

## RELEASE 13 — VFX & Particle System

> **PRIORIDADE P1/P2 (VFX essenciais: trails, brilhos, anéis, afterimage, partículas determinísticas) e P2/P3 (distorções e pós-processamento).** Depende de relógio, cena e render estáveis; cada efeito com controle, custo previsível e opção de desligar.

**Prioridade: alta**

### Objetivo
Criar efeitos de energia, rastros, partículas, impactos e elementos atmosféricos usados nas referências.

### Partículas
- Emissor por ponto, área, cone e malha, conforme viabilidade.
- Spawn rate, lifetime, velocidade, direção, gravidade e tamanho.
- Cor ao longo da vida.
- Alpha e escala ao longo da vida.
- Random seed determinístico.
- Partículas em espaço local ou global.
- Orientação para câmera ou velocidade.
- Limites de partículas e orçamento de memória.
- Presets de poeira, faíscas, brilho, fumaça estilizada e energia abstrata.

### Efeitos de ação
- Trails/ribbons.
- Linhas de velocidade.
- Arcos de energia.
- Impact rings.
- Shockwave visual.
- Emissive pulse.
- Afterimage/ghost trail.
- Hit flash e flashes controlados.
- Efeitos ligados a osso, objeto ou trajetória.
- Spawn por evento de animação ou marcador da timeline.

### Distorções e pós-processamento
- Bloom.
- Vignette.
- Chromatic aberration com controle moderado.
- Radial blur/zoom blur.
- Distortion/heat haze.
- Color grading.
- Film grain opcional.
- Motion blur, preferencialmente como etapa separada e com fallback.
- Controle de intensidade e ordem dos efeitos.

### Segurança visual
- Evitar flashes intensos ou repetitivos por padrão.
- Fornecer controle para reduzir/desativar efeitos luminosos.
- Não usar flashes rápidos como preset padrão.
- Incluir avisos quando uma composição contiver efeitos piscantes.

### Critérios de aceitação
- Criar um efeito de energia que acompanha a mão de um personagem.
- Criar trail ligado a um objeto em movimento.
- Efeito é reproduzível em um frame específico e no render.
- Partículas usam seed e tempo determinísticos.
- Desativar VFX não altera a animação base.

---

## RELEASE 14 — VFX & Compositor 2D

> **PRIORIDADE P2.** Subsistema grande; só começar depois de existir saída de render 3D por frame confiável e pipeline de mídia validado.

**Prioridade: alta**

### Objetivo
Permitir finalizar edits com textos, gráficos, vídeos, imagens e efeitos sem depender de outro aplicativo.

### Timeline multicamada
- Trilhas de vídeo.
- Trilhas de imagem.
- Trilhas de texto.
- Trilhas de áudio.
- Trilhas de render 3D.
- Grupos e composição aninhada.
- In/out points.
- Trim, split, move, duplicate e ripple edit.
- Opacidade e transformações por keyframe.
- Sincronização por frame.
- Preview de composição.

### Máscaras e composição
- Máscara retangular, elíptica e path quando viável.
- Feather, expansão e inversão.
- Alpha compositing.
- Blend modes implementados e documentados.
- Chroma key como etapa posterior se houver desempenho.
- Camadas de adjustment/effect.
- Texto com fontes, tracking, alinhamento e animação.
- Revelação por palavra/letra.
- Contorno, sombra e preenchimento.
- Elementos gráficos vetoriais básicos.

### Integração com 3D
- Renderizar cena 3D como uma fonte de camada.
- Render passes: color, depth, normal, object ID e alpha, conforme suportado.
- Compor múltiplos passes.
- Sobrepor texto, gráficos e efeitos 2D ao render 3D.
- Preservar transparência quando o formato permitir.

### Critérios de aceitação
- Montar uma composição com render 3D, texto, imagem, duas trilhas de áudio e efeitos.
- Fazer trim e keyframes por camada.
- Salvar/reabrir sem perder sincronização.
- Exportar a composição final com duração e frame rate corretos.

---

## RELEASE 15 — Facial Animation & Character Acting

> **PRIORIDADE P1/P2 (morphs faciais existentes, expressões salvas, piscar/olhar) e P2 (lip sync, visemas, retargeting facial).** Não presumir o mesmo rig facial em todos os modelos.

**Prioridade: média-alta**

### Objetivo
Aumentar a expressividade dos personagens.

### Implementar
- Painel facial por morph/shape key.
- Grupos de expressões.
- Bibliotecas de expressões.
- Piscar automático configurável.
- Direção dos olhos e alvo de olhar.
- Controle de sobrancelha, boca e mandíbula quando o rig oferecer suporte.
- Lip sync por áudio em modo básico.
- Timeline de fonemas/visemas quando houver dados suficientes.
- Expressões como clips combináveis com animação corporal.
- Retarget de expressões apenas quando houver mapeamento explícito.

### Critérios de aceitação
- Criar e salvar uma expressão composta.
- Animar olhos e expressões independentemente do corpo.
- Sincronizar abertura da boca com uma faixa de áudio em modo básico.
- Modelos sem morph facial continuam funcionando sem erros.

---

## RELEASE 16 — Cinematic Render & Export Pipeline

> **PRIORIDADE P0/P1 para o caminho BÁSICO (render por frame com estado real da cena + Animation Clock, vídeo/PNG, áudio por timestamp, progresso e cancelamento) — antecipado como infraestrutura, validar cedo; P2/P3 para qualidade cinematográfica (DoF, motion blur, grain, aberração cromática etc.).**

**Prioridade: crítica para entrega final**

### Objetivo
Garantir que a qualidade do vídeo exportado corresponda ao que foi montado na cena.

### Renderização
- Render por frame, não captura improvisada da prévia.
- Frame rate configurável.
- Resolução configurável.
- Render em lotes.
- Barra de progresso real.
- Cancelar e retomar render quando possível.
- Persistência de estado de render.
- Reprocessamento de frames com falha.
- Presets de qualidade.
- Gestão de memória e limpeza de recursos.
- Render offline determinístico para física e partículas.
- Motion blur e depth of field no render final quando habilitados.
- Render passes para compositor.
- Supersampling/anti-aliasing conforme capacidade do dispositivo.

### Exportação
- MP4 com encoder Android suportado.
- PNG sequence.
- WAV/AAC conforme pipeline.
- Áudio sincronizado por timestamp/frame.
- Metadados de frame rate e duração.
- Relatório de erros e frames faltantes.
- Exportação em segundo plano quando o Android permitir.
- Limite de memória e espaço livre verificados antes do render.

### Critérios de aceitação
- O mesmo frame exportado em execuções repetidas tem resultado consistente, salvo fontes explicitamente aleatórias.
- A duração final corresponde ao intervalo da timeline.
- O áudio não deriva progressivamente do vídeo.
- Render pode ser cancelado sem corromper o projeto.
- Falhas são reportadas e não apresentadas como exportação bem-sucedida.

---

# 6. Melhorias transversais obrigatórias

> **PRIORIDADE P0 — transversal a todas as fases** (autosave/recuperação/migração, memória CPU/GPU, recuperação de contexto GL, testes em aparelho real).

## 6.1 Projeto e persistência
- Versionar o formato do projeto.
- Migrações automáticas e testadas.
- Salvar Scene Graph, instâncias, câmeras, luzes, materiais, animações, efeitos e compositor.
- Referências a assets com caminhos internos estáveis.
- Verificar assets ausentes ao abrir projeto.
- Autosave e recuperação de sessão.
- Backup antes de migrações destrutivas.

## 6.2 UX mobile
- Interface adaptada para tela vertical e horizontal.
- Painéis recolhíveis.
- Controles touch para viewport.
- Gizmos de mover, girar e escalar.
- Seleção por toque e Outliner.
- Gestos de timeline sem conflito com scroll.
- Ferramentas acessíveis sem ocupar a viewport inteira.
- Modo de desempenho para aparelhos móveis.
- Não criar controles decorativos ou botões sem ação.

## 6.3 Desempenho Android
- Perfil de memória CPU/GPU.
- LOD para modelos e cenários grandes.
- Frustum culling.
- Instancing.
- Cache de shaders.
- Upload assíncrono de assets.
- Compressão de texturas apropriada ao hardware.
- Limite configurável de partículas.
- Redução adaptativa da qualidade da prévia.
- Render final separado da qualidade da viewport.
- Tratar perda/recuperação do contexto OpenGL.
- Liberar buffers, texturas, framebuffers e programas ao remover recursos.

## 6.4 Qualidade e testes
- Testes unitários para parsers e interpolação.
- Testes de serialização e migração de projeto.
- Testes determinísticos do Animation Clock.
- Testes de round-trip para formatos suportados.
- Testes de cenas com 1, 2, 3 e mais personagens.
- Testes de câmera e cortes.
- Testes de física e bake.
- Testes de render por frame.
- Testes de exportação com áudio.
- Testes em aparelho Android real, além de testes JVM.
- Testes de arquivos corrompidos, grandes e incompletos.

---

# 7. Sequência recomendada e dependências

A ordem deve respeitar as dependências técnicas. Não iniciar um compositor completo antes de existir uma fonte de render de cena confiável.

| Ordem | Release | Dependência principal |
|---:|---|---|
| 1 | 8 — Scene Graph & Multi-Character | Projeto/persistência |
| 2 | 9 — GLB Animation & Animation Pro | Scene Graph + Animator |
| 3 | 10 — Camera Director | Scene Graph + Animation Clock |
| 4 | 11 — Motion Graphics 3D | Scene Graph + transform animation |
| 5 | 12 — Lighting & Material Studio | Render Graph |
| 6 | 13 — VFX & Particles | Render Graph + Animation Clock |
| 7 | 14 — VFX & Compositor 2D | Render por frame + fontes 3D |
| 8 | 15 — Facial Animation | Animation System Pro |
| 9 | 16 — Cinematic Render & Export | Sistemas anteriores integrados |

As releases podem ser divididas em fatias menores. A numeração não exige que cada release seja entregue em um único commit.

---

# 8. Regras obrigatórias para Claude

## Antes de programar
1. Ler o projeto inteiro e identificar a arquitetura real da branch atual.
2. Comparar a branch atual com a base v1.17.0; não presumir que o ZIP ainda representa o HEAD.
3. Identificar os arquivos e classes existentes para cada sistema.
4. Criar um mapa de dependências e riscos.
5. Verificar testes existentes e executar a suíte antes de mudanças.
6. Não assumir que algo está ausente sem procurar no código; não assumir que algo funciona só porque existe uma classe.

## Durante a implementação
1. Implementar em fatias pequenas e compiláveis.
2. Reutilizar Animator, SceneGLView, ProjectStore e modelos existentes quando adequados.
3. Não duplicar motores de animação, relógios ou renderizadores.
4. Não reescrever parsers estáveis sem necessidade.
5. Não remover recursos MMD para priorizar recursos novos.
6. Não adicionar botões, abas ou sliders que não estejam conectados a operações reais.
7. Não usar dados falsos para simular múltiplos personagens, câmeras, luzes ou partículas.
8. Não afirmar suporte a um formato sem testar arquivos reais representativos.
9. Não deixar TODO como se fosse implementação concluída.
10. Considerar o desempenho e a memória do Android desde o primeiro commit.

## Para cada entrega
Informar:
- objetivo da fatia;
- arquivos criados/alterados;
- arquitetura escolhida;
- comportamento implementado;
- limitações ainda existentes;
- testes executados e resultados;
- comando de build usado e resultado;
- passos para testar no aparelho;
- riscos e próxima fatia.

## Critério de conclusão
Uma funcionalidade só pode ser marcada como concluída quando:
1. Pode ser criada ou importada pela UI.
2. Pode ser editada e visualizada.
3. É salva no projeto.
4. Continua correta após fechar e reabrir.
5. É avaliada corretamente na timeline.
6. Aparece corretamente no render/exportação quando aplicável.
7. Tem testes automatizados ou roteiro manual reproduzível.

---

# 9. Primeira tarefa para Claude

**Não implemente todas as releases de uma vez.**

Comece pela seguinte tarefa:

### Fase A — Auditoria atualizada
- Auditar a branch atual e confirmar a versão real.
- Mapear `Project.kt`, `SceneScreen.kt`, `SceneGLView.kt`, `Animator.kt`, `Editor.kt`, `DopeSheet.kt`, parsers, exportadores e testes.
- Determinar se a arquitetura atual suporta múltiplas instâncias independentes de personagens.
- Determinar como o estado de câmera é armazenado e se pode ser convertido em nó persistente.
- Determinar o estado real da importação de animações GLB.
- Determinar o caminho atual de renderização e exportação por frame.
- Identificar limitações de OpenGL ES e memória no Android.
- Executar testes e build disponíveis antes de alterar código.

### Fase B — Plano de implementação da Release 8
Apresentar:
- modelo de dados proposto para Scene Graph;
- estratégia de instâncias independentes;
- integração com ProjectStore;
- estratégia para não duplicar Animator;
- mudanças mínimas necessárias na UI/Outliner;
- plano de testes;
- arquivos que serão modificados.

### Fase C — Implementação incremental
Após a auditoria, implementar a primeira fatia funcional da Release 8. Não avançar para releases seguintes até que a cena multi-instância esteja persistente, reproduzível e testada.

---

# 10. Cenário de validação final

Usar um projeto de teste original com:
- três personagens 3D diferentes;
- ao menos dois personagens com rigs distintos;
- um cenário arquitetônico;
- obstáculos e painéis geométricos;
- uma câmera ampla e uma câmera de close;
- duas luzes de cores diferentes;
- uma animação de corrida/perseguição;
- um efeito de energia preso a um personagem;
- partículas e rastros;
- texto gráfico em uma camada do compositor;
- trilha de áudio original ou de teste.

O teste deve permitir:
1. montar a cena;
2. animar os personagens separadamente;
3. importar e retargetear um clip;
4. criar câmeras e cortes;
5. animar objetos geométricos;
6. criar e controlar VFX;
7. compor texto e camadas;
8. salvar e reabrir o projeto;
9. renderizar a sequência;
10. verificar sincronização, qualidade e estabilidade.

## Definição de sucesso do projeto

O MMD Studio será considerado um estúdio de produção funcional quando o usuário conseguir criar e exportar uma sequência completa como a das referências **sem precisar montar a cena em outro software** para suprir as funções centrais descritas neste roadmap.

Isso não significa que cada efeito avançado precisa existir desde a primeira release. Significa que a arquitetura deve permitir adicioná-los sem refazer o núcleo a cada ciclo.

---

# 11. Registro de progresso (atualizado a cada fatia)

> Regra: este registro é alterado a cada fatia entregue. Nada é marcado como concluído sem build + teste no aparelho confirmados pelo usuário.

## Fase A — Auditoria (feita sobre o ZIP v1.17.0; build NÃO executado)

**Ambiente:** sem Gradle/Kotlin/JDK e sem rede neste ambiente. Build e testes JVM não puderam ser rodados; tudo abaixo é leitura estática do código.

**Respostas às perguntas da Fase A:**

| Pergunta | Achado (arquivo) |
|---|---|
| Versão real | v1.17.0 (README). HEAD do repositório não foi comparado: só existe o ZIP. |
| Suporta várias instâncias independentes? | **Não.** `SceneRenderer` (em `SceneGLView.kt`) guarda UM `model: GlModel?`, UM `animator: Animator?` e UM `curMotion`. `loadModel()` chama `freeModel()` e substitui o modelo. |
| O que são os "props"? | `PmxModel` estáticos (classe `Prop`), sem Animator próprio, só x/y/z/escala, com opção de prender a um osso do modelo principal. Servem de base para o Scene Graph, mas não são personagens. |
| Editor | `Editor.kt` (863 linhas) edita um único modelo. A UI (`SceneScreen.kt`, ~959 linhas) mantém estado local com `remember` (um `editor`, `props`, `camMotion`, `lightCfg`). |
| Persistência | `ProjectMeta` (id, nome, aspecto, resolução, fps, fundo, frames) + arquivos soltos: `model.*`, `animacao.vmd`, props (`saveProps`), rig, secondary. `FORMAT_VERSION = 1`. Não há nós de cena nem hierarquia persistida. |
| Câmera | `OrbitCamera` (yaw/pitch/dist/alvo) é só de visualização e não é salva. Há uma única `vmdCam` (importada de VMD). Não é nó persistente. |
| Luz | Uma `LightCfg` direcional, guardada em SharedPreferences (não no projeto). |
| Outliner | `Outliner.kt`/`LayersPanel`: lista plana derivada do estado (modelo, props, luz, câmera, áudio). Só seleciona e oculta; sem renomear, agrupar, reordenar, duplicar. |
| GLB: animações | Não importadas (confirmado no README v1.14.0; `GlbParser.kt` 354 linhas). |
| Render/export por frame | Existe `captureAwait(frame)` no GL + `MediaExport.kt`/`AudioMux.kt`. Renderiza a cena atual, sem câmeras/cortes. |
| Testes | `ParserTest`, `ImportTest`, `KeyEditTest` (JVM). Nada para cena, câmera ou clock. |

**Riscos principais para a Release 8**
1. `SceneRenderer` está acoplado a um único modelo (GlModel, Animator, boneTex, matLive, estado de morph/sombra). Multi-instância exige extrair esse estado para uma classe por instância.
2. `Editor` e `SceneScreen` assumem um modelo ativo; é preciso um conceito de "instância ativa".
3. Memória/GL: cada instância tem VBO/IBO/texturas/textura de ossos; liberar na remoção (critério de aceite).
4. Projetos antigos (formatVersion 1) precisam migrar para o novo formato sem perda.

## Fase B — Plano da Release 8 (proposto, aguardando OK)

**Modelo de dados (novo `scene/SceneGraph.kt`, Kotlin puro, testável em JVM)**
- `SceneNode(id, name, type, parentId, visible, locked, local: Transform)`; tipos iniciais: `CHARACTER`, `PROP`, `GROUP` (CAMERA/LIGHT/AUDIO/EFFECT reservados para as releases seguintes).
- `Transform(pos, rotEuler, scale)` + cálculo de matriz global pela hierarquia.
- `CharacterData(assetFile, motionFile, ...)` por nó `CHARACTER`; `PropData` reaproveita `PropMeta`.
- Serialização em `scene.json` dentro da pasta do projeto, com `formatVersion` 2.

**Migração:** ao abrir projeto v1, criar `scene.json` com um nó `CHARACTER` (modelo principal) e nós `PROP` a partir de `props`. Backup de `project.json` antes de migrar.

**Instâncias independentes / sem duplicar Animator:** extrair do `SceneRenderer` uma classe `CharacterInstance` (GlModel, `Animator`, boneTex, morphs, matLive, motion). O renderer passa a manter `Map<nodeId, CharacterInstance>`. A classe `Animator` é reutilizada sem alteração, uma instância por personagem. Relógio único: `renderer.frame`.

**Integração com ProjectStore:** `ProjectStore.saveScene/loadScene` (escrita atômica, como `write()` já faz). `props`, `rig` e `secondary` continuam funcionando, migrando por nó em fatias posteriores.

**UI mínima:** Outliner passa a ler o Scene Graph (renomear, ocultar, bloquear, duplicar, excluir, personagem ativo). Sem controles novos além desses.

**Fatiamento (uma por vez, cada uma compilável):**
1. **8.1** `SceneGraph.kt` + serialização + migração v1→v2 + testes JVM (sem tocar na UI/GL).
2. **8.2** `CharacterInstance` extraída do renderer, ainda com 1 personagem (refatoração sem mudança de comportamento).
3. **8.3** Adicionar/remover 2º e 3º personagem, personagem ativo, reprodução simultânea.
4. **8.4** Outliner funcional (renomear, agrupar, duplicar, reordenar) + parent/child a ossos.

**Arquivos previstos em 8.1:** novos `scene/SceneGraph.kt`, `scene/SceneSerializer.kt`, `test/.../SceneGraphTest.kt`; alterado `project/Project.kt` (saveScene/loadScene, FORMAT_VERSION).

**Plano de testes 8.1:** hierarquia e matriz global; ciclo de pai inválido rejeitado; round-trip JSON; migração de projeto v1; arquivo corrompido.

**Estado:** Fase A concluída (estática). Fase B proposta. Fase C iniciada: 8.1 e 8.2 escritas (não compiladas/testadas).

## Correção ao plano (achada ao implementar 8.1)
O arquivo `scene.json` JÁ EXISTE na v1.17.0 e guarda só a lista de props (`ProjectStore.saveProps`). O plano dizia usar `scene.json` para o Scene Graph; isso sobrescreveria os props. **Decisão:** o grafo fica em `scenegraph.json` (versão própria dentro do arquivo). O `FORMAT_VERSION` do `project.json` NÃO foi aumentado nesta fatia, porque nada novo é gravado pela UI ainda; sobe na 8.3, quando o app passar a gravar o grafo.

## Fatia 8.1 — Scene Graph + serialização + migração (v1.18.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** base de dados da cena multi-instância, sem tocar UI nem OpenGL.

**Arquivos novos:** `scene/SceneGraph.kt`, `scene/SceneSerializer.kt`, `test/.../SceneGraphTest.kt`.
**Arquivos alterados:** `project/Project.kt` (`loadScene`, `saveScene`, `loadOrMigrateScene`), `build.gradle.kts` (versão 1.18.0, versionCode 41), `README.md`.

**Comportamento implementado**
- `SceneGraph` imutável (cada edição devolve um novo grafo, pronto para undo/redo). Tipos de nó: CHARACTER, PROP, GROUP, CAMERA, LIGHT, AUDIO, EFFECT (os quatro últimos só reservados).
- Operações: add, remove (com descendentes), rename, visível/trancado (herdados dos pais), setTransform (recusa nó trancado), personagem ativo, reparent (recusa ciclo, pai inexistente e osso em pai que não é personagem), move entre irmãos, agrupar, duplicar subárvore com ids novos.
- `Transform` (posição, rotação em graus, escala por eixo) e matriz global pela hierarquia (4x4 coluna-principal).
- `scenegraph.json`: leitura recusa JSON quebrado/sem versão/versão mais nova; danos parciais (id duplicado, tipo desconhecido, pai inexistente, ciclo, ativo inválido) viram **avisos**, não perda silenciosa.
- Migração v1: `SceneGraph.fromLegacy` + `ProjectStore.loadOrMigrateScene` (cria `project.v1.json.bak` uma vez, não altera o `scene.json` antigo). Props presos a osso viram filhos do personagem principal com `attachBone`.

**Limitações**
- Nada usa o grafo ainda: UI, Outliner e renderer seguem com um modelo só.
- A matriz do osso (`attachBone`) será resolvida pelo renderer na 8.2/8.4; `globalMatrix` ignora o osso.
- `reparent` mantém a matriz local (não compensa a global).
- Sem controle de assets órfãos ao remover nó (arquivos do projeto não são apagados).

**Testes:** 15 testes em `SceneGraphTest` escritos; **não executados** (sem Gradle/Kotlin aqui). Build não executado.
**Para testar:** `gradle testDebugUnitTest` (ou push no GitHub e ver o Actions). Reportar o log de erro de compilação, se houver. Nenhum teste de aparelho nesta fatia, pois não há mudança visível.
**Riscos:** erros de compilação Kotlin (escrito às cegas); o contrato de `GraphResult` e o uso de `ArrayDeque`/smart casts são os pontos a olhar primeiro.
**Próxima fatia:** 8.2 — extrair `CharacterInstance` do `SceneRenderer`, ainda com 1 personagem.

## Fatia 8.2 — CharacterInstance extraído (v1.19.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** extrair o estado GL + Animator de um personagem do `SceneRenderer` para uma classe interna, ainda com 1 personagem. Refatoração sem mudança de comportamento; prepara a fatia 8.3.

**Arquivos alterados:** `render/SceneGLView.kt` (classe interna `CharacterInstance` + uso de `mainChar`), `app/build.gradle.kts` (versão 1.19.0, versionCode 42), `README.md`.

**Comportamento implementado**
- `CharacterInstance` (inner class de `SceneRenderer`) guarda: `gl` (GlModel), `animator`, `boneTex`/`boneCount`/`boneRows`/`boneBuf`, flags de morph de posição/UV, `matLive`/`matLiveOn`, buffers do esqueleto (`bonePos`/`boneParent`/`boneVis`/`line*`/`pt*`), `lastModel`/`lastTex`/`curMotion`, `shBone`, `boneIdx`.
- O renderer mantém um único `mainChar`. `loadModel`, `setMotion`, `freeModel`, `updateSkin`, `drawBones`, `pick`, `dragBone`, restore de contexto e desenho de props presos a osso passam a usar `mainChar.*`.
- API pública de `SceneGLView` inalterada; UI não muda.

**Limitações**
- Ainda só um personagem. Não há mapa de instâncias nem personagem ativo.
- Nada de UI nova. O Scene Graph (8.1) continua sem ser lido pelo renderer.

**Testes:** nenhum novo (refatoração pura). Build não executado (sem Gradle/Kotlin aqui).
**Para testar:** push no GitHub e ver o Actions; instalar o APK e confirmar que o modelo carrega, anima, esqueleto, toque e arrasto continuam iguais. Reportar log de compilação se falhar.
**Riscos:** erro de compilação por campo não reescrito ou acesso a campo movido; ponto principal a olhar é `SceneGLView.kt` (CharacterInstance + mainChar).
**Próxima fatia:** 8.3 — adicionar/remover 2º e 3º personagem, personagem ativo, reprodução simultânea.

## Verificação da fatia 8.1 (19/11/2026, sem mudar código do app)
Compilei de verdade `scene/SceneGraph.kt` + `scene/SceneSerializer.kt` + `SceneGraphTest.kt` com o compilador Kotlin 2.0.21 (JVM) e rodei no JUnit 4.13.2: **0 erros de compilação, 15/15 testes passaram.** Ressalvas: `org.json` foi substituído por um stub mínimo (o real só existe no Android/Gradle) e `PropMeta` por uma cópia idêntica; o resto do app (Compose, OpenGL) NÃO foi compilado aqui. A fatia 8.2 (`SceneGLView.kt`) continua sem compilar. Status: 8.1 = lógica verificada em JVM; ainda falta build no Actions e teste no aparelho.

## Fatia 9.1 — Amostrador de animação glTF (v1.20.0) — LÓGICA VERIFICADA EM JVM; app NÃO compilado
**Objetivo:** base matemática da importação de animações GLB (Release 9): interpolação STEP, LINEAR (com slerp pelo caminho mais curto para quaternions) e CUBICSPLINE (Hermite com tangentes escaladas por dt; rotação normalizada).
**Arquivos novos:** `mmd/GltfSampler.kt`, `test/.../GltfSamplerTest.kt`. **Alterado:** `build.gradle.kts` (1.20.0 / versionCode 43).
**Verificação:** compilado com kotlinc 2.0.21 e executado no JUnit: 7/7 testes OK (linear/clamp, step, slerp, caminho curto, cubic, normalização, dados inválidos recusados).
**Limitações:** ainda NÃO ligado ao `GlbParser` (que continua avisando que animações não são importadas), sem clips, sem UI. Nada muda para o usuário.
**Para testar:** `gradle testDebugUnitTest` no Actions.
**Próxima fatia:** 9.2 — ler `animations` (samplers/channels) no `GlbParser` para `GltfSampler` e converter para keyframes do Editor.

## Fatia 9.2 — GlbParser lê animações glTF (v1.21.0) — LÓGICA VERIFICADA EM JVM; app NÃO compilado
**Objetivo:** ler `animations` (samplers/channels) do GLB/glTF em `GltfClip`/`GltfChannel`, sem aplicar ao modelo ainda.
**Alterados:** `mmd/GlbParser.kt` (`Parsed.clips`, parâmetro com default: `ModelImporter` não muda), `mmd/GltfSampler.kt` (+`GltfChannel`, `GltfClip`), `build.gradle.kts` (1.21.0 / 44). **Novo teste:** `GlbAnimParseTest.kt`.
**Comportamento:** canais translation/rotation/scale resolvem nó, nome e índice de osso (`-1` se o nó não é osso); STEP/LINEAR/CUBICSPLINE via `GltfSampler`. Canais com `weights`, alvo sem nó, sampler inválido ou tamanho errado viram **aviso** e são ignorados, sem derrubar o resto. O aviso antigo "animações não importadas" foi trocado por "N animação(ões) lidas; ainda não aplicadas".
**Verificação:** compilado com kotlinc 2.0.21 (com PmxModel real, org.json stub) e JUnit: 3/3 OK (clip com 2 canais e valores no meio do intervalo, canais inválidos, CUBICSPLINE com tamanho errado). `GlbParser` compilou inteiro fora do Android.
**Limitações:** morph weights não lidos; nada aplicado ao Animator/Editor/UI; testado só com um glTF sintético, não com arquivo real (Mixamo etc.).
**Próxima fatia:** 9.3 — converter clip → keyframes do Editor (conversão glTF→MMD de Z/quaternion, translação relativa ao repouso) e lista de clips na UI.

## Fatia 9.3 — Clip glTF → keyframes do Editor + ligação na importação (v1.22.0) — CONVERSOR VERIFICADO EM JVM; UI/Android NÃO compilados
**Objetivo:** fazer um GLB/glTF animado tocar no app ao importar (critério "importar um GLB com animação e reproduzi-la").
**Novos:** `mmd/GltfToMotion.kt` (`GltfRig`, `GltfToMotion.convert`), `test/.../GltfToMotionTest.kt`. **Alterados:** `GlbParser.kt` (`Parsed.rig`: repouso dos nós + escala), `importer/ModelImporter.kt` (`Result.clips/rig`, GLB solto e dentro de zip), `ui/SceneScreen.kt` (após importar modelo com clips: converte a 1ª animação, `editor.load`, ajusta duração e mostra no status), `GlbAnimParseTest.kt`, `build.gradle.kts` (1.22.0 / 45).
**Matemática:** por osso, delta = qAnim·conj(qRepouso); rotação MMD = Rp·delta·conj(Rp) (Rp = rotação de repouso global do pai glTF); depois (x,y,z,w)→(−x,−y,z,w). Deslocamento = Rp·(T−Trepouso)·escala, Z invertido. 1 key por quadro a 30 fps, curva linear, continuidade de sinal do quaternion.
**Comportamento:** usa só a 1ª animação (avisa se há mais). Canais de escala, de nós que não são ossos e `weights` são ignorados COM aviso. A animação entra no Editor, então é editável, salva no `animacao.vmd` do projeto e vai para as exportações. Nós com `matrix` no glTF: rotação de repouso tratada como identidade (aviso).
**Verificação:** 16/16 testes JVM (sampler 7 + parser 3 + conversor 6) compilando `GlbParser`/`PmxModel`/`VmdMotion` reais. `SceneScreen.kt` e `ModelImporter.kt` (Android) NÃO foram compilados.
**Não feito:** escolher outro clip (lista na UI), blend/camadas, root motion separado, retargeting entre esqueletos, animação de escala.
**Testar no aparelho:** importar um .glb/.zip com esqueleto e animação; deve aparecer "Animação 'x' importada" no status e o modelo se mover no play. Se a pose sair torta/espelhada, o ponto a ajustar é a conversão em `GltfToMotion.convert`; se nenhum osso casar, ver os avisos no log (tag GLB).
**Próxima fatia:** 9.4 — lista de clips com escolha na UI (feita na v1.23.0, ver abaixo) ou 8.3 — vários personagens.

## Fatia 9.4 — Lista de clips com escolha na UI (v1.23.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** um GLB/glTF com várias animações deixa de usar só a 1ª: o usuário escolhe qual aplicar.
**Alterados:** `ui/SceneScreen.kt` (estado `glbClips/glbRig/clipDlg/clipCur`, função `applyClip(i)`, item de menu "Animações do arquivo… (N)" no menu do viewport, diálogo abre sozinho ao importar se houver mais de 1 clip), `ui/StudioDialogs.kt` (+`ClipPickerDialog`), `build.gradle.kts` (1.23.0 / 46), `README.md`.
**Comportamento:** importar continua aplicando a 1ª por padrão; escolher outro clip roda `GltfToMotion.convert` em `Dispatchers.Default`, **substitui** as keys do editor (`editor.load`), ajusta a duração e volta ao quadro 0. A lista marca o clip em uso e mostra a duração.
**Limitações (v1.23.0; CORRIGIDO na v1.24.0 — a troca passou a usar `Editor.replaceUndoable`, desfazível):** trocar de clip não era desfazível (o `load` limpa o desfazer); ao reabrir o projeto a lista de clips NÃO é recarregada (o `animacao.vmd` salvo é o que volta); só um clip por vez (sem blend/camadas); sem pré-visualização do clip antes de aplicar.
**Verificação:** só revisão por leitura e balanceamento de chaves/parênteses; nenhum código novo de lógica pura (usa o conversor já testado 16/16 em JVM). Não compilado.
**Testar no aparelho:** importar um .glb com 2+ animações (ex.: Mixamo/Sketchfab) → o diálogo abre; escolher outra → o modelo muda de movimento no play; reabrir pelo menu "Animações do arquivo…".
**Próxima fatia:** 8.3 (vários personagens) ou o que o usuário escolher no menu.

# 12. Prioridades P0–P3 (nota complementar de 19/11/2026) — incorporadas
Fonte: `MMD_Studio_Nota_Atualizacoes_Prioridade.md` (nota complementar; NÃO substitui este documento). Nada foi removido; "menor prioridade" = fazer depois, não cancelar. Os marcadores P0–P3 estão no início de cada Release (seções 5 e 6).
**Legenda:** P0 essencial (bloqueia/sustenta outras áreas) · P1 alto valor · P2 complementar · P3 baixo retorno inicial.

| # | Item (ordem de utilidade) | Prioridade | Release | Tipo |
|---|---|---|---|---|
| 1 | Auditoria real, build e testes no Android | P0 | transversal | auditoria + correção |
| 2 | Scene Graph persistente + Outliner funcional | P0 | 8 | implementação nova |
| 3 | Múltiplos personagens independentes | P0 | 8 | implementação nova |
| 4 | Núcleo de animação + clips GLB, relógio único | P0 | 9 | implementação nova + correção |
| 5 | Ferramentas manuais (graph editor, layers, IK, root motion) | P0/P1 | 9 | implementação nova |
| 6 | Câmeras persistentes e Camera Director | P1 (base em P0) | 10 | implementação nova |
| 7 | Render por frame + exportação básica | P0/P1 | 16 (antecipado) | implementação nova |
| 8 | Estabilidade, desempenho, persistência | P0 contínuo | 6 | correção/refinamento |
| 9 | Luzes e materiais | P1 | 12 | implementação nova |
| 10 | Motion graphics 3D | P1 | 11 | implementação nova |
| 11 | Expressões faciais básicas | P1/P2 | 15 | implementação nova |
| 12 | VFX de ação essenciais | P1/P2 | 13 | implementação nova |
| 13 | Compositor 2D multicamada | P2 | 14 | implementação nova |
| 14 | Lip sync e facial avançada | P2 | 15 | refinamento futuro |
| 15 | Pós-processamento avançado | P2/P3 | 13/16 | refinamento futuro |
| 16 | Sistemas especializados (deformadores, luz de área, plugins, presets enormes) | P3 | — | refinamento futuro |

**Ordem técnica de execução (dependências):** auditoria → estabilidade/persistência → Scene Graph + Outliner → multi-personagem → Animation Clock → clips GLB → ferramentas manuais → câmeras → render/exportação básica com áudio → luzes/materiais → motion graphics → facial básico → VFX → compositor → render cinematográfico → especializados. Dividir em entregas pequenas; nunca uma release inteira sem testes.
**Ajuste de sequência (com a dependência):** a nota põe multi-personagem (3º) antes de mais trabalho de GLB; por isso, depois da v1.24.0, a próxima fatia de código deve ser a **8.3** (instâncias independentes), e não mais itens de glTF (morph weights/escala), que ficam para depois.

## 12.1 Regra dos cinco níveis (anti-progresso-falso)
Cada função é avaliada em: **Dados · Motor · Interface · Persistência · Saída**. Só vale "concluída" com os cinco + build + teste no aparelho. Classe, modelo de dados, botão ou tela isolados não contam.

## 12.2 Auditoria P0 (19/11/2026, v1.23.0→v1.24.0) — por leitura de código; build NÃO executado neste ambiente
| Sistema | Dados | Motor | Interface | Persistência | Saída | Observação real |
|---|---|---|---|---|---|---|
| Scene Graph | ✅ (testes JVM 15/15 em sessão anterior) | ❌ | ❌ | 🟨 `ProjectStore.loadOrMigrateScene/saveScene` existem, **nenhum chamador** | ❌ | Só o `ProjectStore` referencia o grafo; renderer, SceneScreen e Outliner não o usam |
| Outliner | — | — | 🟨 `LayersPanel` existe, alimentado por props/modelo (não pelo grafo); só selecionar/ocultar | ❌ | — | Faltam renomear, bloquear, duplicar, agrupar, reordenar sobre o grafo |
| Multi-personagem | 🟨 `CharacterInstance` | ❌ só `mainChar` | ❌ | ❌ | ❌ | Prepara 8.3; hoje só 1 personagem animado |
| Importação GLB animada | ✅ clips + `GltfSampler` (JVM) | ✅ `GltfToMotion` (JVM 16/16) | 🟨 v1.22–1.24, **não compilada** | 🟨 vira keys no `animacao.vmd`; lista de clips não recarrega ao reabrir | 🟨 via `Animator` (não testado) | Faltam escala, morph weights, loop/trim/blend |
| Aplicar clip sem destruir keys | — | ✅ v1.24.0 `Editor.replaceUndoable` | ✅ | — | — | **Correção**: antes (v1.23.0) a troca limpava o desfazer; agora é 1 passo de desfazer (teste novo em `KeyEditTest`, não executado) |
| Build/testes no Android | — | — | — | — | — | **Nenhuma versão da v1.13.0 à v1.24.0 teve build confirmado.** Bloqueio nº 1: rodar o Actions, enviar o log e testar no aparelho |

**Próximas ações P0 (ordem):** (1) usuário: build no Actions + roteiro no celular das v1.14–v1.24; (2) corrigir erros de compilação do log; (3) fatia 8.3 (instâncias independentes + personagem ativo + relógio global); (4) Outliner ligado ao Scene Graph (renomear, ocultar, bloquear, duplicar, agrupar, reordenar, undo); (5) recarregar a lista de clips ao reabrir.

## Fatia 9.5 — Troca de clip desfazível (v1.24.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Motivo:** a nota de prioridades exige que aplicar/importar um clip não destrua keyframes existentes. **Alterados:** `edit/Editor.kt` (+`replaceUndoable`: troca todas as keys como um passo de desfazer, sem limpar o histórico), `ui/SceneScreen.kt` (`applyClip` usa `replaceUndoable`; não encolhe a duração total), `ui/StudioDialogs.kt` (texto), `test/.../KeyEditTest.kt` (+teste de troca/desfazer/refazer), `build.gradle.kts` (1.24.0 / 47), `README.md`, este roadmap (marcadores P0–P3, seção 12).
**Limitação:** a importação inicial do GLB (1ª animação) ainda usa `editor.load` ao criar um modelo novo (editor novo, nada a preservar). `vmdExtras` não é restaurado pelo desfazer. Teste novo não executado (sem kotlinc neste ambiente).

## Correção de build (v1.24.1, 19/11/2026)
Primeiro log real do Actions (build de 19:25): `SceneGLView.kt:590:85 Unresolved reference: shBone`. Causa: a extração do `CharacterInstance` (v1.19.0, fatia 8.2) deixou uma referência sem `mainChar.`. Corrigido (1 linha). Era o único erro listado; outros podem aparecer na fase seguinte (testes/dex). Status: aguardando novo build.
