package studio.mmd.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.render.LightCfg
import studio.mmd.render.LookCfg
import java.io.File

/** Lê uma imagem de fundo reduzindo para no máximo ~2048 px no lado maior. */
fun decodeBg(f: File): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, o)
    var ss = 1; while (maxOf(o.outWidth, o.outHeight) / ss > 2048) ss *= 2
    BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = ss })
} catch (e: Throwable) { null }

@Composable
private fun LRow(label: String, v: Float, range: ClosedFloatingPointRange<Float>, fmt: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, modifier = Modifier.width(64.dp))
        Slider(v.coerceIn(range.start, range.endInclusive), onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text(fmt.format(v), fontSize = 11.sp, modifier = Modifier.width(44.dp))
    }
}

/** Diálogo de iluminação: presets + direção, intensidade e cor. */
@Composable
fun LightDialog(c: LightCfg, onChange: (LightCfg) -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } },
        title = { Text("Iluminação") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { onChange(LightCfg()) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Studio", fontSize = 11.sp) }
                    OutlinedButton(onClick = { onChange(LightCfg(160f, 25f, 1.4f, 0.8f, 0.9f, 1f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Rim", fontSize = 11.sp) }
                    OutlinedButton(onClick = { onChange(LightCfg(70f, 8f, 1.3f, 1f, 0.6f, 0.35f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Sunset", fontSize = 11.sp) }
                }
                LRow("Dir. H", c.yaw, 0f..360f, "%.0f°") { onChange(c.copy(yaw = it)) }
                LRow("Dir. V", c.pitch, -20f..90f, "%.0f°") { onChange(c.copy(pitch = it)) }
                LRow("Intens.", c.intensity, 0f..2f, "%.2f") { onChange(c.copy(intensity = it)) }
                LRow("Verm.", c.r, 0f..1f, "%.2f") { onChange(c.copy(r = it)) }
                LRow("Verde", c.g, 0f..1f, "%.2f") { onChange(c.copy(g = it)) }
                LRow("Azul", c.b, 0f..1f, "%.2f") { onChange(c.copy(b = it)) }
            }
        })
}

/** Mesmos controles do diálogo de iluminação, como painel fixo (aba Luz). */
@Composable
fun LightPanel(c: LightCfg, onChange: (LightCfg) -> Unit, modifier: Modifier, look: LookCfg = LookCfg(), onLook: (LookCfg) -> Unit = {}) {
    Column(modifier.background(androidx.compose.ui.graphics.Color(0xFF17181B), androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(8.dp)
        .verticalScroll(androidx.compose.foundation.rememberScrollState())) {
        Text("Luz", fontSize = 13.sp)
        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { onChange(LightCfg()) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Studio", fontSize = 11.sp) }
            OutlinedButton(onClick = { onChange(LightCfg(160f, 25f, 1.4f, 0.8f, 0.9f, 1f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Rim", fontSize = 11.sp) }
            OutlinedButton(onClick = { onChange(LightCfg(70f, 8f, 1.3f, 1f, 0.6f, 0.35f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Sunset", fontSize = 11.sp) }
        }
        LRow("Dir. H", c.yaw, 0f..360f, "%.0f°") { onChange(c.copy(yaw = it)) }
        LRow("Dir. V", c.pitch, -20f..90f, "%.0f°") { onChange(c.copy(pitch = it)) }
        LRow("Intens.", c.intensity, 0f..2f, "%.2f") { onChange(c.copy(intensity = it)) }
        LRow("Verm.", c.r, 0f..1f, "%.2f") { onChange(c.copy(r = it)) }
        LRow("Verde", c.g, 0f..1f, "%.2f") { onChange(c.copy(g = it)) }
        LRow("Azul", c.b, 0f..1f, "%.2f") { onChange(c.copy(b = it)) }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Aparência (todos os modos exceto o contorno)", fontSize = 13.sp)
            OutlinedButton(onClick = { onLook(LookCfg()) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Padrão", fontSize = 11.sp) }
        }
        LRow("Exposição", look.exposure, 0.5f..2f, "%.2f") { onLook(look.copy(exposure = it)) }
        LRow("Contraste", look.contrast, 0.7f..1.5f, "%.2f") { onLook(look.copy(contrast = it)) }
        LRow("Saturação", look.saturation, 0f..2f, "%.2f") { onLook(look.copy(saturation = it)) }
        LRow("Luz de borda", look.rim, 0f..1f, "%.2f") { onLook(look.copy(rim = it)) }
        Text("Modo MMD (toon)", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        LRow("Suavidade", look.softness, 0.02f..0.4f, "%.2f") { onLook(look.copy(softness = it)) }
        LRow("Sombra", look.shade, 0f..1.5f, "%.2f") { onLook(look.copy(shade = it)) }
    }
}

/** v1.23.0: lista as animações de um GLB/glTF importado; escolher uma converte e substitui as keys do editor. */
@Composable
fun ClipPickerDialog(clips: List<studio.mmd.mmd.GltfClip>, current: Int, onPick: (Int) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Animações do arquivo") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Escolher uma substitui as keys atuais (dá para desfazer).", fontSize = 11.sp)
                clips.forEachIndexed { i, c ->
                    val label = (c.name.ifBlank { "Animação ${i + 1}" }) + " · " + "%.1f".format(c.duration) + " s" + if (i == current) " (em uso)" else ""
                    TextButton(onClick = { onPick(i) }, modifier = Modifier.fillMaxWidth()) { Text(label, fontSize = 13.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } }
    )
}
