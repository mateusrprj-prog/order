package studio.mmd.project

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/** Dados de um projeto. Arquivos do projeto ficam em filesDir/projects/<id>/ (project.json, model.*, audio.*, animacao.vmd). */
data class ProjectMeta(
    val id: String, val name: String, val aspect: String, val resolution: Int, val fps: Int,
    val bg: String, val created: Long, val updated: Long, val frames: Int
)

/** Configuração do áudio do projeto (nome original, volume 0..1, atraso em ms). */
data class AudioCfg(val name: String, val volume: Float, val offsetMs: Int)

/** Cenário / acessório extra da cena (PMX estático). Posição em unidades do viewport, escala uniforme. */
/** [bone] vazio = solto no mundo; senão o objeto segue esse osso do modelo principal (x,y,z = deslocamento no espaço do osso; rx,ry,rz = rotação local em graus). */
data class PropMeta(val id: String, val name: String, val ext: String, val x: Float, val y: Float, val z: Float, val s: Float,
                    val bone: String = "", val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f)

object Aspects {
    /** Nome -> largura/altura (0 = livre, sem moldura). */
    val all: List<Pair<String, Float>> = listOf(
        "16:9" to 16f / 9f, "9:16" to 9f / 16f, "4:5" to 4f / 5f, "1:1" to 1f, "4:3" to 4f / 3f, "Livre" to 0f
    )

    fun ratio(key: String): Float = all.firstOrNull { it.first == key }?.second ?: 0f

    /** Resolução = lado menor (4:3 em 2160p = 2880×2160). Livre = null. */
    fun size(key: String, res: Int): Pair<Int, Int>? {
        val r = ratio(key)
        if (r <= 0f) return null
        return if (r >= 1f) Pair((res * r).toInt() / 2 * 2, res) else Pair(res, (res / r).toInt() / 2 * 2)
    }
}

object Backgrounds {
    val all: List<Pair<String, Int>> = listOf(
        "Preto" to 0xFF000000.toInt(), "Cinza" to 0xFF303236.toInt(), "Branco" to 0xFFFFFFFF.toInt(),
        "Azul" to 0xFF1B3A6B.toInt(), "Verde" to 0xFF00B140.toInt()
    )

    fun color(name: String): Int = all.firstOrNull { it.first == name }?.second ?: all[0].second
}

object ProjectStore {
    /** Versão do formato do project.json. Ausente = 0 (projetos até a v1.9.0). v1 = apenas marca a versão; sem mudança de campos. */
    const val FORMAT_VERSION = 1
    private fun root(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    private fun write(ctx: Context, m: ProjectMeta) {
        val j = JSONObject().put("formatVersion", FORMAT_VERSION).put("id", m.id).put("name", m.name).put("aspect", m.aspect).put("resolution", m.resolution)
            .put("fps", m.fps).put("bg", m.bg).put("created", m.created).put("updated", m.updated).put("frames", m.frames)
        // escrita atômica: grava num temporário e troca, para um encerramento no meio não corromper o projeto
        val f = File(dir(ctx, m.id), "project.json"); val tmp = File(f.parentFile, "project.json.tmp")
        tmp.writeText(j.toString())
        if (!tmp.renameTo(f)) { f.writeText(j.toString()); tmp.delete() }
    }

    private fun read(f: File): ProjectMeta? = try {
        val j = JSONObject(f.readText())
        ProjectMeta(
            j.getString("id"), j.getString("name"), j.optString("aspect", "16:9"), j.optInt("resolution", 1080),
            j.optInt("fps", 30), j.optString("bg", "Preto"), j.optLong("created"), j.optLong("updated"), j.optInt("frames", 300)
        )
    } catch (e: Exception) { null }

    fun list(ctx: Context): List<ProjectMeta> =
        (root(ctx).listFiles() ?: emptyArray()).mapNotNull { d -> File(d, "project.json").takeIf { it.exists() }?.let { read(it) } }

    fun get(ctx: Context, id: String): ProjectMeta? = File(File(root(ctx), id), "project.json").takeIf { it.exists() }?.let { read(it) }

    fun create(ctx: Context, name: String, aspect: String, res: Int, fps: Int, bg: String): ProjectMeta {
        val now = System.currentTimeMillis()
        val m = ProjectMeta(UUID.randomUUID().toString(), name, aspect, res, fps, bg, now, now, 300)
        write(ctx, m); return m
    }

    fun rename(ctx: Context, id: String, name: String) { get(ctx, id)?.let { write(ctx, it.copy(name = name)) } }

    /** Atualiza data de modificação e duração. */
    fun touch(ctx: Context, id: String, frames: Int) { get(ctx, id)?.let { write(ctx, it.copy(updated = System.currentTimeMillis(), frames = frames)) } }

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }

    /**
     * Importa um projeto exportado (.zip com project.json na raiz ou numa única subpasta).
     * Cria um projeto NOVO (id novo, nome + " (importado)"), sem mexer nos existentes. Devolve o projeto ou lança IOException.
     */
    fun importZip(ctx: Context, uri: Uri): ProjectMeta {
        val newId = UUID.randomUUID().toString()
        val dst = File(root(ctx), newId).apply { mkdirs() }
        try {
            val canon = dst.canonicalPath + File.separator
            var found = false; var totalBytes = 0L
            (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { raw ->
                java.util.zip.ZipInputStream(raw.buffered()).use { z ->
                    // descobre prefixo (zip com tudo dentro de uma pasta)
                    val entries = ArrayList<Pair<String, ByteArray?>>()
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            if (entries.size >= 20_000) throw IOException("Projeto com arquivos demais (limite 20000)")
                            val tmp = File(dst, "__tmp__/" + entries.size)
                            tmp.parentFile?.mkdirs()
                            tmp.outputStream().use { o -> z.copyTo(o) }
                            totalBytes += tmp.length()
                            if (totalBytes > 3L * 1024 * 1024 * 1024) throw IOException("Projeto grande demais (limite 3 GB descompactado)")
                            entries.add(Pair(e.name.replace('\\', '/'), null))
                        }
                        z.closeEntry(); e = z.nextEntry
                    }
                    val meta = entries.indexOfFirst { it.first == "project.json" || it.first.endsWith("/project.json") }
                    if (meta < 0) throw IOException("Este .zip não é um projeto do MMD Studio (sem project.json)")
                    val prefix = entries[meta].first.removeSuffix("project.json")
                    entries.forEachIndexed { i, (name, _) ->
                        if (!name.startsWith(prefix)) return@forEachIndexed
                        val rel = name.removePrefix(prefix)
                        val target = File(dst, rel)
                        if (!target.canonicalPath.startsWith(canon)) return@forEachIndexed // proteção contra caminhos maliciosos
                        target.parentFile?.mkdirs()
                        File(dst, "__tmp__/$i").renameTo(target)
                    }
                    found = true
                }
            }
            File(dst, "__tmp__").deleteRecursively()
            if (!found) throw IOException("Projeto vazio")
            val j = JSONObject(File(dst, "project.json").readText())
            if (j.optInt("formatVersion", 0) > FORMAT_VERSION) throw IOException("Projeto criado por uma versão mais nova do app (formato ${j.optInt("formatVersion")}). Atualize o MMD Studio.")
            val now = System.currentTimeMillis()
            val m = ProjectMeta(newId, j.optString("name", "Projeto") + " (importado)", j.optString("aspect", "16:9"), j.optInt("resolution", 1080),
                j.optInt("fps", 30), j.optString("bg", "Preto"), now, now, j.optInt("frames", 300))
            write(ctx, m)
            return m
        } catch (e: Exception) {
            dst.deleteRecursively()
            throw if (e is IOException) e else IOException("Projeto inválido: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun sizeBytes(ctx: Context, id: String): Long = File(root(ctx), id).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Copia o arquivo escolhido para o projeto como <prefix>.<ext>, substituindo o anterior. */
    fun copyIn(ctx: Context, id: String, uri: Uri, prefix: String, ext: String): File {
        val d = dir(ctx, id)
        val tmp = File(d, "$prefix.tmp")
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            tmp.outputStream().use { o -> i.copyTo(o) }
        }
        d.listFiles()?.filter { it.name.startsWith("$prefix.") && it.name != tmp.name }?.forEach { it.delete() }
        val dst = File(d, "$prefix.$ext")
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
        return dst
    }

    fun fileWith(ctx: Context, id: String, prefix: String): File? =
        dir(ctx, id).listFiles()?.firstOrNull { it.name.startsWith("$prefix.") && !it.name.endsWith(".tmp") }

    fun animFile(ctx: Context, id: String) = File(dir(ctx, id), "animacao.vmd")

    /** Grava a animação do projeto; null apaga. */
    fun saveAnim(ctx: Context, id: String, bytes: ByteArray?) {
        val f = animFile(ctx, id)
        if (bytes == null) f.delete() else f.writeBytes(bytes)
    }

    // ---------- cenário e acessórios (props)
    private fun propsDir(ctx: Context, id: String) = File(dir(ctx, id), "props").apply { mkdirs() }
    fun propFile(ctx: Context, projectId: String, p: PropMeta) = File(propsDir(ctx, projectId), "${p.id}.${p.ext}")

    fun loadProps(ctx: Context, projectId: String): List<PropMeta> = try {
        val f = File(dir(ctx, projectId), "scene.json")
        if (!f.exists()) emptyList() else {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val j = a.getJSONObject(i)
                PropMeta(j.getString("id"), j.optString("name", "objeto"), j.optString("ext", "zip"),
                    j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(), j.optDouble("s", 1.0).toFloat(),
                    j.optString("bone", ""), j.optDouble("rx", 0.0).toFloat(), j.optDouble("ry", 0.0).toFloat(), j.optDouble("rz", 0.0).toFloat())
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveProps(ctx: Context, projectId: String, list: List<PropMeta>) {
        val a = JSONArray()
        list.forEach { p -> a.put(JSONObject().put("id", p.id).put("name", p.name).put("ext", p.ext).put("x", p.x.toDouble()).put("y", p.y.toDouble()).put("z", p.z.toDouble()).put("s", p.s.toDouble()).put("bone", p.bone).put("rx", p.rx.toDouble()).put("ry", p.ry.toDouble()).put("rz", p.rz.toDouble())) }
        File(dir(ctx, projectId), "scene.json").writeText(a.toString())
    }

    /** Copia o arquivo escolhido para a pasta props do projeto e devolve o registro do objeto. */
    fun addPropFile(ctx: Context, projectId: String, uri: Uri, name: String, ext: String): PropMeta {
        val p = PropMeta(UUID.randomUUID().toString(), name, ext, 0f, 0f, 0f, 1f)
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            propFile(ctx, projectId, p).outputStream().use { o -> i.copyTo(o) }
        }
        return p
    }

    fun deletePropFile(ctx: Context, projectId: String, p: PropMeta) { propFile(ctx, projectId, p).delete() }

    // ---------- Scene Graph (scenegraph.json) — v1.18.0, Release 8 fatia 1. Ainda não ligado à UI.
    /** Lê o scenegraph.json; null se não existir. Lança IOException se estiver corrompido/for de versão mais nova. */
    fun loadScene(ctx: Context, projectId: String): studio.mmd.scene.SceneLoad? {
        val f = File(dir(ctx, projectId), studio.mmd.scene.SceneSerializer.FILE)
        if (!f.exists()) return null
        try { return studio.mmd.scene.SceneSerializer.fromJson(f.readText()) }
        catch (e: IllegalArgumentException) { throw IOException(e.message ?: "scenegraph.json inválido") }
    }

    /** Escrita atômica (temporário + troca), como o project.json. */
    fun saveScene(ctx: Context, projectId: String, g: studio.mmd.scene.SceneGraph) {
        val f = File(dir(ctx, projectId), studio.mmd.scene.SceneSerializer.FILE); val tmp = File(f.parentFile, f.name + ".tmp")
        val text = studio.mmd.scene.SceneSerializer.toJson(g)
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    /**
     * Devolve o grafo do projeto. Se ainda não existe, migra do formato v1 (modelo principal + props do scene.json antigo),
     * guardando antes uma cópia project.v1.json.bak (uma vez) e gravando o scenegraph.json. O scene.json antigo NÃO é alterado.
     */
    fun loadOrMigrateScene(ctx: Context, projectId: String, modelName: String): studio.mmd.scene.SceneLoad {
        loadScene(ctx, projectId)?.let { return it }
        val d = dir(ctx, projectId)
        val pj = File(d, "project.json"); val bak = File(d, "project.v1.json.bak")
        if (pj.exists() && !bak.exists()) pj.copyTo(bak)
        val hasModel = d.listFiles()?.any { it.name.startsWith("model.") } == true
        val g = studio.mmd.scene.SceneGraph.fromLegacy(modelName, hasModel, loadProps(ctx, projectId))
        saveScene(ctx, projectId, g)
        return studio.mmd.scene.SceneLoad(g, listOf("Projeto migrado do formato v1 para o Scene Graph"))
    }

    // ---------- rig: restrições (rig.json)
    fun loadRig(ctx: Context, projectId: String): List<studio.mmd.rig.Constraint> {
        val f = File(dir(ctx, projectId), "rig.json")
        return if (f.exists()) studio.mmd.rig.RigIo.fromJson(f.readText()) else emptyList()
    }

    fun saveRig(ctx: Context, projectId: String, l: List<studio.mmd.rig.Constraint>) {
        val f = File(dir(ctx, projectId), "rig.json")
        if (l.isEmpty()) f.delete() else f.writeText(studio.mmd.rig.RigIo.toJson(l))
    }

    // ---------- movimento secundário (secondary.json)
    fun loadSecondary(ctx: Context, projectId: String): List<studio.mmd.rig.Secondary> {
        val f = File(dir(ctx, projectId), "secondary.json")
        return if (f.exists()) studio.mmd.rig.SecIo.fromJson(f.readText()) else emptyList()
    }

    fun saveSecondary(ctx: Context, projectId: String, l: List<studio.mmd.rig.Secondary>) {
        val f = File(dir(ctx, projectId), "secondary.json")
        if (l.isEmpty()) f.delete() else f.writeText(studio.mmd.rig.SecIo.toJson(l))
    }

    fun loadPhys(ctx: Context, projectId: String): studio.mmd.rig.PhysConfig {
        val f = File(dir(ctx, projectId), "physics.json")
        return if (f.exists()) studio.mmd.rig.PhysIo.fromJson(f.readText()) else studio.mmd.rig.PhysConfig()
    }

    fun savePhys(ctx: Context, projectId: String, c: studio.mmd.rig.PhysConfig) {
        val f = File(dir(ctx, projectId), "physics.json")
        if (!c.enabled) f.delete() else f.writeText(studio.mmd.rig.PhysIo.toJson(c))
    }

    // ---------- áudio (config em audiocfg.json; o arquivo é audio.<ext>)
    fun loadAudioCfg(ctx: Context, projectId: String): AudioCfg? = try {
        val f = File(dir(ctx, projectId), "audiocfg.json")
        if (!f.exists()) null else JSONObject(f.readText()).let {
            AudioCfg(it.optString("name", "áudio"), it.optDouble("volume", 1.0).toFloat(), it.optInt("offset", 0))
        }
    } catch (e: Exception) { null }

    /** null apaga a configuração. */
    fun saveAudioCfg(ctx: Context, projectId: String, c: AudioCfg?) {
        val f = File(dir(ctx, projectId), "audiocfg.json")
        if (c == null) f.delete() else f.writeText(JSONObject().put("name", c.name).put("volume", c.volume.toDouble()).put("offset", c.offsetMs).toString())
    }

    fun deleteAudio(ctx: Context, projectId: String) {
        dir(ctx, projectId).listFiles()?.filter { it.name.startsWith("audio.") }?.forEach { it.delete() }
        saveAudioCfg(ctx, projectId, null)
    }
}
