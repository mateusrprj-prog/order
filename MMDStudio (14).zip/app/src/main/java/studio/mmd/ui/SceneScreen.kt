package studio.mmd.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.ui.geometry.Size
import studio.mmd.project.Aspects
import studio.mmd.project.Backgrounds
import studio.mmd.project.ProjectMeta
import studio.mmd.project.PropMeta
import studio.mmd.project.AudioCfg
import studio.mmd.project.ProjectStore
import java.io.File
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import android.media.MediaPlayer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlin.math.abs
import kotlin.math.floor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.edit.Editor
import studio.mmd.importer.ModelImporter
import studio.mmd.mmd.VmdParser
import studio.mmd.fbx.FbxExporter
import studio.mmd.fbx.GlbExporter
import studio.mmd.export.MediaExport
import studio.mmd.export.VideoEncoder
import android.graphics.Bitmap
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import studio.mmd.render.SceneGLView
import studio.mmd.render.TouchMode
import studio.mmd.render.ViewPreset

val Bg = Color(0xFF0A0A0B); val Panel = Color(0xFF17181B); val Accent = Color(0xFFE53935)
val Muted = Color(0xFF8A8D94)
const val FPS = 30; const val DEFAULT_FRAMES = 300

@Composable
fun SceneScreen(project: ProjectMeta, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var glReady by remember { mutableStateOf(false) }
    var restored by remember { mutableStateOf(false) }
    var guide by remember { mutableStateOf(true) }
    val gl = remember { SceneGLView(ctx).also { it.onReady = { glReady = true } } }
    var mode by remember { mutableStateOf(TouchMode.ORBIT) }
    var menu by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(maxOf(project.frames, 2)) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var editor by remember { mutableStateOf<Editor?>(null) }
    var skeleton by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var selBone by remember { mutableIntStateOf(-1) }
    var selMorph by remember { mutableIntStateOf(-1) }
    var rig by remember { mutableStateOf<List<studio.mmd.rig.Constraint>>(emptyList()) }
    var sec by remember { mutableStateOf<List<studio.mmd.rig.Secondary>>(emptyList()) }
    var baking by remember { mutableStateOf(false) }
    val ed = editor
    val ver = ed?.version ?: 0
    var audio by remember { mutableStateOf<MediaPlayer?>(null) }
    var texData by remember { mutableStateOf<List<ByteArray?>>(emptyList()) }
    var exportMenu by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val prefs = remember { ctx.getSharedPreferences("mmdstudio", android.content.Context.MODE_PRIVATE) }
    var preview60 by remember { mutableStateOf(prefs.getBoolean("preview60", true)) }
    var fbxZip by remember { mutableStateOf(false) }
    var scenePanel by remember { mutableStateOf(false) }
    var audioPanel by remember { mutableStateOf(false) }
    var audioName by remember { mutableStateOf<String?>(null) }
    var audioVol by remember { mutableFloatStateOf(1f) }
    var audioOff by remember { mutableIntStateOf(0) }
    var props by remember { mutableStateOf<List<PropMeta>>(emptyList()) }
    var selProp by remember { mutableIntStateOf(-1) }
    fun note(t: String) { toast = t }
    val scope = rememberCoroutineScope()

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val bytes = e.toVmd(); val n = e.keyCount()
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(bytes) }
                    }
                    isError = false; status = "VMD salvo\n$n keyframes · ${bytes.size / 1024} KB"
                } catch (ex: Throwable) { isError = true; status = "Erro ao salvar: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    fun saveAudio() { ProjectStore.saveAudioCfg(ctx, project.id, audioName?.let { AudioCfg(it, audioVol, audioOff) }) }

    val fbxSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val mo = e.motion(); val frames = maxOf(mo.maxFrame + 1, 2); val tex = texData; val zip = fbxZip
            val base = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }
            isError = false; status = "Exportando FBX...\n$frames quadros"
            scope.launch {
                try {
                    var size = 0L; var rep: FbxExporter.Report? = null
                    withContext(Dispatchers.Default) {
                        val raw = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        val cnt = CountOut(raw.buffered(1 shl 16))
                        cnt.use { c ->
                            val names = FbxExporter.textureFileNames(e.model, tex)
                            if (zip) {
                                val z = ZipOutputStream(c)
                                z.putNextEntry(ZipEntry("$base.fbx"))
                                rep = FbxExporter.write(z, e.model, mo, names, frames)
                                z.closeEntry()
                                names.forEachIndexed { i, nm ->
                                    val b = tex.getOrNull(i)
                                    if (nm != null && b != null) { z.putNextEntry(ZipEntry(nm)); z.write(b); z.closeEntry() }
                                }
                                z.finish()
                            } else { rep = FbxExporter.write(c, e.model, mo, names, frames) }
                            Unit
                        }
                        size = cnt.count
                    }
                    val r = rep
                    status = "FBX exportado\n${r?.bones} ossos · ${r?.frames} quadros a $FPS fps\n${r?.animatedBones} ossos animados · ${size / 1024} KB" +
                        if (zip) "\n(zip com texturas)" else "\n(sem texturas)"
                } catch (ex: Throwable) { isError = true; status = "Erro ao exportar FBX: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    fun outName() = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }

    val glbSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("model/gltf-binary")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val mo = e.motion(); val frames = maxOf(mo.maxFrame + 1, 2); val tex = texData
            isError = false; status = "Exportando GLB...\n$frames quadros"
            scope.launch {
                try {
                    var size = 0L; var rep: FbxExporter.Report? = null
                    withContext(Dispatchers.Default) {
                        val raw = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        val cnt = CountOut(raw.buffered(1 shl 16))
                        cnt.use { c -> rep = GlbExporter.write(c, e.model, mo, tex, frames); Unit }
                        size = cnt.count
                    }
                    val r = rep
                    status = "GLB exportado\n${r?.bones} ossos · ${r?.frames} quadros a $FPS fps\n${r?.animatedBones} ossos animados · ${size / 1024} KB\ntexturas embutidas no arquivo"
                } catch (ex: Throwable) { isError = true; status = "Erro ao exportar GLB: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    val pngSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Salvando imagem..."
            try {
                val shot = gl.captureAwait(frame) ?: throw IllegalStateException("Falha ao capturar a tela")
                val img = MediaExport.cropAspect(shot, Aspects.ratio(project.aspect))
                withContext(Dispatchers.IO) {
                    (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                status = "Imagem salva\n${img.width}×${img.height} (quadro $frame)"
            } catch (ex: Throwable) { isError = true; status = "Erro ao salvar imagem: ${ex.message ?: ex.javaClass.simpleName}" }
            gl.setFrame(frame)
        }
    }

    val vpdSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) scope.launch {
            try {
                val bytes = MediaExport.vpd(e.model, e, frame, outName())
                withContext(Dispatchers.IO) { (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(bytes) } }
                isError = false; status = "Pose salva (.vpd)\nquadro $frame · ${bytes.size / 1024 + 1} KB\n(só ossos; morphs não incluídos)"
            } catch (ex: Throwable) { isError = true; status = "Erro ao salvar pose: ${ex.message ?: ex.javaClass.simpleName}" }
        }
    }

    val zipSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            try {
                editor?.let { e -> ProjectStore.saveAnim(ctx, project.id, if (e.keyCount() > 0) e.toVmd() else null) }
                saveAudio(); ProjectStore.saveProps(ctx, project.id, props); ProjectStore.saveRig(ctx, project.id, rig); ProjectStore.saveSecondary(ctx, project.id, sec)
                val n = withContext(Dispatchers.IO) {
                    val o = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                    o.buffered(1 shl 16).use { MediaExport.zipDir(ProjectStore.dir(ctx, project.id), it) }
                }
                isError = false; status = "Projeto exportado (.zip)\n$n arquivos"
            } catch (ex: Throwable) { isError = true; status = "Erro ao exportar projeto: ${ex.message ?: ex.javaClass.simpleName}" }
        }
    }

    val videoSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        val e = editor
        if (uri != null && !exporting) {
            val frames = if (e != null && e.keyCount() > 0) maxOf(e.motion().maxFrame + 1, 2) else total
            exporting = true; playing = false; isError = false
            scope.launch {
                val tmp = File(ctx.cacheDir, "export_video.mp4")
                var enc: VideoEncoder? = null
                var done = false
                try {
                    status = "Exportando vídeo...\npreparando"
                    val ratio = Aspects.ratio(project.aspect)
                    val limit = Aspects.size(project.aspect, project.resolution)
                    val first = gl.captureAwait(0) ?: throw IllegalStateException("Falha ao capturar a tela")
                    val c0 = MediaExport.cropAspect(first, ratio)
                    var tw = c0.width; var th = c0.height
                    if (limit != null && tw > limit.first) { th = th * limit.first / tw; tw = limit.first }   // nunca aumenta além da tela
                    tw = maxOf(16, tw / 16 * 16); th = maxOf(16, th / 16 * 16)
                    val encoder = withContext(Dispatchers.Default) { VideoEncoder(tmp, tw, th, FPS) }
                    enc = encoder
                    for (f in 0 until frames) {
                        val shot = if (f == 0) first else (gl.captureAwait(f) ?: throw IllegalStateException("Falha ao capturar o quadro $f"))
                        withContext(Dispatchers.Default) {
                            val c = MediaExport.cropAspect(shot, ratio)
                            val b = if (c.width == tw && c.height == th) c else Bitmap.createScaledBitmap(c, tw, th, true)
                            encoder.add(b)
                        }
                        status = "Exportando vídeo...\n${f + 1}/$frames quadros · ${tw}×${th}"
                    }
                    withContext(Dispatchers.Default) { encoder.finish() }
                    done = true
                    withContext(Dispatchers.IO) {
                        val o = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        o.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                    }
                    status = "Vídeo exportado (.mp4)\n${tw}×${th} · $frames quadros a $FPS fps · ${tmp.length() / 1024} KB\n(sem áudio)"
                } catch (ex: Throwable) {
                    isError = true; status = "Erro ao exportar vídeo: ${ex.message ?: ex.javaClass.simpleName}"
                    if (!done) enc?.abort()
                } finally {
                    tmp.delete(); exporting = false; gl.setFrame(frame)
                }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in setOf("mp3", "wav", "ogg", "m4a", "aac", "flac")) {
                    val copy = withContext(Dispatchers.IO) { ProjectStore.copyIn(ctx, project.id, uri, "audio", ext) }
                    val mp = withContext(Dispatchers.IO) { MediaPlayer().apply { setDataSource(copy.absolutePath); prepare() } }
                    audio?.release(); audio = mp; audioName = name; saveAudio()
                    status = "$name\náudio: %.1fs (toca junto com o play)".format(mp.duration / 1000f)
                } else if (ext == "vmd") {
                    val e = editor ?: throw IllegalStateException("Importe um modelo (.pmx/.zip) antes do movimento")
                    val m = e.model
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(ModelImporter.readBytes(ctx, uri)) }
                    val boneNames = m.bones.map { it.name }.toHashSet(); val morphNames = m.morphs.map { it.name }.toHashSet()
                    val bm = mo.bones.keys.count { it in boneNames }; val mm = mo.morphs.keys.count { it in morphNames }
                    playing = false; frame = 0; total = mo.maxFrame + 1
                    e.load(mo); gl.setFrame(0)
                    status = "$name\n${total} frames (%.1fs a $FPS fps)\nossos casados: $bm/${mo.bones.size}\nmorphs casados: $mm/${mo.morphs.size}".format(total / FPS.toFloat()) +
                        if (bm == 0) "\nATENÇÃO: nenhum osso casou; o modelo não vai se mover" else ""
                    if (bm == 0) isError = true
                } else {
                    val src = if (ext == "zip" || ext == "pmx") withContext(Dispatchers.IO) { Uri.fromFile(ProjectStore.copyIn(ctx, project.id, uri, "model", ext)) } else uri
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, src) }
                    val m = r.model
                    editor = Editor(m); texData = r.textures; selBone = -1; selMorph = -1; playing = false; frame = 0; total = DEFAULT_FRAMES
                    gl.loadModel(m, r.textures)
                    status = "${m.name.ifBlank { r.sourceName }}\n${m.vertexCount} vértices · ${m.indices.size / 3} triângulos\n" +
                        "${m.materials.size} materiais · ${m.bones.size} ossos · ${m.morphs.size} morphs\n" +
                        "texturas: ${r.textures.count { it != null }}/${m.textures.size}"
                }
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    val propPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando objeto..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext == "x") throw IllegalStateException("Formato .x ainda não é suportado. Use .pmx ou .zip.")
                if (ext != "pmx" && ext != "zip") throw IllegalStateException("Escolha um .pmx ou .zip")
                val meta = withContext(Dispatchers.IO) { ProjectStore.addPropFile(ctx, project.id, uri, name.substringBeforeLast('.'), ext) }
                val r = try { withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.propFile(ctx, project.id, meta))) } }
                    catch (ex: Throwable) { ProjectStore.deletePropFile(ctx, project.id, meta); throw ex }
                gl.addProp(meta.id, r.model, r.textures, meta.x, meta.y, meta.z, meta.s)
                props = props + meta; selProp = props.size - 1
                ProjectStore.saveProps(ctx, project.id, props)
                status = "${meta.name}\n${r.model.vertexCount} vértices · ${r.model.materials.size} materiais\ntexturas: ${r.textures.count { it != null }}/${r.model.textures.size}"
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    LaunchedEffect(audio, audioVol) { try { val v = audioVol.coerceIn(0f, 1f); audio?.setVolume(v, v) } catch (ignored: Throwable) {} }
    LaunchedEffect(playing, total, audio) {
        val a = audio
        // toca o áudio na posição que corresponde ao quadro f (considerando o atraso); antes do atraso fica em silêncio
        fun startAudioAt(f: Float) {
            if (a == null) return
            try {
                val t = (f * 1000f / FPS).toInt() - audioOff
                if (t >= 0 && t < a.duration) { a.seekTo(t); if (!a.isPlaying) a.start() }
            } catch (ignored: Throwable) {}
        }
        // reprodução por tempo real, sincronizada com o vsync: a posição é fracionária (interpola entre os quadros
        // de 30 fps do VMD), então a prévia pode renderizar a 60 fps; se o aparelho não alcança, pula quadros em vez de atrasar
        var pos = frame.toFloat()
        var wrote = frame
        var last = 0L; var lastRender = 0L; var lastTarget = -1f
        if (playing) { startAudioAt(pos); last = withFrameNanos { it } }
        while (playing) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f); last = now
            if (frame != wrote) {   // o usuário mexeu na timeline durante o play
                pos = frame.toFloat(); wrote = frame
                try { if (a != null && a.isPlaying) a.pause() } catch (ignored: Throwable) {}
                startAudioAt(pos)
            } else pos += dt * FPS
            if (a != null && a.isPlaying) {
                val ap = (a.currentPosition + audioOff) / 1000f * FPS
                if (abs(ap - pos) > 3f) pos = ap   // só corrige se o áudio desviou mais de 3 quadros
            }
            if (pos >= total) {
                pos = 0f
                try { if (a != null && a.isPlaying) a.pause() } catch (ignored: Throwable) {}
                startAudioAt(0f)
            } else if (a != null && !a.isPlaying) startAudioAt(pos)
            if (preview60) {
                if (now - lastRender >= 15_000_000L) { lastRender = now; gl.setFramePos(pos) }
            } else {
                val q = floor(pos)
                if (q != lastTarget) { lastTarget = q; gl.setFramePos(q) }
            }
            val fi = pos.toInt()
            if (fi != frame) { frame = fi; wrote = fi }
        }
        if (a != null) { try { if (a.isPlaying) a.pause() } catch (ignored: Throwable) {} }
        gl.setFrame(frame)
    }
    DisposableEffect(Unit) { onDispose { audio?.release(); audio = null } }

    // ---- salvamento automático do projeto
    fun saveNow() {
        if (!restored) return
        try {
            editor?.let { e -> ProjectStore.saveAnim(ctx, project.id, if (e.keyCount() > 0) e.toVmd() else null) }
            ProjectStore.touch(ctx, project.id, total)
        } catch (ignored: Throwable) {}
    }
    fun closeNow() { saveNow(); onClose() }
    BackHandler { closeNow() }
    LaunchedEffect(ed, ver, total, restored) { if (restored) { delay(1500); saveNow() } }
    LaunchedEffect(Unit) { gl.setClearColor(Backgrounds.color(project.bg)) }

    // ---- reabre o que o projeto já tem (modelo, animação, áudio) quando o GL estiver pronto
    LaunchedEffect(glReady) {
        if (!glReady) return@LaunchedEffect
        try {
            val mf = ProjectStore.fileWith(ctx, project.id, "model")
            if (mf != null) {
                isError = false; status = "Abrindo projeto..."
                val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(mf)) }
                val e = Editor(r.model)
                val vf = ProjectStore.animFile(ctx, project.id)
                if (vf.exists()) {
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(vf.readBytes()) }
                    e.load(mo); total = maxOf(project.frames, mo.maxFrame + 1)
                }
                editor = e; texData = r.textures; gl.loadModel(r.model, r.textures)
                status = null
            }
            rig = ProjectStore.loadRig(ctx, project.id); sec = ProjectStore.loadSecondary(ctx, project.id)
            val loaded = ArrayList<PropMeta>()
            for (pm in ProjectStore.loadProps(ctx, project.id)) {
                try {
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.propFile(ctx, project.id, pm))) }
                    gl.addProp(pm.id, r.model, r.textures, pm.x, pm.y, pm.z, pm.s, pm.bone, pm.rx, pm.ry, pm.rz); loaded.add(pm)
                } catch (ignored: Throwable) {}
            }
            props = loaded
            val af = ProjectStore.fileWith(ctx, project.id, "audio")
            if (af != null) {
                audio = withContext(Dispatchers.IO) { MediaPlayer().apply { setDataSource(af.absolutePath); prepare() } }
                ProjectStore.loadAudioCfg(ctx, project.id)?.let { audioName = it.name; audioVol = it.volume; audioOff = it.offsetMs }
                if (audioName == null) audioName = af.name
            }
        } catch (ex: Throwable) { isError = true; status = "Erro ao abrir o projeto: ${ex.message ?: ex.javaClass.simpleName}" }
        restored = true
    }
    LaunchedEffect(frame) { if (!playing) gl.setFrame(frame) }
    // restrições do Rig: valem na prévia e nas exportações (o Animator lê de RigState); salva com atraso
    LaunchedEffect(rig, restored) {
        studio.mmd.rig.RigState.list = rig; gl.refreshPose()
        if (restored) { delay(800); try { ProjectStore.saveRig(ctx, project.id, rig) } catch (ignored: Throwable) {} }
    }
    LaunchedEffect(sec, restored) {
        studio.mmd.rig.RigState.secondary = sec; gl.refreshPose()
        if (restored) { delay(800); try { ProjectStore.saveSecondary(ctx, project.id, sec) } catch (ignored: Throwable) {} }
    }
    DisposableEffect(Unit) { onDispose { studio.mmd.rig.RigState.list = emptyList(); studio.mmd.rig.RigState.secondary = emptyList() } }
    /** Grava o movimento secundário (e restrições) dos ossos dos grupos ativos como keyframes, quadro a quadro. */
    fun bakeSecondary() {
        val e = editor ?: return
        val groups = sec.filter { it.enabled }
        val names = groups.flatMap { it.bones }.distinct().filter { n -> e.model.bones.any { it.name == n } }
        if (names.isEmpty()) { note("Nenhum grupo ativo"); return }
        val to = maxOf(e.allKeyFrames().lastOrNull() ?: 0, if (e.keyCount() == 0) total - 1 else 1)
        baking = true
        scope.launch {
            try {
                val mo = e.motion()
                val r = withContext(Dispatchers.Default) { studio.mmd.rig.Baker.compute(e.model, mo, names, 0, to) }
                val n = e.bakeRotations(names, 0, to) { f -> r.getOrNull(f) }
                sec = sec.map { if (it.enabled) it.copy(enabled = false) else it }
                note("Assado: $n keyframes. Grupos desligados.")
            } catch (ex: Throwable) { note("Erro ao assar: ${ex.message ?: ex.javaClass.simpleName}") }
            baking = false
        }
    }
    // toda edição gera um VmdMotion novo para a thread GL
    LaunchedEffect(ed, ver) { ed?.let { gl.setMotion(it.motion()) } }
    LaunchedEffect(skeleton, selBone) { gl.setOverlay(skeleton, selBone); gl.dragBone = if (skeleton) selBone else -1 }
    LaunchedEffect(skeleton) { if (!skeleton && (mode == TouchMode.ROTATE || mode == TouchMode.MOVE)) { mode = TouchMode.ORBIT; gl.touchMode = mode } }
    LaunchedEffect(toast) { if (toast != null) { delay(2200); toast = null } }
    // painel de status some sozinho (erros ficam até tocar neles)
    LaunchedEffect(status, isError) { if (status != null && !isError) { delay(6000); status = null } }
    SideEffect {
        gl.onTap = { x, y ->
            if (skeleton && editor != null) gl.pickBone(x, y) { idx -> selBone = idx; if (idx >= 0) tab = 1 }
        }
        gl.onBoneDrag = { rotate, v ->
            val e = editor; val b = e?.model?.bones?.getOrNull(selBone)
            if (e != null && b != null) {
                if (rotate) { if (b.flags and 0x0002 != 0) e.nudgeBone(b.name, frame, v, null) else note("Este osso não pode girar") }
                else { if (b.flags and 0x0004 != 0) e.nudgeBone(b.name, frame, null, v) else note("Este osso não pode mover") }
            }
        }
        gl.onBoneDragEnd = { editor?.finishDrag() }
    }
    val selName = ed?.model?.bones?.getOrNull(selBone)?.name
    val hasKey = ed != null && selName != null && ed.hasKey(selName, frame)
    val keys = remember(ed, ver, selName, skeleton) {
        if (ed == null) IntArray(0) else if (skeleton && selName != null) ed.keyFramesOf(selName) else ed.allKeyFrames()
    }
    DisposableEffect(Unit) { gl.onResume(); onDispose { gl.onPause() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowBackIosNew, null, Modifier.clickable { closeNow() }.padding(8.dp).size(18.dp), tint = Color.White)
                Icon(Icons.Default.ViewInAr, null, Modifier.padding(start = 4.dp).size(18.dp), tint = Color.White)
                Text(project.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Box {
                    Icon(Icons.Default.Save, null, Modifier.clickable { exportMenu = true }.padding(8.dp).size(22.dp), tint = Color.White)
                    DropdownMenu(exportMenu, { exportMenu = false }) {
                        DropdownMenuItem(text = { Text("Salvar animação (.vmd)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes") else if (e.keyCount() == 0) note("Nenhum keyframe para salvar")
                            else saver.launch("animacao.vmd")
                        })
                        DropdownMenuItem(text = { Text("Exportar modelo animado (.glb) — recomendado") }, onClick = {
                            exportMenu = false
                            if (editor == null) note("Importe um modelo antes") else glbSaver.launch("${outName()}.glb")
                        })
                        DropdownMenuItem(text = { Text("Exportar vídeo (.mp4)") }, onClick = {
                            exportMenu = false
                            if (exporting) note("Já existe uma exportação em andamento") else videoSaver.launch("${outName()}.mp4")
                        })
                        DropdownMenuItem(text = { Text("Salvar imagem do quadro (.png)") }, onClick = {
                            exportMenu = false; pngSaver.launch("${outName()}_quadro$frame.png")
                        })
                        DropdownMenuItem(text = { Text("Exportar pose do quadro (.vpd)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes") else vpdSaver.launch("${outName()}_pose$frame.vpd")
                        })
                        DropdownMenuItem(text = { Text("Exportar projeto (.zip)") }, onClick = {
                            exportMenu = false; zipSaver.launch("${outName()}_projeto.zip")
                        })
                        DropdownMenuItem(text = { Text("Exportar modelo animado (.fbx)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes")
                            else {
                                val withTex = texData.any { it != null }
                                fbxZip = withTex
                                val base = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }
                                fbxSaver.launch(if (withTex) "$base.zip" else "$base.fbx")
                            }
                        })
                    }
                }
                Icon(Icons.Default.FolderOpen, null, Modifier.clickable { picker.launch(arrayOf("*/*")) }.padding(8.dp).size(22.dp), tint = Color.White)
                Icon(Icons.Default.Close, null, Modifier.clickable { closeNow() }.padding(8.dp).size(20.dp), tint = Color.White)
            }
            Box(Modifier.padding(horizontal = 8.dp)) {
                Row(Modifier.clickable { menu = true }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Viewport de Edição", color = Color.White, fontSize = 12.sp)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Enquadrar tudo") }, onClick = { gl.frameAll(); menu = false })
                    DropdownMenuItem(text = { Text(if (preview60) "Prévia: 60 fps (toque p/ 30)" else "Prévia: 30 fps (toque p/ 60)") }, onClick = {
                        preview60 = !preview60; prefs.edit().putBoolean("preview60", preview60).apply(); menu = false
                        note(if (preview60) "Prévia a 60 fps" else "Prévia a 30 fps (economiza bateria)")
                    })
                    if (Aspects.ratio(project.aspect) > 0f) {
                        DropdownMenuItem(text = { Text(if (guide) "Ocultar moldura ${project.aspect}" else "Mostrar moldura ${project.aspect}") }, onClick = { guide = !guide; menu = false })
                    }
                    listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esquerda" to ViewPreset.LEFT,
                        "Direita" to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { gl.applyPreset(p); menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(4.dp))) {
                AndroidView(factory = { gl }, modifier = Modifier.fillMaxSize())
                val ratio = Aspects.ratio(project.aspect)
                if (guide && ratio > 0f) Canvas(Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height
                    var fw = w; var fh = fw / ratio
                    if (fh > h) { fh = h; fw = fh * ratio }
                    val l = (w - fw) / 2f; val t = (h - fh) / 2f
                    val dim = Color(0x88000000)
                    drawRect(dim, Offset(0f, 0f), Size(w, t)); drawRect(dim, Offset(0f, t + fh), Size(w, h - t - fh))
                    drawRect(dim, Offset(0f, t), Size(l, fh)); drawRect(dim, Offset(l + fw, t), Size(w - l - fw, fh))
                    drawRect(Color.White.copy(alpha = .5f), Offset(l, t), Size(fw, fh), style = Stroke(2f))
                }
                status?.let { Text(it, color = if (isError) Color(0xFFFF6B6B) else Color.White, fontSize = 9.sp, lineHeight = 12.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).widthIn(max = 200.dp).clip(RoundedCornerShape(6.dp))
                        .clickable { status = null }.background(Panel.copy(alpha = .75f)).padding(horizontal = 6.dp, vertical = 4.dp)) }
                toast?.let { Text(it, color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp).background(Panel.copy(alpha = .9f), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) }
                Column(Modifier.align(Alignment.CenterStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha = .85f))) {
                    ToolButton(Icons.Default.OpenWith, mode == TouchMode.ORBIT) { mode = TouchMode.ORBIT; gl.touchMode = mode }
                    ToolButton(Icons.Default.PanTool, mode == TouchMode.PAN) { mode = TouchMode.PAN; gl.touchMode = mode }
                    if (skeleton && ed != null) {
                        ToolButton(Icons.Default.Sync, mode == TouchMode.ROTATE) { mode = TouchMode.ROTATE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para girar") }
                        ToolButton(Icons.Default.ControlCamera, mode == TouchMode.MOVE) { mode = TouchMode.MOVE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para mover") }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ModeChip("Animação", !skeleton && !scenePanel && !audioPanel) { skeleton = false; scenePanel = false; audioPanel = false }
                ModeChip("Esqueleto", skeleton) { if (ed == null) note("Importe um modelo antes") else { skeleton = true; scenePanel = false; audioPanel = false } }
                ModeChip("Cena", scenePanel) { scenePanel = true; skeleton = false; audioPanel = false }
                ModeChip("Áudio", audioPanel) { audioPanel = true; skeleton = false; scenePanel = false }
                Spacer(Modifier.weight(1f))
                Text("%d / %d".format(frame, total - 1), color = Muted, fontSize = 11.sp)
            }
            if (audioPanel) {
                AudioPanel(audioName, try { audio?.duration ?: 0 } catch (e: Throwable) { 0 }, audioVol, audioOff,
                    { picker.launch(arrayOf("audio/*")) },
                    { audioVol = it }, { audioOff = it },
                    {
                        playing = false; audio?.release(); audio = null; audioName = null
                        ProjectStore.deleteAudio(ctx, project.id); note("Áudio removido")
                    },
                    { saveAudio() },
                    Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 8.dp))
            }
            if (scenePanel) {
                ScenePanel(props, selProp, { selProp = it }, ed?.model?.bones?.map { it.name } ?: emptyList(),
                    { propPicker.launch(arrayOf("*/*")) },
                    { i ->
                        props.getOrNull(i)?.let { pm ->
                            gl.removeProp(pm.id); ProjectStore.deletePropFile(ctx, project.id, pm)
                            props = props.filterIndexed { k, _ -> k != i }; selProp = -1
                            ProjectStore.saveProps(ctx, project.id, props)
                        }
                    },
                    { i, pm -> props = props.mapIndexed { k, o -> if (k == i) pm else o }; gl.setProp(pm.id, pm.x, pm.y, pm.z, pm.s, pm.bone, pm.rx, pm.ry, pm.rz) },
                    { ProjectStore.saveProps(ctx, project.id, props) },
                    Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 8.dp))
            }
            if (skeleton && ed != null) {
                SkeletonPanel(ed, frame, tab, { tab = it }, selBone, { selBone = it }, selMorph, { selMorph = it }, { note(it) }, { frame = it }, rig, { rig = it }, sec, { sec = it }, { bakeSecondary() }, baking,
                    Modifier.fillMaxWidth().height(if (tab >= 3) 270.dp else 230.dp).padding(horizontal = 8.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.clickable { playing = !playing }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame - 1).coerceAtLeast(0) }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipNext, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame + 1).coerceAtMost(total - 1) }.padding(8.dp).size(22.dp))
                Spacer(Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.Undo, null, tint = if (ed?.canUndo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ed?.undo() != true) note("Nada para desfazer") }.padding(8.dp).size(22.dp))
                Icon(Icons.AutoMirrored.Filled.Redo, null, tint = if (ed?.canRedo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ed?.redo() != true) note("Nada para refazer") }.padding(8.dp).size(22.dp))
                KeyButton(hasKey, selName != null) {
                    if (ed == null) note("Importe um modelo antes")
                    else if (selName == null) note("Selecione um osso (modo Esqueleto)")
                    else if (hasKey) { ed.deleteKeys(listOf(selName), frame); note("Keyframe removido") }
                    else { ed.keyBones(listOf(selName), frame); note("Keyframe inserido") }
                }
                Text("+1s", color = Muted, fontSize = 12.sp, modifier = Modifier.clickable { total += FPS }.padding(8.dp))
            }
            Timeline(frame, total, keys, Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp, vertical = 4.dp)) { frame = it }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(3.dp).size(34.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Accent else Color.Transparent).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean, onClick: () -> Unit) {
    Text(text, color = if (active) Color.White else Muted, fontSize = 12.sp,
        modifier = Modifier.padding(end = 6.dp).clip(RoundedCornerShape(14.dp))
            .background(if (active) Accent else Panel).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 5.dp))
}

/** Losango de keyframe: cheio = o osso selecionado já tem key neste quadro. */
@Composable
private fun KeyButton(active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Canvas(Modifier.clickable { onClick() }.padding(8.dp).size(22.dp)) {
        val c = center; val r = size.minDimension / 2f * 0.85f
        val p = Path().apply { moveTo(c.x, c.y - r); lineTo(c.x + r, c.y); lineTo(c.x, c.y + r); lineTo(c.x - r, c.y); close() }
        val col = if (enabled) Accent else Muted
        if (active) drawPath(p, col) else drawPath(p, col, style = Stroke(width = 3f))
    }
}

/** Régua de frames com playhead arrastável (um traço por segundo) e losangos nos keyframes. */
@Composable
private fun Timeline(frame: Int, total: Int, keys: IntArray, modifier: Modifier, onSeek: (Int) -> Unit) {
    val last = (total - 1).coerceAtLeast(1)
    Canvas(modifier.background(Color(0xFF101114)).pointerInput(total) {
        detectTapGestures { onSeek((it.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }.pointerInput(total) {
        detectDragGestures { c, _ -> onSeek((c.position.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }) {
        val secs = (last / FPS).coerceAtLeast(1)
        val step = size.width * FPS / last
        for (s in 0..secs) drawLine(Color(0xFF3A3C42), Offset(s * step, 0f), Offset(s * step, 28f), 2f)
        val cy = size.height * 0.6f; val r = 7f
        val diamonds = keys.size <= 800
        for (k in keys) {
            if (k > last) continue
            val kx = k.toFloat() / last * size.width
            if (diamonds) {
                val p = Path().apply { moveTo(kx, cy - r); lineTo(kx + r, cy); lineTo(kx, cy + r); lineTo(kx - r, cy); close() }
                drawPath(p, Color(0xFFFFC857))
            } else drawLine(Color(0xFFFFC857), Offset(kx, cy - r), Offset(kx, cy + r), 2f)
        }
        val x = frame.toFloat() / last * size.width
        drawLine(Accent, Offset(x, 0f), Offset(x, size.height), 3f)
    }
}

/** OutputStream que conta os bytes gravados. */
private class CountOut(private val o: OutputStream) : OutputStream() {
    var count = 0L
    override fun write(b: Int) { o.write(b); count++ }
    override fun write(b: ByteArray, off: Int, len: Int) { o.write(b, off, len); count += len }
    override fun flush() { o.flush() }
    override fun close() { o.close() }
}
