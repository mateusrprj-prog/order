import studio.mmd.edit.*
import studio.mmd.mmd.*
import studio.mmd.rig.*
import kotlin.math.abs

fun ok(v:Boolean, label:String){ if(!v) error("FAIL: $label"); println("PASS: $label") }
fun fixture(): PmxModel {
 val mats=listOf(
  PmxMaterial("A","A",floatArrayOf(1f,1f,1f,1f),FloatArray(3),0f,FloatArray(3),0,FloatArray(4),0f,-1,-1,0,true,0,3),
  PmxMaterial("B","B",floatArrayOf(1f,1f,1f,1f),FloatArray(3),0f,FloatArray(3),0,FloatArray(4),0f,-1,-1,0,true,0,3))
 val bones=listOf(PmxBone("root","root",0f,0f,0f,-1,0,31,-1,-1,0f,null),PmxBone("leftArm","leftArm",0f,1f,0f,0,0,31,-1,-1,0f,null))
 return PmxModel("mesh",2.1f,floatArrayOf(0f,0f,0f,1f,0f,0f,0f,1f,0f,2f,0f,0f),FloatArray(12),FloatArray(8),
 intArrayOf(0,-1,-1,-1,0,-1,-1,-1,1,-1,-1,-1,1,-1,-1,-1),floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f,0f,0f,0f,1f,0f,0f,0f),intArrayOf(0,1,2,1,3,2),emptyList(),mats,bones,emptyList())
}
fun main(){
 val m=fixture()
 val vfxCfg=studio.mmd.fx.FxConfig(enabled=true,count=64,seed=97)
 ok(studio.mmd.fx.FxStyle.entries.all { style ->
   val lines=studio.mmd.fx.ParticleFx.buildLines(vfxCfg.copy(style=style),17f,30f)
   val points=studio.mmd.fx.ParticleFx.buildPoints(vfxCfg.copy(style=style),17f,30f)
   lines.size==64*6 && points.size==64*3 && lines.all{it.isFinite()} && points.all{it.isFinite()}
 },"nine VFX styles generate deterministic finite line trails and soft-point sprites")
 val topo=MeshTopologyAnalyzer.inspect(m)
 ok(topo.validTriangles==2 && topo.boundaryEdges==4 && topo.nonManifoldEdges==0 && topo.connectedComponents==1 && topo.isolatedVertices==0 && topo.zeroAreaUvTriangles==2,"topology diagnostics: open boundaries/components/UV degeneracy")
 val uv=ModelToolsSession(m); uv.selectRange(0,2); val before=uv.buildModel().uvs.copyOf(); val relaxed=uv.relaxSelectedUv(4,.5f)
 ok(relaxed.changed>0 && relaxed.message.contains("borda") && uv.buildModel().uvs.copyOfRange(2,6).contentEquals(before.copyOfRange(2,6)),"UV relax preserves selected chart boundary")
 val atlas=ModelToolsSession(m).materialAtlas()
 ok(atlas.changed>=2 && atlas.message.contains("compartilhados") && atlas.message.contains("costuras"),"material atlas projection safely preserves shared PMX vertices")
 val transfer=WeightTransfer.transfer(m,m,WeightTransferOptions(neighbors=3))
 ok(transfer.transferredVertices==4 && transfer.fallbackVertices==0 && transfer.model.boneIndices[8]==1 && abs(transfer.model.boneWeights[8]-1f)<1e-5,"weight transfer maps names and nearest vertices")
 val paintTransfer=WeightPaintSession(m); val prior=paintTransfer.buildModel().boneIndices.copyOf()
 val applied=paintTransfer.transferFrom(m,WeightTransferOptions(neighbors=3))
 ok(applied.transferredVertices==4 && paintTransfer.canUndo && paintTransfer.undo() && paintTransfer.buildModel().boneIndices.contentEquals(prior),"weight transfer UI operation is atomic and undoable")
 val renamedBones=m.bones.mapIndexed { i,b -> PmxBone("unmatched_$i",b.nameEn,b.x,b.y,b.z,b.parent,b.layer,b.flags,b.tailBone,b.inheritParent,b.inheritWeight,b.ik) }
 val unmatchedTarget=PmxModel(m.name,m.version,m.positions.copyOf(),m.normals.copyOf(),m.uvs.copyOf(),m.boneIndices.copyOf(),m.boneWeights.copyOf(),m.indices.copyOf(),m.textures,m.materials,renamedBones,m.morphs,m.rigidBodies,m.joints,weightTypes=ByteArray(m.vertexCount){3})
 val fallback=WeightTransfer.transfer(m,unmatchedTarget)
 ok(fallback.fallbackVertices==m.vertexCount && fallback.model.weightTypes.all{it.toInt()==0} && (0 until m.vertexCount).all{abs(fallback.model.boneWeights[it*4]-1f)<1e-5},"unmatched bones use valid normalized BDEF1 fallback")
 for(v in 0 until m.vertexCount) ok(abs((0..3).sumOf{transfer.model.boneWeights[v*4+it].toDouble()}.toFloat()-1f)<1e-4,"weight transfer normalizes vertex $v")
 val boxSolver=ClothXpbd.fromMesh(floatArrayOf(0f,0f,0f),intArrayOf())
 boxSolver.setColliders(boxes=listOf(ClothBox(0f,0f,0f,1f,1f,1f)),thickness=.02f)
 val boxFrame=boxSolver.step(1f/30f,gravityY=0f,groundY=null)
 ok((abs(boxFrame[0])>=1.019f || abs(boxFrame[1])>=1.019f || abs(boxFrame[2])>=1.019f) && boxFrame.all{it.isFinite()},"oriented PMX box collider")
 val triSolver=ClothXpbd.fromMesh(floatArrayOf(.2f,.2f,.005f),intArrayOf())
 triSolver.setColliders(triangles=listOf(ClothTriangleCollider(0f,0f,0f,1f,0f,0f,0f,1f,0f)),thickness=.02f,cellSize=.1f)
 val triFrame=triSolver.step(1f/30f,gravityY=0f,groundY=null)
 ok(triFrame[2]>=.019f && triFrame.all{it.isFinite()},"triangle surface collider broadphase/projection")
 println("6 new feature groups verified")
}
