import studio.mmd.mmd.*
import studio.mmd.rig.*

fun main() {
  val bones = listOf(
    PmxBone("下半身","LowerBody",0f,1f,0f,-1,0,0,0,-1,0f,null),
    PmxBone("左足","LeftThigh",-0.1f,0.8f,0f,0,0,0,0,-1,0f,null),
    PmxBone("右足","RightThigh",0.1f,0.8f,0f,0,0,0,0,-1,0f,null),
    PmxBone("スカート前","FrontSkirt",0f,0.9f,0.2f,0,0,0,0,-1,0f,null)
  )
  val mat = PmxMaterial("Pleated skirt","Pleated skirt",floatArrayOf(1f,1f,1f,1f),floatArrayOf(0f,0f,0f),0f,floatArrayOf(0f,0f,0f),0,floatArrayOf(0f,0f,0f,1f),0f,-1,-1,0,false,0,3)
  val model = PmxModel("SkirtGuardTest",2.1f,
    floatArrayOf(-.2f,.6f,.1f, .2f,.6f,.1f, 0f,.7f,.3f),
    floatArrayOf(0f,1f,0f,0f,1f,0f,0f,1f,0f),
    floatArrayOf(0f,0f,1f,0f,0f,1f),
    intArrayOf(1,0,-1,-1, 2,0,-1,-1, 3,0,-1,-1),
    floatArrayOf(.65f,.35f,0f,0f, .65f,.35f,0f,0f, .9f,.1f,0f,0f),
    intArrayOf(0,1,2),emptyList(),listOf(mat),bones,emptyList())
  val p=SkirtGuardAuto.detect(model)
  check(p.detected) { "Saia não foi reconhecida: ${p.notes}" }
  check(p.confidence >= .86f)
  check(p.skirtVertexCount == 3)
  check(p.skirtBones == listOf(3))
  check(p.colliderHints.any { it.role == "thigh" && it.radius > 0f })
  check(SkirtGuardAuto.profile(model).detected)
  check(p.clothCapsules().isNotEmpty())
  println("PASS reconhecimento de material de saia + vértices + confidence")
  println("PASS detecção de osso de saia e hint de colisor de coxa")
  println("PASS cache do perfil automático no carregamento")
  println("RESULT 3/3")
}
