// Harness Kotlin/JVM da 2.5.0. Executado com implementações reais do modelo/Skirt Guard/XPBD; stubs apenas para Animator/Euler.
// Valida o núcleo isolado, não substitui o build Android/Compose/GLES em dispositivo.
fun verifySkirtGuardPlaybackSession(session: studio.mmd.rig.SkirtGuardPlaybackSession,
                                    current: studio.mmd.mmd.Animator,
                                    previous: studio.mmd.mmd.Animator,
                                    model: studio.mmd.mmd.PmxModel) {
    check(session.ready) { session.status }
    val before = model.positions.copyOf()
    val frame = session.step(1f / 30f, current, previous, 0.018f)
    check(frame != null && frame.size == model.positions.size)
    check(frame!!.all { it.isFinite() })
    check(before.contentEquals(model.positions)) { "O preview não deve editar o PMX" }
}
