# Mesh Quality & Soft Regions workflow

## Mesh quality scan
Call `SkirtGuardMeshQuality.analyze(currentPositions, indices, referencePositions?)` on the simulated or baked mesh. Without reference positions, the scan reports topology validity, degeneracy, area and edge statistics. With reference positions, it also counts unusually stretched and collapsed unique edges.

## Soft correction masks
Call `SkirtGuardRegionWeights.build(positions, indices, region, softness, diffusionIterations, diffusion, baseMask)` to produce a per-vertex [0,1] mask. Regions are `ALL`, `FRONT`, `BACK`, `LEFT`, `RIGHT`. A `baseMask` can limit the effect to preselected vertices/materials. Optional diffusion smooths weights over mesh adjacency and is capped at 32 iterations. A zero-valued base mask remains zero after diffusion (excluded vertices do not receive mask bleed). It returns a separate array and does not modify input positions or indices.

## Integration example
Use the generated weights to multiply correction strength per vertex, or pass them to a correction stage that supports soft masks. The existing Skirt Guard regional Auto-Fix remains available. The new API is not yet wired to viewport paint controls in this release.
