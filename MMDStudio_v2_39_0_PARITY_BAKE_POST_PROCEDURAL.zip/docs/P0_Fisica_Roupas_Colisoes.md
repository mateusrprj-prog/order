# MMD Studio — P0: Física de roupas, colisão corporal e movimento secundário

**Origem:** vídeo enviado pelo usuário em 20/11/2026 (`1000243628.mp4`).  
**Base auditada:** código-fonte do `MMDStudio_v1_30_2_CENA_TRANSFORMAVEL.zip`.  
**Status:** especificação/planejamento técnico. **Nenhuma simulação de tecido ou colisão corpo–roupa foi implementada nesta nota.** A versão do app permanece 1.30.2.

## 1. Problema observado

Na animação enviada, as personagens fazem movimentos de dança com elevação e cruzamento das pernas. Em alguns desses movimentos, a perna atravessa visualmente a saia; a saia não se afasta/deforma o suficiente para acompanhar o volume da perna e o movimento do quadril. O resultado parece rígido e inconsistente.

O objetivo não é fazer a perna esticar ou deformar o esqueleto para acomodar a roupa. **O corpo animado deve continuar sendo a referência; a roupa deve reagir à aproximação e ao contato com o corpo.** A colisão deve corrigir a posição da roupa, não deslocar a perna para fora da animação.

## 2. Auditoria confirmada na v1.30.2

| Área | O que o código faz hoje | Limite relevante |
|---|---|---|
| `rig/Physics.kt` — `PhysEngine` | Simula corpos rígidos e juntas do PMX; tem passo fixo/subpassos, colisões aproximadas entre corpos rígidos e colisão com chão | `collide()` percorre `m.rigidBodies`; não testa os vértices da saia contra a superfície/cápsulas da perna |
| `PhysConfig.collisions` | Liga/desliga colisões entre corpos rígidos | Não significa colisão de malha, tecido ou corpo deformável |
| `rig/Constraints.kt` — `Secondary` | Aplica mola/amortecimento à rotação global dos ossos reconhecidos | Não move vértices da roupa por contato e não impede interpenetração |
| `rig/AutoPhysics.kt` | Reconhece nomes/cadeias como cabelo, saia, roupa e acessórios; cria grupos `Secondary` | Reconhecimento por nome/corpo rígido não cria, por si só, colisores corporais nem simulação de tecido |
| `mmd/PmxModel.kt` | Guarda `softBodyCount` e `softBodyRaw` do PMX 2.1 | Os dados são preservados como bytes, sem estrutura interpretada pelo motor |
| `rig/PhysCache.kt` | Faz bake de poses dos ossos controlados pela física | Não armazena estado de vértices de tecido |
| `ui/EditPanels.kt` | Expõe física MMD e movimento secundário em painéis separados | A UI atual pode dar a impressão de que “Auto: reconhecer física” resolve a colisão da saia, mas não resolve |

**Conclusão:** o defeito observado não deve ser tratado apenas ajustando gravidade, rigidez ou amortecimento. Falta uma camada real de colisão entre a roupa e o corpo e, para roupas sem cadeia PMX adequada, falta também uma solução de tecido/deformação.

## 3. Objetivo funcional

1. Uma perna nunca deve atravessar a saia de forma visível em movimentos normais de dança, caminhada, corrida ou chute, dentro dos limites da malha e da qualidade de simulação escolhida.
2. A saia deve acompanhar o quadril, balançar por inércia e se afastar quando a coxa ou o joelho se aproximar.
3. A perna e o restante do esqueleto continuam seguindo a animação original. O solver não deve “esticar a perna” nem alterar keyframes do usuário para resolver o contato.
4. Cabelo, mangas, casacos, gravatas, fitas e acessórios devem poder reutilizar a mesma infraestrutura, com presets diferentes.
5. Prévia, reprodução, scrub da timeline, bake, captura e exportação devem produzir o mesmo resultado por frame.
6. O recurso deve ser opcional e escalável para Android: começar com poucos colisores e solver leve; elevar qualidade sob demanda.

## 4. Arquitetura proposta — não misturar os três sistemas

### A. Física MMD de corpos rígidos (sistema existente)

Manter `PhysEngine` para os corpos rígidos e juntas descritos no PMX. Melhorar estabilidade, debug e compatibilidade sem rebatizar essa opção como tecido.

### B. Colisores do corpo (nova camada)

Criar colisores cinemáticos ligados à pose animada do personagem. O conjunto inicial deve incluir:

- pelve/quadril;
- coxa esquerda e direita;
- joelho esquerdo e direito;
- panturrilha/perna inferior esquerda e direita;
- opcionalmente tronco, ombros e braços para mangas/casacos.

Começar com cápsulas e esferas, com dimensões editáveis e uma margem pequena de segurança. A posição/orientação de cada colisor vem da pose global do osso naquele frame. Colisores corporais são cinemáticos: seguem o movimento e não empurram o esqueleto.

A detecção deve tratar movimento rápido. Se um colisor atravessar o tecido entre dois passos, usar subpassos/continuous collision detection simplificada para reduzir *tunneling*.

### C. Física de roupa/tecido (novo sistema)

Não depender somente de `Secondary`. A roupa precisa de partículas/vértices simulados e restrições entre eles, mantendo os pontos presos ao rig/pele onde necessário.

Solver recomendado para Android: **PBD/XPBD**, com passo fixo e número limitado de iterações. Restrições mínimas:

- distância/alongamento entre vértices vizinhos;
- cisalhamento onde a topologia permitir;
- flexão entre segmentos para evitar tecido sem forma;
- ancoragem/pinos em vértices próximos à cintura, ombros ou pontos definidos pelo rig;
- colisão tecido–corpo;
- auto-colisão do tecido como etapa posterior e opcional.

A simulação deve começar a partir da malha já deformada pela animação/esqueleto (e morphs aplicáveis), aplicar a correção física na roupa e então enviar a geometria resultante ao renderer. Não alterar o esqueleto para resolver colisões.

### D. Fontes de configuração

1. **PMX 2.1:** interpretar dados *soft body* em estruturas tipadas, incluindo configurações, anchors e pins. O round-trip atual dos bytes brutos deve continuar preservado para não perder dados desconhecidos.
2. **PMX sem soft body:** permitir criar uma roupa simulada a partir de grupos de vértices/cadeias de ossos selecionados, com pontos de ancoragem definidos pelo usuário.
3. **GLB/glTF/OBJ:** oferecer configuração manual de grupos de roupa/âncoras/colisores quando os dados necessários não existirem no arquivo.
4. Não declarar simulação automática perfeita para qualquer modelo: malhas sem topologia útil, sem pesos adequados ou com rig defeituoso podem exigir ajuste manual.

## 5. Ordem de implementação

### P0-A — Diagnóstico e colisores corporais

- [ ] Exibir os corpos rígidos PMX e os grupos de ossos reconhecidos, com nome, modo, grupo/máscara e osso associado.
- [ ] Criar visualização de debug dos colisores no viewport (cápsulas/esferas em wireframe), com liga/desliga.
- [ ] Criar gerador inicial de cápsulas corporais baseado em ossos humanoides; permitir editar raio/comprimento/offset.
- [ ] Garantir que os colisores sigam a pose animada inclusive durante IK, morph de osso, root transform e scrub.
- [ ] Verificar que as máscaras/grupos não bloqueiem acidentalmente contato tecido–corpo.
- [ ] Adicionar testes matemáticos de transformação, interseção, distância, contato e casos degenerados.

### P0-B — Saia/roupa com colisão

- [ ] Criar representação física leve para as partes selecionadas da roupa (pontos/vértices + restrições + âncoras).
- [ ] Implementar colisão entre os pontos/triângulos simulados e as cápsulas corporais.
- [ ] Resolver penetração projetando a roupa para fora do colisor, com margem configurável; nunca deslocar a perna.
- [ ] Adicionar amortecimento, atrito e limite de correção para evitar tremor/explosão.
- [ ] Usar passo fixo e subpassos com limites seguros; detectar NaN/instabilidade e restaurar estado estável.
- [ ] Testar primeiro uma saia com movimento de caminhada, chute frontal, chute lateral, perna cruzada e agachamento.

### P0-C — Bake determinístico e integração

- [ ] Estender o cache para armazenar o estado físico necessário da roupa, não só transformações de ossos.
- [ ] Incluir assinatura do modelo/topologia, malha/grupo simulado, animação, rig, colisores, parâmetros, FPS e versão do solver na chave do cache.
- [ ] Fazer scrub, reprodução e exportação consultarem o mesmo bake determinístico.
- [ ] Invalidar o cache sempre que animação, geometria, morphs, rig, colisores ou parâmetros mudarem.
- [ ] Persistir configurações no projeto e restaurá-las ao reabrir.

### P1 — PMX 2.1 e configuração automática

- [ ] Interpretar o bloco PMX 2.1 Soft Body em vez de apenas preservar os bytes.
- [ ] Mapear materiais/partes de malha e soft bodies para grupos editáveis.
- [ ] Melhorar detecção de saia/cabelo/roupa com nomes japonês, inglês e português, mas permitir correção manual.
- [ ] Criar presets separados: Saia, Cabelo, Manga, Casaco, Gravata/Fita e Acessório.
- [ ] Permitir pintar/selecionar vértices fixos e ajustar as âncoras.

### P2 — Qualidade avançada

- [ ] Auto-colisão da roupa para reduzir atravessamento da própria saia.
- [ ] Melhor tratamento de dobras e rigidez por material.
- [ ] Vento e forças externas por área da cena.
- [ ] Perfis de qualidade e LOD de simulação por distância/visibilidade.
- [ ] Ferramentas de diagnóstico de malha, pesos, âncoras e colisores.

## 6. UI proposta

Na área **Rig → Física**, separar visualmente as funções:

- **Corpos rígidos MMD:** controles já existentes de gravidade, mola, amortecimento, vento, colisões entre rigid bodies e chão.
- **Colisão do corpo:** liga/desliga colisores cinemáticos, escolhe perfil anatômico, mostra debug, edita raio/comprimento/margem.
- **Roupa / tecido:** lista de grupos de tecido, adicionar grupo, auto-detectar, selecionar malha/material/cadeia, definir âncoras, preset, rigidez, flexão, amortecimento, atrito e qualidade.
- **Bake da roupa:** calcular, cancelar, limpar, mostrar progresso e informar quando o cache foi invalidado.

Não reutilizar o rótulo “Colisão entre corpos” para a colisão da roupa. Os conceitos precisam ficar claros para o usuário.

## 7. Regras para evitar regressões

- O sistema antigo de corpos rígidos deve continuar funcionando em modelos PMX que já o usam.
- Quando a física de roupa estiver desligada, o resultado deve coincidir com o skinning atual, sem deslocamento residual.
- Desligar/ligar ou mudar preset não pode modificar keyframes originais.
- O solver não deve criar alocações grandes a cada frame; reutilizar buffers.
- Cálculo pesado deve ocorrer fora da thread de UI; renderer recebe buffers prontos.
- Suportar cancelamento, erros e restauração do último estado válido.
- As instâncias de personagem devem ter estado de física independente; não usar `RigState` global compartilhado entre personagens.
- Não remover nem descartar `softBodyRaw` enquanto a interpretação PMX 2.1 ainda estiver incompleta.

## 8. Critérios de aceitação no aparelho

Usar um modelo real com saia e uma animação que contenha pelo menos: caminhada, elevação da coxa, chute frontal, chute lateral, pernas cruzadas e agachamento.

1. Sem simulação de roupa, registrar o comportamento base para comparação.
2. Com colisão corporal e saia ativadas, a perna não deve atravessar visivelmente a saia nas poses de teste; a roupa deve ceder e recuperar forma sem tremer excessivamente.
3. O esqueleto e os keyframes da perna devem permanecer idênticos ao movimento de origem.
4. Parar em um frame, avançar quadro a quadro, reproduzir e exportar: o resultado deve ser consistente.
5. Fechar/reabrir o projeto: grupos, âncoras, parâmetros e bake persistem conforme especificado.
6. Desativar a física: a malha retorna ao resultado de skinning sem offsets antigos.
7. Medir FPS, memória, aquecimento e tempo de bake no POCO X7 Pro; registrar qualidade usada e tamanho da malha.
8. Repetir com mais de uma personagem na cena para confirmar isolamento por instância.

**Não aceitar como concluído** uma tela com sliders, uma simulação que só balança ossos, ou um corpo rígido que colide apenas com outro corpo rígido. A prova é a roupa efetivamente reagir à perna na geometria renderizada e manter o resultado na exportação.

## 9. Observação de compatibilidade e escopo

A simulação real de tecido é uma evolução maior do motor, não um ajuste cosmético. Deve ser entregue em etapas pequenas, com build e validação no Android a cada etapa. Priorizar primeiro a saia do vídeo e colisão das pernas; depois reutilizar a base em cabelo, mangas, casacos e acessórios.
