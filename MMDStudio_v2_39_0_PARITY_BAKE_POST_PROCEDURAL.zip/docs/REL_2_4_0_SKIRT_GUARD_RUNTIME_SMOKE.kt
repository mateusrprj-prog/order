import studio.mmd.mmd.*
import studio.mmd.rig.*

private fun bone(name: String, en: String, x: Float, y: Float, parent: Int) =
    PmxBone(name, en, x, y, 0f, parent, 0, 0, -1, -1, 0f, null)

private fun sampleModel(): PmxModel {
    val bones = listOf(
        bone("センター", "center", 0f, 1f, -1),
        bone("左足", "thigh_L", -0.2f, 0.8f, 0),
        bone("左ひざ", "knee_L", -0.2f, 0.4f, 1),
        bone("左足首", "ankle_L", -0.2f, 0.1f, 2),
        bone("右足", "thigh_R", 0.2f, 0.8f, 0),
        bone("右ひざ", "knee_R", 0.2f, 0.4f, 4),
        bone("右足首", "ankle_R", 0.2f, 0.1f, 5),
        bone("スカート前", "front_skirt", 0f, 0.75f, 0)
    )
    val material = PmxMaterial("Saia plissada", "Pleated skirt", floatArrayOf(1f,1f,1f,1f),
        floatArrayOf(0f,0f,0f), 0f, floatArrayOf(0f,0f,0f), 0, floatArrayOf(0f,0f,0f,1f),
        0f, -1, -1, 0, false, 0, 3)
    return PmxModel("SkirtGuardRuntime", 2.1f,
        floatArrayOf(-0.25f,0.65f,0.1f, 0.25f,0.65f,0.1f, 0f,0.6f,0.2f),
        FloatArray(9), FloatArray(6),
        intArrayOf(7,1,-1,-1, 7,4,-1,-1, 7,0,-1,-1),
        floatArrayOf(0.9f,0.1f,0f,0f, 0.9f,0.1f,0f,0f, 0.9f,0.1f,0f,0f),
        intArrayOf(0,1,2), emptyList(), listOf(material), bones, emptyList())
}

fun main() {
    val model = sampleModel()
    val profile = SkirtGuardAuto.detect(model)
    check(profile.detected && profile.skirtVertexCount == 3) { "Saia não reconhecida" }
    val pose = SkirtGuardRuntime.pose(model, profile, 0.02f) { _, x, y, z, out ->
        out[0] = x + 1f; out[1] = y - 0.25f; out[2] = z + 0.5f
    }
    check(pose.capsules.size >= 4) { "Esperava cápsulas de quadril, coxas e panturrilhas: ${pose.capsules.size}" }
    check(pose.source.startsWith("BodyColliders")) { "Não usou o plano anatômico: ${pose.source}" }
    val c = pose.capsules.first()
    check(c.ax > -0.5f && c.radius >= 0.02f) { "Transformação/folga não aplicada" }
    check(profile.colliderHints.none { it.boneName.contains("足首") }) { "Tornozelo japonês foi classificado incorretamente como coxa" }
    println("PASS 1: detecção automática de saia, extração de vértices e distinção de tornozelo japonês")
    println("PASS 2: auto-connect anatômico gera cápsulas para coxas/panturrilhas/quadril")
    println("PASS 3: cápsulas acompanham transformação da pose e margem configurável")

    val midX = (c.ax + c.bx) * 0.5f; val midY = (c.ay + c.by) * 0.5f; val midZ = (c.az + c.bz) * 0.5f
    val diagnostic = SkirtGuardDiagnostics.measure(floatArrayOf(midX,midY,midZ), intArrayOf(0), listOf(c))
    check(diagnostic.testedVertices == 1 && diagnostic.penetratingVertices == 1 && diagnostic.maxPenetration > 0f) {
        "Diagnóstico não detectou interpenetração: $diagnostic"
    }
    println("PASS 4: diagnóstico identifica vértices dentro do volume da perna")

    val solver = ClothXpbd.fromMesh(floatArrayOf(0f,0.5f,0f, 0.01f,0.5f,0f, -0.01f,0.5f,0f), intArrayOf(), particleMass = 1f)
    solver.setColliders(capsules = listOf(ClothCapsule(0f,0f,0f, 0f,1f,0f, 0.2f)), thickness = 0.01f)
    val projected = solver.step(1f / 30f, gravityY = 0f, substeps = 1, iterations = 2, damping = 0f, groundY = null)
    val distanceX = kotlin.math.sqrt(projected[0]*projected[0] + (projected[1]-0.5f)*(projected[1]-0.5f) + projected[2]*projected[2])
    check(distanceX >= 0.199f) { "XPBD não projetou a partícula para fora da cápsula: $distanceX" }
    println("PASS 5: solver XPBD projeta vértices para fora das cápsulas")

    val noSkirt = profile.copy(detected = false, regions = emptyList())
    check(SkirtGuardRuntime.restPose(model, noSkirt).capsules.isEmpty())
    println("PASS 6: perfil sem saia não cria colisores falsos")

    val rigidModel = PmxModel(model.name, model.version, model.positions, model.normals, model.uvs,
        model.boneIndices, model.boneWeights, model.indices, model.textures, model.materials, model.bones, model.morphs,
        rigidBodies = listOf(PmxRigid("left thigh body", "left thigh body", 1, 0, 2, 0f, 0f, 0f, 0,
            size = floatArrayOf(0.08f, 0.3f, 0f), pos = floatArrayOf(-0.2f, 0.6f, 0f))))
    val rigidPose = SkirtGuardRuntime.restPose(rigidModel)
    check(rigidPose.capsules.size == BodyColliders.plan(rigidModel).colliders.size) {
        "Fallback duplicou cápsula sobre osso já coberto por rigid body PMX: ${rigidPose.capsules.size} vs ${BodyColliders.plan(rigidModel).colliders.size}"
    }
    check(rigidPose.pmxCoveredSegments == 1) { "Não informou a cobertura PMX existente: ${rigidPose.pmxCoveredSegments}" }
    println("PASS 7: auto-connect não duplica osso coberto por rigid body PMX")
    check(profile.colliderHints.none { it.role == "thigh" && it.boneName.contains("足首") })
    println("PASS 8: os nomes japoneses de tornozelo não geram hints falsos de coxa")
    println("RESULT 8/8")
}
