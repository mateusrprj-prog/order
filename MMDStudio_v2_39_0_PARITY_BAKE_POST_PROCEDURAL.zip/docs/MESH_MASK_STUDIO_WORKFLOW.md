# Mesh Mask Studio — fluxo prático

## Preparar
- Abra o PMX e entre em Model Tools.
- Use o Diagnóstico para identificar componentes conectados, bordas abertas, duplicatas e triângulos degenerados.
- Se a peça está soldada ao corpo, selecione o material da saia antes de trabalhar para evitar máscaras em outras partes.

## Criar uma máscara
- Na aba Máscaras, escolha uma das regiões automáticas ou pinte na viewport.
- `Pintar` aproxima o valor ao alvo; `Adicionar` aumenta; `Apagar` reduz.
- Ative `Espelhar pincel no eixo X` para aplicar o mesmo stroke ao outro lado da caixa delimitadora.
- O preview ciano mostra os vértices com valor acima de 0,05; o painel mostra contagem e média.
- Undo/Redo máscara desfaz apenas a pintura/edição da máscara, não a geometria.

## Corrigir a forma
- `Selecionar vértices pela máscara` permite combinar a máscara com as ferramentas tradicionais de seleção.
- `Relaxar pela máscara` usa Taubin e protege bordas abertas por padrão. Comece com 2–4 iterações e intensidade baixa.
- `Micro relax` é uma segunda operação mais discreta, útil para suavizar pequenas transições.
- `Remover picos / espigões` procura vértices com afastamento local acima da escala das arestas vizinhas. Comece com limiar alto e limite baixo.
- O Undo/Redo geral do painel afeta geometria; o Undo/Redo máscara afeta somente a máscara temporária.

## Guardar resultado
- Confira a geometria no viewport e use o diagnóstico de malha.
- Toque em `Salvar no projeto` para escrever a versão editada do PMX e atualizar o modelo da cena.
- A máscara atual não será reaberta como pintura quando o projeto for carregado novamente. Gere ou pinte uma nova máscara ao retomar a edição.

## Cuidados
- Evite relaxamento forte em malhas com triângulos muito longos ou muito pequenos.
- Preserve detalhes finos reduzindo a intensidade e aumentando o limiar de remoção de picos.
- Em modelos assimétricos, desligue o espelhamento X ou confira visualmente as regiões correspondentes.
- A máscara e o preview são ferramentas de edição; não substituem weight paint, rig ou simulação física do Cloth Studio.
