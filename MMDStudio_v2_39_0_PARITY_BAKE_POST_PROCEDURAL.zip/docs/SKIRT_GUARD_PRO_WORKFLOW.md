# Skirt Guard Pro — fluxo de trabalho 2.6.0

## Preview no viewport

1. Importe o PMX com a saia.
2. Abra Cloth Studio e selecione `Saia detectada`.
3. Ative `Skirt Guard`.
4. Para usar o solver na viewport, ligue `Simular saia durante playback`.
5. Mantenha `Colisão com superfície real do corpo` ligada para usar os triângulos corporais deformados, além das cápsulas anatômicas.
6. Ajuste `Faixa de âncora da cintura` apenas quando o modelo não apresentar influência pélvica adequada. Se houver pesos confiáveis no osso da cintura, eles têm prioridade.
7. Ajuste `Qualidade do preview` entre 2 e 8 iterações. Aumentar a qualidade aumenta o custo de CPU.

O preview está limitado a 4.500 vértices de saia e uma amostra padrão de até 1.800 triângulos corporais próximos. Pode reduzir FPS em dispositivos modestos. Ele não altera os vértices/weights do PMX.

## Bake completo

1. Defina `Quadro inicial = 0`.
2. Escolha `Quadros do trecho`.
3. Configure gravidade, vento, subpassos, iterações e colisões.
4. Execute `Gerar bake XPBD`.
5. Aguarde a gravação do cache e examine o relatório Skirt Guard.

## Bake parcial

1. Gere primeiro um cache completo compatível desde o quadro 0.
2. Defina o primeiro quadro e a quantidade de quadros do novo trecho.
3. O sistema simula sequencialmente desde o quadro 0 para aquecer o XPBD, grava apenas o trecho solicitado e preserva os frames fora dele.
4. O intervalo não pode pular uma lacuna antes do fim do cache existente.

**Atenção:** a assinatura do cache não inclui o arquivo VMD nem todos os parâmetros do solver. Se mudar a animação, gravidade, vento, colisores, topologia/seleção ou qualidade física, limpe o cache e faça um bake completo antes de continuar com intervalos parciais.

## Exportação

A captura/exportação ignora o estado transitório do preview. Para vídeo final, use o cache do bake offline. Inspecione movimentos extremos, principalmente cruzamento de pernas, agachamento, giros rápidos e poses com a saia comprimida.
