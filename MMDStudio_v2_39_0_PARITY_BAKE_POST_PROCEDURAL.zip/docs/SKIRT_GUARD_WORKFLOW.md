# Skirt Guard — fluxo de uso

## O que acontece ao importar o PMX

1. `PmxParser.parse()` chama `SkirtGuardAuto.profile(model)` depois de ler o modelo.
2. Materiais com nomes de saia (inglês/japonês) são correlacionados com os triângulos e vértices correspondentes. Evidência de pesos em bones de saia também pode classificar materiais sem nome explícito, desde que haja evidência suficiente.
3. A seleção inicial do Cloth Studio passa para `Saia detectada` quando existe perfil de saia e a seleção ainda está no modo padrão.
4. Skirt Guard fica ativo por padrão. O liga/desliga e a margem são gravados em `skirt_guard.json`, com arquivo temporário, backup e substituição atômica.

## Fazer a correção física

1. Abra **Cloth Studio** e confira o cartão `SKIRT GUARD AUTO`, a confiança, as regiões e a contagem de vértices.
2. Confirme a seleção `Saia detectada`. Para trabalhar em apenas um painel, escolha o material correspondente ou use outra seleção.
3. Mantenha **Seguir animação, IK e morphs** ligado para que as cápsulas sigam a pose em cada quadro do bake.
4. Mantenha **Skirt Guard · colisão automática pernas/saia** ligado. A margem inicial é `0.018` unidade do modelo; aumente em passos pequenos (por exemplo, `0.022` ou `0.028`) se ainda houver clipping. Reduza se a roupa ficar afastada demais.
5. Aumente as iterações para 12–16 e os subpassos para 6–8 em movimentos rápidos ou poses extremas. O custo aumenta com a quantidade de vértices simulados e quadros.
6. Execute **Gerar bake XPBD**. O bake calcula as cápsulas na pose de cada quadro, executa a projeção de colisão do solver e grava o cache local pré-skinning.
7. Leia a notificação final: ela informa quantas cápsulas próprias foram usadas, quantos segmentos já eram cobertos por rigid bodies PMX e o clipping residual medido contra as cápsulas adicionais.

## Entender o Auto-Connect

O Auto-Connect conecta os colisores anatômicos de quadril, coxas e panturrilhas aos bones. A cada frame, os extremos das cápsulas são transformados pelo estado global dos bones do `Animator`, incluindo FK/IK e movimento animado. Rigid bodies cinemáticos PMX já ligados ao mesmo segmento são respeitados para evitar colisores duplicados; o relatório identifica essa cobertura.

A operação não troca os quatro índices/weights de skinning do PMX. Ela protege a roupa pelo solver físico do bake e grava o resultado no cache de tecido. Isso preserva o modelo original e permite limpar ou refazer o bake.

## Preview de tecido no playback (v2.5.0)

1. No Cloth Studio, habilite **Simular saia durante playback (preview CPU)**. A opção fica desativada por padrão e é salva por projeto.
2. Dê Play ou avance a timeline. O renderer cria uma sessão compacta apenas com triângulos/vértices da região detectada, ancora a faixa superior da cintura (por pesos pélvicos; se não houver pesos reconhecidos, usa fallback pela parte mais alta da malha) e executa XPBD de baixo custo.
3. As cápsulas anatômicas são recalculadas com a pose corrente. A sessão inclui auto-colisão XPBD quando há até 2.048 vértices de saia; o limite geral de preview é 4.500 vértices.
4. Para aparelhos lentos, desligue o preview. Para produção, ajuste iterações/subpassos e use **Gerar bake XPBD**. Se existir cache baked válido, ele tem prioridade sobre o preview.
5. O preview transitório é removido durante captura/exportação. A exportação usa o cache baked, quando disponível, ou a malha original; não depende do estado temporário da viewport.

## Diagnóstico e limites

- **Analisar pose atual** calcula penetração de vértices contra cápsulas, proximidade entre pares não vizinhos e possíveis cruzamentos entre triângulos não adjacentes da saia. O overlay desenha cápsulas em âmbar e vértices sinalizados em vermelho.
- **Auto-Fix limitado no bake** projeta somente uma cópia da saída simulada. O limite configurável é um deslocamento total máximo por vértice, para impedir correções exageradas; PMX e pesos originais permanecem intactos.
- A análise de triângulos usa broadphase AABB + teste segmento-triângulo; ela pode não detectar coplanaridade, contatos tangenciais ou todas as interseções degeneradas. A auto-colisão XPBD está limitada a 2.048 vértices no preview.
- Corpos rígidos PMX dinâmicos (modo 1/2) não são re-simulados pelo bake. O preview é CPU, opcional e pode reduzir FPS em dispositivos limitados.
- Se a saia não for reconhecida, verifique os nomes dos materiais ou selecione manualmente um material. Se não houver bones de coxa/joelho reconhecidos, o auto-connect não cria cápsulas às cegas nem modifica os pesos.
