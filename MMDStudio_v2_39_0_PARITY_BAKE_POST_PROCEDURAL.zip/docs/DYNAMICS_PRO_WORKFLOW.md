# Workflow — Skirt Guard Dynamics Pro (v2.7.0)

## Preparar a saia

1. Abra o projeto e carregue o PMX.
2. Abra **Cloth Studio**.
3. Se o detector encontrar uma saia, escolha **Saia detectada** para selecionar a região automaticamente.
4. Mantenha **Seguir animação, IK e morphs** ligado quando o bake for usado com VMD.
5. Mantenha **Skirt Guard** ligado para gerar cápsulas de quadril/pernas.

## Configurar colisão e tecido

- Aumente a espessura de colisão em passos pequenos se a roupa ainda entrar na perna.
- Aumente subpassos/iterações quando o movimento for rápido ou a malha for mais rígida; isso aumenta o custo da CPU.
- Ajuste gravidade e vento com cautela.
- A colisão de superfície acompanha skinning/morphs, mas é discreta por quadro. A CCD aproximada cobre as cápsulas anatômicas, segmentadas por subpasso.
- A auto-colisão própria é limitada a 2.048 vértices nesta rota do solver.

## Corrigir uma região

1. Ative **Auto-Fix limitado no bake**.
2. Escolha Toda, Frente (+Z), Trás (-Z), Esquerda (-X) ou Direita (+X).
3. Comece com limite pequeno e aumente apenas quando necessário.
4. Execute o bake.
5. Leia as métricas de qualidade e o diagnóstico de triângulos exibidos ao final.

O Auto-Fix opera sobre a cópia simulada e mantém o PMX original intacto. As regiões vizinhas recebem transição suave para evitar um degrau na malha.

## Desfazer/refazer

Após um bake com correção real no último quadro, o painel mostra **Desfazer Auto-Fix** e **Refazer Auto-Fix**. Esses botões atuam somente sobre o último quadro armazenado no histórico do bake mais recente. Um novo bake limpa esse histórico. A operação persiste o quadro corrigido/desfeito no cache do projeto.

## Bake parcial e cache

- O cache v4 é vinculado a modelo PMX, VMD e parâmetros físicos.
- Para iniciar um intervalo depois do quadro zero, precisa existir cache v4 compatível e sem lacuna.
- Se trocar PMX, pesos, morph, bones/IK, VMD, FPS, seleção ou parâmetro físico, gere um bake completo desde o quadro zero.
- Caches v1/v2/v3 são legíveis para diagnóstico/migração, mas não são aplicados nem mesclados pelo fluxo seguro 2.7.0. Um bake completo grava o formato 4.
- Mudanças no algoritmo de simulação precisam atualizar a revisão incluída na `clothBakeSimulationSignature`.

## Como interpretar os diagnósticos

- `arestas estiradas`: comprimento atual excedeu o limite do relatório.
- `arestas colapsadas`: relação comprimento/repouso ficou abaixo do limite crítico.
- `deformação média`: strain médio absoluto das constraints avaliadas.
- `pares de triângulos cruzados`: interseções detectadas pelo broadphase + segmento-triângulo no último quadro. O teste tem orçamento de candidatos e pode não detectar contatos coplanares/degenerados; use inspeção visual também.

## Limites práticos

A CCD de cápsulas é aproximada e lineariza a trajetória de cada subpasso. A superfície triangular do corpo não recebe CCD contínua. O diagnóstico de auto-interseção é auxiliar; ele não substitui um solver completo de contato malha-malha. O desempenho depende do número de vértices, triângulos, subpassos, iterações e colisores.
