# Mesh Mask Studio Pro — fluxo de trabalho (2.10.0)

## Abrir a ferramenta
1. Importe/abra um PMX no MMD Studio.
2. Abra **Model Tools** e escolha a aba **Máscaras**.
3. Ative **Pintar máscara diretamente na viewport** para usar o dedo sobre a superfície do personagem.

## Configurar o pincel
- **Raio do pincel:** alcance em unidades locais do PMX.
- **Força:** intensidade aplicada em cada amostra.
- **Valor alvo:** valor que o modo Replace tenta alcançar.
- **Pintar / Adicionar / Apagar:** substitui progressivamente, soma influência ou subtrai influência.
- **Espelhar X:** repete o traço do outro lado do centro do modelo.
- **Pincel geodésico:** mede a distância por arestas da malha; use quando duas camadas de tecido/corpo estiverem muito próximas e não quiser que a pintura atravesse de uma para outra.
- **Falloff:** Linear, Suave, Afiado ou Constante.

O gesto é agrupado como uma operação Undo. O painel mostra quantos vértices têm influência e quantas entradas de histórico estão disponíveis. Para modelos acima de 250 mil vértices, desative o modo geodésico por segurança de CPU/memória.

## Preparar uma região
A seção **Geração automática de região** cria máscaras TODA, FRENTE, TRÁS, ESQUERDA ou DIREITA. Também pode preencher a seleção atual, preencher tudo, inverter, limpar e suavizar.

A suavização atua na conectividade dos triângulos. Ela não muda a geometria; modifica somente os pesos temporários da máscara.

## Aplicar à malha
1. Ajuste o limiar para selecionar vértices influenciados.
2. Use **Selecionar vértices pela máscara** para transformar a influência em seleção.
3. Para correção de superfície, ajuste iterações Taubin, força e limite de movimento.
4. Execute **Relaxar pela máscara**, **Micro relax** ou **Remover picos/espigões**.
5. Revise o resultado na viewport e salve o modelo/projeto para persistir a geometria.

Os vértices com máscara zero permanecem fixos nas operações mascaradas. As correções têm teto de deslocamento e podem preservar bordas abertas. O Undo/Redo da máscara é separado do Undo/Redo da geometria.

## Exportar/importar máscaras
- **Exportar preset:** abre o seletor de destino Android e grava `.mmdmask`.
- **Importar preset:** escolhe um `.mmdmask` e valida CRC, versão, vértices e assinatura da geometria/topologia.
- Preset de outro PMX ou de uma geometria-base alterada é recusado. Exporte a máscara após abrir a malha-base correta.
- O preset mantém a máscara em separado; ele não modifica nem substitui o arquivo PMX.

## Dicas para o uso em celulares
- Comece com raio médio e força 0,5–0,8; refine com ADD/SUBTRACT.
- Use geodésico em roupas sobrepostas; use o pincel espacial comum para malhas muito grandes.
- Se o gesto for muito comprido, o sistema limita a densidade das amostras mas preserva o início e o fim do caminho.
- O histórico possui orçamento conjunto padrão de 48 MiB e limite de entradas. A capacidade cai automaticamente conforme o número de vértices.
- O overlay desenha pontos de calor amostrados (até ~12 mil), portanto não deve ser confundido com uma seleção exata de todos os vértices renderizados.
