# Cloth Solver Safety Pro — fluxo de trabalho

No playback do Skirt Guard, o solver é chamado com limites de segurança. Se um passo sair da faixa, a sessão restaura o estado anterior em vez de propagar a explosão para os frames seguintes. O relatório pode ser consultado pela sessão; as colisões corporais continuam sendo aproximações geométricas e precisam ser avaliadas por modelo/pose.

## Segurança de uso

Trabalhe em uma cópia do projeto. Depois de aplicar reparos, salve como novo PMX/projeto e teste alguns frames representativos, incluindo poses extremas. O relatório identifica integridade estrutural; não é garantia de equivalência visual com o MMD oficial.
