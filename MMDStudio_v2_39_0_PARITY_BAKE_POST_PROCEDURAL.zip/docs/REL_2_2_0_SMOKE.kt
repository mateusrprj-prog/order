import studio.mmd.material.*
import studio.mmd.mmd.*
import studio.mmd.rig.*
import studio.mmd.fx.*
import kotlin.math.abs
import kotlin.math.PI

fun near(expected: Float, actual: Float, eps: Float = 0.002f) {
    check(abs(expected - actual) <= eps) { "esperado=$expected atual=$actual" }
}
fun material() = PmxMaterial("Studio", "Studio", floatArrayOf(.72f,.31f,.18f,1f), floatArrayOf(.3f,.3f,.3f),30f,floatArrayOf(.1f,.1f,.1f),0,floatArrayOf(0f,0f,0f,1f),0f,-1,-1,0,false,0,3)
fun main() {
    var passed = 0
    fun test(name: String, body: () -> Unit) { body(); passed++; println("PASS $name") }
    val base = material()
    test("Shader Graph básico e preservação PMX") {
        val result = ShaderGraphCompiler.compile(ShaderGraphCompiler.basic(base), base)
        check(result.evaluatedNodes == 5)
        check(result.material.name == base.name && result.material.textureIndex == base.textureIndex && result.material.sphereIndex == base.sphereIndex)
        near(base.diffuse[0], result.material.diffuse[0]); check(result.material.specular.all(Float::isFinite)); check(result.warnings.any { it.contains("metallic") })
    }
    test("Shader Graph → PMX Writer/Parser preserva o material") {
        val compiled = ShaderGraphCompiler.compile(ShaderGraphCompiler.basic(base), base).material
        val model = PmxModel("Shader round-trip",2.1f,floatArrayOf(0f,0f,0f,1f,0f,0f,0f,1f,0f),floatArrayOf(0f,0f,1f,0f,0f,1f,0f,0f,1f),floatArrayOf(0f,0f,1f,0f,0f,1f),intArrayOf(0,-1,-1,-1,0,-1,-1,-1,0,-1,-1,-1),floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f,0f,0f,0f),intArrayOf(0,1,2),emptyList(),listOf(compiled),emptyList(),emptyList())
        val parsed = PmxParser.parse(PmxWriter.write(model).bytes)
        near(compiled.diffuse[0],parsed.materials[0].diffuse[0],.0001f); near(compiled.specularPower,parsed.materials[0].specularPower,.01f); check(parsed.materials[0].textureIndex == compiled.textureIndex)
    }
    test("Shader Graph Mix Color") {
        val graph = MaterialGraph(
            listOf(MaterialGraphNode("black",MaterialNodeKind.COLOR,floatArrayOf(0f,0f,0f,1f)),MaterialGraphNode("gold",MaterialNodeKind.COLOR,floatArrayOf(1f,.5f,.05f,1f)),MaterialGraphNode("factor",MaterialNodeKind.VALUE,value=.25f),MaterialGraphNode("mix",MaterialNodeKind.MIX),MaterialGraphNode("surface",MaterialNodeKind.PRINCIPLED),MaterialGraphNode("out",MaterialNodeKind.OUTPUT)),
            listOf(MaterialGraphLink("black","mix","a"),MaterialGraphLink("gold","mix","b"),MaterialGraphLink("factor","mix","factor"),MaterialGraphLink("mix","surface","baseColor"),MaterialGraphLink("surface","out","surface")))
        val d = ShaderGraphCompiler.compile(graph,base).material.diffuse
        near(.25f,d[0]); near(.125f,d[1]); near(.0125f,d[2])
    }
    test("Shader Graph Multiply Color") {
        val graph = MaterialGraph(
            listOf(MaterialGraphNode("base",MaterialNodeKind.COLOR,floatArrayOf(.8f,.4f,.2f,1f)),MaterialGraphNode("tint",MaterialNodeKind.COLOR,floatArrayOf(.5f,.25f,1f,1f)),MaterialGraphNode("multiply",MaterialNodeKind.MULTIPLY),MaterialGraphNode("surface",MaterialNodeKind.PRINCIPLED),MaterialGraphNode("out",MaterialNodeKind.OUTPUT)),
            listOf(MaterialGraphLink("base","multiply","a"),MaterialGraphLink("tint","multiply","b"),MaterialGraphLink("multiply","surface","baseColor"),MaterialGraphLink("surface","out","surface")))
        val d = ShaderGraphCompiler.compile(graph,base).material.diffuse
        near(.4f,d[0]); near(.1f,d[1]); near(.2f,d[2])
    }
    test("Shader Graph rejeita ciclos e IDs duplicados") {
        val cyclic = MaterialGraph(listOf(MaterialGraphNode("a",MaterialNodeKind.MIX),MaterialGraphNode("b",MaterialNodeKind.MIX),MaterialGraphNode("out",MaterialNodeKind.OUTPUT)),listOf(MaterialGraphLink("a","b","a"),MaterialGraphLink("b","a","a"),MaterialGraphLink("b","out","surface")))
        check(runCatching { ShaderGraphCompiler.compile(cyclic,base) }.exceptionOrNull()?.message?.contains("Ciclo") == true)
        val dup = MaterialGraph(listOf(MaterialGraphNode("x",MaterialNodeKind.VALUE),MaterialGraphNode("x",MaterialNodeKind.OUTPUT)),emptyList())
        check(runCatching { ShaderGraphCompiler.compile(dup,base) }.exceptionOrNull()?.message?.contains("duplicados") == true)
    }
    test("IK geométrico preserva segmentos e alcança alvo possível") {
        val r = Vec3(0f,0f,0f); val m = Vec3(2f,0f,0f); val e = Vec3(4f,0f,0f); val target = Vec3(3f,0f,0f)
        val solved = TwoBoneIkSolver.solve(r,m,e,target,Vec3(0f,0f,1f))
        check(solved.reachable); near(2f,(solved.middle-r).length()); near(2f,(solved.end-solved.middle).length()); near(target.x,solved.end.x); near(target.y,solved.end.y); near(target.z,solved.end.z)
    }
    test("IK sinaliza alvo fora de alcance sem esticar ossos") {
        val r = Vec3(0f,0f,0f); val solved = TwoBoneIkSolver.solve(r,Vec3(1f,0f,0f),Vec3(2f,0f,0f),Vec3(10f,0f,0f),Vec3(0f,0f,1f))
        check(!solved.reachable && solved.reachError > 7.9f); near(1f,(solved.middle-r).length()); near(1f,(solved.end-solved.middle).length())
    }
    test("IK aplica limite mínimo de dobra sem esticar") {
        val minimum = (100.0 * PI / 180.0).toFloat(); val maximum = (120.0 * PI / 180.0).toFloat(); val r = Vec3(0f,0f,0f)
        val solved = TwoBoneIkSolver.solve(r,Vec3(2f,0f,0f),Vec3(4f,0f,0f),Vec3(3f,0f,0f),Vec3(0f,0f,1f),TwoBoneIkLimits(minimum,maximum))
        check(!solved.reachable); near(minimum,solved.bendRadians); near(2f,(solved.middle-r).length()); near(2f,(solved.end-solved.middle).length())
    }
    test("Tecido skinned mantém cache local e âncora na pose atual") {
        val cloth = ClothXpbd.fromMesh(floatArrayOf(0f,1f,0f,1f,1f,0f,0f,0f,0f),intArrayOf(0,1,2)); cloth.pin(0)
        val transform = object: ClothSkinTransform {
            override fun toWorldPosition(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x+2f;o[1]=y;o[2]=z}
            override fun toWorldPreviousPosition(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x+1f;o[1]=y;o[2]=z}
            override fun toWorldVector(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x;o[1]=y;o[2]=z}
            override fun toWorldPreviousVector(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x;o[1]=y;o[2]=z}
            override fun toLocalPosition(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x-2f;o[1]=y;o[2]=z}
            override fun toLocalVector(v:Int,x:Float,y:Float,z:Float,o:FloatArray){o[0]=x;o[1]=y;o[2]=z}
        }
        val before=cloth.position(1); val after=cloth.stepSkinned(1f/30f,transform,gravityY=0f,substeps=1,iterations=1,damping=0f,groundY=null)
        near(before[0]-1f,after[3],.02f); near(before[1],after[4]); near(before[2],after[5]); near(0f,cloth.position(0)[0]); check(after.all(Float::isFinite))
    }
    test("VFX Explosão determinístico, finito e dependente do quadro") {
        val cfg = FxConfig(enabled=true,style=FxStyle.EXPLOSION,count=120,seed=991,speed=3.2f,spread=1.7f)
        val a=ParticleFx.buildLines(cfg,41f,30f); val b=ParticleFx.buildLines(cfg,41f,30f)
        check(a.size==720 && a.contentEquals(b) && a.all(Float::isFinite))
        check(ParticleFx.buildPoints(cfg,41f,30f).size==360)
        check(!a.contentEquals(ParticleFx.buildLines(cfg,42f,30f)))
    }
    test("VFX Vórtice determinístico, finito e dependente do quadro") {
        val cfg = FxConfig(enabled=true,style=FxStyle.VORTEX,count=120,seed=991,speed=3.2f,spread=1.7f)
        val a=ParticleFx.buildLines(cfg,41f,30f); val b=ParticleFx.buildLines(cfg,41f,30f)
        check(a.size==720 && a.contentEquals(b) && a.all(Float::isFinite))
        check(ParticleFx.buildPoints(cfg,41f,30f).size==360)
        check(!a.contentEquals(ParticleFx.buildLines(cfg,42f,30f)))
    }
    test("Os 13 estilos VFX geram linhas e sprites finitos e repetíveis") {
        check(FxStyle.entries.size == 13)
        val cfg=FxConfig(enabled=true,count=48,seed=4001)
        FxStyle.entries.forEach { style ->
            val a=ParticleFx.buildLines(cfg.copy(style=style),18f,24f)
            val b=ParticleFx.buildLines(cfg.copy(style=style),18f,24f)
            check(a.size==288 && a.contentEquals(b) && a.all(Float::isFinite)) { "Falha no estilo $style" }
            val points=ParticleFx.buildPoints(cfg.copy(style=style),18f,24f)
            check(points.size==144 && points.all(Float::isFinite)) { "Falha nos sprites $style" }
        }
    }
    println("RESULTADO: $passed/12 grupos funcionais aprovados")
}
