# Mask Sculpt Pro — fluxo de trabalho (2.11.0)

## Preparar a região

1. Abra **Model Tools → Máscaras**.
2. Pinte diretamente na viewport usando o pincel espacial ou geodésico.
3. Ative a simetria X para repetir o traço no lado oposto.
4. Use a suavização da máscara para criar transições menos abruptas.
5. Veja o overlay antes de modificar a malha.

## Escolher a operação

- **Inflar:** volume positivo seguindo as normais locais.
- **Encolher:** volume negativo seguindo as normais locais.
- **Pinçar:** puxa os vértices para o centroide ponderado da máscara.
- **Mover:** desloca em X/Y/Z locais. O deslocamento final é ponderado pelo valor da máscara.
- **Achatar:** reduz a distância à superfície de um plano estimado pela normal média da máscara.
- **Escalar:** escala a região em torno do centroide ponderado, com fator contínuo pela máscara.
- **Girar:** gira a região em torno do centroide ponderado nos eixos locais X/Y/Z.

## Ajustar sem danificar a malha

- Comece com força entre 0,2 e 0,5.
- Use limite baixo para ajustes em tecido fino.
- Mantenha **Proteger bordas abertas** ativo para não arrastar contornos livres.
- Aumente a força e o limite gradualmente, conferindo o overlay e a silhueta em cada aplicação.
- Se uma operação não alterar vértices, verifique se a máscara tem influência e se a proteção de bordas não está fixando a região inteira.

## Histórico e salvamento

Cada aplicação é uma operação única de geometria. **Undo geometria** e **Redo geometria** revertem a deformação, sem apagar a pintura da máscara. Salve o PMX/projeto depois de aprovar o resultado. Os presets `.mmdmask` continuam guardando somente pesos de máscara e exigem a mesma malha-base/topologia para importação.
