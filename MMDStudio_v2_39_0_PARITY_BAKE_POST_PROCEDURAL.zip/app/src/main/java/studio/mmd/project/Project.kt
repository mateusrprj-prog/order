package studio.mmd.project

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipOutputStream

/** Dados de um projeto. Arquivos do projeto ficam em filesDir/projects/<id>/ (project.json, model.*, audio.*, animacao.vmd). */
data class ProjectMeta(
    val id: String, val name: String, val aspect: String, val resolution: Int, val fps: Int,
    val bg: String, val created: Long, val updated: Long, val frames: Int
)

/** Configuração do áudio do projeto (nome original, volume 0..1, atraso em ms). */
data class AudioCfg(val name: String, val volume: Float, val offsetMs: Int)

/** Preferências do Skirt Guard armazenadas junto do projeto e incluídas no backup ZIP. */
data class SkirtGuardProjectConfig(
    val enabled: Boolean = true,
    val margin: Float = 0.018f,
    val autoFix: Boolean = true,
    val maxCorrection: Float = 0.025f,
    val liveOverlay: Boolean = false,
    val liveSimulation: Boolean = false,
    val bodySurfaceCollision: Boolean = true,
    val anchorBand: Float = 0.045f,
    val playbackIterations: Int = 5,
    val correctionRegion: String = "ALL"
) {
    fun sanitized() = copy(
        margin = (if (margin.isFinite()) margin else 0.018f).coerceIn(0f, 0.08f),
        maxCorrection = (if (maxCorrection.isFinite()) maxCorrection else 0.025f).coerceIn(0.002f, 0.08f),
        anchorBand = (if (anchorBand.isFinite()) anchorBand else 0.045f).coerceIn(0.01f, 0.18f),
        playbackIterations = playbackIterations.coerceIn(2, 8),
        correctionRegion = correctionRegion.takeIf { it in setOf("ALL", "FRONT", "BACK", "LEFT", "RIGHT") } ?: "ALL"
    )
}

/** Cenário / acessório extra da cena (PMX estático). Posição em unidades do viewport, escala uniforme. */
/** [bone] vazio = solto no mundo; senão o objeto segue esse osso do modelo principal (x,y,z = deslocamento no espaço do osso; rx,ry,rz = rotação local em graus). */
data class PropMeta(val id: String, val name: String, val ext: String, val x: Float, val y: Float, val z: Float, val s: Float,
                    val bone: String = "", val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f)

object Aspects {
    /** Nome -> largura/altura (0 = livre, sem moldura). */
    val all: List<Pair<String, Float>> = listOf(
        "16:9" to 16f / 9f, "9:16" to 9f / 16f, "4:5" to 4f / 5f, "1:1" to 1f, "4:3" to 4f / 3f, "Livre" to 0f
    )

    fun ratio(key: String): Float = all.firstOrNull { it.first == key }?.second ?: 0f

    /** Resolução = lado menor (4:3 em 2160p = 2880×2160). Livre = null. */
    fun size(key: String, res: Int): Pair<Int, Int>? {
        val r = ratio(key)
        if (r <= 0f) return null
        return if (r >= 1f) Pair((res * r).toInt() / 2 * 2, res) else Pair(res, (res / r).toInt() / 2 * 2)
    }
}

object Backgrounds {
    val all: List<Pair<String, Int>> = listOf(
        "Preto" to 0xFF000000.toInt(), "Cinza" to 0xFF303236.toInt(), "Branco" to 0xFFFFFFFF.toInt(),
        "Azul" to 0xFF1B3A6B.toInt(), "Verde" to 0xFF00B140.toInt()
    )

    fun color(name: String): Int = all.firstOrNull { it.first == name }?.second ?: all[0].second
}

object ProjectStore {
    /** Versão do formato do project.json. Ausente = 0 (projetos até a v1.9.0). v1 = apenas marca a versão; sem mudança de campos. */
    const val FORMAT_VERSION = 1
    private fun root(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    private fun write(ctx: Context, m: ProjectMeta) {
        val j = JSONObject().put("formatVersion", FORMAT_VERSION).put("id", m.id).put("name", m.name).put("aspect", m.aspect).put("resolution", m.resolution)
            .put("fps", m.fps).put("bg", m.bg).put("created", m.created).put("updated", m.updated).put("frames", m.frames)
        // escrita atômica: grava num temporário e troca, para um encerramento no meio não corromper o projeto
        val f = File(dir(ctx, m.id), "project.json"); val tmp = File(f.parentFile, "project.json.tmp")
        tmp.writeText(j.toString())
        if (!tmp.renameTo(f)) { f.writeText(j.toString()); tmp.delete() }
    }

    private fun read(f: File): ProjectMeta? = try {
        val j = JSONObject(f.readText())
        ProjectMeta(
            j.getString("id"), j.getString("name"), j.optString("aspect", "16:9"), j.optInt("resolution", 1080),
            j.optInt("fps", 30), j.optString("bg", "Preto"), j.optLong("created"), j.optLong("updated"), j.optInt("frames", 300)
        )
    } catch (e: Exception) { null }

    fun list(ctx: Context): List<ProjectMeta> =
        (root(ctx).listFiles() ?: emptyArray()).mapNotNull { d -> File(d, "project.json").takeIf { it.exists() }?.let { read(it) } }

    fun get(ctx: Context, id: String): ProjectMeta? = File(File(root(ctx), id), "project.json").takeIf { it.exists() }?.let { read(it) }

    fun create(ctx: Context, name: String, aspect: String, res: Int, fps: Int, bg: String): ProjectMeta {
        val now = System.currentTimeMillis()
        val m = ProjectMeta(UUID.randomUUID().toString(), name, aspect, res, fps, bg, now, now, 300)
        write(ctx, m); return m
    }

    fun rename(ctx: Context, id: String, name: String) { get(ctx, id)?.let { write(ctx, it.copy(name = name)) } }

    /** Atualiza data de modificação e duração. */
    fun touch(ctx: Context, id: String, frames: Int) { get(ctx, id)?.let { write(ctx, it.copy(updated = System.currentTimeMillis(), frames = frames)) } }

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }

    /**
     * Importa um projeto exportado (.zip com project.json na raiz ou numa única subpasta).
     * Cria um projeto NOVO (id novo, nome + " (importado)"), sem mexer nos existentes. Devolve o projeto ou lança IOException.
     */
    fun importZip(ctx: Context, uri: Uri): ProjectMeta {
        val newId = UUID.randomUUID().toString()
        val dst = File(root(ctx), newId).apply { mkdirs() }
        try {
            val canon = dst.canonicalPath + File.separator
            var found = false; var totalBytes = 0L
            (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { raw ->
                java.util.zip.ZipInputStream(raw.buffered()).use { z ->
                    // descobre prefixo (zip com tudo dentro de uma pasta)
                    val entries = ArrayList<Pair<String, ByteArray?>>()
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            if (entries.size >= 20_000) throw IOException("Projeto com arquivos demais (limite 20000)")
                            val tmp = File(dst, "__tmp__/" + entries.size)
                            tmp.parentFile?.mkdirs()
                            tmp.outputStream().use { o -> z.copyTo(o) }
                            totalBytes += tmp.length()
                            if (totalBytes > 3L * 1024 * 1024 * 1024) throw IOException("Projeto grande demais (limite 3 GB descompactado)")
                            entries.add(Pair(e.name.replace('\\', '/'), null))
                        }
                        z.closeEntry(); e = z.nextEntry
                    }
                    val meta = entries.indexOfFirst { it.first == "project.json" || it.first.endsWith("/project.json") }
                    if (meta < 0) throw IOException("Este .zip não é um projeto do MMD Studio (sem project.json)")
                    val prefix = entries[meta].first.removeSuffix("project.json")
                    entries.forEachIndexed { i, (name, _) ->
                        if (!name.startsWith(prefix)) return@forEachIndexed
                        val rel = name.removePrefix(prefix)
                        val target = File(dst, rel)
                        if (!target.canonicalPath.startsWith(canon)) return@forEachIndexed // proteção contra caminhos maliciosos
                        target.parentFile?.mkdirs()
                        File(dst, "__tmp__/$i").renameTo(target)
                    }
                    found = true
                }
            }
            File(dst, "__tmp__").deleteRecursively()
            if (!found) throw IOException("Projeto vazio")
            val j = JSONObject(File(dst, "project.json").readText())
            if (j.optInt("formatVersion", 0) > FORMAT_VERSION) throw IOException("Projeto criado por uma versão mais nova do app (formato ${j.optInt("formatVersion")}). Atualize o MMD Studio.")
            val now = System.currentTimeMillis()
            val m = ProjectMeta(newId, j.optString("name", "Projeto") + " (importado)", j.optString("aspect", "16:9"), j.optInt("resolution", 1080),
                j.optInt("fps", 30), j.optString("bg", "Preto"), now, now, j.optInt("frames", 300))
            write(ctx, m)
            return m
        } catch (e: Exception) {
            dst.deleteRecursively()
            throw if (e is IOException) e else IOException("Projeto inválido: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun sizeBytes(ctx: Context, id: String): Long = File(root(ctx), id).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Copia o arquivo escolhido para o projeto como <prefix>.<ext>, substituindo o anterior. */
    fun copyIn(ctx: Context, id: String, uri: Uri, prefix: String, ext: String): File {
        val d = dir(ctx, id)
        if (prefix == "model") { File(d, "model_editado.zip").delete(); File(d, "model_editado.zip.bak").delete(); File(d, "model_editado_backup.zip").delete() }
        val tmp = File(d, "$prefix.tmp")
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            tmp.outputStream().use { o -> i.copyTo(o) }
        }
        d.listFiles()?.filter { it.name.startsWith("$prefix.") && it.name != tmp.name }?.forEach { it.delete() }
        val dst = File(d, "$prefix.$ext")
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
        return dst
    }

    fun fileWith(ctx: Context, id: String, prefix: String): File? =
        dir(ctx, id).listFiles()?.firstOrNull { it.name.startsWith("$prefix.") && !it.name.endsWith(".tmp") && !it.name.endsWith(".bak") }

    /** Grava o movimento de câmera VMD com arquivo temporário sincronizado e backup de recuperação. */
    fun cameraBackupFile(ctx: Context, id: String) = File(dir(ctx, id), "camera.vmd.bak")

    fun editedModelFile(ctx: Context, id: String) = File(dir(ctx, id), "model_editado.zip")
    /** Backup com extensão .zip para que o importador reconheça o formato diretamente. */
    fun editedModelBackupFile(ctx: Context, id: String) = File(dir(ctx, id), "model_editado_backup.zip")

    /** Persiste uma versão PMX editada com as texturas do projeto, sem sobrescrever o arquivo original importado. */
    fun saveEditedModel(ctx: Context, id: String, pmxBytes: ByteArray, textureNames: List<String>, textures: List<ByteArray?>) {
        val d = dir(ctx, id); val dst = editedModelFile(ctx, id)
        val tmp = File(d, "model_editado.zip.tmp"); val bak = editedModelBackupFile(ctx, id)
        ZipOutputStream(FileOutputStream(tmp)).use { zip ->
            val entries = HashSet<String>()
            zip.putNextEntry(java.util.zip.ZipEntry("model.pmx")); zip.write(pmxBytes); zip.closeEntry(); entries.add("model.pmx")
            textureNames.forEachIndexed { i, raw ->
                val name = raw.replace('\\', '/').trimStart('/')
                val data = textures.getOrNull(i)
                if (name.isNotBlank() && !name.split('/').any { it == ".." } && data != null && entries.add(name)) {
                    zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(data); zip.closeEntry()
                }
            }
            zip.finish()
        }
        if (dst.exists()) try { dst.copyTo(bak, overwrite = true) } catch (_: Exception) {}
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, overwrite = true); tmp.delete() }
    }

    /** Cache de tecido por nome, incluído automaticamente no pacote exportado do projeto. */
    fun clothCacheFile(ctx: Context, id: String, name: String): File {
        val safe = name.lowercase().replace(Regex("[^a-z0-9_-]"), "_").take(64).ifBlank { "cache" }
        return File(File(dir(ctx, id), "cloth_cache").apply { mkdirs() }, "$safe.clothcache")
    }

    fun saveClothCache(ctx: Context, id: String, name: String, cache: studio.mmd.rig.ClothBakeCache) {
        studio.mmd.rig.ClothCacheCodec.writeAtomic(clothCacheFile(ctx, id, name), cache)
    }

    fun loadClothCache(ctx: Context, id: String, name: String): studio.mmd.rig.ClothBakeCache =
        studio.mmd.rig.ClothCacheCodec.readWithBackup(clothCacheFile(ctx, id, name))

    fun deleteClothCache(ctx: Context, id: String, name: String) {
        val f = clothCacheFile(ctx, id, name)
        f.delete(); File(f.parentFile, f.name + ".bak").delete(); File(f.parentFile, f.name + ".tmp").delete()
    }

    /** Preferências anti-clipping da saia, persistidas por projeto com backup e troca atômica. */
    fun loadSkirtGuardConfig(ctx: Context, id: String): SkirtGuardProjectConfig {
        val d = dir(ctx, id)
        fun read(file: File): SkirtGuardProjectConfig {
            val j = JSONObject(file.readText())
            return SkirtGuardProjectConfig(
                enabled = j.optBoolean("enabled", true),
                margin = j.optDouble("margin", 0.018).toFloat(),
                autoFix = j.optBoolean("autoFix", true),
                maxCorrection = j.optDouble("maxCorrection", 0.025).toFloat(),
                liveOverlay = j.optBoolean("liveOverlay", false),
                liveSimulation = j.optBoolean("liveSimulation", false),
                bodySurfaceCollision = j.optBoolean("bodySurfaceCollision", true),
                anchorBand = j.optDouble("anchorBand", 0.045).toFloat(),
                playbackIterations = j.optInt("playbackIterations", 5),
                correctionRegion = j.optString("correctionRegion", "ALL")
            ).sanitized()
        }
        val main = File(d, "skirt_guard.json")
        if (!main.exists()) return SkirtGuardProjectConfig()
        return try { read(main) } catch (_: Exception) {
            val backup = File(d, "skirt_guard.json.bak")
            if (backup.exists()) runCatching { read(backup) }.getOrDefault(SkirtGuardProjectConfig())
            else SkirtGuardProjectConfig()
        }
    }

    fun saveSkirtGuardConfig(ctx: Context, id: String, config: SkirtGuardProjectConfig) {
        val c = config.sanitized(); val d = dir(ctx, id)
        val file = File(d, "skirt_guard.json"); val tmp = File(d, "skirt_guard.json.tmp")
        val json = JSONObject().put("formatVersion", 5).put("enabled", c.enabled).put("margin", c.margin.toDouble())
            .put("autoFix", c.autoFix).put("maxCorrection", c.maxCorrection.toDouble()).put("liveOverlay", c.liveOverlay)
            .put("liveSimulation", c.liveSimulation).put("bodySurfaceCollision", c.bodySurfaceCollision)
            .put("anchorBand", c.anchorBand.toDouble()).put("playbackIterations", c.playbackIterations)
            .put("correctionRegion", c.correctionRegion)
        FileOutputStream(tmp).use { out -> out.write(json.toString().toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync() }
        if (file.exists()) try { file.copyTo(File(d, "skirt_guard.json.bak"), overwrite = true) } catch (_: Exception) { }
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }

    /** Configuração de VFX pertence ao projeto e acompanha o arquivo ZIP exportado/importado. */
    fun loadFxConfig(ctx: Context, id: String): studio.mmd.fx.FxConfig {
        val dir = dir(ctx, id)
        fun read(file: File): studio.mmd.fx.FxConfig {
            val j = JSONObject(file.readText())
            return studio.mmd.fx.FxConfig(
                enabled = j.optBoolean("enabled", false),
                style = runCatching { studio.mmd.fx.FxStyle.valueOf(j.optString("style", "SPARKS")) }.getOrDefault(studio.mmd.fx.FxStyle.SPARKS),
                count = j.optInt("count", 90), originX = j.optDouble("x", 0.0).toFloat(), originY = j.optDouble("y", 1.2).toFloat(), originZ = j.optDouble("z", 0.0).toFloat(),
                spread = j.optDouble("spread", 1.2).toFloat(), speed = j.optDouble("speed", 1.8).toFloat(), gravity = j.optDouble("gravity", 2.8).toFloat(),
                lifeSeconds = j.optDouble("life", 2.4).toFloat(), size = j.optDouble("size", .035).toFloat(), red = j.optDouble("r", 1.0).toFloat(),
                green = j.optDouble("g", .55).toFloat(), blue = j.optDouble("b", .12).toFloat(), alpha = j.optDouble("a", .9).toFloat(), seed = j.optInt("seed", 721)
            ).sanitized()
        }
        val main = File(dir, "vfx.json")
        if (!main.exists()) return studio.mmd.fx.FxConfig()
        return try { read(main) } catch (primary: Exception) {
            val backup = File(dir, "vfx.json.bak")
            if (backup.exists()) try { read(backup) } catch (_: Exception) { studio.mmd.fx.FxConfig() }
            else studio.mmd.fx.FxConfig()
        }
    }

    fun saveFxConfig(ctx: Context, id: String, config: studio.mmd.fx.FxConfig) {
        val c = config.sanitized(); val f = File(dir(ctx, id), "vfx.json"); val tmp = File(f.parentFile, "vfx.json.tmp")
        val j = JSONObject().put("enabled", c.enabled).put("style", c.style.name).put("count", c.count)
            .put("x", c.originX.toDouble()).put("y", c.originY.toDouble()).put("z", c.originZ.toDouble())
            .put("spread", c.spread.toDouble()).put("speed", c.speed.toDouble()).put("gravity", c.gravity.toDouble())
            .put("life", c.lifeSeconds.toDouble()).put("size", c.size.toDouble()).put("r", c.red.toDouble()).put("g", c.green.toDouble()).put("b", c.blue.toDouble()).put("a", c.alpha.toDouble()).put("seed", c.seed)
        FileOutputStream(tmp).use { out -> out.write(j.toString().toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync() }
        if (f.exists()) try { f.copyTo(File(f.parentFile, "vfx.json.bak"), overwrite = true) } catch (_: Exception) { }
        if (!tmp.renameTo(f)) { tmp.copyTo(f, overwrite = true); tmp.delete() }
    }

    /** Grade de pós-produção por projeto, incluído no ZIP de backup e restauração. */
    fun loadPostFx(ctx: Context, id: String): studio.mmd.export.PostFxConfig {
        val d = dir(ctx, id)
        fun read(file: File): studio.mmd.export.PostFxConfig {
            val j = JSONObject(file.readText())
            return studio.mmd.export.PostFxConfig(
                enabled = j.optBoolean("enabled", false), exposure = j.optDouble("exposure", 0.0).toFloat(),
                contrast = j.optDouble("contrast", 1.0).toFloat(), saturation = j.optDouble("saturation", 1.0).toFloat(),
                vignette = j.optDouble("vignette", 0.0).toFloat(), grain = j.optDouble("grain", 0.0).toFloat(),
                chromaticAberration = j.optDouble("chroma", 0.0).toFloat(), toneMap = j.optBoolean("toneMap", true),
                seed = j.optInt("seed", 731)
            ).sanitized()
        }
        val f = File(d, "post_fx.json")
        if (!f.exists()) return studio.mmd.export.PostFxConfig()
        return try { read(f) } catch (_: Exception) {
            val bak = File(d, "post_fx.json.bak")
            if (bak.exists()) runCatching { read(bak) }.getOrDefault(studio.mmd.export.PostFxConfig()) else studio.mmd.export.PostFxConfig()
        }
    }

    fun savePostFx(ctx: Context, id: String, config: studio.mmd.export.PostFxConfig) {
        val c = config.sanitized(); val d = dir(ctx, id)
        val f = File(d, "post_fx.json"); val tmp = File(d, "post_fx.json.tmp")
        val j = JSONObject().put("enabled", c.enabled).put("exposure", c.exposure.toDouble())
            .put("contrast", c.contrast.toDouble()).put("saturation", c.saturation.toDouble())
            .put("vignette", c.vignette.toDouble()).put("grain", c.grain.toDouble())
            .put("chroma", c.chromaticAberration.toDouble()).put("toneMap", c.toneMap).put("seed", c.seed)
        FileOutputStream(tmp).use { out -> out.write(j.toString().toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync() }
        if (f.exists()) try { f.copyTo(File(d, "post_fx.json.bak"), overwrite = true) } catch (_: Exception) { }
        if (!tmp.renameTo(f)) { tmp.copyTo(f, overwrite = true); tmp.delete() }
    }

    fun saveCameraMotion(ctx: Context, id: String, bytes: ByteArray?) {
        val d = dir(ctx, id)
        val f = File(d, "camera.vmd")
        val tmp = File(d, "camera.vmd.tmp")
        val bak = File(d, "camera.vmd.bak")
        if (bytes == null) { f.delete(); tmp.delete(); bak.delete(); return }
        FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
        if (f.exists()) try { f.copyTo(bak, overwrite = true) } catch (_: Exception) { /* arquivo principal preservado */ }
        if (!tmp.renameTo(f)) { tmp.copyTo(f, overwrite = true); tmp.delete() }
    }

    fun animFile(ctx: Context, id: String) = File(dir(ctx, id), "animacao.vmd")
    fun animBackupFile(ctx: Context, id: String) = File(dir(ctx, id), "animacao.vmd.bak")

    /**
     * Grava a animação por substituição atômica. Mantém uma única cópia anterior válida
     * para recuperação quando o processo ou o aparelho é interrompido durante um save.
     * null apaga a animação atual e o backup correspondente.
     */
    fun saveAnim(ctx: Context, id: String, bytes: ByteArray?) {
        val f = animFile(ctx, id)
        val tmp = File(f.parentFile, f.name + ".tmp")
        val bak = animBackupFile(ctx, id)
        if (bytes == null) {
            f.delete(); tmp.delete(); bak.delete()
            return
        }
        FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
        if (f.exists()) {
            // A cópia anterior só é substituída depois de o temporário estar totalmente gravado.
            try { f.copyTo(bak, overwrite = true) } catch (_: Exception) { /* o arquivo principal continua íntegro */ }
        }
        if (!tmp.renameTo(f)) {
            tmp.copyTo(f, overwrite = true)
            tmp.delete()
        }
    }

    // ---------- cenário e acessórios (props)
    private fun propsDir(ctx: Context, id: String) = File(dir(ctx, id), "props").apply { mkdirs() }
    fun propFile(ctx: Context, projectId: String, p: PropMeta) = File(propsDir(ctx, projectId), "${p.id}.${p.ext}")

    fun loadProps(ctx: Context, projectId: String): List<PropMeta> = try {
        val f = File(dir(ctx, projectId), "scene.json")
        if (!f.exists()) emptyList() else {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val j = a.getJSONObject(i)
                PropMeta(j.getString("id"), j.optString("name", "objeto"), j.optString("ext", "zip"),
                    j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(), j.optDouble("s", 1.0).toFloat(),
                    j.optString("bone", ""), j.optDouble("rx", 0.0).toFloat(), j.optDouble("ry", 0.0).toFloat(), j.optDouble("rz", 0.0).toFloat())
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveProps(ctx: Context, projectId: String, list: List<PropMeta>) {
        val a = JSONArray()
        list.forEach { p -> a.put(JSONObject().put("id", p.id).put("name", p.name).put("ext", p.ext).put("x", p.x.toDouble()).put("y", p.y.toDouble()).put("z", p.z.toDouble()).put("s", p.s.toDouble()).put("bone", p.bone).put("rx", p.rx.toDouble()).put("ry", p.ry.toDouble()).put("rz", p.rz.toDouble())) }
        File(dir(ctx, projectId), "scene.json").writeText(a.toString())
    }

    /** Copia o arquivo escolhido para a pasta props do projeto e devolve o registro do objeto. */
    fun addPropFile(ctx: Context, projectId: String, uri: Uri, name: String, ext: String): PropMeta {
        val p = PropMeta(UUID.randomUUID().toString(), name, ext, 0f, 0f, 0f, 1f)
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            propFile(ctx, projectId, p).outputStream().use { o -> i.copyTo(o) }
        }
        return p
    }

    fun deletePropFile(ctx: Context, projectId: String, p: PropMeta) { propFile(ctx, projectId, p).delete() }


    // ---------- transformação raiz das personagens (independente do esqueleto e animável por keyframes)
    fun loadRootTransforms(ctx: Context, projectId: String): studio.mmd.scene.RootTransformState = try {
        val f = File(dir(ctx, projectId), studio.mmd.scene.RootTransformCodec.FILE)
        if (f.exists()) studio.mmd.scene.RootTransformCodec.decode(f.readText()) else studio.mmd.scene.RootTransformState()
    } catch (_: Throwable) { studio.mmd.scene.RootTransformState() }

    fun saveRootTransforms(ctx: Context, projectId: String, state: studio.mmd.scene.RootTransformState) {
        val f = File(dir(ctx, projectId), studio.mmd.scene.RootTransformCodec.FILE)
        val tmp = File(f.parentFile, f.name + ".tmp")
        val text = studio.mmd.scene.RootTransformCodec.encode(state)
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    // ---------- elenco: personagens extras animados (cast.json + cast/<id>.<ext> + cast/<id>.vmd) — v1.27.0, 8.3c
    private fun castDir(ctx: Context, id: String) = File(dir(ctx, id), "cast").apply { mkdirs() }
    fun castFile(ctx: Context, projectId: String, c: studio.mmd.scene.CastMeta) = File(castDir(ctx, projectId), "${c.id}.${c.ext}")
    fun castMotionFile(ctx: Context, projectId: String, castId: String) = File(castDir(ctx, projectId), "$castId.vmd")
    private fun castRigFile(ctx: Context, projectId: String, castId: String): File {
        val safeId = castId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
        return File(castDir(ctx, projectId), "$safeId.rig.json")
    }

    /** Perfil isolado de restrições, movimento secundário e física real de cada personagem extra. */
    fun loadCastRig(ctx: Context, projectId: String, castId: String): studio.mmd.rig.RigConfig = try {
        val f = castRigFile(ctx, projectId, castId)
        if (f.exists()) studio.mmd.rig.CharacterRigProfileCodec.safeDecode(f.readText()) else studio.mmd.rig.RigConfig()
    } catch (_: Throwable) { studio.mmd.rig.RigConfig() }

    fun saveCastRig(ctx: Context, projectId: String, castId: String, config: studio.mmd.rig.RigConfig) {
        val f = castRigFile(ctx, projectId, castId)
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(studio.mmd.rig.CharacterRigProfileCodec.encode(config))
        if (!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
    }

    fun deleteCastRig(ctx: Context, projectId: String, castId: String) { castRigFile(ctx, projectId, castId).delete() }

    /** Lê o elenco. Arquivo ausente = vazio. Avisos (itens inválidos) vão para o log; nunca lança. */
    fun loadCast(ctx: Context, projectId: String): List<studio.mmd.scene.CastMeta> = try {
        val f = File(dir(ctx, projectId), studio.mmd.scene.CastCodec.FILE)
        if (!f.exists()) emptyList() else {
            val r = studio.mmd.scene.CastCodec.fromJson(f.readText())
            r.warnings.forEach { studio.mmd.util.Log.w("CAST", it) }
            r.cast
        }
    } catch (e: Exception) { emptyList() }

    /** Escrita atômica (temporário + troca), como o project.json. */
    fun saveCast(ctx: Context, projectId: String, list: List<studio.mmd.scene.CastMeta>) {
        val f = File(dir(ctx, projectId), studio.mmd.scene.CastCodec.FILE); val tmp = File(f.parentFile, f.name + ".tmp")
        val text = studio.mmd.scene.CastCodec.toJson(list)
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    /** Copia o modelo escolhido para cast/<id>.<ext> e devolve o registro (id novo: importar o mesmo arquivo 2x gera 2 personagens independentes). */
    fun addCastFile(ctx: Context, projectId: String, uri: Uri, name: String, ext: String): studio.mmd.scene.CastMeta {
        val c = studio.mmd.scene.CastMeta(UUID.randomUUID().toString(), name, ext)
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            castFile(ctx, projectId, c).outputStream().use { o -> i.copyTo(o) }
        }
        return c
    }

    fun deleteCastFiles(ctx: Context, projectId: String, c: studio.mmd.scene.CastMeta) {
        castFile(ctx, projectId, c).delete(); castMotionFile(ctx, projectId, c.id).delete(); deleteCastRig(ctx, projectId, c.id)
    }

    // ---------- Outliner (outliner.json) — v1.29.0, fatia 8.4a: nomes, bloqueio, visibilidade no render, grupos, ordem.
    fun loadOutliner(ctx: Context, projectId: String): studio.mmd.scene.OutlinerState = try {
        val f = File(dir(ctx, projectId), studio.mmd.scene.OutlinerState.Codec.FILE)
        if (!f.exists()) studio.mmd.scene.OutlinerState() else {
            val r = studio.mmd.scene.OutlinerState.Codec.fromJson(f.readText())
            r.warnings.forEach { studio.mmd.util.Log.w("OUTLINER", it) }
            r.state
        }
    } catch (e: Exception) { studio.mmd.scene.OutlinerState() }

    fun saveOutliner(ctx: Context, projectId: String, st: studio.mmd.scene.OutlinerState) {
        val f = File(dir(ctx, projectId), studio.mmd.scene.OutlinerState.Codec.FILE); val tmp = File(f.parentFile, f.name + ".tmp")
        val text = st.toJson()
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    /** Copia o arquivo de um acessório/cenário para um id novo (duplicar). */
    fun duplicateProp(ctx: Context, projectId: String, p: PropMeta): PropMeta {
        val n = p.copy(id = UUID.randomUUID().toString(), name = p.name + " (cópia)", x = p.x + 1f)
        propFile(ctx, projectId, p).copyTo(propFile(ctx, projectId, n), overwrite = true)
        return n
    }

    /** Copia o arquivo (e o movimento, se houver) de um personagem extra para um id novo (duplicar). */
    fun duplicateCast(ctx: Context, projectId: String, c: studio.mmd.scene.CastMeta): studio.mmd.scene.CastMeta {
        val n = c.copy(id = UUID.randomUUID().toString(), name = c.name + " (cópia)", x = c.x + 2f)
        castFile(ctx, projectId, c).copyTo(castFile(ctx, projectId, n), overwrite = true)
        val mf = castMotionFile(ctx, projectId, c.id)
        if (mf.exists()) mf.copyTo(castMotionFile(ctx, projectId, n.id), overwrite = true)
        val rf = castRigFile(ctx, projectId, c.id)
        if (rf.exists()) rf.copyTo(castRigFile(ctx, projectId, n.id), overwrite = true)
        return n
    }

    // ---------- Scene Graph (scenegraph.json) — v1.18.0, Release 8 fatia 1. Ainda não ligado à UI.
    /** Lê o scenegraph.json; null se não existir. Lança IOException se estiver corrompido/for de versão mais nova. */
    fun loadScene(ctx: Context, projectId: String): studio.mmd.scene.SceneLoad? {
        val f = File(dir(ctx, projectId), studio.mmd.scene.SceneSerializer.FILE)
        if (!f.exists()) return null
        try { return studio.mmd.scene.SceneSerializer.fromJson(f.readText()) }
        catch (e: IllegalArgumentException) { throw IOException(e.message ?: "scenegraph.json inválido") }
    }

    /** Escrita atômica (temporário + troca), como o project.json. */
    fun saveScene(ctx: Context, projectId: String, g: studio.mmd.scene.SceneGraph) {
        val f = File(dir(ctx, projectId), studio.mmd.scene.SceneSerializer.FILE); val tmp = File(f.parentFile, f.name + ".tmp")
        val text = studio.mmd.scene.SceneSerializer.toJson(g)
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    /**
     * Devolve o grafo do projeto. Se ainda não existe, migra do formato v1 (modelo principal + props do scene.json antigo),
     * guardando antes uma cópia project.v1.json.bak (uma vez) e gravando o scenegraph.json. O scene.json antigo NÃO é alterado.
     */
    fun loadOrMigrateScene(ctx: Context, projectId: String, modelName: String): studio.mmd.scene.SceneLoad {
        loadScene(ctx, projectId)?.let { return it }
        val d = dir(ctx, projectId)
        val pj = File(d, "project.json"); val bak = File(d, "project.v1.json.bak")
        if (pj.exists() && !bak.exists()) pj.copyTo(bak)
        val hasModel = d.listFiles()?.any { it.name.startsWith("model.") } == true
        val g = studio.mmd.scene.SceneGraph.fromLegacy(modelName, hasModel, loadProps(ctx, projectId))
        saveScene(ctx, projectId, g)
        return studio.mmd.scene.SceneLoad(g, listOf("Projeto migrado do formato v1 para o Scene Graph"))
    }

    // ---------- rig: restrições (rig.json)
    fun loadRig(ctx: Context, projectId: String): List<studio.mmd.rig.Constraint> {
        val f = File(dir(ctx, projectId), "rig.json")
        return if (f.exists()) studio.mmd.rig.RigIo.fromJson(f.readText()) else emptyList()
    }

    fun saveRig(ctx: Context, projectId: String, l: List<studio.mmd.rig.Constraint>) {
        val f = File(dir(ctx, projectId), "rig.json")
        if (l.isEmpty()) f.delete() else f.writeText(studio.mmd.rig.RigIo.toJson(l))
    }

    // ---------- movimento secundário (secondary.json)
    fun loadSecondary(ctx: Context, projectId: String): List<studio.mmd.rig.Secondary> {
        val f = File(dir(ctx, projectId), "secondary.json")
        return if (f.exists()) studio.mmd.rig.SecIo.fromJson(f.readText()) else emptyList()
    }

    fun saveSecondary(ctx: Context, projectId: String, l: List<studio.mmd.rig.Secondary>) {
        val f = File(dir(ctx, projectId), "secondary.json")
        if (l.isEmpty()) f.delete() else f.writeText(studio.mmd.rig.SecIo.toJson(l))
    }

    // ---------- editor de partes: correções manuais do personagem principal (parts.json) — v1.32.0
    fun loadParts(ctx: Context, projectId: String): studio.mmd.rig.PartOverrides {
        val f = File(dir(ctx, projectId), "parts.json")
        return if (f.exists()) studio.mmd.rig.PartOverridesIo.fromJson(f.readText()) else studio.mmd.rig.PartOverrides()
    }

    fun saveParts(ctx: Context, projectId: String, o: studio.mmd.rig.PartOverrides) {
        val f = File(dir(ctx, projectId), "parts.json")
        if (o.isEmpty) { f.delete(); return }
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(studio.mmd.rig.PartOverridesIo.toJson(o))
        if (!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
    }

    fun loadPhys(ctx: Context, projectId: String): studio.mmd.rig.PhysConfig {
        val f = File(dir(ctx, projectId), "physics.json")
        return if (f.exists()) studio.mmd.rig.PhysIo.fromJson(f.readText()) else studio.mmd.rig.PhysConfig()
    }

    fun savePhys(ctx: Context, projectId: String, c: studio.mmd.rig.PhysConfig) {
        val f = File(dir(ctx, projectId), "physics.json")
        if (!c.enabled) f.delete() else f.writeText(studio.mmd.rig.PhysIo.toJson(c))
    }

    // ---------- áudio (config em audiocfg.json; o arquivo é audio.<ext>)
    fun loadAudioCfg(ctx: Context, projectId: String): AudioCfg? = try {
        val f = File(dir(ctx, projectId), "audiocfg.json")
        if (!f.exists()) null else JSONObject(f.readText()).let {
            AudioCfg(it.optString("name", "áudio"), it.optDouble("volume", 1.0).toFloat(), it.optInt("offset", 0))
        }
    } catch (e: Exception) { null }

    /** null apaga a configuração. */
    fun saveAudioCfg(ctx: Context, projectId: String, c: AudioCfg?) {
        val f = File(dir(ctx, projectId), "audiocfg.json")
        if (c == null) f.delete() else f.writeText(JSONObject().put("name", c.name).put("volume", c.volume.toDouble()).put("offset", c.offsetMs).toString())
    }

    fun deleteAudio(ctx: Context, projectId: String) {
        dir(ctx, projectId).listFiles()?.filter { it.name.startsWith("audio.") }?.forEach { it.delete() }
        saveAudioCfg(ctx, projectId, null)
    }
}
