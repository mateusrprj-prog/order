package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import kotlin.math.abs

/** Auditoria da distribuição de skinning PMX sem alteração da malha. */
data class PmxWeightAuditReport(
    val vertices: Int,
    val weightedVertices: Int,
    val unweightedVertices: Int,
    val invalidBoneReferences: Int,
    val invalidWeights: Int,
    val sumMismatch: Int,
    val duplicateInfluences: Int,
    val maxInfluences: Int,
    val averageInfluences: Float
) {
    val healthy: Boolean get() = invalidBoneReferences == 0 && invalidWeights == 0 && unweightedVertices == 0 && sumMismatch == 0
}

data class PmxWeightRepairResult(
    val model: PmxModel,
    val reportBefore: PmxWeightAuditReport,
    val reportAfter: PmxWeightAuditReport,
    val repairedVertices: Int,
    val removedInfluences: Int,
    val leftUnweighted: Int
)

/**
 * Ferramentas de auditoria e reparo conservador dos quatro slots de influência PMX.
 * O resultado é um novo PmxModel; o objeto de origem e os demais dados (morphs, SDEF, QDEF,
 * soft-body, materiais, rigids e metadados) são preservados por cópia/referência imutável.
 */
object PmxWeightDoctor {
    fun inspect(model: PmxModel): PmxWeightAuditReport {
        val n = model.vertexCount
        if (model.boneIndices.size < n * 4 || model.boneWeights.size < n * 4)
            return PmxWeightAuditReport(n, 0, n, n, n, n, 0, 0, 0f)
        var weighted = 0; var unweighted = 0; var badBone = 0; var badWeight = 0; var sumBad = 0
        var duplicate = 0; var influenceTotal = 0; var maxInfluence = 0
        for (v in 0 until n) {
            val base = v * 4; var sum = 0f; var active = 0; var badRef = false; var badW = false
            val seen = HashSet<Int>()
            for (k in 0..3) {
                val bone = model.boneIndices[base + k]; val w = model.boneWeights[base + k]
                if (!w.isFinite() || w < 0f) { badW = true; continue }
                if (w <= 1e-6f) continue
                active++; sum += w
                if (bone !in model.bones.indices) badRef = true
                if (!seen.add(bone)) duplicate++
            }
            if (badRef) badBone++
            if (badW) badWeight++
            if (active == 0 || sum <= 1e-8f) unweighted++ else {
                weighted++; if (abs(sum - 1f) > .03f) sumBad++
            }
            influenceTotal += active; maxInfluence = maxOf(maxInfluence, active)
        }
        return PmxWeightAuditReport(n, weighted, unweighted, badBone, badWeight, sumBad, duplicate,
            maxInfluence, if (n > 0) influenceTotal.toFloat() / n else 0f)
    }

    /**
     * Normaliza pesos válidos, remove referências inválidas e combina slots duplicados.
     * `fallbackBone` é opcional: sem ele, vértices que perderem todas as influências ficam sem peso
     * e são explicitamente contabilizados (não inventamos um rig para o usuário).
     */
    fun repair(model: PmxModel, fallbackBone: Int? = null): PmxWeightRepairResult {
        require(fallbackBone == null || fallbackBone in model.bones.indices) { "Osso fallback inválido" }
        val n = model.vertexCount
        require(model.boneIndices.size >= n * 4 && model.boneWeights.size >= n * 4) { "Arrays de skinning incompletos; reparo cancelado sem alterar o PMX" }
        val before = inspect(model)
        val ids = model.boneIndices.copyOf(); val weights = model.boneWeights.copyOf()
        val weightTypes = model.weightTypes.copyOf()
        var repaired = 0; var removed = 0
        for (v in 0 until n) {
            val base = v * 4
            val originalIds = IntArray(4) { ids[base + it] }
            val originalWeights = FloatArray(4) { weights[base + it] }
            val type = weightTypes.getOrNull(v)?.toInt()?.and(0xff)
            // SDEF usa C/R0/R1 associados à ordem original dos dois ossos. Nunca reordenar
            // um SDEF válido; se um dos dois vínculos estiver corrompido, converter só esse
            // vértice para BDEF2 antes de reconstruir os slots.
            if (type == 3) {
                val aValid = originalIds[0] in model.bones.indices && originalWeights[0].isFinite() && originalWeights[0] >= 0f
                val bValid = originalIds[1] in model.bones.indices && originalWeights[1].isFinite() && originalWeights[1] >= 0f
                val sum = originalWeights[0].takeIf { it.isFinite() && it > 0f }?.plus(originalWeights[1].takeIf { it.isFinite() && it > 0f } ?: 0f) ?: 0f
                if (aValid && bValid && sum > 1e-8f) {
                    val w0 = originalWeights[0] / sum
                    val outIds = originalIds.copyOf(); val outWeights = FloatArray(4)
                    outWeights[0] = w0; outWeights[1] = 1f - w0
                    for (slot in 2..3) outIds[slot] = -1
                    if (!outIds.contentEquals(originalIds) || (0..3).any { abs(outWeights[it] - (if (originalWeights[it].isFinite()) originalWeights[it] else 0f)) > 1e-6f }) repaired++
                    outIds.copyInto(ids, base); outWeights.copyInto(weights, base)
                    continue
                }
                if (v < weightTypes.size) weightTypes[v] = 1 // fallback seguro: BDEF2 sem parâmetros SDEF
            }
            val merged = LinkedHashMap<Int, Float>()
            var validInfluenceSlots = 0
            for (slot in 0..3) {
                val bone = originalIds[slot]; val w = originalWeights[slot]
                if (!w.isFinite() || w <= 1e-6f || bone !in model.bones.indices) { if (w.isFinite() && w > 1e-6f || bone >= model.bones.size) removed++; continue }
                validInfluenceSlots++
                merged[bone] = (merged[bone] ?: 0f) + w
            }
            val repairedType = weightTypes.getOrNull(v)?.toInt()?.and(0xff) ?: type
            val maxSlots = when (repairedType) { 0 -> 1; 1 -> 2; else -> 4 }
            val selected = merged.entries.sortedByDescending { it.value }.take(maxSlots)
            removed += (validInfluenceSlots - selected.size).coerceAtLeast(0)
            val sum = selected.sumOf { it.value.toDouble() }.toFloat()
            val outIds = IntArray(4) { -1 }; val outWeights = FloatArray(4)
            if (sum > 1e-8f && sum.isFinite()) selected.forEachIndexed { slot, entry ->
                outIds[slot] = entry.key; outWeights[slot] = (entry.value / sum).coerceIn(0f, 1f)
            } else if (fallbackBone != null) {
                outIds[0] = fallbackBone; outWeights[0] = 1f
            }
            if (!outIds.contentEquals(originalIds) || outWeights.indices.any { abs(outWeights[it] - (if (originalWeights[it].isFinite()) originalWeights[it] else 0f)) > 1e-6f }) repaired++
            outIds.copyInto(ids, base); outWeights.copyInto(weights, base)
        }
        val repairedModel = PmxModel(
            model.name, model.version, model.positions.copyOf(), model.normals.copyOf(), model.uvs.copyOf(),
            ids, weights, model.indices.copyOf(), model.textures.toList(), model.materials.toList(), model.bones.toList(), model.morphs.toList(),
            model.rigidBodies.toList(), model.joints.toList(), model.nameEn, model.comment, model.commentEn, model.displayFrames.toList(),
            model.addUvCount, model.addUvs.copyOf(), weightTypes, model.sdef?.copyOf(), model.edgeScale.copyOf(),
            model.textEncoding, model.indexSizes.copyOf(), model.softBodyCount, model.softBodyRaw?.copyOf(), model.warnings.toList()
        )
        val after = inspect(repairedModel)
        return PmxWeightRepairResult(repairedModel, before, after, repaired, removed, after.unweightedVertices)
    }
}
