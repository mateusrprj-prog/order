package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxMorph
import kotlin.math.*

/** Unwrap por charts com costuras explícitas, LSCM sparse (CG) e empacotamento em atlas. */
object SeamAwareUvUnwrapper {
    data class Result(
        val model: PmxModel,
        val islandCount: Int,
        val splitVertices: Int,
        val solverFallbacks: Int,
        val warnings: List<String>,
        val aborted: Boolean = false
    )

    private data class EdgeUse(val face: Int)
    private data class Row(val ids: IntArray, val weights: FloatArray, val fixed: Float)

    fun edgeKey(a: Int, b: Int): Long {
        val lo = min(a, b); val hi = max(a, b)
        return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
    }

    /** Marca como costura as arestas entre faces cujo ângulo diedro atinge o limite. */
    fun seamsByAngle(model: PmxModel, angleDegrees: Float = 55f): Set<Long> {
        require(angleDegrees.isFinite())
        val threshold = angleDegrees.coerceIn(0f, 180f)
        val normals = faceNormals(model)
        val uses = edgeUses(model)
        val out = LinkedHashSet<Long>()
        for ((key, faces) in uses) {
            if (faces.size != 2) continue
            val a = normals[faces[0].face]; val b = normals[faces[1].face]
            val dot = (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]).coerceIn(-1f, 1f)
            val angle = Math.toDegrees(acos(dot).toDouble()).toFloat()
            if (angle >= threshold) out.add(key)
        }
        return out
    }

    /** Marca arestas compartilhadas por materiais diferentes. */
    fun seamsAtMaterialBorders(model: PmxModel): Set<Long> {
        val faceMaterial = IntArray(model.indices.size / 3) { -1 }
        var offset = 0
        model.materials.forEachIndexed { material, m ->
            val end = (offset + m.indexCount.coerceAtLeast(0)).coerceAtMost(model.indices.size)
            for (i in offset / 3 until min(faceMaterial.size, end / 3)) faceMaterial[i] = material
            offset = end
        }
        val uses = edgeUses(model)
        return uses.filter { (_, faces) -> faces.size == 2 && faceMaterial.getOrElse(faces[0].face) { -1 } != faceMaterial.getOrElse(faces[1].face) { -1 } }.keys
    }

    fun unwrap(model: PmxModel, seams: Set<Long> = emptySet(), padding: Float = 0.025f): Result {
        require(padding.isFinite() && padding in 0f..0.2f) { "Padding deve ficar entre 0 e 0,2" }
        val vertexCount = model.vertexCount
        val faceCount = model.indices.size / 3
        if (vertexCount == 0 || faceCount == 0) return Result(model, 0, 0, 0, listOf("Malha sem triângulos válidos"))
        val uses = edgeUses(model)
        val faceAdj = Array(faceCount) { LinkedHashSet<Int>() }
        for ((key, list) in uses) {
            if (key in seams || list.size != 2) continue
            val a = list[0].face; val b = list[1].face
            if (a in 0 until faceCount && b in 0 until faceCount) { faceAdj[a].add(b); faceAdj[b].add(a) }
        }
        val faceChart = IntArray(faceCount) { -1 }
        val charts = ArrayList<MutableList<Int>>()
        val queue = IntArray(faceCount)
        for (start in 0 until faceCount) {
            if (faceChart[start] >= 0 || !validFace(model, start)) continue
            val chartId = charts.size
            val faces = ArrayList<Int>()
            var head = 0; var tail = 0
            queue[tail++] = start; faceChart[start] = chartId
            while (head < tail) {
                val f = queue[head++]; faces.add(f)
                for (next in faceAdj[f]) if (faceChart[next] < 0) { faceChart[next] = chartId; queue[tail++] = next }
            }
            charts.add(faces)
        }
        if (charts.isEmpty()) return Result(model, 0, 0, 0, listOf("Nenhum triângulo válido para unwrap"))

        val chartUvs = Array(charts.size) { HashMap<Int, FloatArray>() }
        var fallbacks = 0
        for (ci in charts.indices) {
            val faceList = charts[ci]
            val verts = LinkedHashSet<Int>()
            faceList.forEach { f -> for (k in 0..2) verts.add(model.indices[f * 3 + k]) }
            val ordered = verts.toIntArray()
            val solved = solveLscm(model, faceList, ordered)
            val uv = solved ?: planarFallback(model, ordered)
            if (solved == null) fallbacks++
            val columns = ceil(sqrt(charts.size.toDouble())).toInt().coerceAtLeast(1)
            val rows = ceil(charts.size.toDouble() / columns).toInt().coerceAtLeast(1)
            val cellW = 1f / columns; val cellH = 1f / rows
            val padU = min(padding / columns, cellW * .24f); val padV = min(padding / rows, cellH * .24f)
            val side = min(cellW - padU * 2f, cellH - padV * 2f).coerceAtLeast(1e-4f)
            val baseU = (ci % columns) * cellW + (cellW - side) * .5f
            val baseV = (ci / columns) * cellH + (cellH - side) * .5f
            for (i in ordered.indices) chartUvs[ci][ordered[i]] = floatArrayOf(baseU + uv[i * 2] * side, baseV + uv[i * 2 + 1] * side)
        }

        // Cada vértice compartilhado por charts distintos ganha uma cópia PMX independente.
        val firstChart = IntArray(vertexCount) { -1 }
        val lookup = HashMap<Long, Int>()
        val newToOld = ArrayList<Int>(vertexCount)
        repeat(vertexCount) { newToOld.add(it) }
        val newIndices = model.indices.copyOf()
        val outUvs = ArrayList<Float>(max(model.uvs.size, vertexCount * 2 + 16))
        for (v in 0 until vertexCount) { outUvs.add(model.uvs.getOrElse(v * 2) { 0f }); outUvs.add(model.uvs.getOrElse(v * 2 + 1) { 0f }) }
        fun outputVertex(old: Int, chart: Int): Int {
            if (old !in 0 until vertexCount || chart < 0) return old
            val key = (old.toLong() shl 32) or (chart.toLong() and 0xffffffffL)
            lookup[key]?.let { return it }
            val result = if (firstChart[old] < 0) {
                firstChart[old] = chart
                old
            } else if (firstChart[old] == chart) old else {
                val n = newToOld.size
                newToOld.add(old)
                outUvs.add(0f); outUvs.add(0f)
                n
            }
            lookup[key] = result
            val values = chartUvs[chart][old]
            if (values != null) { outUvs[result * 2] = values[0]; outUvs[result * 2 + 1] = values[1] }
            return result
        }
        for (f in 0 until faceCount) {
            val chart = faceChart[f]
            if (chart < 0) continue // triângulo inválido é preservado sem remapeamento
            for (k in 0..2) {
                val at = f * 3 + k
                newIndices[at] = outputVertex(model.indices[at], chart)
            }
        }
        val mapping = newToOld.toIntArray()
        val requiredVertexIndexSize = when {
            mapping.size <= 256 -> 1
            mapping.size <= 65536 -> 2
            else -> 4
        }
        val rawIndexDataPresent = model.morphs.any { it.raw != null } || model.softBodyRaw != null
        val originalVertexIndexSize = model.indexSizes.getOrNull(0)
        if (mapping.size > vertexCount && rawIndexDataPresent &&
            (originalVertexIndexSize == null || requiredVertexIndexSize > originalVertexIndexSize)) {
            val warning = "Unwrap cancelado: este PMX contém morphs/soft bodies binários e a duplicação exigiria ampliar o tamanho do índice de vértice; os blocos raw seriam corrompidos pelo escritor atual. Nenhuma alteração foi aplicada."
            return Result(model, charts.size, 0, fallbacks, listOf(warning), aborted = true)
        }
        val newPositions = remapFloat(model.positions, mapping, 3)
        val newNormals = remapFloat(model.normals, mapping, 3)
        val newBoneIndices = remapInt(model.boneIndices, mapping, 4, -1)
        val newBoneWeights = remapFloat(model.boneWeights, mapping, 4)
        val newWeightTypes = remapByte(model.weightTypes, mapping, 1)
        val newSdef = model.sdef?.let { remapFloat(it, mapping, 9) }
        val newAddUvs = if (model.addUvCount > 0) remapFloat(model.addUvs, mapping, model.addUvCount * 4) else model.addUvs.copyOf()
        val newEdgeScale = if (model.edgeScale.size >= vertexCount) remapFloat(model.edgeScale, mapping, 1) else model.edgeScale.copyOf()
        val reverse = Array(vertexCount) { ArrayList<Int>() }
        mapping.forEachIndexed { newIndex, oldIndex -> if (oldIndex in reverse.indices) reverse[oldIndex].add(newIndex) }
        val newMorphs = model.morphs.map { morph ->
            if (morph.type != 1 || morph.vertexIdx == null || morph.vertexDelta == null || morph.vertexDelta.size < morph.vertexIdx.size * 3) morph
            else {
                val ids = ArrayList<Int>(); val deltas = ArrayList<Float>()
                for (entry in morph.vertexIdx.indices) {
                    val old = morph.vertexIdx[entry]
                    if (old !in reverse.indices) continue
                    for (newIndex in reverse[old]) {
                        ids.add(newIndex)
                        for (k in 0..2) deltas.add(morph.vertexDelta[entry * 3 + k])
                    }
                }
                PmxMorph(morph.name, morph.nameEn, morph.panel, morph.type, ids.toIntArray(), deltas.toFloatArray(),
                    morph.boneIdx?.copyOf(), morph.boneTrans?.copyOf(), morph.boneRot?.copyOf(), morph.groupIdx?.copyOf(), morph.groupRate?.copyOf(), morph.raw?.copyOf(), ids.size)
            }
        }
        val warnings = model.warnings.toMutableList()
        if (model.morphs.any { it.type in 3..7 }) warnings.add("UV unwrap criou vértices nas costuras; morphs UV PMX (tipos 3–7) foram preservados sem expansão de seus índices binários.")
        if (fallbacks > 0) warnings.add("$fallbacks ilhas usaram projeção planar de fallback por degeneração ou falha numérica do LSCM.")
        val updatedIndexSizes = model.indexSizes.copyOf()
        if (updatedIndexSizes.isNotEmpty()) {
            updatedIndexSizes[0] = max(updatedIndexSizes[0], requiredVertexIndexSize)
        }
        val result = PmxModel(
            model.name, model.version, newPositions, newNormals, outUvs.toFloatArray(), newBoneIndices, newBoneWeights, newIndices,
            model.textures.toList(), model.materials.toList(), model.bones.toList(), newMorphs, model.rigidBodies.toList(), model.joints.toList(),
            model.nameEn, model.comment, model.commentEn, model.displayFrames.toList(), model.addUvCount, newAddUvs, newWeightTypes,
            newSdef, newEdgeScale, model.textEncoding, updatedIndexSizes, model.softBodyCount, model.softBodyRaw?.copyOf(), warnings
        )
        return Result(result, charts.size, mapping.size - vertexCount, fallbacks, warnings.distinct())
    }

    private fun validFace(m: PmxModel, f: Int): Boolean {
        val o = f * 3
        if (o + 2 >= m.indices.size) return false
        val a = m.indices[o]; val b = m.indices[o + 1]; val c = m.indices[o + 2]
        return a in 0 until m.vertexCount && b in 0 until m.vertexCount && c in 0 until m.vertexCount && a != b && b != c && c != a
    }

    private fun edgeUses(m: PmxModel): Map<Long, List<EdgeUse>> {
        val out = HashMap<Long, MutableList<EdgeUse>>()
        for (f in 0 until m.indices.size / 3) {
            if (!validFace(m, f)) continue
            val o = f * 3; val a = m.indices[o]; val b = m.indices[o + 1]; val c = m.indices[o + 2]
            for ((x, y) in arrayOf(a to b, b to c, c to a)) out.getOrPut(edgeKey(x, y)) { ArrayList() }.add(EdgeUse(f))
        }
        return out
    }

    private fun faceNormals(m: PmxModel): Array<FloatArray> = Array(m.indices.size / 3) { f ->
        if (!validFace(m, f)) return@Array floatArrayOf(0f, 1f, 0f)
        val a = m.indices[f * 3]; val b = m.indices[f * 3 + 1]; val c = m.indices[f * 3 + 2]
        val ax = m.positions[b * 3] - m.positions[a * 3]; val ay = m.positions[b * 3 + 1] - m.positions[a * 3 + 1]; val az = m.positions[b * 3 + 2] - m.positions[a * 3 + 2]
        val bx = m.positions[c * 3] - m.positions[a * 3]; val by = m.positions[c * 3 + 1] - m.positions[a * 3 + 1]; val bz = m.positions[c * 3 + 2] - m.positions[a * 3 + 2]
        normalized(floatArrayOf(ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx))
    }

    /** Monta as equações de Cauchy-Riemann em coordenadas locais de cada triângulo. */
    private fun solveLscm(m: PmxModel, faces: List<Int>, vertices: IntArray): FloatArray? {
        if (vertices.size < 3) return null
        val local = HashMap<Int, Int>(vertices.size)
        vertices.forEachIndexed { i, v -> local[v] = i }
        val a = 0; var b = 1; var far = -1f
        for (i in 1 until vertices.size) {
            val d = distance2(m, vertices[0], vertices[i]); if (d > far) { far = d; b = i }
        }
        if (far < 1e-12f) return null
        // Pinos: A=(0,0), B=(1,0); removem translação, rotação e escala global.
        val fixedValues = HashMap<Int, Float>()
        fixedValues[a * 2] = 0f; fixedValues[a * 2 + 1] = 0f
        fixedValues[b * 2] = 1f; fixedValues[b * 2 + 1] = 0f
        val rows = ArrayList<Row>(faces.size * 2)
        for (f in faces) {
            val o = f * 3
            val ids = intArrayOf(local[m.indices[o]] ?: continue, local[m.indices[o + 1]] ?: continue, local[m.indices[o + 2]] ?: continue)
            val p0 = point(m, vertices[ids[0]]); val p1 = point(m, vertices[ids[1]]); val p2 = point(m, vertices[ids[2]])
            val e1x = p1[0] - p0[0]; val e1y = p1[1] - p0[1]; val e1z = p1[2] - p0[2]
            val len = sqrt(e1x * e1x + e1y * e1y + e1z * e1z)
            if (len < 1e-8f) continue
            val e2x = p2[0] - p0[0]; val e2y = p2[1] - p0[1]; val e2z = p2[2] - p0[2]
            val x3 = (e1x * e2x + e1y * e2y + e1z * e2z) / len
            val y3 = sqrt(max(0f, e2x * e2x + e2y * e2y + e2z * e2z - x3 * x3))
            val area2 = len * y3
            if (area2 < 1e-10f) continue
            val gx = floatArrayOf(-y3 / area2, y3 / area2, 0f)
            val gy = floatArrayOf((x3 - len) / area2, -x3 / area2, len / area2)
            val weight = sqrt(area2 * .5f)
            val vars = IntArray(6); val coeff = FloatArray(6)
            for (i in 0..2) { vars[i * 2] = ids[i] * 2; vars[i * 2 + 1] = ids[i] * 2 + 1 }
            for (i in 0..2) { coeff[i * 2] = gx[i] * weight; coeff[i * 2 + 1] = -gy[i] * weight }
            rows.add(makeRow(vars, coeff, fixedValues))
            for (i in 0..2) { coeff[i * 2] = gy[i] * weight; coeff[i * 2 + 1] = gx[i] * weight }
            rows.add(makeRow(vars, coeff, fixedValues))
        }
        if (rows.size < 2) return null
        val freeMap = IntArray(vertices.size * 2) { -1 }
        var freeCount = 0
        for (v in freeMap.indices) if (v !in fixedValues) freeMap[v] = freeCount++
        if (freeCount == 0) return null
        val sparseRows = rows.map { row ->
            val ids = ArrayList<Int>(); val ws = ArrayList<Float>(); var fixed = row.fixed
            for (i in row.ids.indices) {
                val id = row.ids[i]; val w = row.weights[i]
                if (id >= 0) { val fId = freeMap[id]; if (fId >= 0) { ids.add(fId); ws.add(w) } }
            }
            Row(ids.toIntArray(), ws.toFloatArray(), fixed)
        }
        val rhs = FloatArray(freeCount)
        for (r in sparseRows) for (i in r.ids.indices) rhs[r.ids[i]] -= r.weights[i] * r.fixed
        fun apply(x: FloatArray): FloatArray {
            val out = FloatArray(freeCount)
            for (r in sparseRows) {
                var value = 0f
                for (i in r.ids.indices) value += r.weights[i] * x[r.ids[i]]
                for (i in r.ids.indices) out[r.ids[i]] += r.weights[i] * value
            }
            for (i in out.indices) out[i] += x[i] * 1e-8f
            return out
        }
        val x = FloatArray(freeCount)
        var residual = rhs.copyOf(); var direction = residual.copyOf()
        var rr = dot(residual, residual)
        val initial = rr
        val maxIterations = min(1600, max(80, freeCount * 8))
        var iterations = 0
        while (iterations++ < maxIterations && rr > max(1e-16f, initial * 1e-10f)) {
            val ad = apply(direction)
            val denom = dot(direction, ad)
            if (!denom.isFinite() || denom <= 1e-20f) break
            val alpha = rr / denom
            for (i in x.indices) { x[i] += alpha * direction[i]; residual[i] -= alpha * ad[i] }
            val next = dot(residual, residual)
            if (!next.isFinite()) return null
            val beta = if (rr > 1e-20f) next / rr else 0f
            for (i in direction.indices) direction[i] = residual[i] + beta * direction[i]
            rr = next
        }
        if (!x.all(Float::isFinite) || !rr.isFinite() || rr > max(1e-8f, initial * .15f)) return null
        val all = FloatArray(vertices.size * 2)
        for ((id, value) in fixedValues) all[id] = value
        for (i in freeMap.indices) if (freeMap[i] >= 0) all[i] = x[freeMap[i]]
        return normalizeChart(all)
    }

    private fun makeRow(vars: IntArray, coeff: FloatArray, fixed: Map<Int, Float>): Row {
        var fixedSum = 0f
        for (i in vars.indices) fixed[vars[i]]?.let { fixedSum += coeff[i] * it }
        return Row(vars.copyOf(), coeff.copyOf(), fixedSum)
    }

    private fun normalizeChart(values: FloatArray): FloatArray {
        var minU = Float.POSITIVE_INFINITY; var maxU = Float.NEGATIVE_INFINITY
        var minV = Float.POSITIVE_INFINITY; var maxV = Float.NEGATIVE_INFINITY
        for (i in values.indices step 2) { minU = min(minU, values[i]); maxU = max(maxU, values[i]); minV = min(minV, values[i + 1]); maxV = max(maxV, values[i + 1]) }
        val du = (maxU - minU).coerceAtLeast(1e-8f); val dv = (maxV - minV).coerceAtLeast(1e-8f)
        val side = max(du, dv)
        val offsetU = (side - du) * .5f; val offsetV = (side - dv) * .5f
        return FloatArray(values.size) { i -> if (i % 2 == 0) (values[i] - minU + offsetU) / side else (values[i] - minV + offsetV) / side }
    }

    private fun planarFallback(m: PmxModel, vertices: IntArray): FloatArray {
        val min = FloatArray(3) { Float.POSITIVE_INFINITY }; val max = FloatArray(3) { Float.NEGATIVE_INFINITY }
        for (v in vertices) for (k in 0..2) { val p = m.positions[v * 3 + k]; min[k] = min(min[k], p); max[k] = max(max[k], p) }
        val order = (0..2).sortedByDescending { max[it] - min[it] }
        val a = order[0]; val b = order[1]
        val du = (max[a] - min[a]).coerceAtLeast(1e-8f); val dv = (max[b] - min[b]).coerceAtLeast(1e-8f)
        val out = FloatArray(vertices.size * 2)
        vertices.forEachIndexed { i, v -> out[i * 2] = (m.positions[v * 3 + a] - min[a]) / du; out[i * 2 + 1] = (m.positions[v * 3 + b] - min[b]) / dv }
        return out
    }

    private fun point(m: PmxModel, v: Int) = floatArrayOf(m.positions[v * 3], m.positions[v * 3 + 1], m.positions[v * 3 + 2])
    private fun distance2(m: PmxModel, a: Int, b: Int): Float { var sum = 0f; for (k in 0..2) { val d = m.positions[a * 3 + k] - m.positions[b * 3 + k]; sum += d * d }; return sum }
    private fun normalized(v: FloatArray): FloatArray { val n = sqrt(v.sumOf { (it * it).toDouble() }.toFloat()).coerceAtLeast(1e-10f); return FloatArray(3) { v[it] / n } }
    private fun dot(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += a[i] * b[i]; return s }

    private fun remapFloat(source: FloatArray, mapping: IntArray, stride: Int): FloatArray {
        if (source.isEmpty()) return source.copyOf()
        val out = FloatArray(mapping.size * stride)
        for (i in mapping.indices) for (k in 0 until stride) out[i * stride + k] = source.getOrElse(mapping[i] * stride + k) { 0f }
        return out
    }
    private fun remapInt(source: IntArray, mapping: IntArray, stride: Int, fallback: Int): IntArray {
        if (source.isEmpty()) return source.copyOf()
        val out = IntArray(mapping.size * stride)
        for (i in mapping.indices) for (k in 0 until stride) out[i * stride + k] = source.getOrElse(mapping[i] * stride + k) { fallback }
        return out
    }
    private fun remapByte(source: ByteArray, mapping: IntArray, stride: Int): ByteArray {
        if (source.isEmpty()) return source.copyOf()
        val out = ByteArray(mapping.size * stride)
        for (i in mapping.indices) for (k in 0 until stride) out[i * stride + k] = source.getOrElse(mapping[i] * stride + k) { 0 }
        return out
    }
}
