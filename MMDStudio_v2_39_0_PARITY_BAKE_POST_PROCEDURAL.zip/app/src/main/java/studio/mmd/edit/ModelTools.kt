package studio.mmd.edit

import studio.mmd.mmd.PmxMaterial
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxMorph
import studio.mmd.mmd.PmxRigid
import studio.mmd.mmd.PmxJoint
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.asin
import kotlin.math.atan2

/** Multiplica quaternions no formato XYZW. */
private fun multiplyQuaternion(a: FloatArray, b: FloatArray): FloatArray {
    val ax = a[0]; val ay = a[1]; val az = a[2]; val aw = a[3]
    val bx = b[0]; val by = b[1]; val bz = b[2]; val bw = b[3]
    return floatArrayOf(
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz
    )
}

/** PMX guarda Euler XYZ em radianos. A rotação resultante usa a mesma ordem X→Y→Z da malha. */
private fun quaternionFromEulerXYZ(x: Float, y: Float, z: Float): FloatArray {
    val hx = x * .5f; val hy = y * .5f; val hz = z * .5f
    val qx = floatArrayOf(kotlin.math.sin(hx), 0f, 0f, kotlin.math.cos(hx))
    val qy = floatArrayOf(0f, kotlin.math.sin(hy), 0f, kotlin.math.cos(hy))
    val qz = floatArrayOf(0f, 0f, kotlin.math.sin(hz), kotlin.math.cos(hz))
    return multiplyQuaternion(multiplyQuaternion(qz, qy), qx)
}

private fun addGlobalEulerRotation(old: FloatArray, dxDegrees: Float, dyDegrees: Float, dzDegrees: Float): FloatArray {
    val ox = old.getOrElse(0) { 0f }.takeIf { it.isFinite() } ?: 0f
    val oy = old.getOrElse(1) { 0f }.takeIf { it.isFinite() } ?: 0f
    val oz = old.getOrElse(2) { 0f }.takeIf { it.isFinite() } ?: 0f
    val delta = quaternionFromEulerXYZ(Math.toRadians(dxDegrees.toDouble()).toFloat(), Math.toRadians(dyDegrees.toDouble()).toFloat(), Math.toRadians(dzDegrees.toDouble()).toFloat())
    val q = multiplyQuaternion(delta, quaternionFromEulerXYZ(ox, oy, oz))
    val qx = q[0]; val qy = q[1]; val qz = q[2]; val qw = q[3]
    val sinY = (2f * (qw * qy - qz * qx)).coerceIn(-1f, 1f)
    val x = atan2(2f * (qw * qx + qy * qz), 1f - 2f * (qx * qx + qy * qy))
    val y = asin(sinY)
    val z = atan2(2f * (qw * qz + qx * qy), 1f - 2f * (qy * qy + qz * qz))
    return floatArrayOf(x, y, z)
}

enum class SculptBrushMode { INFLATE, SMOOTH, PINCH, MOVE }

/** Deformações destrutivas controladas por pesos de máscara, sem tocar vértices com peso zero. */
enum class MeshMaskDeformMode { INFLATE, DEFLATE, PINCH, MOVE, FLATTEN, SCALE, ROTATE }

/** Ferramentas não destrutivas de malha/UV/material. Toda operação é feita em cópias e tem Undo/Redo. */
class ModelToolsSession(val source: PmxModel, private val historyLimit: Int = 24) {
    private var positions = source.positions.copyOf()
    private var normals = source.normals.copyOf()
    private var uvs = source.uvs.copyOf()
    private var materials = source.materials.toList()
    private var bones = source.bones.toList()
    private var morphs = source.morphs.toList()
    private var rigidBodies = source.rigidBodies.toList()
    private var joints = source.joints.toList()
    private val selected = LinkedHashSet<Int>()
    private val undo = ArrayList<Snapshot>()
    private val redo = ArrayList<Snapshot>()

    private data class Snapshot(val positions: FloatArray, val normals: FloatArray, val uvs: FloatArray, val materials: List<PmxMaterial>, val bones: List<PmxBone>, val morphs: List<PmxMorph>, val rigidBodies: List<PmxRigid>, val joints: List<PmxJoint>)
    data class Report(val changed: Int, val message: String)

    val canUndo: Boolean get() = undo.isNotEmpty()
    val canRedo: Boolean get() = redo.isNotEmpty()
    val vertexCount: Int get() = source.vertexCount
    val triangleCount: Int get() = source.indices.size / 3
    val materialCount: Int get() = materials.size
    val selectedCount: Int get() = selected.size
    fun selectedVertices(): IntArray = selected.toIntArray()
    fun isSelected(vertex: Int): Boolean = vertex in selected

    private fun snapshot() = Snapshot(positions.copyOf(), normals.copyOf(), uvs.copyOf(), materials.toList(), bones.toList(), morphs.toList(), rigidBodies.toList(), joints.toList())
    private fun checkpoint() {
        undo.add(snapshot())
        if (undo.size > historyLimit.coerceAtLeast(1)) undo.removeAt(0)
        redo.clear()
    }

    fun undo(): Boolean {
        if (undo.isEmpty()) return false
        redo.add(snapshot())
        val s = undo.removeAt(undo.lastIndex)
        positions = s.positions; normals = s.normals; uvs = s.uvs; materials = s.materials; bones = s.bones; morphs = s.morphs; rigidBodies = s.rigidBodies; joints = s.joints
        return true
    }

    fun redo(): Boolean {
        if (redo.isEmpty()) return false
        undo.add(snapshot())
        val s = redo.removeAt(redo.lastIndex)
        positions = s.positions; normals = s.normals; uvs = s.uvs; materials = s.materials; bones = s.bones; morphs = s.morphs; rigidBodies = s.rigidBodies; joints = s.joints
        return true
    }

    /** Seleção de vértices por operações topológicas; seleção não altera o PMX até aplicar uma ferramenta. */
    fun selectAll(): Int { selected.clear(); selected.addAll(0 until vertexCount); return selected.size }
    fun clearSelection(): Int { selected.clear(); return 0 }
    fun invertSelection(): Int { val next = (0 until vertexCount).filter { it !in selected }; selected.clear(); selected.addAll(next); return selected.size }
    fun selectRange(first: Int, last: Int, additive: Boolean = false): Int {
        val a = min(first, last).coerceIn(0, (vertexCount - 1).coerceAtLeast(0))
        val b = max(first, last).coerceIn(0, (vertexCount - 1).coerceAtLeast(0))
        if (!additive) selected.clear()
        if (vertexCount > 0) for (v in a..b) selected.add(v)
        return selected.size
    }

    /** Seleciona os vértices usados pelas faces do material PMX (indexCount é contado em índices, não triângulos). */
    fun selectByMaterial(materialIndex: Int, additive: Boolean = false): Int {
        require(materialIndex in materials.indices) { "Material inválido" }
        var start = 0
        for (i in 0 until materialIndex) start += materials[i].indexCount.coerceAtLeast(0)
        val end = (start + materials[materialIndex].indexCount.coerceAtLeast(0)).coerceAtMost(source.indices.size)
        if (!additive) selected.clear()
        for (i in start until end) source.indices.getOrNull(i)?.takeIf { it in 0 until vertexCount }?.let { selected.add(it) }
        return selected.size
    }

    /** Seleciona vértices com influência mínima de um osso específico. */
    fun selectByBone(boneIndex: Int, minimumWeight: Float = 0.01f, additive: Boolean = false): Int {
        require(boneIndex in bones.indices) { "Osso inválido" }
        val threshold = minimumWeight.coerceIn(0f, 1f)
        if (!additive) selected.clear()
        for (v in 0 until vertexCount) for (k in 0..3) {
            val o = v * 4 + k
            if (source.boneIndices.getOrElse(o) { -1 } == boneIndex && source.boneWeights.getOrElse(o) { 0f } >= threshold) { selected.add(v); break }
        }
        return selected.size
    }

    /** Seleção espacial inclusiva por caixa delimitadora no espaço local PMX. */
    fun selectInBounds(minX: Float, maxX: Float, minY: Float, maxY: Float, minZ: Float, maxZ: Float, additive: Boolean = false): Int {
        val bounds = listOf(minX, maxX, minY, maxY, minZ, maxZ)
        require(bounds.all { it.isFinite() }) { "Limites da seleção inválidos" }
        if (!additive) selected.clear()
        for (v in 0 until vertexCount) {
            val o = v * 3; val x = positions[o]; val y = positions[o + 1]; val z = positions[o + 2]
            if (x in min(minX, maxX)..max(minX, maxX) && y in min(minY, maxY)..max(minY, maxY) && z in min(minZ, maxZ)..max(minZ, maxZ)) selected.add(v)
        }
        return selected.size
    }

    private fun adjacency(): Array<LinkedHashSet<Int>> {
        val a = Array(vertexCount) { LinkedHashSet<Int>() }
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val x = source.indices[i]; val y = source.indices[i + 1]; val z = source.indices[i + 2]
            if (x !in 0 until vertexCount || y !in 0 until vertexCount || z !in 0 until vertexCount) continue
            a[x].add(y); a[x].add(z); a[y].add(x); a[y].add(z); a[z].add(x); a[z].add(y)
        }
        return a
    }

    fun growSelection(rings: Int = 1): Int {
        val a = adjacency(); repeat(rings.coerceIn(1, 32)) { val next = selected.toMutableSet(); selected.forEach { v -> next.addAll(a[v]) }; selected.clear(); selected.addAll(next) }
        return selected.size
    }
    fun shrinkSelection(rings: Int = 1): Int {
        val a = adjacency(); repeat(rings.coerceIn(1, 32)) { val next = selected.filterTo(LinkedHashSet()) { v -> a[v].isNotEmpty() && a[v].all { it in selected } }; selected.clear(); selected.addAll(next) }
        return selected.size
    }
    /** Seleciona somente o componente topológico conectado ao vértice inicial. */
    fun selectConnectedComponent(seedVertex: Int, additive: Boolean = false): Int {
        require(seedVertex in 0 until vertexCount) { "Vértice inicial inválido" }
        val graph = adjacency()
        val visited = BooleanArray(vertexCount)
        val queue = ArrayDeque<Int>()
        queue.add(seedVertex); visited[seedVertex] = true
        while (queue.isNotEmpty()) {
            val v = queue.removeFirst()
            for (n in graph[v]) if (!visited[n]) { visited[n] = true; queue.add(n) }
        }
        if (!additive) selected.clear()
        for (v in visited.indices) if (visited[v]) selected.add(v)
        return selected.size
    }

    /** Seleção geodésica: distância acumulada pelas arestas, não distância reta através do corpo. */
    fun selectGeodesicRadius(seedVertex: Int, radius: Float, additive: Boolean = false): Int {
        require(seedVertex in 0 until vertexCount) { "Vértice inicial inválido" }
        require(radius.isFinite() && radius >= 0f) { "Raio geodésico inválido" }
        val graph = adjacency()
        val distances = FloatArray(vertexCount) { Float.POSITIVE_INFINITY }
        val queue = java.util.PriorityQueue<Pair<Float, Int>>(compareBy<Pair<Float, Int>> { it.first })
        distances[seedVertex] = 0f; queue.add(0f to seedVertex)
        while (queue.isNotEmpty()) {
            val (distance, v) = queue.poll()
            if (distance != distances[v] || distance > radius) continue
            val o = v * 3
            for (n in graph[v]) {
                val no = n * 3
                val dx = positions[o] - positions[no]; val dy = positions[o + 1] - positions[no + 1]; val dz = positions[o + 2] - positions[no + 2]
                val edge = sqrt(dx * dx + dy * dy + dz * dz)
                if (!edge.isFinite()) continue
                val next = distance + edge
                if (next <= radius && next < distances[n]) { distances[n] = next; queue.add(next to n) }
            }
        }
        if (!additive) selected.clear()
        for (v in distances.indices) if (distances[v].isFinite() && distances[v] <= radius) selected.add(v)
        return selected.size
    }

    /** Substitui a seleção pelos vértices cuja máscara temporária excede o limiar. */
    fun selectByMask(mask: FloatArray, threshold: Float = .5f, additive: Boolean = false): Int {
        require(mask.size == vertexCount) { "Máscara incompatível" }
        val t = threshold.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: .5f
        if (!additive) selected.clear()
        for (v in mask.indices) if (mask[v].isFinite() && mask[v] >= t) selected.add(v)
        return selected.size
    }

    /** Relaxamento Taubin (passo positivo + negativo) guiado por máscara e limitado por deslocamento. */
    fun relaxMasked(mask: FloatArray, iterations: Int = 4, strength: Float = .35f,
                    maxDisplacement: Float = .025f, preserveBoundary: Boolean = true): Report {
        require(mask.size == vertexCount) { "Máscara incompatível" }
        val power = strength.takeIf { it.isFinite() }?.coerceIn(0f, .85f) ?: .35f
        val limit = maxDisplacement.takeIf { it.isFinite() }?.coerceIn(.0001f, .5f) ?: .025f
        if (vertexCount == 0 || power <= 0f) return Report(0, "Máscara vazia ou intensidade zero")
        val graph = adjacency()
        val active = mask.indices.filter { v ->
            val o = v * 3
            mask[v].isFinite() && mask[v] > 1e-4f && graph[v].isNotEmpty() &&
                positions[o].isFinite() && positions[o + 1].isFinite() && positions[o + 2].isFinite()
        }
        if (active.isEmpty()) return Report(0, "Nenhum vértice com máscara e vizinhança")
        val boundary = BooleanArray(vertexCount)
        if (preserveBoundary) {
            val uses = HashMap<Long, Int>()
            fun add(a: Int, b: Int) { val lo = min(a, b); val hi = max(a, b); val key = (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL); uses[key] = (uses[key] ?: 0) + 1 }
            for (i in source.indices.indices step 3) {
                if (i + 2 >= source.indices.size) break
                val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
                if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
                add(a,b); add(b,c); add(c,a)
            }
            uses.forEach { (key, count) -> if (count == 1) { boundary[(key shr 32).toInt()] = true; boundary[key.toInt()] = true } }
        }
        val original = positions.copyOf()
        var work = positions.copyOf()
        val lambda = .48f * power
        val mu = -lambda * 1.02f
        repeat(iterations.coerceIn(1, 16)) {
            for (factor in floatArrayOf(lambda, mu)) {
                val src = work.copyOf()
                for (v in active) {
                    if (preserveBoundary && boundary[v]) continue
                    val w = mask[v].takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
                    if (w <= 0f) continue
                    val o = v * 3
                    if (!src[o].isFinite() || !src[o + 1].isFinite() || !src[o + 2].isFinite()) continue
                    var ax = 0f; var ay = 0f; var az = 0f; var count = 0
                    for (n in graph[v]) {
                        val no = n * 3
                        if (!src[no].isFinite() || !src[no + 1].isFinite() || !src[no + 2].isFinite()) continue
                        ax += src[no]; ay += src[no + 1]; az += src[no + 2]; count++
                    }
                    if (count == 0) continue
                    val inv = 1f / count
                    val k = factor * w
                    work[o] = src[o] + (ax * inv - src[o]) * k
                    work[o + 1] = src[o + 1] + (ay * inv - src[o + 1]) * k
                    work[o + 2] = src[o + 2] + (az * inv - src[o + 2]) * k
                }
            }
        }
        var changed = 0
        for (v in active) {
            val o = v * 3; var dx = work[o] - original[o]; var dy = work[o + 1] - original[o + 1]; var dz = work[o + 2] - original[o + 2]
            val distance = sqrt(dx * dx + dy * dy + dz * dz)
            val allowed = limit * (mask[v].coerceIn(0f, 1f))
            if (!distance.isFinite()) continue
            if (distance > allowed && distance > 1e-9f) { val s = allowed / distance; dx *= s; dy *= s; dz *= s }
            if (dx * dx + dy * dy + dz * dz > 1e-14f) changed++
        }
        if (changed == 0) return Report(0, "Relaxamento não produziu deslocamento")
        checkpoint()
        for (v in active) {
            val o = v * 3; var dx = work[o] - original[o]; var dy = work[o + 1] - original[o + 1]; var dz = work[o + 2] - original[o + 2]
            val distance = sqrt(dx * dx + dy * dy + dz * dz); val allowed = limit * mask[v].coerceIn(0f, 1f)
            if (distance > allowed && distance > 1e-9f) { val s = allowed / distance; dx *= s; dy *= s; dz *= s }
            positions[o] = original[o] + dx; positions[o + 1] = original[o + 1] + dy; positions[o + 2] = original[o + 2] + dz
        }
        recalculateNormalsNoHistory()
        return Report(changed, "Relaxamento Taubin em $changed vértices · bordas ${if (preserveBoundary) "protegidas" else "livres"}")
    }

    /** Remove picos locais isolados guiado por máscara, com limiar relativo à escala dos vizinhos. */
    fun removeSpikesMasked(mask: FloatArray, strength: Float = .65f, thresholdRatio: Float = 1.6f,
                           maxCorrection: Float = .03f, preserveBoundary: Boolean = true): Report {
        require(mask.size == vertexCount) { "Máscara incompatível" }
        val power = strength.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: .65f
        val threshold = thresholdRatio.takeIf { it.isFinite() }?.coerceIn(.5f, 8f) ?: 1.6f
        val limit = maxCorrection.takeIf { it.isFinite() }?.coerceIn(.0001f, .5f) ?: .03f
        val graph = adjacency(); val boundary = BooleanArray(vertexCount)
        if (preserveBoundary) {
            val uses = HashMap<Long, Int>()
            fun add(a: Int, b: Int) { val lo = min(a,b); val hi = max(a,b); val key=(lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL); uses[key]=(uses[key] ?: 0)+1 }
            for (i in source.indices.indices step 3) { if (i+2 >= source.indices.size) break; val a=source.indices[i]; val b=source.indices[i+1]; val c=source.indices[i+2]; if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue; add(a,b); add(b,c); add(c,a) }
            uses.forEach { (key,count) -> if (count == 1) { boundary[(key shr 32).toInt()] = true; boundary[key.toInt()] = true } }
        }
        val src = positions.copyOf(); val updates = HashMap<Int, FloatArray>()
        for (v in 0 until vertexCount) {
            val w = mask[v].takeIf { it.isFinite() }?.coerceIn(0f,1f) ?: 0f
            val vo = v * 3
            if (w <= 1e-4f || graph[v].size < 3 || (preserveBoundary && boundary[v]) ||
                !src[vo].isFinite() || !src[vo + 1].isFinite() || !src[vo + 2].isFinite()) continue
            val ns = graph[v].filter { n -> val o=n*3; src[o].isFinite() && src[o+1].isFinite() && src[o+2].isFinite() }
            if (ns.size < 3) continue
            var cx=0f; var cy=0f; var cz=0f; val radialLengths=FloatArray(ns.size)
            for ((i,n) in ns.withIndex()) { val o=n*3; cx+=src[o]; cy+=src[o+1]; cz+=src[o+2]; val dx=src[o]-src[vo]; val dy=src[o+1]-src[vo+1]; val dz=src[o+2]-src[vo+2]; radialLengths[i]=sqrt(dx*dx+dy*dy+dz*dz) }
            val inv=1f/ns.size; cx*=inv; cy*=inv; cz*=inv
            val neighborEdges=ArrayList<Float>()
            for (i in ns.indices) for (j in i+1 until ns.size) if (ns[j] in graph[ns[i]]) {
                val a=ns[i]*3; val b=ns[j]*3; val ex=src[a]-src[b]; val ey=src[a+1]-src[b+1]; val ez=src[a+2]-src[b+2]
                val edge=sqrt(ex*ex+ey*ey+ez*ez); if (edge.isFinite() && edge > 1e-7f) neighborEdges.add(edge)
            }
            radialLengths.sort(); neighborEdges.sort()
            val localScale=(neighborEdges.getOrNull(neighborEdges.size/2) ?: (radialLengths[radialLengths.size/2] * .25f)).coerceAtLeast(1e-6f)
            val o=vo; val dx=cx-src[o]; val dy=cy-src[o+1]; val dz=cz-src[o+2]; val deviation=sqrt(dx*dx+dy*dy+dz*dz)
            val excess=(deviation-localScale*threshold).coerceAtLeast(0f)
            if (excess <= 0f) continue
            val move=(excess*power*w).coerceAtMost(limit)
            val ratio=(move/deviation.coerceAtLeast(1e-8f)).coerceIn(0f,1f)
            updates[v]=floatArrayOf(src[o]+dx*ratio,src[o+1]+dy*ratio,src[o+2]+dz*ratio)
        }
        if (updates.isEmpty()) return Report(0, "Nenhum pico isolado acima do limiar foi encontrado")
        checkpoint(); updates.forEach { (v,p) -> val o=v*3; positions[o]=p[0]; positions[o+1]=p[1]; positions[o+2]=p[2] }
        recalculateNormalsNoHistory()
        return Report(updates.size, "${updates.size} picos locais corrigidos · limite ${"%.4f".format(java.util.Locale.US, limit)}")
    }

    /**
     * Aplica escultura ponderada pela máscara. A operação calcula todos os deslocamentos
     * a partir da mesma geometria de origem, limita o movimento por vértice e pode fixar
     * as bordas abertas. Vértices com máscara zero permanecem bit a bit inalterados.
     */
    fun deformMasked(
        mask: FloatArray,
        mode: MeshMaskDeformMode,
        strength: Float = .5f,
        maxDisplacement: Float = .025f,
        moveX: Float = 0f,
        moveY: Float = 0f,
        moveZ: Float = 0f,
        preserveBoundary: Boolean = true,
        scaleFactor: Float = .85f,
        rotateX: Float = 0f,
        rotateY: Float = 0f,
        rotateZ: Float = 0f
    ): Report {
        require(mask.size == vertexCount) { "Máscara incompatível com a malha" }
        require(listOf(strength, maxDisplacement, moveX, moveY, moveZ, scaleFactor, rotateX, rotateY, rotateZ).all { it.isFinite() }) { "Parâmetros de deformação inválidos" }
        val power = strength.coerceIn(0f, 1f)
        val limit = maxDisplacement.coerceIn(.0001f, .5f)
        if (vertexCount == 0 || power <= 1e-6f) return Report(0, "Máscara vazia ou intensidade zero")

        val weights = FloatArray(vertexCount) { i -> mask[i].takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f }
        var totalWeight = 0f
        var cx = 0f; var cy = 0f; var cz = 0f
        var nx = 0f; var ny = 0f; var nz = 0f
        for (v in 0 until vertexCount) {
            val w = weights[v]
            val o = v * 3
            if (w <= 1e-6f || !positions[o].isFinite() || !positions[o + 1].isFinite() || !positions[o + 2].isFinite()) continue
            totalWeight += w
            cx += positions[o] * w; cy += positions[o + 1] * w; cz += positions[o + 2] * w
            var vx = normals.getOrElse(o) { 0f }; var vy = normals.getOrElse(o + 1) { 0f }; var vz = normals.getOrElse(o + 2) { 0f }
            val nLen = sqrt(vx * vx + vy * vy + vz * vz)
            if (nLen > 1e-8f && nLen.isFinite()) { vx /= nLen; vy /= nLen; vz /= nLen; nx += vx * w; ny += vy * w; nz += vz * w }
        }
        if (totalWeight <= 1e-6f) return Report(0, "A máscara não contém vértices válidos")
        cx /= totalWeight; cy /= totalWeight; cz /= totalWeight
        val planeLen = sqrt(nx * nx + ny * ny + nz * nz)
        if (planeLen > 1e-8f && planeLen.isFinite()) { nx /= planeLen; ny /= planeLen; nz /= planeLen }
        else { nx = 0f; ny = 1f; nz = 0f }

        val boundary = BooleanArray(vertexCount)
        if (preserveBoundary) {
            val uses = HashMap<Long, Int>()
            fun addEdge(a: Int, b: Int) {
                if (a !in 0 until vertexCount || b !in 0 until vertexCount) return
                val lo = min(a, b); val hi = max(a, b)
                val key = (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
                uses[key] = (uses[key] ?: 0) + 1
            }
            for (i in source.indices.indices step 3) {
                if (i + 2 >= source.indices.size) break
                val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
                if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
                addEdge(a, b); addEdge(b, c); addEdge(c, a)
            }
            uses.forEach { (key, count) ->
                if (count == 1) { boundary[(key shr 32).toInt()] = true; boundary[key.toInt()] = true }
            }
        }

        val original = positions.copyOf()
        val next = original.copyOf()
        var changed = 0
        for (v in 0 until vertexCount) {
            val w = weights[v]
            if (w <= 1e-6f || (preserveBoundary && boundary[v])) continue
            val o = v * 3
            val px = original[o]; val py = original[o + 1]; val pz = original[o + 2]
            if (!px.isFinite() || !py.isFinite() || !pz.isFinite()) continue
            val amount = power * w
            var dx = 0f; var dy = 0f; var dz = 0f
            when (mode) {
                MeshMaskDeformMode.INFLATE, MeshMaskDeformMode.DEFLATE -> {
                    var vx = normals.getOrElse(o) { 0f }; var vy = normals.getOrElse(o + 1) { 0f }; var vz = normals.getOrElse(o + 2) { 0f }
                    var length = sqrt(vx * vx + vy * vy + vz * vz)
                    if (!length.isFinite() || length <= 1e-8f) { vx = nx; vy = ny; vz = nz; length = 1f }
                    if (length > 1e-8f) { vx /= length; vy /= length; vz /= length }
                    val sign = if (mode == MeshMaskDeformMode.INFLATE) 1f else -1f
                    val distance = limit * amount * sign
                    dx = vx * distance; dy = vy * distance; dz = vz * distance
                }
                MeshMaskDeformMode.PINCH -> {
                    dx = (cx - px) * amount * .35f
                    dy = (cy - py) * amount * .35f
                    dz = (cz - pz) * amount * .35f
                }
                MeshMaskDeformMode.MOVE -> {
                    dx = moveX * amount; dy = moveY * amount; dz = moveZ * amount
                }
                MeshMaskDeformMode.FLATTEN -> {
                    val distance = (px - cx) * nx + (py - cy) * ny + (pz - cz) * nz
                    val correction = -distance * amount
                    dx = nx * correction; dy = ny * correction; dz = nz * correction
                }
                MeshMaskDeformMode.SCALE -> {
                    val factor = 1f + (scaleFactor.coerceIn(.1f, 3f) - 1f) * amount
                    dx = (px - cx) * (factor - 1f)
                    dy = (py - cy) * (factor - 1f)
                    dz = (pz - cz) * (factor - 1f)
                }
                MeshMaskDeformMode.ROTATE -> {
                    // Quaternion por vértice, sem alocar arrays temporários em malhas grandes.
                    val hx = Math.toRadians((rotateX.coerceIn(-360f, 360f) * amount).toDouble()).toFloat() * .5f
                    val hy = Math.toRadians((rotateY.coerceIn(-360f, 360f) * amount).toDouble()).toFloat() * .5f
                    val hz = Math.toRadians((rotateZ.coerceIn(-360f, 360f) * amount).toDouble()).toFloat() * .5f
                    val sx = kotlin.math.sin(hx); val cxr = kotlin.math.cos(hx)
                    val sy = kotlin.math.sin(hy); val cyr = kotlin.math.cos(hy)
                    val sz = kotlin.math.sin(hz); val czr = kotlin.math.cos(hz)
                    val qx = czr * cyr * sx - sz * sy * cxr
                    val qy = czr * sy * cxr + sz * cyr * sx
                    val qz = sz * cyr * cxr - czr * sy * sx
                    val qw = czr * cyr * cxr + sz * sy * sx
                    val vx = px - cx; val vy = py - cy; val vz = pz - cz
                    val tx = 2f * (qy * vz - qz * vy)
                    val ty = 2f * (qz * vx - qx * vz)
                    val tz = 2f * (qx * vy - qy * vx)
                    val rx = vx + qw * tx + (qy * tz - qz * ty)
                    val ry = vy + qw * ty + (qz * tx - qx * tz)
                    val rz = vz + qw * tz + (qx * ty - qy * tx)
                    dx = rx - vx; dy = ry - vy; dz = rz - vz
                }
            }
            val length = sqrt(dx * dx + dy * dy + dz * dz)
            if (!length.isFinite() || length <= 1e-8f) continue
            if (length > limit) { val scale = limit / length; dx *= scale; dy *= scale; dz *= scale }
            next[o] = px + dx; next[o + 1] = py + dy; next[o + 2] = pz + dz
            if (dx * dx + dy * dy + dz * dz > 1e-14f) changed++
        }
        if (changed == 0) return Report(0, "A operação não encontrou vértices deformáveis (verifique máscara e bordas)")
        checkpoint()
        positions = next
        recalculateNormalsNoHistory()
        val label = when (mode) {
            MeshMaskDeformMode.INFLATE -> "Inflar"; MeshMaskDeformMode.DEFLATE -> "Encolher";
            MeshMaskDeformMode.PINCH -> "Pinçar"; MeshMaskDeformMode.MOVE -> "Mover";
            MeshMaskDeformMode.FLATTEN -> "Achatar"; MeshMaskDeformMode.SCALE -> "Escalar";
            MeshMaskDeformMode.ROTATE -> "Girar"
        }
        return Report(changed, "$label pela máscara: $changed vértices · limite ${"%.4f".format(java.util.Locale.US, limit)} · bordas ${if (preserveBoundary) "protegidas" else "livres"}")
    }

    fun selectBoundary(): Int {
        val edgeUse = HashMap<Long, Int>()
        fun key(a: Int, b: Int): Long { val lo = min(a, b); val hi = max(a, b); return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL) }
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
            for ((x, y) in listOf(a to b, b to c, c to a)) { val k = key(x, y); edgeUse[k] = (edgeUse[k] ?: 0) + 1 }
        }
        selected.clear()
        edgeUse.filterValues { it == 1 }.keys.forEach { k -> selected.add((k shr 32).toInt()); selected.add(k.toInt()) }
        return selected.size
    }

    /** Escultura local: translação, escala e rotação em torno do centroide da seleção. */
    fun transformSelected(tx: Float, ty: Float, tz: Float, scale: Float = 1f, rx: Float = 0f, ry: Float = 0f, rz: Float = 0f): Report {
        require(listOf(tx, ty, tz, scale, rx, ry, rz).all { it.isFinite() } && abs(scale) > 1e-6f) { "Transformação da seleção inválida" }
        if (selected.isEmpty()) return Report(0, "Nenhum vértice selecionado")
        val ids = selected.toIntArray(); var cx = 0f; var cy = 0f; var cz = 0f
        ids.forEach { val o = it * 3; cx += positions[o]; cy += positions[o + 1]; cz += positions[o + 2] }
        cx /= ids.size; cy /= ids.size; cz /= ids.size
        val ax = Math.toRadians(rx.toDouble()).toFloat(); val ay = Math.toRadians(ry.toDouble()).toFloat(); val az = Math.toRadians(rz.toDouble()).toFloat()
        val sx = kotlin.math.sin(ax); val cxr = kotlin.math.cos(ax); val sy = kotlin.math.sin(ay); val cyr = kotlin.math.cos(ay); val sz = kotlin.math.sin(az); val czr = kotlin.math.cos(az)
        fun vector(x0: Float, y0: Float, z0: Float): FloatArray {
            var x = x0 * scale; var y = y0 * scale; var z = z0 * scale
            val y1 = y * cxr - z * sx; val z1 = y * sx + z * cxr; y = y1; z = z1
            val x2 = x * cyr + z * sy; val z2 = -x * sy + z * cyr; x = x2; z = z2
            return floatArrayOf(x * czr - y * sz, x * sz + y * czr, z)
        }
        checkpoint()
        ids.forEach { v -> val o = v * 3; val q = vector(positions[o] - cx, positions[o + 1] - cy, positions[o + 2] - cz); positions[o] = cx + q[0] + tx; positions[o + 1] = cy + q[1] + ty; positions[o + 2] = cz + q[2] + tz }
        val selectedSet = ids.toSet()
        morphs = morphs.map { m ->
            if (m.type != 1 || m.vertexIdx == null || m.vertexDelta == null) m else {
                val d = m.vertexDelta.copyOf()
                for (i in m.vertexIdx.indices) if (m.vertexIdx[i] in selectedSet && i * 3 + 2 < d.size) { val q = vector(d[i * 3], d[i * 3 + 1], d[i * 3 + 2]); d[i * 3] = q[0]; d[i * 3 + 1] = q[1]; d[i * 3 + 2] = q[2] }
                PmxMorph(m.name, m.nameEn, m.panel, m.type, m.vertexIdx.copyOf(), d, m.boneIdx?.copyOf(), m.boneTrans?.copyOf(), m.boneRot?.copyOf(), m.groupIdx?.copyOf(), m.groupRate?.copyOf(), m.raw?.copyOf(), m.count)
            }
        }
        recalculateNormalsNoHistory()
        return Report(ids.size, "Escultura aplicada em ${ids.size} vértices")
    }

    fun inflateSelected(distance: Float): Report {
        require(distance.isFinite()) { "Distância inválida" }
        if (selected.isEmpty() || abs(distance) < 1e-8f) return Report(0, "Nenhum vértice selecionado ou distância zero")
        checkpoint()
        selected.forEach { v -> val o = v * 3; val n = normals.getOrElse(o) { 0f }; val ny = normals.getOrElse(o + 1) { 1f }; val nz = normals.getOrElse(o + 2) { 0f }; positions[o] += n * distance; positions[o + 1] += ny * distance; positions[o + 2] += nz * distance }
        recalculateNormalsNoHistory()
        return Report(selected.size, "Inflar aplicado em ${selected.size} vértices")
    }

    /** Pincel de escultura espacial com falloff suave. A operação inteira vira um único Undo. */
    fun sculptBrush(
        centerX: Float, centerY: Float, centerZ: Float, radius: Float, strength: Float,
        mode: SculptBrushMode, moveX: Float = 0f, moveY: Float = 0f, moveZ: Float = 0f
    ): Report {
        require(listOf(centerX, centerY, centerZ, radius, strength, moveX, moveY, moveZ).all { it.isFinite() }) { "Parâmetros do pincel inválidos" }
        require(radius > 0f) { "Raio do pincel deve ser positivo" }
        val power = strength.coerceIn(0f, 1f)
        if (power <= 0f || vertexCount == 0) return Report(0, "Pincel sem intensidade")
        val ids = IntArray(vertexCount); val falloff = FloatArray(vertexCount); var count = 0
        val r2 = radius * radius
        for (v in 0 until vertexCount) {
            val o = v * 3
            val dx = positions[o] - centerX; val dy = positions[o + 1] - centerY; val dz = positions[o + 2] - centerZ
            val d2 = dx * dx + dy * dy + dz * dz
            if (d2 <= r2) {
                val t = (1f - sqrt(d2 / r2)).coerceIn(0f, 1f)
                falloff[v] = t * t * (3f - 2f * t); ids[count++] = v
            }
        }
        if (count == 0) return Report(0, "Nenhum vértice dentro do raio")
        checkpoint()
        val neighbors = if (mode == SculptBrushMode.SMOOTH) adjacency() else null
        val before = if (neighbors != null) positions.copyOf() else positions
        for (k in 0 until count) {
            val v = ids[k]; val o = v * 3; val amount = power * falloff[v]
            when (mode) {
                SculptBrushMode.INFLATE -> {
                    var nx = normals[o]; var ny = normals[o + 1]; var nz = normals[o + 2]
                    var len = sqrt(nx * nx + ny * ny + nz * nz)
                    if (len < 1e-6f) { nx = positions[o] - centerX; ny = positions[o + 1] - centerY; nz = positions[o + 2] - centerZ; len = sqrt(nx * nx + ny * ny + nz * nz) }
                    if (len > 1e-6f) { nx /= len; ny /= len; nz /= len }
                    val d = radius * .18f * amount
                    positions[o] += nx * d; positions[o + 1] += ny * d; positions[o + 2] += nz * d
                }
                SculptBrushMode.PINCH -> {
                    positions[o] += (centerX - positions[o]) * amount * .35f
                    positions[o + 1] += (centerY - positions[o + 1]) * amount * .35f
                    positions[o + 2] += (centerZ - positions[o + 2]) * amount * .35f
                }
                SculptBrushMode.MOVE -> {
                    positions[o] += moveX * amount; positions[o + 1] += moveY * amount; positions[o + 2] += moveZ * amount
                }
                SculptBrushMode.SMOOTH -> {
                    val ns = neighbors?.get(v).orEmpty()
                    if (ns.isNotEmpty()) {
                        var ax = 0f; var ay = 0f; var az = 0f
                        ns.forEach { n -> val no = n * 3; ax += before[no]; ay += before[no + 1]; az += before[no + 2] }
                        val inv = 1f / ns.size
                        positions[o] += (ax * inv - before[o]) * amount
                        positions[o + 1] += (ay * inv - before[o + 1]) * amount
                        positions[o + 2] += (az * inv - before[o + 2]) * amount
                    }
                }
            }
        }
        recalculateNormalsNoHistory()
        return Report(count, "$count vértices afetados pelo pincel ${mode.name.lowercase()}")
    }

    /** Suavização Laplaciana localizada, sem mover vértices fora da seleção. */
    fun smoothSelected(iterations: Int = 1, strength: Float = 0.5f): Report {
        if (selected.isEmpty()) return Report(0, "Nenhum vértice selecionado")
        val a = adjacency(); val amount = strength.coerceIn(0f, 1f); val passes = iterations.coerceIn(1, 20)
        if (amount <= 0f) return Report(0, "Intensidade zero")
        checkpoint()
        repeat(passes) {
            val src = positions.copyOf()
            for (v in selected) {
                val around = a[v]; if (around.isEmpty()) continue
                var x = 0f; var y = 0f; var z = 0f
                around.forEach { val o = it * 3; x += src[o]; y += src[o + 1]; z += src[o + 2] }
                val o = v * 3; val k = amount / around.size
                positions[o] = src[o] + (x - src[o] * around.size) * k
                positions[o + 1] = src[o + 1] + (y - src[o + 1] * around.size) * k
                positions[o + 2] = src[o + 2] + (z - src[o + 2] * around.size) * k
            }
        }
        recalculateNormalsNoHistory()
        return Report(selected.size, "Suavização aplicada em ${selected.size} vértices")
    }

    private fun recalculateNormalsNoHistory() {
        val out = FloatArray(vertexCount * 3)
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
            val ao = a * 3; val bo = b * 3; val co = c * 3
            val abx = positions[bo] - positions[ao]; val aby = positions[bo + 1] - positions[ao + 1]; val abz = positions[bo + 2] - positions[ao + 2]
            val acx = positions[co] - positions[ao]; val acy = positions[co + 1] - positions[ao + 1]; val acz = positions[co + 2] - positions[ao + 2]
            val nx = aby * acz - abz * acy; val ny = abz * acx - abx * acz; val nz = abx * acy - aby * acx
            for (v in intArrayOf(a, b, c)) { val o = v * 3; out[o] += nx; out[o + 1] += ny; out[o + 2] += nz }
        }
        for (v in 0 until vertexCount) { val o = v * 3; val len = sqrt(out[o] * out[o] + out[o + 1] * out[o + 1] + out[o + 2] * out[o + 2]); if (len > 1e-9f && len.isFinite()) { normals[o] = out[o] / len; normals[o + 1] = out[o + 1] / len; normals[o + 2] = out[o + 2] / len } }
    }

    /** Projeção cilíndrica em torno de Y. U representa o ângulo e V a altura normalizada. */
    fun cylindricalUv(): Report {
        if (vertexCount == 0) return Report(0, "Malha vazia")
        var minY = Float.POSITIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY
        for (v in 0 until vertexCount) { val y = positions[v * 3 + 1]; if (y.isFinite()) { minY = min(minY, y); maxY = max(maxY, y) } }
        if (!minY.isFinite()) return Report(0, "Posições inválidas")
        checkpoint(); val span = (maxY - minY).coerceAtLeast(1e-8f)
        for (v in 0 until vertexCount) { val o = v * 3; val u = atan2(positions[o + 2], positions[o]).let { (it / (2f * Math.PI.toFloat()) + 0.5f).coerceIn(0f, 1f) }; uvs[v * 2] = u; uvs[v * 2 + 1] = ((positions[o + 1] - minY) / span).coerceIn(0f, 1f) }
        return Report(vertexCount, "UV cilíndrico aplicado; costura UV não duplicada")
    }

    /** Projeção esférica em torno do centro da caixa. */
    fun sphericalUv(): Report {
        if (vertexCount == 0) return Report(0, "Malha vazia")
        var minX = Float.POSITIVE_INFINITY; var maxX = Float.NEGATIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        for (v in 0 until vertexCount) { val o = v * 3; minX = min(minX, positions[o]); maxX = max(maxX, positions[o]); minY = min(minY, positions[o + 1]); maxY = max(maxY, positions[o + 1]); minZ = min(minZ, positions[o + 2]); maxZ = max(maxZ, positions[o + 2]) }
        val cx = (minX + maxX) * .5f; val cy = (minY + maxY) * .5f; val cz = (minZ + maxZ) * .5f
        checkpoint()
        for (v in 0 until vertexCount) { val o = v * 3; val x = positions[o] - cx; val y = positions[o + 1] - cy; val z = positions[o + 2] - cz; val len = sqrt(x*x + y*y + z*z).coerceAtLeast(1e-8f); uvs[v * 2] = atan2(z, x) / (2f * Math.PI.toFloat()) + .5f; uvs[v * 2 + 1] = kotlin.math.acos((y / len).coerceIn(-1f, 1f)) / Math.PI.toFloat() }
        return Report(vertexCount, "UV esférico aplicado; costura UV não duplicada")
    }

    /** Reescala o retângulo UV selecionado para 0..1; exige seleção para evitar alterar ilhas não pretendidas. */
    fun normalizeSelectedUv(): Report {
        if (selected.isEmpty()) return Report(0, "Selecione vértices antes de normalizar UV")
        var minU = Float.POSITIVE_INFINITY; var maxU = Float.NEGATIVE_INFINITY; var minV = Float.POSITIVE_INFINITY; var maxV = Float.NEGATIVE_INFINITY
        selected.forEach { val o = it * 2; minU = min(minU, uvs[o]); maxU = max(maxU, uvs[o]); minV = min(minV, uvs[o + 1]); maxV = max(maxV, uvs[o + 1]) }
        val du = (maxU - minU).coerceAtLeast(1e-8f); val dv = (maxV - minV).coerceAtLeast(1e-8f)
        checkpoint(); selected.forEach { val o = it * 2; uvs[o] = (uvs[o] - minU) / du; uvs[o + 1] = (uvs[o + 1] - minV) / dv }
        return Report(selected.size, "UV normalizado em ${selected.size} vértices selecionados")
    }

    /** Relaxamento UV Laplaciano; a borda da seleção fica fixa para não encolher a ilha sem controle. */
    fun relaxSelectedUv(iterations: Int = 1, strength: Float = 0.35f): Report {
        if (selected.size < 3) return Report(0, "Selecione ao menos três vértices UV")
        val graph = adjacency()
        val chosen = selected.toHashSet()
        val boundary = selected.filter { v -> graph[v].any { it !in chosen } || graph[v].size < 2 }.toHashSet()
        val amount = strength.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
        if (amount <= 0f) return Report(0, "Intensidade zero")
        checkpoint()
        repeat(iterations.coerceIn(1, 32)) {
            val src = uvs.copyOf()
            for (v in selected) {
                if (v in boundary) continue
                val neighbors = graph[v].filter { it in chosen }
                if (neighbors.isEmpty()) continue
                var u = 0f; var vv = 0f
                neighbors.forEach { u += src[it * 2]; vv += src[it * 2 + 1] }
                val o = v * 2; val inv = 1f / neighbors.size
                uvs[o] = src[o] + (u * inv - src[o]) * amount
                uvs[o + 1] = src[o + 1] + (vv * inv - src[o + 1]) * amount
            }
        }
        return Report((selected - boundary).size, "UV relaxado; ${boundary.size} vértices de borda preservados")
    }

    /** Projeção-Atlas automática por material. Não cria costuras nem divide vértices PMX: vértices compartilhados são preservados. */
    fun materialAtlas(columns: Int = 0, padding: Float = 0.035f): Report {
        if (materials.isEmpty() || source.indices.isEmpty()) return Report(0, "Modelo sem materiais ou triângulos")
        val cols = if (columns > 0) columns.coerceAtMost(materials.size) else kotlin.math.ceil(sqrt(materials.size.toFloat())).toInt().coerceAtLeast(1)
        val rows = kotlin.math.ceil(materials.size.toFloat() / cols).toInt().coerceAtLeast(1)
        val pad = padding.takeIf { it.isFinite() }?.coerceIn(0f, 0.2f) ?: 0.035f
        val owner = IntArray(vertexCount) { -1 }
        val perMaterial = Array(materials.size) { LinkedHashSet<Int>() }
        var offset = 0
        for (mi in materials.indices) {
            val end = (offset + materials[mi].indexCount.coerceAtLeast(0)).coerceAtMost(source.indices.size)
            for (ii in offset until end) source.indices[ii].takeIf { it in 0 until vertexCount }?.let { perMaterial[mi].add(it) }
            offset = end
        }
        val shared = BooleanArray(vertexCount)
        perMaterial.forEachIndexed { mi, ids -> ids.forEach { v -> if (owner[v] == -1) owner[v] = mi else if (owner[v] != mi) shared[v] = true } }
        checkpoint()
        var changed = 0
        for (mi in materials.indices) {
            val ids = perMaterial[mi].filter { v ->
                val o = v * 3
                !shared[v] && o + 2 < positions.size && positions[o].isFinite() && positions[o + 1].isFinite() && positions[o + 2].isFinite()
            }
            if (ids.isEmpty()) continue
            var minX = Float.POSITIVE_INFINITY; var maxX = Float.NEGATIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
            ids.forEach { v -> val o=v*3; minX=min(minX,positions[o]); maxX=max(maxX,positions[o]); minY=min(minY,positions[o+1]); maxY=max(maxY,positions[o+1]); minZ=min(minZ,positions[o+2]); maxZ=max(maxZ,positions[o+2]) }
            val spans = floatArrayOf(maxX-minX, maxY-minY, maxZ-minZ)
            val planes = listOf(0 to 1, 0 to 2, 1 to 2)
            val pair = planes.maxBy { (a,b) -> spans[a] * spans[b] }
            val ax = pair.first; val bx = pair.second
            val amin = floatArrayOf(minX,minY,minZ)[ax]; val bmin = floatArrayOf(minX,minY,minZ)[bx]
            val aspan = (spans[ax]).coerceAtLeast(1e-8f); val bspan = (spans[bx]).coerceAtLeast(1e-8f)
            val col = mi % cols; val row = mi / cols
            val cellW = 1f / cols; val cellH = 1f / rows
            val innerW = (cellW * (1f - 2f*pad)).coerceAtLeast(1e-5f); val innerH = (cellH * (1f - 2f*pad)).coerceAtLeast(1e-5f)
            ids.forEach { v ->
                val valueA = positions[v*3+ax]; val valueB = positions[v*3+bx]
                val localU = ((valueA-amin)/aspan).coerceIn(0f,1f); val localV=((valueB-bmin)/bspan).coerceIn(0f,1f)
                uvs[v*2] = col*cellW + cellW*pad + localU*innerW
                uvs[v*2+1] = row*cellH + cellH*pad + localV*innerH
                changed++
            }
        }
        val sharedCount = shared.count { it }
        return Report(changed, "Atlas projetado por material: $changed vértices · $sharedCount vértices compartilhados preservados; costuras PMX não foram divididas")
    }

    /** Recalcula normais ponderadas pela área, ignorando faces degeneradas e preservando fallback finito. */
    fun recalculateNormals(): Report {
        val out = FloatArray(vertexCount * 3)
        var validFaces = 0
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
            val ao = a * 3; val bo = b * 3; val co = c * 3
            val abx = positions[bo] - positions[ao]; val aby = positions[bo + 1] - positions[ao + 1]; val abz = positions[bo + 2] - positions[ao + 2]
            val acx = positions[co] - positions[ao]; val acy = positions[co + 1] - positions[ao + 1]; val acz = positions[co + 2] - positions[ao + 2]
            val nx = aby * acz - abz * acy; val ny = abz * acx - abx * acz; val nz = abx * acy - aby * acx
            if (!nx.isFinite() || !ny.isFinite() || !nz.isFinite() || nx * nx + ny * ny + nz * nz < 1e-16f) continue
            for (v in intArrayOf(a, b, c)) { val o = v * 3; out[o] += nx; out[o + 1] += ny; out[o + 2] += nz }
            validFaces++
        }
        if (validFaces == 0) return Report(0, "Nenhuma face válida para calcular normais")
        checkpoint()
        var changed = 0
        for (v in 0 until vertexCount) {
            val o = v * 3; val len = sqrt(out[o] * out[o] + out[o + 1] * out[o + 1] + out[o + 2] * out[o + 2])
            if (len > 1e-10f && len.isFinite()) {
                val nx = out[o] / len; val ny = out[o + 1] / len; val nz = out[o + 2] / len
                if (abs(normals[o] - nx) + abs(normals[o + 1] - ny) + abs(normals[o + 2] - nz) > 1e-5f) changed++
                normals[o] = nx; normals[o + 1] = ny; normals[o + 2] = nz
            } else {
                val oldLen = sqrt(normals[o] * normals[o] + normals[o + 1] * normals[o + 1] + normals[o + 2] * normals[o + 2])
                if (!oldLen.isFinite() || oldLen < 1e-10f) { normals[o] = 0f; normals[o + 1] = 1f; normals[o + 2] = 0f }
                else { normals[o] /= oldLen; normals[o + 1] /= oldLen; normals[o + 2] /= oldLen }
            }
        }
        return Report(changed, "Normais recalculadas em $changed vértices")
    }

    /** Projeção planar normalizada em 0..1. axis=0 usa XZ, 1 usa XY, 2 usa ZY. */
    fun planarUv(axis: Int = 0): Report {
        require(axis in 0..2)
        if (vertexCount == 0) return Report(0, "Malha vazia")
        var minA = Float.POSITIVE_INFINITY; var maxA = Float.NEGATIVE_INFINITY
        var minB = Float.POSITIVE_INFINITY; var maxB = Float.NEGATIVE_INFINITY
        fun pair(v: Int): Pair<Float, Float> {
            val o = v * 3
            return when (axis) { 0 -> positions[o] to positions[o + 2]; 1 -> positions[o] to positions[o + 1]; else -> positions[o + 2] to positions[o + 1] }
        }
        for (v in 0 until vertexCount) {
            val (a, b) = pair(v)
            if (!a.isFinite() || !b.isFinite()) continue
            minA = min(minA, a); maxA = max(maxA, a); minB = min(minB, b); maxB = max(maxB, b)
        }
        if (!minA.isFinite() || !minB.isFinite()) return Report(0, "Coordenadas inválidas")
        val spanA = max(maxA - minA, 1e-8f); val spanB = max(maxB - minB, 1e-8f)
        checkpoint()
        for (v in 0 until vertexCount) {
            val (a, b) = pair(v); val o = v * 2
            if (!a.isFinite() || !b.isFinite()) { uvs[o] = 0f; uvs[o + 1] = 0f }
            else { uvs[o] = ((a - minA) / spanA).coerceIn(0f, 1f); uvs[o + 1] = ((b - minB) / spanB).coerceIn(0f, 1f) }
        }
        return Report(vertexCount, "Projeção UV planar aplicada em $vertexCount vértices")
    }

    fun flipUv(horizontal: Boolean): Report {
        if (uvs.isEmpty()) return Report(0, "Modelo sem coordenadas UV")
        checkpoint()
        for (v in 0 until vertexCount) { val o = v * 2; if (horizontal) uvs[o] = 1f - uvs[o] else uvs[o + 1] = 1f - uvs[o + 1] }
        return Report(vertexCount, if (horizontal) "UV espelhado no eixo U" else "UV espelhado no eixo V")
    }

    /** Escala e desloca UV sem limitar o resultado, permitindo tiling maior que 0..1. */
    fun transformUv(scaleU: Float, scaleV: Float, offsetU: Float, offsetV: Float): Report {
        require(listOf(scaleU, scaleV, offsetU, offsetV).all { it.isFinite() }) { "Transformação UV inválida" }
        checkpoint()
        for (v in 0 until vertexCount) { val o = v * 2; uvs[o] = (if (uvs[o].isFinite()) uvs[o] else 0f) * scaleU + offsetU; uvs[o + 1] = (if (uvs[o + 1].isFinite()) uvs[o + 1] else 0f) * scaleV + offsetV }
        return Report(vertexCount, "Transformação UV aplicada em $vertexCount vértices")
    }

    /** Transformação geométrica ao redor do centro da caixa; morphs de vértice recebem a mesma rotação/escala vetorial. */
    fun transformGeometry(scaleX: Float, scaleY: Float, scaleZ: Float, rotateX: Float, rotateY: Float, rotateZ: Float): Report {
        val values = listOf(scaleX, scaleY, scaleZ, rotateX, rotateY, rotateZ)
        require(values.all { it.isFinite() } && abs(scaleX) > 1e-6f && abs(scaleY) > 1e-6f && abs(scaleZ) > 1e-6f) { "Transformação geométrica inválida" }
        if (vertexCount == 0) return Report(0, "Malha vazia")
        require(positions.all { it.isFinite() }) { "A malha contém posições não finitas; execute o diagnóstico antes de transformar" }
        var minX = Float.POSITIVE_INFINITY; var maxX = Float.NEGATIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        for (v in 0 until vertexCount) { val o = v * 3; minX = min(minX, positions[o]); maxX = max(maxX, positions[o]); minY = min(minY, positions[o + 1]); maxY = max(maxY, positions[o + 1]); minZ = min(minZ, positions[o + 2]); maxZ = max(maxZ, positions[o + 2]) }
        val cx = (minX + maxX) * .5f; val cy = (minY + maxY) * .5f; val cz = (minZ + maxZ) * .5f
        val rx = Math.toRadians(rotateX.toDouble()); val ry = Math.toRadians(rotateY.toDouble()); val rz = Math.toRadians(rotateZ.toDouble())
        val sx = kotlin.math.sin(rx).toFloat(); val cxr = kotlin.math.cos(rx).toFloat()
        val sy = kotlin.math.sin(ry).toFloat(); val cyr = kotlin.math.cos(ry).toFloat()
        val sz = kotlin.math.sin(rz).toFloat(); val czr = kotlin.math.cos(rz).toFloat()
        fun rotateVector(x0: Float, y0: Float, z0: Float): FloatArray {
            var x = x0; var y = y0; var z = z0
            val y1 = y * cxr - z * sx; val z1 = y * sx + z * cxr; y = y1; z = z1
            val x2 = x * cyr + z * sy; val z2 = -x * sy + z * cyr; x = x2; z = z2
            val x3 = x * czr - y * sz; val y3 = x * sz + y * czr
            return floatArrayOf(x3, y3, z)
        }
        fun vector(x0: Float, y0: Float, z0: Float): FloatArray = rotateVector(x0 * scaleX, y0 * scaleY, z0 * scaleZ)
        fun normalVector(x0: Float, y0: Float, z0: Float): FloatArray {
            val n = rotateVector(x0 / scaleX, y0 / scaleY, z0 / scaleZ)
            val len = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).coerceAtLeast(1e-9f)
            return floatArrayOf(n[0] / len, n[1] / len, n[2] / len)
        }
        fun point(x0: Float, y0: Float, z0: Float): FloatArray {
            val p = vector(x0 - cx, y0 - cy, z0 - cz)
            return floatArrayOf(p[0] + cx, p[1] + cy, p[2] + cz)
        }
        fun axisOrNull(a: FloatArray?): FloatArray? {
            if (a == null || a.size < 3) return a?.copyOf()
            val n = normalVector(a[0], a[1], a[2])
            return n + a.copyOfRange(3, a.size)
        }
        checkpoint()
        for (v in 0 until vertexCount) {
            val o = v * 3; val p = point(positions[o], positions[o + 1], positions[o + 2])
            positions[o] = p[0]; positions[o + 1] = p[1]; positions[o + 2] = p[2]
            val nx = normals[o].takeIf { it.isFinite() } ?: 0f
            val ny = normals[o + 1].takeIf { it.isFinite() } ?: 1f
            val nz = normals[o + 2].takeIf { it.isFinite() } ?: 0f
            val n = normalVector(nx, ny, nz)
            normals[o] = n[0]; normals[o + 1] = n[1]; normals[o + 2] = n[2]
        }
        bones = bones.map { b ->
            val p = point(b.x, b.y, b.z)
            PmxBone(b.name, b.nameEn, p[0], p[1], p[2], b.parent, b.layer, b.flags, b.tailBone, b.inheritParent, b.inheritWeight, b.ik,
                b.tailOffset?.let { vector(it.getOrElse(0) { 0f }, it.getOrElse(1) { 0f }, it.getOrElse(2) { 0f }) },
                axisOrNull(b.fixedAxis), axisOrNull(b.localAxisX), axisOrNull(b.localAxisZ), b.externalKey)
        }
        morphs = morphs.map { m ->
            if (m.type == 1 && m.vertexDelta != null && m.vertexDelta.size >= (m.vertexIdx?.size ?: 0) * 3) {
                val delta = m.vertexDelta.copyOf()
                for (k in 0 until (m.vertexIdx?.size ?: 0)) { val o = k * 3; val t = vector(delta[o], delta[o + 1], delta[o + 2]); delta[o] = t[0]; delta[o + 1] = t[1]; delta[o + 2] = t[2] }
                PmxMorph(m.name, m.nameEn, m.panel, m.type, m.vertexIdx?.copyOf(), delta, m.boneIdx?.copyOf(), m.boneTrans?.copyOf(), m.boneRot?.copyOf(), m.groupIdx?.copyOf(), m.groupRate?.copyOf(), m.raw?.copyOf(), m.count)
            } else m
        }
        rigidBodies = rigidBodies.map { r ->
            val p = point(r.pos.getOrElse(0) { 0f }, r.pos.getOrElse(1) { 0f }, r.pos.getOrElse(2) { 0f })
            PmxRigid(r.name, r.nameEn, r.bone, r.group, r.shape, r.mass, r.linearDamping, r.angularDamping, r.mode, r.mask,
                floatArrayOf(r.size.getOrElse(0) { 0f } * abs(scaleX), r.size.getOrElse(1) { 0f } * abs(scaleY), r.size.getOrElse(2) { 0f } * abs(scaleZ)), p,
                addGlobalEulerRotation(r.rot, rotateX, rotateY, rotateZ), r.restitution, r.friction)
        }
        joints = joints.map { j ->
            val p = point(j.pos.getOrElse(0) { 0f }, j.pos.getOrElse(1) { 0f }, j.pos.getOrElse(2) { 0f })
            PmxJoint(j.name, j.a, j.b, p, addGlobalEulerRotation(j.rot, rotateX, rotateY, rotateZ),
                j.posMin.copyOf(), j.posMax.copyOf(), j.rotMin.copyOf(), j.rotMax.copyOf(), j.springPos.copyOf(), j.springRot.copyOf(), j.type, j.nameEn)
        }
        return Report(vertexCount, "Transformação aplicada à malha, ossos, morphs e corpos rígidos ($vertexCount vértices)")
    }

    fun updateMaterial(index: Int, material: PmxMaterial): Report {
        require(index in materials.indices) { "Material inválido" }
        require(material.diffuse.size >= 4 && material.specular.size >= 3 && material.ambient.size >= 3) { "Canais de material incompletos" }
        checkpoint()
        materials = materials.toMutableList().also { it[index] = material }
        return Report(1, "Material '${material.name}' atualizado")
    }

    /** Reatribui textura base/esfera sem descartar os demais parâmetros PMX do material. */
    fun setMaterialTextures(index: Int, textureIndex: Int, sphereIndex: Int, sphereMode: Int): Report {
        val old = materials.getOrNull(index) ?: return Report(0, "Material inválido")
        require(textureIndex == -1 || textureIndex in source.textures.indices) { "Índice de textura base inválido" }
        require(sphereIndex == -1 || sphereIndex in source.textures.indices) { "Índice de textura esfera inválido" }
        require(sphereMode in 0..3) { "Modo de esfera PMX inválido" }
        checkpoint()
        val updated = PmxMaterial(old.name, old.nameEn, old.diffuse.copyOf(), old.specular.copyOf(), old.specularPower, old.ambient.copyOf(), old.flags,
            old.edgeColor.copyOf(), old.edgeSize, textureIndex, sphereIndex, sphereMode, old.toonShared, old.toonIndex, old.indexCount, old.memo)
        materials = materials.toMutableList().also { it[index] = updated }
        return Report(1, "Texturas do material '${old.name}' atualizadas")
    }

    fun positionsCopy(): FloatArray = positions.copyOf()

    fun buildModel(): PmxModel = PmxModel(
        source.name, source.version, positions.copyOf(), normals.copyOf(), uvs.copyOf(),
        source.boneIndices.copyOf(), source.boneWeights.copyOf(), source.indices.copyOf(), source.textures.toList(), materials.toList(), bones.toList(), morphs.toList(),
        rigidBodies.toList(), joints.toList(), source.nameEn, source.comment, source.commentEn, source.displayFrames.toList(),
        source.addUvCount, source.addUvs.copyOf(), source.weightTypes.copyOf(), source.sdef?.copyOf(), source.edgeScale.copyOf(), source.textEncoding,
        source.indexSizes.copyOf(), source.softBodyCount, source.softBodyRaw?.copyOf(), source.warnings.toList()
    )

    fun material(index: Int): PmxMaterial? = materials.getOrNull(index)
    fun materials(): List<PmxMaterial> = materials.toList()
}

fun copyPmxMaterial(
    source: PmxMaterial,
    diffuse: FloatArray = source.diffuse.copyOf(),
    specular: FloatArray = source.specular.copyOf(),
    specularPower: Float = source.specularPower,
    ambient: FloatArray = source.ambient.copyOf(),
    flags: Int = source.flags,
    edgeColor: FloatArray = source.edgeColor.copyOf(),
    edgeSize: Float = source.edgeSize
): PmxMaterial = PmxMaterial(source.name, source.nameEn, diffuse, specular, specularPower, ambient, flags, edgeColor, edgeSize,
    source.textureIndex, source.sphereIndex, source.sphereMode, source.toonShared, source.toonIndex, source.indexCount, source.memo)

/** Diagnóstico rápido antes de exportar PMX. Não altera o modelo. */
data class ModelDiagnosticReport(
    val vertices: Int, val triangles: Int, val materials: Int,
    val invalidIndices: Int, val degenerateTriangles: Int, val invalidNormals: Int,
    val uvOutsideUnit: Int, val invalidWeights: Int, val nonFinitePositions: Int, val materialIndexMismatch: Boolean,
    val issues: List<String>
) { val hasErrors get() = invalidIndices > 0 || degenerateTriangles > 0 || invalidNormals > 0 || invalidWeights > 0 || nonFinitePositions > 0 || materialIndexMismatch }

object ModelDiagnostics {
    fun inspect(model: PmxModel): ModelDiagnosticReport {
        val vc = model.vertexCount; var badIndex = 0; var degenerate = 0; var badNormals = 0; var uvOut = 0; var badWeights = 0; var badPositions = 0
        for (ix in model.indices) if (ix !in 0 until vc) badIndex++
        for (v in 0 until vc) {
            val n = v * 3; val u = v * 2; val w = v * 4
            if (n + 2 >= model.positions.size || (0..2).any { !model.positions.getOrElse(n + it) { Float.NaN }.isFinite() }) badPositions++
            if (n + 2 >= model.normals.size || !model.normals[n].isFinite() || !model.normals[n + 1].isFinite() || !model.normals[n + 2].isFinite() || abs(model.normals.getOrElse(n) { 0f } * model.normals.getOrElse(n) { 0f } + model.normals.getOrElse(n + 1) { 0f } * model.normals.getOrElse(n + 1) { 0f } + model.normals.getOrElse(n + 2) { 0f } * model.normals.getOrElse(n + 2) { 0f } - 1f) > .08f) badNormals++
            if (u + 1 >= model.uvs.size || !model.uvs.getOrElse(u) { 0f }.isFinite() || !model.uvs.getOrElse(u + 1) { 0f }.isFinite() || model.uvs.getOrElse(u) { 0f } !in 0f..1f || model.uvs.getOrElse(u + 1) { 0f } !in 0f..1f) uvOut++
            val sum = (0..3).sumOf { k -> model.boneWeights.getOrElse(w + k) { 0f }.toDouble() }.toFloat()
            val hasBoneData = model.boneIndices.size >= vc * 4 && model.boneWeights.size >= vc * 4
            if (hasBoneData && (!sum.isFinite() || abs(sum - 1f) > .03f || (0..3).any { k -> val bi = model.boneIndices[w + k]; val bw = model.boneWeights[w + k]; !bw.isFinite() || bw < 0f || (bw > 1e-5f && bi !in model.bones.indices) })) badWeights++
        }
        for (i in model.indices.indices step 3) {
            if (i + 2 >= model.indices.size) break
            val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
            if (a in 0 until vc && b in 0 until vc && c in 0 until vc) {
                if (a == b || b == c || c == a) degenerate++ else {
                    val ao = a * 3; val bo = b * 3; val co = c * 3
                    val abx = model.positions[bo] - model.positions[ao]; val aby = model.positions[bo + 1] - model.positions[ao + 1]; val abz = model.positions[bo + 2] - model.positions[ao + 2]
                    val acx = model.positions[co] - model.positions[ao]; val acy = model.positions[co + 1] - model.positions[ao + 1]; val acz = model.positions[co + 2] - model.positions[ao + 2]
                    val nx = aby * acz - abz * acy; val ny = abz * acx - abx * acz; val nz = abx * acy - aby * acx
                    if (nx * nx + ny * ny + nz * nz < 1e-14f) degenerate++
                }
            }
        }
        val materialSum = model.materials.sumOf { it.indexCount.toLong() }
        val mismatch = materialSum != model.indices.size.toLong() || model.materials.any { it.indexCount < 0 || it.indexCount % 3 != 0 }
        val issues = buildList {
            if (badIndex > 0) add("$badIndex índices fora do intervalo da malha")
            if (degenerate > 0) add("$degenerate triângulos degenerados")
            if (badNormals > 0) add("$badNormals normais inválidas ou não normalizadas")
            if (uvOut > 0) add("$uvOut vértices com UV fora de 0..1 (pode ser intencional para tiling)")
            if (badWeights > 0) add("$badWeights vértices com pesos/ossos inconsistentes")
            if (badPositions > 0) add("$badPositions vértices com posições não finitas")
            if (mismatch) add("A soma dos índices por material não corresponde à malha")
            if (isEmpty()) add("Nenhum problema estrutural detectado")
        }
        return ModelDiagnosticReport(vc, model.indices.size / 3, model.materials.size, badIndex, degenerate, badNormals, uvOut, badWeights, badPositions, mismatch, issues)
    }
}
