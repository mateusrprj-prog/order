package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Modos básicos de pincel para pesos de skinning PMX. */
enum class WeightPaintMode { REPLACE, ADD, SUBTRACT }

data class WeightPaintReport(val vertices: Int, val changed: Int, val normalized: Int = 0, val removedInfluences: Int = 0)

/**
 * Editor de pesos PMX independente da viewport. Suporta BDEF1/BDEF2/BDEF4; ao alterar um vértice
 * SDEF/QDEF, converte-o para BDEF2/BDEF4 para não preservar parâmetros incompatíveis.
 * As operações são aplicadas em cópias; [buildModel] gera um PmxModel novo sem mutar a origem.
 */
class WeightPaintSession(val source: PmxModel, private val historyLimit: Int = 32) {
    private var indices = source.boneIndices.copyOf()
    private var weights = source.boneWeights.copyOf()
    private var types = if (source.weightTypes.size == source.vertexCount) source.weightTypes.copyOf() else ByteArray(source.vertexCount)
    private val undo = ArrayList<Snapshot>()
    private val redo = ArrayList<Snapshot>()
    private var suppressCheckpoint = false

    private data class Snapshot(val indices: IntArray, val weights: FloatArray, val types: ByteArray)

    val vertexCount: Int get() = source.vertexCount
    val boneCount: Int get() = source.bones.size
    val canUndo: Boolean get() = undo.isNotEmpty()
    val canRedo: Boolean get() = redo.isNotEmpty()

    private fun snapshot() = Snapshot(indices.copyOf(), weights.copyOf(), types.copyOf())
    private fun checkpoint() {
        if (suppressCheckpoint) return
        undo.add(snapshot())
        if (undo.size > historyLimit.coerceAtLeast(1)) undo.removeAt(0)
        redo.clear()
    }

    fun undo(): Boolean {
        if (undo.isEmpty()) return false
        redo.add(snapshot())
        val s = undo.removeAt(undo.lastIndex)
        indices = s.indices; weights = s.weights; types = s.types
        return true
    }

    fun redo(): Boolean {
        if (redo.isEmpty()) return false
        undo.add(snapshot())
        val s = redo.removeAt(redo.lastIndex)
        indices = s.indices; weights = s.weights; types = s.types
        return true
    }

    /** Transfere os pesos de outro PMX por proximidade e nomes de ossos, como uma única operação Undo. */
    fun transferFrom(sourceModel: PmxModel, options: WeightTransferOptions = WeightTransferOptions()): WeightTransferReport {
        val transferred = WeightTransfer.transfer(sourceModel, buildModel(), options)
        checkpoint()
        indices = transferred.model.boneIndices.copyOf()
        weights = transferred.model.boneWeights.copyOf()
        types = transferred.model.weightTypes.copyOf()
        return transferred.copy(model = buildModel())
    }

    /** Pinta vértices explícitos com peso-alvo e intensidade; [falloff] opcional deve ter 1 valor por vértice. */
    fun paintVertices(
        vertices: IntArray, targetBone: Int, targetWeight: Float,
        strength: Float = 1f, mode: WeightPaintMode = WeightPaintMode.REPLACE,
        falloff: FloatArray? = null
    ): WeightPaintReport {
        require(targetBone in 0 until boneCount) { "Osso alvo inválido" }
        val target = targetWeight.coerceIn(0f, 1f)
        val power = strength.coerceIn(0f, 1f)
        val valid = vertices.distinct().filter { it in 0 until vertexCount && (falloff == null || falloff.size == vertexCount) }
        if (valid.isEmpty() || power <= 0f) return WeightPaintReport(vertices.size, 0)
        checkpoint()
        var changed = 0
        for (v in valid) {
            val local = power * (falloff?.get(v)?.coerceIn(0f, 1f) ?: 1f)
            if (local <= 0f) continue
            val map = influences(v)
            val old = map[targetBone] ?: 0f
            when (mode) {
                WeightPaintMode.REPLACE -> {
                    val next = old + (target - old) * local
                    map[targetBone] = next
                    val rest = map.filterKeys { it != targetBone }.values.sum()
                    if (rest > 1e-8f) map.keys.filter { it != targetBone }.forEach { b -> map[b] = (map[b] ?: 0f) * (1f - next) / rest }
                }
                WeightPaintMode.ADD -> map[targetBone] = old + target * local
                WeightPaintMode.SUBTRACT -> map[targetBone] = max(0f, old - target * local)
            }
            setInfluences(v, map)
            changed++
        }
        return WeightPaintReport(valid.size, changed)
    }

    /**
     * Aplica um stroke contínuo como uma única operação Undo. Cada amostra é um ponto XYZ em espaço
     * local PMX; segmentos entre amostras evitam falhas quando o dedo se move rapidamente.
     */
    fun paintStroke(
        points: List<FloatArray>, radius: Float, targetBone: Int, targetWeight: Float,
        strength: Float = 1f, mode: WeightPaintMode = WeightPaintMode.REPLACE
    ): WeightPaintReport {
        require(radius.isFinite() && radius > 0f) { "Raio do pincel deve ser positivo" }
        require(targetBone in 0 until boneCount) { "Osso alvo inválido" }
        val valid = points.filter { it.size >= 3 && it.take(3).all(Float::isFinite) }
        if (valid.isEmpty() || strength <= 0f) return WeightPaintReport(0, 0)
        checkpoint()
        suppressCheckpoint = true
        var changed = 0
        var affected = 0
        try {
            var previous: FloatArray? = null
            for (point in valid) {
                val p = previous
                val report = if (p == null) paintSphere(point[0], point[1], point[2], radius, targetBone, targetWeight, strength, mode)
                    else paintCapsule(p[0], p[1], p[2], point[0], point[1], point[2], radius, targetBone, targetWeight, strength, mode)
                changed += report.changed
                affected += report.vertices
                previous = point
            }
        } finally { suppressCheckpoint = false }
        return WeightPaintReport(affected, changed)
    }

    /** Pincel esférico no espaço local do modelo, com falloff suave centro→borda. */
    fun paintSphere(
        centerX: Float, centerY: Float, centerZ: Float, radius: Float,
        targetBone: Int, targetWeight: Float, strength: Float = 1f,
        mode: WeightPaintMode = WeightPaintMode.REPLACE
    ): WeightPaintReport = paintCapsule(
        centerX, centerY, centerZ, centerX, centerY, centerZ, radius,
        targetBone, targetWeight, strength, mode
    )

    /** Pinta ao longo de um segmento 3D (stroke), usando distância ao eixo e falloff suave. */
    fun paintCapsule(
        ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, radius: Float,
        targetBone: Int, targetWeight: Float, strength: Float = 1f,
        mode: WeightPaintMode = WeightPaintMode.REPLACE
    ): WeightPaintReport {
        require(radius.isFinite() && radius > 0f) { "Raio do pincel deve ser positivo" }
        require(listOf(ax, ay, az, bx, by, bz).all { it.isFinite() }) { "Traço do pincel contém coordenadas inválidas" }
        val falloff = FloatArray(vertexCount)
        val vertices = IntArray(vertexCount)
        var n = 0
        val abx = bx - ax; val aby = by - ay; val abz = bz - az
        val den = abx * abx + aby * aby + abz * abz
        val r2 = radius * radius
        for (v in 0 until vertexCount) {
            val o = v * 3
            val apx = source.positions[o] - ax; val apy = source.positions[o + 1] - ay; val apz = source.positions[o + 2] - az
            val t = if (den < 1e-12f) 0f else ((apx * abx + apy * aby + apz * abz) / den).coerceIn(0f, 1f)
            val dx = source.positions[o] - (ax + abx * t)
            val dy = source.positions[o + 1] - (ay + aby * t)
            val dz = source.positions[o + 2] - (az + abz * t)
            val d2 = dx * dx + dy * dy + dz * dz
            if (d2 <= r2) {
                val tFall = (1f - sqrt(d2 / r2)).coerceIn(0f, 1f)
                falloff[v] = tFall * tFall * (3f - 2f * tFall)
                vertices[n++] = v
            }
        }
        return paintVertices(vertices.copyOf(n), targetBone, targetWeight, strength, mode, falloff)
    }

    /** Consulta o peso de um osso num vértice, sem expor os arrays internos. */
    fun influenceAt(vertex: Int, bone: Int): Float {
        require(vertex in 0 until vertexCount && bone in 0 until boneCount)
        return influences(vertex)[bone] ?: 0f
    }

    fun verticesInfluencedBy(bone: Int, minimumWeight: Float = 0.01f): IntArray {
        require(bone in 0 until boneCount)
        val minWeight = minimumWeight.coerceIn(0f, 1f)
        return (0 until vertexCount).filter { influenceAt(it, bone) >= minWeight }.toIntArray()
    }

    /** Normaliza todos os vértices e elimina índices inválidos/duplicados. */
    fun normalizeAll(): WeightPaintReport {
        if (vertexCount == 0) return WeightPaintReport(0, 0)
        checkpoint(); var changed = 0
        for (v in 0 until vertexCount) {
            val beforeI = IntArray(4) { indices.getOrElse(v * 4 + it) { -1 } }
            val beforeW = FloatArray(4) { weights.getOrElse(v * 4 + it) { 0f } }
            val map = influences(v); setInfluences(v, map)
            if (!beforeI.contentEquals(IntArray(4) { indices[v * 4 + it] }) || !beforeW.contentEquals(FloatArray(4) { weights[v * 4 + it] })) changed++
        }
        return WeightPaintReport(vertexCount, changed, changed)
    }

    /** Remove pesos abaixo do limite e mantém no máximo [maxInfluences] influências por vértice. */
    fun prune(minWeight: Float = 0.01f, maxInfluences: Int = 4): WeightPaintReport {
        val threshold = minWeight.coerceIn(0f, 0.99f); val maxInf = maxInfluences.coerceIn(1, 4)
        if (vertexCount == 0) return WeightPaintReport(0, 0)
        checkpoint(); var changed = 0; var removed = 0
        for (v in 0 until vertexCount) {
            val oldCount = influences(v).size
            val map = influences(v).filterValues { it >= threshold }.entries.sortedByDescending { it.value }.take(maxInf).associate { it.key to it.value }
            removed += (oldCount - map.size).coerceAtLeast(0)
            val before = FloatArray(4) { weights[v * 4 + it] }
            setInfluences(v, map)
            if (!before.contentEquals(FloatArray(4) { weights[v * 4 + it] })) changed++
        }
        return WeightPaintReport(vertexCount, changed, changed, removed)
    }

    /** Suaviza pesos pela vizinhança topológica da malha, preservando vértices de borda como dados normais. */
    fun smooth(iterations: Int = 1, strength: Float = 0.5f): WeightPaintReport {
        if (vertexCount == 0 || source.indices.size < 3) return WeightPaintReport(vertexCount, 0)
        val adjacency = Array(vertexCount) { LinkedHashSet<Int>() }
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
            adjacency[a].add(b); adjacency[a].add(c); adjacency[b].add(a); adjacency[b].add(c); adjacency[c].add(a); adjacency[c].add(b)
        }
        val amount = strength.coerceIn(0f, 1f); val passes = iterations.coerceIn(1, 12)
        if (amount <= 0f) return WeightPaintReport(vertexCount, 0)
        val beforeIndices = indices.copyOf(); val beforeWeights = weights.copyOf()
        checkpoint()
        repeat(passes) {
            val current = Array(vertexCount) { influences(it) }
            val next = Array(vertexCount) { current[it].toMutableMap() }
            for (v in 0 until vertexCount) {
                val around = adjacency[v]
                if (around.isEmpty()) continue
                val average = HashMap<Int, Float>()
                for (nb in around) for ((bone, w) in current[nb]) average[bone] = (average[bone] ?: 0f) + w / around.size
                val blend = HashMap<Int, Float>()
                for (b in current[v].keys + average.keys) {
                    val old = current[v][b] ?: 0f; val avg = average[b] ?: 0f
                    val w = old + (avg - old) * amount
                    if (w > 1e-5f) blend[b] = w
                }
                next[v] = blend
            }
            for (v in 0 until vertexCount) setInfluences(v, next[v])
        }
        var changed = 0
        for (v in 0 until vertexCount) {
            val o = v * 4
            var differs = false
            for (i in 0..3) if (beforeIndices[o + i] != indices[o + i] || kotlin.math.abs(beforeWeights[o + i] - weights[o + i]) > 1e-6f) differs = true
            if (differs) changed++
        }
        return WeightPaintReport(vertexCount, changed)
    }

    /** Espelha pesos pela posição X=-X procurando vértices dentro de [tolerance] no espaço local. */
    fun mirrorX(tolerance: Float = 0.002f, sourcePositiveX: Boolean = true): WeightPaintReport {
        val tol = tolerance.coerceIn(1e-5f, 10f)
        if (vertexCount == 0) return WeightPaintReport(0, 0)
        data class Cell(val x: Int, val y: Int, val z: Int)
        fun cell(x: Float, y: Float, z: Float) = Cell(floor(x / tol).toInt(), floor(y / tol).toInt(), floor(z / tol).toInt())
        val buckets = HashMap<Cell, MutableList<Int>>()
        for (v in 0 until vertexCount) {
            val o = v * 3; val c = cell(source.positions[o], source.positions[o + 1], source.positions[o + 2])
            buckets.getOrPut(c) { ArrayList() }.add(v)
        }
        val mirrorBone = IntArray(boneCount) { mirroredBone(it) }
        val pairs = ArrayList<Pair<Int, Int>>()
        val t2 = tol * tol
        for (v in 0 until vertexCount) {
            val o = v * 3
            val sourceOnPositive = source.positions[o] >= 0f
            if (sourceOnPositive != sourcePositiveX || kotlin.math.abs(source.positions[o]) < tol * 0.5f) continue
            val tx = -source.positions[o]; val ty = source.positions[o + 1]; val tz = source.positions[o + 2]
            val c = cell(tx, ty, tz); var best = -1; var bestD = t2
            for (dx in -1..1) for (dy in -1..1) for (dz in -1..1) {
                for (candidate in buckets[Cell(c.x + dx, c.y + dy, c.z + dz)].orEmpty()) {
                    if (candidate == v) continue
                    val q = candidate * 3
                    val ax = source.positions[q] - tx; val ay = source.positions[q + 1] - ty; val az = source.positions[q + 2] - tz
                    val d = ax * ax + ay * ay + az * az
                    if (d <= bestD) { bestD = d; best = candidate }
                }
            }
            if (best >= 0) pairs.add(v to best)
        }
        if (pairs.isEmpty()) return WeightPaintReport(vertexCount, 0)
        checkpoint()
        for ((left, right) in pairs) {
            val mirrored = HashMap<Int, Float>()
            for ((bone, w) in influences(left)) { val mb = mirrorBone.getOrElse(bone) { bone }; mirrored[mb] = (mirrored[mb] ?: 0f) + w }
            setInfluences(right, mirrored)
        }
        return WeightPaintReport(vertexCount, pairs.size, pairs.size)
    }

    /** Copia os pesos editados para os arrays mutáveis do modelo original (usado para atualizar a viewport). */
    fun applyToSource(): Boolean {
        if (source.boneIndices.size != indices.size || source.boneWeights.size != weights.size) return false
        indices.copyInto(source.boneIndices)
        weights.copyInto(source.boneWeights)
        if (source.weightTypes.size == types.size) types.copyInto(source.weightTypes)
        return true
    }

    fun buildModel(): PmxModel = PmxModel(
        source.name, source.version, source.positions.copyOf(), source.normals.copyOf(), source.uvs.copyOf(),
        indices.copyOf(), weights.copyOf(), source.indices.copyOf(), source.textures, source.materials, source.bones, source.morphs,
        source.rigidBodies, source.joints, source.nameEn, source.comment, source.commentEn, source.displayFrames,
        source.addUvCount, source.addUvs.copyOf(), types.copyOf(), source.sdef?.copyOf(), source.edgeScale.copyOf(),
        source.textEncoding, source.indexSizes.copyOf(), source.softBodyCount, source.softBodyRaw?.copyOf(), source.warnings
    )

    private fun influences(vertex: Int): MutableMap<Int, Float> {
        val result = LinkedHashMap<Int, Float>()
        val o = vertex * 4
        for (i in 0..3) {
            val b = indices.getOrElse(o + i) { -1 }; val w = weights.getOrElse(o + i) { 0f }
            if (b in 0 until boneCount && w.isFinite() && w > 0f) result[b] = (result[b] ?: 0f) + w
        }
        return result
    }

    private fun setInfluences(vertex: Int, sourceMap: Map<Int, Float>) {
        val sorted = sourceMap.entries.filter { it.key in 0 until boneCount && it.value.isFinite() && it.value > 1e-6f }
            .sortedByDescending { it.value }.take(4)
        val out = IntArray(4) { -1 }; val w = FloatArray(4)
        val sum = sorted.sumOf { it.value.toDouble() }.toFloat()
        if (sorted.isNotEmpty() && sum > 1e-8f) sorted.forEachIndexed { i, e -> out[i] = e.key; w[i] = e.value / sum }
        else if (boneCount > 0) { out[0] = 0; w[0] = 1f }
        val o = vertex * 4
        for (i in 0..3) { if (o + i < indices.size) indices[o + i] = out[i]; if (o + i < weights.size) weights[o + i] = w[i] }
        if (vertex < types.size) types[vertex] = when (sorted.size) { 0, 1 -> 0; 2 -> 1; else -> 2 }.toByte()
    }

    private fun mirroredBone(index: Int): Int {
        val bone = source.bones.getOrNull(index) ?: return index
        val variants = listOf(
            "左" to "右", "右" to "左", "Left" to "Right", "Right" to "Left", "left" to "right", "right" to "left",
            "_L" to "_R", "_R" to "_L", ".L" to ".R", ".R" to ".L", " L" to " R", " R" to " L"
        )
        for ((a, b) in variants) {
            val candidates = buildList {
                if (bone.name.contains(a)) add(bone.name.replace(a, b))
                if (bone.nameEn.contains(a)) add(bone.nameEn.replace(a, b))
            }
            for (candidate in candidates) {
                val found = source.bones.indexOfFirst { it.name == candidate || it.nameEn == candidate }
                if (found >= 0) return found
            }
        }
        return index
    }
}
