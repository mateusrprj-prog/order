package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.max
import kotlin.math.roundToLong

/** Diagnóstico topológico independente do renderer; não modifica o PMX. */
data class MeshTopologyReport(
    val validTriangles: Int,
    val boundaryEdges: Int,
    val nonManifoldEdges: Int,
    val inconsistentWindingEdges: Int,
    val connectedComponents: Int,
    val isolatedVertices: Int,
    val duplicatePositionGroups: Int,
    val duplicateVertices: Int,
    val zeroAreaUvTriangles: Int,
    val invalidTriangleRecords: Int
) {
    val hasTopologyWarnings: Boolean get() = boundaryEdges > 0 || nonManifoldEdges > 0 || inconsistentWindingEdges > 0 || isolatedVertices > 0 || duplicatePositionGroups > 0 || zeroAreaUvTriangles > 0 || invalidTriangleRecords > 0
}

object MeshTopologyAnalyzer {
    private data class EdgeUse(var count: Int = 0, var directionSum: Int = 0)
    private data class PositionKey(val x: Long, val y: Long, val z: Long)

    fun inspect(model: PmxModel, positionTolerance: Float = 1e-5f, uvAreaTolerance: Float = 1e-10f): MeshTopologyReport {
        val n = model.vertexCount
        val adjacency = Array(n) { LinkedHashSet<Int>() }
        val edges = HashMap<Long, EdgeUse>()
        val used = BooleanArray(n)
        var validTriangles = 0
        var invalidRecords = 0
        var zeroUvArea = 0
        fun edgeKey(a: Int, b: Int): Long {
            val lo = min(a, b); val hi = max(a, b)
            return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
        }
        fun addEdge(a: Int, b: Int) {
            val use = edges.getOrPut(edgeKey(a, b)) { EdgeUse() }
            use.count++
            use.directionSum += if (a < b) 1 else -1
        }

        for (i in model.indices.indices step 3) {
            if (i + 2 >= model.indices.size) { invalidRecords++; break }
            val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
            if (a !in 0 until n || b !in 0 until n || c !in 0 until n || a == b || b == c || c == a) {
                invalidRecords++
                continue
            }
            validTriangles++
            used[a] = true; used[b] = true; used[c] = true
            adjacency[a].add(b); adjacency[a].add(c)
            adjacency[b].add(a); adjacency[b].add(c)
            adjacency[c].add(a); adjacency[c].add(b)
            addEdge(a, b); addEdge(b, c); addEdge(c, a)
            if (model.uvs.size >= n * 2) {
                val au = a * 2; val bu = b * 2; val cu = c * 2
                val ax = model.uvs[au]; val ay = model.uvs[au + 1]
                val bx = model.uvs[bu]; val by = model.uvs[bu + 1]
                val cx = model.uvs[cu]; val cy = model.uvs[cu + 1]
                if (listOf(ax, ay, bx, by, cx, cy).all(Float::isFinite)) {
                    val area2 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
                    if (abs(area2) <= uvAreaTolerance) zeroUvArea++
                }
            }
        }

        val boundary = edges.values.count { it.count == 1 }
        val nonManifold = edges.values.count { it.count > 2 }
        val winding = edges.values.count { it.count == 2 && abs(it.directionSum) == 2 }
        var components = 0
        val seen = BooleanArray(n)
        val queue = IntArray(n)
        for (start in 0 until n) {
            if (seen[start] || adjacency[start].isEmpty()) continue
            components++
            var head = 0; var tail = 0
            queue[tail++] = start; seen[start] = true
            while (head < tail) {
                val v = queue[head++]
                for (next in adjacency[v]) if (!seen[next]) {
                    seen[next] = true
                    queue[tail++] = next
                }
            }
        }
        val isolated = used.count { !it }

        val tolerance = positionTolerance.takeIf { it.isFinite() && it > 0f } ?: 1e-5f
        val groups = HashMap<PositionKey, Int>()
        for (v in 0 until n) {
            val o = v * 3
            if (o + 2 >= model.positions.size) continue
            val x = model.positions[o]; val y = model.positions[o + 1]; val z = model.positions[o + 2]
            if (!x.isFinite() || !y.isFinite() || !z.isFinite()) continue
            val key = PositionKey((x / tolerance).roundToLong(), (y / tolerance).roundToLong(), (z / tolerance).roundToLong())
            groups[key] = (groups[key] ?: 0) + 1
        }
        val duplicateGroups = groups.values.count { it > 1 }
        val duplicateCount = groups.values.sumOf { (it - 1).coerceAtLeast(0) }
        return MeshTopologyReport(validTriangles, boundary, nonManifold, winding, components, isolated,
            duplicateGroups, duplicateCount, zeroUvArea, invalidRecords)
    }
}
