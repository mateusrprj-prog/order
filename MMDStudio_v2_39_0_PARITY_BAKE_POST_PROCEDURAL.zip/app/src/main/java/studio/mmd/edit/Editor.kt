package studio.mmd.edit

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import studio.mmd.mmd.MotionFrameOps
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Keyframe de osso: v = pos xyz + quat xyzw; ip = 16 bytes de Bézier. Imutável por convenção (troca-se o objeto, não os arrays). */
class BKey(val frame: Int, val v: FloatArray, val ip: ByteArray)
class MKey(val frame: Int, val w: Float)

/** Referência a UMA key do dope sheet: trilha (osso ou morph) + quadro. */
data class KeyRef(val morph: Boolean, val name: String, val frame: Int)

/** Pose salva na biblioteca do projeto. bones: nome -> [px,py,pz,qx,qy,qz,qw]. */
class PoseSnap(val name: String, val bones: Map<String, FloatArray>, val morphs: Map<String, Float>)

/** Conversão Euler (graus) <-> quaternion. Ordem Y·X·Z (o Z é aplicado primeiro), como no MMD. */
object Euler {
    private fun mul(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
    )

    private fun axis(i: Int, deg: Float): FloatArray {
        val h = Math.toRadians(deg.toDouble()).toFloat() / 2f
        val s = sin(h); val c = cos(h)
        return when (i) {
            0 -> floatArrayOf(s, 0f, 0f, c)
            1 -> floatArrayOf(0f, s, 0f, c)
            else -> floatArrayOf(0f, 0f, s, c)
        }
    }

    fun quat(xDeg: Float, yDeg: Float, zDeg: Float): FloatArray {
        val q = mul(mul(axis(1, yDeg), axis(0, xDeg)), axis(2, zDeg))
        val l = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
        if (l < 1e-8f) return floatArrayOf(0f, 0f, 0f, 1f)
        for (i in 0..3) q[i] /= l
        return q
    }

    /** q = (x,y,z,w). Retorna (x,y,z) em graus. */
    fun euler(q: FloatArray): FloatArray {
        val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
        val r00 = 1 - 2 * (y * y + z * z)
        val r02 = 2 * (x * z + y * w)
        val r10 = 2 * (x * y + z * w)
        val r11 = 1 - 2 * (x * x + z * z)
        val r12 = 2 * (y * z - x * w)
        val r20 = 2 * (x * z - y * w)
        val r22 = 1 - 2 * (x * x + y * y)
        val ex = asin((-r12).coerceIn(-1f, 1f))
        val ey: Float
        val ez: Float
        if (abs(r12) < 0.99999f) { ey = atan2(r02, r22); ez = atan2(r10, r11) }
        else { ey = atan2(-r20, r00); ez = 0f }
        return floatArrayOf(
            Math.toDegrees(ex.toDouble()).toFloat(),
            Math.toDegrees(ey.toDouble()).toFloat(),
            Math.toDegrees(ez.toDouble()).toFloat()
        )
    }
}

/**
 * Dados editáveis da animação (keyframes de ossos e morphs) + desfazer/refazer.
 * Tudo roda na thread principal. A thread GL só recebe o VmdMotion imutável devolvido por [motion].
 *
 * Regra de edição: mexer num osso/morph num quadro cria ou atualiza o keyframe daquele quadro (auto-key).
 */
class Editor(model: PmxModel) {
    var model: PmxModel = model
        private set
    /** Muda a cada edição (inclusive durante o arrasto de um slider). */
    var version by mutableIntStateOf(0)
        private set

    /** Muda só em comandos discretos (zerar, colar, desfazer, carregar VMD...). Os sliders relêem os valores quando isto muda. */
    var stamp by mutableIntStateOf(0)
        private set

    private val boneKeys = HashMap<String, ArrayList<BKey>>()
    private val morphKeys = HashMap<String, ArrayList<MKey>>()
    private val boneCache = HashMap<String, VmdTrack>()
    private val morphCache = HashMap<String, VmdMorphTrack>()
    private val dirtyB = HashSet<String>()
    private val dirtyM = HashSet<String>()
    private var boneNames: Set<String> = model.bones.map { it.name }.toHashSet()

    /** Substitui a malha sem perder as trilhas VMD; mantém apenas tracks com nomes ainda existentes. */
    fun replaceModel(updated: PmxModel) {
        val names = updated.bones.map { it.name }.toHashSet()
        val morphNames = updated.morphs.map { it.name }.toHashSet()
        model = updated
        boneNames = names
        boneKeys.keys.retainAll(names)
        boneCache.keys.retainAll(names)
        dirtyB.retainAll(names)
        morphKeys.keys.retainAll(morphNames)
        morphCache.keys.retainAll(morphNames)
        dirtyM.retainAll(morphNames)
        version++
        stamp++
    }
    private var clip: Map<String, FloatArray>? = null

    val hasClip: Boolean get() = !clip.isNullOrEmpty()

    private companion object {
        val IDENT = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)
        val RX = Regex("(?<![A-Za-z])([LR])(?![a-z])")
        val RS = Regex("(?<=[a-z0-9])([LR])\$")

        /** Curva linear padrão do MMD (20,20)-(107,107) nos 4 canais. */
        fun linearIp(): ByteArray {
            val a = ByteArray(16)
            for (i in 0..3) { a[i] = 20; a[4 + i] = 20; a[8 + i] = 107; a[12 + i] = 107 }
            return a
        }

        fun isIdent(v: FloatArray) =
            abs(v[0]) < 1e-6f && abs(v[1]) < 1e-6f && abs(v[2]) < 1e-6f &&
                abs(v[3]) < 1e-6f && abs(v[4]) < 1e-6f && abs(v[5]) < 1e-6f && v[6] > 0.999999f

        /** Espelho no plano X=0: pos (-x,y,z), rotação (qx,-qy,-qz,qw). */
        fun mirrorV(v: FloatArray) = floatArrayOf(-v[0], v[1], v[2], v[3], -v[4], -v[5], v[6])

        fun bez(ip: ByteArray, i1: Int, i2: Int, i3: Int, i4: Int, s: Float): Float {
            val x1 = (ip[i1].toInt() and 0xFF) / 127f; val y1 = (ip[i2].toInt() and 0xFF) / 127f
            val x2 = (ip[i3].toInt() and 0xFF) / 127f; val y2 = (ip[i4].toInt() and 0xFF) / 127f
            if (x1 == y1 && x2 == y2) return s
            var lo = 0f; var hi = 1f; var t = s
            for (k in 0 until 18) {
                t = (lo + hi) / 2
                val u = 1 - t
                val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
                if (x < s) lo = t else hi = t
            }
            val u = 1 - t
            return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
        }

        /** Índice do keyframe em [frame] ou -(ponto de inserção)-1. */
        fun idxB(l: List<BKey>, frame: Int): Int {
            var lo = 0; var hi = l.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1; val f = l[mid].frame
                if (f == frame) return mid
                if (f < frame) lo = mid + 1 else hi = mid - 1
            }
            return -(lo + 1)
        }

        fun idxM(l: List<MKey>, frame: Int): Int {
            var lo = 0; var hi = l.size - 1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1; val f = l[mid].frame
                if (f == frame) return mid
                if (f < frame) lo = mid + 1 else hi = mid - 1
            }
            return -(lo + 1)
        }
    }

    // ---------------------------------------------------------------- consulta

    fun hasTrack(name: String) = boneKeys[name]?.isNotEmpty() == true
    fun hasMorphTrack(name: String) = morphKeys[name]?.isNotEmpty() == true
    fun hasKey(name: String, frame: Int): Boolean = boneKeys[name]?.let { idxB(it, frame) >= 0 } ?: false

    fun keyFramesOf(name: String): IntArray {
        val l = boneKeys[name] ?: return IntArray(0)
        return IntArray(l.size) { l[it].frame }
    }

    fun allKeyFrames(): IntArray {
        val s = HashSet<Int>()
        for (l in boneKeys.values) for (k in l) s.add(k.frame)
        for (l in morphKeys.values) for (k in l) s.add(k.frame)
        val a = s.toIntArray(); a.sort(); return a
    }

    /** Valor local do osso no quadro [f] (pos xyz + quat xyzw), interpolado como o Animator faz. */
    fun sampleBone(name: String, f: Float, o: FloatArray) {
        val l = boneKeys[name]
        if (l == null || l.isEmpty()) { IDENT.copyInto(o); return }
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) { l[0].v.copyInto(o); return }
        if (i == l.size - 1) { l[i].v.copyInto(o); return }
        val a = l[i]; val b = l[i + 1]
        val s = (f - a.frame) / (b.frame - a.frame)
        val sx = bez(b.ip, 0, 4, 8, 12, s); val sy = bez(b.ip, 1, 5, 9, 13, s)
        val sz = bez(b.ip, 2, 6, 10, 14, s); val sr = bez(b.ip, 3, 7, 11, 15, s)
        o[0] = a.v[0] + (b.v[0] - a.v[0]) * sx
        o[1] = a.v[1] + (b.v[1] - a.v[1]) * sy
        o[2] = a.v[2] + (b.v[2] - a.v[2]) * sz
        var dot = 0f
        for (c in 0..3) dot += a.v[3 + c] * b.v[3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val q = a.v[3 + c] * (1 - sr) + b.v[3 + c] * sg * sr; o[3 + c] = q; len += q * q }
        len = sqrt(len)
        if (len > 1e-8f) for (c in 0..3) o[3 + c] /= len
    }

    fun sampleMorph(name: String, f: Float): Float {
        val l = morphKeys[name]
        if (l == null || l.isEmpty()) return 0f
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) return l[0].w
        if (i == l.size - 1) return l[i].w
        val s = (f - l[i].frame) / (l[i + 1].frame - l[i].frame)
        return l[i].w + (l[i + 1].w - l[i].w) * s
    }

    // ---------------------------------------------------------------- escrita de baixo nível (sem undo)

    private fun putBone(name: String, frame: Int, v: FloatArray, ip: ByteArray?) {
        val l = boneKeys.getOrPut(name) { ArrayList() }
        val i = idxB(l, frame)
        if (i >= 0) l[i] = BKey(frame, v, ip ?: l[i].ip) else l.add(-(i + 1), BKey(frame, v, ip ?: linearIp()))
        dirtyB.add(name)
    }

    private fun removeBone(name: String, frame: Int): Boolean {
        val l = boneKeys[name] ?: return false
        val i = idxB(l, frame)
        if (i < 0) return false
        l.removeAt(i)
        if (l.isEmpty()) boneKeys.remove(name)
        dirtyB.add(name)
        return true
    }

    private fun putMorph(name: String, frame: Int, w: Float) {
        val l = morphKeys.getOrPut(name) { ArrayList() }
        val i = idxM(l, frame)
        if (i >= 0) l[i] = MKey(frame, w) else l.add(-(i + 1), MKey(frame, w))
        dirtyM.add(name)
    }

    private fun removeMorph(name: String, frame: Int): Boolean {
        val l = morphKeys[name] ?: return false
        val i = idxM(l, frame)
        if (i < 0) return false
        l.removeAt(i)
        if (l.isEmpty()) morphKeys.remove(name)
        dirtyM.add(name)
        return true
    }

    // ---------------------------------------------------------------- desfazer / refazer

    private class Snap(val b: Map<String, List<BKey>?>, val m: Map<String, List<MKey>?>, val x: studio.mmd.mmd.VmdExtras)
    private class Entry(val before: Snap, val after: Snap)

    private val undoS = ArrayList<Entry>()
    private val redoS = ArrayList<Entry>()
    private var openBefore: Snap? = null
    private var openB: Set<String> = emptySet()
    private var openM: Set<String> = emptySet()

    val canUndo: Boolean get() = undoS.isNotEmpty() || openBefore != null
    val canRedo: Boolean get() = redoS.isNotEmpty()

    private fun snap(bn: Collection<String>, mn: Collection<String>): Snap =
        Snap(bn.associateWith { n -> boneKeys[n]?.let { ArrayList(it) } },
            mn.associateWith { n -> morphKeys[n]?.let { ArrayList(it) } }, vmdExtras)

    private fun restore(s: Snap) {
        vmdExtras = s.x   // v1.29.6: IK on/off também entra no desfazer
        for ((k, v) in s.b) { if (v == null) boneKeys.remove(k) else boneKeys[k] = ArrayList(v); dirtyB.add(k) }
        for ((k, v) in s.m) { if (v == null) morphKeys.remove(k) else morphKeys[k] = ArrayList(v); dirtyM.add(k) }
    }

    private fun bump(discrete: Boolean) { version++; if (discrete) stamp++ }

    private fun begin(bn: Collection<String>, mn: Collection<String> = emptyList()) {
        if (openBefore != null) {
            if (openB == bn.toSet() && openM == mn.toSet()) return
            commit()
        }
        openB = bn.toSet(); openM = mn.toSet()
        openBefore = snap(openB, openM)
    }

    private fun commit() {
        val b = openBefore ?: return
        openBefore = null
        undoS.add(Entry(b, snap(openB, openM)))
        redoS.clear()
        while (undoS.size > 100) undoS.removeAt(0)
    }

    private inline fun edit(bn: Collection<String>, mn: Collection<String> = emptyList(), block: () -> Unit) {
        begin(bn, mn); block(); commit(); bump(true)
    }

    /** Chamar quando o arrasto de um slider termina: fecha a transação (um único passo de desfazer). */
    fun finish() { commit(); version++ }

    fun undo(): Boolean {
        commit()
        if (undoS.isEmpty()) return false
        val e = undoS.removeAt(undoS.lastIndex)
        restore(e.before); redoS.add(e); bump(true)
        return true
    }

    fun redo(): Boolean {
        commit()
        if (redoS.isEmpty()) return false
        val e = redoS.removeAt(redoS.lastIndex)
        restore(e.after); undoS.add(e); bump(true)
        return true
    }

    // ---------------------------------------------------------------- edição de ossos

    /** Edição contínua (slider): cria/atualiza o keyframe de [name] no [frame]. Fechar com [finish]. */
    fun liveBone(name: String, frame: Int, rot: FloatArray?, pos: FloatArray?) {
        begin(listOf(name))
        val cur = FloatArray(7)
        sampleBone(name, frame.toFloat(), cur)
        if (rot != null) for (i in 0..3) cur[3 + i] = rot[i]
        if (pos != null) for (i in 0..2) cur[i] = pos[i]
        putBone(name, frame, cur, null)
        version++
    }

    /**
     * Arrasto no viewport: [dq] (quaternion xyzw, no espaço do pai) é aplicado por cima da rotação atual e [dp] soma à posição.
     * Cria/atualiza o keyframe do quadro. Fechar com [finishDrag].
     */
    fun nudgeBone(name: String, frame: Int, dq: FloatArray?, dp: FloatArray?) {
        begin(listOf(name))
        val cur = FloatArray(7)
        sampleBone(name, frame.toFloat(), cur)
        if (dq != null) {
            val a = dq; val x = cur[3]; val y = cur[4]; val z = cur[5]; val w = cur[6]
            val r = floatArrayOf(
                a[3] * x + a[0] * w + a[1] * z - a[2] * y,
                a[3] * y - a[0] * z + a[1] * w + a[2] * x,
                a[3] * z + a[0] * y - a[1] * x + a[2] * w,
                a[3] * w - a[0] * x - a[1] * y - a[2] * z
            )
            val l = sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2] + r[3] * r[3])
            if (l > 1e-8f) for (i in 0..3) cur[3 + i] = r[i] / l
        }
        if (dp != null) for (i in 0..2) cur[i] += dp[i]
        putBone(name, frame, cur, null)
        version++
    }

    // ---------------------------------------------------------------- curvas de interpolação

    /** Área de transferência de curva (x1,y1,x2,y2 em 0..127). */
    var curveClip: IntArray? = null

    /** Os 16 bytes da curva do keyframe (trecho que CHEGA nele a partir do keyframe anterior) ou null se não há key no quadro. */
    fun curveOf(name: String, frame: Int): ByteArray? {
        val l = boneKeys[name] ?: return null
        val i = idxB(l, frame)
        return if (i >= 0) l[i].ip.copyOf() else null
    }

    /** ch: 0=X 1=Y 2=Z 3=rotação, -1=todos. */
    private fun writeCurve(name: String, frame: Int, ch: Int, p: IntArray) {
        val l = boneKeys[name] ?: return
        val i = idxB(l, frame)
        if (i < 0) return
        val k = l[i]; val ip = k.ip.copyOf()
        for (c in (if (ch < 0) 0..3 else ch..ch)) {
            ip[c] = p[0].toByte(); ip[4 + c] = p[1].toByte(); ip[8 + c] = p[2].toByte(); ip[12 + c] = p[3].toByte()
        }
        l[i] = BKey(frame, k.v, ip); dirtyB.add(name)
    }

    /** Aplica um preset Bézier a todas as keys ósseas de um intervalo e trilhas selecionadas. */
    fun setCurveRange(names: Collection<String>, from: Int, to: Int, ch: Int, points: IntArray): Int {
        val lo = min(from, to); val hi = max(from, to)
        if (lo < 0 || hi < lo || ch !in -1..3 || points.size != 4) return 0
        val p = IntArray(4) { points[it].coerceIn(0, 127) }
        val tracks = names.distinct().filter { name -> boneKeys[name]?.any { it.frame in lo..hi } == true }
        if (tracks.isEmpty()) return 0
        val frames = tracks.associateWith { name -> boneKeys[name]!!.filter { it.frame in lo..hi }.map { it.frame } }
        val affected = frames.values.sumOf { it.size }
        edit(tracks) {
            for (name in tracks) for (f in frames[name].orEmpty()) writeCurve(name, f, ch, p)
        }
        return affected
    }

    /** Arrasto de um ponto da curva (fechar com [finishDrag]). */
    fun liveCurve(name: String, frame: Int, ch: Int, p: IntArray) { begin(listOf(name)); writeCurve(name, frame, ch, p); version++ }

    /** Aplica a curva de uma vez (preset, colar, inverter): um passo de desfazer. */
    fun setCurve(name: String, frame: Int, ch: Int, p: IntArray) { edit(listOf(name)) { writeCurve(name, frame, ch, p) } }

    /** Aplica a curva em todos os keyframes do osso. Retorna quantos. */
    fun setCurveAll(name: String, ch: Int, p: IntArray): Int {
        val fr = keyFramesOf(name)
        edit(listOf(name)) { for (f in fr) writeCurve(name, f, ch, p) }
        return fr.size
    }

    /**
     * Repete um intervalo de animação N vezes sem apagar o trecho original.
     * As keys posteriores nas mesmas trilhas são deslocadas para a frente para abrir espaço.
     * Ossos, morphs e o deslocamento posterior formam uma única operação de Undo.
     * Retorna o número de keys duplicadas; zero indica intervalo/vínculo inválido ou vazio.
     */
    fun repeatRange(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int, repeats: Int): Int {
        val lo = min(from, to); val hi = max(from, to)
        if (lo < 0 || hi < lo || repeats !in 1..100) return 0
        val period = hi.toLong() - lo.toLong() + 1L
        val totalShift = period * repeats.toLong()
        if (period <= 0L || hi.toLong() + totalShift >= Int.MAX_VALUE) return 0
        val boneNamesInRange = bn.distinct().filter { name -> boneKeys[name]?.any { it.frame in lo..hi } == true }
        val morphNamesInRange = mn.distinct().filter { name -> morphKeys[name]?.any { it.frame in lo..hi } == true }
        if (boneNamesInRange.isEmpty() && morphNamesInRange.isEmpty()) return 0
        // Só as trilhas que realmente serão modificadas podem impedir o deslocamento por overflow.
        val latestFollowing = (boneNamesInRange.mapNotNull { boneKeys[it]?.lastOrNull()?.frame } +
            morphNamesInRange.mapNotNull { morphKeys[it]?.lastOrNull()?.frame }).filter { it > hi }.maxOrNull() ?: hi
        if (latestFollowing.toLong() + totalShift >= Int.MAX_VALUE) return 0

        val boneSource = boneNamesInRange.associateWith { name -> boneKeys[name]!!.filter { it.frame in lo..hi }.toList() }
        val morphSource = morphNamesInRange.associateWith { name -> morphKeys[name]!!.filter { it.frame in lo..hi }.toList() }
        var duplicated = 0
        edit(boneNamesInRange, morphNamesInRange) {
            // Empurra as keys que vinham depois do intervalo, mantendo o restante da animação intacto.
            for (name in boneNamesInRange) {
                val later = boneKeys[name]?.filter { it.frame > hi }?.toList() ?: emptyList()
                for (key in later) removeBone(name, key.frame)
                for (key in later) putBone(name, (key.frame.toLong() + totalShift).toInt(), key.v.copyOf(), key.ip.copyOf())
            }
            for (name in morphNamesInRange) {
                val later = morphKeys[name]?.filter { it.frame > hi }?.toList() ?: emptyList()
                for (key in later) removeMorph(name, key.frame)
                for (key in later) putMorph(name, (key.frame.toLong() + totalShift).toInt(), key.w)
            }
            for (cycle in 1..repeats) {
                val shift = (period * cycle.toLong()).toInt()
                for ((name, source) in boneSource) for (key in source) {
                    putBone(name, key.frame + shift, key.v.copyOf(), key.ip.copyOf())
                    duplicated++
                }
                for ((name, source) in morphSource) for (key in source) {
                    putMorph(name, key.frame + shift, key.w)
                    duplicated++
                }
            }
        }
        return duplicated
    }

    /**
     * Exclui as keys dentro do intervalo e fecha o espaço deslocando as keys seguintes para trás.
     * Só afeta trilhas que possuem ao menos uma key dentro do intervalo; tudo vira um único Undo.
     * Retorna o total de keys removidas e deslocadas.
     */
    fun rippleDeleteRange(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        val lo = min(from, to); val hi = max(from, to)
        if (lo < 0 || hi < lo) return 0
        val boneNames = bn.distinct().filter { name -> boneKeys[name]?.any { it.frame in lo..hi } == true }
        val morphNames = mn.distinct().filter { name -> morphKeys[name]?.any { it.frame in lo..hi } == true }
        if (boneNames.isEmpty() && morphNames.isEmpty()) return 0
        val span = hi.toLong() - lo.toLong() + 1L
        val boneSource = boneNames.associateWith { name -> boneKeys[name]!!.filter { it.frame >= lo }.toList() }
        val morphSource = morphNames.associateWith { name -> morphKeys[name]!!.filter { it.frame >= lo }.toList() }
        val affected = boneSource.values.sumOf { it.size } + morphSource.values.sumOf { it.size }
        edit(boneNames, morphNames) {
            for (name in boneNames) {
                val source = boneSource[name].orEmpty()
                for (key in source) removeBone(name, key.frame)
                for (key in source) if (key.frame > hi) {
                    putBone(name, (key.frame.toLong() - span).toInt(), key.v.copyOf(), key.ip.copyOf())
                }
            }
            for (name in morphNames) {
                val source = morphSource[name].orEmpty()
                for (key in source) removeMorph(name, key.frame)
                for (key in source) if (key.frame > hi) {
                    putMorph(name, (key.frame.toLong() - span).toInt(), key.w)
                }
            }
        }
        return affected
    }

    /**
     * Inverte no tempo as keys de osso e morph dentro de um intervalo, mantendo os limites
     * e os quadros existentes. As curvas Bézier dos segmentos internos também são invertidas
     * para que a aceleração/desaceleração acompanhe a direção temporal. Uma única entrada de Undo.
     */
    fun reverseRange(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        val lo = min(from, to); val hi = max(from, to)
        if (lo < 0 || hi <= lo) return 0
        val boneNamesInRange = bn.distinct().filter { name -> ((boneKeys[name]?.count { it.frame in lo..hi }) ?: 0) >= 2 }
        val morphNamesInRange = mn.distinct().filter { name -> ((morphKeys[name]?.count { it.frame in lo..hi }) ?: 0) >= 2 }
        if (boneNamesInRange.isEmpty() && morphNamesInRange.isEmpty()) return 0
        val boneSource = boneNamesInRange.associateWith { name -> boneKeys[name]!!.filter { it.frame in lo..hi }.toList() }
        val morphSource = morphNamesInRange.associateWith { name -> morphKeys[name]!!.filter { it.frame in lo..hi }.toList() }
        var moved = 0
        edit(boneNamesInRange, morphNamesInRange) {
            for (name in boneNamesInRange) {
                val src = boneSource[name]!!
                src.forEach { removeBone(name, it.frame) }
                for (i in src.indices) {
                    val key = src[i]
                    val newFrame = (lo.toLong() + hi.toLong() - key.frame.toLong()).toInt()
                    val ip = if (i < src.lastIndex) reverseBezier(src[i + 1].ip) else key.ip.copyOf()
                    putBone(name, newFrame, key.v.copyOf(), ip)
                    moved++
                }
            }
            for (name in morphNamesInRange) {
                val src = morphSource[name]!!
                src.forEach { removeMorph(name, it.frame) }
                for (key in src) {
                    val newFrame = (lo.toLong() + hi.toLong() - key.frame.toLong()).toInt()
                    putMorph(name, newFrame, key.w)
                    moved++
                }
            }
        }
        return moved
    }

    /** Reverte os quatro canais Bézier no tempo: p1' = 1-p2; p2' = 1-p1. */
    private fun reverseBezier(source: ByteArray): ByteArray {
        val out = source.copyOf()
        for (channel in 0..3) {
            out[channel] = (127 - (source[8 + channel].toInt() and 0xFF)).coerceIn(0, 127).toByte()
            out[4 + channel] = (127 - (source[12 + channel].toInt() and 0xFF)).coerceIn(0, 127).toByte()
            out[8 + channel] = (127 - (source[channel].toInt() and 0xFF)).coerceIn(0, 127).toByte()
            out[12 + channel] = (127 - (source[4 + channel].toInt() and 0xFF)).coerceIn(0, 127).toByte()
        }
        return out
    }

    /**
     * Suaviza valores de keys existentes em um intervalo sem alterar os quadros das keys.
     * A primeira e a última key de cada trilha permanecem fixas. Para ossos, posição é filtrada
     * linearmente e rotação usa média de quaternions com correção de hemisfério. Morphs usam
     * média linear. O algoritmo é determinístico e executa como um único passo de Undo.
     */
    fun smoothRange(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int, strength: Float, passes: Int = 1): Int {
        val lo = min(from, to); val hi = max(from, to)
        val amount = strength.coerceIn(0f, 1f)
        val iterations = passes.coerceIn(1, 8)
        if (lo < 0 || hi <= lo || amount <= 0f) return 0
        val boneNamesInRange = bn.distinct().filter { name -> ((boneKeys[name]?.count { it.frame in lo..hi }) ?: 0) >= 3 }
        val morphNamesInRange = mn.distinct().filter { name -> ((morphKeys[name]?.count { it.frame in lo..hi }) ?: 0) >= 3 }
        if (boneNamesInRange.isEmpty() && morphNamesInRange.isEmpty()) return 0
        val affected = (boneNamesInRange.sumOf { boneKeys[it]!!.count { k -> k.frame in lo..hi } - 2 } +
            morphNamesInRange.sumOf { morphKeys[it]!!.count { k -> k.frame in lo..hi } - 2 }).coerceAtLeast(0)

        edit(boneNamesInRange, morphNamesInRange) {
            repeat(iterations) {
                for (name in boneNamesInRange) {
                    val src = boneKeys[name]?.filter { it.frame in lo..hi }?.toList() ?: continue
                    if (src.size < 3) continue
                    for (i in 1 until src.lastIndex) {
                        val prev = src[i - 1]; val cur = src[i]; val next = src[i + 1]
                        val out = cur.v.copyOf()
                        for (axis in 0..2) {
                            val avg = (prev.v[axis] + next.v[axis]) * 0.5f
                            out[axis] = cur.v[axis] + (avg - cur.v[axis]) * amount
                        }
                        var qx = prev.v[3]; var qy = prev.v[4]; var qz = prev.v[5]; var qw = prev.v[6]
                        val dotPrev = qx * cur.v[3] + qy * cur.v[4] + qz * cur.v[5] + qw * cur.v[6]
                        if (dotPrev < 0f) { qx = -qx; qy = -qy; qz = -qz; qw = -qw }
                        var nx = next.v[3]; var ny = next.v[4]; var nz = next.v[5]; var nw = next.v[6]
                        val dotNext = nx * cur.v[3] + ny * cur.v[4] + nz * cur.v[5] + nw * cur.v[6]
                        if (dotNext < 0f) { nx = -nx; ny = -ny; nz = -nz; nw = -nw }
                        var ax = (qx + nx) * 0.5f; var ay = (qy + ny) * 0.5f
                        var az = (qz + nz) * 0.5f; var aw = (qw + nw) * 0.5f
                        var qLen = sqrt(ax * ax + ay * ay + az * az + aw * aw)
                        if (qLen > 1e-8f) { ax /= qLen; ay /= qLen; az /= qLen; aw /= qLen }
                        var rx = cur.v[3] + (ax - cur.v[3]) * amount
                        var ry = cur.v[4] + (ay - cur.v[4]) * amount
                        var rz = cur.v[5] + (az - cur.v[5]) * amount
                        var rw = cur.v[6] + (aw - cur.v[6]) * amount
                        qLen = sqrt(rx * rx + ry * ry + rz * rz + rw * rw)
                        if (qLen > 1e-8f) { rx /= qLen; ry /= qLen; rz /= qLen; rw /= qLen }
                        out[3] = rx; out[4] = ry; out[5] = rz; out[6] = rw
                        putBone(name, cur.frame, out, cur.ip.copyOf())
                    }
                }
                for (name in morphNamesInRange) {
                    val src = morphKeys[name]?.filter { it.frame in lo..hi }?.toList() ?: continue
                    if (src.size < 3) continue
                    for (i in 1 until src.lastIndex) {
                        val cur = src[i]
                        val avg = (src[i - 1].w + src[i + 1].w) * 0.5f
                        putMorph(name, cur.frame, cur.w + (avg - cur.w) * amount)
                    }
                }
            }
        }
        return affected
    }

    /** Fim do arrasto no viewport: fecha o passo de desfazer e faz os sliders relerem os valores. */
    fun finishDrag() { commit(); bump(true) }

    /** Cria keyframe (valor atual interpolado) nos ossos que ainda não têm key no quadro. */
    fun keyBones(names: Collection<String>, frame: Int): Int {
        var c = 0
        edit(names) {
            for (n in names) {
                if (hasKey(n, frame)) continue
                val o = FloatArray(7); sampleBone(n, frame.toFloat(), o)
                putBone(n, frame, o, null); c++
            }
        }
        return c
    }

    fun deleteKeys(names: Collection<String>, frame: Int): Int {
        var c = 0
        edit(names) { for (n in names) if (removeBone(n, frame)) c++ }
        return c
    }

    fun zeroBones(names: Collection<String>, frame: Int) {
        edit(names) { for (n in names) putBone(n, frame, IDENT.copyOf(), null) }
    }

    fun mirrorBone(name: String, frame: Int): Boolean {
        val p = mirrorName(name) ?: return false
        val o = FloatArray(7); sampleBone(name, frame.toFloat(), o)
        edit(listOf(p)) { putBone(p, frame, mirrorV(o), null) }
        return true
    }

    // ---------------------------------------------------------------- pose inteira

    fun copyPose(frame: Int): Int {
        val m = HashMap<String, FloatArray>()
        for (n in boneNames) {
            val o = FloatArray(7); sampleBone(n, frame.toFloat(), o)
            if (boneKeys.containsKey(n) || !isIdent(o)) m[n] = o
        }
        clip = m
        bump(false)
        return m.size
    }

    fun pastePose(frame: Int): Int {
        val c = clip ?: return 0
        edit(c.keys.toList()) { for ((n, v) in c) putBone(n, frame, v.copyOf(), null) }
        return c.size
    }

    fun mirrorPose(frame: Int): Int {
        val cur = HashMap<String, FloatArray>()
        for (n in boneNames) { val o = FloatArray(7); sampleBone(n, frame.toFloat(), o); cur[n] = o }
        val out = HashMap<String, FloatArray>()
        for (n in boneNames) {
            val p = mirrorName(n)
            if (p != null) out[n] = mirrorV(cur.getValue(p))
            else if (!hasSide(n)) out[n] = mirrorV(cur.getValue(n))
        }
        var c = 0
        edit(out.keys.toList()) {
            for ((n, v) in out) if (boneKeys.containsKey(n) || !isIdent(v)) { putBone(n, frame, v, null); c++ }
        }
        return c
    }

    fun zeroPose(frame: Int): Int {
        val names = boneKeys.keys.toList()
        edit(names) { for (n in names) putBone(n, frame, IDENT.copyOf(), null) }
        return names.size
    }

    fun resetPose(frame: Int): Int {
        val names = boneKeys.keys.toList()
        var c = 0
        edit(names) { for (n in names) if (removeBone(n, frame)) c++ }
        return c
    }

    // ---------------------------------------------------------------- captura de movimento

    /**
     * Grava as trilhas do mocap (osso -> lista de (quadro, [px,py,pz,qx,qy,qz,qw])) num único passo de desfazer.
     * Antes, apaga as keys desses ossos entre [from] e [to] (regenerar só um trecho). Devolve quantas keys foram escritas.
     */
    fun applyMocap(tracks: Map<String, List<Pair<Int, FloatArray>>>, from: Int, to: Int): Int {
        var n = 0
        val names = tracks.keys.filter { it in boneNames }
        edit(names) {
            for (nm in names) {
                val old = boneKeys[nm]?.map { it.frame }?.filter { it in from..to } ?: emptyList()
                for (fr in old) removeBone(nm, fr)
                for ((fr, v) in tracks.getValue(nm)) { putBone(nm, fr, v.copyOf(), null); n++ }
            }
        }
        return n
    }

    /**
     * Grava uma animação gerada (ossos + morphs) num único passo de desfazer. Antes apaga as keys dos ossos/morphs afetados entre
     * [from] e [to]. Ossos/morphs que o modelo não tem são ignorados. Devolve quantas keys foram escritas.
     */
    fun applyAnim(tracks: Map<String, List<Pair<Int, FloatArray>>>, morphs: Map<String, List<Pair<Int, Float>>>, from: Int, to: Int): Int {
        var n = 0
        val names = tracks.keys.filter { it in boneNames }
        val mnames = morphs.keys.filter { m -> model.morphs.any { it.name == m } }
        edit(names, mnames) {
            for (nm in names) {
                val old = boneKeys[nm]?.map { it.frame }?.filter { it in from..to } ?: emptyList()
                for (fr in old) removeBone(nm, fr)
                for ((fr, v) in tracks.getValue(nm)) { putBone(nm, fr, v.copyOf(), null); n++ }
            }
            for (nm in mnames) {
                val old = morphKeys[nm]?.map { it.frame }?.filter { it in from..to } ?: emptyList()
                for (fr in old) removeMorph(nm, fr)
                for ((fr, w) in morphs.getValue(nm)) { putMorph(nm, fr, w); n++ }
            }
        }
        return n
    }

    /**
     * v1.28.0 (Cartoon Motion Library): grava trilhas COM as curvas Bézier (diferente de [applyAnim], que usa curva linear) num único
     * passo de desfazer. Antes apaga, nos ossos/morphs afetados, as keys entre [from] e [to]. Ossos/morphs que o modelo não tem são ignorados.
     * Devolve quantas keys foram escritas.
     */
    fun applyKeys(bones: Map<String, List<BKey>>, morphs: Map<String, List<MKey>>, from: Int, to: Int): Int {
        var n = 0
        val names = bones.keys.filter { it in boneNames }
        val mnames = morphs.keys.filter { m -> model.morphs.any { it.name == m } }
        val ikOff = studio.mmd.cartoon.ikBonesDriving(model, names)   // v1.29.6: pernas são dirigidas por IK; sem desligar, o IK anula o Cartoon
        edit(names, mnames) {
            if (ikOff.isNotEmpty()) vmdExtras = studio.mmd.mmd.VmdExtras(studio.mmd.cartoon.IkRange.off(vmdExtras.ik, ikOff, from, to), vmdExtras.lights, vmdExtras.shadows, vmdExtras.visibility)
            for (nm in names) {
                val old = boneKeys[nm]?.map { it.frame }?.filter { it in from..to } ?: emptyList()
                for (fr in old) removeBone(nm, fr)
                for (k in bones.getValue(nm)) { putBone(nm, k.frame, k.v.copyOf(), k.ip.copyOf()); n++ }
            }
            for (nm in mnames) {
                val old = morphKeys[nm]?.map { it.frame }?.filter { it in from..to } ?: emptyList()
                for (fr in old) removeMorph(nm, fr)
                for (k in morphs.getValue(nm)) { putMorph(nm, k.frame, k.w); n++ }
            }
        }
        return n
    }

    // ---------------------------------------------------------------- biblioteca de poses

    /** Fotografia da pose (ossos animados/não neutros + morphs ativos) no quadro [frame]. */
    fun snapshot(frame: Int, name: String): PoseSnap {
        val b = HashMap<String, FloatArray>()
        for (n in boneNames) { val o = FloatArray(7); sampleBone(n, frame.toFloat(), o); if (boneKeys.containsKey(n) || !isIdent(o)) b[n] = o }
        val m = HashMap<String, Float>()
        for (mo in model.morphs) { val w = sampleMorph(mo.name, frame.toFloat()); if (w != 0f || morphKeys.containsKey(mo.name)) m[mo.name] = w }
        return PoseSnap(name, b, m)
    }

    /** Aplica a pose como keyframes no quadro [frame]; devolve quantos ossos foram gravados. */
    fun applySnap(p: PoseSnap, frame: Int): Int {
        val bn = p.bones.keys.filter { it in boneNames }
        val mn = p.morphs.keys.filter { k -> model.morphs.any { it.name == k } }
        edit(bn, mn) { for (n in bn) putBone(n, frame, p.bones.getValue(n).copyOf(), null); for (n in mn) putMorph(n, frame, p.morphs.getValue(n)) }
        return bn.size
    }

    // ---------------------------------------------------------------- morphs

    fun liveMorph(name: String, frame: Int, w: Float) {
        begin(emptyList(), listOf(name))
        putMorph(name, frame, w)
        version++
    }

    fun zeroMorph(name: String, frame: Int) { edit(emptyList(), listOf(name)) { putMorph(name, frame, 0f) } }
    fun deleteMorphKey(name: String, frame: Int): Boolean {
        var ok = false
        edit(emptyList(), listOf(name)) { ok = removeMorph(name, frame) }
        return ok
    }

    // ---------------------------------------------------------------- lado esquerdo/direito

    private fun hasSide(n: String): Boolean =
        n.contains('左') || n.contains('右') || n.contains("Left") || n.contains("Right") ||
            n.contains("left") || n.contains("right") || RX.containsMatchIn(n) || RS.containsMatchIn(n)

    /** Nome do osso do outro lado (só se existir no modelo), ou null. */
    fun mirrorName(n: String): String? {
        val t = when {
            n.contains('左') -> n.replace('左', '右')
            n.contains('右') -> n.replace('右', '左')
            n.contains("Left") -> n.replace("Left", "Right")
            n.contains("Right") -> n.replace("Right", "Left")
            n.contains("left") -> n.replace("left", "right")
            n.contains("right") -> n.replace("right", "left")
            RX.containsMatchIn(n) -> RX.replace(n) { if (it.value == "L") "R" else "L" }
            RS.containsMatchIn(n) -> RS.replace(n) { if (it.value == "L") "R" else "L" }
            else -> return null
        }
        return if (t != n && t in boneNames) t else null
    }

    // ---------------------------------------------------------------- exportar VMD

    /** Número de keyframes (ossos + morphs) que seriam gravados. */
    fun keyCount(): Int = boneKeys.values.sumOf { it.size } + morphKeys.values.sumOf { it.size }

    /** VMD v2 com os keyframes de ossos e morphs (nomes em Shift_JIS, 15 bytes; câmera/luz/sombra/IK vazios). */
    /** [cam]: se informada, grava também a seção de câmera (61 bytes por key) no VMD. */
    fun toVmd(cam: studio.mmd.mmd.VmdCamera? = null): ByteArray {
        val sj = Charset.forName("Shift_JIS")
        val bl = ArrayList<Pair<String, BKey>>()
        for ((n, l) in boneKeys) for (k in l) bl.add(n to k)
        bl.sortBy { it.second.frame }
        val ml = ArrayList<Pair<String, MKey>>()
        for ((n, l) in morphKeys) for (k in l) ml.add(n to k)
        ml.sortBy { it.second.frame }
        val nc = cam?.frames?.size ?: 0
        val b = ByteBuffer.allocate(30 + 20 + 4 + bl.size * 111 + 4 + ml.size * 23 + 4 + nc * 61 + vmdExtras.byteSize()).order(ByteOrder.LITTLE_ENDIAN)
        fun fixed(s: String, n: Int) {
            val e = s.toByteArray(sj)
            val a = ByteArray(n)
            System.arraycopy(e, 0, a, 0, min(e.size, n))
            b.put(a)
        }
        fixed("Vocaloid Motion Data 0002", 30)
        fixed(model.name, 20)
        b.putInt(bl.size)
        for ((n, k) in bl) {
            fixed(n, 15); b.putInt(k.frame)
            for (i in 0..6) b.putFloat(k.v[i])
            // 64 bytes: as 16 de interpolação repetidas deslocadas de 1 em 1, fechando com 01 00 00
            for (r in 0..3) for (j in 0 until 16) {
                val idx = j + r
                b.put(if (idx < 16) k.ip[idx] else if (idx == 16) 1.toByte() else 0.toByte())
            }
        }
        b.putInt(ml.size)
        for ((n, k) in ml) { fixed(n, 15); b.putInt(k.frame); b.putFloat(k.w) }
        b.putInt(nc)   // câmera
        if (cam != null) for (i in 0 until nc) {
            b.putInt(cam.frames[i]); b.putFloat(cam.dist[i])
            for (c in 0..2) b.putFloat(cam.pos[i * 3 + c])
            for (c in 0..2) b.putFloat(cam.rot[i * 3 + c])
            b.put(cam.ip, i * 24, 24)
            b.putInt(cam.fov[i].toInt()); b.put(0.toByte())   // fov em graus; perspectiva ligada
        }
        vmdExtras.write(b)   // luz, sombra, IK (v1.13.0: preservados do VMD importado)
        return b.array()
    }

    // ---------------------------------------------------------------- ligação com VMD / renderer

    /** Substitui toda a animação pelo conteúdo do VMD (só ossos/morphs que existem no modelo). Limpa o desfazer. */
    /** Quantas keys do último VMD carregado não casaram com ossos/morphs do modelo (e portanto não serão regravadas). */
    var lastSkippedBoneKeys = 0; var lastSkippedMorphKeys = 0
    /** IK ligado/desligado, luz e self-shadow do último VMD carregado (v1.13.0). Não é editável nem entra no arquivo de projeto ainda. */
    var vmdExtras: studio.mmd.mmd.VmdExtras = studio.mmd.mmd.VmdExtras.EMPTY; private set
    fun load(mo: VmdMotion) {
        lastSkippedBoneKeys = 0; lastSkippedMorphKeys = 0; vmdExtras = mo.extras
        boneKeys.clear(); morphKeys.clear(); boneCache.clear(); morphCache.clear()
        dirtyB.clear(); dirtyM.clear(); undoS.clear(); redoS.clear(); openBefore = null
        val mn = model.morphs.map { it.name }.toHashSet()
        for ((n, t) in mo.bones) {
            if (n !in boneNames) { lastSkippedBoneKeys += t.frames.size; continue }
            val l = ArrayList<BKey>(t.frames.size)
            for (i in t.frames.indices) l.add(BKey(t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
            boneKeys[n] = l; dirtyB.add(n)
        }
        for ((n, t) in mo.morphs) {
            if (n !in mn) { lastSkippedMorphKeys += t.frames.size; continue }
            val l = ArrayList<MKey>(t.frames.size)
            for (i in t.frames.indices) l.add(MKey(t.frames[i], t.w[i]))
            morphKeys[n] = l; dirtyM.add(n)
        }
        bump(true)
    }

    /**
     * v1.24.0: substitui toda a animação pelo [mo] COMO UM PASSO DE DESFAZER (as keys anteriores voltam com desfazer).
     * Diferente de [load], não limpa o histórico. Só ossos/morphs que existem no modelo; o resto é contado em lastSkipped*.
     */
    fun replaceUndoable(mo: VmdMotion) {
        val mset = model.morphs.map { it.name }.toHashSet()
        val bn = HashSet<String>(boneKeys.keys); for (n in mo.bones.keys) if (n in boneNames) bn.add(n)
        val mn = HashSet<String>(morphKeys.keys); for (n in mo.morphs.keys) if (n in mset) mn.add(n)
        edit(bn, mn) {
            lastSkippedBoneKeys = 0; lastSkippedMorphKeys = 0; vmdExtras = mo.extras
            for (n in bn) { boneKeys.remove(n); boneCache.remove(n); dirtyB.add(n) }
            for (n in mn) { morphKeys.remove(n); morphCache.remove(n); dirtyM.add(n) }
            for ((n, t) in mo.bones) {
                if (n !in boneNames) { lastSkippedBoneKeys += t.frames.size; continue }
                val l = ArrayList<BKey>(t.frames.size)
                for (i in t.frames.indices) l.add(BKey(t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
                boneKeys[n] = l
            }
            for ((n, t) in mo.morphs) {
                if (n !in mset) { lastSkippedMorphKeys += t.frames.size; continue }
                val l = ArrayList<MKey>(t.frames.size)
                for (i in t.frames.indices) l.add(MKey(t.frames[i], t.w[i]))
                morphKeys[n] = l
            }
        }
    }

    /**
     * "Assar": grava uma rotação por quadro (de [from] a [to]) nos ossos [names]; [rots] devolve, para cada quadro, a
     * rotação local (x,y,z,w) por osso. A posição continua a do keyframe/animação atual. Um único passo de desfazer.
     */
    fun bakeRotations(names: Collection<String>, from: Int, to: Int, rots: (Int) -> Map<String, FloatArray>?): Int {
        var n = 0
        val o = FloatArray(7)
        edit(names) {
            for (f in from..to) {
                val r = rots(f) ?: continue
                for (nm in names) {
                    val q = r[nm] ?: continue
                    sampleBone(nm, f.toFloat(), o)
                    val v = FloatArray(7); for (k in 0..2) v[k] = o[k]; for (k in 0..3) v[3 + k] = q[k]
                    putBone(nm, f, v, linearIp()); n++
                }
            }
        }
        return n
    }

    // ---------------------------------------------------------------- v1.15.0 (Release 5): edição de keys por trecho
    // Seleção = trilhas (ossos/morphs) × intervalo de quadros [from, to]. Tudo com desfazer (um passo por comando).

    private class KeyClip(val bones: Map<String, List<BKey>>, val morphs: Map<String, List<MKey>>)
    private var keyClip: KeyClip? = null
    val hasKeyClip: Boolean get() = keyClip != null

    /** Nomes dos ossos / morphs que têm ao menos um keyframe. */
    fun boneTrackNames(): List<String> = boneKeys.keys.sorted()
    fun morphTrackNames(): List<String> = morphKeys.keys.sorted()

    fun countKeys(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        var c = 0
        for (n in bn) boneKeys[n]?.let { l -> for (k in l) if (k.frame in from..to) c++ }
        for (n in mn) morphKeys[n]?.let { l -> for (k in l) if (k.frame in from..to) c++ }
        return c
    }

    /** Move as keys do trecho por [delta] quadros. Devolve quantas moveu; -1 se alguma iria para antes do quadro 0 (nada é alterado). Key de destino no mesmo quadro é substituída. */
    fun moveKeys(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int, delta: Int): Int {
        if (delta == 0) return 0
        var lo = Int.MAX_VALUE
        for (n in bn) boneKeys[n]?.forEach { if (it.frame in from..to) lo = min(lo, it.frame) }
        for (n in mn) morphKeys[n]?.forEach { if (it.frame in from..to) lo = min(lo, it.frame) }
        if (lo == Int.MAX_VALUE) return 0
        if (lo + delta < 0) return -1
        var c = 0
        edit(bn, mn) {
            for (n in bn) {
                val sel = boneKeys[n]?.filter { it.frame in from..to } ?: continue
                for (k in sel) removeBone(n, k.frame)
                for (k in sel) putBone(n, k.frame + delta, k.v, k.ip)
                c += sel.size
            }
            for (n in mn) {
                val sel = morphKeys[n]?.filter { it.frame in from..to } ?: continue
                for (k in sel) removeMorph(n, k.frame)
                for (k in sel) putMorph(n, k.frame + delta, k.w)
                c += sel.size
            }
        }
        return c
    }

    /** Copia as keys do trecho (posições relativas a [from]) para a área de transferência de keys. */
    fun copyKeys(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        val b = HashMap<String, List<BKey>>(); val m = HashMap<String, List<MKey>>()
        var c = 0
        for (n in bn) { val sel = boneKeys[n]?.filter { it.frame in from..to }?.map { BKey(it.frame - from, it.v, it.ip) } ?: continue; if (sel.isNotEmpty()) { b[n] = sel; c += sel.size } }
        for (n in mn) { val sel = morphKeys[n]?.filter { it.frame in from..to }?.map { MKey(it.frame - from, it.w) } ?: continue; if (sel.isNotEmpty()) { m[n] = sel; c += sel.size } }
        keyClip = if (c > 0) KeyClip(b, m) else null
        return c
    }

    /** Cola as keys copiadas começando em [at]. Mesmas trilhas de quando copiou; substitui keys no mesmo quadro. */
    fun pasteKeys(at: Int): Int {
        val k = keyClip ?: return 0
        var c = 0
        edit(k.bones.keys, k.morphs.keys) {
            for ((n, l) in k.bones) if (n in boneNames) for (e in l) { putBone(n, at + e.frame, e.v, e.ip); c++ }
            for ((n, l) in k.morphs) for (e in l) { putMorph(n, at + e.frame, e.w); c++ }
        }
        return c
    }

    fun deleteRange(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        var c = 0
        edit(bn, mn) {
            for (n in bn) for (f in (boneKeys[n]?.filter { it.frame in from..to }?.map { it.frame } ?: emptyList())) if (removeBone(n, f)) c++
            for (n in mn) for (f in (morphKeys[n]?.filter { it.frame in from..to }?.map { it.frame } ?: emptyList())) if (removeMorph(n, f)) c++
        }
        return c
    }

    /**
     * Retiming: escala o tempo do trecho [from, to] por [factor] (2 = metade da velocidade, 0,5 = o dobro), mantendo o quadro [from] fixo.
     * As keys depois de [to] nas mesmas trilhas são deslocadas junto (ripple). Frames arredondados; keys que caem no mesmo quadro: a última vence.
     * Devolve quantas keys foram afetadas (trecho + deslocadas); 0 se nada no trecho ou factor fora de 0,1–10.
     */
    fun retimeKeys(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int, factor: Float): Int {
        if (factor < 0.1f || factor > 10f || to <= from) return 0
        if (countKeys(bn, mn, from, to) == 0) return 0
        val shift = Math.round((to - from) * factor) - (to - from)
        fun nf(f: Int) = if (f <= to) from + Math.round((f - from) * factor) else f + shift
        var c = 0
        edit(bn, mn) {
            for (n in bn) {
                val sel = boneKeys[n]?.filter { it.frame >= from } ?: continue
                if (sel.isEmpty()) continue
                for (k in sel) removeBone(n, k.frame)
                for (k in sel) putBone(n, nf(k.frame), k.v, k.ip)
                c += sel.size
            }
            for (n in mn) {
                val sel = morphKeys[n]?.filter { it.frame >= from } ?: continue
                if (sel.isEmpty()) continue
                for (k in sel) removeMorph(n, k.frame)
                for (k in sel) putMorph(n, nf(k.frame), k.w)
                c += sel.size
            }
        }
        return c
    }

    // ---------------------------------------------------------------- v1.16.0 (Release 5, fatia 2): dope sheet — keys individuais

    fun morphKeyFramesOf(name: String): IntArray {
        val l = morphKeys[name] ?: return IntArray(0)
        return IntArray(l.size) { l[it].frame }
    }

    /** Só as refs que existem de verdade (quadro e trilha). */
    private fun existing(refs: Collection<KeyRef>): List<KeyRef> = refs.filter {
        if (it.morph) morphKeys[it.name]?.let { l -> idxM(l, it.frame) >= 0 } == true
        else boneKeys[it.name]?.let { l -> idxB(l, it.frame) >= 0 } == true
    }

    fun hasKeyRef(r: KeyRef): Boolean = existing(listOf(r)).isNotEmpty()

    /** Menor quadro que [delta] permite: devolve true se alguma key iria para antes do quadro 0. */
    fun moveWouldGoNegative(refs: Collection<KeyRef>, delta: Int): Boolean =
        refs.any { it.frame + delta < 0 }

    /**
     * Move as keys [refs] por [delta] quadros (uma transação de desfazer). Devolve quantas moveu; -1 se alguma iria para antes do
     * quadro 0 (nada é alterado). Key de destino no mesmo quadro, que NÃO está sendo movida, é substituída.
     */
    fun moveKeyRefs(refs: Collection<KeyRef>, delta: Int): Int {
        val ex = existing(refs)
        if (ex.isEmpty() || delta == 0) return 0
        if (moveWouldGoNegative(ex, delta)) return -1
        val bn = ex.filter { !it.morph }.map { it.name }.toSet()
        val mn = ex.filter { it.morph }.map { it.name }.toSet()
        // captura os valores ANTES de remover (a remoção muda os índices)
        val bk = ArrayList<Pair<KeyRef, BKey>>(); val mk = ArrayList<Pair<KeyRef, MKey>>()
        for (r in ex) {
            if (r.morph) { val l = morphKeys[r.name]!!; mk.add(r to l[idxM(l, r.frame)]) }
            else { val l = boneKeys[r.name]!!; bk.add(r to l[idxB(l, r.frame)]) }
        }
        edit(bn, mn) {
            for ((r, _) in bk) removeBone(r.name, r.frame)
            for ((r, _) in mk) removeMorph(r.name, r.frame)
            for ((r, k) in bk) putBone(r.name, r.frame + delta, k.v, k.ip)
            for ((r, k) in mk) putMorph(r.name, r.frame + delta, k.w)
        }
        return ex.size
    }

    fun deleteKeyRefs(refs: Collection<KeyRef>): Int {
        val ex = existing(refs)
        if (ex.isEmpty()) return 0
        val bn = ex.filter { !it.morph }.map { it.name }.toSet()
        val mn = ex.filter { it.morph }.map { it.name }.toSet()
        var c = 0
        edit(bn, mn) {
            for (r in ex) if (if (r.morph) removeMorph(r.name, r.frame) else removeBone(r.name, r.frame)) c++
        }
        return c
    }

    /** Copia as keys [refs] para a área de transferência de keys (posições relativas à menor). Devolve quantas copiou. */
    fun copyKeyRefs(refs: Collection<KeyRef>): Int {
        val ex = existing(refs)
        if (ex.isEmpty()) return 0
        val base = ex.minOf { it.frame }
        val b = HashMap<String, ArrayList<BKey>>(); val m = HashMap<String, ArrayList<MKey>>()
        for (r in ex) {
            if (r.morph) { val l = morphKeys[r.name]!!; m.getOrPut(r.name) { ArrayList() }.add(MKey(r.frame - base, l[idxM(l, r.frame)].w)) }
            else { val l = boneKeys[r.name]!!; val k = l[idxB(l, r.frame)]; b.getOrPut(r.name) { ArrayList() }.add(BKey(r.frame - base, k.v, k.ip)) }
        }
        keyClip = KeyClip(b, m)
        return ex.size
    }

    /**
     * v2.29.0: insere [count] frames vazios em [atFrame] em TODAS as trilhas (ossos, morphs, IK, luz, sombra, visibilidade):
     * as keys em frames >= atFrame deslizam para frente. Um único passo de Desfazer. Retorna o total de keys antes da operação (0 = nada feito).
     */
    fun insertFramesAll(atFrame: Int, count: Int): Int {
        if (atFrame < 0 || count <= 0 || count > 100000) return 0
        val before = keyCount()
        if (before == 0) return 0
        replaceUndoable(MotionFrameOps.insertFrames(motion(), atFrame, count))
        return before
    }

    /**
     * v2.29.0: remove keys redundantes que a interpolação linear entre os vizinhos reproduz dentro da tolerância
     * (posição em unidades do modelo, rotação em graus, morph em peso). Keys com curva Bézier não linear são preservadas.
     * Um único passo de Desfazer. Retorna quantas keys foram removidas.
     */
    fun reduceKeysAll(positionTol: Float, angleTolDeg: Float, morphTol: Float): Int {
        if (keyCount() < 3) return 0
        val r = MotionFrameOps.reduceMotion(motion(), positionTol, angleTolDeg, morphTol)
        if (r.second > 0) replaceUndoable(r.first)
        return r.second
    }

    /**
     * v2.34.0: fecha o loop — copia a key do quadro [from] para o quadro [to] em cada trilha que tenha key em [from]
     * (ossos e morphs), para o último quadro ficar igual ao primeiro. Um passo de Desfazer. Retorna quantas keys foram escritas.
     */
    fun closeLoop(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        if (from < 0 || to <= from) return 0
        val boneNames = bn.distinct().filter { n -> boneKeys[n]?.let { idxB(it, from) >= 0 } == true }
        val morphNames = mn.distinct().filter { n -> morphKeys[n]?.let { idxM(it, from) >= 0 } == true }
        if (boneNames.isEmpty() && morphNames.isEmpty()) return 0
        edit(boneNames, morphNames) {
            for (n in boneNames) {
                val l = boneKeys[n] ?: continue
                val k = l[idxB(l, from)]
                putBone(n, to, k.v.copyOf(), linearIp())
            }
            for (n in morphNames) {
                val l = morphKeys[n] ?: continue
                putMorph(n, to, l[idxM(l, from)].w)
            }
        }
        return boneNames.size + morphNames.size
    }

    // ---------------------------------------------------------------- v2.35.0: bake, curva automática, copiar/colar

    private var clipboard: studio.mmd.mmd.MotionClip? = null
    fun clipboardKeyCount(): Int = clipboard?.keyCount ?: 0

    /** Copia as keys do trecho nas trilhas escolhidas. Retorna quantas keys foram copiadas. */
    fun copyClip(bn: Collection<String>, mn: Collection<String>, from: Int, to: Int): Int {
        if (from < 0 || to < from) return 0
        val c = studio.mmd.mmd.MotionClipboard.copy(motion(), from, to, bn.toSet(), mn.toSet())
        clipboard = if (c.isEmpty) clipboard else c
        return if (c.isEmpty) 0 else c.keyCount
    }

    /** Cola a área de transferência em [at]; [mirror] troca lados e inverte X. Um passo de Desfazer. Retorna as keys escritas. */
    fun pasteClip(at: Int, mirror: Boolean, repeat: Int, merge: Boolean): Int {
        val c = clipboard ?: return 0
        val r = studio.mmd.mmd.MotionClipboard.paste(
            motion(), c, at, if (merge) studio.mmd.mmd.PasteMode.MERGE else studio.mmd.mmd.PasteMode.REPLACE_RANGE,
            mirror, repeat, boneNames.toSet()
        )
        if (r.written > 0) replaceUndoable(r.motion)
        return r.written
    }

    /** Espelha o trecho [from, to] no lugar (esquerda↔direita, X invertido). Um passo de Desfazer. */
    fun mirrorRangeAll(from: Int, to: Int): Int {
        if (from < 0 || to <= from) return 0
        val r = studio.mmd.mmd.MotionClipboard.mirrorRange(motion(), from, to, boneNames.toSet())
        if (r.written > 0) replaceUndoable(r.motion)
        return r.written
    }

    /** Desloca as keys do trecho por [delta] quadros. Um passo de Desfazer. Retorna 1 se algo mudou. */
    fun shiftRangeAll(from: Int, to: Int, delta: Int): Int {
        if (from < 0 || to < from || delta == 0 || keyCount() == 0) return 0
        replaceUndoable(studio.mmd.mmd.MotionClipboard.shiftRange(motion(), from, to, delta))
        return 1
    }

    /** Bake: converte o trecho em keys a cada [step] quadros com curva linear. Retorna a variação no número de keys. */
    fun bakeRangeAll(from: Int, to: Int, step: Int): Int {
        if (from < 0 || to <= from || keyCount() < 2) return 0
        val r = studio.mmd.mmd.MotionBake.bakeMotion(motion(), from, to, step)
        replaceUndoable(r.first)
        return r.second
    }

    /** Curva automática: funde keys densos em segmentos Bézier dentro da tolerância. Retorna quantas keys foram removidas. */
    fun autoCurveAll(positionTol: Float, angleTolDeg: Float): Int {
        val m = motion()
        var removed = 0
        val bones = m.bones.mapValues { val r = studio.mmd.mmd.MotionBake.autoCurve(it.value, positionTol, angleTolDeg); removed += r.removed; r.track }
        if (removed > 0) replaceUndoable(VmdMotion(m.modelName, bones, m.morphs, m.maxFrame, m.warnings, m.extras))
        return removed
    }

    // ---------------------------------------------------------------- v2.36–2.39: pose, vai-e-volta, procedural

    /** Manter pose: grava a pose do quadro [from] também em [to]. Um passo de Desfazer. */
    fun holdPoseAll(from: Int, to: Int): Int {
        if (from < 0 || to < 0 || from == to || keyCount() == 0) return 0
        replaceUndoable(studio.mmd.mmd.PoseTools.hold(motion(), from, to)); return 1
    }

    /** Vai-e-volta: acrescenta o trecho invertido logo após [to]. Um passo de Desfazer. */
    fun pingPongAll(from: Int, to: Int): Int {
        if (from < 0 || to <= from || keyCount() == 0) return 0
        replaceUndoable(studio.mmd.mmd.PoseTools.pingPong(motion(), from, to)); return 1
    }

    /** Piscar automático no morph [morph] entre [from] e [to]. Substitui as keys do morph nesse trecho. */
    fun autoBlinkAll(morph: String, from: Int, to: Int, fps: Int, seed: Int): Int {
        if (morph.isBlank() || to <= from) return 0
        val gen = studio.mmd.mmd.ProceduralMotion.autoBlink(from, to, fps, seed)
        if (gen.frames.isEmpty()) return 0
        val m = motion()
        val old = m.morphs[morph]
        val map = java.util.TreeMap<Int, Float>()
        if (old != null) for (i in 0 until minOf(old.frames.size, old.w.size)) if (old.frames[i] < from || old.frames[i] > to) map[old.frames[i]] = old.w[i]
        for (i in gen.frames.indices) map[gen.frames[i]] = gen.w[i]
        val fr = map.keys.toIntArray()
        val morphs = LinkedHashMap(m.morphs); morphs[morph] = VmdMorphTrack(fr, FloatArray(fr.size) { map.getValue(fr[it]) })
        replaceUndoable(VmdMotion(m.modelName, m.bones, morphs, maxOf(m.maxFrame, to), m.warnings, m.extras))
        return gen.frames.size
    }

    /** Respiração no osso [bone] entre [from] e [to] (ruído senoidal na rotação X). Substitui as keys do osso no trecho. */
    fun breathingAll(bone: String, from: Int, to: Int, fps: Int, amplitudeDeg: Float): Int {
        if (bone.isBlank() || to <= from) return 0
        val gen = studio.mmd.mmd.ProceduralMotion.breathing(from, to, fps, amplitudeDeg)
        if (gen.frames.isEmpty()) return 0
        val m = motion()
        val base = studio.mmd.mmd.MotionClipboard.clearRange(
            VmdMotion(m.modelName, m.bones.filterKeys { it == bone }, emptyMap(), m.maxFrame), from, to
        ).bones[bone]
        val clip = studio.mmd.mmd.MotionClip(to - from + 1, mapOf(bone to List(gen.frames.size) { i ->
            studio.mmd.mmd.ClipBoneKey(gen.frames[i] - from, gen.v.copyOfRange(i * 7, i * 7 + 7), gen.ip.copyOfRange(i * 16, i * 16 + 16))
        }), emptyMap())
        val seed = VmdMotion(m.modelName, if (base != null) mapOf(bone to base) else emptyMap(), emptyMap(), m.maxFrame)
        val merged = studio.mmd.mmd.MotionClipboard.paste(seed, clip, from, studio.mmd.mmd.PasteMode.MERGE).motion
        val bones = LinkedHashMap(m.bones); bones[bone] = merged.bones.getValue(bone)
        replaceUndoable(VmdMotion(m.modelName, bones, m.morphs, maxOf(m.maxFrame, to), m.warnings, m.extras))
        return gen.frames.size
    }

    /** Monta o VmdMotion imutável para o Animator, reconstruindo só as trilhas alteradas. */
    fun motion(): VmdMotion {
        for (n in dirtyB) {
            val l = boneKeys[n]
            if (l == null || l.isEmpty()) { boneCache.remove(n); continue }
            val v = FloatArray(l.size * 7); val ip = ByteArray(l.size * 16)
            for (i in l.indices) { l[i].v.copyInto(v, i * 7); l[i].ip.copyInto(ip, i * 16) }
            boneCache[n] = VmdTrack(IntArray(l.size) { l[it].frame }, v, ip)
        }
        dirtyB.clear()
        for (n in dirtyM) {
            val l = morphKeys[n]
            if (l == null || l.isEmpty()) { morphCache.remove(n); continue }
            morphCache[n] = VmdMorphTrack(IntArray(l.size) { l[it].frame }, FloatArray(l.size) { l[it].w })
        }
        dirtyM.clear()
        var mx = 0
        for (t in boneCache.values) mx = max(mx, t.frames[t.frames.size - 1])
        for (t in morphCache.values) mx = max(mx, t.frames[t.frames.size - 1])
        return VmdMotion("editado", HashMap(boneCache), HashMap(morphCache), mx, extras = vmdExtras)
    }
}
