package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Opções para transferência de pesos por vizinhos mais próximos em espaço local. */
data class WeightTransferOptions(
    val neighbors: Int = 4,
    val maxDistance: Float = Float.POSITIVE_INFINITY,
    val exactDistance: Float = 1e-5f,
    val rootFallbackBone: Int = 0
)

data class WeightTransferReport(
    val model: PmxModel,
    val transferredVertices: Int,
    val fallbackVertices: Int,
    val unmatchedSourceBones: List<String>,
    val averageMatchDistance: Float
)

/**
 * Transfere influências entre duas malhas por k-NN, agregando ossos por nome em vez de índice.
 * Um KD-tree evita a varredura O(alvo × origem); o PMX alvo mantém geometria/materiais/morphs.
 */
object WeightTransfer {
    private data class Node(val index: Int, val axis: Int, val left: Node?, val right: Node?)
    private data class Hit(val index: Int, val distance2: Float)

    fun transfer(source: PmxModel, target: PmxModel, options: WeightTransferOptions = WeightTransferOptions()): WeightTransferReport {
        require(source.vertexCount > 0 && target.vertexCount > 0) { "Os dois modelos precisam ter vértices" }
        require(source.boneIndices.size >= source.vertexCount * 4 && source.boneWeights.size >= source.vertexCount * 4) { "O modelo de origem não contém pesos PMX completos" }
        require(source.bones.isNotEmpty() && target.bones.isNotEmpty()) { "Os modelos precisam possuir ossos" }
        val k = options.neighbors.coerceIn(1, 16)
        val maxDistance2 = if (options.maxDistance.isFinite() && options.maxDistance > 0f) options.maxDistance * options.maxDistance else Float.POSITIVE_INFINITY
        val exact2 = options.exactDistance.takeIf { it.isFinite() && it >= 0f }?.let { it * it } ?: 1e-10f
        val sourceIndices = (0 until source.vertexCount).filter { v ->
            val o=v*3; o+2<source.positions.size && source.positions[o].isFinite() && source.positions[o+1].isFinite() && source.positions[o+2].isFinite()
        }.toIntArray()
        require(sourceIndices.isNotEmpty()) { "A origem não contém posições finitas" }
        fun coordinate(v: Int, axis: Int) = source.positions[v * 3 + axis]
        fun build(ids: List<Int>, depth: Int): Node? {
            if (ids.isEmpty()) return null
            val axis=depth%3
            val sorted=ids.sortedBy { coordinate(it,axis) }
            val mid=sorted.size/2
            return Node(sorted[mid],axis,build(sorted.subList(0,mid),depth+1),build(sorted.subList(mid+1,sorted.size),depth+1))
        }
        val root=build(sourceIndices.toList(),0)
        val sourceToTarget=IntArray(source.bones.size) { -1 }
        val unmatched=LinkedHashSet<String>()
        source.bones.forEachIndexed { i,b ->
            val key=normalizeName(b.name)
            val mapped=if (key.isEmpty()) -1 else target.bones.indexOfFirst { normalizeName(it.name)==key }
            if (mapped >= 0) sourceToTarget[i]=mapped else unmatched += b.name
        }
        val outIndices=IntArray(target.vertexCount*4) { -1 }
        val outWeights=FloatArray(target.vertexCount*4)
        val outTypes=target.weightTypes.copyOf().let { if (it.size == target.vertexCount) it else ByteArray(target.vertexCount) { 0 } }
        var fallback=0; var distanceSum=0.0

        fun search(node: Node?, tx: Float, ty: Float, tz: Float, best: MutableList<Hit>) {
            if (node == null) return
            val o=node.index*3
            val dx=source.positions[o]-tx; val dy=source.positions[o+1]-ty; val dz=source.positions[o+2]-tz
            val d2=dx*dx+dy*dy+dz*dz
            if (d2.isFinite() && d2 <= maxDistance2) {
                best += Hit(node.index,d2)
                best.sortBy { it.distance2 }
                while (best.size>k) best.removeAt(best.lastIndex)
            }
            val delta=when(node.axis) { 0 -> tx-source.positions[o]; 1 -> ty-source.positions[o+1]; else -> tz-source.positions[o+2] }
            val near=if(delta<0f) node.left else node.right
            val far=if(delta<0f) node.right else node.left
            search(near,tx,ty,tz,best)
            val worst=if(best.size<k) Float.POSITIVE_INFINITY else best.last().distance2
            if(delta*delta<=worst || best.size<k) search(far,tx,ty,tz,best)
        }

        for (v in 0 until target.vertexCount) {
            val to=v*3
            if (to+2>=target.positions.size || !target.positions[to].isFinite() || !target.positions[to+1].isFinite() || !target.positions[to+2].isFinite()) {
                assignFallback(v,options.rootFallbackBone,target.bones.size,outIndices,outWeights); outTypes[v] = 0; fallback++; continue
            }
            val hits=ArrayList<Hit>(k)
            search(root,target.positions[to],target.positions[to+1],target.positions[to+2],hits)
            if (hits.isEmpty()) { assignFallback(v,options.rootFallbackBone,target.bones.size,outIndices,outWeights); outTypes[v] = 0; fallback++; continue }
            val nearestDistance = sqrt(hits[0].distance2.toDouble())
            val aggregate=HashMap<Int,Double>()
            val exact=hits.firstOrNull { it.distance2<=exact2 }
            val weightedHits=if(exact!=null) listOf(exact) else hits
            for (hit in weightedHits) {
                val distance=sqrt(hit.distance2.toDouble()).toFloat()
                val factor=if(exact!=null) 1.0 else 1.0/(max(distance,1e-6f).toDouble().pow(2.0))
                val so=hit.index*4
                for (slot in 0..3) {
                    val sb=source.boneIndices.getOrElse(so+slot) { -1 }
                    val sw=source.boneWeights.getOrElse(so+slot) { 0f }
                    val tb=sourceToTarget.getOrElse(sb) { -1 }
                    if (tb >= 0 && sw.isFinite() && sw > 0f) aggregate[tb]=(aggregate[tb] ?: 0.0)+sw.toDouble()*factor
                }
            }
            val chosen=aggregate.entries.filter { it.value.isFinite() && it.value>0.0 }.sortedByDescending { it.value }.take(4)
            val sum=chosen.sumOf { it.value }
            if (sum <= 1e-12) { assignFallback(v,options.rootFallbackBone,target.bones.size,outIndices,outWeights); outTypes[v] = 0; fallback++ }
            else {
                chosen.forEachIndexed { slot,e -> outIndices[v*4+slot]=e.key; outWeights[v*4+slot]=(e.value/sum).toFloat() }
                outTypes[v]=when(chosen.size) { 1 -> 0; 2 -> 1; else -> 2 }
                distanceSum += nearestDistance
            }
        }
        val result=PmxModel(target.name,target.version,target.positions.copyOf(),target.normals.copyOf(),target.uvs.copyOf(),outIndices,outWeights,
            target.indices.copyOf(),target.textures.toList(),target.materials,target.bones,target.morphs,target.rigidBodies,target.joints,
            target.nameEn,target.comment,target.commentEn,target.displayFrames,target.addUvCount,target.addUvs.copyOf(),outTypes,target.sdef?.copyOf(),target.edgeScale.copyOf(),target.textEncoding,target.indexSizes.copyOf(),target.softBodyCount,target.softBodyRaw?.copyOf(),target.warnings.toList())
        return WeightTransferReport(result,target.vertexCount-fallback,fallback,unmatched.toList(),(distanceSum/max(1,target.vertexCount-fallback)).toFloat())
    }

    private fun normalizeName(value: String) = value.trim().lowercase().replace(" ", "").replace("_", "")
    private fun assignFallback(vertex: Int, requested: Int, boneCount: Int, indices: IntArray, weights: FloatArray) {
        val bone=requested.takeIf { it in 0 until boneCount } ?: 0
        indices[vertex*4]=bone; weights[vertex*4]=1f
        for(k in 1..3) { indices[vertex*4+k]=-1; weights[vertex*4+k]=0f }
    }
    private fun Double.pow(exponent: Double): Double = Math.pow(this,exponent)
}
