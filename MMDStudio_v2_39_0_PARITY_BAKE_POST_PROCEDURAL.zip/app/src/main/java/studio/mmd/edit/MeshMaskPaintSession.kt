package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import java.util.PriorityQueue
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

enum class MeshMaskPaintMode { REPLACE, ADD, SUBTRACT }
enum class MeshMaskFalloff { LINEAR, SMOOTH, SHARP, CONSTANT }

data class MeshMaskPaintReport(
    val affectedVertices: Int,
    val changedVertices: Int,
    val minValue: Float,
    val maxValue: Float
)

/**
 * Máscara temporária por vértice, independente do PMX. Suporta strokes contínuos,
 * simetria X, brush espacial acelerado por grade, pintura geodésica sobre a superfície,
 * suavização topológica e histórico Undo/Redo limitado.
 */
class MeshMaskPaintSession(
    val source: PmxModel,
    private val historyLimit: Int = 20,
    private val historyBudgetBytes: Long = 48L * 1024L * 1024L
) {
    private var values = FloatArray(source.vertexCount)
    /** O limite combina número configurado de passos e orçamento de memória para snapshots. */
    private val historyEntryLimit: Int = minOf(
        historyLimit.coerceIn(1, 64),
        (historyBudgetBytes.coerceAtLeast(0L) / (values.size.toLong() * 4L).coerceAtLeast(1L))
            .coerceAtMost(64L).toInt().coerceAtLeast(2)
    )
    private val undo = ArrayList<FloatArray>()
    private val redo = ArrayList<FloatArray>()
    private val topologyAdjacency by lazy(LazyThreadSafetyMode.NONE) { buildAdjacency() }

    val vertexCount: Int get() = values.size
    val canUndo: Boolean get() = undo.isNotEmpty()
    val canRedo: Boolean get() = redo.isNotEmpty()
    val historyEntries: Int get() = undo.size + redo.size
    val historyCapacity: Int get() = historyEntryLimit
    val paintedVertices: Int get() = values.count { it > 1e-4f }
    val meanValue: Float get() = if (values.isEmpty()) 0f else values.average().toFloat()

    private fun pushBounded(stack: ArrayList<FloatArray>, snapshot: FloatArray) {
        while (undo.size + redo.size >= historyEntryLimit) {
            val victim = when {
                stack === undo && undo.isNotEmpty() -> undo
                stack === redo && redo.isNotEmpty() -> redo
                undo.isNotEmpty() -> undo
                redo.isNotEmpty() -> redo
                else -> null
            } ?: break
            victim.removeAt(0)
        }
        stack.add(snapshot)
    }

    private fun checkpoint() {
        // Um novo comando invalida Redo antes de reservar o snapshot do estado anterior.
        redo.clear()
        pushBounded(undo, values.copyOf())
    }

    fun valuesCopy(): FloatArray = values.copyOf()

    fun replace(next: FloatArray): Boolean {
        if (next.size != values.size || next.any { !it.isFinite() }) return false
        checkpoint()
        values = FloatArray(next.size) { next[it].coerceIn(0f, 1f) }
        return true
    }

    fun clear(): Int {
        val changed = values.count { it > 1e-6f }
        if (changed == 0) return 0
        checkpoint(); values.fill(0f)
        return changed
    }

    fun fill(value: Float = 1f): Int {
        val target = value.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        val changed = values.count { abs(it - target) > 1e-6f }
        if (changed == 0) return 0
        checkpoint(); values.fill(target)
        return changed
    }

    fun fillVertices(vertices: IntArray, value: Float = 1f): Int {
        val target = value.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        val valid = vertices.distinct().filter { it in values.indices && abs(values[it] - target) > 1e-6f }
        if (valid.isEmpty()) return 0
        checkpoint(); valid.forEach { values[it] = target }
        return valid.size
    }

    fun invert(): Int {
        if (values.isEmpty()) return 0
        checkpoint(); for (i in values.indices) values[i] = 1f - values[i]
        return values.size
    }

    fun undo(): Boolean {
        if (undo.isEmpty()) return false
        val previous = undo.removeAt(undo.lastIndex)
        pushBounded(redo, values.copyOf())
        values = previous
        return true
    }

    fun redo(): Boolean {
        if (redo.isEmpty()) return false
        val next = redo.removeAt(redo.lastIndex)
        pushBounded(undo, values.copyOf())
        values = next
        return true
    }

    /**
     * Pinta ao longo dos segmentos entre amostras. Quando [surfaceConstrained] está ativo,
     * os valores se propagam pela conectividade dos triângulos e respeitam a distância
     * geodésica, impedindo que o pincel salte diretamente entre superfícies próximas no espaço.
     * Cada chamada válida é uma única operação Undo.
     */
    fun paintStroke(
        points: List<FloatArray>, positions: FloatArray = source.positions,
        radius: Float, strength: Float = 1f, target: Float = 1f,
        mode: MeshMaskPaintMode = MeshMaskPaintMode.REPLACE, mirrorX: Boolean = false,
        surfaceConstrained: Boolean = false, falloff: MeshMaskFalloff = MeshMaskFalloff.SMOOTH
    ): MeshMaskPaintReport {
        require(positions.size == vertexCount * 3) { "Geometria incompatível com a máscara" }
        require(radius.isFinite() && radius > 1e-6f) { "Raio precisa ser positivo" }
        if (surfaceConstrained && vertexCount > 250_000) return report(0)
        val samples = points.filter { it.size >= 3 && it.take(3).all(Float::isFinite) }
        val power = strength.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
        val wanted = target.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
        if (samples.isEmpty() || power <= 0f || vertexCount == 0) return report(0)

        val grid = VertexSpatialGrid(positions, radius.coerceAtLeast(1e-4f))
        var minX = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        for (v in 0 until vertexCount) {
            val x = positions[v * 3]
            if (x.isFinite()) { minX = minOf(minX, x); maxX = maxOf(maxX, x) }
        }
        val mirrorCenter = if (minX.isFinite() && maxX.isFinite()) (minX + maxX) * .5f else 0f
        checkpoint()

        val changed = if (surfaceConstrained) {
            paintGeodesic(samples, positions, grid, radius, power, wanted, mode, mirrorX, mirrorCenter, falloff)
        } else {
            var count = 0
            var previous: FloatArray? = null
            for (point in samples) {
                count += paintSegment(previous, point, positions, grid, radius, power, wanted, mode, falloff)
                if (mirrorX) {
                    val mirrored = floatArrayOf(2f * mirrorCenter - point[0], point[1], point[2])
                    val mirroredPrevious = previous?.let { floatArrayOf(2f * mirrorCenter - it[0], it[1], it[2]) }
                    count += paintSegment(mirroredPrevious, mirrored, positions, grid, radius, power, wanted, mode, falloff)
                }
                previous = point
            }
            count
        }
        return report(changed)
    }

    private fun paintSegment(
        previous: FloatArray?, point: FloatArray, positions: FloatArray, grid: VertexSpatialGrid,
        radius: Float, strength: Float, target: Float, mode: MeshMaskPaintMode,
        falloff: MeshMaskFalloff
    ): Int {
        val a = previous ?: point
        val abx = point[0] - a[0]; val aby = point[1] - a[1]; val abz = point[2] - a[2]
        val den = abx * abx + aby * aby + abz * abz
        val radius2 = radius * radius
        var changed = 0
        for (v in grid.querySegment(a, point, radius)) {
            val o = v * 3
            val px = positions[o]; val py = positions[o + 1]; val pz = positions[o + 2]
            if (!px.isFinite() || !py.isFinite() || !pz.isFinite()) continue
            val apx = px - a[0]; val apy = py - a[1]; val apz = pz - a[2]
            val t = if (den <= 1e-12f) 0f else ((apx * abx + apy * aby + apz * abz) / den).coerceIn(0f, 1f)
            val dx = px - (a[0] + abx * t); val dy = py - (a[1] + aby * t); val dz = pz - (a[2] + abz * t)
            val d2 = dx * dx + dy * dy + dz * dz
            if (d2 > radius2) continue
            val normalized = (1f - sqrt(d2 / radius2)).coerceIn(0f, 1f)
            val amount = (strength * evaluateFalloff(normalized, falloff)).coerceIn(0f, 1f)
            if (applyValue(v, amount, target, mode)) changed++
        }
        return changed
    }

    private fun paintGeodesic(
        samples: List<FloatArray>, positions: FloatArray, grid: VertexSpatialGrid,
        radius: Float, strength: Float, target: Float, mode: MeshMaskPaintMode,
        mirrorX: Boolean, mirrorCenter: Float, falloff: MeshMaskFalloff
    ): Int {
        val adjacency = topologyAdjacency
        if (adjacency.all { it.isEmpty() }) return 0

        // Reamostra pelo comprimento acumulado do traço. O limite reduz a densidade em
        // caminhos extremos, mas preserva início, fim e distribuição ao longo de todo o stroke.
        val dense = densifyPolyline(samples, radius, maxSamples = 16_384)

        val distance = FloatArray(vertexCount) { Float.POSITIVE_INFINITY }
        val queue = PriorityQueue<GeoNode>(compareBy { it.distance })
        fun seed(point: FloatArray) {
            val seed = grid.nearestVertex(point, radius * 1.35f)
            if (seed < 0) return
            val o = seed * 3
            val dx = positions[o] - point[0]; val dy = positions[o + 1] - point[1]; val dz = positions[o + 2] - point[2]
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            if (d <= radius && d < distance[seed]) {
                distance[seed] = d
                queue.add(GeoNode(seed, d))
            }
        }
        for (p in dense) {
            seed(p)
            if (mirrorX) seed(floatArrayOf(2f * mirrorCenter - p[0], p[1], p[2]))
        }
        if (queue.isEmpty()) return 0

        while (queue.isNotEmpty()) {
            val node = queue.remove()
            if (node.distance > distance[node.vertex] + 1e-6f || node.distance > radius) continue
            val a = node.vertex * 3
            for (next in adjacency[node.vertex]) {
                val b = next * 3
                val dx = positions[a] - positions[b]
                val dy = positions[a + 1] - positions[b + 1]
                val dz = positions[a + 2] - positions[b + 2]
                val edge = sqrt(dx * dx + dy * dy + dz * dz)
                if (!edge.isFinite() || edge <= 1e-8f) continue
                val candidate = node.distance + edge
                if (candidate <= radius && candidate + 1e-6f < distance[next]) {
                    distance[next] = candidate
                    queue.add(GeoNode(next, candidate))
                }
            }
        }

        var changed = 0
        for (v in distance.indices) {
            val d = distance[v]
            if (!d.isFinite() || d > radius) continue
            val normalized = (1f - d / radius).coerceIn(0f, 1f)
            val amount = (strength * evaluateFalloff(normalized, falloff)).coerceIn(0f, 1f)
            if (applyValue(v, amount, target, mode)) changed++
        }
        return changed
    }

    private data class GeoNode(val vertex: Int, val distance: Float)

    private fun densifyPolyline(samples: List<FloatArray>, radius: Float, maxSamples: Int): List<FloatArray> {
        if (samples.size <= 1) return samples.map { floatArrayOf(it[0], it[1], it[2]) }
        val cumulative = FloatArray(samples.size)
        for (i in 1 until samples.size) {
            val a = samples[i - 1]; val b = samples[i]
            val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]
            cumulative[i] = cumulative[i - 1] + sqrt(dx * dx + dy * dy + dz * dz)
        }
        val total = cumulative.last()
        if (!total.isFinite() || total <= 1e-8f) return listOf(samples.first().copyOf(3))
        val desiredSpacing = (radius * .32f).coerceAtLeast(.006f)
        val intervals = ceilSteps(total / desiredSpacing).coerceIn(1, (maxSamples - 1).coerceAtLeast(1))
        val result = ArrayList<FloatArray>(intervals + 1)
        var segment = 0
        for (i in 0..intervals) {
            val distance = total * (i.toFloat() / intervals)
            while (segment < samples.lastIndex - 1 && cumulative[segment + 1] < distance) segment++
            val a = samples[segment]; val b = samples[(segment + 1).coerceAtMost(samples.lastIndex)]
            val span = cumulative[(segment + 1).coerceAtMost(samples.lastIndex)] - cumulative[segment]
            val t = if (span <= 1e-8f) 0f else ((distance - cumulative[segment]) / span).coerceIn(0f, 1f)
            result.add(floatArrayOf(
                a[0] + (b[0] - a[0]) * t,
                a[1] + (b[1] - a[1]) * t,
                a[2] + (b[2] - a[2]) * t
            ))
        }
        return result
    }

    private fun ceilSteps(value: Float): Int = kotlin.math.ceil(value.toDouble()).toInt()

    private fun evaluateFalloff(value: Float, falloff: MeshMaskFalloff): Float = when (falloff) {
        MeshMaskFalloff.LINEAR -> value
        MeshMaskFalloff.SMOOTH -> value * value * (3f - 2f * value)
        MeshMaskFalloff.SHARP -> value * value
        MeshMaskFalloff.CONSTANT -> if (value > 0f) 1f else 0f
    }.coerceIn(0f, 1f)

    private fun applyValue(vertex: Int, amount: Float, target: Float, mode: MeshMaskPaintMode): Boolean {
        if (amount <= 0f) return false
        val old = values[vertex]
        val next = when (mode) {
            MeshMaskPaintMode.REPLACE -> old + (target - old) * amount
            MeshMaskPaintMode.ADD -> (old + target * amount).coerceAtMost(1f)
            MeshMaskPaintMode.SUBTRACT -> (old - target * amount).coerceAtLeast(0f)
        }.coerceIn(0f, 1f)
        if (abs(next - old) <= 1e-6f) return false
        values[vertex] = next
        return true
    }

    /** Grade espacial uniforme para limitar o teste de distância aos vértices próximos ao stroke. */
    private class VertexSpatialGrid(private val positions: FloatArray, cellSizeInput: Float) {
        private data class Cell(val x: Int, val y: Int, val z: Int)
        private val count = positions.size / 3
        private val cellSize = cellSizeInput.coerceAtLeast(1e-4f)
        private val cells = HashMap<Cell, MutableList<Int>>()

        init {
            for (v in 0 until count) {
                val o = v * 3
                val x = positions[o]; val y = positions[o + 1]; val z = positions[o + 2]
                if (!x.isFinite() || !y.isFinite() || !z.isFinite()) continue
                val key = cell(x, y, z)
                cells.getOrPut(key) { ArrayList() }.add(v)
            }
        }

        private fun cell(x: Float, y: Float, z: Float) = Cell(
            floor(x / cellSize).toInt(), floor(y / cellSize).toInt(), floor(z / cellSize).toInt()
        )

        fun querySegment(a: FloatArray, b: FloatArray, radius: Float): IntArray {
            val bounds = cellBounds(a, b, radius)
            val nx = bounds[1].toLong() - bounds[0] + 1L
            val ny = bounds[3].toLong() - bounds[2] + 1L
            val nz = bounds[5].toLong() - bounds[4] + 1L
            val volume = if (nx > 0L && ny > 0L && nz > 0L) nx * ny * nz else Long.MAX_VALUE
            if (nx <= 0L || ny <= 0L || nz <= 0L || nx > 8192L || ny > 8192L || nz > 8192L || volume > 8192L) {
                // Um segmento longo diagonal pode ter um AABB gigantesco. Divide a consulta
                // em trechos locais, evitando varrer todos os vértices em cada evento de toque.
                val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]
                val length = sqrt(dx * dx + dy * dy + dz * dz)
                val steps = ceilStepsSafe(length / (cellSize * .5f).coerceAtLeast(1e-4f)).coerceAtLeast(1)
                if (steps > 32_768) return IntArray(count) { it }
                val expansion = radius + length / steps * .51f
                val found = LinkedHashSet<Int>()
                for (i in 0..steps) {
                    val t = i.toFloat() / steps
                    val px = a[0] + dx * t; val py = a[1] + dy * t; val pz = a[2] + dz * t
                    if (!collectBounds(found,
                        px - expansion, px + expansion,
                        py - expansion, py + expansion,
                        pz - expansion, pz + expansion
                    )) return IntArray(count) { it }
                }
                return found.toIntArray()
            }
            return queryBounds(
                minOf(a[0], b[0]) - radius, maxOf(a[0], b[0]) + radius,
                minOf(a[1], b[1]) - radius, maxOf(a[1], b[1]) + radius,
                minOf(a[2], b[2]) - radius, maxOf(a[2], b[2]) + radius
            )
        }

        private fun cellBounds(a: FloatArray, b: FloatArray, radius: Float): IntArray = intArrayOf(
            floor((minOf(a[0], b[0]) - radius) / cellSize).toInt(), floor((maxOf(a[0], b[0]) + radius) / cellSize).toInt(),
            floor((minOf(a[1], b[1]) - radius) / cellSize).toInt(), floor((maxOf(a[1], b[1]) + radius) / cellSize).toInt(),
            floor((minOf(a[2], b[2]) - radius) / cellSize).toInt(), floor((maxOf(a[2], b[2]) + radius) / cellSize).toInt()
        )

        private fun queryBounds(minX: Float, maxX: Float, minY: Float, maxY: Float, minZ: Float, maxZ: Float): IntArray {
            val found = LinkedHashSet<Int>()
            if (!collectBounds(found, minX, maxX, minY, maxY, minZ, maxZ)) return IntArray(count) { it }
            return found.toIntArray()
        }

        /** Acrescenta células no conjunto do chamador, sem criar milhares de sets temporários por stroke longo. */
        private fun collectBounds(
            found: MutableSet<Int>, minX: Float, maxX: Float,
            minY: Float, maxY: Float, minZ: Float, maxZ: Float
        ): Boolean {
            val x0 = floor(minX / cellSize).toInt(); val x1 = floor(maxX / cellSize).toInt()
            val y0 = floor(minY / cellSize).toInt(); val y1 = floor(maxY / cellSize).toInt()
            val z0 = floor(minZ / cellSize).toInt(); val z1 = floor(maxZ / cellSize).toInt()
            val nx = x1.toLong() - x0 + 1L; val ny = y1.toLong() - y0 + 1L; val nz = z1.toLong() - z0 + 1L
            if (nx <= 0L || ny <= 0L || nz <= 0L || nx > 8192L || ny > 8192L || nz > 8192L || nx * ny * nz > 8192L) return false
            for (x in x0..x1) for (y in y0..y1) for (z in z0..z1) cells[Cell(x, y, z)]?.let { found.addAll(it) }
            return true
        }

        private fun ceilStepsSafe(value: Float): Int = if (!value.isFinite()) Int.MAX_VALUE else kotlin.math.ceil(value.toDouble()).toInt().coerceAtLeast(1)

        fun nearestVertex(point: FloatArray, maxDistance: Float): Int {
            val candidates = querySegment(point, point, maxDistance)
            val limit2 = maxDistance * maxDistance
            var best = -1; var best2 = limit2
            for (v in candidates) {
                val o = v * 3
                val dx = positions[o] - point[0]; val dy = positions[o + 1] - point[1]; val dz = positions[o + 2] - point[2]
                val d2 = dx * dx + dy * dy + dz * dz
                if (d2.isFinite() && d2 < best2) { best2 = d2; best = v }
            }
            return best
        }
    }

    /** Suaviza a máscara pela conectividade de triângulos. [keepZero] protege regiões zeradas. */
    fun smooth(iterations: Int = 1, strength: Float = .35f, keepZero: Boolean = false): Int {
        val amount = strength.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
        if (amount <= 0f || values.isEmpty()) return 0
        val adjacency = topologyAdjacency
        if (adjacency.all { it.isEmpty() }) return 0
        checkpoint()
        val original = values.copyOf()
        repeat(iterations.coerceIn(1, 32)) {
            val src = values.copyOf(); val next = src.copyOf()
            for (v in src.indices) {
                val neighbors = adjacency[v]
                if (neighbors.isEmpty() || (keepZero && original[v] <= 1e-6f)) continue
                var sum = 0f; neighbors.forEach { sum += src[it] }
                next[v] = (src[v] + (sum / neighbors.size - src[v]) * amount).coerceIn(0f, 1f)
            }
            values = next
        }
        return values.indices.count { abs(values[it] - original[it]) > 1e-6f }
    }

    fun thresholdVertices(threshold: Float = .5f): IntArray {
        val t = threshold.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: .5f
        return values.indices.filter { values[it] >= t }.toIntArray()
    }

    private fun buildAdjacency(): Array<LinkedHashSet<Int>> {
        val out = Array(vertexCount) { LinkedHashSet<Int>() }
        for (i in source.indices.indices step 3) {
            if (i + 2 >= source.indices.size) break
            val a = source.indices[i]; val b = source.indices[i + 1]; val c = source.indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount) continue
            out[a].add(b); out[a].add(c); out[b].add(a); out[b].add(c); out[c].add(a); out[c].add(b)
        }
        return out
    }

    private fun report(affected: Int): MeshMaskPaintReport = MeshMaskPaintReport(
        affected, values.count { it > 1e-4f }, values.minOrNull() ?: 0f, values.maxOrNull() ?: 0f
    )
}
