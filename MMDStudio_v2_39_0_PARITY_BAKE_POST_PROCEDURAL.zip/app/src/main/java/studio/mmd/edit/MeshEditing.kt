package studio.mmd.edit

import studio.mmd.mmd.PmxMaterial
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxMorph
import kotlin.math.sqrt

/** Edição de faces PMX sem descartar canais, bones, morphs ou corpos rígidos. */
object MeshEditing {
    data class Result(val model: PmxModel, val changedFaces: Int, val message: String, val aborted: Boolean = false)

    /** Remove somente triângulos cujos três vértices estejam selecionados. Mantém vértices órfãos para preservar morphs. */
    fun deleteFacesInsideSelection(model: PmxModel, selectedVertices: IntArray): Result {
        val selected = selectedVertices.toHashSet()
        require(selected.isNotEmpty()) { "Selecione vértices antes de apagar faces" }
        if (model.materials.isEmpty()) {
            val out = ArrayList<Int>(model.indices.size); var removed = 0; var i = 0
            while (i + 2 < model.indices.size) {
                val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                if (a in selected && b in selected && c in selected) removed++ else { out.add(a); out.add(b); out.add(c) }
                i += 3
            }
            while (i < model.indices.size) out.add(model.indices[i++])
            if (removed == 0) return Result(model, 0, "Nenhuma face totalmente contida na seleção")
            return Result(cloneWith(model, out.toIntArray()), removed, "$removed faces removidas; os vértices permanecem para preservar skinning e morphs")
        }
        val out = ArrayList<Int>(model.indices.size)
        val materials = ArrayList<PmxMaterial>(model.materials.size)
        var cursor = 0; var removed = 0
        for (m in model.materials) {
            val start = cursor.coerceAtMost(model.indices.size)
            val end = (cursor + m.indexCount.coerceAtLeast(0)).coerceAtMost(model.indices.size)
            val before = out.size
            var i = start
            while (i + 2 < end) {
                val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                if (a in selected && b in selected && c in selected) removed++
                else { out.add(a); out.add(b); out.add(c) }
                i += 3
            }
            while (i < end) out.add(model.indices[i++])
            val count = out.size - before
            materials.add(copyMaterialWithCount(m, count))
            cursor = end
        }
        while (cursor < model.indices.size) out.add(model.indices[cursor++])
        if (removed == 0) return Result(model, 0, "Nenhuma face totalmente contida na seleção")
        val updated = cloneWith(model, indices = out.toIntArray(), materials = materials)
        return Result(updated, removed, "$removed faces removidas; os vértices permanecem para preservar skinning e morphs")
    }

    /** Inverte winding apenas das faces totalmente contidas na seleção e recalcula normais suavizadas. */
    fun flipFacesInsideSelection(model: PmxModel, selectedVertices: IntArray): Result {
        val selected = selectedVertices.toHashSet()
        require(selected.isNotEmpty()) { "Selecione vértices antes de inverter faces" }
        val indices = model.indices.copyOf(); var changed = 0
        for (i in indices.indices step 3) {
            if (i + 2 >= indices.size) break
            val a = indices[i]; val b = indices[i + 1]; val c = indices[i + 2]
            if (a in selected && b in selected && c in selected) { indices[i + 1] = c; indices[i + 2] = b; changed++ }
        }
        if (changed == 0) return Result(model, 0, "Nenhuma face totalmente contida na seleção")
        val normals = recalculateNormals(model.positions, indices)
        return Result(cloneWith(model, indices = indices, normals = normals), changed, "$changed faces invertidas e normais recalculadas")
    }

    /**
     * Extruda um patch de faces. Mantém as faces originais como base, cria a tampa superior e paredes nas
     * arestas de fronteira. insetAmount desloca a tampa em direção ao centro do patch (0 = sem inset).
     */
    fun extrudeFacesInsideSelection(model: PmxModel, selectedVertices: IntArray, distance: Float, insetAmount: Float = 0f): Result {
        require(distance.isFinite() && insetAmount.isFinite()) { "Parâmetros de extrusão inválidos" }
        require(insetAmount in 0f..0.95f) { "Inset deve ficar entre 0 e 0,95" }
        val selected = selectedVertices.toHashSet()
        require(selected.isNotEmpty()) { "Selecione vértices antes de extrudar faces" }
        if (model.indices.size < 3 || model.vertexCount == 0) return Result(model, 0, "Malha vazia")
        val faceCount = model.indices.size / 3
        val faceMaterial = IntArray(faceCount) { -1 }
        var cursor = 0
        model.materials.forEachIndexed { mi, material ->
            val end = (cursor + material.indexCount.coerceAtLeast(0)).coerceAtMost(model.indices.size)
            for (f in cursor / 3 until minOf(faceCount, end / 3)) faceMaterial[f] = mi
            cursor = end
        }
        val selectedFaces = LinkedHashSet<Int>()
        val selectedVerts = LinkedHashSet<Int>()
        for (f in 0 until faceCount) {
            val o = f * 3; val a = model.indices[o]; val b = model.indices[o + 1]; val c = model.indices[o + 2]
            if (a in 0 until model.vertexCount && b in 0 until model.vertexCount && c in 0 until model.vertexCount && a in selected && b in selected && c in selected) {
                selectedFaces.add(f); selectedVerts.add(a); selectedVerts.add(b); selectedVerts.add(c)
            }
        }
        if (selectedFaces.isEmpty()) return Result(model, 0, "Nenhuma face totalmente contida na seleção")

        data class BoundaryEdge(val a: Int, val b: Int, val material: Int)
        val edgeUses = LinkedHashMap<Long, MutableList<BoundaryEdge>>()
        fun edgeKey(a: Int, b: Int): Long {
            val lo = minOf(a, b); val hi = maxOf(a, b)
            return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
        }
        for (f in selectedFaces) {
            val o = f * 3; val a = model.indices[o]; val b = model.indices[o + 1]; val c = model.indices[o + 2]
            val mat = faceMaterial[f]
            for ((x, y) in arrayOf(a to b, b to c, c to a)) edgeUses.getOrPut(edgeKey(x, y)) { ArrayList() }.add(BoundaryEdge(x, y, mat))
        }
        val boundaries = edgeUses.values.filter { it.size == 1 }.map { it[0] }
        if (boundaries.isEmpty()) return Result(model, 0, "A seleção não tem borda livre; selecione um patch aberto para extrudar")

        val newToOld = ArrayList<Int>(model.vertexCount + selectedVerts.size)
        repeat(model.vertexCount) { newToOld.add(it) }
        val duplicate = HashMap<Int, Int>()
        selectedVerts.forEach { old -> duplicate[old] = newToOld.size; newToOld.add(old) }
        val mapping = newToOld.toIntArray()
        val requiredIndexSize = when { mapping.size <= 256 -> 1; mapping.size <= 65536 -> 2; else -> 4 }
        val rawBlocks = model.morphs.any { it.raw != null } || model.softBodyRaw != null
        val originalIndexSize = model.indexSizes.getOrNull(0)
        if (rawBlocks && requiredIndexSize > (originalIndexSize ?: 0)) {
            return Result(model, 0, "Extrusão cancelada: seria necessário ampliar o índice PMX enquanto há blocos morph/soft-body raw. Nenhuma alteração foi aplicada.", aborted = true)
        }

        val normalsForExtrusion = FloatArray(model.vertexCount * 3)
        for (f in selectedFaces) {
            val o = f * 3; val a = model.indices[o]; val b = model.indices[o + 1]; val c = model.indices[o + 2]
            val ax = model.positions[b * 3] - model.positions[a * 3]; val ay = model.positions[b * 3 + 1] - model.positions[a * 3 + 1]; val az = model.positions[b * 3 + 2] - model.positions[a * 3 + 2]
            val bx = model.positions[c * 3] - model.positions[a * 3]; val by = model.positions[c * 3 + 1] - model.positions[a * 3 + 1]; val bz = model.positions[c * 3 + 2] - model.positions[a * 3 + 2]
            val nx = ay * bz - az * by; val ny = az * bx - ax * bz; val nz = ax * by - ay * bx
            for (v in intArrayOf(a, b, c)) { normalsForExtrusion[v * 3] += nx; normalsForExtrusion[v * 3 + 1] += ny; normalsForExtrusion[v * 3 + 2] += nz }
        }
        val center = FloatArray(3)
        selectedVerts.forEach { v -> for (k in 0..2) center[k] += model.positions[v * 3 + k] }
        for (k in 0..2) center[k] /= selectedVerts.size.toFloat()
        val positions = remapFloat(model.positions, mapping, 3)
        for (old in selectedVerts) {
            val dst = duplicate.getValue(old); val o = old * 3; val d = dst * 3
            var nx = normalsForExtrusion[o]; var ny = normalsForExtrusion[o + 1]; var nz = normalsForExtrusion[o + 2]
            val length = sqrt(nx * nx + ny * ny + nz * nz)
            if (length > 1e-10f) { nx /= length; ny /= length; nz /= length } else { nx = 0f; ny = 1f; nz = 0f }
            positions[d] = model.positions[o] + nx * distance + (center[0] - model.positions[o]) * insetAmount
            positions[d + 1] = model.positions[o + 1] + ny * distance + (center[1] - model.positions[o + 1]) * insetAmount
            positions[d + 2] = model.positions[o + 2] + nz * distance + (center[2] - model.positions[o + 2]) * insetAmount
        }
        val indexOut = ArrayList<Int>(model.indices.size + selectedFaces.size * 3 + boundaries.size * 6)
        val materialOut = ArrayList<PmxMaterial>(model.materials.size)
        fun emitFace(f: Int) {
            val o = f * 3; val a = model.indices[o]; val b = model.indices[o + 1]; val c = model.indices[o + 2]
            indexOut.add(a); indexOut.add(b); indexOut.add(c) // base original
            indexOut.add(duplicate[a] ?: a); indexOut.add(duplicate[b] ?: b); indexOut.add(duplicate[c] ?: c) // extruded cap
        }
        fun emitUnselectedFace(f: Int) { val o = f * 3; indexOut.add(model.indices[o]); indexOut.add(model.indices[o + 1]); indexOut.add(model.indices[o + 2]) }
        fun emitSides(material: Int) {
            for (e in boundaries) if (if (model.materials.isEmpty()) true else e.material == material) {
                val da = duplicate[e.a] ?: continue; val db = duplicate[e.b] ?: continue
                indexOut.add(e.a); indexOut.add(e.b); indexOut.add(db)
                indexOut.add(e.a); indexOut.add(db); indexOut.add(da)
            }
        }
        if (model.materials.isEmpty()) {
            for (f in 0 until faceCount) if (f in selectedFaces) emitFace(f) else emitUnselectedFace(f)
            emitSides(-1)
        } else {
            cursor = 0
            for ((mi, material) in model.materials.withIndex()) {
                val start = cursor.coerceAtMost(model.indices.size); val end = (cursor + material.indexCount.coerceAtLeast(0)).coerceAtMost(model.indices.size)
                for (f in start / 3 until minOf(faceCount, end / 3)) if (f in selectedFaces) emitFace(f) else emitUnselectedFace(f)
                emitSides(mi)
                val count = indexOut.size - materialOut.sumOf { it.indexCount }
                materialOut.add(copyMaterialWithCount(material, count))
                cursor = end
            }
            // Mantém qualquer cauda fora das faixas de material sem reinterpretá-la.
            val known = cursor.coerceAtMost(model.indices.size)
            for (i in known until model.indices.size) indexOut.add(model.indices[i])
        }
        val normals = recalculateNormals(positions, indexOut.toIntArray())
        val morphs = model.morphs.map { morph ->
            if (morph.type != 1 || morph.vertexIdx == null || morph.vertexDelta == null || morph.vertexDelta.size < morph.vertexIdx.size * 3) morph
            else {
                val ids = ArrayList<Int>(); val deltas = ArrayList<Float>()
                for (entry in morph.vertexIdx.indices) {
                    val old = morph.vertexIdx[entry]
                    ids.add(old); for (k in 0..2) deltas.add(morph.vertexDelta[entry * 3 + k])
                    duplicate[old]?.let { ids.add(it); for (k in 0..2) deltas.add(morph.vertexDelta[entry * 3 + k]) }
                }
                PmxMorph(morph.name, morph.nameEn, morph.panel, morph.type, ids.toIntArray(), deltas.toFloatArray(), morph.boneIdx?.copyOf(),
                    morph.boneTrans?.copyOf(), morph.boneRot?.copyOf(), morph.groupIdx?.copyOf(), morph.groupRate?.copyOf(), morph.raw?.copyOf(), ids.size)
            }
        }
        val updatedIndexSizes = model.indexSizes.copyOf()
        if (updatedIndexSizes.isNotEmpty()) updatedIndexSizes[0] = maxOf(updatedIndexSizes[0], requiredIndexSize)
        val warnings = model.warnings.toMutableList()
        if (model.morphs.any { it.type in 3..7 }) warnings.add("Extrusão duplicou vértices; morphs UV PMX (tipos 3–7) em blocos raw não foram expandidos para as novas cópias.")
        if (edgeUses.values.any { it.size > 2 }) warnings.add("O patch contém arestas non-manifold; verifique as paredes geradas nessas regiões.")
        val remapped = PmxModel(model.name, model.version, positions, normals, remapFloat(model.uvs, mapping, 2), remapInt(model.boneIndices, mapping, 4, -1),
            remapFloat(model.boneWeights, mapping, 4), indexOut.toIntArray(), model.textures.toList(), if (model.materials.isEmpty()) emptyList() else materialOut,
            model.bones.toList(), morphs, model.rigidBodies.toList(), model.joints.toList(), model.nameEn, model.comment, model.commentEn, model.displayFrames.toList(),
            model.addUvCount, if (model.addUvCount > 0) remapFloat(model.addUvs, mapping, model.addUvCount * 4) else model.addUvs.copyOf(),
            remapByte(model.weightTypes, mapping), model.sdef?.let { remapFloat(it, mapping, 9) },
            if (model.edgeScale.size >= model.vertexCount) remapFloat(model.edgeScale, mapping, 1) else model.edgeScale.copyOf(),
            model.textEncoding, updatedIndexSizes, model.softBodyCount, model.softBodyRaw?.copyOf(), warnings)
        val addedFaces = selectedFaces.size + boundaries.size * 2
        return Result(remapped, addedFaces, "Extrusão: ${selectedFaces.size} faces superiores e ${boundaries.size * 2} faces laterais; ${selectedVerts.size} vértices duplicados")
    }

    /** Remove apenas triângulos degenerados (índices repetidos ou área quase zero), por material. */
    fun removeDegenerateFaces(model: PmxModel, areaTolerance: Float = 1e-10f): Result {
        require(areaTolerance.isFinite() && areaTolerance >= 0f)
        if (model.materials.isEmpty()) {
            val out = ArrayList<Int>(model.indices.size); var removed = 0; var i = 0
            while (i + 2 < model.indices.size) {
                val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                val valid = a in 0 until model.vertexCount && b in 0 until model.vertexCount && c in 0 until model.vertexCount
                val degenerate = !valid || a == b || b == c || c == a || triangleAreaSquared(model, a, b, c) <= areaTolerance
                if (degenerate) removed++ else { out.add(a); out.add(b); out.add(c) }
                i += 3
            }
            while (i < model.indices.size) out.add(model.indices[i++])
            if (removed == 0) return Result(model, 0, "Nenhum triângulo degenerado encontrado")
            return Result(cloneWith(model, out.toIntArray()), removed, "$removed triângulos degenerados removidos")
        }
        val out = ArrayList<Int>(model.indices.size); val materials = ArrayList<PmxMaterial>(model.materials.size)
        var cursor = 0; var removed = 0
        for (m in model.materials) {
            val start = cursor.coerceAtMost(model.indices.size); val end = (cursor + m.indexCount.coerceAtLeast(0)).coerceAtMost(model.indices.size)
            val before = out.size; var i = start
            while (i + 2 < end) {
                val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                val valid = a in 0 until model.vertexCount && b in 0 until model.vertexCount && c in 0 until model.vertexCount
                val degenerate = !valid || a == b || b == c || c == a || triangleAreaSquared(model, a, b, c) <= areaTolerance
                if (degenerate) removed++ else { out.add(a); out.add(b); out.add(c) }
                i += 3
            }
            while (i < end) out.add(model.indices[i++])
            materials.add(copyMaterialWithCount(m, out.size - before)); cursor = end
        }
        while (cursor < model.indices.size) out.add(model.indices[cursor++])
        if (removed == 0) return Result(model, 0, "Nenhum triângulo degenerado encontrado")
        return Result(cloneWith(model, indices = out.toIntArray(), materials = materials), removed, "$removed triângulos degenerados removidos")
    }

    private fun triangleAreaSquared(m: PmxModel, a: Int, b: Int, c: Int): Float {
        val ax = m.positions[b * 3] - m.positions[a * 3]; val ay = m.positions[b * 3 + 1] - m.positions[a * 3 + 1]; val az = m.positions[b * 3 + 2] - m.positions[a * 3 + 2]
        val bx = m.positions[c * 3] - m.positions[a * 3]; val by = m.positions[c * 3 + 1] - m.positions[a * 3 + 1]; val bz = m.positions[c * 3 + 2] - m.positions[a * 3 + 2]
        val x = ay * bz - az * by; val y = az * bx - ax * bz; val z = ax * by - ay * bx
        return (x * x + y * y + z * z) * .25f
    }

    private fun recalculateNormals(p: FloatArray, ix: IntArray): FloatArray {
        val n = FloatArray(p.size)
        for (i in ix.indices step 3) {
            if (i + 2 >= ix.size) break
            val a = ix[i]; val b = ix[i + 1]; val c = ix[i + 2]
            if (a !in 0 until p.size / 3 || b !in 0 until p.size / 3 || c !in 0 until p.size / 3) continue
            val ax = p[b * 3] - p[a * 3]; val ay = p[b * 3 + 1] - p[a * 3 + 1]; val az = p[b * 3 + 2] - p[a * 3 + 2]
            val bx = p[c * 3] - p[a * 3]; val by = p[c * 3 + 1] - p[a * 3 + 1]; val bz = p[c * 3 + 2] - p[a * 3 + 2]
            val nx = ay * bz - az * by; val ny = az * bx - ax * bz; val nz = ax * by - ay * bx
            for (v in intArrayOf(a, b, c)) { n[v * 3] += nx; n[v * 3 + 1] += ny; n[v * 3 + 2] += nz }
        }
        for (v in 0 until n.size / 3) {
            val o = v * 3; val len = sqrt(n[o] * n[o] + n[o + 1] * n[o + 1] + n[o + 2] * n[o + 2])
            if (len > 1e-10f) { n[o] /= len; n[o + 1] /= len; n[o + 2] /= len } else { n[o] = 0f; n[o + 1] = 1f; n[o + 2] = 0f }
        }
        return n
    }

    private fun remapFloat(source: FloatArray, mapping: IntArray, stride: Int): FloatArray {
        if (source.isEmpty()) return source.copyOf()
        return FloatArray(mapping.size * stride) { i -> source.getOrElse(mapping[i / stride] * stride + i % stride) { 0f } }
    }
    private fun remapInt(source: IntArray, mapping: IntArray, stride: Int, fallback: Int): IntArray {
        if (source.isEmpty()) return source.copyOf()
        return IntArray(mapping.size * stride) { i -> source.getOrElse(mapping[i / stride] * stride + i % stride) { fallback } }
    }
    private fun remapByte(source: ByteArray, mapping: IntArray): ByteArray {
        if (source.isEmpty()) return source.copyOf()
        return ByteArray(mapping.size) { i -> source.getOrElse(mapping[i]) { 0 } }
    }

    private fun copyMaterialWithCount(m: PmxMaterial, count: Int) = PmxMaterial(m.name, m.nameEn, m.diffuse.copyOf(), m.specular.copyOf(), m.specularPower, m.ambient.copyOf(), m.flags,
        m.edgeColor.copyOf(), m.edgeSize, m.textureIndex, m.sphereIndex, m.sphereMode, m.toonShared, m.toonIndex, count, m.memo)

    private fun cloneWith(model: PmxModel, indices: IntArray, materials: List<PmxMaterial> = model.materials, normals: FloatArray = model.normals.copyOf()) = PmxModel(
        model.name, model.version, model.positions.copyOf(), normals, model.uvs.copyOf(), model.boneIndices.copyOf(), model.boneWeights.copyOf(), indices,
        model.textures.toList(), materials, model.bones.toList(), model.morphs.toList(), model.rigidBodies.toList(), model.joints.toList(),
        model.nameEn, model.comment, model.commentEn, model.displayFrames.toList(), model.addUvCount, model.addUvs.copyOf(), model.weightTypes.copyOf(),
        model.sdef?.copyOf(), model.edgeScale.copyOf(), model.textEncoding, model.indexSizes.copyOf(), model.softBodyCount, model.softBodyRaw?.copyOf(), model.warnings.toList()
    )
}
