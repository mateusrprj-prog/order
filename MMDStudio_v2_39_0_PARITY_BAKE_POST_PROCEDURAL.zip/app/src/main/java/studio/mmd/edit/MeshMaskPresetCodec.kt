package studio.mmd.edit

import studio.mmd.mmd.PmxModel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.util.zip.CRC32

/** Formato binário seguro para presets .mmdmask; não grava nem modifica o PMX. */
object MeshMaskPresetCodec {
    private const val MAGIC = 0x4B534D4D // MMSK em little-endian
    private const val VERSION = 1
    private const val MAX_VERTICES = 10_000_000
    private const val MAX_NAME_BYTES = 240
    private const val FIXED_HEADER = 4 + 4 + 4 + 8 + 2
    private const val CRC_BYTES = 4

    data class Preset(val name: String, val values: FloatArray, val topologySignature: Long)

    fun encode(model: PmxModel, values: FloatArray, name: String = model.name.ifBlank { "Máscara" }): ByteArray {
        require(values.size == model.vertexCount) { "A máscara não corresponde ao número de vértices do PMX" }
        require(values.all { it.isFinite() }) { "A máscara contém valores não finitos" }
        require(values.size <= MAX_VERTICES) { "Malha excede o limite do formato" }
        val labelText = truncateUtf8(name.ifBlank { "Máscara" }, MAX_NAME_BYTES)
        val label = labelText.toByteArray(StandardCharsets.UTF_8)
        val payloadSize = Math.addExact(FIXED_HEADER + label.size, Math.multiplyExact(values.size, 4))
        val buffer = ByteBuffer.allocate(payloadSize + CRC_BYTES).order(ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(MAGIC)
        buffer.putInt(VERSION)
        buffer.putInt(values.size)
        buffer.putLong(topologySignature(model))
        buffer.putShort(label.size.toShort())
        buffer.put(label)
        for (v in values) buffer.putFloat(v.coerceIn(0f, 1f))
        val crc = CRC32().apply { update(buffer.array(), 0, payloadSize) }.value.toInt()
        buffer.putInt(crc)
        return buffer.array()
    }

    /** Valida CRC, versão, limites, topologia e comprimento antes de alocar a máscara. */
    fun decode(bytes: ByteArray, model: PmxModel): Preset {
        require(bytes.size >= FIXED_HEADER + CRC_BYTES) { "Arquivo de máscara incompleto" }
        require(bytes.size <= FIXED_HEADER + MAX_NAME_BYTES + MAX_VERTICES * 4L + CRC_BYTES) { "Arquivo de máscara excede o limite" }
        val expectedCrc = ByteBuffer.wrap(bytes, bytes.size - CRC_BYTES, CRC_BYTES).order(ByteOrder.LITTLE_ENDIAN).int
        val actualCrc = CRC32().apply { update(bytes, 0, bytes.size - CRC_BYTES) }.value.toInt()
        require(expectedCrc == actualCrc) { "CRC da máscara inválido: arquivo corrompido" }
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(buffer.int == MAGIC) { "Formato de arquivo não reconhecido" }
        val version = buffer.int
        require(version == VERSION) { "Versão de máscara não suportada: $version" }
        val count = buffer.int
        require(count in 0..MAX_VERTICES) { "Quantidade de vértices inválida" }
        val signature = buffer.long
        val nameLength = buffer.short.toInt() and 0xffff
        require(nameLength <= MAX_NAME_BYTES) { "Nome do preset excede o limite" }
        val expectedSize = FIXED_HEADER.toLong() + nameLength + count.toLong() * 4L + CRC_BYTES
        require(expectedSize == bytes.size.toLong()) { "Tamanho do arquivo não corresponde ao cabeçalho" }
        require(count == model.vertexCount) { "A máscara tem $count vértices; o PMX atual tem ${model.vertexCount}" }
        require(signature == topologySignature(model)) { "A máscara pertence a outra geometria/topologia. Importe o PMX original." }
        val nameBytes = ByteArray(nameLength); buffer.get(nameBytes)
        val name = String(nameBytes, StandardCharsets.UTF_8).ifBlank { "Máscara" }
        val values = FloatArray(count)
        for (i in values.indices) {
            val value = buffer.float
            require(value.isFinite() && value in -1e-5f..1.00001f) { "Valor inválido na máscara, vértice $i" }
            values[i] = value.coerceIn(0f, 1f)
        }
        return Preset(name, values, signature)
    }


    /** Trunca por ponto de código Unicode, nunca no meio de uma sequência UTF-8. */
    private fun truncateUtf8(value: String, maxBytes: Int): String {
        val out = StringBuilder()
        var index = 0
        var bytes = 0
        while (index < value.length) {
            val codePoint = value.codePointAt(index)
            val encodedBytes = when {
                codePoint <= 0x7f -> 1
                codePoint <= 0x7ff -> 2
                codePoint <= 0xffff -> 3
                else -> 4
            }
            if (bytes + encodedBytes > maxBytes) break
            out.appendCodePoint(codePoint)
            bytes += encodedBytes
            index += Character.charCount(codePoint)
        }
        if (out.isNotEmpty()) return out.toString()
        return "Máscara".takeIf { it.toByteArray(StandardCharsets.UTF_8).size <= maxBytes } ?: "Mask"
    }

    /** FNV-1a 64-bit de posição base + índices; não depende de hashCode da JVM. */
    fun topologySignature(model: PmxModel): Long {
        var hash = -0x340d631b7bdddcdbL // offset basis FNV-1a 64
        fun mix(value: Int) {
            for (shift in 0..24 step 8) {
                hash = hash xor ((value ushr shift) and 0xff).toLong()
                hash *= 0x100000001b3L
            }
        }
        mix(model.vertexCount)
        mix(model.indices.size)
        for (i in model.positions.indices) mix(model.positions[i].toRawBits())
        for (index in model.indices) mix(index)
        return hash
    }
}
