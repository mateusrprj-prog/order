package studio.mmd.rig

import kotlin.math.*

data class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(other: Vec3) = Vec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vec3) = Vec3(x - other.x, y - other.y, z - other.z)
    operator fun times(value: Float) = Vec3(x * value, y * value, z * value)
    fun dot(other: Vec3) = x * other.x + y * other.y + z * other.z
    fun cross(other: Vec3) = Vec3(y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x)
    fun length() = sqrt(dot(this))
    fun normalized(fallback: Vec3 = Vec3(0f, 1f, 0f)): Vec3 { val l = length(); return if (l > 1e-8f && l.isFinite()) this * (1f / l) else fallback }
}

data class TwoBoneIkLimits(val minimumBendRadians: Float = 0f, val maximumBendRadians: Float = Math.PI.toFloat())
data class TwoBoneIkResult(
    val middle: Vec3,
    val end: Vec3,
    val requestedTarget: Vec3,
    val clampedTarget: Vec3,
    val rootToTarget: Float,
    val reachError: Float,
    val bendRadians: Float,
    val reachable: Boolean
)

/** Geometria analítica robusta para cotovelo/joelho 2-bones com pole vector e limites de dobra. */
object TwoBoneIkSolver {
    fun solve(
        root: Vec3,
        middleRest: Vec3,
        endRest: Vec3,
        target: Vec3,
        pole: Vec3,
        limits: TwoBoneIkLimits = TwoBoneIkLimits()
    ): TwoBoneIkResult {
        require(listOf(root, middleRest, endRest, target, pole).all { listOf(it.x, it.y, it.z).all(Float::isFinite) }) { "IK contém coordenadas não finitas" }
        val l1 = (middleRest - root).length()
        val l2 = (endRest - middleRest).length()
        require(l1 > 1e-6f && l2 > 1e-6f) { "Os dois segmentos IK precisam ter comprimento positivo" }
        val delta = target - root
        val rawDistance = delta.length()
        val direction = delta.normalized((endRest - root).normalized())
        val minBend = limits.minimumBendRadians.takeIf(Float::isFinite)?.coerceIn(0f, Math.PI.toFloat()) ?: 0f
        val maxBend = limits.maximumBendRadians.takeIf(Float::isFinite)?.coerceIn(minBend, Math.PI.toFloat()) ?: Math.PI.toFloat()
        val requestedBend = Math.PI.toFloat() - acos((((l1 * l1 + l2 * l2 - rawDistance * rawDistance) / (2f * l1 * l2)).coerceIn(-1f, 1f)))
        val bend = requestedBend.coerceIn(minBend, maxBend)
        // Ângulo de dobra zero = perna/cotovelo estendido.
        val interior = Math.PI.toFloat() - bend
        val allowedDistance = sqrt((l1 * l1 + l2 * l2 - 2f * l1 * l2 * cos(interior)).coerceAtLeast(0f))
        val epsilon = min(l1, l2) * 1e-5f + 1e-6f
        val minReach = abs(l1 - l2) + epsilon
        val maxReach = (l1 + l2 - epsilon).coerceAtLeast(minReach)
        val distance = allowedDistance.coerceIn(minReach, maxReach)
        val clamped = root + direction * distance
        val along = ((l1 * l1 + distance * distance - l2 * l2) / (2f * distance)).coerceIn(-l1, l1)
        val height = sqrt((l1 * l1 - along * along).coerceAtLeast(0f))
        var bendAxis = pole - root
        bendAxis = bendAxis - direction * bendAxis.dot(direction)
        if (bendAxis.length() < 1e-6f) {
            val fallback = if (abs(direction.y) < 0.9f) Vec3(0f, 1f, 0f) else Vec3(1f, 0f, 0f)
            bendAxis = fallback - direction * fallback.dot(direction)
        }
        val perpendicular = bendAxis.normalized()
        val mid = root + direction * along + perpendicular * height
        val reachable = rawDistance in minReach..maxReach && abs(requestedBend - bend) < 1e-4f
        return TwoBoneIkResult(mid, clamped, target, clamped, rawDistance, (target - clamped).length(), bend, reachable)
    }
}
