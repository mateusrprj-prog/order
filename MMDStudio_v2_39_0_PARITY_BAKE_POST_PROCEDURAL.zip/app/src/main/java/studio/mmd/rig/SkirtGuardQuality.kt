package studio.mmd.rig

import kotlin.math.abs
import kotlin.math.sqrt

/** Mesh diagnostics and soft region weights for skirt/clothing workflows. Pure JVM; does not mutate source arrays. */
data class SkirtGuardMeshQualityReport(
    val vertexCount: Int,
    val triangleCount: Int,
    val invalidTriangles: Int,
    val degenerateTriangles: Int,
    val minArea: Float,
    val meanArea: Float,
    val maxArea: Float,
    val minEdge: Float,
    val meanEdge: Float,
    val maxEdge: Float,
    val stretchedEdges: Int,
    val collapsedEdges: Int,
    val nonFiniteVertices: Int
) {
    val valid: Boolean get() = invalidTriangles == 0 && nonFiniteVertices == 0
}

/** Independent quality pass; optional reference positions let it estimate edge stretch after simulation. */
object SkirtGuardMeshQuality {
    fun analyze(current: FloatArray, indices: IntArray, reference: FloatArray? = null,
               degenerateAreaThreshold: Float = 1e-8f, stretchThreshold: Float = 2.5f,
               collapseThreshold: Float = 0.25f): SkirtGuardMeshQualityReport {
        val vertexCount = current.size / 3
        require(current.size % 3 == 0) { "Posições precisam estar em XYZ" }
        require(reference == null || reference.size == current.size) { "Referência de posições incompatível" }
        val nonFinite = (0 until vertexCount).count { v ->
            val o = v * 3; !current[o].isFinite() || !current[o + 1].isFinite() || !current[o + 2].isFinite()
        }
        var invalid = 0; var degenerate = 0
        var areaMin = Float.POSITIVE_INFINITY; var areaMax = 0f; var areaSum = 0.0
        var edgesMin = Float.POSITIVE_INFINITY; var edgesMax = 0f; var edgesSum = 0.0; var edgeCount = 0
        var stretched = 0; var collapsed = 0
        fun distance(a: Int, b: Int, p: FloatArray): Float {
            val ao = a * 3; val bo = b * 3
            val dx = p[ao] - p[bo]; val dy = p[ao + 1] - p[bo + 1]; val dz = p[ao + 2] - p[bo + 2]
            return sqrt(dx * dx + dy * dy + dz * dz)
        }
        val edgeSet = HashSet<Long>()
        fun addEdge(a: Int, b: Int) {
            val lo = minOf(a, b); val hi = maxOf(a, b); val key = (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
            if (!edgeSet.add(key)) return
            val len = distance(a, b, current)
            if (!len.isFinite()) return
            edgesMin = minOf(edgesMin, len); edgesMax = maxOf(edgesMax, len); edgesSum += len; edgeCount++
            if (reference != null) {
                val base = distance(a, b, reference)
                if (base > 1e-8f && len / base > stretchThreshold) stretched++
                if (base > 1e-8f && len / base < collapseThreshold) collapsed++
            }
        }
        for (i in indices.indices step 3) {
            if (i + 2 >= indices.size) { invalid++; continue }
            val a = indices[i]; val b = indices[i + 1]; val c = indices[i + 2]
            if (a !in 0 until vertexCount || b !in 0 until vertexCount || c !in 0 until vertexCount ||
                listOf(a, b, c).any { v -> val o = v * 3; !current[o].isFinite() || !current[o + 1].isFinite() || !current[o + 2].isFinite() }) { invalid++; continue }
            val ax = current[a * 3]; val ay = current[a * 3 + 1]; val az = current[a * 3 + 2]
            val ux = current[b * 3] - ax; val uy = current[b * 3 + 1] - ay; val uz = current[b * 3 + 2] - az
            val vx = current[c * 3] - ax; val vy = current[c * 3 + 1] - ay; val vz = current[c * 3 + 2] - az
            val cx = uy * vz - uz * vy; val cy = uz * vx - ux * vz; val cz = ux * vy - uy * vx
            val area = sqrt(cx * cx + cy * cy + cz * cz) * 0.5f
            if (area < degenerateAreaThreshold) degenerate++
            areaMin = minOf(areaMin, area); areaMax = maxOf(areaMax, area); areaSum += area
            addEdge(a, b); addEdge(b, c); addEdge(c, a)
        }
        val triCount = indices.size / 3
        return SkirtGuardMeshQualityReport(vertexCount, triCount, invalid, degenerate,
            if (areaMin.isFinite()) areaMin else 0f, if (triCount > 0) (areaSum / triCount).toFloat() else 0f, areaMax,
            if (edgesMin.isFinite()) edgesMin else 0f, if (edgeCount > 0) (edgesSum / edgeCount).toFloat() else 0f, edgesMax,
            stretched, collapsed, nonFinite)
    }

}


/** Creates deterministic vertex influence weights and optionally diffuses them over mesh adjacency. */
object SkirtGuardRegionWeights {
    fun build(positions: FloatArray, indices: IntArray, region: SkirtCorrectionRegion = SkirtCorrectionRegion.ALL,
             softness: Float = 0.35f, diffusionIterations: Int = 0, diffusion: Float = 0.45f,
             baseMask: FloatArray? = null): FloatArray {
        require(positions.size % 3 == 0) { "Posições precisam estar em XYZ" }
        val n = positions.size / 3
        require(baseMask == null || baseMask.size == n) { "Máscara base incompatível" }
        val finite = (0 until n).filter { v -> val o = v * 3; positions[o].isFinite() && positions[o + 1].isFinite() && positions[o + 2].isFinite() }
        if (finite.isEmpty()) return FloatArray(n)
        var cx = 0f; var cz = 0f
        finite.forEach { v -> cx += positions[v * 3]; cz += positions[v * 3 + 2] }
        cx /= finite.size; cz /= finite.size
        var rx = 1e-5f; var rz = 1e-5f
        finite.forEach { v -> rx = maxOf(rx, abs(positions[v * 3] - cx)); rz = maxOf(rz, abs(positions[v * 3 + 2] - cz)) }
        val soft = softness.takeIf { it.isFinite() }?.coerceIn(0.05f, 1f) ?: 0.35f
        fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        val weights = FloatArray(n)
        for (v in finite) {
            val nx = ((positions[v * 3] - cx) / rx).coerceIn(-1f, 1f)
            val nz = ((positions[v * 3 + 2] - cz) / rz).coerceIn(-1f, 1f)
            weights[v] = when (region) {
                SkirtCorrectionRegion.ALL -> 1f
                SkirtCorrectionRegion.FRONT -> smooth((nz + soft) / (2f * soft))
                SkirtCorrectionRegion.BACK -> smooth((-nz + soft) / (2f * soft))
                SkirtCorrectionRegion.RIGHT -> smooth((nx + soft) / (2f * soft))
                SkirtCorrectionRegion.LEFT -> smooth((-nx + soft) / (2f * soft))
            } * (baseMask?.get(v)?.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f)
        }
        if (diffusionIterations <= 0 || indices.size < 3) return weights
        val adj = Array(n) { HashSet<Int>() }
        for (i in indices.indices step 3) {
            if (i + 2 >= indices.size) break
            val a = indices[i]; val b = indices[i + 1]; val c = indices[i + 2]
            if (a !in 0 until n || b !in 0 until n || c !in 0 until n) continue
            adj[a].add(b); adj[a].add(c); adj[b].add(a); adj[b].add(c); adj[c].add(a); adj[c].add(b)
        }
        val amount = diffusion.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0.45f
        var current = weights
        repeat(diffusionIterations.coerceIn(0, 32)) {
            val next = current.copyOf()
            for (v in 0 until n) if (adj[v].isNotEmpty()) {
                var mean = 0f; adj[v].forEach { mean += current[it] }; mean /= adj[v].size
                next[v] = (current[v] * (1f - amount) + mean * amount).coerceIn(0f, 1f)
            }
            current = next
        }
        if (baseMask != null) for (v in current.indices) {
            val gate = baseMask[v].takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
            current[v] = (current[v] * gate).coerceIn(0f, 1f)
        }
        return current
    }
}
