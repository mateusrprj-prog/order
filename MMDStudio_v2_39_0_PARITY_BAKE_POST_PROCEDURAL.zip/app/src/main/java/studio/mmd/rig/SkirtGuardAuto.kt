package studio.mmd.rig

import studio.mmd.mmd.PmxModel
import java.util.Collections
import java.util.WeakHashMap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Import-time, conservative automatic skirt recognition and collision/rebinding plan. Pure JVM code. */
data class SkirtGuardRegion(val materialIndex: Int, val materialName: String, val confidence: Float, val vertices: IntArray)
data class SkirtGuardColliderHint(val boneIndex: Int, val boneName: String, val role: String, val radius: Float, val start: FloatArray, val end: FloatArray)
data class SkirtGuardCapsule(val ax: Float, val ay: Float, val az: Float, val bx: Float, val by: Float, val bz: Float, val radius: Float)
data class SkirtGuardWeightReconnect(val vertex: Int, val slot: Int, val oldBone: Int, val newBone: Int, val weight: Float)
data class SkirtGuardProfile(
    val detected: Boolean, val confidence: Float, val regions: List<SkirtGuardRegion>,
    val skirtBones: List<Int>, val colliderHints: List<SkirtGuardColliderHint>,
    val reconnectPlan: List<SkirtGuardWeightReconnect>, val notes: List<String>
) {
    /** União dos vértices detectados, calculada uma única vez por perfil para uso no Cloth Studio. */
    val skirtVertexIndices: IntArray by lazy(LazyThreadSafetyMode.PUBLICATION) {
        regions.asSequence().flatMap { it.vertices.asSequence() }.distinct().toList().toIntArray()
    }
    val skirtVertexCount: Int get() = skirtVertexIndices.size
    val readyForClothCollision: Boolean get() = detected && colliderHints.isNotEmpty()
    /** Convert the auto-generated hints into ClothXpbd capsule primitives. Optional current bone origins translate the hints with the pose. */
    fun clothCapsules(currentBoneOrigins: Map<Int, FloatArray> = emptyMap()): List<SkirtGuardCapsule> = colliderHints.mapNotNull { h ->
        val origin = currentBoneOrigins[h.boneIndex]?.takeIf { it.size >= 3 && it.take(3).all(Float::isFinite) }
        val dx = origin?.get(0)?.minus(h.start[0]) ?: 0f
        val dy = origin?.get(1)?.minus(h.start[1]) ?: 0f
        val dz = origin?.get(2)?.minus(h.start[2]) ?: 0f
        SkirtGuardCapsule(h.start[0]+dx, h.start[1]+dy, h.start[2]+dz, h.end[0]+dx, h.end[1]+dy, h.end[2]+dz, h.radius)
    }
}

object SkirtGuardAuto {
    private val cache: MutableMap<PmxModel, SkirtGuardProfile> = Collections.synchronizedMap(WeakHashMap())
    private val skirtTokens = listOf("skirt", "dress", "flare", "petticoat", "frill", "hem", "スカート", "裙", "裾", "ドレス", "フレア", "ワンピ")
    private val thighTokens = listOf("thigh", "upperleg", "upleg", "legupper")
    private val kneeTokens = listOf("knee", "calf", "shin", "lowerleg", "loleg", "leglower", "膝", "ひざ")
    private val pelvisTokens = listOf("pelvis", "hips", "lowerbody", "下半身", "腰")
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun hit(name: String, tokens: List<String>) = tokens.any { token -> name.lowercase().contains(token.lowercase()) || norm(name).contains(norm(token)) }
    fun profile(model: PmxModel): SkirtGuardProfile = cache.getOrPut(model) { detect(model) }
    fun analyze(model: PmxModel): SkirtGuardProfile = detect(model)

    fun detect(model: PmxModel): SkirtGuardProfile {
        val notes = mutableListOf<String>()
        val totalVerts = model.vertexCount
        val materialRanges = mutableListOf<Pair<Int, Int>>() // [startIndex,endExclusive] in index-buffer
        var cursor = 0
        model.materials.forEach { m ->
            val count = m.indexCount.coerceAtLeast(0)
            materialRanges += cursor to min(model.indices.size, cursor + count)
            cursor += count
        }
        val regions = mutableListOf<SkirtGuardRegion>()
        for (mi in model.materials.indices) {
            val m = model.materials[mi]
            val name = (m.name + " " + m.nameEn).trim()
            val (start, end) = materialRanges.getOrElse(mi) { 0 to 0 }
            val tokenHit = hit(name, skirtTokens)
            val verts = if (end > start) model.indices.slice(start until end).filter { it in 0 until totalVerts }.distinct().toIntArray() else IntArray(0)
            val boneEvidence = verts.sumOf { v ->
                val o = v * 4
                (0 until 4).sumOf { s ->
                    val bi = model.boneIndices.getOrNull(o + s) ?: -1
                    val wt = model.boneWeights.getOrNull(o + s) ?: 0f
                    if (bi in model.bones.indices && hit(model.bones[bi].name + " " + model.bones[bi].nameEn, skirtTokens)) wt.toDouble() else 0.0
                }
            }.toFloat() / max(1, verts.size)
            val confidence = when {
                tokenHit && verts.isNotEmpty() -> (0.86f + min(0.12f, boneEvidence * 0.12f)).coerceAtMost(0.98f)
                boneEvidence >= 0.30f && verts.size >= 20 -> 0.68f
                tokenHit -> 0.55f
                else -> 0f
            }
            if (confidence >= 0.5f && verts.isNotEmpty()) regions += SkirtGuardRegion(mi, name, confidence, verts)
        }
        val skirtBoneIndices = model.bones.indices.filter { hit(model.bones[it].name + " " + model.bones[it].nameEn, skirtTokens) }
        if (regions.isEmpty()) notes += "Saia não detectada com confiança suficiente; perfil automático não altera pesos."
        else notes += "${regions.size} material(is) candidato(s) de saia detectado(s); pesos originais preservados."
        val colliderHints = mutableListOf<SkirtGuardColliderHint>()
        for (bi in model.bones.indices) {
            val b = model.bones[bi]; val name = b.name + " " + b.nameEn
            val jpCore = b.name.trim().let { n -> if (n.startsWith("左") || n.startsWith("右")) n.drop(1) else n }
            val excluded = hit(name, listOf("twist", "捩", "ik"))
            val role = when {
                !excluded && (hit(name, thighTokens) || jpCore == "足") -> "thigh"
                !excluded && (hit(name, kneeTokens) || jpCore == "膝" || jpCore == "ひざ") -> "knee-lowerleg"
                else -> ""
            }
            if (role.isEmpty()) continue
            val parent = b.parent.takeIf { it in model.bones.indices }?.let { model.bones[it] }
            val end = if (b.tailBone in model.bones.indices) model.bones[b.tailBone].let { floatArrayOf(it.x,it.y,it.z) }
                else if (b.tailOffset != null && b.tailOffset.size >= 3) floatArrayOf(b.x+b.tailOffset[0],b.y+b.tailOffset[1],b.z+b.tailOffset[2])
                else parent?.let { floatArrayOf(it.x,it.y,it.z) } ?: floatArrayOf(b.x,b.y+0.08f,b.z)
            val length = distance(floatArrayOf(b.x,b.y,b.z),end).coerceAtLeast(0.04f)
            val radius = (measureRadius(model, bi, b.x,b.y,b.z,end).takeIf { it.isFinite() } ?: length*0.16f).coerceIn(0.025f, length*0.45f)
            colliderHints += SkirtGuardColliderHint(bi, b.name.ifBlank { b.nameEn }, role, radius, floatArrayOf(b.x,b.y,b.z), end)
        }
        if (colliderHints.isEmpty()) notes += "Sem nomes de ossos de coxa/joelho reconhecidos para colisor automático."
        else notes += "${colliderHints.size} hints de colisores de coxa/joelho disponíveis para ligar à simulação."
        val confidence = regions.maxOfOrNull { it.confidence } ?: 0f
        return SkirtGuardProfile(regions.isNotEmpty(), confidence, regions, skirtBoneIndices, colliderHints, emptyList(), notes)
    }

    private fun measureRadius(model: PmxModel, bone: Int, bx: Float, by: Float, bz: Float, end: FloatArray): Float {
        var maxD = 0f; var found = 0
        for (v in 0 until model.vertexCount) {
            val o = v*4; var weight = 0f
            for (s in 0..3) if (model.boneIndices.getOrNull(o+s) == bone) weight += model.boneWeights.getOrNull(o+s) ?: 0f
            if (weight < 0.25f) continue
            val p = v*3; val x=model.positions[p]; val y=model.positions[p+1]; val z=model.positions[p+2]
            val dx=end[0]-bx; val dy=end[1]-by; val dz=end[2]-bz; val l2=dx*dx+dy*dy+dz*dz
            val t=if(l2>1e-8f) (((x-bx)*dx+(y-by)*dy+(z-bz)*dz)/l2).coerceIn(0f,1f) else 0f
            val qx=bx+dx*t; val qy=by+dy*t; val qz=bz+dz*t
            maxD=max(maxD,sqrt((x-qx)*(x-qx)+(y-qy)*(y-qy)+(z-qz)*(z-qz))); found++
        }
        return if(found>=3 && maxD>0f) maxD*1.05f else 0f
    }
    private fun distance(a:FloatArray,b:FloatArray)=sqrt((a[0]-b[0])*(a[0]-b[0])+(a[1]-b[1])*(a[1]-b[1])+(a[2]-b[2])*(a[2]-b[2]))
}
