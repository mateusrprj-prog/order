package studio.mmd.rig

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.PmxModel

/** Bake de tecido independente da GPU, com um snapshot XYZ por vértice e por quadro. */
data class ClothBakeCache(
    val vertexCount: Int, val fps: Int, val frames: List<FloatArray>,
    val modelHash: Long = 0L,
    /** Assinatura dos parâmetros/seleção do solver. */
    val simulationHash: Long = 0L,
    /** Assinatura das curvas de osso/morph/IK da animação usada no bake. */
    val motionHash: Long = 0L,
    /** Versão semântica do algoritmo das assinaturas (4 = FNV-1a 64-bit). */
    val signatureVersion: Int = 4
) {
    init {
        require(vertexCount >= 0)
        require(fps in 1..240)
        require(signatureVersion in 1..4)
        require(frames.all { it.size == vertexCount * 3 })
    }
}

/** Codec binário versionado para caches XPBD. Rejeita tamanhos inconsistentes, NaN/Inf e CRC inválido. */
object ClothCacheCodec {
    private val magic = byteArrayOf(77, 77, 68, 67, 76, 84, 72, 49) // MMDCLTH1
    private const val HEADER_V1 = 8 + 4 * 4 + 8
    private const val HEADER_V2 = HEADER_V1 + 8
    private const val HEADER_V3 = HEADER_V2 + 16
    // v4 mantém a estrutura binária v3; muda o algoritmo/semântica das assinaturas para 64 bits.
    private const val FORMAT_VERSION = 4
    private const val MAX_BYTES = 512L * 1024 * 1024
    private const val MAX_VERTICES = 2_000_000
    private const val MAX_FRAMES = 100_000

    /** Hash FNV-1a de 64 bits com serialização tipada e endian explícito para assinaturas de assets. */
    private class Signature64 {
        private var state = -3750763034362895579L
        fun byte(value: Int) { state = (state xor (value.toLong() and 0xffL)) * 1099511628211L }
        fun int(value: Int) { byte(value); byte(value ushr 8); byte(value ushr 16); byte(value ushr 24) }
        fun long(value: Long) { int(value.toInt()); int((value ushr 32).toInt()) }
        fun text(value: String) { val bytes = value.toByteArray(Charsets.UTF_8); int(bytes.size); bytes.forEach { byte(it.toInt()) } }
        fun bytes(value: ByteArray?) { if (value == null) { int(-1); return }; int(value.size); value.forEach { byte(it.toInt()) } }
        fun floats(value: FloatArray?) { if (value == null) { int(-1); return }; int(value.size); value.forEach { int(it.toRawBits()) } }
        fun ints(value: IntArray?) { if (value == null) { int(-1); return }; int(value.size); value.forEach(::int) }
        fun result(): Long = state
    }

    fun encode(cache: ClothBakeCache): ByteArray {
        require(cache.vertexCount <= MAX_VERTICES && cache.frames.size <= MAX_FRAMES) { "Bake de tecido excede os limites do cache" }
        val floatCount = cache.vertexCount.toLong() * 3L * cache.frames.size.toLong()
        val payloadBytes = floatCount * 4L
        val total = HEADER_V3.toLong() + payloadBytes + 4L
        require(total <= MAX_BYTES && total <= Int.MAX_VALUE) { "Cache de tecido grande demais" }
        require(cache.signatureVersion == FORMAT_VERSION) { "Caches legados precisam ser recalculados antes de gravar no formato atual" }
        val out = ByteBuffer.allocate(total.toInt()).order(ByteOrder.LITTLE_ENDIAN)
        out.put(magic); out.putInt(FORMAT_VERSION); out.putInt(cache.vertexCount); out.putInt(cache.fps); out.putInt(cache.frames.size); out.putLong(payloadBytes); out.putLong(cache.modelHash); out.putLong(cache.simulationHash); out.putLong(cache.motionHash)
        for (frame in cache.frames) for (v in frame) {
            require(v.isFinite()) { "Cache contém posição não finita" }
            out.putFloat(v)
        }
        val crc = CRC32(); crc.update(out.array(), 0, out.position())
        out.putInt(crc.value.toInt())
        return out.array()
    }

    fun decode(bytes: ByteArray): ClothBakeCache {
        require(bytes.size >= HEADER_V1 + 4 && bytes.size.toLong() <= MAX_BYTES) { "Cache de tecido truncado ou grande demais" }
        val input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val got = ByteArray(magic.size); input.get(got)
        require(got.contentEquals(magic)) { "Assinatura de cache XPBD inválida" }
        val version = input.int
        require(version in 1..FORMAT_VERSION) { "Versão de cache XPBD não suportada: $version" }
        val vertices = input.int; val fps = input.int; val count = input.int; val payload = input.long
        val modelHash = if (version >= 2) input.long else 0L
        val simulationHash = if (version >= 3) input.long else 0L
        val motionHash = if (version >= 3) input.long else 0L
        val header = when (version) { 1 -> HEADER_V1; 2 -> HEADER_V2; else -> HEADER_V3 }
        require(vertices in 0..MAX_VERTICES && fps in 1..240 && count in 0..MAX_FRAMES) { "Metadados de cache XPBD inválidos" }
        val expected = vertices.toLong() * 3L * count.toLong() * 4L
        require(payload == expected && header.toLong() + payload + 4L == bytes.size.toLong()) { "Tamanho interno do cache XPBD inconsistente" }
        val crc = CRC32(); crc.update(bytes, 0, bytes.size - 4)
        val stored = ByteBuffer.wrap(bytes, bytes.size - 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        require(stored == crc.value.toInt()) { "CRC do cache XPBD não confere" }
        val frames = ArrayList<FloatArray>(count)
        repeat(count) {
            val frame = FloatArray(vertices * 3)
            for (i in frame.indices) {
                val v = input.float
                require(v.isFinite()) { "Cache contém posição não finita" }
                frame[i] = v
            }
            frames.add(frame)
        }
        return ClothBakeCache(vertices, fps, frames, modelHash, simulationHash, motionHash, version)
    }

    /** Assinatura estável da geometria PMX usada para invalidar bakes de outro modelo/topologia. */
    fun modelSignature(positions: FloatArray, indices: IntArray): Long {
        val hash = Signature64()
        hash.text("pmx-geometry-v2")
        hash.floats(positions)
        hash.ints(indices)
        return hash.result()
    }

    /** Assinatura completa dos dados PMX que podem alterar a simulação/skin/cache. */
    fun modelSignature(model: PmxModel): Long {
        val hash = Signature64()
        hash.text("pmx-model-v2")
        hash.text(model.name); hash.text(model.nameEn); hash.text(model.comment); hash.text(model.commentEn)
        hash.int(model.version.toRawBits()); hash.floats(model.positions); hash.ints(model.indices)
        hash.int(model.textures.size); model.textures.forEach(hash::text)
        hash.ints(model.boneIndices); hash.floats(model.boneWeights); hash.bytes(model.weightTypes); hash.floats(model.sdef)
        hash.floats(model.addUvs); hash.int(model.addUvCount); hash.floats(model.edgeScale)
        hash.int(model.bones.size)
        model.bones.forEach { bone ->
            hash.text(bone.name); hash.text(bone.nameEn); hash.floats(floatArrayOf(bone.x, bone.y, bone.z, bone.inheritWeight))
            hash.int(bone.parent); hash.int(bone.layer); hash.int(bone.flags); hash.int(bone.tailBone); hash.int(bone.inheritParent); hash.int(bone.externalKey)
            hash.floats(bone.tailOffset); hash.floats(bone.fixedAxis); hash.floats(bone.localAxisX); hash.floats(bone.localAxisZ)
            bone.ik?.let { ik ->
                hash.int(1); hash.int(ik.target); hash.int(ik.loopCount); hash.int(ik.limitAngle.toRawBits()); hash.int(ik.links.size)
                ik.links.forEach { link -> hash.int(link.bone); hash.int(if (link.hasLimit) 1 else 0); hash.floats(link.min); hash.floats(link.max) }
            } ?: hash.int(0)
        }
        hash.int(model.materials.size); model.materials.forEach {
            hash.text(it.name); hash.text(it.nameEn); hash.int(it.indexCount); hash.int(it.textureIndex)
            hash.int(it.sphereIndex); hash.int(it.sphereMode); hash.int(it.flags); hash.int(if (it.toonShared) 1 else 0)
            hash.int(it.toonIndex); hash.text(it.memo)
        }
        hash.int(model.morphs.size); model.morphs.forEach { morph ->
            hash.text(morph.name); hash.text(morph.nameEn); hash.int(morph.panel); hash.int(morph.type); hash.int(morph.count)
            hash.ints(morph.vertexIdx); hash.floats(morph.vertexDelta); hash.ints(morph.boneIdx); hash.floats(morph.boneTrans); hash.floats(morph.boneRot)
            hash.ints(morph.groupIdx); hash.floats(morph.groupRate); hash.bytes(morph.raw)
        }
        hash.int(model.rigidBodies.size); model.rigidBodies.forEach { body ->
            hash.text(body.name); hash.text(body.nameEn); hash.int(body.bone); hash.int(body.group); hash.int(body.shape); hash.int(body.mode); hash.int(body.mask)
            hash.floats(floatArrayOf(body.mass, body.linearDamping, body.angularDamping, body.restitution, body.friction))
            hash.floats(body.size); hash.floats(body.pos); hash.floats(body.rot)
        }
        hash.int(model.joints.size); model.joints.forEach { joint ->
            hash.text(joint.name); hash.text(joint.nameEn); hash.int(joint.type); hash.int(joint.a); hash.int(joint.b)
            hash.floats(joint.pos); hash.floats(joint.rot); hash.floats(joint.posMin); hash.floats(joint.posMax)
            hash.floats(joint.rotMin); hash.floats(joint.rotMax); hash.floats(joint.springPos); hash.floats(joint.springRot)
        }
        hash.int(model.softBodyCount); hash.bytes(model.softBodyRaw)
        return hash.result()
    }

    /** Assinatura estável das curvas de osso, morph e IK do VMD. */
    fun motionSignature(motion: VmdMotion?): Long {
        if (motion == null) return Signature64().also { it.text("no-vmd") }.result()
        val hash = Signature64()
        hash.text("vmd-character-motion-v2")
        hash.text(motion.modelName); hash.int(motion.maxFrame)
        hash.int(motion.bones.size)
        for ((name, track) in motion.bones.toSortedMap()) {
            hash.text(name); hash.ints(track.frames); hash.floats(track.v); hash.bytes(track.ip)
        }
        hash.int(motion.morphs.size)
        for ((name, track) in motion.morphs.toSortedMap()) {
            hash.text(name); hash.ints(track.frames); hash.floats(track.w)
        }
        hash.int(motion.extras.ik.size)
        for ((name, track) in motion.extras.ik.toSortedMap()) {
            hash.text(name); hash.ints(track.frames); hash.int(track.on.size); track.on.forEach { hash.byte(if (it) 1 else 0) }
        }
        return hash.result()
    }

    /** Assinatura determinística e tipada dos controles que alteram o resultado do bake. */
    fun simulationSignature(vararg values: Any?): Long {
        val hash = Signature64()
        hash.text("cloth-simulation-settings-v2")
        values.forEach { value ->
            when (value) {
                null -> { hash.byte(0); hash.text("null") }
                is Boolean -> { hash.byte(1); hash.byte(if (value) 1 else 0) }
                is Int -> { hash.byte(2); hash.int(value) }
                is Long -> { hash.byte(3); hash.long(value) }
                is Float -> { hash.byte(4); hash.int(value.toRawBits()) }
                is Double -> { hash.byte(5); hash.long(value.toRawBits()) }
                is String -> { hash.byte(6); hash.text(value) }
                else -> { hash.byte(7); hash.text(value.toString()) }
            }
        }
        return hash.result()
    }

    fun isCompatible(
        cache: ClothBakeCache?, vertexCount: Int, fps: Int, modelHash: Long,
        simulationHash: Long, motionHash: Long
    ): Boolean = cache != null && cache.signatureVersion == FORMAT_VERSION &&
        cache.vertexCount == vertexCount && cache.fps == fps && cache.modelHash == modelHash &&
        cache.simulationHash == simulationHash && cache.motionHash == motionHash

    /**
     * Substitui um intervalo de frames preservando as partes não editadas de um cache compatível.
     * Um intervalo iniciado depois de zero exige cache anterior válido; assim não são inventados frames
     * anteriores com pose de repouso. O chamador pode simular do frame 0 para aquecer o XPBD e entregar
     * apenas os snapshots do trecho solicitado.
     */
    fun mergeFrameRange(
        existing: ClothBakeCache?, startFrame: Int, replacements: List<FloatArray>,
        vertexCount: Int, fps: Int, modelHash: Long, fallbackFrame: FloatArray,
        simulationHash: Long = 0L, motionHash: Long = 0L
    ): ClothBakeCache {
        require(startFrame >= 0) { "Quadro inicial não pode ser negativo" }
        require(replacements.isNotEmpty()) { "O intervalo novo não contém quadros" }
        require(vertexCount >= 0 && fallbackFrame.size == vertexCount * 3) { "Frame-base incompatível com a malha" }
        require(fps in 1..240)
        val compatible = existing?.takeIf {
            it.signatureVersion == FORMAT_VERSION && it.vertexCount == vertexCount && it.fps == fps &&
                it.modelHash == modelHash && it.simulationHash == simulationHash && it.motionHash == motionHash
        }
        require(startFrame == 0 || compatible != null) {
            "Bake parcial exige um cache anterior compatível; gere primeiro a sequência desde o quadro 0"
        }
        require(startFrame == 0 || startFrame <= (compatible?.frames?.size ?: 0)) {
            "O quadro inicial não pode pular uma lacuna no cache existente"
        }
        replacements.forEachIndexed { index, frame ->
            require(frame.size == vertexCount * 3) { "Frame ${startFrame + index} tem tamanho incompatível" }
            require(frame.all(Float::isFinite)) { "Frame ${startFrame + index} contém coordenadas inválidas" }
        }
        val endExclusive = Math.addExact(startFrame, replacements.size)
        val total = maxOf(compatible?.frames?.size ?: 0, endExclusive)
        val frames = ArrayList<FloatArray>(total)
        for (frameIndex in 0 until total) {
            val replaced = frameIndex - startFrame
            val frame = when {
                replaced in replacements.indices -> replacements[replaced].copyOf()
                frameIndex < (compatible?.frames?.size ?: 0) -> compatible!!.frames[frameIndex].copyOf()
                else -> fallbackFrame.copyOf()
            }
            frames += frame
        }
        return ClothBakeCache(vertexCount, fps, frames, modelHash, simulationHash, motionHash)
    }

    /** Escreve via temporário + fsync + backup para sobreviver a encerramento abrupto. */
    fun writeAtomic(file: File, cache: ClothBakeCache) {
        val bytes = encode(cache)
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        val bak = File(file.parentFile, file.name + ".bak")
        FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
        if (file.exists()) try { file.copyTo(bak, overwrite = true) } catch (_: Exception) { /* conserva o principal */ }
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }

    fun readWithBackup(file: File): ClothBakeCache {
        fun readChecked(target: File): ClothBakeCache {
            require(target.length() <= MAX_BYTES) { "Cache de tecido grande demais" }
            return decode(target.readBytes())
        }
        try { return readChecked(file) } catch (primary: Exception) {
            val backup = File(file.parentFile, file.name + ".bak")
            if (!backup.exists()) throw primary
            return try { readChecked(backup) } catch (secondary: Exception) {
                throw IllegalArgumentException("Cache principal e backup estão inválidos: ${primary.message}; ${secondary.message}", secondary)
            }
        }
    }
}
