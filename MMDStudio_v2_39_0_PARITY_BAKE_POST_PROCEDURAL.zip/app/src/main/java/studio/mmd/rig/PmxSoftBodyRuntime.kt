package studio.mmd.rig

import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxSoftBody
import kotlin.math.max

/**
 * Runtime experimental de soft bodies PMX 2.1 sobre o solver XPBD do MMD Studio.
 * Constrói partículas a partir das faces do material PMX e mantém o mapa de volta
 * para os índices globais do modelo. NÃO é Bullet SoftBody nem garante equivalência MMD.
 */
data class PmxSoftBodyRuntimeConfig(
    val maxVertices: Int = 12_000,
    val enableSelfCollision: Boolean = true,
    val maxDisplacementPerStep: Float = 8f,
    val maxSpeed: Float = 500f,
    val maxAbsoluteCoordinate: Float = 100_000f,
    val groundY: Float? = null
)

data class PmxSoftBodyRuntimeStats(
    val sourceIndex: Int,
    val name: String,
    val shape: Int,
    val material: Int,
    val particles: Int,
    val triangles: Int,
    val stretchConstraints: Int,
    val bendConstraints: Int,
    val pins: Int,
    val anchors: Int,
    val warnings: List<String>
)

class PmxSoftBodyRuntime private constructor(
    private val solver: ClothXpbd,
    val sourceVertices: IntArray,
    val localTriangles: IntArray,
    private val anchorMap: List<AnchorBinding>,
    private val softBody: PmxSoftBody,
    val stats: PmxSoftBodyRuntimeStats,
    private val config: PmxSoftBodyRuntimeConfig
) {
    private data class AnchorBinding(val rigidBody: Int, val localVertex: Int, val offset: FloatArray, val nearMode: Boolean)

    private val lastPositions = FloatArray(sourceVertices.size * 3)
    var lastSafetyReport: ClothStepSafetyReport? = null
        private set

    val particleCount: Int get() = sourceVertices.size

    /** Atualiza alvos de anchors em coordenadas PMX. Vértices sem alvo conservam o último alvo. */
    fun updateAnchorTargets(rigidBodyPositions: Map<Int, FloatArray>) {
        for (a in anchorMap) {
            val target = rigidBodyPositions[a.rigidBody] ?: continue
            if (target.size < 3 || !target.take(3).all { it.isFinite() }) continue
            // Offset de repouso preserva a relação espacial entre âncora e corpo rígido.
            solver.movePin(a.localVertex, target[0] + a.offset[0], target[1] + a.offset[1], target[2] + a.offset[2])
        }
    }

    /** Colisores devem estar no mesmo espaço local PMX das partículas. */
    fun setColliders(
        spheres: List<ClothSphere> = emptyList(),
        capsules: List<ClothCapsule> = emptyList(),
        boxes: List<ClothBox> = emptyList(),
        triangles: List<ClothTriangleCollider> = emptyList()
    ) {
        solver.setColliders(spheres, capsules, boxes, triangles,
            thickness = softBody.collisionMargin.takeIf { it.isFinite() && it > 0f }?.coerceIn(0.001f, 0.25f) ?: 0.015f)
    }

    /** Executa um passo protegido e devolve posições locais (3 floats por partícula). */
    fun step(
        deltaSeconds: Float,
        gravityY: Float = -9.81f,
        windX: Float = 0f,
        windY: Float = 0f,
        windZ: Float = 0f,
        substeps: Int? = null,
        iterations: Int? = null
    ): FloatArray {
        val cfg = softBody.config
        val damping = cfg.getOrElse(1) { 0.025f }.takeIf { it.isFinite() }?.coerceIn(0f, 0.95f) ?: 0.025f
        val drag = cfg.getOrElse(2) { 0f }.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f
        val lift = cfg.getOrElse(3) { 0f }.takeIf { it.isFinite() }?.coerceIn(-2f, 2f) ?: 0f
        val aero = when (softBody.aeroModel.coerceIn(0, 4)) {
            0 -> 0.35f   // V_Point: força por partícula, aproximada
            1, 3 -> 1f   // modelos two-sided
            else -> 0.65f
        }
        val safeWindX = (windX * (1f + drag) * aero).takeIf { it.isFinite() } ?: 0f
        val safeWindY = (windY + lift * absGravity(gravityY)) .takeIf { it.isFinite() } ?: 0f
        val safeWindZ = (windZ * (1f + drag) * aero).takeIf { it.isFinite() } ?: 0f
        val pIt = softBody.iterations.getOrElse(1) { 8 }.coerceIn(1, 32)
        val vIt = softBody.iterations.getOrElse(0) { 4 }.coerceIn(1, 16)
        val result = solver.stepGuarded(
            deltaSeconds = deltaSeconds,
            gravityY = gravityY,
            windX = safeWindX,
            windY = safeWindY,
            windZ = safeWindZ,
            substeps = (substeps ?: vIt).coerceIn(1, 16),
            iterations = (iterations ?: pIt).coerceIn(1, 32),
            damping = damping,
            groundY = config.groundY,
            selfCollision = config.enableSelfCollision && particleCount <= 2048,
            safety = ClothStepSafetyConfig(
                maxDisplacementPerStep = config.maxDisplacementPerStep,
                maxSpeed = config.maxSpeed,
                maxAbsoluteCoordinate = config.maxAbsoluteCoordinate
            )
        )
        lastSafetyReport = result.report
        result.positions.copyInto(lastPositions, endIndex = minOf(lastPositions.size, result.positions.size))
        return lastPositions.copyOf()
    }

    /** Aplica o último resultado ao array de posições global PMX, sem alterar os vértices fora do soft body. */
    fun scatterInto(globalPositions: FloatArray, simulated: FloatArray = lastPositions) {
        require(globalPositions.size % 3 == 0) { "Array global deve conter XYZ por vértice" }
        require(simulated.size >= sourceVertices.size * 3) { "Snapshot de soft body incompleto" }
        for (i in sourceVertices.indices) {
            val src = sourceVertices[i]
            require(src in 0 until globalPositions.size / 3) { "Mapa de vértices PMX inválido" }
            val a = i * 3; val b = src * 3
            val x = simulated[a]; val y = simulated[a + 1]; val z = simulated[a + 2]
            if (x.isFinite() && y.isFinite() && z.isFinite()) {
                globalPositions[b] = x; globalPositions[b + 1] = y; globalPositions[b + 2] = z
            }
        }
    }

    fun reset() { solver.reset(); solver.snapshotPositions().copyInto(lastPositions); lastSafetyReport = null }

    companion object {
        /**
         * Constrói um runtime do registro PMX. A seção de faces do material define o tecido.
         * Os parâmetros LST/AST são convertidos para compliance XPBD como aproximação monotônica.
         */
        fun create(
            model: PmxModel,
            softBodyIndex: Int,
            config: PmxSoftBodyRuntimeConfig = PmxSoftBodyRuntimeConfig()
        ): PmxSoftBodyRuntime {
            require(softBodyIndex in model.softBodies.indices) { "Soft body inexistente" }
            val sb = model.softBodies[softBodyIndex]
            require(sb.shape == 0 || sb.shape == 1) { "Shape PMX soft body desconhecido: ${sb.shape}" }
            require(sb.material in model.materials.indices) { "Material do soft body fora do modelo" }
            val vertexLimit = config.maxVertices.coerceIn(3, 100_000)
            val offset = model.materials.take(sb.material).sumOf { it.indexCount.coerceAtLeast(0) }
            val count = model.materials[sb.material].indexCount.coerceAtLeast(0)
            require(count >= 3 && count % 3 == 0) { "Material do soft body não contém triângulos" }
            require(offset >= 0 && offset + count <= model.indices.size) { "Faixa de índices do material excede a malha" }
            val unique = LinkedHashMap<Int, Int>()
            val triangles = IntArray(count)
            for (i in 0 until count) {
                val global = model.indices[offset + i]
                require(global in 0 until model.vertexCount) { "Índice PMX fora da malha: $global" }
                triangles[i] = unique.getOrPut(global) { unique.size }
            }
            require(unique.size in 3..vertexLimit) { "Soft body excede limite de partículas (${unique.size}/$vertexLimit)" }
            val sourceVertices = unique.keys.toIntArray()
            val rest = FloatArray(sourceVertices.size * 3)
            for (i in sourceVertices.indices) {
                val src = sourceVertices[i] * 3; val dst = i * 3
                rest[dst] = model.positions[src]; rest[dst + 1] = model.positions[src + 1]; rest[dst + 2] = model.positions[src + 2]
                require(rest[dst].isFinite() && rest[dst + 1].isFinite() && rest[dst + 2].isFinite()) { "Soft body contém posição não finita" }
            }
            val stiffnessL = sb.materialStiffness.getOrElse(0) { 50 }.coerceIn(0, 100) / 100f
            val stiffnessA = sb.materialStiffness.getOrElse(1) { 25 }.coerceIn(0, 100) / 100f
            val stretchCompliance = (1f - stiffnessL).let { it * it * 0.003f + 1e-7f }
            val bendCompliance = if (sb.shape == 1) 10_000f else (1f - stiffnessA).let { it * it * 0.02f + 1e-5f }
            val totalMass = sb.totalMass.takeIf { it.isFinite() && it > 1e-5f } ?: 1f
            val solver = ClothXpbd.fromMesh(rest, triangles, totalMass / sourceVertices.size, stretchCompliance, bendCompliance)
            val localByGlobal = unique
            val warnings = ArrayList<String>()
            if (sb.shape == 1) warnings += "Rope usa constraints de aresta da triangulação do material; requer malha adequada para representar a corda."
            if (sb.config.getOrElse(4) { 0f } > 0f) warnings += "Pressão PR preservada no PMX, mas não aplicada pelo solver XPBD atual."
            if (sb.config.getOrElse(5) { 0f } > 0f) warnings += "Conservação de volume VC preservada, mas não aplicada pelo solver XPBD atual."
            if (sb.config.getOrElse(7) { 0f } > 0f) warnings += "Pose matching MT não está implementado; rigidez estrutural usa LST/AST."
            val pinSet = LinkedHashSet<Int>()
            for (global in sb.pins) {
                val local = localByGlobal[global]
                if (local == null) warnings += "Pin PMX $global não pertence às faces do material selecionado."
                else pinSet += local
            }
            val anchors = ArrayList<AnchorBinding>()
            for (a in sb.anchors) {
                val local = localByGlobal[a.vertex]
                if (local == null) { warnings += "Anchor do vértice ${a.vertex} fora do material do soft body."; continue }
                if (a.rigidBody !in model.rigidBodies.indices) { warnings += "Anchor referencia rigid body ${a.rigidBody} inválido."; continue }
                if (pinSet.add(local)) solver.pin(local)
                val rb = model.rigidBodies[a.rigidBody]
                anchors += AnchorBinding(a.rigidBody, local,
                    floatArrayOf(rest[local * 3] - rb.pos[0], rest[local * 3 + 1] - rb.pos[1], rest[local * 3 + 2] - rb.pos[2]), a.nearMode)
            }
            for (local in pinSet) if (anchors.none { it.localVertex == local }) solver.pin(local)
            val stats0 = solver.stats
            val stats = PmxSoftBodyRuntimeStats(softBodyIndex, sb.name, sb.shape, sb.material, sourceVertices.size,
                triangles.size / 3, stats0.stretchConstraints, stats0.bendConstraints, pinSet.size, anchors.size, warnings)
            return PmxSoftBodyRuntime(solver, sourceVertices, triangles, anchors, sb, stats, config)
        }

        private fun absGravity(value: Float) = kotlin.math.abs(value.takeIf { it.isFinite() } ?: 9.81f)
    }
}
