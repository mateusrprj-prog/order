package studio.mmd.rig

import org.json.JSONArray
import org.json.JSONObject
import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxModel
import kotlin.math.abs

/**
 * v1.32.0 — Editor de Partes do Modelo (P1 1.1/1.2). Lógica pura (sem Android), testável na JVM.
 *
 * O reconhecimento COMBINA sinais independentes e dá uma confiança a cada elemento (osso, material, corpo rígido):
 *  1. nome do osso (JP/EN); 2. nome do corpo rígido; 3. corpo rígido dinâmico (corrobora, nunca decide sozinho);
 *  4. hierarquia (osso sem nome útil herda da cadeia do pai); 5. nome do material; 6. pesos dos vértices
 *  (material cujos vértices pesam nos ossos já classificados).
 * Nenhum sinal sozinho chega a "alta": nome de material, em particular, nunca decide sozinho.
 * As correções do usuário ([PartOverrides]) sempre prevalecem sobre o automático.
 */
object PartCat {
    const val NONE = "none"          // "fora das partes" (removido pelo usuário)
    const val UNKNOWN = "unknown"
    const val HAIR = "hair"
    const val BANGS = "bangs"
    const val TAIL_HAIR = "braid"
    const val SKIRT = "skirt"
    const val TOP = "top"
    const val BOTTOM = "bottom"
    const val SLEEVE = "sleeve"
    const val COAT = "coat"
    const val RIBBON = "ribbon"
    const val ACCESSORY = "accessory"
    const val TAIL_EAR = "tail_ear"
    const val CHEST = "chest"
    const val SHOES = "shoes"
    const val BODY = "body"

    /** [preset] = índice em [SecPreset] (ou -1 sem preset); [family] agrupa subtipos que não conflitam entre si. */
    class Def(val id: String, val label: String, val preset: Int, val family: String, val sided: Boolean, val keys: List<String>)

    val all: List<Def> = listOf(
        Def(BANGS, "Franja", 0, "hair", false, listOf("前髪", "bangs", "fringe", "まえがみ")),
        Def(TAIL_HAIR, "Tranças e rabos", 0, "hair", true, listOf("三つ編み", "みつあみ", "braid", "ポニーテール", "ポニテ", "ponytail", "ツインテール", "ツインテ", "twintail", "おさげ", "束")),
        Def(HAIR, "Cabelo", 0, "hair", false, listOf("髪", "hair", "ヘア", "ahoge", "アホ毛", "横髪", "後髪", "側髪", "もみあげ")),
        Def(CHEST, "Peito e partes secundárias", 5, "body", true, listOf("乳", "おっぱい", "oppai", "breast", "bust", "boob", "ちち")),
        Def(SKIRT, "Saia", 1, "cloth", false, listOf("スカート", "skirt", "スカ", "裾", "フレア", "flare", "ドレス", "dress", "ワンピ")),
        Def(SLEEVE, "Mangas", 1, "cloth", true, listOf("袖", "sleeve", "そで")),
        Def(COAT, "Casacos e partes soltas", 1, "cloth", false, listOf("マント", "cape", "cloak", "コート", "coat", "羽織", "ジャケット", "jacket", "パーカー", "hood", "フード", "ケープ", "ショール", "shawl", "エプロン", "apron", "ファー", "fur", "襟", "collar", "帯", "obi", "フリル", "frill")),
        Def(RIBBON, "Gravatas, fitas e laços", 2, "acc", false, listOf("リボン", "ribbon", "ネクタイ", "necktie", "tie", "ボウ", "bow", "マフラー", "scarf", "紐", "himo", "string", "strap", "蝶")),
        Def(TAIL_EAR, "Cauda e orelhas", 6, "acc", true, listOf("尻尾", "しっぽ", "tail", "耳", "ケモ", "ear", "ミミ")),
        Def(ACCESSORY, "Acessórios", 2, "acc", false, listOf("アクセ", "accessor", "飾", "ピアス", "イヤリング", "earring", "鈴", "bell", "chain", "チェーン", "タッセル", "tassel", "羽", "wing", "feather", "ケーブル", "cable", "ヘッドホン", "headphone", "メガネ", "眼鏡", "glasses", "帽子", "hat")),
        Def(TOP, "Roupa superior", 1, "cloth", false, listOf("上着", "シャツ", "shirt", "ブラウス", "blouse", "トップス", "tops", "セーター", "sweater", "ベスト", "vest", "服", "cloth", "衣装", "costume")),
        Def(BOTTOM, "Roupa inferior", 1, "cloth", false, listOf("パンツ", "pants", "ズボン", "shorts", "ショーツ", "スパッツ", "ホットパンツ", "タイツ", "tights", "レギンス")),
        Def(SHOES, "Calçados e meias", 3, "cloth", true, listOf("靴", "shoes", "boots", "ブーツ", "ソックス", "socks", "sock", "ニーソ", "stocking")),
        Def(BODY, "Corpo e rosto", 3, "skin", false, listOf("肌", "顔", "skin", "body", "face", "眉", "brow", "まつげ", "睫毛", "lash", "白目", "瞳", "mouth", "口", "歯", "teeth", "舌", "tongue", "頬", "cheek", "ボディ", "目", "eye"))
    )
    private val byId: Map<String, Def> = all.associateBy { it.id }
    fun def(id: String): Def? = byId[id]
    fun label(id: String): String = when (id) {
        NONE -> "Fora das partes"; UNKNOWN -> "Desconhecida — revisar"; else -> byId[id]?.label ?: id
    }
    /** Categorias oferecidas para correção manual (ordem de exibição). */
    val choosable: List<String> = all.map { it.id } + UNKNOWN + NONE
    /** Categorias cuja simulação de movimento secundário faz sentido por padrão. */
    fun physicalByDefault(id: String) = id != UNKNOWN && id != NONE && id != SHOES && id != BOTTOM && id != TOP && id != BODY
}

enum class PartKind(val tag: String, val label: String) { BONE("bone", "osso"), MATERIAL("mat", "material"), RIGID("rigid", "corpo rígido") }

/** Uma correção do usuário: o elemento pertence à [category] (e ao subgrupo [group], ex.: "Esquerda"). */
data class PartAssign(val category: String, val group: String = "")

/** Correções persistidas por personagem. Imutável; troca-se o objeto. Vazio = só o reconhecimento automático. */
data class PartOverrides(
    val assign: Map<String, PartAssign> = emptyMap(),
    val confirmed: Set<String> = emptySet(),
    /** Por id de parte ("categoria|grupo"): true/false força a física; ausente = padrão da categoria. */
    val physics: Map<String, Boolean> = emptyMap()
) {
    val isEmpty get() = assign.isEmpty() && confirmed.isEmpty() && physics.isEmpty()
    fun withAssign(keys: Collection<String>, a: PartAssign) = copy(assign = assign + keys.associateWith { a }, confirmed = confirmed + keys)
    fun withConfirmed(keys: Collection<String>) = copy(confirmed = confirmed + keys)
    fun without(keys: Collection<String>) = copy(assign = assign - keys.toSet(), confirmed = confirmed - keys.toSet())
    fun withPhysics(partId: String, on: Boolean?) = copy(physics = if (on == null) physics - partId else physics + (partId to on))
}

object PartOverridesIo {
    const val VERSION = 1
    fun toJson(o: PartOverrides): String {
        val a = JSONArray()
        o.assign.forEach { (k, v) -> a.put(JSONObject().put("k", k).put("c", v.category).put("g", v.group)) }
        val p = JSONObject(); o.physics.forEach { (k, v) -> p.put(k, v) }
        return JSONObject().put("v", VERSION).put("assign", a).put("confirmed", JSONArray(o.confirmed.toList())).put("physics", p).toString()
    }

    /** Nunca lança: texto inválido ou de versão futura volta ao reconhecimento automático puro. */
    fun fromJson(s: String): PartOverrides = try {
        val r = JSONObject(s)
        if (r.optInt("v", 0) > VERSION) PartOverrides() else {
            val a = r.optJSONArray("assign") ?: JSONArray()
            val assign = LinkedHashMap<String, PartAssign>()
            for (i in 0 until a.length()) {
                val j = a.optJSONObject(i) ?: continue
                val k = j.optString("k", ""); if (k.isEmpty()) continue
                assign[k] = PartAssign(j.optString("c", PartCat.UNKNOWN), j.optString("g", ""))
            }
            val c = r.optJSONArray("confirmed") ?: JSONArray()
            val confirmed = LinkedHashSet<String>(); for (i in 0 until c.length()) c.optString(i, "").takeIf { it.isNotEmpty() }?.let { confirmed.add(it) }
            val p = r.optJSONObject("physics") ?: JSONObject()
            val physics = LinkedHashMap<String, Boolean>(); for (k in p.keys()) physics[k] = p.optBoolean(k, true)
            PartOverrides(assign, confirmed, physics)
        }
    } catch (_: Throwable) { PartOverrides() }
}

class PartElement(
    val key: String, val kind: PartKind, val index: Int, val name: String,
    val category: String, val group: String, val confidence: Float,
    val manual: Boolean, val confirmed: Boolean,
    val evidence: List<String>, val alternatives: List<String>
) {
    val level: PartLevel get() = PartRecognizer.level(confidence, manual || confirmed)
}

enum class PartLevel(val label: String) { CONFIRMED("confirmada"), HIGH("confiança alta"), MEDIUM("confiança média"), LOW("confiança baixa"), REVIEW("revisar") }

class ModelPart(val id: String, val category: String, val group: String, val elements: List<PartElement>, val physics: Boolean) {
    val label: String get() = PartCat.label(category) + (if (group.isNotEmpty()) " · $group" else "")
    val bones: List<PartElement> get() = elements.filter { it.kind == PartKind.BONE }
    val materials: List<PartElement> get() = elements.filter { it.kind == PartKind.MATERIAL }
    val rigids: List<PartElement> get() = elements.filter { it.kind == PartKind.RIGID }
    /** Confiança da parte = a do elemento MAIS incerto (uma peça duvidosa não fica escondida na média). */
    val confidence: Float get() = elements.minOfOrNull { it.confidence } ?: 0f
    val level: PartLevel get() = PartRecognizer.level(confidence, elements.all { it.manual || it.confirmed })
    val needsReview: Boolean get() = category == PartCat.UNKNOWN || level == PartLevel.REVIEW || level == PartLevel.LOW
}

class PartReport(val parts: List<ModelPart>, val orphanOverrides: Int) {
    val reviewCount get() = parts.count { it.category != PartCat.NONE && it.needsReview }
    val summary: String get() {
        val real = parts.filter { it.category != PartCat.NONE }
        if (real.isEmpty()) return "Nenhuma parte reconhecida"
        return "${real.size} parte(s) · ${reviewCount} para revisar" + (if (orphanOverrides > 0) " · $orphanOverrides correção(ões) ignorada(s) (modelo mudou)" else "")
    }
}

/** Resultado do reconhecimento AUTOMÁTICO (caro: pesos de vértices). Guarde-o por modelo e aplique correções com [PartRecognizer.build]. */
class PartAnalysis internal constructor(
    val model: PmxModel,
    internal val elements: List<PartElement>
)

object PartRecognizer {
    // Ossos-padrão do corpo: nunca viram "parte" e bloqueiam a herança de categoria pela hierarquia.
    private val bodyBones = listOf(
        "センター", "グルーブ", "腰", "上半身", "上半身2", "下半身", "首", "頭", "肩", "腕", "ひじ", "手首", "手捩", "腕捩", "親指", "人指", "中指", "薬指", "小指",
        "足", "ひざ", "足首", "足ＩＫ", "つま先", "目", "両目", "全ての親", "操作中心", "肩P", "肩C",
        "center", "groove", "waist", "upper body", "lower body", "neck", "head", "shoulder", "arm", "elbow", "wrist", "thumb", "index", "middle", "ring", "little", "leg", "knee", "ankle", "toe", "eye")

    fun level(conf: Float, userVerified: Boolean): PartLevel = when {
        userVerified -> PartLevel.CONFIRMED
        conf >= 0.70f -> PartLevel.HIGH
        conf >= 0.50f -> PartLevel.MEDIUM
        conf >= 0.30f -> PartLevel.LOW
        else -> PartLevel.REVIEW
    }

    fun isIk(b: PmxBone) = b.ik != null || b.name.contains("IK") || b.name.contains("ＩＫ")

    /** "Esquerda"/"Direita"/"" a partir do nome (左/右, left/right, sufixos _L/.R etc.). */
    fun sideOf(name: String): String {
        if (name.contains('左')) return "Esquerda"
        if (name.contains('右')) return "Direita"
        val low = name.lowercase()
        val l = Regex("(^|[\\s_.\\-])(l|left)($|[\\s_.\\-\\d])")
        val r = Regex("(^|[\\s_.\\-])(r|right)($|[\\s_.\\-\\d])")
        val hasL = l.containsMatchIn(low); val hasR = r.containsMatchIn(low)
        return if (hasL && !hasR) "Esquerda" else if (hasR && !hasL) "Direita" else ""
    }

    private fun tokens(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() { if (sb.isNotEmpty()) { out.add(sb.toString().lowercase()); sb.clear() } }
        var prev = ' '
        for (ch in text) {
            val isAlpha = ch in 'a'..'z' || ch in 'A'..'Z'
            val isDigit = ch in '0'..'9'
            if (!isAlpha && !isDigit) { flush(); prev = ch; continue }
            // camelCase e letra↔dígito viram fronteira de token
            if (sb.isNotEmpty() && ((ch in 'A'..'Z' && prev in 'a'..'z') || (isDigit != (prev in '0'..'9')))) flush()
            sb.append(ch); prev = ch
        }
        flush()
        return out
    }

    /** Casa [key] com [text]: japonês e palavras ASCII longas por substring; ASCII curto só como palavra/prefixo de palavra. */
    private fun matches(key: String, text: String, toks: List<String>): Boolean {
        val k = key.lowercase()
        val ascii = k.all { it.code < 128 }
        if (!ascii) return text.contains(k)
        if (k.length >= 5) return text.lowercase().contains(k)
        return toks.any { it == k || it == k + "s" || (it.startsWith(k) && it.length <= k.length + 1) }
    }

    private class Hit(val cat: PartCat.Def, val key: String) { val keyLen get() = key.length }

    private fun hits(text: String): List<Hit> {
        if (text.isBlank()) return emptyList()
        val toks = tokens(text)
        val res = ArrayList<Hit>()
        for (c in PartCat.all) {
            var best: String? = null
            for (k in c.keys) if ((best == null || k.length > best.length) && matches(k, text, toks)) best = k
            if (best != null) res.add(Hit(c, best))
        }
        // mais específico primeiro (palavra mais longa); empate = ordem da lista
        return res.sortedByDescending { it.keyLen }
    }

    /** Acumulador de evidência por categoria: confiança = 1 − Π(1 − força) das fontes que concordam. */
    private class Acc {
        val strengths = HashMap<String, ArrayList<Float>>()
        val notes = HashMap<String, ArrayList<String>>()
        fun add(cat: String, s: Float, note: String) { strengths.getOrPut(cat) { ArrayList() }.add(s); notes.getOrPut(cat) { ArrayList() }.add(note) }
        fun conf(cat: String): Float { var p = 1f; strengths[cat]?.forEach { p *= (1f - it) }; return 1f - p }
        val isEmpty get() = strengths.isEmpty()
    }

    private val bodyAscii = bodyBones.filter { it.all { c -> c.code < 128 } }.map { it.lowercase() }
    private val bodyJp = bodyBones.filter { it.any { c -> c.code > 127 } }

    private fun asciiBodyName(x: String): Boolean {
        val t = x.trim().lowercase().replace('_', ' ').replace('.', ' ').replace('-', ' ').replace(Regex("\\s+"), " ")
        if (t.isEmpty()) return false
        return bodyAscii.any { k ->
            t == k || t == "left $k" || t == "right $k" || t == "$k l" || t == "$k r" || t == "l $k" || t == "r $k" || t == "$k left" || t == "$k right"
        }
    }

    /** Osso-padrão do MMD (nome exato, com ou sem 左/右): nunca vira parte. Nomes como "左スカート前" NÃO casam. */
    private fun isBodyBone(b: PmxBone): Boolean {
        val core = b.name.removePrefix("左").removePrefix("右").removeSuffix("ＩＫ").removeSuffix("IK").trim()
        return bodyJp.any { it == core } || asciiBodyName(b.name) || asciiBodyName(b.nameEn)
    }

    private fun finish(acc: Acc): Triple<String, Float, List<String>>? {
        if (acc.isEmpty) return null
        val ranked = acc.strengths.keys.map { it to acc.conf(it) }.sortedByDescending { it.second }
        val best = ranked[0]
        val bestFam = PartCat.def(best.first)?.family
        // concorrente real = outra categoria de OUTRA família (franja vs cabelo não é conflito)
        val rival = ranked.drop(1).firstOrNull { PartCat.def(it.first)?.family != bestFam }
        var conf = best.second
        val alts = ArrayList<String>()
        if (rival != null) { conf = (conf - 0.6f * rival.second).coerceAtLeast(0.05f); alts.add(rival.first) }
        return Triple(best.first, conf.coerceIn(0f, 0.97f), alts)
    }

    /** Reconhecimento automático puro (sem correções). Pode levar centenas de ms em modelos grandes: rode fora da thread de UI. */
    fun analyze(model: PmxModel): PartAnalysis {
        val bones = model.bones
        val dynBones = HashMap<Int, ArrayList<Int>>()          // osso -> corpos rígidos dinâmicos nele
        for ((i, rb) in model.rigidBodies.withIndex()) if ((rb.mode == 1 || rb.mode == 2) && rb.bone in bones.indices && !isIk(bones[rb.bone])) dynBones.getOrPut(rb.bone) { ArrayList() }.add(i)

        // ---- ossos: nome, corpo rígido, física, hierarquia
        val boneAcc = Array(bones.size) { Acc() }
        val boneDirect = BooleanArray(bones.size)
        for ((i, b) in bones.withIndex()) {
            if (isIk(b) || isBodyBone(b)) continue
            val hs = hits(b.name + " " + b.nameEn).take(2)
            for ((n, h) in hs.withIndex()) {
                val strong = h.key.any { it.code > 127 } || h.key.length >= 5     // japonês ou palavra longa
                val s = if (strong) 0.55f else 0.45f
                boneAcc[i].add(h.cat.id, if (n == 0) s else s * 0.6f, "nome do osso \"${b.name}\"")
                boneDirect[i] = true
            }
        }
        for ((i, rb) in model.rigidBodies.withIndex()) {
            val bi = rb.bone; if (bi !in bones.indices || isIk(bones[bi]) || isBodyBone(bones[bi])) continue
            hits(rb.name + " " + rb.nameEn).firstOrNull()?.let { h -> boneAcc[bi].add(h.cat.id, 0.45f, "nome do corpo rígido \"${rb.name}\""); boneDirect[bi] = true }
        }
        // corpo rígido dinâmico corrobora a categoria que o NOME já sugeriu (nunca cria categoria sozinho)
        for ((bi, _) in dynBones) {
            val a = boneAcc[bi]; if (a.isEmpty) continue
            val top = a.strengths.keys.maxByOrNull { a.conf(it) } ?: continue
            a.add(top, 0.25f, "tem corpo rígido com física")
        }
        // herança pela hierarquia (do pai para os filhos, em ordem topológica por profundidade)
        val order = bones.indices.sortedBy { depth(bones, it) }
        for (i in order) {
            val b = bones[i]
            if (isIk(b) || isBodyBone(b) || boneDirect[i]) continue
            val p = b.parent; if (p !in bones.indices) continue
            val pa = boneAcc[p]; if (pa.isEmpty) continue
            val pBest = finish(pa) ?: continue
            if (isBodyBone(bones[p]) && !boneDirect[p]) continue
            val s = if (dynBones.containsKey(i)) 0.45f else 0.30f
            boneAcc[i].add(pBest.first, s, "herda da cadeia de \"${bones[p].name}\"")
        }
        val boneCat = arrayOfNulls<String>(bones.size)
        val els = ArrayList<PartElement>()
        for ((i, b) in bones.withIndex()) {
            if (isIk(b) || isBodyBone(b)) continue
            val f = finish(boneAcc[i])
            if (f != null) {
                boneCat[i] = f.first
                els.add(element(PartKind.BONE, i, b.name, f.first, f.second, boneAcc[i].notes[f.first].orEmpty(), f.third, sideOf(b.name + " " + b.nameEn)))
            } else if (dynBones.containsKey(i)) {
                // tem física mas nenhum nome ajuda: aparece para o usuário classificar
                els.add(element(PartKind.BONE, i, b.name, PartCat.UNKNOWN, 0.1f, listOf("corpo rígido com física sem nome reconhecível"), emptyList(), ""))
            }
        }
        // ---- corpos rígidos: acompanham o osso (nome do próprio corpo conta; dinâmicos ligados a osso classificado herdam)
        for ((i, rb) in model.rigidBodies.withIndex()) {
            val acc = Acc()
            hits(rb.name + " " + rb.nameEn).firstOrNull()?.let { acc.add(it.cat.id, 0.45f, "nome do corpo rígido") }
            val bc = rb.bone.takeIf { it in bones.indices }?.let { boneCat[it] }
            if (bc != null) acc.add(bc, 0.35f, "ligado ao osso \"${bones[rb.bone].name}\"")
            val f = finish(acc) ?: continue
            if (rb.mode == 0 && rb.bone in bones.indices && isBodyBone(bones[rb.bone])) continue
            els.add(element(PartKind.RIGID, i, rb.name, f.first, f.second, acc.notes[f.first].orEmpty(), f.third, sideOf(rb.name + " " + rb.nameEn)))
        }
        // ---- materiais: nome (limitado) + pesos dos vértices
        val matWeights = materialBoneWeights(model)
        for ((mi, m) in model.materials.withIndex()) {
            val acc = Acc()
            val nameHit = hits(m.name + " " + m.nameEn).firstOrNull()
            if (nameHit != null) acc.add(nameHit.cat.id, 0.40f, "nome do material \"${m.name}\"")   // teto de fonte única: nunca "alta"
            val w = matWeights.getOrNull(mi)
            if (w != null && w.isNotEmpty()) {
                val perCat = HashMap<String, Float>(); var total = 0f
                for ((bi, wt) in w) { total += wt; val c = boneCat.getOrNull(bi); if (c != null) perCat[c] = (perCat[c] ?: 0f) + wt }
                if (total > 0f && perCat.isNotEmpty()) {
                    val topEntry = perCat.maxByOrNull { it.value }!!
                    val share = topEntry.value / total
                    if (share >= 0.5f) acc.add(topEntry.key, (0.30f + 0.40f * share).coerceAtMost(0.70f), "${(share * 100).toInt()}% dos pesos dos vértices em ossos de ${PartCat.label(topEntry.key)}")
                }
            }
            val f = finish(acc)
            val cat = f?.first ?: PartCat.UNKNOWN
            els.add(element(PartKind.MATERIAL, mi, m.name, cat, f?.second ?: 0f, acc.notes[cat].orEmpty().ifEmpty { listOf("sem nome nem pesos que indiquem a peça") }, f?.third ?: emptyList(), ""))
        }
        return PartAnalysis(model, els)
    }

    private fun element(kind: PartKind, index: Int, name: String, cat: String, conf: Float, notes: List<String>, alts: List<String>, side: String): PartElement {
        val def = PartCat.def(cat)
        val group = if (def != null && def.sided) side else ""
        return PartElement(key(kind, index, name), kind, index, name, cat, group, conf, false, false, notes, alts)
    }

    fun key(kind: PartKind, index: Int, name: String) = when (kind) {
        PartKind.BONE -> "bone:$name"
        else -> "${kind.tag}:$index:$name"
    }

    private fun depth(bones: List<PmxBone>, i: Int): Int { var d = 0; var p = bones[i].parent; while (p in bones.indices && d < 256) { d++; p = bones[p].parent }; return d }

    /** Peso total de cada osso nos vértices de cada material (cada vértice conta uma vez por material). */
    fun materialBoneWeights(model: PmxModel): List<Map<Int, Float>> {
        val res = ArrayList<Map<Int, Float>>()
        var cursor = 0
        val vc = model.vertexCount
        val hasW = model.boneIndices.size >= vc * 4 && model.boneWeights.size >= vc * 4
        for (m in model.materials) {
            val acc = HashMap<Int, Float>()
            if (hasW) {
                val seen = HashSet<Int>()
                val end = (cursor + m.indexCount).coerceAtMost(model.indices.size)
                for (k in cursor until end) {
                    val v = model.indices[k]; if (v !in 0 until vc || !seen.add(v)) continue
                    for (j in 0 until 4) {
                        val bi = model.boneIndices[v * 4 + j]; val wt = model.boneWeights[v * 4 + j]
                        if (bi >= 0 && wt > 0f) acc[bi] = (acc[bi] ?: 0f) + wt
                    }
                }
            }
            cursor += m.indexCount
            res.add(acc)
        }
        return res
    }

    /** Aplica as correções do usuário e monta as partes (agrupadas por categoria + subgrupo). Barato; chame a cada mudança. */
    fun build(analysis: PartAnalysis, o: PartOverrides): PartReport {
        val m = analysis.model
        var orphans = 0
        val present = analysis.elements.map { it.key }.toHashSet()
        // elementos que o automático não listou mas o usuário atribuiu (ex.: osso comum movido para "Saia")
        val extra = ArrayList<PartElement>()
        val extraKeys = HashSet<String>()
        for ((k, a) in o.assign) {
            if (k in present) continue
            val e = parseKey(m, k)
            if (e == null) { orphans++; continue }
            if (extraKeys.add(k)) extra.add(PartElement(k, e.first, e.second, e.third, a.category, a.group, 0f, true, true, listOf("adicionado manualmente"), emptyList()))
        }
        val all = ArrayList<PartElement>()
        for (e in analysis.elements) {
            val a = o.assign[e.key]
            val confirmed = e.key in o.confirmed
            all.add(when {
                a != null -> PartElement(e.key, e.kind, e.index, e.name, a.category, a.group, 1f, true, true, listOf("definido pelo usuário (antes: ${PartCat.label(e.category)})"), emptyList())
                confirmed -> PartElement(e.key, e.kind, e.index, e.name, e.category, e.group, 1f, false, true, e.evidence + "confirmado pelo usuário", e.alternatives)
                else -> e
            })
        }
        for (e in extra) all.add(PartElement(e.key, e.kind, e.index, e.name, e.category, e.group, 1f, true, true, e.evidence, emptyList()))
        val grouped = LinkedHashMap<String, ArrayList<PartElement>>()
        val order = PartCat.all.map { it.id } + PartCat.UNKNOWN + PartCat.NONE
        for (e in all.sortedWith(compareBy<PartElement>({ order.indexOf(it.category).let { i -> if (i < 0) 999 else i } }, { it.group }, { it.kind.ordinal }, { it.index }))) {
            grouped.getOrPut(partId(e.category, e.group)) { ArrayList() }.add(e)
        }
        val parts = grouped.map { (id, list) ->
            val cat = list[0].category; val grp = list[0].group
            ModelPart(id, cat, grp, list, o.physics[id] ?: PartCat.physicalByDefault(cat))
        }
        return PartReport(parts, orphans)
    }

    fun partId(category: String, group: String) = "$category|$group"

    /** Nome de grupo livre digitado pelo usuário: sem espaços nas pontas, sem "|" e ":" (separadores internos), até 24 caracteres. */
    fun sanitizeGroup(raw: String): String = raw.replace("|", " ").replace(":", " ").trim().replace(Regex("\\s+"), " ").take(24).trim()

    private fun parseKey(m: PmxModel, key: String): Triple<PartKind, Int, String>? {
        val p = key.split(':', limit = 3)
        return when (p.getOrNull(0)) {
            "bone" -> { val n = key.substringAfter(':'); val i = m.bones.indexOfFirst { it.name == n }; if (i >= 0) Triple(PartKind.BONE, i, n) else null }
            "mat" -> { val i = p.getOrNull(1)?.toIntOrNull() ?: return null; val n = p.getOrNull(2) ?: return null; if (m.materials.getOrNull(i)?.name == n) Triple(PartKind.MATERIAL, i, n) else null }
            "rigid" -> { val i = p.getOrNull(1)?.toIntOrNull() ?: return null; val n = p.getOrNull(2) ?: return null; if (m.rigidBodies.getOrNull(i)?.name == n) Triple(PartKind.RIGID, i, n) else null }
            else -> null
        }
    }

    // ------------------------------------------------------------------ ferramentas de divisão (geometria como sinal auxiliar, só quando o usuário pede)

    /** Posição (x,y,z) de cada elemento: osso = posição do osso; rigid = posição do corpo; material = centróide dos vértices. */
    fun positionOf(model: PmxModel, e: PartElement): FloatArray? = when (e.kind) {
        PartKind.BONE -> model.bones.getOrNull(e.index)?.let { floatArrayOf(it.x, it.y, it.z) }
        PartKind.RIGID -> model.rigidBodies.getOrNull(e.index)?.pos?.takeIf { it.size >= 3 }
        PartKind.MATERIAL -> materialCentroid(model, e.index)
    }

    fun materialCentroid(model: PmxModel, mi: Int): FloatArray? {
        var cursor = 0
        for (i in 0 until mi) cursor += model.materials.getOrNull(i)?.indexCount ?: return null
        val m = model.materials.getOrNull(mi) ?: return null
        val vc = model.vertexCount; val end = (cursor + m.indexCount).coerceAtMost(model.indices.size)
        var sx = 0.0; var sy = 0.0; var sz = 0.0; var n = 0
        val seen = HashSet<Int>()
        for (k in cursor until end) { val v = model.indices[k]; if (v in 0 until vc && seen.add(v)) { sx += model.positions[v * 3]; sy += model.positions[v * 3 + 1]; sz += model.positions[v * 3 + 2]; n++ } }
        return if (n == 0) null else floatArrayOf((sx / n).toFloat(), (sy / n).toFloat(), (sz / n).toFloat())
    }

    /**
     * Divide [part] em subgrupos pela posição: eixo 0 = lados (X: +X é a esquerda do personagem no MMD), eixo 2 = frente/trás
     * (a frente do modelo é −Z). Elementos a menos de [eps] do plano central ficam sem grupo. Devolve as novas correções.
     */
    fun splitPart(model: PmxModel, part: ModelPart, axis: Int, o: PartOverrides, eps: Float = 0.05f): PartOverrides {
        var out = o
        val (neg, pos) = if (axis == 0) ("Direita" to "Esquerda") else ("Frente" to "Trás")
        for (e in part.elements) {
            val p = positionOf(model, e) ?: continue
            val v = p[axis.coerceIn(0, 2)]
            val g = when {
                abs(v) <= eps -> ""
                axis == 0 -> if (v > 0f) pos else neg
                else -> if (v < 0f) "Frente" else "Trás"
            }
            if (g != e.group) out = out.withAssign(listOf(e.key), PartAssign(part.category, g))
        }
        return out
    }

    // ------------------------------------------------------------------ ligação com o movimento secundário (efeito real)

    const val SEC_PREFIX = "part:"
    const val SEC_NAME_PREFIX = "Parte · "

    /**
     * Cria um grupo de movimento secundário por parte com física ligada e com ossos. Os grupos têm id fixo `part:<id>`:
     * reaplicar SUBSTITUI só estes, sem tocar nos grupos manuais nem nos do "Auto".
     * Devolve a nova lista e uma nota (partes sem ossos não geram grupo).
     */
    fun applyToSecondary(model: PmxModel, report: PartReport, current: List<Secondary>): Pair<List<Secondary>, String> {
        val keep = current.filter { !it.id.startsWith(SEC_PREFIX) }
        val old = current.filter { it.id.startsWith(SEC_PREFIX) }.associateBy { it.id }
        val created = ArrayList<Secondary>(); var skippedNoBones = 0
        for (p in report.parts) {
            if (!p.physics || p.category == PartCat.NONE || p.category == PartCat.UNKNOWN) continue
            val names = p.bones.map { it.name }.filter { n -> model.bones.any { it.name == n && !isIk(it) } }.distinct()
            if (names.isEmpty()) { skippedNoBones++; continue }
            val id = SEC_PREFIX + p.id
            val base = Secondary(id, SEC_NAME_PREFIX + p.label, names)
            val preset = PartCat.def(p.category)?.preset?.takeIf { it in 0..6 } ?: 3
            // preserva ajustes finos que o usuário fez no grupo depois de aplicar (sliders), trocando só nome/ossos
            created.add(old[id]?.copy(name = base.name, bones = names) ?: SecPreset.apply(base, preset))
        }
        val note = if (created.isEmpty()) "Nenhuma parte com ossos e física ligada" else
            "${created.size} grupo(s) de movimento secundário criados a partir das partes" + (if (skippedNoBones > 0) " · $skippedNoBones sem ossos (só material) foram ignoradas" else "")
        return (keep + created) to note
    }
}
