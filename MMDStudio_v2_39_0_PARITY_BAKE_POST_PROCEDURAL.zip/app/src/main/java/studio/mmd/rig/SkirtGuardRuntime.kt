package studio.mmd.rig

import studio.mmd.mmd.PmxModel
import kotlin.math.max
import kotlin.math.sqrt

/** Snapshot de colisores de pernas/baixa cintura já transformados para a pose atual do personagem. */
data class SkirtGuardPose(
    val capsules: List<ClothCapsule>,
    val source: String,
    val warnings: List<String> = emptyList(),
    /** Segmentos que já estão protegidos por rigid bodies PMX cinemáticos ligados aos bones. */
    val pmxCoveredSegments: Int = 0
)

/** Diagnóstico pós-solver: penetração restante entre os vértices simulados e os colisores da personagem. */
data class SkirtGuardDiagnostics(
    val testedVertices: Int,
    val penetratingVertices: Int,
    val maxPenetration: Float,
    val worstVertex: Int,
    val colliderCount: Int
) {
    val clean: Boolean get() = penetratingVertices == 0 || maxPenetration <= 1e-4f

    companion object {
        /**
         * Mede a distância assinada de cada vértice aos eixos das cápsulas. O transform opcional converte
         * posições pré-skinning para o espaço animado MMD; null significa espaço local/rest.
         */
        fun measure(
            localPositions: FloatArray,
            vertices: IntArray,
            capsules: List<ClothCapsule>,
            transform: ((Int, Float, Float, Float, FloatArray) -> Unit)? = null,
            tolerance: Float = 1e-4f
        ): SkirtGuardDiagnostics {
            if (localPositions.size < 3 || vertices.isEmpty() || capsules.isEmpty())
                return SkirtGuardDiagnostics(0, 0, 0f, -1, capsules.size)
            val out = FloatArray(3)
            var tested = 0
            var penetrating = 0
            var worst = 0f
            var worstVertex = -1
            for (v in vertices) {
                val o = v * 3
                if (v < 0 || o + 2 >= localPositions.size) continue
                val x = localPositions[o]; val y = localPositions[o + 1]; val z = localPositions[o + 2]
                if (!x.isFinite() || !y.isFinite() || !z.isFinite()) continue
                if (transform != null) transform(v, x, y, z, out)
                else { out[0] = x; out[1] = y; out[2] = z }
                if (!out.all(Float::isFinite)) continue
                tested++
                var signedDistance = Float.POSITIVE_INFINITY
                for (c in capsules) {
                    val abx = c.bx - c.ax; val aby = c.by - c.ay; val abz = c.bz - c.az
                    val apx = out[0] - c.ax; val apy = out[1] - c.ay; val apz = out[2] - c.az
                    val den = abx * abx + aby * aby + abz * abz
                    val t = if (den <= 1e-10f) 0f else ((apx * abx + apy * aby + apz * abz) / den).coerceIn(0f, 1f)
                    val dx = out[0] - (c.ax + abx * t)
                    val dy = out[1] - (c.ay + aby * t)
                    val dz = out[2] - (c.az + abz * t)
                    val d = sqrt(dx * dx + dy * dy + dz * dz) - c.radius
                    if (d < signedDistance) signedDistance = d
                }
                if (signedDistance < -tolerance) {
                    penetrating++
                    val depth = -signedDistance
                    if (depth > worst) { worst = depth; worstVertex = v }
                }
            }
            return SkirtGuardDiagnostics(tested, penetrating, max(0f, worst), worstVertex, capsules.size)
        }
    }
}

/**
 * Faz o binding automático da proteção de saia ao esqueleto. Os pontos de repouso são transformados
 * pela pose do osso a cada frame; assim os colisores seguem FK, IK e morphs de osso sem alterar o PMX.
 */
object SkirtGuardRuntime {
    /** transformPoint(bone, restX, restY, restZ, out) deve aplicar a transformação global atual do osso. */
    fun pose(
        model: PmxModel,
        profile: SkirtGuardProfile = SkirtGuardAuto.profile(model),
        margin: Float = 0.015f,
        transformPoint: (Int, Float, Float, Float, FloatArray) -> Unit
    ): SkirtGuardPose {
        if (!profile.detected) return SkirtGuardPose(emptyList(), "none", listOf("Nenhuma região de saia detectada"))
        val safeMargin = (if (margin.isFinite()) margin else 0.015f).coerceIn(0f, 0.15f)
        val result = ArrayList<ClothCapsule>()
        val warnings = ArrayList<String>()
        val pointA = FloatArray(3)
        val pointB = FloatArray(3)
        // O plano anatômico usa nomes JP/EN com lado explícito, ignora IK/D/twist e não duplica
        // ossos já cobertos por corpos rígidos cinemáticos do próprio PMX.
        val bodyPlan = try { BodyColliders.plan(model) } catch (_: Throwable) { BodyColliderPlan.EMPTY }
        val boundBones = HashSet<Int>()
        // Corpos rígidos PMX estáticos/cinemáticos ligados ao osso já entram no solver pela SceneScreen.
        // Marcá-los evita que o fallback acrescente uma segunda cápsula sobre o mesmo segmento.
        model.rigidBodies.asSequence().filter { it.mode == 0 && it.bone in model.bones.indices }
            .forEach { boundBones += it.bone }
        val hintCoveredByPmx = profile.colliderHints.count { it.boneIndex in boundBones }
        val pmxCoveredSegments = maxOf(bodyPlan.covered.size, hintCoveredByPmx)
        val hasPmxCoverage = pmxCoveredSegments > 0
        for (body in bodyPlan.colliders) {
            if (body.bone !in model.bones.indices || body.radius <= 0f) continue
            try {
                transformPoint(body.bone, body.a[0], body.a[1], body.a[2], pointA)
                transformPoint(body.bone, body.b[0], body.b[1], body.b[2], pointB)
                if (!pointA.all(Float::isFinite) || !pointB.all(Float::isFinite)) continue
                val r = (body.radius + safeMargin).coerceIn(0.005f, 2f)
                result += ClothCapsule(pointA[0], pointA[1], pointA[2], pointB[0], pointB[1], pointB[2], r)
                boundBones += body.bone
            } catch (_: Throwable) {
                warnings += "Falha ao transformar colisor ${body.key}"
            }
        }

        // Fallback complementar para rigs não canônicos/parciais. Só acrescenta bones que o plano
        // anatômico ainda não cobriu, evitando cápsulas duplicadas no mesmo segmento.
        var usedHints = false
        for (hint in profile.colliderHints) {
            if (hint.boneIndex !in model.bones.indices || hint.radius <= 0f || hint.boneIndex in boundBones) continue
            try {
                transformPoint(hint.boneIndex, hint.start[0], hint.start[1], hint.start[2], pointA)
                transformPoint(hint.boneIndex, hint.end[0], hint.end[1], hint.end[2], pointB)
                if (!pointA.all(Float::isFinite) || !pointB.all(Float::isFinite)) continue
                result += ClothCapsule(pointA[0], pointA[1], pointA[2], pointB[0], pointB[1], pointB[2], (hint.radius + safeMargin).coerceIn(0.005f, 2f))
                boundBones += hint.boneIndex
                usedHints = true
            } catch (_: Throwable) { warnings += "Falha ao transformar hint ${hint.boneName}" }
        }
        if (result.isEmpty() && !hasPmxCoverage) warnings += "Saia reconhecida, mas não há ossos de perna/quadril compatíveis para gerar colisores"
        val source = when {
            bodyPlan.colliders.isNotEmpty() && usedHints -> "BodyColliders+SkirtHints"
            bodyPlan.colliders.isNotEmpty() -> "BodyColliders"
            hasPmxCoverage && usedHints -> "PmxRigids+SkirtHints"
            hasPmxCoverage -> "PmxRigids"
            else -> "SkirtHints"
        }
        return SkirtGuardPose(result, source, warnings, pmxCoveredSegments)
    }

    /** Constrói a pose de repouso para bake sem seguimento de animação. */
    fun restPose(model: PmxModel, profile: SkirtGuardProfile = SkirtGuardAuto.profile(model), margin: Float = 0.015f): SkirtGuardPose =
        pose(model, profile, margin) { _, x, y, z, out -> out[0] = x; out[1] = y; out[2] = z }
}
