package studio.mmd.rig

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.floor
import kotlin.math.abs

/** Colisor esférico no espaço local da simulação de tecido. */
data class ClothSphere(val x: Float, val y: Float, val z: Float, val radius: Float)
/** Colisor cápsula no espaço local da simulação de tecido. */
data class ClothCapsule(val ax: Float, val ay: Float, val az: Float, val bx: Float, val by: Float, val bz: Float, val radius: Float)
/** Caixa orientada; sizeX/Y/Z são semi-extensões PMX no espaço local da caixa. Euler XYZ em radianos. */
data class ClothBox(val x: Float, val y: Float, val z: Float, val sizeX: Float, val sizeY: Float, val sizeZ: Float, val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f)
/** Cápsula que se desloca entre dois poses; usada para reduzir tunneling em passos rápidos. */
data class SweptClothCapsule(val previous: ClothCapsule, val current: ClothCapsule)
/** Triângulo estático da superfície do corpo usado como colisor de duas faces. */
data class ClothTriangleCollider(val ax: Float, val ay: Float, val az: Float, val bx: Float, val by: Float, val bz: Float, val cx: Float, val cy: Float, val cz: Float)

data class ClothStats(val particles: Int, val stretchConstraints: Int, val bendConstraints: Int, val pinned: Int)

data class ClothQualityReport(
    val vertexCount: Int,
    val invalidVertices: Int,
    val checkedEdges: Int,
    val overstretchedEdges: Int,
    val compressedEdges: Int,
    val collapsedEdges: Int,
    val maxStretchRatio: Float,
    val averageAbsoluteStrain: Float
) {
    val healthy: Boolean get() = invalidVertices == 0 && overstretchedEdges == 0 && collapsedEdges == 0
}


/** Limites de segurança contra explosão numérica na simulação em tempo real. */
data class ClothStepSafetyConfig(
    val maxDisplacementPerStep: Float = 8f,
    val maxSpeed: Float = 500f,
    val maxAbsoluteCoordinate: Float = 100_000f
)

data class ClothStepSafetyReport(
    val accepted: Boolean,
    val checkedParticles: Int,
    val nonFiniteParticles: Int,
    val excessiveDisplacementParticles: Int,
    val excessiveSpeedParticles: Int,
    val maxDisplacement: Float,
    val maxSpeed: Float,
    val reason: String
)

data class ClothStepSafetyResult(val positions: FloatArray, val report: ClothStepSafetyReport)

/** Conversão entre o espaço local pré-skinning do cache e o espaço deformado do corpo em um frame. */
interface ClothSkinTransform {
    fun toWorldPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray)
    /** A posição histórica usa a pose do quadro anterior quando disponível, preservando velocidade de animação. */
    fun toWorldPreviousPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) = toWorldPosition(vertex, x, y, z, out)
    fun toWorldPreviousVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) = toWorldVector(vertex, x, y, z, out)
    fun toLocalPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray)
    fun toWorldVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray)
    fun toLocalVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray)
}

/**
 * Solver de tecido XPBD (Extended Position Based Dynamics) em CPU.
 * Recebe a malha triangulada, constrói constraints de aresta e dobra e retorna posições por vértice.
 * Não depende de Android/OpenGL, pode rodar em executor de fundo e fazer bake para cache.
 *
 * Unidade de escala = unidade do modelo. A integração na viewport deve enviar as posições resultantes
 * para o buffer dinâmico de vértices e usar os colisores do personagem na mesma coordenada local.
 */
class ClothXpbd private constructor(
    restPositions: FloatArray,
    inverseMass: FloatArray,
    private val stretch: List<DistanceConstraint>,
    private val bend: List<DistanceConstraint>,
    private val selfCollisionExclusions: Set<Long>
) {
    private data class DistanceConstraint(val a: Int, val b: Int, val rest: Float, val compliance: Float, var lambda: Float = 0f)
    private data class Pin(val index: Int, var x: Float, var y: Float, var z: Float)

    private val rest = restPositions.copyOf()
    private val p = restPositions.copyOf()
    private val previous = restPositions.copyOf()
    private val velocity = FloatArray(restPositions.size)
    private val invMass = inverseMass.copyOf()
    private val originalInvMass = inverseMass.copyOf()
    private val pins = LinkedHashMap<Int, Pin>()
    private var spheres: List<ClothSphere> = emptyList()
    private var capsules: List<ClothCapsule> = emptyList()
    private var sweptCapsules: List<SweptClothCapsule> = emptyList()
    private var boxes: List<ClothBox> = emptyList()
    private data class GridCell(val x: Int, val y: Int, val z: Int)
    private data class SurfaceTriangle(val ax: Float, val ay: Float, val az: Float, val bx: Float, val by: Float, val bz: Float, val cx: Float, val cy: Float, val cz: Float, val nx: Float, val ny: Float, val nz: Float, val minX: Float, val minY: Float, val minZ: Float, val maxX: Float, val maxY: Float, val maxZ: Float)
    private var surfaceTriangles: List<SurfaceTriangle> = emptyList()
    private var surfaceBuckets: Map<GridCell, IntArray> = emptyMap()
    private var largeSurfaceTriangles: IntArray = IntArray(0)
    private var surfaceCellSize = 0.2f
    private var collisionThickness = 0.015f
    var lastStepSafetyReport: ClothStepSafetyReport? = null
        private set

    val vertexCount: Int get() = p.size / 3
    val stats: ClothStats get() = ClothStats(vertexCount, stretch.size, bend.size, pins.size)

    init {
        require(restPositions.size % 3 == 0) { "Posições devem conter XYZ por vértice" }
        require(inverseMass.size == vertexCount) { "É necessário um inverseMass por vértice" }
    }

    /** Fixa um vértice no ponto informado (ou no repouso quando x/y/z não são passados). */
    fun pin(index: Int, x: Float = p[index * 3], y: Float = p[index * 3 + 1], z: Float = p[index * 3 + 2]) {
        require(index in 0 until vertexCount)
        require(x.isFinite() && y.isFinite() && z.isFinite()) { "Âncora contém coordenadas não finitas" }
        pins[index] = Pin(index, x, y, z); invMass[index] = 0f
        setPosition(index, x, y, z); velocity[index * 3] = 0f; velocity[index * 3 + 1] = 0f; velocity[index * 3 + 2] = 0f
    }

    fun movePin(index: Int, x: Float, y: Float, z: Float) {
        val pin = pins[index] ?: return
        require(x.isFinite() && y.isFinite() && z.isFinite()) { "Âncora contém coordenadas não finitas" }
        pin.x = x; pin.y = y; pin.z = z
        setPosition(index, x, y, z)
    }

    fun unpin(index: Int): Boolean {
        if (pins.remove(index) == null) return false
        invMass[index] = originalInvMass[index]
        return true
    }

    /** Massa individual em unidades do modelo; vértices ancorados continuam com inverseMass zero. */
    fun setMass(index: Int, mass: Float) {
        require(index in 0 until vertexCount)
        require(mass.isFinite() && mass > 1e-6f) { "Massa deve ser positiva e finita" }
        originalInvMass[index] = 1f / mass
        if (index !in pins) invMass[index] = originalInvMass[index]
    }

    fun setColliders(
        spheres: List<ClothSphere> = emptyList(),
        capsules: List<ClothCapsule> = emptyList(),
        boxes: List<ClothBox> = emptyList(),
        triangles: List<ClothTriangleCollider> = emptyList(),
        thickness: Float = 0.015f,
        cellSize: Float = 0.2f
    ) {
        this.spheres = spheres.filter { it.radius > 0f && it.radius.isFinite() && it.x.isFinite() && it.y.isFinite() && it.z.isFinite() }
        this.capsules = capsules.filter { it.radius > 0f && it.radius.isFinite() && it.ax.isFinite() && it.ay.isFinite() && it.az.isFinite() && it.bx.isFinite() && it.by.isFinite() && it.bz.isFinite() }
        this.boxes = boxes.filter { listOf(it.x,it.y,it.z,it.sizeX,it.sizeY,it.sizeZ,it.rx,it.ry,it.rz).all(Float::isFinite) && it.sizeX > 0f && it.sizeY > 0f && it.sizeZ > 0f }
        collisionThickness = thickness.takeIf { it.isFinite() }?.coerceIn(0.001f, 0.25f) ?: 0.015f
        surfaceCellSize = cellSize.takeIf { it.isFinite() }?.coerceIn(0.025f, 2f) ?: 0.2f
        val built = ArrayList<SurfaceTriangle>(triangles.size)
        for (t in triangles) {
            val values = floatArrayOf(t.ax,t.ay,t.az,t.bx,t.by,t.bz,t.cx,t.cy,t.cz)
            if (!values.all(Float::isFinite)) continue
            val abx=t.bx-t.ax; val aby=t.by-t.ay; val abz=t.bz-t.az
            val acx=t.cx-t.ax; val acy=t.cy-t.ay; val acz=t.cz-t.az
            var nx=aby*acz-abz*acy; var ny=abz*acx-abx*acz; var nz=abx*acy-aby*acx
            val len=sqrt(nx*nx+ny*ny+nz*nz)
            if (len < 1e-9f || !len.isFinite()) continue
            nx/=len; ny/=len; nz/=len
            built += SurfaceTriangle(t.ax,t.ay,t.az,t.bx,t.by,t.bz,t.cx,t.cy,t.cz,nx,ny,nz,
                min(t.ax,min(t.bx,t.cx))-collisionThickness, min(t.ay,min(t.by,t.cy))-collisionThickness, min(t.az,min(t.bz,t.cz))-collisionThickness,
                max(t.ax,max(t.bx,t.cx))+collisionThickness, max(t.ay,max(t.by,t.cy))+collisionThickness, max(t.az,max(t.bz,t.cz))+collisionThickness)
        }
        surfaceTriangles = built
        val buckets = HashMap<GridCell, MutableList<Int>>()
        val large = ArrayList<Int>()
        fun cell(v: Float) = floor(v / surfaceCellSize).toInt()
        built.forEachIndexed { index, tri ->
            val x0=cell(tri.minX); val y0=cell(tri.minY); val z0=cell(tri.minZ)
            val x1=cell(tri.maxX); val y1=cell(tri.maxY); val z1=cell(tri.maxZ)
            val cellCount=(x1.toLong()-x0+1L)*(y1.toLong()-y0+1L)*(z1.toLong()-z0+1L)
            if (cellCount > 512L) large += index
            else for (x in x0..x1) for (y in y0..y1) for (z in z0..z1) buckets.getOrPut(GridCell(x,y,z)) { ArrayList() }.add(index)
        }
        surfaceBuckets = buckets.mapValues { it.value.distinct().toIntArray() }
        largeSurfaceTriangles = large.toIntArray()
    }

    /**
     * Define cápsulas cinemáticas varridas entre a pose anterior e a atual. As listas devem manter
     * a mesma ordem anatômica (quadril/coxa/panturrilha); entradas faltantes usam a pose atual.
     */
    fun setSweptCapsules(previous: List<ClothCapsule>, current: List<ClothCapsule>) {
        sweptCapsules = current.mapIndexed { index, now ->
            val before = previous.getOrNull(index) ?: now
            SweptClothCapsule(before, now)
        }.filter { pair ->
            listOf(pair.previous.ax, pair.previous.ay, pair.previous.az, pair.previous.bx, pair.previous.by, pair.previous.bz, pair.previous.radius,
                pair.current.ax, pair.current.ay, pair.current.az, pair.current.bx, pair.current.by, pair.current.bz, pair.current.radius).all(Float::isFinite) &&
                pair.previous.radius > 0f && pair.current.radius > 0f
        }
    }

    fun clearSweptCapsules() { sweptCapsules = emptyList() }

    fun setPosition(index: Int, x: Float, y: Float, z: Float) {
        require(index in 0 until vertexCount)
        require(x.isFinite() && y.isFinite() && z.isFinite()) { "Posição contém coordenadas não finitas" }
        val o = index * 3; p[o] = x; p[o + 1] = y; p[o + 2] = z
    }

    /** Aplica correção geométrica sem criar impulso: desloca posição atual e histórico pelo mesmo delta. */
    fun applyPositionCorrection(index: Int, x: Float, y: Float, z: Float): Boolean {
        require(index in 0 until vertexCount)
        require(x.isFinite() && y.isFinite() && z.isFinite()) { "Correção contém coordenadas não finitas" }
        if (index in pins) return false
        val o = index * 3
        val dx = x - p[o]; val dy = y - p[o + 1]; val dz = z - p[o + 2]
        if (!dx.isFinite() || !dy.isFinite() || !dz.isFinite()) return false
        p[o] = x; p[o + 1] = y; p[o + 2] = z
        previous[o] += dx; previous[o + 1] += dy; previous[o + 2] += dz
        return true
    }

    fun position(index: Int): FloatArray {
        require(index in 0 until vertexCount)
        val o = index * 3; return floatArrayOf(p[o], p[o + 1], p[o + 2])
    }

    /** Snapshot imutável da posição local atual, sem avançar o relógio físico. */
    fun snapshotPositions(): FloatArray = p.copyOf()

    /** Métricas de qualidade geométrica da simulação, úteis para detectar explosão/colapso do tecido. */
    fun qualityReport(overstretchThreshold: Float = 1.25f, compressionThreshold: Float = 0.5f): ClothQualityReport {
        var invalid = 0
        for (v in 0 until vertexCount) {
            val o = v * 3
            if (!p[o].isFinite() || !p[o + 1].isFinite() || !p[o + 2].isFinite()) invalid++
        }
        val overLimit = (if (overstretchThreshold.isFinite()) overstretchThreshold else 1.25f).coerceIn(1.01f, 10f)
        val compressLimit = (if (compressionThreshold.isFinite()) compressionThreshold else 0.5f).coerceIn(0.01f, 0.99f)
        var checked = 0; var over = 0; var compressed = 0; var collapsed = 0
        var maxRatio = 1f; var strainSum = 0.0
        for (constraint in stretch + bend) {
            if (constraint.rest <= 1e-8f) continue
            val a = constraint.a * 3; val b = constraint.b * 3
            val dx = p[b] - p[a]; val dy = p[b + 1] - p[a + 1]; val dz = p[b + 2] - p[a + 2]
            val length = sqrt(dx * dx + dy * dy + dz * dz)
            if (!length.isFinite()) { invalid++; continue }
            val ratio = length / constraint.rest
            checked++; maxRatio = max(maxRatio, ratio); strainSum += kotlin.math.abs(ratio - 1f).toDouble()
            if (ratio > overLimit) over++
            if (ratio < compressLimit) compressed++
            if (ratio < 0.15f) collapsed++
        }
        return ClothQualityReport(vertexCount, invalid, checked, over, compressed, collapsed,
            maxRatio, if (checked > 0) (strainSum / checked).toFloat() else 0f)
    }

    fun reset() {
        rest.copyInto(p); rest.copyInto(previous); velocity.fill(0f)
        stretch.forEach { it.lambda = 0f }; bend.forEach { it.lambda = 0f }
        sweptCapsules = emptyList(); lastStepSafetyReport = null
        for ((_, pin) in pins) setPosition(pin.index, pin.x, pin.y, pin.z)
    }

    /** Executa um passo de simulação e devolve um snapshot das posições (3 floats por partícula). */
    fun step(
        deltaSeconds: Float,
        gravityY: Float = -9.81f,
        windX: Float = 0f, windY: Float = 0f, windZ: Float = 0f,
        substeps: Int = 4, iterations: Int = 8,
        damping: Float = 0.025f,
        groundY: Float? = 0f,
        selfCollision: Boolean = false
    ): FloatArray {
        if (vertexCount == 0 || !deltaSeconds.isFinite() || deltaSeconds <= 0f) return p.copyOf()
        val steps = substeps.coerceIn(1, 16)
        val dt = deltaSeconds.coerceAtMost(0.1f) / steps
        val iters = iterations.coerceIn(1, 32)
        val damp = (if (damping.isFinite()) damping else 0.025f).coerceIn(0f, 0.99f)
        val gx = if (gravityY.isFinite()) gravityY else -9.81f
        val wx = if (windX.isFinite()) windX else 0f
        val wy = if (windY.isFinite()) windY else 0f
        val wz = if (windZ.isFinite()) windZ else 0f
        val fullFrameSweeps = sweptCapsules
        repeat(steps) { substepIndex ->
            if (fullFrameSweeps.isNotEmpty()) {
                val t0 = substepIndex.toFloat() / steps.toFloat()
                val t1 = (substepIndex + 1).toFloat() / steps.toFloat()
                fun at(a: ClothCapsule, b: ClothCapsule, t: Float) = ClothCapsule(
                    a.ax + (b.ax - a.ax) * t, a.ay + (b.ay - a.ay) * t, a.az + (b.az - a.az) * t,
                    a.bx + (b.bx - a.bx) * t, a.by + (b.by - a.by) * t, a.bz + (b.bz - a.bz) * t,
                    a.radius + (b.radius - a.radius) * t
                )
                sweptCapsules = fullFrameSweeps.map { pair ->
                    SweptClothCapsule(at(pair.previous, pair.current, t0), at(pair.previous, pair.current, t1))
                }
            }
            p.copyInto(previous)
            for (i in 0 until vertexCount) {
                if (invMass[i] <= 0f) continue
                val o = i * 3
                velocity[o] += wx * dt
                velocity[o + 1] += (gx + wy) * dt
                velocity[o + 2] += wz * dt
                p[o] += velocity[o] * dt
                p[o + 1] += velocity[o + 1] * dt
                p[o + 2] += velocity[o + 2] * dt
            }
            for (c in stretch) c.lambda = 0f
            for (c in bend) c.lambda = 0f
            repeat(iters) {
                for (c in stretch) solveDistance(c, dt)
                for (c in bend) solveDistance(c, dt)
                for ((_, pin) in pins) setPosition(pin.index, pin.x, pin.y, pin.z)
                if (groundY != null) for (v in 0 until vertexCount) {
                    if (invMass[v] <= 0f) continue
                    val o = v * 3
                    if (p[o + 1] < groundY) p[o + 1] = groundY
                }
                if (spheres.isNotEmpty() || capsules.isNotEmpty() || sweptCapsules.isNotEmpty() || boxes.isNotEmpty() || surfaceTriangles.isNotEmpty()) solveCollisions()
                if (selfCollision && vertexCount <= 2048) solveSelfCollision(0.0025f)
            }
            val keep = 1f - damp
            for (i in 0 until vertexCount) {
                if (invMass[i] <= 0f) { velocity[i * 3] = 0f; velocity[i * 3 + 1] = 0f; velocity[i * 3 + 2] = 0f; continue }
                val o = i * 3
                velocity[o] = (p[o] - previous[o]) / dt * keep
                velocity[o + 1] = (p[o + 1] - previous[o + 1]) / dt * keep
                velocity[o + 2] = (p[o + 2] - previous[o + 2]) / dt * keep
            }
        }
        // A varredura pertence a um único frame; passos futuros mantêm a cápsula na pose final
        // até que o chamador forneça o próximo par anterior/atual.
        if (fullFrameSweeps.isNotEmpty()) {
            sweptCapsules = fullFrameSweeps.map { SweptClothCapsule(it.current, it.current) }
        }
        return p.copyOf()
    }

    /**
     * Executa um passo XPBD transacional: se aparecer NaN/Infinity, coordenada absurda,
     * deslocamento extremo ou velocidade fora do limite, restaura partículas, velocidades,
     * histórico, multiplicadores XPBD e cápsulas varridas ao snapshot anterior.
     * O modo clássico [step] continua disponível para ferramentas offline sem esse guard.
     */
    fun stepGuarded(
        deltaSeconds: Float,
        gravityY: Float = -9.81f,
        windX: Float = 0f, windY: Float = 0f, windZ: Float = 0f,
        substeps: Int = 4, iterations: Int = 8,
        damping: Float = 0.025f,
        groundY: Float? = 0f,
        selfCollision: Boolean = false,
        safety: ClothStepSafetyConfig = ClothStepSafetyConfig()
    ): ClothStepSafetyResult {
        val beforeP = p.copyOf(); val beforePrevious = previous.copyOf(); val beforeVelocity = velocity.copyOf()
        val stretchLambda = FloatArray(stretch.size) { stretch[it].lambda }
        val bendLambda = FloatArray(bend.size) { bend[it].lambda }
        val beforeSweeps = sweptCapsules
        val maxDisp = safety.maxDisplacementPerStep.takeIf { it.isFinite() && it > 0f } ?: 8f
        val maxSpeedLimit = safety.maxSpeed.takeIf { it.isFinite() && it > 0f } ?: 500f
        val maxCoord = safety.maxAbsoluteCoordinate.takeIf { it.isFinite() && it > 0f } ?: 100_000f
        var badFinite = 0; var badDisplacement = 0; var badSpeed = 0
        var observedDisplacement = 0f; var observedSpeed = 0f
        var reason = "OK"
        val returned = try {
            step(deltaSeconds, gravityY, windX, windY, windZ, substeps, iterations, damping, groundY, selfCollision)
        } catch (ex: Exception) {
            reason = "Falha durante o solver: ${ex.message ?: ex.javaClass.simpleName}"
            beforeP.copyOf()
        }
        val dt = deltaSeconds.takeIf { it.isFinite() && it > 1e-6f }?.coerceAtMost(0.1f) ?: (1f / 60f)
        for (v in 0 until vertexCount) {
            val o = v * 3
            val x = returned.getOrElse(o) { Float.NaN }; val y = returned.getOrElse(o + 1) { Float.NaN }; val z = returned.getOrElse(o + 2) { Float.NaN }
            if (!x.isFinite() || !y.isFinite() || !z.isFinite() || abs(x) > maxCoord || abs(y) > maxCoord || abs(z) > maxCoord) { badFinite++; continue }
            val dx = x - beforeP[o]; val dy = y - beforeP[o + 1]; val dz = z - beforeP[o + 2]
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            if (d.isFinite()) {
                observedDisplacement = max(observedDisplacement, d)
                val speed = d / dt
                observedSpeed = max(observedSpeed, speed)
                if (d > maxDisp) badDisplacement++
                if (speed > maxSpeedLimit) badSpeed++
            } else badFinite++
        }
        val accepted = badFinite == 0 && badDisplacement == 0 && badSpeed == 0 && reason == "OK"
        if (!accepted) {
            beforeP.copyInto(p); beforePrevious.copyInto(previous); beforeVelocity.copyInto(velocity)
            stretch.forEachIndexed { i, c -> c.lambda = stretchLambda[i] }
            bend.forEachIndexed { i, c -> c.lambda = bendLambda[i] }
            sweptCapsules = beforeSweeps
            if (reason == "OK") reason = when {
                badFinite > 0 -> "Partículas não finitas ou coordenadas fora do limite"
                badDisplacement > 0 -> "Deslocamento por passo excedeu ${maxDisp} unidades"
                else -> "Velocidade excedeu ${maxSpeedLimit} unidades/s"
            }
        }
        val report = ClothStepSafetyReport(accepted, vertexCount, badFinite, badDisplacement, badSpeed,
            observedDisplacement, observedSpeed, reason)
        lastStepSafetyReport = report
        return ClothStepSafetyResult(if (accepted) returned else beforeP.copyOf(), report)
    }

    /**
     * Executa um passo XPBD com partículas convertidas para o espaço animado do corpo.
     * As colisões recebidas em setColliders() devem estar nesse mesmo espaço. Ao retornar,
     * a posição/velocidade são convertidas de volta ao espaço local pré-skinning do cache.
     */
    fun stepSkinned(
        deltaSeconds: Float,
        transform: ClothSkinTransform,
        gravityY: Float = -9.81f,
        windX: Float = 0f, windY: Float = 0f, windZ: Float = 0f,
        substeps: Int = 4, iterations: Int = 8,
        damping: Float = 0.025f,
        groundY: Float? = null,
        selfCollision: Boolean = false,
        safety: ClothStepSafetyConfig? = null
    ): FloatArray {
        val tmp = FloatArray(3)
        fun transformArray(array: FloatArray, localToWorld: Boolean, historical: Boolean = false, vector: Boolean = false) {
            for (v in 0 until vertexCount) {
                val o = v * 3
                when {
                    vector && localToWorld && historical -> transform.toWorldPreviousVector(v, array[o], array[o + 1], array[o + 2], tmp)
                    vector && localToWorld -> transform.toWorldVector(v, array[o], array[o + 1], array[o + 2], tmp)
                    vector -> transform.toLocalVector(v, array[o], array[o + 1], array[o + 2], tmp)
                    historical -> transform.toWorldPreviousPosition(v, array[o], array[o + 1], array[o + 2], tmp)
                    localToWorld -> transform.toWorldPosition(v, array[o], array[o + 1], array[o + 2], tmp)
                    else -> transform.toLocalPosition(v, array[o], array[o + 1], array[o + 2], tmp)
                }
                array[o] = tmp[0]; array[o + 1] = tmp[1]; array[o + 2] = tmp[2]
            }
        }
        // Flags permitem restaurar o estado mesmo que uma conversão ou o solver falhe.
        var currentWorld = false
        var historyWorld = false
        var velocityWorld = false
        val transformedPins = ArrayList<Pin>(pins.size)
        try {
            // Partículas/velocidades começam na pose anterior; colisores e âncoras já estão na pose atual.
            // Assim o corpo pode avançar enquanto a roupa conserva inércia no espaço do personagem.
            transformArray(p, localToWorld = true, historical = true); currentWorld = true
            transformArray(previous, localToWorld = true, historical = true); historyWorld = true
            transformArray(velocity, localToWorld = true, historical = true, vector = true); velocityWorld = true
            for (pin in pins.values) {
                transform.toWorldPosition(pin.index, pin.x, pin.y, pin.z, tmp)
                pin.x = tmp[0]; pin.y = tmp[1]; pin.z = tmp[2]
                transformedPins += pin
            }
            if (safety == null) step(deltaSeconds, gravityY, windX, windY, windZ, substeps, iterations, damping, groundY, selfCollision)
            else stepGuarded(deltaSeconds, gravityY, windX, windY, windZ, substeps, iterations, damping, groundY, selfCollision, safety).positions
        } finally {
            if (currentWorld) transformArray(p, localToWorld = false)
            if (historyWorld) transformArray(previous, localToWorld = false)
            if (velocityWorld) transformArray(velocity, localToWorld = false, vector = true)
            for (pin in transformedPins) {
                transform.toLocalPosition(pin.index, pin.x, pin.y, pin.z, tmp)
                pin.x = tmp[0]; pin.y = tmp[1]; pin.z = tmp[2]
                setPosition(pin.index, pin.x, pin.y, pin.z)
            }
        }
        return p.copyOf()
    }

    /** Faz bake de vários passos; o chamador pode cancelar entre frames e gravar o cache externamente. */
    fun bake(frames: Int, fps: Int = 30, onFrame: ((Int, FloatArray) -> Unit)? = null): List<FloatArray> {
        val count = frames.coerceIn(0, 100000); val rate = fps.coerceIn(1, 240)
        val out = ArrayList<FloatArray>(count)
        for (f in 0 until count) {
            val state = step(1f / rate)
            out.add(state)
            onFrame?.invoke(f, state.copyOf())
        }
        return out
    }

    /** Variante streaming para renders longos: entrega cada quadro sem manter todo o bake em memória. */
    fun bakeStreaming(frames: Int, fps: Int = 30, onFrame: (Int, FloatArray) -> Unit): FloatArray {
        val count = frames.coerceIn(0, 1_000_000); val rate = fps.coerceIn(1, 240)
        var last = p.copyOf()
        for (f in 0 until count) {
            last = step(1f / rate)
            onFrame(f, last.copyOf())
        }
        return last
    }

    private fun solveDistance(c: DistanceConstraint, dt: Float) {
        val a = c.a * 3; val b = c.b * 3
        val dx = p[b] - p[a]; val dy = p[b + 1] - p[a + 1]; val dz = p[b + 2] - p[a + 2]
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len < 1e-8f) return
        val wa = invMass[c.a]; val wb = invMass[c.b]
        val alpha = c.compliance / (dt * dt)
        val dl = (-(len - c.rest) - alpha * c.lambda) / (wa + wb + alpha).coerceAtLeast(1e-9f)
        c.lambda += dl
        val nx = dx / len; val ny = dy / len; val nz = dz / len
        p[a] -= wa * nx * dl; p[a + 1] -= wa * ny * dl; p[a + 2] -= wa * nz * dl
        p[b] += wb * nx * dl; p[b + 1] += wb * ny * dl; p[b + 2] += wb * nz * dl
    }

    private fun solveCollisions() {
        val triangleVisited = if (surfaceTriangles.isNotEmpty()) IntArray(surfaceTriangles.size) else IntArray(0)
        var triangleGeneration = 0
        for (v in 0 until vertexCount) {
            if (invMass[v] <= 0f) continue
            val o = v * 3
            for (s in spheres) {
                val dx=p[o]-s.x; val dy=p[o+1]-s.y; val dz=p[o+2]-s.z
                val d2=dx*dx+dy*dy+dz*dz; val r2=s.radius*s.radius
                if (d2 < r2) {
                    if (d2 < 1e-12f) { p[o]=s.x; p[o+1]=s.y+s.radius; p[o+2]=s.z }
                    else { val k=s.radius/sqrt(d2); p[o]=s.x+dx*k; p[o+1]=s.y+dy*k; p[o+2]=s.z+dz*k }
                }
            }
            for (c in capsules) {
                val abx=c.bx-c.ax; val aby=c.by-c.ay; val abz=c.bz-c.az
                val apx=p[o]-c.ax; val apy=p[o+1]-c.ay; val apz=p[o+2]-c.az
                val den=abx*abx+aby*aby+abz*abz
                val t=if (den<1e-9f) 0f else ((apx*abx+apy*aby+apz*abz)/den).coerceIn(0f,1f)
                val cx=c.ax+abx*t; val cy=c.ay+aby*t; val cz=c.az+abz*t
                val dx=p[o]-cx; val dy=p[o+1]-cy; val dz=p[o+2]-cz
                val d2=dx*dx+dy*dy+dz*dz
                if (d2 < c.radius*c.radius) {
                    if (d2 < 1e-12f) { p[o]=cx; p[o+1]=cy+c.radius; p[o+2]=cz }
                    else { val k=c.radius/sqrt(d2); p[o]=cx+dx*k; p[o+1]=cy+dy*k; p[o+2]=cz+dz*k }
                }
            }
            for (swept in sweptCapsules) collideSweptCapsule(o, swept)
            for (box in boxes) collideBox(o, box)
            if (surfaceTriangles.isNotEmpty()) {
                if (triangleGeneration == Int.MAX_VALUE) { triangleVisited.fill(0); triangleGeneration = 1 } else triangleGeneration++
                collideSurface(o, triangleVisited, triangleGeneration)
            }
        }
    }

    /** CCD discreto com refinamento temporal: testa a trajetória do vértice contra a cápsula interpolada. */
    private fun collideSweptCapsule(o: Int, swept: SweptClothCapsule) {
        val start = swept.previous
        val end = swept.current
        val px0 = previous[o]; val py0 = previous[o + 1]; val pz0 = previous[o + 2]
        val px1 = p[o]; val py1 = p[o + 1]; val pz1 = p[o + 2]
        val targetRadius = max(start.radius, end.radius) + collisionThickness
        val radius2 = targetRadius * targetRadius

        fun distanceSquared(t: Float): Float {
            val px = px0 + (px1 - px0) * t
            val py = py0 + (py1 - py0) * t
            val pz = pz0 + (pz1 - pz0) * t
            val ax = start.ax + (end.ax - start.ax) * t
            val ay = start.ay + (end.ay - start.ay) * t
            val az = start.az + (end.az - start.az) * t
            val bx = start.bx + (end.bx - start.bx) * t
            val by = start.by + (end.by - start.by) * t
            val bz = start.bz + (end.bz - start.bz) * t
            val abx = bx - ax; val aby = by - ay; val abz = bz - az
            val den = abx * abx + aby * aby + abz * abz
            val u = if (den <= 1e-10f) 0f else (((px - ax) * abx + (py - ay) * aby + (pz - az) * abz) / den).coerceIn(0f, 1f)
            val dx = px - (ax + abx * u); val dy = py - (ay + aby * u); val dz = pz - (az + abz * u)
            return dx * dx + dy * dy + dz * dz
        }

        var low = 0f
        var high = -1f
        val samples = 10
        var previousT = 0f
        for (sample in 0..samples) {
            val t = sample.toFloat() / samples
            if (distanceSquared(t) < radius2) {
                high = t
                low = previousT
                break
            }
            previousT = t
        }
        if (high < 0f) return
        repeat(6) {
            val mid = (low + high) * 0.5f
            if (distanceSquared(mid) < radius2) high = mid else low = mid
        }

        val t = high
        val hx = px0 + (px1 - px0) * t
        val hy = py0 + (py1 - py0) * t
        val hz = pz0 + (pz1 - pz0) * t
        val ax = start.ax + (end.ax - start.ax) * t
        val ay = start.ay + (end.ay - start.ay) * t
        val az = start.az + (end.az - start.az) * t
        val bx = start.bx + (end.bx - start.bx) * t
        val by = start.by + (end.by - start.by) * t
        val bz = start.bz + (end.bz - start.bz) * t
        val abx = bx - ax; val aby = by - ay; val abz = bz - az
        val den = abx * abx + aby * aby + abz * abz
        val u = if (den <= 1e-10f) 0f else (((hx - ax) * abx + (hy - ay) * aby + (hz - az) * abz) / den).coerceIn(0f, 1f)
        val qx = ax + abx * u; val qy = ay + aby * u; val qz = az + abz * u
        var nx = hx - qx; var ny = hy - qy; var nz = hz - qz
        var n2 = nx * nx + ny * ny + nz * nz
        if (n2 <= 1e-12f) {
            // Normal estável perpendicular ao eixo da cápsula em caso de contato exatamente central.
            nx = if (kotlin.math.abs(aby) < 0.8f * kotlin.math.sqrt(den.coerceAtLeast(1e-12f))) 0f else 1f
            ny = if (nx == 0f) 0f else 0f
            nz = if (nx == 0f) 1f else 0f
            n2 = nx * nx + ny * ny + nz * nz
        }
        val invLen = 1f / kotlin.math.sqrt(n2.coerceAtLeast(1e-12f))
        nx *= invLen; ny *= invLen; nz *= invLen
        val finalQx = end.ax + (end.bx - end.ax) * u
        val finalQy = end.ay + (end.by - end.ay) * u
        val finalQz = end.az + (end.bz - end.az) * u
        val finalRadius = max(end.radius, start.radius) + collisionThickness
        p[o] = finalQx + nx * finalRadius
        p[o + 1] = finalQy + ny * finalRadius
        p[o + 2] = finalQz + nz * finalRadius
    }

    private fun rotateEuler(x0: Float, y0: Float, z0: Float, rx: Float, ry: Float, rz: Float): FloatArray {
        val sx=kotlin.math.sin(rx); val cx=kotlin.math.cos(rx)
        val sy=kotlin.math.sin(ry); val cy=kotlin.math.cos(ry)
        val sz=kotlin.math.sin(rz); val cz=kotlin.math.cos(rz)
        val y1=y0*cx-z0*sx; val z1=y0*sx+z0*cx
        val x2=x0*cy+z1*sy; val z2=-x0*sy+z1*cy
        return floatArrayOf(x2*cz-y1*sz, x2*sz+y1*cz, z2)
    }

    /** Inversa exata de rotateEuler: Rz(-z), Ry(-y), Rx(-x). */
    private fun inverseRotateEuler(x0: Float, y0: Float, z0: Float, rx: Float, ry: Float, rz: Float): FloatArray {
        val sz=kotlin.math.sin(rz); val cz=kotlin.math.cos(rz)
        val x1=x0*cz+y0*sz; val y1=-x0*sz+y0*cz
        val sy=kotlin.math.sin(ry); val cy=kotlin.math.cos(ry)
        val x2=x1*cy-z0*sy; val z2=x1*sy+z0*cy
        val sx=kotlin.math.sin(rx); val cx=kotlin.math.cos(rx)
        return floatArrayOf(x2,y1*cx+z2*sx,-y1*sx+z2*cx)
    }

    private fun collideBox(o: Int, box: ClothBox) {
        val rel=inverseRotateEuler(p[o]-box.x,p[o+1]-box.y,p[o+2]-box.z,box.rx,box.ry,box.rz)
        val hx=box.sizeX; val hy=box.sizeY; val hz=box.sizeZ
        if (kotlin.math.abs(rel[0]) > hx || kotlin.math.abs(rel[1]) > hy || kotlin.math.abs(rel[2]) > hz) return
        val dx=hx-kotlin.math.abs(rel[0]); val dy=hy-kotlin.math.abs(rel[1]); val dz=hz-kotlin.math.abs(rel[2])
        when (min(dx,min(dy,dz))) {
            dx -> rel[0]=(if (rel[0] < 0f) -1f else 1f)*(hx+collisionThickness)
            dy -> rel[1]=(if (rel[1] < 0f) -1f else 1f)*(hy+collisionThickness)
            else -> rel[2]=(if (rel[2] < 0f) -1f else 1f)*(hz+collisionThickness)
        }
        val world=rotateEuler(rel[0],rel[1],rel[2],box.rx,box.ry,box.rz)
        p[o]=box.x+world[0]; p[o+1]=box.y+world[1]; p[o+2]=box.z+world[2]
    }

    private fun collideSurface(o: Int, visited: IntArray, generation: Int) {
        val cx=floor(p[o]/surfaceCellSize).toInt(); val cy=floor(p[o+1]/surfaceCellSize).toInt(); val cz=floor(p[o+2]/surfaceCellSize).toInt()
        val min2=collisionThickness*collisionThickness
        fun project(index: Int) {
            if (visited[index] == generation) return
            visited[index] = generation
            val t=surfaceTriangles[index]
            if (p[o] < t.minX || p[o] > t.maxX || p[o+1] < t.minY || p[o+1] > t.maxY || p[o+2] < t.minZ || p[o+2] > t.maxZ) return
            val q=closestPointTriangle(p[o],p[o+1],p[o+2],t)
            val dx=p[o]-q[0]; val dy=p[o+1]-q[1]; val dz=p[o+2]-q[2]
            val distance2 = dx*dx+dy*dy+dz*dz
            if (distance2 >= min2) return
            if (distance2 > 1e-12f) {
                // Nas bordas, a normal radial da distância ao triângulo evita empurrar a roupa na direção errada.
                val scale = collisionThickness / sqrt(distance2)
                p[o]=q[0]+dx*scale; p[o+1]=q[1]+dy*scale; p[o+2]=q[2]+dz*scale
            } else {
                val side=if ((previous[o]-q[0])*t.nx+(previous[o+1]-q[1])*t.ny+(previous[o+2]-q[2])*t.nz < 0f) -1f else 1f
                p[o]=q[0]+t.nx*collisionThickness*side
                p[o+1]=q[1]+t.ny*collisionThickness*side
                p[o+2]=q[2]+t.nz*collisionThickness*side
            }
        }
        largeSurfaceTriangles.forEach(::project)
        surfaceBuckets[GridCell(cx,cy,cz)]?.forEach(::project)
    }

    private fun closestPointTriangle(px: Float, py: Float, pz: Float, t: SurfaceTriangle): FloatArray {
        val abx=t.bx-t.ax; val aby=t.by-t.ay; val abz=t.bz-t.az
        val acx=t.cx-t.ax; val acy=t.cy-t.ay; val acz=t.cz-t.az
        val apx=px-t.ax; val apy=py-t.ay; val apz=pz-t.az
        val d1=abx*apx+aby*apy+abz*apz; val d2=acx*apx+acy*apy+acz*apz
        if (d1<=0f && d2<=0f) return floatArrayOf(t.ax,t.ay,t.az)
        val bpx=px-t.bx; val bpy=py-t.by; val bpz=pz-t.bz
        val d3=abx*bpx+aby*bpy+abz*bpz; val d4=acx*bpx+acy*bpy+acz*bpz
        if (d3>=0f && d4<=d3) return floatArrayOf(t.bx,t.by,t.bz)
        val vc=d1*d4-d3*d2
        if (vc<=0f && d1>=0f && d3<=0f) { val v=d1/(d1-d3); return floatArrayOf(t.ax+v*abx,t.ay+v*aby,t.az+v*abz) }
        val cpx=px-t.cx; val cpy=py-t.cy; val cpz=pz-t.cz
        val d5=abx*cpx+aby*cpy+abz*cpz; val d6=acx*cpx+acy*cpy+acz*cpz
        if (d6>=0f && d5<=d6) return floatArrayOf(t.cx,t.cy,t.cz)
        val vb=d5*d2-d1*d6
        if (vb<=0f && d2>=0f && d6<=0f) { val w=d2/(d2-d6); return floatArrayOf(t.ax+w*acx,t.ay+w*acy,t.az+w*acz) }
        val va=d3*d6-d5*d4
        if (va<=0f && d4-d3>=0f && d5-d6>=0f) { val w=(d4-d3)/((d4-d3)+(d5-d6)); return floatArrayOf(t.bx+w*(t.cx-t.bx),t.by+w*(t.cy-t.by),t.bz+w*(t.cz-t.bz)) }
        val denom=1f/(va+vb+vc).coerceAtLeast(1e-12f); val v=vb*denom; val w=vc*denom
        return floatArrayOf(t.ax+abx*v+acx*w,t.ay+aby*v+acy*w,t.az+abz*v+acz*w)
    }

    /** Auto-colisão espacialmente acelerada; exclui pares até 2 arestas de distância topológica. */
    private fun solveSelfCollision(distance: Float) {
        if (distance <= 0f) return
        data class Cell(val x: Int, val y: Int, val z: Int)
        fun cell(x: Float, y: Float, z: Float) = Cell(floor(x / distance).toInt(), floor(y / distance).toInt(), floor(z / distance).toInt())
        val buckets = HashMap<Cell, MutableList<Int>>()
        val min2 = distance * distance
        for (a in 0 until vertexCount) {
            val oa = a * 3
            val ca = cell(p[oa], p[oa + 1], p[oa + 2])
            for (dxCell in -1..1) for (dyCell in -1..1) for (dzCell in -1..1) {
                val bucket = buckets[Cell(ca.x + dxCell, ca.y + dyCell, ca.z + dzCell)] ?: continue
                for (b in bucket) {
                    if (pairKey(a, b) in selfCollisionExclusions) continue
                    val wa = invMass[a]; val wb = invMass[b]
                    if (wa + wb <= 0f) continue
                    val ob = b * 3
                    var dx = p[oa] - p[ob]; var dy = p[oa + 1] - p[ob + 1]; var dz = p[oa + 2] - p[ob + 2]
                    var d2 = dx * dx + dy * dy + dz * dz
                    if (d2 >= min2) continue
                    if (d2 < 1e-12f) {
                        val share = distance / (wa + wb)
                        when ((a + b) % 3) {
                            0 -> { p[oa] += share * wa; p[ob] -= share * wb }
                            1 -> { p[oa + 1] += share * wa; p[ob + 1] -= share * wb }
                            else -> { p[oa + 2] += share * wa; p[ob + 2] -= share * wb }
                        }
                        continue
                    }
                    val d = sqrt(d2)
                    val push = (distance - d) / d / (wa + wb)
                    p[oa] += dx * push * wa; p[oa + 1] += dy * push * wa; p[oa + 2] += dz * push * wa
                    p[ob] -= dx * push * wb; p[ob + 1] -= dy * push * wb; p[ob + 2] -= dz * push * wb
                }
            }
            buckets.getOrPut(ca) { ArrayList() }.add(a)
        }
    }

    private fun pairKey(a0: Int, b0: Int): Long {
        val a = min(a0, b0); val b = max(a0, b0)
        return (a.toLong() shl 32) or (b.toLong() and 0xffffffffL)
    }

    companion object {
        /** Constrói constraints de estiramento nas arestas e dobra entre vértices opostos de triângulos adjacentes. */
        private fun pairKeyStatic(a0: Int, b0: Int): Long {
            val a = min(a0, b0); val b = max(a0, b0)
            return (a.toLong() shl 32) or (b.toLong() and 0xffffffffL)
        }

        fun fromMesh(
            positions: FloatArray, triangles: IntArray,
            particleMass: Float = 1f,
            stretchCompliance: Float = 0f,
            bendCompliance: Float = 0.0005f
        ): ClothXpbd {
            require(positions.size % 3 == 0) { "Posições devem conter XYZ por vértice" }
            require(positions.all { it.isFinite() }) { "Malha contém coordenadas não finitas" }
            require(triangles.size % 3 == 0) { "Índices devem conter triângulos" }
            val n = positions.size / 3
            val mass = particleMass.takeIf { it.isFinite() && it > 1e-6f } ?: 1f
            val inv = FloatArray(n) { 1f / mass }
            val edgeMap = HashMap<Long, MutableList<Int>>()
            fun edgeKey(a0: Int, b0: Int): Long { val a = min(a0, b0); val b = max(a0, b0); return (a.toLong() shl 32) or (b.toLong() and 0xffffffffL) }
            for (i in triangles.indices step 3) {
                val a = triangles[i]; val b = triangles[i + 1]; val c = triangles[i + 2]
                require(a in 0 until n && b in 0 until n && c in 0 until n) { "Índice de triângulo fora da malha" }
                edgeMap.getOrPut(edgeKey(a, b)) { ArrayList() }.add(c)
                edgeMap.getOrPut(edgeKey(b, c)) { ArrayList() }.add(a)
                edgeMap.getOrPut(edgeKey(c, a)) { ArrayList() }.add(b)
            }
            fun dist(a: Int, b: Int): Float {
                val x = positions[a * 3] - positions[b * 3]; val y = positions[a * 3 + 1] - positions[b * 3 + 1]; val z = positions[a * 3 + 2] - positions[b * 3 + 2]
                return sqrt(x * x + y * y + z * z)
            }
            val stretchAlpha = stretchCompliance.takeIf { it.isFinite() }?.coerceAtLeast(0f) ?: 0f
            val bendAlpha = bendCompliance.takeIf { it.isFinite() }?.coerceAtLeast(0f) ?: 0.0005f
            val stretch = edgeMap.keys.map { key ->
                val a = (key shr 32).toInt(); val b = key.toInt()
                DistanceConstraint(a, b, dist(a, b), stretchAlpha)
            }
            val bendPairs = HashSet<Long>()
            val bend = ArrayList<DistanceConstraint>()
            for ((_, opposite) in edgeMap) if (opposite.size >= 2) {
                val a = opposite[0]; val b = opposite[1]
                val key = edgeKey(a, b)
                if (a != b && bendPairs.add(key)) bend.add(DistanceConstraint(min(a, b), max(a, b), dist(a, b), bendAlpha))
            }
            // Exclui vizinhos topológicos diretos e de segundo anel da auto-colisão.
            val adjacency = Array(n) { LinkedHashSet<Int>() }
            for (i in triangles.indices step 3) {
                val a = triangles[i]; val b = triangles[i + 1]; val c = triangles[i + 2]
                adjacency[a].add(b); adjacency[a].add(c)
                adjacency[b].add(a); adjacency[b].add(c)
                adjacency[c].add(a); adjacency[c].add(b)
            }
            val exclusions = HashSet<Long>()
            for (a in 0 until n) {
                for (b in adjacency[a]) exclusions.add(pairKeyStatic(a, b))
                for (b in adjacency[a]) for (c in adjacency[b]) if (c != a) exclusions.add(pairKeyStatic(a, c))
            }
            return ClothXpbd(positions, inv, stretch, bend, exclusions)
        }
    }
}
