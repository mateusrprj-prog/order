package studio.mmd.rig

/** Região da saia que recebe o pós-ajuste automático. O falloff evita uma fronteira abrupta. */
enum class SkirtCorrectionRegion { ALL, FRONT, BACK, LEFT, RIGHT }

data class SkirtCorrectionComparison(val before: FloatArray, val after: FloatArray) {
    fun beforeCopy() = before.copyOf()
    fun afterCopy() = after.copyOf()
}

/**
 * Histórico transacional leve para correções de tecido. Mantém snapshots independentes,
 * limite de memória e pilhas separadas de undo/redo. Não altera o PMX de origem.
 */
class SkirtGuardCorrectionHistory(
    private val maxEntries: Int = 8,
    private val maxStoredFloats: Int = 4_000_000
) {
    private data class Entry(val before: FloatArray, val after: FloatArray)
    private val undoStack = ArrayDeque<Entry>()
    private val redoStack = ArrayDeque<Entry>()
    private var storedFloats = 0

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
    val size: Int get() = undoStack.size

    @Synchronized
    fun record(before: FloatArray, after: FloatArray): Boolean {
        if (before.size != after.size || before.isEmpty() || before.size.toLong() * 2L > maxStoredFloats.toLong()) return false
        if (!before.all(Float::isFinite) || !after.all(Float::isFinite)) return false
        val entry = Entry(before.copyOf(), after.copyOf())
        while (redoStack.isNotEmpty()) {
            val removed = redoStack.removeFirst()
            storedFloats -= removed.before.size + removed.after.size
        }
        while (undoStack.isNotEmpty() && (undoStack.size + redoStack.size >= maxEntries.coerceAtLeast(1) || storedFloats + entry.before.size * 2 > maxStoredFloats)) {
            val removed = undoStack.removeFirst()
            storedFloats -= removed.before.size + removed.after.size
        }
        if (entry.before.size * 2 > maxStoredFloats) return false
        undoStack.add(entry)
        storedFloats += entry.before.size + entry.after.size
        return true
    }

    @Synchronized
    fun undo(current: FloatArray): FloatArray? {
        val entry = undoStack.removeLastOrNull() ?: return null
        if (entry.before.size != current.size || !current.contentEquals(entry.after)) {
            undoStack.add(entry)
            return null
        }
        redoStack.add(Entry(entry.before.copyOf(), current.copyOf()))
        return entry.before.copyOf()
    }

    @Synchronized
    fun redo(current: FloatArray): FloatArray? {
        val entry = redoStack.removeLastOrNull() ?: return null
        if (entry.after.size != current.size || !current.contentEquals(entry.before)) {
            redoStack.add(entry)
            return null
        }
        undoStack.add(Entry(entry.before.copyOf(), entry.after.copyOf()))
        return entry.after.copyOf()
    }

    @Synchronized
    fun comparison(): SkirtCorrectionComparison? {
        val entry = undoStack.lastOrNull() ?: redoStack.lastOrNull() ?: return null
        return SkirtCorrectionComparison(entry.before.copyOf(), entry.after.copyOf())
    }

    @Synchronized
    fun clear() {
        undoStack.clear(); redoStack.clear(); storedFloats = 0
    }
}
