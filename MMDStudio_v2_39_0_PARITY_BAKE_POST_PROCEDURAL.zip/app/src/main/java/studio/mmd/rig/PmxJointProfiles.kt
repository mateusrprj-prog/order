package studio.mmd.rig

import studio.mmd.mmd.PmxJoint

/** Limites de translação/rotação expressas no referencial local da junta. */
data class PmxJointConstraintProfile(
    val positionMin: FloatArray, val positionMax: FloatArray,
    val rotationMin: FloatArray, val rotationMax: FloatArray,
    val springPosition: FloatArray, val springRotation: FloatArray,
    val label: String, val approximate: Boolean
)

/**
 * Semântica PMX 2.0/2.1 dos seis tipos de junta.
 * O solver do app é posicional próprio (não Bullet); Slider/Hinge/ConeTwist usam restrições axiais
 * compatíveis com os graus de liberdade do tipo, mas não são integração Bullet bit a bit.
 */
object PmxJointProfiles {
    private const val FREE = 100000f
    private fun axis(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)
    private fun copy3(a: FloatArray, default: Float = 0f) = FloatArray(3) { a.getOrNull(it)?.takeIf { v -> v.isFinite() } ?: default }

    fun resolve(joint: PmxJoint): PmxJointConstraintProfile {
        val pMin = copy3(joint.posMin); val pMax = copy3(joint.posMax)
        val rMin = copy3(joint.rotMin); val rMax = copy3(joint.rotMax)
        val sPos = copy3(joint.springPos).map { it.coerceAtLeast(0f) }.toFloatArray()
        val sRot = copy3(joint.springRot).map { it.coerceAtLeast(0f) }.toFloatArray()
        return when (joint.type) {
            0 -> PmxJointConstraintProfile(pMin,pMax,rMin,rMax,sPos,sRot,"Spring 6DOF",false)
            1 -> PmxJointConstraintProfile(pMin,pMax,rMin,rMax,FloatArray(3),FloatArray(3),"6DOF",false)
            2 -> PmxJointConstraintProfile(axis(0f,0f,0f),axis(0f,0f,0f),axis(-FREE,-FREE,-FREE),axis(FREE,FREE,FREE),FloatArray(3),FloatArray(3),"Point-to-Point",false)
            3 -> PmxJointConstraintProfile(axis(0f,0f,0f),axis(0f,0f,0f),rMin,rMax,FloatArray(3),FloatArray(3),"Cone Twist (limites angulares Euler aproximados)",true)
            4 -> PmxJointConstraintProfile(axis(pMin[0],0f,0f),axis(pMax[0],0f,0f),axis(0f,0f,0f),axis(0f,0f,0f),FloatArray(3),FloatArray(3),"Slider (eixo X local)",true)
            5 -> PmxJointConstraintProfile(axis(0f,0f,0f),axis(0f,0f,0f),axis(rMin[0],0f,0f),axis(rMax[0],0f,0f),FloatArray(3),FloatArray(3),"Hinge (eixo X local)",true)
            else -> PmxJointConstraintProfile(pMin,pMax,rMin,rMax,FloatArray(3),FloatArray(3),"Tipo desconhecido (fallback 6DOF)",true)
        }
    }
}
