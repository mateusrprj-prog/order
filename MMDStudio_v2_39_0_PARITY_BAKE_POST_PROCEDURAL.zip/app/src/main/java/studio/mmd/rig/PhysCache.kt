package studio.mmd.rig

import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMotion

/**
 * v1.14.0: cache da física ("bake"). Guarda, quadro a quadro (30 por segundo), a pose global dos ossos que a física controla
 * (quaternion + posição = 7 floats por osso). Com um cache válido, a prévia, o vídeo e as exportações NÃO simulam de novo:
 * leem daqui, então o resultado é idêntico em qualquer taxa de prévia, ao pular na timeline e ao exportar.
 * Só vale para o mesmo modelo, a mesma animação (conteúdo), a mesma configuração de física, as mesmas restrições e o mesmo movimento secundário;
 * qualquer mudança invalida (o Animator confere a [key] e ignora um cache velho). Fica só em memória (some ao fechar o app).
 */
class PhysCache(val model: PmxModel, val key: Long, val frames: Int, val bones: IntArray, val full: BooleanArray, val data: FloatArray) {
    val stride get() = bones.size * 7
    val bytes get() = data.size * 4L
}

object PhysBake {
    /** Assinatura do conteúdo da animação (não da instância: o Editor monta um objeto novo a cada chamada). */
    fun signature(mo: VmdMotion?): Long {
        if (mo == null) return 0L
        var h = -3750763034362895579L
        fun mix(x: Int) { h = (h xor x.toLong()) * 1099511628211L }
        for ((k, t) in mo.bones.toSortedMap()) { mix(k.hashCode()); mix(java.util.Arrays.hashCode(t.frames)); mix(java.util.Arrays.hashCode(t.v)); mix(java.util.Arrays.hashCode(t.ip)) }
        for ((k, t) in mo.morphs.toSortedMap()) { mix(k.hashCode()); mix(java.util.Arrays.hashCode(t.frames)); mix(java.util.Arrays.hashCode(t.w)) }
        for ((k, t) in mo.extras.ik.toSortedMap()) { mix(k.hashCode()); mix(java.util.Arrays.hashCode(t.frames)); mix(java.util.Arrays.hashCode(t.on)) }
        return h
    }

    fun combine(motionSig: Long, cfg: PhysConfig, rig: List<Constraint>, sec: List<Secondary>): Long {
        var h = motionSig
        fun mix(x: Int) { h = (h xor x.toLong()) * 1099511628211L }
        mix(cfg.hashCode()); mix(rig.hashCode()); mix(sec.hashCode())
        return h
    }

    /**
     * Simula do quadro 0 ao quadro [to] (inclusive) a 30 quadros/s, em passos fixos de 1/240 s, e guarda o resultado.
     * Pode rodar fora da thread principal. Devolve null se o modelo não tem física ativa.
     * [progress] recebe o quadro atual (0..to); devolva true para cancelar.
     */
    fun run(model: PmxModel, motion: VmdMotion, to: Int, progress: (Int) -> Boolean = { false }, rig: RigConfig = RigState.main): PhysCache? {
        if (!rig.phys.enabled) return null
        val an = Animator(model, 1f, rig)
        an.useCache = false
        an.motion = motion
        val drv = an.physDrivenBones() ?: return null
        val last = to.coerceAtLeast(0)
        val per = drv.size * 7
        val data = FloatArray((last + 1) * per)
        for (f in 0..last) {
            an.evaluatePose(f.toFloat())
            an.copyDriven(drv, data, f * per)
            if (progress(f)) return null
        }
        return PhysCache(model, an.physKey(), last + 1, drv, an.physFullFlags(drv), data)
    }
}
