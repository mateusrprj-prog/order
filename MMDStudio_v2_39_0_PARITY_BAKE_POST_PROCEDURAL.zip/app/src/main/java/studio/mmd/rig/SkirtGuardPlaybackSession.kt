package studio.mmd.rig

import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel

/**
 * Sessão leve de tecido exclusivo da saia para playback. Compacta só os vértices/triângulos
 * detectados, mantém a cintura ancorada e devolve uma cópia da malha original com offsets
 * pré-skinning. O PMX nunca é modificado.
 */
class SkirtGuardPlaybackSession(
    private val model: PmxModel,
    private val profile: SkirtGuardProfile,
    private val maxVertices: Int = 4500,
    private val maxBodyTriangles: Int = 1800,
    private val bodySurfaceCollision: Boolean = true,
    private val anchorBandFraction: Float = 0.045f
) {
    val sourceVertices: IntArray
    private val compactOfSource: IntArray
    private val solver: ClothXpbd?
    /** Triângulos reais do corpo (fora da saia), compactados para colisão animada no preview. */
    private val bodySourceVertices: IntArray
    private val bodyCompactTriangles: IntArray
    private val bodyCompactOfSource: IntArray
    private val fixedStepSeconds = 1f / 60f
    private val bodyTriangleBudget = maxBodyTriangles.coerceIn(0, 4000)
    private var timeAccumulator = 0f
    val bodyCollisionTriangleCount: Int get() = bodyCompactTriangles.size / 3
    val ready: Boolean
    val status: String
    /** Último diagnóstico do passo físico; permite inspecionar rollback sem expor o solver interno. */
    val lastSafetyReport: ClothStepSafetyReport? get() = solver?.lastStepSafetyReport
    /** Quantidade de frames em que a validação recusou e reverteu o passo do solver. */
    var safetyRollbackCount: Int = 0
        private set

    init {
        val selected = profile.skirtVertexIndices.asSequence()
            .filter { it in 0 until model.vertexCount }
            .distinct().toList()
        if (!profile.detected || profile.colliderHints.isEmpty() || selected.size < 3 || selected.size > maxVertices) {
            sourceVertices = intArrayOf(); compactOfSource = IntArray(model.vertexCount) { -1 }
            bodySourceVertices = intArrayOf(); bodyCompactTriangles = intArrayOf(); bodyCompactOfSource = IntArray(model.vertexCount) { -1 }
            solver = null; ready = false
            status = when {
                selected.size > maxVertices -> "Saia tem ${selected.size} vértices; playback limitado a $maxVertices para manter a taxa de quadros"
                profile.colliderHints.isEmpty() -> "Saia detectada, mas não há ossos de perna reconhecidos para proteção no playback"
                else -> "Região de saia insuficiente para simulação ao vivo"
            }
        } else {
            sourceVertices = selected.toIntArray()
            compactOfSource = IntArray(model.vertexCount) { -1 }
            sourceVertices.forEachIndexed { local, source -> compactOfSource[source] = local }

            // Superfície corporal real: triângulos inteiramente fora da saia e próximos ao volume dela.
            // Isso exclui a própria roupa e evita indexar corpo distante (rosto, mãos, acessórios).
            bodyCompactOfSource = IntArray(model.vertexCount) { -1 }
            val bodyTriCandidates = ArrayList<Int>()
            var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
            for (v in sourceVertices) {
                val o = v * 3
                minX = kotlin.math.min(minX, model.positions[o]); minY = kotlin.math.min(minY, model.positions[o + 1]); minZ = kotlin.math.min(minZ, model.positions[o + 2])
                maxX = kotlin.math.max(maxX, model.positions[o]); maxY = kotlin.math.max(maxY, model.positions[o + 1]); maxZ = kotlin.math.max(maxZ, model.positions[o + 2])
            }
            val bodyPadding = 0.24f
            if (bodySurfaceCollision && bodyTriangleBudget > 0 && minX.isFinite()) {
                for (i in model.indices.indices step 3) {
                    if (i + 2 >= model.indices.size) break
                    val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                    if (a !in compactOfSource.indices || b !in compactOfSource.indices || c !in compactOfSource.indices) continue
                    if (compactOfSource[a] >= 0 || compactOfSource[b] >= 0 || compactOfSource[c] >= 0) continue
                    val ao = a * 3; val bo = b * 3; val co = c * 3
                    val cx = (model.positions[ao] + model.positions[bo] + model.positions[co]) / 3f
                    val cy = (model.positions[ao + 1] + model.positions[bo + 1] + model.positions[co + 1]) / 3f
                    val cz = (model.positions[ao + 2] + model.positions[bo + 2] + model.positions[co + 2]) / 3f
                    if (cx < minX - bodyPadding || cx > maxX + bodyPadding || cy < minY - bodyPadding || cy > maxY + bodyPadding || cz < minZ - bodyPadding || cz > maxZ + bodyPadding) continue
                    bodyTriCandidates.add(a); bodyTriCandidates.add(b); bodyTriCandidates.add(c)
                }
            }
            val candidateCount = bodyTriCandidates.size / 3
            val stride = if (candidateCount > bodyTriangleBudget && bodyTriangleBudget > 0) kotlin.math.ceil(candidateCount.toDouble() / bodyTriangleBudget).toInt() else 1
            val sampled = ArrayList<Int>(minOf(candidateCount, bodyTriangleBudget) * 3)
            var tri = 0
            while (tri < candidateCount && sampled.size / 3 < bodyTriangleBudget) {
                val offset = tri * 3
                sampled.add(bodyTriCandidates[offset]); sampled.add(bodyTriCandidates[offset + 1]); sampled.add(bodyTriCandidates[offset + 2])
                tri += stride
            }
            val bodyVertices = sampled.distinct().toIntArray()
            bodySourceVertices = bodyVertices
            bodyVertices.forEachIndexed { local, source -> bodyCompactOfSource[source] = local }
            bodyCompactTriangles = IntArray(sampled.size) { index -> bodyCompactOfSource[sampled[index]] }

            val compactPositions = FloatArray(sourceVertices.size * 3)
            sourceVertices.forEachIndexed { local, source ->
                val src = source * 3; val dst = local * 3
                compactPositions[dst] = model.positions[src]; compactPositions[dst + 1] = model.positions[src + 1]; compactPositions[dst + 2] = model.positions[src + 2]
            }
            val triangles = ArrayList<Int>()
            for (i in model.indices.indices step 3) {
                if (i + 2 >= model.indices.size) break
                val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
                if (a !in compactOfSource.indices || b !in compactOfSource.indices || c !in compactOfSource.indices) continue
                val ca = compactOfSource[a]; val cb = compactOfSource[b]; val cc = compactOfSource[c]
                if (ca >= 0 && cb >= 0 && cc >= 0 && ca != cb && cb != cc && cc != ca) {
                    triangles += ca; triangles += cb; triangles += cc
                }
            }
            if (triangles.size < 3) {
                solver = null; ready = false; status = "Saia reconhecida, mas não há triângulos completos para simular"
            } else {
                val built = runCatching { ClothXpbd.fromMesh(compactPositions, triangles.toIntArray(), bendCompliance = 0.0012f) }.getOrNull()
                solver = built
                if (built == null) { ready = false; status = "Não foi possível construir a malha XPBD da saia" }
                else {
                    val waistBones = model.bones.indices.filter { i ->
                        val n = (model.bones[i].name + " " + model.bones[i].nameEn).lowercase()
                        listOf("pelvis", "hips", "waist", "lowerbody", "下半身", "腰", "センター").any(n::contains)
                    }.toHashSet()
                    val weightedPins = ArrayList<Pair<Int, Float>>()
                    for (local in sourceVertices.indices) {
                        val v = sourceVertices[local]; val o = v * 4
                        var weight = 0f
                        for (slot in 0..3) if ((model.boneIndices.getOrElse(o + slot) { -1 }) in waistBones)
                            weight += model.boneWeights.getOrElse(o + slot) { 0f }.coerceAtLeast(0f)
                        if (weight >= 0.45f) weightedPins += local to weight
                    }
                    val band = (if (anchorBandFraction.isFinite()) anchorBandFraction else 0.045f).coerceIn(0.01f, 0.18f)
                    val pins = if (weightedPins.isNotEmpty()) weightedPins.sortedByDescending { it.second }.take(384).map { it.first }
                    else {
                        val skirtTopY = sourceVertices.maxOf { model.positions[it * 3 + 1] }
                        val skirtBottomY = sourceVertices.minOf { model.positions[it * 3 + 1] }
                        val threshold = skirtTopY - (skirtTopY - skirtBottomY).coerceAtLeast(0.01f) * band
                        sourceVertices.indices.filter { model.positions[sourceVertices[it] * 3 + 1] >= threshold }
                            .sortedByDescending { model.positions[sourceVertices[it] * 3 + 1] }
                            .take(384)
                    }
                    pins.distinct().forEach { built.pin(it) }
                    ready = true
                    status = "Simulação ao vivo: ${sourceVertices.size} vértices · ${triangles.size / 3} triângulos de roupa · ${pins.size} âncoras · ${bodyCompactTriangles.size / 3} triângulos corporais animados · auto-colisão ${if (sourceVertices.size <= 2048) "ativa" else "desligada por desempenho"}"
                }
            }
        }
    }

    fun reset() { solver?.reset(); timeAccumulator = 0f; safetyRollbackCount = 0 }

    /** currentPose é a pose que será desenhada; previousPose representa o frame de inércia. */
    fun step(
        deltaSeconds: Float,
        currentPose: Animator,
        previousPose: Animator,
        margin: Float = 0.018f,
        gravityY: Float = -9.81f,
        iterations: Int = 5
    ): FloatArray? {
        val cloth = solver ?: return null
        if (!ready || !deltaSeconds.isFinite() || deltaSeconds <= 0f) return null
        val guardPose = SkirtGuardRuntime.pose(model, profile, margin) { bone, x, y, z, out ->
            currentPose.bonePointToModel(bone, x, y, z, out)
        }
        val previousGuardPose = SkirtGuardRuntime.pose(model, profile, margin) { bone, x, y, z, out ->
            previousPose.bonePointToModel(bone, x, y, z, out)
        }
        cloth.setSweptCapsules(previousGuardPose.capsules, guardPose.capsules)
        val surface = if (bodySurfaceCollision && bodyCompactTriangles.isNotEmpty()) {
            val source = if (currentPose.vertexMorphed && currentPose.morphedPositions.size == model.positions.size) currentPose.morphedPositions else model.positions
            val posed = FloatArray(bodySourceVertices.size * 3)
            val tmp = FloatArray(3)
            for (i in bodySourceVertices.indices) {
                val v = bodySourceVertices[i]; val o = v * 3
                currentPose.skinPointToModel(v, source[o], source[o + 1], source[o + 2], tmp)
                val d = i * 3; posed[d] = tmp[0]; posed[d + 1] = tmp[1]; posed[d + 2] = tmp[2]
            }
            val triangles = ArrayList<ClothTriangleCollider>(bodyCompactTriangles.size / 3)
            for (i in bodyCompactTriangles.indices step 3) {
                val a = bodyCompactTriangles[i] * 3; val b = bodyCompactTriangles[i + 1] * 3; val c = bodyCompactTriangles[i + 2] * 3
                triangles += ClothTriangleCollider(posed[a], posed[a + 1], posed[a + 2], posed[b], posed[b + 1], posed[b + 2], posed[c], posed[c + 1], posed[c + 2])
            }
            triangles
        } else emptyList()
        cloth.setColliders(capsules = guardPose.capsules, triangles = surface, thickness = margin.coerceIn(0.001f, 0.25f))
        val map = sourceVertices
        val transform = object : ClothSkinTransform {
            private fun source(vertex: Int) = map.getOrElse(vertex) { -1 }
            private fun morphOffset(pose: Animator, sourceVertex: Int, out: FloatArray) {
                if (pose.vertexMorphed && pose.morphedPositions.size == model.positions.size) {
                    val o = sourceVertex * 3
                    out[0] = pose.morphedPositions[o] - model.positions[o]
                    out[1] = pose.morphedPositions[o + 1] - model.positions[o + 1]
                    out[2] = pose.morphedPositions[o + 2] - model.positions[o + 2]
                } else { out[0] = 0f; out[1] = 0f; out[2] = 0f }
            }
            private val morph = FloatArray(3)
            override fun toWorldPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else {
                    morphOffset(currentPose, v, morph); currentPose.skinPointToModel(v,x+morph[0],y+morph[1],z+morph[2],out)
                }
            }
            override fun toWorldPreviousPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else {
                    morphOffset(previousPose, v, morph); previousPose.skinPointToModel(v,x+morph[0],y+morph[1],z+morph[2],out)
                }
            }
            override fun toWorldVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else currentPose.skinVectorToModel(v,x,y,z,out)
            }
            override fun toWorldPreviousVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else previousPose.skinVectorToModel(v,x,y,z,out)
            }
            override fun toLocalPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else {
                    currentPose.unskinPointFromModel(v,x,y,z,out); morphOffset(currentPose, v, morph)
                    out[0] -= morph[0]; out[1] -= morph[1]; out[2] -= morph[2]
                }
            }
            override fun toLocalVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                val v = source(vertex); if (v < 0) { out[0]=x; out[1]=y; out[2]=z } else currentPose.unskinVectorFromModel(v,x,y,z,out)
            }
        }
        // Passo fixo reduz variação do solver quando o FPS oscila. Um único stepSkinned por frame
        // preserva corretamente a conversão entre a pose anterior e a atual; os subpassos internos
        // usam dt fixo e o catch-up é limitado para evitar travamento em aparelho lento.
        val accumulated = (timeAccumulator + deltaSeconds.coerceIn(1f / 240f, 0.1f)).coerceAtMost(0.1f)
        val steps = kotlin.math.floor((accumulated + 1e-7f) / fixedStepSeconds).toInt().coerceIn(0, 6)
        val simulated = if (steps > 0) {
            val simulatedTime = steps * fixedStepSeconds
            timeAccumulator = (accumulated - simulatedTime).coerceAtLeast(0f)
            cloth.stepSkinned(
                simulatedTime, transform,
                gravityY = gravityY, substeps = steps, iterations = iterations.coerceIn(2, 8),
                damping = 0.075f, groundY = null, selfCollision = (sourceVertices.size <= 2048),
                safety = ClothStepSafetyConfig(maxDisplacementPerStep = 8f, maxSpeed = 500f, maxAbsoluteCoordinate = 100_000f)
            ).also { if (cloth.lastStepSafetyReport?.accepted == false) safetyRollbackCount++ }
        } else {
            timeAccumulator = accumulated
            // Em taxas acima de 60 fps, mantém a última posição estável até o próximo tick físico.
            cloth.snapshotPositions()
        }
        val full = model.positions.copyOf()
        for (local in map.indices) {
            val dst = map[local] * 3; val src = local * 3
            full[dst] = simulated[src]; full[dst + 1] = simulated[src + 1]; full[dst + 2] = simulated[src + 2]
        }
        return full
    }
}
