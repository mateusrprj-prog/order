package studio.mmd.rig

import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMotion

/** Calcula, quadro a quadro e em ordem, a rotação local final dos ossos (já com restrições e movimento secundário). */
object Baker {
    /** Retorna, para cada quadro de [from] a [to], o mapa nome → quaternion local (x,y,z,w). Pode rodar fora da thread principal. */
    fun compute(model: PmxModel, motion: VmdMotion, names: Collection<String>, from: Int, to: Int,
                rig: RigConfig = RigState.main): List<Map<String, FloatArray>> {
        val an = Animator(model, 1f, rig); an.motion = motion
        val idx = HashMap<String, Int>()
        for (i in model.bones.indices) idx.putIfAbsent(model.bones[i].name, i)
        val o = FloatArray(7)
        val out = ArrayList<Map<String, FloatArray>>()
        for (f in from..to) {
            an.evaluatePose(f.toFloat())
            val m = HashMap<String, FloatArray>()
            for (nm in names) { val b = idx[nm] ?: continue; an.local(b, o); m[nm] = floatArrayOf(o[3], o[4], o[5], o[6]) }
            out.add(m)
        }
        return out
    }
}
