package studio.mmd.rig

import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMotion
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Relatório do exame da saia na pose pedida. As posições continuam no espaço PMX local. */
data class SkirtGuardAnalysisReport(
    val frame: Float,
    val detected: Boolean,
    val confidence: Float,
    val testedVertices: Int,
    val penetratingVertices: Int,
    val maxPenetration: Float,
    val worstVertex: Int,
    val colliderCount: Int,
    val nearSelfContactPairs: Int,
    val selfIntersectingTrianglePairs: Int,
    val flaggedVertexIndices: IntArray,
    val capsules: List<ClothCapsule>,
    val warnings: List<String> = emptyList()
) {
    val clean: Boolean get() = penetratingVertices == 0
    fun summary(): String = if (!detected) "Nenhuma saia detectada" else
        "Frame ${frame.toInt()}: $testedVertices vértices analisados · $penetratingVertices com penetração · " +
            "máximo ${"%.4f".format(java.util.Locale.US, maxPenetration)} · $nearSelfContactPairs pares em proximidade · $selfIntersectingTrianglePairs pares de triângulos cruzados · $colliderCount colisores"
}

data class SkirtGuardFixReport(
    val positions: FloatArray,
    val correctedVertices: Int,
    val maxDisplacement: Float,
    val totalDisplacement: Float
)

/** Ferramentas não destrutivas de diagnóstico, correção limitada e proximidade entre partes da própria saia. */
object SkirtGuardStudio {
    private data class Cell(val x: Int, val y: Int, val z: Int)
    private fun pairKey(a: Int, b: Int): Long = (min(a, b).toLong() shl 32) or (max(a, b).toLong() and 0xffffffffL)

    fun analyzePose(
        model: PmxModel,
        motion: VmdMotion?,
        frame: Float,
        margin: Float = 0.018f,
        selfContactDistance: Float = 0.012f,
        maxFlagged: Int = 512
    ): SkirtGuardAnalysisReport {
        val profile = SkirtGuardAuto.profile(model)
        if (!profile.detected) return SkirtGuardAnalysisReport(frame, false, 0f, 0, 0, 0f, -1, 0, 0, 0, intArrayOf(), emptyList())
        val animator = Animator(model, 1f).also { it.motion = motion; it.prepareClothPose(frame.coerceAtLeast(0f)) }
        val pose = SkirtGuardRuntime.pose(model, profile, margin) { bone, x, y, z, out -> animator.bonePointToModel(bone, x, y, z, out) }
        val source = if (animator.vertexMorphed && animator.morphedPositions.size == model.positions.size) animator.morphedPositions else model.positions
        val p = FloatArray(3)
        val posedPositions = FloatArray(model.vertexCount * 3)
        for (v in 0 until model.vertexCount) {
            val o = v * 3
            animator.skinPointToModel(v, source[o], source[o + 1], source[o + 2], p)
            posedPositions[o] = p[0]; posedPositions[o + 1] = p[1]; posedPositions[o + 2] = p[2]
        }
        var tested = 0; var penetrating = 0; var maxDepth = 0f; var worst = -1
        val flagged = ArrayList<Int>(min(maxFlagged, 64))
        for (v in profile.skirtVertexIndices) {
            if (v !in 0 until model.vertexCount || pose.capsules.isEmpty()) continue
            val o = v * 3
            p[0] = posedPositions[o]; p[1] = posedPositions[o + 1]; p[2] = posedPositions[o + 2]
            if (!p.all(Float::isFinite)) continue
            tested++
            var nearest = Float.POSITIVE_INFINITY
            for (c in pose.capsules) {
                val abx = c.bx - c.ax; val aby = c.by - c.ay; val abz = c.bz - c.az
                val apx = p[0] - c.ax; val apy = p[1] - c.ay; val apz = p[2] - c.az
                val den = abx * abx + aby * aby + abz * abz
                val t = if (den <= 1e-10f) 0f else ((apx * abx + apy * aby + apz * abz) / den).coerceIn(0f, 1f)
                val dx = p[0] - (c.ax + abx * t); val dy = p[1] - (c.ay + aby * t); val dz = p[2] - (c.az + abz * t)
                nearest = min(nearest, sqrt(dx * dx + dy * dy + dz * dz) - c.radius)
            }
            if (nearest < -1e-4f) {
                penetrating++
                val depth = -nearest
                if (depth > maxDepth) { maxDepth = depth; worst = v }
                if (flagged.size < maxFlagged) flagged += v
            }
        }
        val selfPairs = countNearSelfContacts(model, posedPositions, profile.skirtVertexIndices, selfContactDistance)
        val intersections = countSelfIntersectingTrianglePairs(model, posedPositions, profile.skirtVertexIndices)
        return SkirtGuardAnalysisReport(frame, true, profile.confidence, tested, penetrating, maxDepth, worst,
            pose.capsules.size, selfPairs, intersections, flagged.toIntArray(), pose.capsules, pose.warnings)
    }

    /** Detecta proximidade entre vértices não vizinhos; é um alarme de auto-contato, não uma prova de interseção triângulo-triângulo. */
    fun countNearSelfContacts(model: PmxModel, positions: FloatArray, selected: IntArray, radius: Float): Int {
        val r = radius.takeIf { it.isFinite() }?.coerceIn(0.001f, 0.2f) ?: 0.012f
        if (selected.size < 2 || positions.size < model.vertexCount * 3) return 0
        val adjacency = Array(model.vertexCount) { HashSet<Int>() }
        for (i in model.indices.indices step 3) {
            if (i + 2 >= model.indices.size) break
            val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
            if (a !in adjacency.indices || b !in adjacency.indices || c !in adjacency.indices) continue
            adjacency[a].add(b); adjacency[a].add(c); adjacency[b].add(a); adjacency[b].add(c); adjacency[c].add(a); adjacency[c].add(b)
        }
        val excluded = HashSet<Long>()
        for (a in selected) if (a in adjacency.indices) {
            for (b in adjacency[a]) {
                excluded += pairKey(a, b)
                for (c in adjacency[b]) if (c != a) excluded += pairKey(a, c)
            }
        }
        fun cell(v: Float) = floor(v / r).toInt()
        val buckets = HashMap<Cell, MutableList<Int>>()
        val valid = selected.filter { it in 0 until model.vertexCount && (it * 3 + 2) < positions.size }
        var count = 0; var examined = 0
        for (v in valid) {
            val o = v * 3; val x = positions[o]; val y = positions[o + 1]; val z = positions[o + 2]
            if (!x.isFinite() || !y.isFinite() || !z.isFinite()) continue
            val cx = cell(x); val cy = cell(y); val cz = cell(z)
            for (dx in -1..1) for (dy in -1..1) for (dz in -1..1) {
                val candidates = buckets[Cell(cx + dx, cy + dy, cz + dz)] ?: continue
                for (u in candidates) {
                    if (++examined > 1_000_000) return count
                    if (pairKey(v, u) in excluded) continue
                    val q = u * 3; val xx = x - positions[q]; val yy = y - positions[q + 1]; val zz = z - positions[q + 2]
                    if (xx * xx + yy * yy + zz * zz < r * r) count++
                }
            }
            buckets.getOrPut(Cell(cx, cy, cz)) { ArrayList() }.add(v)
        }
        return count
    }

    /** Detecta cruzamento geométrico entre triângulos não adjacentes da região da saia via broadphase espacial. */
    fun countSelfIntersectingTrianglePairs(model: PmxModel, positions: FloatArray, selected: IntArray, maxCandidates: Int = 750_000): Int {
        if (positions.size < model.vertexCount * 3 || model.indices.size < 6 || selected.isEmpty()) return 0
        val selectedMask = BooleanArray(model.vertexCount)
        selected.forEach { if (it in selectedMask.indices) selectedMask[it] = true }
        data class Tri(val a: Int, val b: Int, val c: Int, val minX: Float, val minY: Float, val minZ: Float,
                       val maxX: Float, val maxY: Float, val maxZ: Float)
        val tris = ArrayList<Tri>()
        for (i in model.indices.indices step 3) {
            if (i + 2 >= model.indices.size) break
            val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
            if (a !in selectedMask.indices || b !in selectedMask.indices || c !in selectedMask.indices) continue
            if (!selectedMask[a] || !selectedMask[b] || !selectedMask[c]) continue
            val ao = a * 3; val bo = b * 3; val co = c * 3
            val values = floatArrayOf(positions[ao], positions[ao+1], positions[ao+2], positions[bo], positions[bo+1], positions[bo+2], positions[co], positions[co+1], positions[co+2])
            if (!values.all(Float::isFinite)) continue
            tris += Tri(a,b,c, min(values[0],min(values[3],values[6])), min(values[1],min(values[4],values[7])), min(values[2],min(values[5],values[8])),
                max(values[0],max(values[3],values[6])), max(values[1],max(values[4],values[7])), max(values[2],max(values[5],values[8])))
        }
        if (tris.size < 2) return 0
        val cellSize = 0.08f
        fun cell(v: Float) = floor(v / cellSize).toInt()
        data class Cell(val x: Int, val y: Int, val z: Int)
        val buckets = HashMap<Cell, MutableList<Int>>()
        val oversized = ArrayList<Int>()
        for (i in tris.indices) {
            val t = tris[i]
            val x0=cell(t.minX); val y0=cell(t.minY); val z0=cell(t.minZ)
            val x1=cell(t.maxX); val y1=cell(t.maxY); val z1=cell(t.maxZ)
            val volume=(x1.toLong()-x0+1L)*(y1.toLong()-y0+1L)*(z1.toLong()-z0+1L)
            if (volume > 128L) oversized += i
            else for (x in x0..x1) for (y in y0..y1) for (z in z0..z1) buckets.getOrPut(Cell(x,y,z)) { ArrayList() }.add(i)
        }
        val candidates = HashSet<Long>()
        fun addPair(a: Int, b: Int) {
            if (a == b) return
            val lo = min(a,b); val hi=max(a,b)
            candidates += (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL)
        }
        val candidateLimit = maxCandidates.coerceIn(1, 2_000_000)
        for (ids in buckets.values) {
            if (candidates.size >= candidateLimit) break
            for (i in ids.indices) {
                if (candidates.size >= candidateLimit) break
                for (j in i + 1 until ids.size) {
                    addPair(ids[i], ids[j])
                    if (candidates.size >= candidateLimit) break
                }
            }
        }
        // Triângulos enormes são raros; só comparam contra o conjunto próximo pelo AABB, respeitando o orçamento.
        for (large in oversized) {
            if (candidates.size >= candidateLimit) break
            val a = tris[large]
            for (j in tris.indices) if (j != large) {
                val b = tris[j]
                if (a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY && a.minZ <= b.maxZ && a.maxZ >= b.minZ) addPair(large,j)
                if (candidates.size >= candidateLimit) break
            }
        }
        fun segmentTriangle(p0: FloatArray, p1: FloatArray, a: FloatArray, b: FloatArray, c: FloatArray): Boolean {
            val dx=p1[0]-p0[0]; val dy=p1[1]-p0[1]; val dz=p1[2]-p0[2]
            val e1x=b[0]-a[0]; val e1y=b[1]-a[1]; val e1z=b[2]-a[2]
            val e2x=c[0]-a[0]; val e2y=c[1]-a[1]; val e2z=c[2]-a[2]
            val hx=dy*e2z-dz*e2y; val hy=dz*e2x-dx*e2z; val hz=dx*e2y-dy*e2x
            val det=e1x*hx+e1y*hy+e1z*hz
            if (kotlin.math.abs(det) < 1e-8f) return false
            val inv=1f/det; val sx=p0[0]-a[0]; val sy=p0[1]-a[1]; val sz=p0[2]-a[2]
            val u=(sx*hx+sy*hy+sz*hz)*inv
            if (u < 1e-5f || u > 1f-1e-5f) return false
            val qx=sy*e1z-sz*e1y; val qy=sz*e1x-sx*e1z; val qz=sx*e1y-sy*e1x
            val v=(dx*qx+dy*qy+dz*qz)*inv
            if (v < 1e-5f || u+v > 1f-1e-5f) return false
            val t=(e2x*qx+e2y*qy+e2z*qz)*inv
            return t > 1e-5f && t < 1f-1e-5f
        }
        fun triPos(t: Tri): Array<FloatArray> = arrayOf(t.a,t.b,t.c).map { v ->
            val o=v*3; floatArrayOf(positions[o],positions[o+1],positions[o+2])
        }.toTypedArray()
        var intersections=0; var examined=0
        for (key in candidates) {
            if (++examined > candidateLimit) break
            val ia=(key shr 32).toInt(); val ib=key.toInt()
            val a=tris[ia]; val b=tris[ib]
            if (a.a==b.a || a.a==b.b || a.a==b.c || a.b==b.a || a.b==b.b || a.b==b.c || a.c==b.a || a.c==b.b || a.c==b.c) continue
            val ap=triPos(a); val bp=triPos(b)
            var hit=false
            for (e in 0..2) if (segmentTriangle(ap[e],ap[(e+1)%3],bp[0],bp[1],bp[2]) || segmentTriangle(bp[e],bp[(e+1)%3],ap[0],ap[1],ap[2])) { hit=true; break }
            if (hit) intersections++
        }
        return intersections
    }

    /**
     * Corrige apenas a cópia de posições do bake/preview. Deslocamento é limitado por vértice e por passada.
     * As conversões opcionais permitem resolver em espaço animado e gravar de volta no espaço pré-skinning.
     */
    fun autoFix(
        localPositions: FloatArray,
        vertices: IntArray,
        capsules: List<ClothCapsule>,
        maxDisplacement: Float = 0.025f,
        strength: Float = 0.85f,
        passes: Int = 2,
        toWorld: ((Int, Float, Float, Float, FloatArray) -> Unit)? = null,
        toLocal: ((Int, Float, Float, Float, FloatArray) -> Unit)? = null,
        region: SkirtCorrectionRegion = SkirtCorrectionRegion.ALL,
        regionSoftness: Float = 0.32f
    ): SkirtGuardFixReport {
        val out = localPositions.copyOf()
        if (capsules.isEmpty() || vertices.isEmpty()) return SkirtGuardFixReport(out, 0, 0f, 0f)
        val limit = maxDisplacement.takeIf { it.isFinite() }?.coerceIn(0.001f, 0.2f) ?: 0.025f
        val gain = strength.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0.85f
        if (gain <= 0f) return SkirtGuardFixReport(out, 0, 0f, 0f)
        val world = FloatArray(3); val local = FloatArray(3)
        var centerX = 0f; var centerZ = 0f; var centerCount = 0
        for (v in vertices) if (v >= 0 && v * 3 + 2 < out.size) {
            val x = out[v * 3]; val z = out[v * 3 + 2]
            if (x.isFinite() && z.isFinite()) { centerX += x; centerZ += z; centerCount++ }
        }
        if (centerCount > 0) { centerX /= centerCount; centerZ /= centerCount }
        var radiusX = 0.05f; var radiusZ = 0.05f
        for (v in vertices) if (v >= 0 && v * 3 + 2 < out.size) {
            radiusX = max(radiusX, kotlin.math.abs(out[v * 3] - centerX))
            radiusZ = max(radiusZ, kotlin.math.abs(out[v * 3 + 2] - centerZ))
        }
        val softness = (if (regionSoftness.isFinite()) regionSoftness else 0.32f).coerceIn(0.05f, 1f)
        fun smooth01(value: Float): Float { val t = value.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        fun regionWeight(v: Int): Float {
            val nx = ((out[v * 3] - centerX) / radiusX).coerceIn(-1f, 1f)
            val nz = ((out[v * 3 + 2] - centerZ) / radiusZ).coerceIn(-1f, 1f)
            return when (region) {
                SkirtCorrectionRegion.ALL -> 1f
                SkirtCorrectionRegion.FRONT -> smooth01((nz + softness) / (2f * softness))
                SkirtCorrectionRegion.BACK -> smooth01((-nz + softness) / (2f * softness))
                SkirtCorrectionRegion.RIGHT -> smooth01((nx + softness) / (2f * softness))
                SkirtCorrectionRegion.LEFT -> smooth01((-nx + softness) / (2f * softness))
            }
        }
        var affected = 0; var maxMove = 0f; var totalMove = 0f
        val seen = HashSet<Int>()
        for (v in vertices) {
            if (v in seen || v < 0 || v * 3 + 2 >= out.size) continue
            seen += v
            val o = v * 3
            val regionalGain = gain * regionWeight(v)
            if (regionalGain <= 1e-5f) continue
            local[0] = out[o]; local[1] = out[o + 1]; local[2] = out[o + 2]
            if (toWorld != null) toWorld(v, local[0], local[1], local[2], world) else local.copyInto(world)
            if (!world.all(Float::isFinite)) continue
            val start = world.copyOf()
            repeat(passes.coerceIn(1, 4)) {
                for (c in capsules) {
                    val abx = c.bx - c.ax; val aby = c.by - c.ay; val abz = c.bz - c.az
                    val apx = world[0] - c.ax; val apy = world[1] - c.ay; val apz = world[2] - c.az
                    val den = abx * abx + aby * aby + abz * abz
                    val t = if (den <= 1e-10f) 0f else ((apx * abx + apy * aby + apz * abz) / den).coerceIn(0f, 1f)
                    val qx = c.ax + abx * t; val qy = c.ay + aby * t; val qz = c.az + abz * t
                    var dx = world[0] - qx; var dy = world[1] - qy; var dz = world[2] - qz
                    val distance = sqrt(dx * dx + dy * dy + dz * dz)
                    val target = c.radius + 1e-4f
                    if (distance >= target) continue
                    if (distance <= 1e-7f) {
                        // Normal determinística para não produzir NaN em vértices exatamente no eixo da cápsula.
                        dx = if (v % 3 == 0) 1f else 0f; dy = if (v % 3 == 1) 1f else 0f; dz = if (v % 3 == 2) 1f else 0f
                    }
                    val len = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1e-7f)
                    val push = (target - distance).coerceAtLeast(0f) * regionalGain
                    world[0] += dx / len * push; world[1] += dy / len * push; world[2] += dz / len * push
                }
                // O limite é por vértice no total, não por colisão/passada: vários ossos próximos não podem empurrar demais a roupa.
                val sx = world[0] - start[0]; val sy = world[1] - start[1]; val sz = world[2] - start[2]
                val moved = sqrt(sx * sx + sy * sy + sz * sz)
                if (moved > limit) {
                    val scale = limit / moved
                    world[0] = start[0] + sx * scale; world[1] = start[1] + sy * scale; world[2] = start[2] + sz * scale
                }
            }
            val dx = world[0] - start[0]; val dy = world[1] - start[1]; val dz = world[2] - start[2]
            val moved = sqrt(dx * dx + dy * dy + dz * dz)
            if (moved > 1e-7f) {
                if (toLocal != null) toLocal(v, world[0], world[1], world[2], local) else world.copyInto(local)
                out[o] = local[0]; out[o + 1] = local[1]; out[o + 2] = local[2]
                affected++; maxMove = max(maxMove, moved); totalMove += moved
            }
        }
        return SkirtGuardFixReport(out, affected, maxMove, totalMove)
    }
}
