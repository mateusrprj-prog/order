package studio.mmd.cartoon

import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdExtras
import studio.mmd.mmd.VmdIkTrack
import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/**
 * v1.29.2 — Cartoon em personagens EXTRAS do Elenco (pendência da IA anterior).
 * Extras não têm `Editor`: o movimento deles é um `VmdMotion` guardado em `cast/<id>.vmd`. Esta parte é PURA (sem Android):
 * mescla um movimento Cartoon (`Built`) dentro do movimento atual do extra e grava o resultado como VMD.
 */
/**
 * v1.29.6 — IK das pernas. No PMX os pés são controlados por IK (左足ＩＫ…): o IK refaz a perna a cada quadro e ANULA o movimento
 * que o Cartoon grava em 足/ひざ/足首 (sintoma: "os pés não mexem"). Solução: desligar, só no trecho do Cartoon, os IKs que dirigem
 * os ossos animados (usa o IK on/off do VMD, que o Animator já respeita).
 */
fun ikBonesDriving(model: PmxModel, names: Collection<String>): List<String> {
    val set = names.toHashSet(); val out = ArrayList<String>()
    for (b in model.bones) {
        val ik = b.ik ?: continue
        if (ik.links.any { l -> model.bones.getOrNull(l.bone)?.name in set }) out.add(b.name)
    }
    return out
}

object IkRange {
    /** Devolve [ik] com os IKs [names] DESLIGADOS entre [from] e [to]; no quadro to+1 volta o estado que valia ali antes. */
    fun off(ik: Map<String, VmdIkTrack>, names: Collection<String>, from: Int, to: Int): Map<String, VmdIkTrack> {
        val out = HashMap(ik)
        for (n in names) {
            val old = ik[n]
            val after = old?.at((to + 1).toFloat()) ?: true
            val before = old?.at((from - 1).toFloat()) ?: true
            val fr = ArrayList<Int>(); val on = ArrayList<Boolean>()
            if (old != null) for (i in old.frames.indices) { val f = old.frames[i]; if (f in from..(to + 1)) continue; fr.add(f); on.add(old.on[i]) }
            if (from > 0 && fr.none { it < from }) { fr.add(0); on.add(before) }   // antes da 1ª key vale o valor dela: fixa o estado anterior
            fr.add(from); on.add(false); fr.add(to + 1); on.add(after)
            val order = fr.indices.sortedBy { fr[it] }
            out[n] = VmdIkTrack(IntArray(order.size) { fr[order[it]] }, BooleanArray(order.size) { on[order[it]] })
        }
        return out
    }
}

object CartoonMerge {
    class Result(val motion: VmdMotion, val boneKeys: Int, val morphKeys: Int) { val written: Int get() = boneKeys + morphKeys }

    /**
     * Mescla [b] em [old] (pode ser null = extra parado). Nas trilhas que o Cartoon escreve, as keys entre b.first e b.last
     * são substituídas (mesma regra de `Editor.applyKeys`); o resto do movimento fica intacto.
     * [validBones]/[validMorphs]: nomes que o modelo do extra tem (null = não filtrar). Trilhas inexistentes no modelo são ignoradas.
     */
    fun merge(old: VmdMotion?, b: Built, validBones: Set<String>?, validMorphs: Set<String>?, ikOff: List<String> = emptyList()): Result {
        val bones = HashMap<String, VmdTrack>(old?.bones ?: emptyMap())
        val morphs = HashMap<String, VmdMorphTrack>(old?.morphs ?: emptyMap())
        var nb = 0; var nm = 0
        for ((name, keys) in b.bones) {
            if (validBones != null && name !in validBones) continue
            if (keys.isEmpty()) continue
            val frames = ArrayList<Int>(); val v = ArrayList<FloatArray>(); val ip = ArrayList<ByteArray>()
            val o = bones[name]
            if (o != null) for (i in o.frames.indices) {
                val f = o.frames[i]
                if (f in b.first..b.last) continue
                frames.add(f); v.add(o.v.copyOfRange(i * 7, i * 7 + 7)); ip.add(o.ip.copyOfRange(i * 16, i * 16 + 16))
            }
            for (k in keys) { frames.add(k.frame); v.add(k.v.copyOf()); ip.add(k.ip.copyOf()); nb++ }
            val order = frames.indices.sortedBy { frames[it] }   // estável: em quadro repetido, a ordem de inserção decide
            val fv = FloatArray(order.size * 7); val fi = ByteArray(order.size * 16)
            order.forEachIndexed { n, idx -> v[idx].copyInto(fv, n * 7); ip[idx].copyInto(fi, n * 16) }
            bones[name] = VmdTrack(IntArray(order.size) { frames[order[it]] }, fv, fi)
        }
        for ((name, keys) in b.morphs) {
            if (validMorphs != null && name !in validMorphs) continue
            if (keys.isEmpty()) continue
            val frames = ArrayList<Int>(); val w = ArrayList<Float>()
            val o = morphs[name]
            if (o != null) for (i in o.frames.indices) { if (o.frames[i] in b.first..b.last) continue; frames.add(o.frames[i]); w.add(o.w[i]) }
            for (k in keys) { frames.add(k.frame); w.add(k.w); nm++ }
            val order = frames.indices.sortedBy { frames[it] }
            morphs[name] = VmdMorphTrack(IntArray(order.size) { frames[order[it]] }, FloatArray(order.size) { w[order[it]] })
        }
        val maxF = maxOf(old?.maxFrame ?: 0, if (nb + nm > 0) b.last else 0)
        val oe = old?.extras ?: VmdExtras.EMPTY
        val extras = if (ikOff.isEmpty() || nb == 0) oe else VmdExtras(IkRange.off(oe.ik, ikOff, b.first, b.last), oe.lights, oe.shadows, oe.visibility)
        val mo = VmdMotion(old?.modelName ?: "cartoon", bones, morphs, maxF, emptyList(), extras)
        return Result(mo, nb, nm)
    }

    /** VMD v2 com ossos e morphs de [mo] (nomes em Shift_JIS, 15 bytes), sem câmera; luz/sombra/IK de [mo].extras são preservados. */
    fun toVmdBytes(mo: VmdMotion, modelName: String): ByteArray {
        val sj = Charset.forName("Shift_JIS")
        class BRow(val n: String, val f: Int, val v: FloatArray, val ip: ByteArray)
        val bl = ArrayList<BRow>()
        for ((n, t) in mo.bones) for (i in t.frames.indices) bl.add(BRow(n, t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
        bl.sortBy { it.f }
        class MRow(val n: String, val f: Int, val w: Float)
        val ml = ArrayList<MRow>()
        for ((n, t) in mo.morphs) for (i in t.frames.indices) ml.add(MRow(n, t.frames[i], t.w[i]))
        ml.sortBy { it.f }
        val b = ByteBuffer.allocate(30 + 20 + 4 + bl.size * 111 + 4 + ml.size * 23 + 4 + mo.extras.byteSize()).order(ByteOrder.LITTLE_ENDIAN)
        fun fixed(s: String, n: Int) {
            val e = s.toByteArray(sj); val a = ByteArray(n)
            System.arraycopy(e, 0, a, 0, minOf(e.size, n)); b.put(a)
        }
        fixed("Vocaloid Motion Data 0002", 30)
        fixed(modelName, 20)
        b.putInt(bl.size)
        for (r in bl) {
            fixed(r.n, 15); b.putInt(r.f)
            for (i in 0..6) b.putFloat(r.v[i])
            for (row in 0..3) for (j in 0 until 16) {   // mesmo layout de 64 bytes do Editor.toVmd
                val idx = j + row
                b.put(if (idx < 16) r.ip[idx] else if (idx == 16) 1.toByte() else 0.toByte())
            }
        }
        b.putInt(ml.size)
        for (r in ml) { fixed(r.n, 15); b.putInt(r.f); b.putFloat(r.w) }
        b.putInt(0)   // câmera
        mo.extras.write(b)
        return b.array()
    }
}
