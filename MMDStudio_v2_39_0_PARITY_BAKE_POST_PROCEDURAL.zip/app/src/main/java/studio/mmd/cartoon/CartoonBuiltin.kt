package studio.mmd.cartoon

import studio.mmd.edit.BKey
import studio.mmd.edit.Euler
import studio.mmd.edit.MKey
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin

/**
 * v1.28.0 — movimentos cartunescos ORIGINAIS do projeto, gerados em código (sem arquivos externos, sem licença de terceiros,
 * sem links). Usam os nomes de osso padrão do MMD (センター, 上半身, 左腕...); ossos que o modelo não tem são ignorados na aplicação
 * e aparecem na "compatibilidade" do item.
 *
 * SINAIS (v1.29.6: MEDIDOS com o Animator real, ver CartoonAxisTest; na v1.28.0 eram suposições e saíam invertidos):
 *  - Tronco/cabeça/pescoço/下半身: inclinar para a FRENTE = X NEGATIVO. Os movimentos abaixo são escritos pensando "X positivo = para a frente";
 *    [PB.rot] inverte o X desses ossos (e dos joelhos) na hora de gravar, então os números dos movimentos continuam valendo.
 *  - Perna (足): para a frente = X positivo (LEG = +1). Joelho (ひざ): dobrar = X negativo (invertido em PB.rot; os valores escritos são "dobra positiva").
 *  - Braço esquerdo: sobe com Z positivo (ARM_UP = +1; o direito, com Z negativo);  vai para a frente com Y positivo (ARM_FWD = +1; o direito, negativo).
 */
object CartoonBuiltin {
    const val LEAN = 1f
    const val LEG = 1f
    const val ARM_UP = 1f
    const val ARM_FWD = 1f
    /** Ossos cujo X é gravado invertido (ver nota no topo). */
    private val FLIP_X = setOf("上半身", "上半身2", "首", "頭", "下半身", "左ひざ", "右ひざ")

    class Def(val id: String, val name: String, val cat: CartoonCat, val make: () -> Clip)

    private const val C = "センター"; private const val UB = "上半身"; private const val UB2 = "上半身2"; private const val NK = "首"; private const val HD = "頭"
    private const val LS = "左肩"; private const val RS = "右肩"; private const val LA = "左腕"; private const val RA = "右腕"
    private const val LE = "左ひじ"; private const val RE = "右ひじ"; private const val LW = "左手首"; private const val RW = "右手首"
    private const val LB = "下半身"; private const val LL = "左足"; private const val RL = "右足"; private const val LK = "左ひざ"; private const val RK = "右ひざ"
    private const val LF = "左足首"; private const val RF = "右足首"; private const val LEYE = "左目"; private const val REYE = "右目"
    private const val BLINK = "まばたき"; private const val SMILE = "笑い"; private const val TROUBLE = "困る"; private const val ANGRY = "怒り"; private const val SURPRISE = "驚き"; private const val MA = "あ"; private const val MO = "お"

    /** Construtor de pose de UM quadro (soma contribuições): rotações em graus, posições em unidades do MMD. */
    class PB {
        val r = HashMap<String, FloatArray>(); val m = HashMap<String, Float>()
        fun rot(b: String, x: Float = 0f, y: Float = 0f, z: Float = 0f): PB { val a = r.getOrPut(b) { FloatArray(6) }; a[0] += if (b in FLIP_X) -x else x; a[1] += y; a[2] += z; return this }
        fun pos(b: String, x: Float = 0f, y: Float = 0f, z: Float = 0f): PB { val a = r.getOrPut(b) { FloatArray(6) }; a[3] += x; a[4] += y; a[5] += z; return this }
        fun morph(n: String, w: Float): PB { m[n] = max(m[n] ?: 0f, w.coerceIn(0f, 1f)); return this }
        /** Braço esquerdo (l) e direito (r) espelhados: [up] sobe, [fwd] vai para a frente (graus). */
        fun arms(up: Float, fwd: Float = 0f, upR: Float = up, fwdR: Float = fwd): PB {
            rot(LA, 0f, ARM_FWD * fwd, ARM_UP * up); rot(RA, 0f, -ARM_FWD * fwdR, -ARM_UP * upR); return this
        }
        fun legs(swingL: Float, swingR: Float, kneeL: Float = 0f, kneeR: Float = 0f): PB {
            rot(LL, LEG * swingL); rot(RL, LEG * swingR); rot(LK, kneeL); rot(RK, kneeR); return this
        }
        fun lean(deg: Float): PB = rot(UB, LEAN * deg)
    }

    private fun assemble(frames: List<Int>, pbs: List<PB>, ip: ByteArray): Clip {
        val bn = HashSet<String>(); val mn = HashSet<String>()
        for (pb in pbs) { bn.addAll(pb.r.keys); mn.addAll(pb.m.keys) }
        val bones = HashMap<String, List<BKey>>(); val morphs = HashMap<String, List<MKey>>()
        for (b in bn) bones[b] = frames.indices.map { i ->
            val a = pbs[i].r[b] ?: FloatArray(6); val q = Euler.quat(a[0], a[1], a[2])
            BKey(frames[i], floatArrayOf(a[3], a[4], a[5], q[0], q[1], q[2], q[3]), ip.copyOf())
        }
        for (n in mn) morphs[n] = frames.indices.map { i -> MKey(frames[i], pbs[i].m[n] ?: 0f) }
        return Clip(bones, morphs)
    }

    /** Amostra [f](fase 0..1, pose) a cada [step] quadros. Se [f] for periódica, o clip fecha sozinho (fase 1 = fase 0). */
    private fun sample(len: Int, step: Int = 3, f: (Float, PB) -> Unit): Clip {
        val frames = ArrayList<Int>(); var fr = 0
        while (fr < len) { frames.add(fr); fr += step }
        frames.add(len)
        return assemble(frames, frames.map { fi -> PB().also { f(fi.toFloat() / len, it) } }, CartoonMath.linearIp())
    }

    /** Sequência de poses-chave com curva suave (ease in-out) entre elas. */
    private fun k(frame: Int, pose: (PB) -> Unit): Pair<Int, (PB) -> Unit> = Pair(frame, pose)

    private fun seq(vararg ks: Pair<Int, (PB) -> Unit>): Clip {
        val l = ks.sortedBy { it.first }
        return assemble(l.map { it.first }, l.map { PB().also { pb -> it.second(pb) } }, CartoonMath.EASE)
    }

    private fun s(p: Float, k: Float = 1f, ph: Float = 0f): Float = sin(2f * PI.toFloat() * (p * k + ph))
    private fun hump(p: Float, k: Float = 1f): Float = abs(s(p, k * 0.5f))           // 0..1, "quica" duas vezes por ciclo de seno
    private fun decay(p: Float, rate: Float): Float = exp(-rate * p)

    val all: List<Def> by lazy {
        listOf(
            // ---------------- Idle
            Def("idle_breath", "Respiração exagerada", CartoonCat.IDLE) { sample(60) { p, b ->
                b.rot(UB, LEAN * (4f + 4f * s(p))); b.rot(UB2, LEAN * 3f * s(p, 1f, 0.1f)); b.rot(LS, 0f, 0f, 6f * s(p)); b.rot(RS, 0f, 0f, -6f * s(p))
                b.pos(C, 0f, 0.15f * s(p)); b.rot(HD, -3f * s(p, 1f, 0.15f)); b.arms(6f + 3f * s(p)) } },
            Def("idle_sway", "Balanço de espera", CartoonCat.IDLE) { sample(90) { p, b ->
                b.pos(C, 0.6f * s(p)); b.rot(UB, 0f, 0f, 5f * s(p)); b.rot(HD, 0f, 0f, -4f * s(p, 1f, 0.1f)); b.rot(LB, 0f, 0f, -3f * s(p))
                b.arms(4f * s(p, 1f, 0.25f) + 6f); b.rot(NK, 0f, 6f * s(p, 1f, 0.3f)) } },
            Def("idle_tap", "Impaciente (bate o pé)", CartoonCat.IDLE) { sample(48) { p, b ->
                val t = hump(p, 4f); b.rot(RL, LEG * 10f * t); b.rot(RK, 12f * t); b.rot(RF, -10f * t)
                b.rot(HD, 0f, 0f, 6f * s(p)); b.rot(UB, LEAN * 2f, 0f, 3f * s(p)); b.arms(8f, 0f); b.pos(C, 0f, -0.05f * t) } },
            // ---------------- Walking
            Def("walk_cartoon", "Caminhada cartunesca", CartoonCat.WALKING) { sample(24, 2) { p, b ->
                b.pos(C, 0.25f * s(p), 0.5f * hump(p, 2f) - 0.25f); b.legs(35f * s(p), -35f * s(p), 40f * maxOf(0f, s(p, 1f, 0.25f)), 40f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.arms(8f, 40f * s(p, 1f, 0.5f), 8f, 40f * s(p)); b.lean(8f); b.rot(UB, 0f, 9f * s(p)); b.rot(HD, 4f * s(p, 2f), -5f * s(p)) } },
            Def("walk_long", "Passos largos", CartoonCat.WALKING) { sample(36, 3) { p, b ->
                b.pos(C, 0f, 0.8f * hump(p, 2f) - 0.4f); b.legs(55f * s(p), -55f * s(p), 55f * maxOf(0f, s(p, 1f, 0.25f)), 55f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.arms(6f, 55f * s(p, 1f, 0.5f), 6f, 55f * s(p)); b.lean(12f); b.rot(UB, 0f, 14f * s(p)); b.rot(HD, 0f, -8f * s(p)) } },
            Def("walk_funny", "Caminhada engraçada", CartoonCat.WALKING) { sample(32, 2) { p, b ->
                b.pos(C, 0.5f * s(p), 0.6f * hump(p, 2f)); b.legs(20f * s(p), -20f * s(p), 70f * maxOf(0f, s(p, 1f, 0.25f)), 70f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.rot(UB, 0f, 0f, 10f * s(p)); b.rot(HD, 0f, 0f, -14f * s(p)); b.arms(25f + 15f * s(p, 2f), 20f, 25f - 15f * s(p, 2f), 20f)
                b.rot(LE, 0f, 40f); b.rot(RE, 0f, -40f) } },
            Def("walk_clumsy", "Caminhada desajeitada", CartoonCat.WALKING) { sample(40, 2) { p, b ->
                b.pos(C, 0.4f * s(p) + 0.2f * s(p, 3f), 0.35f * hump(p, 2f)); b.legs(30f * s(p) + 8f * s(p, 3f), -30f * s(p) + 8f * s(p, 2f), 25f * hump(p, 1f), 25f * hump(p, 1f))
                b.arms(14f + 10f * s(p, 2f, 0.3f), 30f * s(p, 1f, 0.7f), 14f + 10f * s(p, 3f), 30f * s(p, 1f, 0.2f))
                b.rot(UB, LEAN * 5f, 6f * s(p, 1f, 0.2f), 12f * s(p, 1f, 0.1f)); b.rot(HD, 6f * s(p, 2f), 0f, -10f * s(p, 1f, 0.4f)) } },
            // ---------------- Running
            Def("run_cartoon", "Corrida exagerada", CartoonCat.RUNNING) { sample(16, 1) { p, b ->
                b.pos(C, 0f, 1.2f * hump(p, 2f) - 0.4f); b.legs(70f * s(p), -70f * s(p), 90f * maxOf(0f, s(p, 1f, 0.25f)), 90f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.arms(10f, 60f * s(p, 1f, 0.5f), 10f, 60f * s(p)); b.rot(LE, 0f, 70f); b.rot(RE, 0f, -70f); b.lean(18f); b.rot(UB, 0f, 12f * s(p)); b.rot(HD, -10f) } },
            Def("run_fast", "Corrida acelerada", CartoonCat.RUNNING) { sample(10, 1) { p, b ->
                b.pos(C, 0f, 0.9f * hump(p, 2f) - 0.2f); b.legs(60f * s(p), -60f * s(p), 100f * maxOf(0f, s(p, 1f, 0.25f)), 100f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.arms(5f, 50f * s(p, 1f, 0.5f), 5f, 50f * s(p)); b.rot(LE, 0f, 80f); b.rot(RE, 0f, -80f); b.lean(26f); b.rot(HD, -16f) } },
            Def("run_panic", "Corrida desesperada", CartoonCat.RUNNING) { sample(14, 1) { p, b ->
                b.pos(C, 0f, 1f * hump(p, 2f) - 0.2f); b.legs(65f * s(p), -65f * s(p), 95f * maxOf(0f, s(p, 1f, 0.25f)), 95f * maxOf(0f, -s(p, 1f, 0.25f)))
                b.arms(70f + 25f * s(p), 20f * s(p, 1f, 0.5f), 70f - 25f * s(p), 20f * s(p)); b.lean(10f); b.rot(HD, 0f, 0f, 14f * s(p, 2f))
                b.rot(UB, 0f, 10f * s(p)); b.morph(MA, 0.8f); b.morph(SURPRISE, 0.7f) } },
            // ---------------- Reactions
            Def("react_surprise", "Surpresa (pulo)", CartoonCat.REACTIONS) { seq(
                k(0) { b -> b.arms(8f) },
                k(6) { b -> b.pos(C, 0f, -0.8f); b.lean(12f); b.legs(-10f, -10f, 40f, 40f); b.arms(0f, -10f) },
                k(12) { b -> b.pos(C, 0f, 2.6f); b.lean(-8f); b.arms(95f, 10f); b.rot(HD, -12f); b.morph(MA, 0.9f); b.morph(SURPRISE, 1f) },
                k(20) { b -> b.pos(C, 0f, -0.5f); b.lean(10f); b.legs(-5f, -5f, 35f, 35f); b.arms(60f, 10f); b.morph(SURPRISE, 0.8f) },
                k(28) { b -> b.pos(C, 0f, 0.1f); b.arms(40f); b.morph(SURPRISE, 0.6f) },
                k(36) { b -> b.arms(15f); b.morph(SURPRISE, 0.3f) }) },
            Def("react_scare", "Susto (arrepio)", CartoonCat.REACTIONS) { sample(40, 2) { p, b ->
                val a = decay(p, 2.5f); val sh = s(p, 7f)
                b.pos(C, 0.5f * sh * a, 0.6f * a); b.rot(UB, LEAN * -6f * a, 0f, 8f * sh * a); b.rot(HD, -10f * a, 0f, 10f * s(p, 7f, 0.25f) * a)
                b.arms(55f * a, -15f * a, 55f * a, -15f * a); b.legs(-8f * a, -8f * a, 30f * a, 30f * a); b.morph(SURPRISE, a); b.morph(MA, 0.6f * a) } },
            Def("react_confused", "Confusão (coça a cabeça)", CartoonCat.REACTIONS) { sample(60, 3) { p, b ->
                val on = (s(p, 0.5f) * 0.5f + 0.5f)
                b.rot(HD, 0f, 12f * s(p), 15f * on); b.rot(NK, 0f, 6f * s(p)); b.rot(UB, 0f, 0f, 3f * s(p))
                b.rot(RA, 0f, -ARM_FWD * 20f * on, -ARM_UP * 95f * on); b.rot(RE, 0f, -80f * on); b.rot(RW, 0f, 0f, 20f * s(p, 4f) * on)
                b.morph(TROUBLE, 0.8f * on) } },
            Def("react_joy", "Alegria (saltitar)", CartoonCat.REACTIONS) { sample(30, 2) { p, b ->
                b.pos(C, 0f, 1.1f * hump(p, 2f)); b.legs(0f, 0f, 20f * (1f - hump(p, 2f)), 20f * (1f - hump(p, 2f)))
                b.arms(80f + 25f * s(p, 2f), 10f, 80f - 25f * s(p, 2f), 10f); b.rot(HD, 0f, 0f, 8f * s(p)); b.rot(UB, 0f, 0f, 4f * s(p)); b.morph(SMILE, 1f) } },
            Def("react_sad", "Tristeza (desabar)", CartoonCat.REACTIONS) {
                seq(k(0) { b -> b.arms(8f) },
                    k(24) { b -> b.lean(16f); b.rot(HD, 22f); b.rot(NK, 8f); b.rot(LS, 0f, 0f, 10f); b.rot(RS, 0f, 0f, -10f); b.pos(C, 0f, -0.4f); b.arms(-6f); b.morph(TROUBLE, 1f) },
                    k(44) { b -> b.lean(15f); b.rot(HD, 24f); b.rot(NK, 8f); b.rot(LS, 0f, 0f, 14f); b.rot(RS, 0f, 0f, -14f); b.pos(C, 0f, -0.45f); b.arms(-8f); b.morph(TROUBLE, 1f) },
                    k(60) { b -> b.lean(16f); b.rot(HD, 22f); b.rot(NK, 8f); b.rot(LS, 0f, 0f, 10f); b.rot(RS, 0f, 0f, -10f); b.pos(C, 0f, -0.4f); b.arms(-6f); b.morph(TROUBLE, 1f) }) },
            // ---------------- Body Movement
            Def("body_lean", "Inclinação exagerada", CartoonCat.BODY) { sample(60) { p, b ->
                b.pos(C, 1f * s(p)); b.rot(UB, 0f, 0f, 18f * s(p)); b.rot(UB2, 0f, 0f, 10f * s(p)); b.rot(HD, 0f, 0f, -14f * s(p)); b.rot(LB, 0f, 0f, -8f * s(p))
                b.arms(15f, 0f, 15f, 0f) } },
            Def("body_sway", "Balanço de corpo", CartoonCat.BODY) { sample(48) { p, b ->
                b.pos(C, 0.5f * s(p), 0.3f * hump(p, 2f)); b.rot(UB, LEAN * 6f * s(p, 2f), 14f * s(p)); b.rot(LB, 0f, -10f * s(p)); b.rot(HD, 0f, -8f * s(p)); b.arms(20f + 10f * s(p, 2f)) } },
            Def("body_stretch", "Alongamento", CartoonCat.BODY) {
                seq(k(0) { b -> b.arms(8f) },
                    k(18) { b -> b.arms(150f, 0f, 150f, 0f); b.rot(UB, LEAN * -12f); b.rot(HD, -12f); b.pos(C, 0f, 0.4f); b.legs(0f, 0f, 0f, 0f); b.morph(MA, 0.6f) },
                    k(40) { b -> b.arms(160f, 0f, 160f, 0f); b.rot(UB, LEAN * -18f); b.rot(UB2, LEAN * -8f); b.rot(HD, -14f); b.pos(C, 0f, 0.5f); b.morph(MA, 0.9f) },
                    k(56) { b -> b.arms(60f); b.lean(8f); b.pos(C, 0f, -0.2f) },
                    k(72) { b -> b.arms(8f) }) },
            Def("body_shrink", "Contração (encolher)", CartoonCat.BODY) {
                seq(k(0) { b -> b.arms(8f) },
                    k(10) { b -> b.rot(LS, 0f, 0f, -18f); b.rot(RS, 0f, 0f, 18f); b.lean(18f); b.rot(HD, 14f); b.pos(C, 0f, -0.7f); b.legs(-6f, -6f, 30f, 30f); b.arms(-10f, 25f, -10f, 25f) },
                    k(28) { b -> b.rot(LS, 0f, 0f, -20f); b.rot(RS, 0f, 0f, 20f); b.lean(20f); b.rot(HD, 16f); b.pos(C, 0f, -0.75f); b.legs(-6f, -6f, 32f, 32f); b.arms(-10f, 25f, -10f, 25f) },
                    k(40) { b -> b.arms(8f) }) },
            // ---------------- Facial Expressions
            Def("face_blink", "Piscar cartunesco", CartoonCat.FACE) {
                seq(k(0) { b -> b.morph(BLINK, 0f) }, k(8) { b -> b.morph(BLINK, 0f) }, k(10) { b -> b.morph(BLINK, 1f); b.rot(HD, 3f) }, k(13) { b -> b.morph(BLINK, 0f) },
                    k(36) { b -> b.morph(BLINK, 0f) }, k(38) { b -> b.morph(BLINK, 1f); b.rot(HD, 4f) }, k(41) { b -> b.morph(BLINK, 0f) }, k(43) { b -> b.morph(BLINK, 1f) },
                    k(46) { b -> b.morph(BLINK, 0f) }, k(60) { b -> b.morph(BLINK, 0f) }) },
            Def("face_lookaround", "Olhar para os lados", CartoonCat.FACE) {
                seq(k(0) { b -> b.rot(HD, 0f, 0f) },
                    k(14) { b -> b.rot(HD, 0f, 35f); b.rot(NK, 0f, 10f); b.rot(LEYE, 0f, 15f); b.rot(REYE, 0f, 15f) },
                    k(30) { b -> b.rot(HD, 0f, 35f); b.rot(NK, 0f, 10f); b.rot(LEYE, 0f, 15f); b.rot(REYE, 0f, 15f) },
                    k(40) { b -> b.rot(HD, 0f, -35f); b.rot(NK, 0f, -10f); b.rot(LEYE, 0f, -15f); b.rot(REYE, 0f, -15f); b.morph(BLINK, 1f) },
                    k(41) { b -> b.rot(HD, 0f, -35f); b.rot(NK, 0f, -10f); b.rot(LEYE, 0f, -15f); b.rot(REYE, 0f, -15f); b.morph(BLINK, 1f) },
                    k(44) { b -> b.rot(HD, 0f, -35f); b.rot(NK, 0f, -10f); b.rot(LEYE, 0f, -15f); b.rot(REYE, 0f, -15f) },
                    k(58) { b -> b.rot(HD, 0f, -35f); b.rot(NK, 0f, -10f); b.rot(LEYE, 0f, -15f); b.rot(REYE, 0f, -15f) },
                    k(72) { b -> b.rot(HD, 0f, 0f) }) },
            Def("face_expressions", "Expressões exageradas", CartoonCat.FACE) {
                seq(k(0) { b -> b.rot(HD, 0f) },
                    k(14) { b -> b.morph(SMILE, 1f); b.rot(HD, 0f, 0f, 8f) },
                    k(30) { b -> b.morph(SURPRISE, 1f); b.morph(MA, 0.8f); b.rot(HD, -12f) },
                    k(48) { b -> b.morph(ANGRY, 1f); b.rot(HD, 10f); b.rot(NK, 5f) },
                    k(66) { b -> b.morph(TROUBLE, 1f); b.rot(HD, 12f, 0f, -10f) },
                    k(90) { b -> b.rot(HD, 0f) }) },
            Def("face_headbob", "Cabeça de boneco (bobblehead)", CartoonCat.FACE) { sample(24, 2) { p, b ->
                b.rot(HD, 10f * s(p, 2f), 8f * s(p), 8f * s(p, 1f, 0.25f)); b.rot(NK, 4f * s(p, 2f, 0.1f), 0f, 4f * s(p)); b.morph(SMILE, 0.6f) } },
            // ---------------- Slapstick
            Def("slap_slip", "Escorregão", CartoonCat.SLAPSTICK) {
                seq(k(0) { b -> b.arms(8f) },
                    k(8) { b -> b.legs(40f, -30f, 5f, 40f); b.rot(UB, LEAN * -10f); b.arms(30f, 15f, 30f, 15f) },
                    k(16) { b -> b.pos(C, 0f, 0.8f); b.rot(UB, LEAN * -28f); b.legs(55f, 30f, 10f, 20f); b.arms(120f, 0f, 120f, 0f); b.rot(HD, -15f); b.morph(SURPRISE, 1f); b.morph(MA, 1f) },
                    k(28) { b -> b.pos(C, 0f, -1.8f); b.rot(UB, LEAN * -15f); b.legs(85f, 85f, 70f, 70f); b.arms(40f, 30f, 40f, 30f); b.morph(TROUBLE, 0.8f) },
                    k(36) { b -> b.pos(C, 0f, -1.5f); b.rot(UB, LEAN * -8f); b.legs(85f, 85f, 70f, 70f); b.arms(30f); b.rot(HD, 8f); b.morph(TROUBLE, 1f) },
                    k(54) { b -> b.pos(C, 0f, -1.5f); b.rot(UB, LEAN * -8f); b.legs(85f, 85f, 70f, 70f); b.arms(30f); b.rot(HD, 8f); b.morph(TROUBLE, 1f) }) },
            Def("slap_trip", "Tropeço", CartoonCat.SLAPSTICK) {
                seq(k(0) { b -> b.arms(8f); b.legs(15f, -15f) },
                    k(6) { b -> b.legs(30f, -10f, 10f, 5f); b.lean(8f) },
                    k(12) { b -> b.lean(38f); b.pos(C, 0f, -0.3f, 0f); b.legs(-10f, 60f, 10f, 20f); b.arms(60f, 50f, 60f, 50f); b.rot(HD, -20f); b.morph(SURPRISE, 1f) },
                    k(20) { b -> b.lean(45f); b.pos(C, 0f, -0.9f); b.legs(-20f, 70f, 20f, 40f); b.arms(100f, 70f, 100f, 70f); b.morph(SURPRISE, 1f) },
                    k(32) { b -> b.lean(18f); b.pos(C, 0f, -0.2f); b.legs(10f, 10f, 20f, 20f); b.arms(40f, 20f, 40f, 20f); b.morph(SURPRISE, 0.5f) },
                    k(48) { b -> b.arms(8f) }) },
            Def("slap_fall", "Queda estilizada (de costas)", CartoonCat.SLAPSTICK) {
                seq(k(0) { b -> b.arms(8f) },
                    k(10) { b -> b.rot(UB, LEAN * -20f); b.arms(100f, 0f, 100f, 0f); b.pos(C, 0f, 0.3f); b.morph(SURPRISE, 1f) },
                    k(22) { b -> b.rot(UB, LEAN * -45f); b.rot(LB, LEAN * 40f); b.pos(C, 0f, -1.8f, 0.8f); b.arms(130f, 0f, 130f, 0f); b.legs(-70f, -70f, 10f, 10f); b.morph(MA, 1f) },
                    k(30) { b -> b.rot(UB, LEAN * -60f); b.rot(LB, LEAN * 20f); b.pos(C, 0f, -3.2f, 1.5f); b.arms(50f, 0f, 50f, 0f); b.legs(-60f, -60f, 5f, 5f) },
                    k(36) { b -> b.rot(UB, LEAN * -52f); b.rot(LB, LEAN * 24f); b.pos(C, 0f, -3.0f, 1.5f); b.arms(60f, 0f, 60f, 0f); b.legs(-60f, -60f, 5f, 5f); b.morph(TROUBLE, 1f) },
                    k(60) { b -> b.rot(UB, LEAN * -52f); b.rot(LB, LEAN * 24f); b.pos(C, 0f, -3.0f, 1.5f); b.arms(60f, 0f, 60f, 0f); b.legs(-60f, -60f, 5f, 5f); b.morph(TROUBLE, 1f) }) },
            Def("slap_recover", "Recuperando o equilíbrio", CartoonCat.SLAPSTICK) { sample(48, 2) { p, b ->
                val a = decay(p, 2f); val w = s(p, 3f)
                b.rot(UB, LEAN * 20f * w * a, 0f, 22f * s(p, 3f, 0.25f) * a); b.pos(C, 1.2f * s(p, 3f, 0.25f) * a); b.legs(25f * w * a, -25f * w * a, 20f * a, 20f * a)
                b.arms(70f * a * (1f + s(p, 3f)) * 0.5f + 20f * a, 40f * w * a, 70f * a * (1f - s(p, 3f)) * 0.5f + 20f * a, -40f * w * a); b.morph(SURPRISE, 0.8f * a) } },
            // ---------------- Hand Gestures
            Def("hand_point", "Apontar", CartoonCat.HANDS) {
                seq(k(0) { b -> b.arms(8f) },
                    k(14) { b -> b.rot(RA, 0f, -ARM_FWD * 75f, -ARM_UP * 70f); b.rot(RE, 0f, -8f); b.rot(HD, 0f, -10f); b.lean(4f) },
                    k(22) { b -> b.rot(RA, 0f, -ARM_FWD * 85f, -ARM_UP * 72f); b.rot(RE, 0f, -2f); b.rot(HD, 0f, -10f); b.lean(6f) },
                    k(28) { b -> b.rot(RA, 0f, -ARM_FWD * 75f, -ARM_UP * 70f); b.rot(RE, 0f, -8f); b.rot(HD, 0f, -10f); b.lean(4f) },
                    k(36) { b -> b.rot(RA, 0f, -ARM_FWD * 85f, -ARM_UP * 72f); b.rot(RE, 0f, -2f); b.rot(HD, 0f, -10f); b.lean(6f) },
                    k(48) { b -> b.arms(8f) }) },
            Def("hand_wave", "Acenar", CartoonCat.HANDS) { sample(36, 2) { p, b ->
                b.rot(RA, 0f, 0f, -ARM_UP * 105f); b.rot(RE, 0f, -50f + 12f * s(p, 2f)); b.rot(RW, 0f, 0f, -ARM_UP * 28f * s(p, 3f)); b.rot(HD, 0f, 0f, 6f * s(p))
                b.rot(UB, 0f, 0f, 3f * s(p)); b.arms(8f, 0f, 0f, 0f); b.morph(SMILE, 0.8f) } },
            Def("hand_talk", "Gesticular (explicar)", CartoonCat.HANDS) { sample(60, 3) { p, b ->
                b.arms(25f + 12f * s(p, 2f), 40f + 20f * s(p, 2f, 0.25f), 25f - 12f * s(p, 2f), 40f - 20f * s(p, 2f, 0.25f)); b.rot(LE, 0f, 35f + 12f * s(p, 2f)); b.rot(RE, 0f, -35f - 12f * s(p, 2f, 0.1f))
                b.rot(HD, 6f * s(p, 2f), 5f * s(p), 0f); b.rot(UB, LEAN * 3f, 4f * s(p)); b.morph(MA, 0.6f * hump(p, 4f)) } },
            Def("hand_celebrate", "Braços expressivos (celebrar)", CartoonCat.HANDS) { sample(40, 2) { p, b ->
                b.arms(90f + 55f * s(p), 5f, 90f - 55f * s(p), 5f); b.rot(LW, 0f, 0f, 20f * s(p, 2f)); b.rot(RW, 0f, 0f, -20f * s(p, 2f)); b.pos(C, 0f, 0.4f * hump(p, 2f))
                b.rot(HD, 0f, 0f, 8f * s(p)); b.morph(SMILE, 1f) } }
        )
    }

    fun byId(id: String): Def? = all.firstOrNull { it.id == id }
}
