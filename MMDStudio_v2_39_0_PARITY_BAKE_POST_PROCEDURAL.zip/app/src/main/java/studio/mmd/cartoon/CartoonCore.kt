package studio.mmd.cartoon

import studio.mmd.edit.BKey
import studio.mmd.edit.MKey
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdTrack
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * v1.28.0 — Cartoon Motion Library, núcleo PURO (sem Android): modelo de clip, intensidade, velocidade, repetição, trecho,
 * suavização e combinação por grupos de ossos. Reaproveita [BKey]/[MKey] do Editor e o [VmdMotion] do parser;
 * a reprodução continua sendo a do Animator (não existe um segundo sistema de animação).
 */
enum class CartoonCat(val label: String) {
    IDLE("Idle"), WALKING("Walking"), RUNNING("Running"), REACTIONS("Reactions"),
    BODY("Body Movement"), FACE("Facial Expressions"), SLAPSTICK("Slapstick"), HANDS("Hand Gestures");
    companion object { fun fromName(s: String): CartoonCat = values().firstOrNull { it.name == s } ?: BODY }
}

/** Grupos usados para combinar movimentos sem conflito: cada osso pertence a UM grupo, e cada grupo vem de UMA fonte. */
enum class BoneGroup(val label: String) { BODY("Corpo"), HEAD("Cabeça"), ARMS("Braços"), LEGS("Pernas"), FACE("Rosto (morphs)") }

object BoneGroups {
    fun of(bone: String): BoneGroup = when {
        bone == "頭" || bone == "首" || bone.contains("目") -> BoneGroup.HEAD
        bone.contains("肩") || bone.contains("腕") || bone.contains("ひじ") || bone.contains("手") || bone.contains("指") -> BoneGroup.ARMS
        bone.contains("足") || bone.contains("ひざ") || bone.contains("つま先") || bone.contains("ＩＫ") || bone.contains("IK") -> BoneGroup.LEGS
        else -> BoneGroup.BODY
    }
}

/** Um movimento: trilhas de ossos e de morphs em quadros de 30 fps, com curvas Bézier preservadas. */
class Clip(val bones: Map<String, List<BKey>>, val morphs: Map<String, List<MKey>>) {
    val length: Int get() {
        var m = 0
        for (l in bones.values) if (l.isNotEmpty()) m = max(m, l[l.size - 1].frame)
        for (l in morphs.values) if (l.isNotEmpty()) m = max(m, l[l.size - 1].frame)
        return m
    }

    /** Fração (0..1) das trilhas de osso que existem no modelo. Sem ossos no clip (só morphs): fração dos morphs. */
    fun compat(modelBones: Set<String>, modelMorphs: Set<String>): Float {
        if (bones.isNotEmpty()) return bones.keys.count { it in modelBones }.toFloat() / bones.size
        if (morphs.isNotEmpty()) return morphs.keys.count { it in modelMorphs }.toFloat() / morphs.size
        return 0f
    }

    /** Miniatura: "energia" do movimento (soma dos ângulos dos ossos) em [bins] pontos, normalizada para 0..1. */
    fun energy(bins: Int): FloatArray {
        val out = FloatArray(bins); val len = max(length, 1); val o = FloatArray(7)
        for (b in 0 until bins) {
            val f = len * (b + 0.5f) / bins; var e = 0f
            for (l in bones.values) {
                CartoonMath.sample(l, f, o)
                val w = abs(o[6]).coerceAtMost(1f)
                e += 2f * acos(w) + sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]) * 0.15f
            }
            for (l in morphs.values) e += CartoonMath.sampleM(l, f) * 0.6f
            out[b] = e
        }
        val mx = out.maxOrNull() ?: 0f
        if (mx > 1e-6f) for (i in out.indices) out[i] /= mx
        return out
    }

    companion object {
        fun from(mo: VmdMotion): Clip {
            val b = HashMap<String, List<BKey>>()
            for ((n, t) in mo.bones) b[n] = List(t.frames.size) { i -> BKey(t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)) }
            val m = HashMap<String, List<MKey>>()
            for ((n, t) in mo.morphs) m[n] = List(t.frames.size) { i -> MKey(t.frames[i], t.w[i]) }
            return Clip(b, m)
        }
    }
}

/** Parâmetros de aplicação (P2). Quadros de início/fim são do clip ORIGINAL; [atFrame] é onde cai na timeline. */
data class CartoonParams(
    val speed: Float = 1f,        // 0.25..4: >1 = mais rápido
    val intensity: Float = 1f,    // 0..2: escala as rotações (eixo-ângulo) e as posições
    val loops: Int = 1,           // repetições (1..16)
    val srcStart: Int = 0,
    val srcEnd: Int = -1,         // -1 = até o fim
    val smooth: Float = 0f,       // 0..1: suaviza as curvas e, em movimento que não fecha, a emenda entre repetições
    val atFrame: Int = 0
)

/** Resultado pronto para o Editor ([bones]/[morphs] já deslocados para [CartoonParams.atFrame]). */
class Built(val bones: Map<String, List<BKey>>, val morphs: Map<String, List<MKey>>, val first: Int, val last: Int) {
    val keyCount: Int get() = bones.values.sumOf { it.size } + morphs.values.sumOf { it.size }
    val isEmpty: Boolean get() = bones.isEmpty() && morphs.isEmpty()

    /** Para a prévia: o mesmo conteúdo como VmdMotion (quadros absolutos). */
    fun toMotion(ikOff: List<String> = emptyList()): VmdMotion {
        val b = HashMap<String, VmdTrack>()
        for ((n, l) in bones) {
            val v = FloatArray(l.size * 7); val ip = ByteArray(l.size * 16)
            for (i in l.indices) { l[i].v.copyInto(v, i * 7); l[i].ip.copyInto(ip, i * 16) }
            b[n] = VmdTrack(IntArray(l.size) { l[it].frame }, v, ip)
        }
        val m = HashMap<String, VmdMorphTrack>()
        for ((n, l) in morphs) m[n] = VmdMorphTrack(IntArray(l.size) { l[it].frame }, FloatArray(l.size) { l[it].w })
        val ex = if (ikOff.isEmpty()) studio.mmd.mmd.VmdExtras.EMPTY
            else studio.mmd.mmd.VmdExtras(ik = ikOff.associateWith { studio.mmd.mmd.VmdIkTrack(intArrayOf(0), booleanArrayOf(false)) })   // prévia: IKs das pernas desligados
        return VmdMotion("cartoon", b, m, last, emptyList(), ex)
    }
}

object CartoonMath {
    val EASE = byteArrayOf(50, 50, 50, 50, 0, 0, 0, 0, 77, 77, 77, 77, 127, 127, 127, 127)   // ease in-out

    fun linearIp(): ByteArray { val a = ByteArray(16); for (i in 0..3) { a[i] = 20; a[4 + i] = 20; a[8 + i] = 107; a[12 + i] = 107 }; return a }

    private fun bez(ip: ByteArray, i1: Int, i2: Int, i3: Int, i4: Int, s: Float): Float {
        val x1 = (ip[i1].toInt() and 0xFF) / 127f; val y1 = (ip[i2].toInt() and 0xFF) / 127f
        val x2 = (ip[i3].toInt() and 0xFF) / 127f; val y2 = (ip[i4].toInt() and 0xFF) / 127f
        if (x1 == y1 && x2 == y2) return s
        var lo = 0f; var hi = 1f; var t = s
        for (k in 0 until 18) {
            t = (lo + hi) / 2; val u = 1 - t
            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
            if (x < s) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
    }

    /** Valor (pos xyz + quat xyzw) da trilha no quadro [f], interpolado como o Animator/Editor fazem. */
    fun sample(l: List<BKey>, f: Float, o: FloatArray) {
        if (l.isEmpty()) { o.fill(0f); o[6] = 1f; return }
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) { l[0].v.copyInto(o); return }
        if (i == l.size - 1) { l[i].v.copyInto(o); return }
        val a = l[i]; val b = l[i + 1]
        val s = (f - a.frame) / (b.frame - a.frame)
        val sx = bez(b.ip, 0, 4, 8, 12, s); val sy = bez(b.ip, 1, 5, 9, 13, s); val sz = bez(b.ip, 2, 6, 10, 14, s); val sr = bez(b.ip, 3, 7, 11, 15, s)
        o[0] = a.v[0] + (b.v[0] - a.v[0]) * sx; o[1] = a.v[1] + (b.v[1] - a.v[1]) * sy; o[2] = a.v[2] + (b.v[2] - a.v[2]) * sz
        var dot = 0f
        for (c in 0..3) dot += a.v[3 + c] * b.v[3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val q = a.v[3 + c] * (1 - sr) + b.v[3 + c] * sg * sr; o[3 + c] = q; len += q * q }
        len = sqrt(len)
        if (len > 1e-8f) for (c in 0..3) o[3 + c] /= len
    }

    fun sampleM(l: List<MKey>, f: Float): Float {
        if (l.isEmpty()) return 0f
        var lo = 0; var hi = l.size - 1; var i = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (l[mid].frame <= f) { i = mid; lo = mid + 1 } else hi = mid - 1 }
        if (i < 0) return l[0].w
        if (i == l.size - 1) return l[i].w
        val s = (f - l[i].frame) / (l[i + 1].frame - l[i].frame)
        return l[i].w + (l[i + 1].w - l[i].w) * s
    }

    /** Intensidade: rotação em eixo-ângulo (ângulo × k, vale k > 1) e posição × k. k = 1 devolve o mesmo valor. */
    fun scaleKey(v: FloatArray, k: Float): FloatArray {
        val o = v.copyOf()
        if (k == 1f) return o
        o[0] *= k; o[1] *= k; o[2] *= k
        var qx = v[3]; var qy = v[4]; var qz = v[5]; var qw = v[6]
        if (qw < 0) { qx = -qx; qy = -qy; qz = -qz; qw = -qw }
        val sn = sqrt(qx * qx + qy * qy + qz * qz)
        if (sn < 1e-6f) { o[3] = 0f; o[4] = 0f; o[5] = 0f; o[6] = 1f; return o }
        val ang = 2f * acos(qw.coerceIn(-1f, 1f)) * k
        val h = ang / 2f; val s = sin(h) / sn
        o[3] = qx * s; o[4] = qy * s; o[5] = qz * s; o[6] = kotlin.math.cos(h)
        return o
    }

    private fun mixIp(ip: ByteArray, w: Float): ByteArray {
        if (w <= 0f) return ip
        val o = ByteArray(16)
        for (i in 0 until 16) o[i] = ((ip[i].toInt() and 0xFF) * (1 - w) + (EASE[i].toInt() and 0xFF) * w).roundToInt().coerceIn(0, 127).toByte()
        return o
    }

    private fun near(a: FloatArray, b: FloatArray): Boolean {
        for (i in 0..2) if (abs(a[i] - b[i]) > 0.02f) return false
        var d = 0f; for (i in 3..6) d += a[i] * b[i]
        return abs(d) > 0.9995f
    }

    /** O trecho [s, e] termina como começou (todas as trilhas)? Então repete sem emenda. */
    fun isClosed(clip: Clip, s: Int, e: Int): Boolean {
        val a = FloatArray(7); val b = FloatArray(7)
        for (l in clip.bones.values) { sample(l, s.toFloat(), a); sample(l, e.toFloat(), b); if (!near(a, b)) return false }
        for (l in clip.morphs.values) if (abs(sampleM(l, s.toFloat()) - sampleM(l, e.toFloat())) > 0.02f) return false
        return true
    }

    /** Duração (quadros) de um ciclo já com velocidade e emenda — usada pela UI para mostrar a duração resultante. */
    fun cycleFrames(clip: Clip, p: CartoonParams): Int {
        val (s, e) = range(clip, p)
        val core = max(1, ((e - s) / p.speed.coerceIn(0.1f, 8f)).roundToInt())
        return core + seamOf(clip, p, s, e)
    }

    fun range(clip: Clip, p: CartoonParams): Pair<Int, Int> {
        val len = max(clip.length, 1)
        val s = p.srcStart.coerceIn(0, len - 1)
        var e = if (p.srcEnd < 0) len else min(p.srcEnd, len)
        if (e <= s) e = len
        return s to e
    }

    /** Quadros de emenda entre repetições de um movimento que NÃO fecha (termina diferente de como começa): no mínimo 1, para não perder a pose final. */
    private fun seamOf(clip: Clip, p: CartoonParams, s: Int, e: Int, repeats: Boolean = p.loops > 1): Int =
        if (repeats && !isClosed(clip, s, e)) max(1, (p.smooth.coerceIn(0f, 1f) * 12f).roundToInt()) else 0

    private fun addKey(out: ArrayList<BKey>, k: BKey) {
        if (out.isNotEmpty() && out[out.size - 1].frame == k.frame) out[out.size - 1] = k else out.add(k)
    }

    /**
     * Gera as trilhas de UM clip com os parâmetros dados. [groups] limita aos grupos de ossos desejados (null = todos);
     * o grupo FACE controla os morphs. [fitLen] (opcional): repete até cobrir esse tamanho e corta nele (usado pela camada de cima).
     */
    fun build(clip: Clip, p: CartoonParams, groups: Set<BoneGroup>?, fitLen: Int? = null): Built {
        val (s, e) = range(clip, p)
        val speed = p.speed.coerceIn(0.1f, 8f); val k = p.intensity.coerceIn(0f, 3f); val sm = p.smooth.coerceIn(0f, 1f)
        val core = max(1, ((e - s) / speed).roundToInt())
        val closed = isClosed(clip, s, e)
        val seam = seamOf(clip, p, s, e, p.loops > 1 || fitLen != null)
        val cycle = core + seam
        val loops = if (fitLen != null) max(1, ceil(fitLen.toFloat() / cycle).toInt()) else p.loops.coerceIn(1, 64)
        val base = p.atFrame.coerceAtLeast(0)
        val outB = HashMap<String, List<BKey>>(); val outM = HashMap<String, List<MKey>>()
        var first = Int.MAX_VALUE; var last = 0
        val tmp = FloatArray(7)

        for ((name, l) in clip.bones) {
            if (groups != null && BoneGroups.of(name) !in groups) continue
            if (l.isEmpty()) continue
            // keys do trecho + chaves amostradas nas bordas
            val seg = ArrayList<BKey>()
            sample(l, s.toFloat(), tmp); seg.add(BKey(s, tmp.copyOf(), l[0].ip))
            for (key in l) if (key.frame > s && key.frame < e) seg.add(key)
            sample(l, e.toFloat(), tmp)
            val nextIp = l.firstOrNull { it.frame >= e }?.ip ?: l[l.size - 1].ip
            seg.add(BKey(e, tmp.copyOf(), nextIp))
            val res = ArrayList<BKey>()
            for (c in 0 until loops) {
                val off = base + c * cycle
                for ((i, key) in seg.withIndex()) {
                    if (c > 0 && closed && i == 0) continue                  // ponto de emenda já existe (fim do ciclo anterior)
                    val fr = off + ((key.frame - s) / speed).roundToInt()
                    addKey(res, BKey(fr, scaleKey(key.v, k), mixIp(key.ip, sm)))
                }
            }
            val cut = if (fitLen != null) trimTo(res, base + fitLen) else res
            if (cut.isNotEmpty()) { outB[name] = cut; first = min(first, cut[0].frame); last = max(last, cut[cut.size - 1].frame) }
        }

        if (groups == null || BoneGroup.FACE in groups) for ((name, l) in clip.morphs) {
            if (l.isEmpty()) continue
            val seg = ArrayList<MKey>()
            seg.add(MKey(s, sampleM(l, s.toFloat())))
            for (key in l) if (key.frame > s && key.frame < e) seg.add(key)
            seg.add(MKey(e, sampleM(l, e.toFloat())))
            val res = ArrayList<MKey>()
            for (c in 0 until loops) {
                val off = base + c * cycle
                for ((i, key) in seg.withIndex()) {
                    if (c > 0 && closed && i == 0) continue
                    val fr = off + ((key.frame - s) / speed).roundToInt()
                    val w = (key.w * k).coerceIn(0f, 1f)
                    if (res.isNotEmpty() && res[res.size - 1].frame == fr) res[res.size - 1] = MKey(fr, w) else res.add(MKey(fr, w))
                }
            }
            val cut = if (fitLen != null) trimToM(res, base + fitLen) else res
            if (cut.isNotEmpty()) { outM[name] = cut; first = min(first, cut[0].frame); last = max(last, cut[cut.size - 1].frame) }
        }
        if (first == Int.MAX_VALUE) first = base
        return Built(outB, outM, first, last)
    }

    /** Corta a lista em [limit] (inclusive), amostrando o valor exato do corte para não dar salto. */
    private fun trimTo(l: ArrayList<BKey>, limit: Int): ArrayList<BKey> {
        if (l.isEmpty() || l[l.size - 1].frame <= limit) return l
        val o = FloatArray(7); sample(l, limit.toFloat(), o)
        val out = ArrayList<BKey>()
        for (k in l) if (k.frame < limit) out.add(k)
        val ip = l.firstOrNull { it.frame >= limit }?.ip ?: linearIp()
        out.add(BKey(limit, o.copyOf(), ip))
        return out
    }

    private fun trimToM(l: ArrayList<MKey>, limit: Int): ArrayList<MKey> {
        if (l.isEmpty() || l[l.size - 1].frame <= limit) return l
        val w = sampleM(l, limit.toFloat())
        val out = ArrayList<MKey>()
        for (k in l) if (k.frame < limit) out.add(k)
        out.add(MKey(limit, w))
        return out
    }

    /**
     * P3 — combinar: [over] (outro clip) assume os grupos [overGroups]; o clip base fica com todo o resto.
     * Como cada osso/morph vem de uma única fonte, não há conflito de ossos. A camada de cima repete (loop) para cobrir a duração da base
     * (ou toca uma vez e para, se [overLoop] = false). Velocidade/intensidade da camada de cima são as dela ([pOver]).
     */
    fun combine(base: Clip, pBase: CartoonParams, over: Clip?, pOver: CartoonParams, overGroups: Set<BoneGroup>, overLoop: Boolean = true): Built {
        if (over == null || overGroups.isEmpty()) return build(base, pBase, null)
        val keep = BoneGroup.values().toSet() - overGroups
        val a = build(base, pBase, keep)
        val len = max(1, a.last - pBase.atFrame)
        val b = build(over, pOver.copy(atFrame = pBase.atFrame, loops = 1), overGroups, if (overLoop) len else null)
        val bones = HashMap<String, List<BKey>>(a.bones); bones.putAll(b.bones)
        val morphs = HashMap<String, List<MKey>>(a.morphs); morphs.putAll(b.morphs)
        val fr = min(a.first, b.first); val ls = max(a.last, b.last)
        return Built(bones, morphs, fr, ls)
    }
}
