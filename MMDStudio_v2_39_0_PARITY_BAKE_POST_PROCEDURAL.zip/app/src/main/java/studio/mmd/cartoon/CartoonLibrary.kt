package studio.mmd.cartoon

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import studio.mmd.mmd.VmdParser
import java.io.File

/** Item da biblioteca: da casa (gerado em código) ou do usuário (VMD copiado para filesDir/cartoon). */
class CartoonItem(val id: String, val name: String, val cat: CartoonCat, val frames: Int, val builtin: Boolean, val file: String = "") {
    val seconds: Float get() = frames / 30f
}

/**
 * v1.28.0 — biblioteca de movimentos cartunescos. Movimentos "da casa" vêm de [CartoonBuiltin] (sem arquivos externos); os do usuário
 * são arquivos .vmd importados localmente (copiados para o armazenamento do app: nada depende de link externo) + library.json.
 * A reprodução usa o mesmo Animator/Editor dos demais movimentos.
 */
object CartoonLibrary {
    val items = mutableStateListOf<CartoonItem>()
    private val cache = HashMap<String, Clip>()
    private fun dir(ctx: Context) = File(ctx.filesDir, "cartoon").also { it.mkdirs() }

    fun load(ctx: Context) {
        items.clear(); cache.clear()
        for (d in CartoonBuiltin.all) {
            try { val c = d.make(); cache[d.id] = c; items.add(CartoonItem(d.id, d.name, d.cat, c.length, true)) }
            catch (e: Throwable) { studio.mmd.util.Log.e("Cartoon", "Movimento da casa '${d.id}' falhou", e) }
        }
        try {
            val f = File(dir(ctx), "library.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (File(dir(ctx), o.getString("file")).exists())
                        items.add(CartoonItem(o.getString("id"), o.getString("name"), CartoonCat.fromName(o.optString("cat", "BODY")), o.optInt("frames"), false, o.getString("file")))
                }
            }
        } catch (e: Exception) { studio.mmd.util.Log.e("Cartoon", "library.json ilegível (arquivos preservados)", e) }
    }

    /** Clip do item (VMD do usuário é lido na primeira vez e guardado em cache). Null se o arquivo sumiu ou não abre. */
    fun clipOf(ctx: Context, it: CartoonItem): Clip? {
        cache[it.id]?.let { c -> return c }
        if (it.builtin) return null
        return try {
            val c = Clip.from(VmdParser.parse(File(dir(ctx), it.file).readBytes())); cache[it.id] = c; c
        } catch (e: Throwable) { studio.mmd.util.Log.e("Cartoon", "VMD '${it.name}' não abriu", e); null }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        for (v in items) if (!v.builtin) a.put(JSONObject().put("id", v.id).put("name", v.name).put("cat", v.cat.name).put("frames", v.frames).put("file", v.file))
        File(dir(ctx), "library.json").writeText(a.toString())
    }

    /** Importa um .vmd escolhido pelo usuário. Falha com mensagem clara se não for VMD ou não tiver keys de osso/morph. */
    fun importVmd(ctx: Context, uri: Uri, displayName: String, cat: CartoonCat): CartoonItem {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("Não consegui ler o arquivo")
        val mo = VmdParser.parse(bytes)                               // lança com mensagem se a assinatura/estrutura for inválida
        val clip = Clip.from(mo)
        if (clip.bones.isEmpty() && clip.morphs.isEmpty()) throw IllegalArgumentException("Este VMD não tem movimento de ossos nem de morphs (só câmera/luz?)")
        val id = "u_" + System.currentTimeMillis()
        val fn = "$id.vmd"
        File(dir(ctx), fn).writeBytes(bytes)
        val item = CartoonItem(id, displayName.substringBeforeLast('.').ifBlank { "Movimento" }, cat, clip.length, false, fn)
        cache[id] = clip; items.add(item); save(ctx)
        return item
    }

    fun remove(ctx: Context, it: CartoonItem) {
        if (it.builtin) return
        File(dir(ctx), it.file).delete(); cache.remove(it.id); items.remove(it); save(ctx)
    }
}
