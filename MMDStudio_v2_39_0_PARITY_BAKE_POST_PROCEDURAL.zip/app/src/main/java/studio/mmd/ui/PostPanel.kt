package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.export.PostFxConfig
import kotlin.math.roundToInt

@Composable
fun PostPanel(config: PostFxConfig, onChange: (PostFxConfig) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).verticalScroll(rememberScrollState()).padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("POST STUDIO · COMPOSITOR DE EXPORTAÇÃO", color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Switch(checked = config.enabled, onCheckedChange = { onChange(config.copy(enabled = it)) })
        }
        Text("Grade não destrutivo aplicado a PNG, sequência e MP4. A prévia original da viewport não é alterada.", color = Muted, fontSize = 9.sp)
        PostSlider("Exposição", config.exposure, -3f..3f, { onChange(config.copy(exposure = it)) }, " EV")
        PostSlider("Contraste", config.contrast, 0f..2f, { onChange(config.copy(contrast = it)) })
        PostSlider("Saturação", config.saturation, 0f..2f, { onChange(config.copy(saturation = it)) })
        PostSlider("Vinheta", config.vignette, 0f..1f, { onChange(config.copy(vignette = it)) })
        PostSlider("Grão de filme", config.grain, 0f..0.12f, { onChange(config.copy(grain = it)) })
        PostSlider("Aberração RGB", config.chromaticAberration, 0f..6f, { onChange(config.copy(chromaticAberration = it)) }, " px")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Tone mapping ACES", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = config.toneMap, onCheckedChange = { onChange(config.copy(toneMap = it)) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(onClick = { onChange(PostFxConfig(enabled = true, exposure = .15f, contrast = 1.08f, saturation = .92f, vignette = .28f, grain = .018f)) }, modifier = Modifier.weight(1f)) { Text("Cinema") }
            Button(onClick = { onChange(PostFxConfig()) }, modifier = Modifier.weight(1f)) { Text("Original") }
        }
    }
}

@Composable
private fun PostSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, suffix: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(86.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValue, valueRange = range, modifier = Modifier.weight(1f))
        Text("${(value * 100f).roundToInt() / 100f}$suffix", color = Color.White, fontSize = 9.sp, modifier = Modifier.width(46.dp))
    }
}
