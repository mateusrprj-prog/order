package studio.mmd.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import studio.mmd.ai.TextAnim
import studio.mmd.edit.Editor

/**
 * "Animar com IA (texto)": descreve o movimento em português; a IA devolve poses (direções dos membros) que o app converte nos
 * ossos do modelo atual e grava como keyframes a partir do quadro atual (um único passo de desfazer).
 * A chave da API é a do próprio usuário (console.anthropic.com) e fica só neste aparelho.
 */
@Composable
fun AiAnimDialog(ed: Editor, currentFrame: Int, timelineFps: Int, onClose: () -> Unit, onDone: (String, Int) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("mmdstudio", android.content.Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(prefs.getString("ai_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("ai_model", TextAnim.DEFAULT_MODEL) ?: TextAnim.DEFAULT_MODEL) }
    var prompt by remember { mutableStateOf("") }
    var secs by remember { mutableStateOf(5f) }
    var stage by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    val running = job?.isActive == true

    fun run() {
        val k = key.trim()
        if (k.isEmpty()) { err = "Cole a sua chave de API da Anthropic (console.anthropic.com)."; return }
        if (prompt.isBlank()) { err = "Descreva o movimento que você quer."; return }
        val m = model.trim().ifEmpty { TextAnim.DEFAULT_MODEL }
        prefs.edit().putString("ai_key", k).putString("ai_model", m).apply()
        val start = currentFrame; val dur = secs
        err = null; stage = "Pedindo a animação à IA… (pode levar até 1–2 min)"
        job = scope.launch {
            try {
                val text = withContext(Dispatchers.IO) { TextAnim.request(k, m, TextAnim.systemPrompt(ed.model), TextAnim.userPrompt(prompt, dur)) }
                stage = "Convertendo para os ossos do modelo…"
                val r = withContext(Dispatchers.Default) { TextAnim.build(ed.model, text, start, timelineFps) }
                val n = ed.applyAnim(r.tracks, r.morphs, start, r.last)
                onDone("IA: \"${r.title}\" aplicada: $n keys em ${r.tracks.size} ossos e ${r.morphs.size} morphs, quadros $start–${r.last}.\nDesfazer descarta tudo de uma vez.", r.last)
                onClose()
            } catch (c: CancellationException) { throw c
            } catch (t: Throwable) { err = t.message ?: t.javaClass.simpleName
            } finally { stage = "" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!running) onClose() },
        title = { Text("Animar com IA (texto)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Descreva o movimento. A IA cria a animação no modelo atual, a partir do quadro $currentFrame.", fontSize = 12.sp)
                OutlinedTextField(prompt, { prompt = it }, label = { Text("Ex.: dança animada, pula de alegria e acena") },
                    minLines = 2, maxLines = 5, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !running)
                Row(Modifier.padding(top = 4.dp)) {
                    listOf("Acenar e sorrir", "Pular de alegria", "Dança animada", "Caminhar", "Reverência").forEach { s ->
                        Text(s, fontSize = 10.sp, color = Color(0xFF9AA0A6), modifier = Modifier.clickable(enabled = !running) { prompt = s }.padding(end = 8.dp, top = 4.dp, bottom = 4.dp))
                    }
                }
                Text("Duração: %.0f s".format(secs), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                Slider(secs, { secs = it }, valueRange = 2f..20f, enabled = !running)
                OutlinedTextField(key, { key = it }, label = { Text("Chave da API (Anthropic)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), enabled = !running)
                OutlinedTextField(model, { model = it }, label = { Text("Modelo") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp), enabled = !running)
                Text("A chave fica só neste aparelho e é enviada apenas à API da Anthropic. Cada geração consome créditos da sua conta da API.",
                    fontSize = 10.sp, color = Color(0xFF9AA0A6), modifier = Modifier.padding(top = 6.dp))
                if (stage.isNotEmpty()) Row(Modifier.padding(top = 10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("  $stage", fontSize = 12.sp)
                }
                err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = { TextButton({ run() }, enabled = !running) { Text("Gerar animação") } },
        dismissButton = { TextButton({ if (running) { job?.cancel(); stage = "" } else onClose() }) { Text(if (running) "Cancelar" else "Fechar") } }
    )
}
