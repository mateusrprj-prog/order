package studio.mmd.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.hypot
import kotlin.math.roundToInt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import studio.mmd.edit.WeightPaintMode
import studio.mmd.edit.WeightPaintSession
import androidx.compose.material3.FilterChip
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Button
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.edit.Editor
import studio.mmd.edit.Euler
import studio.mmd.mmd.Animator
import studio.mmd.rig.TwoBoneIkSolver
import studio.mmd.rig.TwoBoneIkLimits
import studio.mmd.rig.Vec3
import studio.mmd.mmd.PmxBone
import studio.mmd.rig.AXIS_NAMES
import studio.mmd.rig.CType
import studio.mmd.rig.Constraint
import studio.mmd.rig.SecPreset
import studio.mmd.rig.Secondary
import androidx.compose.material3.Switch
import kotlin.math.min

/** Painel do modo Esqueleto: abas Ossos / Osso / Pose / Morphs / Curva. */
@Composable
fun SkeletonPanel(
    ed: Editor, frame: Int,
    tab: Int, onTab: (Int) -> Unit,
    selBone: Int, onSelBone: (Int) -> Unit,
    selMorph: Int, onSelMorph: (Int) -> Unit,
    note: (String) -> Unit,
    onFrame: (Int) -> Unit,
    rig: List<Constraint>, onRig: (List<Constraint>) -> Unit,
    sec: List<Secondary>, onSec: (List<Secondary>) -> Unit, phys: studio.mmd.rig.PhysConfig, onPhys: (studio.mmd.rig.PhysConfig) -> Unit, onBake: () -> Unit, busy: Boolean,
    bonesShown: Boolean = true, onBonesShown: (Boolean) -> Unit = {},
    onTotal: (Int) -> Unit = {},
    modifier: Modifier = Modifier,
    rigOwner: String = "Personagem principal",
    rigConfig: studio.mmd.rig.RigConfig = studio.mmd.rig.RigState.main,
    onCache: (studio.mmd.rig.PhysCache?) -> Unit = {},
    parts: studio.mmd.rig.PartOverrides = studio.mmd.rig.PartOverrides(),
    onParts: (studio.mmd.rig.PartOverrides) -> Unit = {},
    onWeightCommit: ((WeightPaintSession) -> Unit)? = null
) {
    val titles = listOf("Ossos", "Osso", "Pose", "Morphs", "Curva", "Rig", "Keys", "Pesos")
    Column(modifier.background(Panel, RoundedCornerShape(8.dp))) {
        Row(Modifier.fillMaxWidth()) {
            titles.forEachIndexed { i, t ->
                Column(Modifier.weight(1f).clickable { onTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(t, color = if (i == tab) Color.White else Muted, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(vertical = 8.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(if (i == tab) Accent else Color.Transparent))
                }
            }
            // mostrar/ocultar os ossos desenhados sobre o modelo (a seleção e a edição continuam funcionando)
            androidx.compose.material3.Icon(
                if (bonesShown) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                if (bonesShown) "Ocultar ossos" else "Mostrar ossos",
                tint = if (bonesShown) Color.White else Muted,
                modifier = Modifier.clickable { onBonesShown(!bonesShown) }.padding(horizontal = 10.dp, vertical = 6.dp).size(26.dp)
            )
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp)) {
            when (tab) {
                0 -> BonesTab(ed, selBone, onSelBone)
                1 -> BoneTab(ed, frame, selBone, note)
                2 -> PoseTab(ed, frame, note)
                3 -> MorphTab(ed, frame, selMorph, onSelMorph)
                4 -> CurveTab(ed, frame, selBone, note, onFrame)
                5 -> RigTab(ed, frame, selBone, rig, onRig, sec, onSec, phys, onPhys, onBake, busy, note, rigOwner, rigConfig, onCache, parts, onParts, onSelBone)
                6 -> KeysTab(ed, frame, selBone, onSelBone, note, onFrame, onTotal)
                else -> WeightPaintPanel(ed, selBone, onSelBone, note, onWeightCommit)
            }
        }
    }
}

/** Ferramentas PMX de pesos: pincel esférico ancorado no osso, espelhamento e limpeza global. */
@Composable
private fun WeightPaintPanel(
    ed: Editor, selectedBone: Int, onSelectBone: (Int) -> Unit, note: (String) -> Unit,
    onCommit: ((WeightPaintSession) -> Unit)?
) {
    val session = remember(ed) { WeightPaintSession(ed.model) }
    var revision by remember(ed) { mutableIntStateOf(0) }
    var boneMenu by remember { mutableStateOf(false) }
    var radius by remember { mutableFloatStateOf(0.8f) }
    var strength by remember { mutableFloatStateOf(0.75f) }
    var targetWeight by remember { mutableFloatStateOf(1f) }
    var mode by remember { mutableStateOf(WeightPaintMode.REPLACE) }
    var positiveSource by remember { mutableStateOf(true) }
    val bone = ed.model.bones.getOrNull(selectedBone)
    @Suppress("UNUSED_VARIABLE") val redraw = revision
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("PINTURA DE PESOS PMX", color = Color.White, fontSize = 13.sp)
        Text("Editor de influência de ossos para BDEF1/BDEF2/BDEF4. O pincel esférico usa a posição de repouso do osso selecionado como centro.", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { boneMenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(bone?.name ?: "Selecione um osso", fontSize = 12.sp)
            }
            DropdownMenu(expanded = boneMenu, onDismissRequest = { boneMenu = false }) {
                ed.model.bones.forEachIndexed { i, b ->
                    DropdownMenuItem(text = { Text(b.name, fontSize = 12.sp) }, onClick = { onSelectBone(i); boneMenu = false })
                }
            }
        }
        SliderRow("Raio", radius, 0.05f..5f, "", 2, { radius = it }, {})
        SliderRow("Peso alvo", targetWeight, 0f..1f, "", 2, { targetWeight = it }, {})
        SliderRow("Força", strength, 0f..1f, "", 2, { strength = it }, {})
        Text("Modo de pintura", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FilterChip(selected = mode == WeightPaintMode.REPLACE, onClick = { mode = WeightPaintMode.REPLACE }, label = { Text("Substituir", fontSize = 10.sp) })
            FilterChip(selected = mode == WeightPaintMode.ADD, onClick = { mode = WeightPaintMode.ADD }, label = { Text("Adicionar", fontSize = 10.sp) })
            FilterChip(selected = mode == WeightPaintMode.SUBTRACT, onClick = { mode = WeightPaintMode.SUBTRACT }, label = { Text("Subtrair", fontSize = 10.sp) })
        }
        Button(enabled = bone != null, onClick = {
            val b = bone ?: return@Button
            val r = session.paintSphere(b.x, b.y, b.z, radius, selectedBone, targetWeight, strength, mode)
            revision++; note("Pincel de pesos: ${r.changed} vértices processados perto de ${b.name}")
        }, modifier = Modifier.fillMaxWidth()) { Text("Pintar região do osso", fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))
        Text("CORREÇÕES DA MALHA", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(onClick = { val r = session.normalizeAll(); revision++; note("Pesos normalizados: ${r.changed} vértices") }, modifier = Modifier.weight(1f)) { Text("Normalizar", fontSize = 10.sp) }
            OutlinedButton(onClick = { val r = session.prune(0.015f, 4); revision++; note("Influências removidas: ${r.removedInfluences}") }, modifier = Modifier.weight(1f)) { Text("Limpar pesos", fontSize = 10.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(onClick = { val r = session.smooth(2, 0.35f); revision++; note("Suavização de pesos aplicada em ${r.changed} vértices") }, modifier = Modifier.weight(1f)) { Text("Suavizar", fontSize = 10.sp) }
            OutlinedButton(onClick = { positiveSource = !positiveSource; val r = session.mirrorX(0.002f, positiveSource); revision++; note("Espelhamento concluído: ${r.changed} pares") }, modifier = Modifier.weight(1f)) { Text(if (positiveSource) "+X → -X" else "-X → +X", fontSize = 10.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(enabled = session.canUndo, onClick = { session.undo(); revision++ }, modifier = Modifier.weight(1f)) { Text("Desfazer", fontSize = 10.sp) }
            OutlinedButton(enabled = session.canRedo, onClick = { session.redo(); revision++ }, modifier = Modifier.weight(1f)) { Text("Refazer", fontSize = 10.sp) }
        }
        Button(enabled = onCommit != null, onClick = { onCommit?.invoke(session); revision++ }, modifier = Modifier.fillMaxWidth()) {
            Text("Aplicar ao modelo e salvar", fontSize = 12.sp)
        }
        if (onCommit == null) Text("A aplicação direta está disponível no personagem principal. Personagens extras ainda não têm persistência de malha separada.", color = Color(0xFFFFCC80), fontSize = 10.sp)
        Text("Vértices: ${session.vertexCount} · Ossos: ${session.boneCount}. Este pincel é baseado em esfera no espaço do modelo; seleção/pintura diretamente sob o dedo na viewport ainda não está conectada.", color = Muted, fontSize = 10.sp)
    }
}

// ------------------------------------------------------------------ componentes pequenos

@Composable
internal fun SearchBox(q: String, hint: String, onChange: (String) -> Unit) {
    BasicTextField(
        value = q, onValueChange = onChange, singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Accent),
        modifier = Modifier.fillMaxWidth().background(Color(0xFF101114), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 8.dp),
        decorationBox = { inner -> Box { if (q.isEmpty()) Text(hint, color = Muted, fontSize = 13.sp); inner() } }
    )
}

@Composable
private fun RowScope.Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled) { onClick() }.padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (enabled) Color.White else Color(0xFF5A5C62), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun MiniBtn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Text(text, color = if (enabled) Color.White else Color(0xFF5A5C62), fontSize = 11.sp, maxLines = 1,
        modifier = Modifier.padding(start = 6.dp).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled) { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp))
}

@Composable
private fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, digits: Int,
    onChange: (Float) -> Unit, onDone: () -> Unit
) {
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        if (label.isNotEmpty()) Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(16.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange,
            onValueChangeFinished = onDone, valueRange = range, modifier = Modifier.weight(1f)
        )
        Text("%.${digits}f%s".format(value, unit), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(58.dp))
    }
}

// ------------------------------------------------------------------ aba Ossos

private class BRow(val idx: Int, val depth: Int, val kids: Boolean)

private fun buildRows(bones: List<PmxBone>, q: String, collapsed: List<Int>): List<BRow> {
    val n = bones.size
    if (q.isNotBlank()) {
        val s = q.trim().lowercase()
        return bones.indices.filter { bones[it].name.lowercase().contains(s) || bones[it].nameEn.lowercase().contains(s) }.map { BRow(it, 0, false) }
    }
    val kids = Array(n) { ArrayList<Int>() }
    val roots = ArrayList<Int>()
    for (i in 0 until n) { val p = bones[i].parent; if (p in 0 until n && p != i) kids[p].add(i) else roots.add(i) }
    val out = ArrayList<BRow>(n)
    val seen = BooleanArray(n)
    fun walk(i: Int, d: Int) {
        if (seen[i]) return
        seen[i] = true
        out.add(BRow(i, d, kids[i].isNotEmpty()))
        if (i in collapsed) return
        for (c in kids[i]) walk(c, d + 1)
    }
    for (r in roots) walk(r, 0)
    return out
}

@Composable
private fun BonesTab(ed: Editor, sel: Int, onSel: (Int) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val bones = ed.model.bones
    var q by remember { mutableStateOf("") }
    val collapsed = remember { mutableStateListOf<Int>() }
    val rows = remember(ed, q, collapsed.toList()) { buildRows(bones, q, collapsed.toList()) }
    Column(Modifier.fillMaxSize()) {
        SearchBox(q, "Buscar osso") { q = it }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(rows, key = { it.idx }) { r ->
                val b = bones[r.idx]
                Row(
                    Modifier.fillMaxWidth().background(if (r.idx == sel) Accent.copy(alpha = .35f) else Color.Transparent)
                        .clickable { onSel(r.idx) }.padding(start = (min(r.depth, 12) * 10).dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (r.kids) (if (r.idx in collapsed) "▸" else "▾") else "·", color = Muted, fontSize = 14.sp,
                        modifier = Modifier.clickable(enabled = r.kids) { if (r.idx in collapsed) collapsed.remove(r.idx) else collapsed.add(r.idx) }
                            .padding(horizontal = 6.dp, vertical = 6.dp).width(16.dp)
                    )
                    Text(b.name.ifBlank { "osso ${r.idx}" }, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (b.nameEn.isNotBlank() && b.nameEn != b.name)
                        Text("  ${b.nameEn}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (ed.hasTrack(b.name)) Text("  ◆", color = Accent, fontSize = 11.sp)
                    Spacer(Modifier.width(6.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ aba Osso

@Composable
private fun BoneTab(ed: Editor, frame: Int, sel: Int, note: (String) -> Unit) {
    if (sel !in ed.model.bones.indices) {
        Text("Toque num osso no modelo ou escolha na aba Ossos.", color = Muted, fontSize = 12.sp)
        return
    }
    val b = ed.model.bones[sel]
    val name = b.name
    val rotatable = b.flags and 0x0002 != 0
    val movable = b.flags and 0x0004 != 0
    val showRot = rotatable || !movable
    val showMove = movable || !rotatable
    val stamp = ed.stamp
    val cur = remember(name, frame, stamp) { FloatArray(7).also { ed.sampleBone(name, frame.toFloat(), it) } }
    var eul by remember(name, frame, stamp) { mutableStateOf(Euler.euler(cur.copyOfRange(3, 7))) }
    var pos by remember(name, frame, stamp) { mutableStateOf(cur.copyOfRange(0, 3)) }
    val hasKey = ed.hasKey(name, frame)

    fun rot(e: FloatArray) { eul = e; ed.liveBone(name, frame, Euler.quat(e[0], e[1], e[2]), null) }
    fun move(p: FloatArray) { pos = p; ed.liveBone(name, frame, null, p) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text(name.ifBlank { "osso $sel" } + if (hasKey) "   ◆ keyframe neste quadro" else "", color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (showRot) {
            Text("Rotação (graus)", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            SliderRow("X", eul[0], -180f..180f, "°", 1, { rot(floatArrayOf(it, eul[1], eul[2])) }, { ed.finish() })
            SliderRow("Y", eul[1], -180f..180f, "°", 1, { rot(floatArrayOf(eul[0], it, eul[2])) }, { ed.finish() })
            SliderRow("Z", eul[2], -180f..180f, "°", 1, { rot(floatArrayOf(eul[0], eul[1], it)) }, { ed.finish() })
        }
        if (showMove) {
            Text("Posição", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            SliderRow("X", pos[0], -30f..30f, "", 2, { move(floatArrayOf(it, pos[1], pos[2])) }, { ed.finish() })
            SliderRow("Y", pos[1], -30f..30f, "", 2, { move(floatArrayOf(pos[0], it, pos[2])) }, { ed.finish() })
            SliderRow("Z", pos[2], -30f..30f, "", 2, { move(floatArrayOf(pos[0], pos[1], it)) }, { ed.finish() })
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Zerar osso") { ed.zeroBones(listOf(name), frame); note("Osso zerado no quadro $frame") }
            Btn("Espelhar") { note(if (ed.mirrorBone(name, frame)) "Copiado espelhado para o outro lado" else "Esse osso não tem par esquerdo/direito") }
            Btn("Resetar osso", enabled = hasKey) { ed.deleteKeys(listOf(name), frame); note("Keyframe removido") }
        }
        Text("Mexer nos valores cria ou atualiza o keyframe deste osso no quadro atual.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

// ------------------------------------------------------------------ aba Pose

@Composable
private fun PoseTab(ed: Editor, frame: Int, note: (String) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val all = remember(ed) { ed.model.bones.map { it.name }.distinct() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Keyframe de todos") { note("Keyframe em ${ed.keyBones(all, frame)} ossos (quadro $frame)") }
            Btn("Copiar pose") { note("Pose copiada (${ed.copyPose(frame)} ossos)") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Colar pose", enabled = ed.hasClip) { note("Pose colada em ${ed.pastePose(frame)} ossos") }
            Btn("Espelhar pose") { note("Pose espelhada (${ed.mirrorPose(frame)} ossos)") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Zerar pose") { note(if (ed.zeroPose(frame) == 0) "Nenhum osso animado ainda" else "Pose zerada no quadro $frame") }
            Btn("Resetar pose") { note("${ed.resetPose(frame)} keyframes removidos do quadro $frame") }
        }
        Text(
            "Zerar: grava rotação/posição neutras. Resetar: remove os keyframes deste quadro. " +
                "Espelhar: troca esquerda/direita e inverte o eixo X.",
            color = Muted, fontSize = 10.sp
        )
        Text("Biblioteca de poses (ossos + morphs)", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Salvar pose atual") {
                val n = "Pose ${studio.mmd.project.PoseLib.items.size + 1}"
                val sn = ed.snapshot(frame, n); studio.mmd.project.PoseLib.add(sn); note("$n salva (${sn.bones.size} ossos, ${sn.morphs.size} morphs)")
            }
        }
        if (studio.mmd.project.PoseLib.items.isEmpty()) Text("Nenhuma pose salva neste projeto.", color = Muted, fontSize = 10.sp)
        studio.mmd.project.PoseLib.items.forEachIndexed { i, p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${p.name} · ${p.bones.size} ossos", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
                Btn("Aplicar") { note("${p.name} aplicada em ${ed.applySnap(p, frame)} ossos (quadro $frame)") }
                Btn("Excluir") { studio.mmd.project.PoseLib.remove(i) }
            }
        }
    }
}

// ------------------------------------------------------------------ aba Morphs

@Composable
private fun MorphTab(ed: Editor, frame: Int, sel: Int, onSel: (Int) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val ver = ed.version
    val stamp = ed.stamp
    val morphs = ed.model.morphs
    var q by remember { mutableStateOf("") }
    // só os tipos que o Animator aplica hoje: grupo, vértice e osso
    val list = remember(ed, q) {
        val s = q.trim().lowercase()
        morphs.indices.filter { i ->
            val m = morphs[i]
            (m.type in 0..3 || m.type == 8 || m.type == 9) && (s.isEmpty() || m.name.lowercase().contains(s) || m.nameEn.lowercase().contains(s))
        }
    }
    Column(Modifier.fillMaxSize()) {
        SearchBox(q, "Buscar morph") { q = it }
        if (sel in morphs.indices) {
            val name = morphs[sel].name
            var w by remember(name, frame, stamp) { mutableFloatStateOf(ed.sampleMorph(name, frame.toFloat())) }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                MiniBtn("Zerar") { w = 0f; ed.zeroMorph(name, frame) }
                MiniBtn("Remover key", enabled = ed.hasMorphTrack(name)) { ed.deleteMorphKey(name, frame) }
                MiniBtn("Fechar") { onSel(-1) }
            }
            SliderRow("", w, 0f..1f, "", 2, { w = it; ed.liveMorph(name, frame, it) }, { ed.finish() })
        } else Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(list, key = { it }) { i ->
                val m = morphs[i]
                Row(
                    Modifier.fillMaxWidth().background(if (i == sel) Accent.copy(alpha = .35f) else Color.Transparent)
                        .clickable { onSel(if (i == sel) -1 else i) }.padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(m.name.ifBlank { "morph $i" }, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (m.nameEn.isNotBlank() && m.nameEn != m.name)
                        Text("  ${m.nameEn}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (ed.hasMorphTrack(m.name)) Text("  ◆", color = Accent, fontSize = 11.sp)
                }
            }
        }
    }
}


// ------------------------------------------------------------------ aba Curva

private val PRESETS = listOf(
    "Linear" to intArrayOf(20, 20, 107, 107),
    "Início suave" to intArrayOf(53, 0, 127, 127),
    "Fim suave" to intArrayOf(0, 0, 74, 127),
    "Suave" to intArrayOf(53, 0, 74, 127),
    "Forte" to intArrayOf(89, 0, 38, 127),
    "Segurar" to intArrayOf(127, 0, 127, 0),
    "Pulo" to intArrayOf(0, 127, 0, 127)
)

/** Canal da aba -> índice no VMD (0=X 1=Y 2=Z 3=rot). Canal da aba: 0=Rot 1=X 2=Y 3=Z 4=Todos. */
private fun chIdx(ch: Int) = if (ch == 0 || ch == 4) 3 else ch - 1

private fun readPts(ip: ByteArray?, ch: Int): IntArray {
    if (ip == null) return intArrayOf(20, 20, 107, 107)
    val c = chIdx(ch)
    return intArrayOf(ip[c].toInt() and 0xFF, ip[4 + c].toInt() and 0xFF, ip[8 + c].toInt() and 0xFF, ip[12 + c].toInt() and 0xFF)
}

@Composable
private fun CurveTab(ed: Editor, frame: Int, sel: Int, note: (String) -> Unit, onFrame: (Int) -> Unit) {
    if (sel !in ed.model.bones.indices) {
        Text("Toque num osso no modelo ou escolha na aba Ossos.", color = Muted, fontSize = 12.sp)
        return
    }
    val name = ed.model.bones[sel].name
    var ch by remember { mutableIntStateOf(0) }
    val stamp = ed.stamp
    val hasKey = ed.hasKey(name, frame)
    val chArg = if (ch == 4) -1 else chIdx(ch)
    var pts by remember(name, frame, stamp, ch, hasKey) { mutableStateOf(readPts(ed.curveOf(name, frame), ch)) }
    val keys = ed.keyFramesOf(name)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth()) {
            Canvas(
                Modifier.size(150.dp).background(Color(0xFF101114), RoundedCornerShape(6.dp))
                    .pointerInput(name, frame, ch, hasKey) {
                        var active = -1
                        detectDragGestures(
                            onDragStart = { o ->
                                val pad = 16.dp.toPx(); val gw = size.width - 2 * pad; val gh = size.height - 2 * pad
                                val p = pts
                                val d1 = hypot(pad + p[0] / 127f * gw - o.x, pad + (1 - p[1] / 127f) * gh - o.y)
                                val d2 = hypot(pad + p[2] / 127f * gw - o.x, pad + (1 - p[3] / 127f) * gh - o.y)
                                active = if (!hasKey) -1 else if (d1 <= d2) 0 else 1
                            },
                            onDrag = { change, _ ->
                                if (active >= 0) {
                                    change.consume()
                                    val pad = 16.dp.toPx(); val gw = size.width - 2 * pad; val gh = size.height - 2 * pad
                                    val nx = ((change.position.x - pad) / gw).coerceIn(0f, 1f)
                                    val ny = (1f - (change.position.y - pad) / gh).coerceIn(0f, 1f)
                                    val q = pts.copyOf()
                                    q[active * 2] = (nx * 127).roundToInt(); q[active * 2 + 1] = (ny * 127).roundToInt()
                                    pts = q; ed.liveCurve(name, frame, chArg, q)
                                }
                            },
                            onDragEnd = { if (active >= 0) ed.finishDrag(); active = -1 },
                            onDragCancel = { if (active >= 0) ed.finishDrag(); active = -1 }
                        )
                    }
            ) {
                val pad = 16.dp.toPx(); val gw = size.width - 2 * pad; val gh = size.height - 2 * pad
                for (i in 0..4) {
                    val gx = pad + gw * i / 4f; val gy = pad + gh * i / 4f
                    drawLine(Color(0xFF26282D), Offset(gx, pad), Offset(gx, pad + gh), 1f)
                    drawLine(Color(0xFF26282D), Offset(pad, gy), Offset(pad + gw, gy), 1f)
                }
                val p = pts
                val a = Offset(pad, pad + gh); val b = Offset(pad + gw, pad)
                val h1 = Offset(pad + p[0] / 127f * gw, pad + (1 - p[1] / 127f) * gh)
                val h2 = Offset(pad + p[2] / 127f * gw, pad + (1 - p[3] / 127f) * gh)
                val col = if (hasKey) Accent else Muted
                drawLine(col.copy(alpha = .6f), a, h1, 2f); drawLine(col.copy(alpha = .6f), b, h2, 2f)
                val path = Path().apply { moveTo(a.x, a.y); cubicTo(h1.x, h1.y, h2.x, h2.y, b.x, b.y) }
                drawPath(path, col, style = Stroke(width = 4f))
                drawCircle(Color.White, 10.dp.toPx() / 1.4f, h1); drawCircle(col, 10.dp.toPx() / 1.4f, h1, style = Stroke(3f))
                drawCircle(Color.White, 10.dp.toPx() / 1.4f, h2); drawCircle(col, 10.dp.toPx() / 1.4f, h2, style = Stroke(3f))
            }
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Rot", "X", "Y", "Z", "Todos").forEachIndexed { i, t ->
                        Text(t, color = if (i == ch) Color.White else Muted, fontSize = 11.sp,
                            modifier = Modifier.padding(end = 4.dp).background(if (i == ch) Accent else Color(0xFF26282D), RoundedCornerShape(10.dp))
                                .clickable { ch = i }.padding(horizontal = 9.dp, vertical = 5.dp))
                    }
                }
                Text("cubic-bezier(%.2f, %.2f, %.2f, %.2f)".format(pts[0] / 127f, pts[1] / 127f, pts[2] / 127f, pts[3] / 127f),
                    color = Color.White, fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
                Text(if (hasKey) "Curva do trecho que chega neste keyframe." else "Sem keyframe deste osso no quadro $frame.",
                    color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                Row(Modifier.padding(top = 6.dp)) {
                    MiniBtn("◀ key") { val k = keys.lastOrNull { it < frame }; if (k != null) onFrame(k) else note("Sem keyframe antes") }
                    MiniBtn("key ▶") { val k = keys.firstOrNull { it > frame }; if (k != null) onFrame(k) else note("Sem keyframe depois") }
                }
                Row(Modifier.padding(top = 6.dp)) {
                    MiniBtn("Copiar", hasKey) { ed.curveClip = pts.copyOf(); note("Curva copiada") }
                    MiniBtn("Colar", hasKey && ed.curveClip != null) { ed.curveClip?.let { ed.setCurve(name, frame, chArg, it) } }
                }
                Row(Modifier.padding(top = 6.dp)) {
                    MiniBtn("Colar em todos", ed.curveClip != null && keys.isNotEmpty()) {
                        ed.curveClip?.let { val n = ed.setCurveAll(name, chArg, it); note("Curva aplicada em $n keyframes") }
                    }
                    MiniBtn("Inverter", hasKey) { val p = pts; ed.setCurve(name, frame, chArg, intArrayOf(127 - p[2], 127 - p[3], 127 - p[0], 127 - p[1])) }
                }
            }
        }
        Text("Presets", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            PRESETS.forEach { (label, pr) ->
                Column(Modifier.padding(end = 6.dp).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
                    .clickable { if (hasKey) ed.setCurve(name, frame, chArg, pr) else note("Sem keyframe neste quadro") }.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Canvas(Modifier.size(40.dp)) {
                        val x1 = pr[0] / 127f; val y1 = pr[1] / 127f; val x2 = pr[2] / 127f; val y2 = pr[3] / 127f
                        val path = Path()
                        for (k in 0..24) {
                            val t = k / 24f; val u = 1 - t
                            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
                            val y = 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
                            val px = 3f + x * (size.width - 6f); val py = size.height - 3f - y * (size.height - 6f)
                            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }
                        drawPath(path, Color.White, style = Stroke(width = 3f))
                    }
                    Text(label, color = Muted, fontSize = 9.sp, maxLines = 1)
                }
            }
        }
    }
}


// ------------------------------------------------------------------ aba Rig (Action Constraints)

@Composable
private fun RigSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.width(44.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text("%.1f%s".format(value, unit), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(54.dp))
    }
}

@Composable
private fun RigTab(
    ed: Editor, frame: Int, sel: Int, rig: List<Constraint>, onRig: (List<Constraint>) -> Unit,
    sec: List<Secondary>, onSec: (List<Secondary>) -> Unit, phys: studio.mmd.rig.PhysConfig, onPhys: (studio.mmd.rig.PhysConfig) -> Unit, onBake: () -> Unit, busy: Boolean, note: (String) -> Unit,
    rigOwner: String, rigConfig: studio.mmd.rig.RigConfig, onCache: (studio.mmd.rig.PhysCache?) -> Unit,
    parts: studio.mmd.rig.PartOverrides, onParts: (studio.mmd.rig.PartOverrides) -> Unit, onSelBone: (Int) -> Unit
) {
    var sub by remember(ed.model) { mutableIntStateOf(2) }
    var full by remember { androidx.compose.runtime.mutableStateOf(false) }
    // o conteúdo é o mesmo no painel pequeno e na tela cheia (mesmo estado, só muda o espaço disponível)
    val body: @Composable (Boolean) -> Unit = { isFull ->
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("CONFIGURAÇÃO DE RIG · $rigOwner", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f))
                Text(if (isFull) "✕ Fechar" else "⛶ Tela cheia", color = Color.White, fontSize = 11.sp, maxLines = 1,
                    modifier = Modifier.background(if (isFull) Accent else Color(0xFF26282D), RoundedCornerShape(6.dp))
                        .clickable { full = !isFull }.padding(horizontal = 10.dp, vertical = 5.dp))
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Restrições" to rig.size.toString(), "Secundário" to sec.size.toString(), "Física real" to (if (phys.enabled) "on" else "off"), "Partes" to (if (parts.isEmpty) "auto" else "${parts.assign.size}"), "IK Assist" to "2 bones").forEachIndexed { i, (t, c) ->
                    Text("$t ($c)", color = if (i == sub) Color.White else Muted, fontSize = 10.sp, maxLines = 1, softWrap = false,
                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                        modifier = Modifier.widthIn(min = 76.dp).background(if (i == sub) Accent else Color(0xFF26282D), RoundedCornerShape(6.dp))
                            .clickable { sub = i }.padding(horizontal = 7.dp, vertical = 6.dp))
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f)) {
                when (sub) {
                    0 -> ConstraintsView(ed, sel, rig, onRig)
                    1 -> SecondaryView(ed, sel, sec, onSec, onBake, busy, note)
                    3 -> PartsView(ed, parts, onParts, sec, onSec, onSelBone, note, compact = !isFull)
                    4 -> IkAssistView(ed, frame, sel, onSelBone, note)
                    else -> PhysView(ed, phys, onPhys, rigConfig, rigConfig.physCache, onCache)
                }
            }
        }
    }
    if (full) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { full = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)) {
            Box(Modifier.fillMaxSize().background(Color(0xFF0E0F11)).padding(10.dp)) { body(true) }
        }
        Text("Rig aberto em tela cheia.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(6.dp))
    } else body(false)
}

@Composable
private fun PhysView(ed: Editor, c: studio.mmd.rig.PhysConfig, onPhys: (studio.mmd.rig.PhysConfig) -> Unit,
                     rigConfig: studio.mmd.rig.RigConfig, cache: studio.mmd.rig.PhysCache?, onCache: (studio.mmd.rig.PhysCache?) -> Unit) {
    val rbs = ed.model.rigidBodies; val js = ed.model.joints
    val dyn = rbs.count { it.mode != 0 }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Corpos rígidos: ${rbs.size} (${dyn} com física) · Juntas: ${js.size}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
        if (dyn == 0 || js.isEmpty()) {
            Text("Este modelo não tem corpos rígidos/juntas no arquivo. Use \"Movimento secundário\" (Auto) para dar balanço.", color = Muted, fontSize = 11.sp)
        } else {
            Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Ativar física real", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = c.enabled, onCheckedChange = { onPhys(c.copy(enabled = it)) })
            }
            RigSlider("Grav.", c.gravity, 0f..2f, "x") { onPhys(c.copy(gravity = it)) }
            RigSlider("Mola", c.stiffness, 0.2f..4f, "x") { onPhys(c.copy(stiffness = it)) }
            RigSlider("Amort.", c.damping, 0.3f..3f, "x") { onPhys(c.copy(damping = it)) }
            RigSlider("Vento", c.wind, 0f..3f, "x") { onPhys(c.copy(wind = it)) }
            Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Colisão entre corpos", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = c.collisions, onCheckedChange = { onPhys(c.copy(collisions = it)) })
            }
            // v1.34.0: colisores corporais gerados do esqueleto (saia/roupa não atravessa quadril e pernas)
            val bodyPlan = androidx.compose.runtime.remember(ed.model) { studio.mmd.rig.BodyColliders.plan(ed.model) }
            Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Colisores do corpo (quadril/pernas)", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = c.bodyColliders, enabled = c.collisions && bodyPlan.colliders.isNotEmpty(), onCheckedChange = { onPhys(c.copy(bodyColliders = it)) })
            }
            Text(bodyPlan.summary + if (!c.collisions) " · Ligue \"Colisão entre corpos\" para usar." else "", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 4.dp))
            if (c.bodyColliders && c.collisions) for (bc in bodyPlan.colliders) {
                RigSlider(bc.label, c.colliderScale[bc.key] ?: 1f, studio.mmd.rig.PhysConfig.SCALE_MIN..studio.mmd.rig.PhysConfig.SCALE_MAX, "x") { v ->
                    onPhys(c.copy(colliderScale = c.colliderScale + (bc.key to v)))
                }
            }
            Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Chão (y = 0)", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = c.ground, onCheckedChange = { onPhys(c.copy(ground = it)) })
            }
            // v1.14.0: cache (bake) determinístico
            val scope = rememberCoroutineScope()
            var working by remember { mutableStateOf(false) }
            var info by remember(ed.model, cache) { mutableStateOf(cache?.takeIf { it.model === ed.model }?.let { "Cache: ${it.frames} quadros · ${it.bytes / 1024} KB" } ?: "Sem cache (a física simula ao vivo)") }
            Text(info, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniBtn(if (working) "Calculando..." else "Calcular cache", enabled = !working && c.enabled) {
                    working = true
                    val mo = ed.motion(); val model = ed.model
                    val to = minOf(maxOf(ed.allKeyFrames().lastOrNull() ?: 0, 60), 20000)
                    scope.launch {
                        try {
                            val r = withContext(Dispatchers.Default) { studio.mmd.rig.PhysBake.run(model, mo, to, rig = rigConfig) }
                            if (r == null) info = "Nada calculado (ative a física real antes)"
                            else { onCache(r); info = "Cache: ${r.frames} quadros · ${r.bytes / 1024} KB" }
                        } catch (ex: Throwable) { info = "Erro ao calcular: ${ex.message ?: ex.javaClass.simpleName}" }
                        working = false
                    }
                }
                MiniBtn("Limpar cache", enabled = !working) { onCache(null); info = "Sem cache (a física simula ao vivo)" }
            }
            Text("Com cache, a prévia, o vídeo e as exportações leem a física já calculada (resultado idêntico em qualquer taxa e ao pular na timeline). Ele só vale enquanto animação, restrições, movimento secundário e configuração não mudarem; depois disso é ignorado e a física volta a simular ao vivo (recalcule). Fica só na memória.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            Text("A física entra na prévia, no vídeo e na exportação GLB/FBX. Ao dar play ou saltar na timeline ela reinicia e se acomoda sozinha. Se o modelo \"explodir\", reduza Mola ou aumente Amort.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun IkBonePicker(label: String, selected: Int, bones: List<PmxBone>, onSelected: (Int) -> Unit) {
    var expanded by remember(label) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = Muted, fontSize = 10.sp)
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(bones.getOrNull(selected)?.let { "${selected + 1} · ${it.name}" } ?: "Escolher osso", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            bones.forEachIndexed { i, bone ->
                DropdownMenuItem(text = { Text("${i + 1} · ${bone.name}", maxLines = 1) }, onClick = { onSelected(i); expanded = false })
            }
        }
    }
}

@Composable
private fun IkAssistView(ed: Editor, frame: Int, selectedBone: Int, onSelectBone: (Int) -> Unit, note: (String) -> Unit) {
    val bones = ed.model.bones
    val firstIk = remember(ed.model, selectedBone) {
        if (bones.getOrNull(selectedBone)?.ik != null) selectedBone
        else bones.indexOfFirst { it.ik != null }.takeIf { it >= 0 } ?: bones.indexOfFirst { it.name.contains("IK", true) }.coerceAtLeast(0)
    }
    val defaultIk = bones.getOrNull(firstIk)?.ik
    var controller by remember(ed.model) { mutableIntStateOf(firstIk) }
    // PMX عادةً lista links do effector para a raiz: primeiro = junta, último = raiz.
    // Usamos essa cadeia real como ponto de partida, em vez de assumir os três primeiros ossos.
    var root by remember(ed.model) { mutableIntStateOf(defaultIk?.links?.lastOrNull()?.bone?.takeIf { it in bones.indices } ?: 0) }
    var middle by remember(ed.model) { mutableIntStateOf(defaultIk?.links?.firstOrNull()?.bone?.takeIf { it in bones.indices } ?: (1).coerceAtMost((bones.size - 1).coerceAtLeast(0))) }
    var end by remember(ed.model) { mutableIntStateOf(defaultIk?.target?.takeIf { it in bones.indices } ?: (2).coerceAtMost((bones.size - 1).coerceAtLeast(0))) }
    var poleX by remember(ed.model) { mutableFloatStateOf(0f) }
    var poleY by remember(ed.model) { mutableFloatStateOf(0f) }
    var poleZ by remember(ed.model) { mutableFloatStateOf(2f) }
    var minBend by remember(ed.model) { mutableFloatStateOf(0f) }
    var maxBend by remember(ed.model) { mutableFloatStateOf(180f) }
    var targetX by remember(ed.model) { mutableFloatStateOf(0f) }
    var targetY by remember(ed.model) { mutableFloatStateOf(0f) }
    var targetZ by remember(ed.model) { mutableFloatStateOf(0f) }
    val frameMotion = remember(ed.model, ed.version, frame) { ed.motion() }
    val posePositions = remember(ed.model, frameMotion, frame) {
        val animator = Animator(ed.model, 1f).also { it.motion = frameMotion; it.prepareClothPose(frame.toFloat()) }
        FloatArray(bones.size * 3).also(animator::bonePositionsMmd)
    }
    LaunchedEffect(ed.model, frame, controller, root, middle, end, ed.version) {
        val targetBone = bones.getOrNull(end)
        if (targetBone != null && posePositions.size >= (end + 1) * 3) {
            targetX = posePositions[end * 3]; targetY = posePositions[end * 3 + 1]; targetZ = posePositions[end * 3 + 2]
        }
    }
    fun isAncestor(ancestor: Int, child: Int): Boolean {
        var current = bones.getOrNull(child)?.parent ?: -1
        val visited = HashSet<Int>()
        while (current in bones.indices && visited.add(current)) {
            if (current == ancestor) return true
            current = bones[current].parent
        }
        return false
    }
    val validChain = root in bones.indices && middle in bones.indices && end in bones.indices && root != middle && middle != end && root != end
    val orderedHierarchy = validChain && isAncestor(root, middle) && isAncestor(middle, end)
    val solved = remember(posePositions, root, middle, end, targetX, targetY, targetZ, poleX, poleY, poleZ, minBend, maxBend, orderedHierarchy) {
        if (!orderedHierarchy) null else runCatching {
            fun point(b: Int) = Vec3(posePositions[b * 3], posePositions[b * 3 + 1], posePositions[b * 3 + 2])
            val r = point(root); val m = point(middle); val e = point(end)
            TwoBoneIkSolver.solve(r, m, e, Vec3(targetX, targetY, targetZ), m + Vec3(poleX, poleY, poleZ),
                TwoBoneIkLimits(Math.toRadians(minBend.toDouble()).toFloat(), Math.toRadians(maxOf(minBend, maxBend).toDouble()).toFloat()))
        }.getOrNull()
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("IK ASSIST · ALVO + CADEIA DE DOIS SEGMENTOS", color = Color.White, fontSize = 12.sp)
        Text("Escolha a cadeia para pré-visualizar comprimentos, alcance e pole vector. Ao aplicar, a posição é gravada no controlador PMX e o Animator resolve a cadeia pelo CCD, incluindo os limites IK do modelo.", color = Muted, fontSize = 10.sp)
        if (bones.isEmpty()) {
            Text("O modelo não possui esqueleto.", color = Muted, fontSize = 11.sp)
        } else {
            IkBonePicker("Controlador IK PMX", controller, bones, { index ->
                controller = index
                onSelectBone(index)
                val ik = bones.getOrNull(index)?.ik
                if (ik != null) {
                    ik.target.takeIf { it in bones.indices }?.let { end = it }
                    ik.links.firstOrNull()?.bone?.takeIf { it in bones.indices }?.let { middle = it }
                    ik.links.lastOrNull()?.bone?.takeIf { it in bones.indices }?.let { root = it }
                }
            })
            IkBonePicker("Osso raiz", root, bones, { root = it })
            IkBonePicker("Osso intermediário", middle, bones, { middle = it })
            IkBonePicker("Efetor / ponta", end, bones, { end = it })
            Text("Alvo global (MMD)", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            RigSlider("Alvo X", targetX, -100f..100f, "") { targetX = it }
            RigSlider("Alvo Y", targetY, -100f..100f, "") { targetY = it }
            RigSlider("Alvo Z", targetZ, -100f..100f, "") { targetZ = it }
            Text("Pole vector · direção da dobra", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
            RigSlider("Pole X", poleX, -20f..20f, "") { poleX = it }
            RigSlider("Pole Y", poleY, -20f..20f, "") { poleY = it }
            RigSlider("Pole Z", poleZ, -20f..20f, "") { poleZ = it }
            Text("Limites de dobra", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
            RigSlider("Mín. °", minBend, 0f..180f, "°") { minBend = minOf(it, maxBend) }
            RigSlider("Máx. °", maxBend, 0f..180f, "°") { maxBend = maxOf(it, minBend) }
            if (solved != null) {
                val s = solved
                Text(if (s.reachable) "Alvo alcançável" else "Alvo além do alcance / limite", color = if (s.reachable) Color(0xFF8DDBA2) else Color(0xFFFFBE78), fontSize = 11.sp)
                Text("Distância raiz-alvo: %.3f · erro: %.3f · dobra: %.1f°".format(s.rootToTarget, s.reachError, Math.toDegrees(s.bendRadians.toDouble())), color = Muted, fontSize = 10.sp)
                Text("Junta prevista: (%.2f, %.2f, %.2f) · ponta prevista: (%.2f, %.2f, %.2f)".format(s.middle.x, s.middle.y, s.middle.z, s.end.x, s.end.y, s.end.z), color = Muted, fontSize = 10.sp)
            } else Text(
                if (!validChain) "Selecione três ossos diferentes para a prévia do solver geométrico."
                else "A cadeia precisa respeitar a hierarquia raiz → intermediário → ponta. Use um controlador IK PMX para preencher os ossos automaticamente.",
                color = Muted, fontSize = 10.sp
            )
            val controllerIk = bones.getOrNull(controller)?.ik
            Button(onClick = {
                val controlBone = bones.getOrNull(controller)
                if (controlBone == null || controllerIk == null) {
                    note("Escolha um osso controlador que tenha uma cadeia IK definida no PMX.")
                } else {
                    val animator = Animator(ed.model, 1f).also { it.motion = ed.motion(); it.prepareClothPose(frame.toFloat()) }
                    val currentPositions = FloatArray(bones.size * 3).also(animator::bonePositionsMmd)
                    val o = controller * 3
                    val delta = FloatArray(3)
                    animator.toParentSpace(controller, targetX - currentPositions[o], targetY - currentPositions[o + 1], targetZ - currentPositions[o + 2], delta)
                    val local = FloatArray(7).also { ed.sampleBone(controlBone.name, frame.toFloat(), it) }
                    val next = floatArrayOf(local[0] + delta[0], local[1] + delta[1], local[2] + delta[2])
                    ed.liveBone(controlBone.name, frame, null, next)
                    ed.finish()
                    note("Alvo IK '${controlBone.name}' atualizado no quadro $frame. O CCD do PMX resolverá ${controllerIk.links.size} elo(s) respeitando limites.")
                }
            }, enabled = controllerIk != null, modifier = Modifier.fillMaxWidth()) { Text("Gravar alvo IK no quadro $frame") }
            if (controllerIk == null) Text("Para aplicar, o controlador escolhido precisa ter uma definição IK no arquivo PMX. A prévia de alcance funciona também com qualquer cadeia de três ossos.", color = Muted, fontSize = 10.sp)
        }
    }
}

private fun isIkBone(b: PmxBone) = b.ik != null || b.name.contains("IK") || b.name.contains("ＩＫ")

/** O osso [root] e todos os descendentes (sem ossos de IK), no máximo 80. */
private fun chainOf(bones: List<PmxBone>, root: Int): List<Int> {
    val res = ArrayList<Int>(); val q = ArrayDeque<Int>(); q.add(root)
    while (q.isNotEmpty() && res.size < 80) {
        val b = q.removeFirst()
        if (!isIkBone(bones[b])) res.add(b)
        for (i in bones.indices) if (bones[i].parent == b && i != b) q.add(i)
    }
    return res
}

@Composable
private fun SecondaryView(ed: Editor, sel: Int, sec: List<Secondary>, onSec: (List<Secondary>) -> Unit, onBake: () -> Unit, busy: Boolean, note: (String) -> Unit) {
    val bones = ed.model.bones
    fun upd(id: String, f: (Secondary) -> Secondary) = onSec(sec.map { if (it.id == id) f(it) else it })
    var info by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            MiniBtn("+ Cadeia do osso selecionado", sel in bones.indices) {
                val l = chainOf(bones, sel)
                if (l.isEmpty()) note("Osso de IK não pode ser simulado")
                else onSec(sec + SecPreset.apply(Secondary(java.util.UUID.randomUUID().toString(), "Cadeia · ${bones[sel].name}", l.map { bones[it].name }), 0))
            }
            MiniBtn("Auto: reconhecer física") {
                val r = studio.mmd.rig.AutoPhysics.detect(ed.model)
                info = r.summary
                if (r.groups.isEmpty()) note(r.summary)
                else { onSec(sec.filter { !it.name.endsWith("(auto)") && !it.name.endsWith("(física)") } + r.groups); note("${r.groups.size} grupo(s) criado(s)") }
            }
            MiniBtn(if (busy) "Assando..." else "Assar em keyframes", !busy && sec.any { it.enabled }) { onBake() }
        }
        if (info.isNotEmpty()) Text(info, color = Color(0xFFB0B3BA), fontSize = 11.sp)
        if (sec.isEmpty()) Text("Movimento secundário: cabelo, saia e acessórios balançam sozinhos (mola simples, não é a física do MMD). Selecione o 1º osso da cadeia (ex.: raiz do cabelo) e toque em \"+ Cadeia\", ou use o \"Auto: reconhecer física\" (acha cabelo, saia, roupa, peito, cauda/orelha e acessórios pelos corpos rígidos do modelo). Vale na prévia e nas exportações; \"Assar\" grava o resultado como keyframes (e desliga os grupos).", color = Muted, fontSize = 12.sp)
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(sec, key = { it.id }) { g ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Color(0xFF1E2024), RoundedCornerShape(8.dp)).padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(g.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${g.bones.size} osso(s)", color = Muted, fontSize = 10.sp)
                        }
                        Switch(checked = g.enabled, onCheckedChange = { v -> upd(g.id) { it.copy(enabled = v) } })
                        MiniBtn("Excluir") { onSec(sec.filter { it.id != g.id }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
                        SecPreset.names.forEachIndexed { k, pn ->
                            Text(pn, color = if (g.preset == k) Color.White else Muted, fontSize = 12.sp,
                                modifier = Modifier.padding(end = 6.dp).background(if (g.preset == k) Accent else Color(0xFF26282D), RoundedCornerShape(6.dp))
                                    .clickable { upd(g.id) { SecPreset.apply(it, k) } }.padding(horizontal = 10.dp, vertical = 5.dp))
                        }
                    }
                    RigSlider("Intens.", g.intensity, 0f..1f, "") { v -> upd(g.id) { it.copy(intensity = v) } }
                    RigSlider("Rigidez", g.stiffness, 20f..600f, "") { v -> upd(g.id) { it.copy(stiffness = v) } }
                    RigSlider("Amort.", g.damping, 0.05f..1.5f, "") { v -> upd(g.id) { it.copy(damping = v) } }
                    RigSlider("Atraso", g.delay, 0f..1f, "") { v -> upd(g.id) { it.copy(delay = v) } }
                }
            }
        }
    }
}

@Composable
private fun ConstraintsView(ed: Editor, sel: Int, rig: List<Constraint>, onRig: (List<Constraint>) -> Unit) {
    val bones = ed.model.bones
    val name = bones.getOrNull(sel)?.name
    var picking by remember { mutableStateOf<String?>(null) }   // id da restrição que escolhe o alvo
    var q by remember { mutableStateOf("") }
    fun upd(id: String, f: (Constraint) -> Constraint) = onRig(rig.map { if (it.id == id) f(it) else it })

    val pk = picking
    if (pk != null) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Escolha o osso alvo", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                MiniBtn("Cancelar") { picking = null; q = "" }
            }
            SearchBox(q, "Buscar osso") { q = it }
            val list = remember(q, bones) { bones.indices.filter { q.isBlank() || bones[it].name.contains(q, true) || bones[it].nameEn.contains(q, true) } }
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                items(list) { i ->
                    Text(bones[i].name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().clickable { upd(pk) { c -> c.copy(target = bones[i].name) }; picking = null; q = "" }.padding(vertical = 8.dp, horizontal = 6.dp))
                }
            }
        }
        return
    }

    if (name == null) {
        Text("Selecione um osso (aba Ossos ou toque no viewport) para dar restrições a ele.", color = Muted, fontSize = 13.sp)
        return
    }
    val mine = rig.filter { it.bone == name }
    Column(Modifier.fillMaxSize()) {
        Text("Osso: $name · ${mine.size} restrição(ões) · ${rig.size} no total", color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            CType.names.forEachIndexed { t, n ->
                MiniBtn("+ $n") { onRig(rig + Constraint(java.util.UUID.randomUUID().toString(), name, t,
                    min = if (t == CType.LIMIT_POS) listOf(-5f, -5f, -5f) else listOf(-180f, -180f, -180f),
                    max = if (t == CType.LIMIT_POS) listOf(5f, 5f, 5f) else listOf(180f, 180f, 180f))) }
            }
        }
        if (mine.isEmpty()) Text("Nenhuma restrição neste osso. Toque num \"+\" acima.\nElas valem na prévia e nas exportações (vídeo, GLB, FBX, pose); não alteram o VMD salvo.", color = Muted, fontSize = 12.sp)
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(mine, key = { it.id }) { c ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Color(0xFF1E2024), RoundedCornerShape(8.dp)).padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(CType.names[c.type], color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Switch(checked = c.enabled, onCheckedChange = { v -> upd(c.id) { it.copy(enabled = v) } })
                        MiniBtn("Excluir") { onRig(rig.filter { it.id != c.id }) }
                    }
                    when (c.type) {
                        CType.LIMIT_ROT, CType.LIMIT_POS -> {
                            val rot = c.type == CType.LIMIT_ROT
                            val r = if (rot) -180f..180f else -20f..20f
                            val u = if (rot) "°" else ""
                            listOf("X", "Y", "Z").forEachIndexed { k, ax ->
                                RigSlider("$ax mín", c.min[k], r, u) { v -> upd(c.id) { it.copy(min = it.min.toMutableList().also { l -> l[k] = v }) } }
                                RigSlider("$ax máx", c.max[k], r, u) { v -> upd(c.id) { it.copy(max = it.max.toMutableList().also { l -> l[k] = v }) } }
                            }
                            Text(if (rot) "Rotação em graus (ordem Y·X·Z, como na aba Osso)." else "Posição em unidades do MMD.", color = Muted, fontSize = 10.sp)
                        }
                        else -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Alvo:", color = Muted, fontSize = 12.sp)
                                MiniBtn(if (c.target.isEmpty()) "escolher osso" else c.target) { picking = c.id }
                            }
                            if (c.type == CType.LOOK_AT) {
                                Text("Eixo do osso que aponta para o alvo (frente do MMD = −Z):", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState())) {
                                    AXIS_NAMES.forEachIndexed { k, an ->
                                        Text(an, color = if (c.axis == k) Color.White else Muted, fontSize = 12.sp,
                                            modifier = Modifier.padding(end = 6.dp, top = 4.dp).background(if (c.axis == k) Accent else Color(0xFF26282D), RoundedCornerShape(6.dp))
                                                .clickable { upd(c.id) { it.copy(axis = k) } }.padding(horizontal = 12.dp, vertical = 6.dp))
                                    }
                                }
                            }
                            RigSlider("Peso", c.weight, 0f..1f, "") { v -> upd(c.id) { it.copy(weight = v) } }
                            if (c.target.isEmpty()) Text("Escolha o osso alvo para a restrição funcionar.", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}


// ------------------------------------------------------------------ v1.15.0 (Release 5): Keys — editar keyframes por trecho

/** Aba Keys: "Trecho" (edição por intervalo, v1.15.0) ou "Dope sheet" (grade visual com keys individuais, v1.16.0). */
@Composable
private fun KeysTab(ed: Editor, frame: Int, selBone: Int, onSelBone: (Int) -> Unit, note: (String) -> Unit, onFrame: (Int) -> Unit, onTotal: (Int) -> Unit) {
    var view by remember { mutableIntStateOf(1) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Trecho" to 0, "Dope sheet" to 1).forEach { (t, i) ->
                Box(
                    Modifier.weight(1f).background(if (view == i) Color(0xFF4A2A2A) else Color(0xFF26282D), RoundedCornerShape(6.dp))
                        .clickable { view = i }.padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) { Text(t, color = Color.White, fontSize = 12.sp, maxLines = 1) }
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (view == 0) KeysRange(ed, frame, selBone, note, onFrame, onTotal)
            else DopeSheet(ed, frame, selBone, onSelBone, note, onFrame, onTotal)
        }
    }
}

@Composable
private fun KeysRange(ed: Editor, frame: Int, selBone: Int, note: (String) -> Unit, onFrame: (Int) -> Unit, onTotal: (Int) -> Unit) {
    var from by remember { mutableIntStateOf(0) }
    var to by remember { mutableIntStateOf(30) }
    var scope by remember { mutableIntStateOf(1) } // 0 osso selecionado, 1 todos os ossos, 2 ossos + morphs
    var factor by remember { mutableFloatStateOf(1f) }
    var repeatCount by remember { mutableIntStateOf(2) }
    var insertCount by remember { mutableIntStateOf(10) }
    var smoothStrength by remember { mutableFloatStateOf(0.35f) }
    var smoothPasses by remember { mutableIntStateOf(1) }
    val selName = ed.model.bones.getOrNull(selBone)?.name
    // lê version para recompor depois de cada edição
    val ver = ed.version
    val bn: List<String> = when (scope) { 0 -> listOfNotNull(selName); else -> ed.boneTrackNames() }
    val mn: List<String> = if (scope == 2) ed.morphTrackNames() else emptyList()
    val lo = minOf(from, to); val hi = maxOf(from, to)
    val count = remember(ver, scope, selBone, lo, hi) { ed.countKeys(bn, mn, lo, hi) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Trilhas:", color = Muted, fontSize = 11.sp)
            listOf("Osso selec." to 0, "Todos os ossos" to 1, "Ossos+morphs" to 2).forEach { (t, i) ->
                MiniBtn((if (scope == i) "● " else "") + t) { scope = i }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Início $from", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(72.dp))
            MiniBtn("−1") { from = (from - 1).coerceAtLeast(0) }; MiniBtn("+1") { from += 1 }; MiniBtn("= quadro") { from = frame }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Fim $to", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(72.dp))
            MiniBtn("−1") { to = (to - 1).coerceAtLeast(0) }; MiniBtn("+1") { to += 1 }; MiniBtn("= quadro") { to = frame }
            MiniBtn("Tudo") { from = 0; to = ed.allKeyFrames().lastOrNull() ?: 0 }
        }
        Text("$count key(s) no trecho $lo–$hi" + if (scope == 0 && selName == null) " · selecione um osso" else "", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Mover", color = Muted, fontSize = 11.sp, modifier = Modifier.width(48.dp))
            listOf(-10, -1, 1, 10).forEach { d ->
                MiniBtn((if (d > 0) "+" else "") + d, enabled = count > 0) {
                    val r = ed.moveKeys(bn, mn, lo, hi, d)
                    if (r < 0) note("Não dá: alguma key iria para antes do quadro 0")
                    else { from = lo + d; to = hi + d; onTotal(ed.allKeyFrames().lastOrNull() ?: 0); note("$r key(s) movidas") }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("Copiar", enabled = count > 0) { note("${ed.copyKeys(bn, mn, lo, hi)} key(s) copiadas") }
            MiniBtn("Colar no quadro $frame", enabled = ed.hasKeyClip) { val c = ed.pasteKeys(frame); onTotal(ed.allKeyFrames().lastOrNull() ?: 0); note("$c key(s) coladas") }
            MiniBtn("Apagar", enabled = count > 0) { note("${ed.deleteRange(bn, mn, lo, hi)} key(s) apagadas") }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("Excluir + fechar", enabled = count > 0) {
                val n = ed.rippleDeleteRange(bn, mn, lo, hi)
                onTotal(ed.allKeyFrames().lastOrNull() ?: 0)
                note("Ripple delete: $n keys removidas/deslocadas; espaço fechado nas trilhas afetadas. Desfazer disponível.")
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("Reverter tempo", enabled = count >= 2 && hi > lo) {
                val n = ed.reverseRange(bn, mn, lo, hi)
                if (n > 0) note("$n keys invertidas no intervalo; curvas Bézier internas também foram invertidas. Desfazer disponível.")
                else note("Cada trilha precisa ter pelo menos duas keys no intervalo.")
            }
        }
        // v2.34.0: fechar loop (última pose = primeira pose) nas trilhas do escopo.
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("Fechar loop ($lo → $hi)", enabled = hi > lo && count > 0) {
                val n = ed.closeLoop(bn, mn, lo, hi)
                if (n > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("Loop fechado: $n trilha(s) ganharam no quadro $hi a mesma pose do quadro $lo. Desfazer disponível.") }
                else note("Nenhuma trilha tem key no quadro $lo")
            }
        }
        // v2.35.0: bake, curva automática, copiar/colar/espelhar trecho.
        Text("Bake, curvas e copiar/colar", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MiniBtn("Bake 1 em 1 ($lo→$hi)", enabled = hi > lo && ed.keyCount() >= 2) {
                val d = ed.bakeRangeAll(lo, hi, 1)
                onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1))
                note("Bake: o trecho virou keys a cada quadro (${if (d >= 0) "+$d" else "$d"} keys). Desfazer disponível.")
            }
            MiniBtn("Curva automática", enabled = ed.keyCount() >= 3) {
                val r = ed.autoCurveAll(0.02f, 0.75f)
                note(if (r > 0) "Curva automática: $r key(s) fundidas em curvas Bézier. Desfazer disponível." else "Nada a fundir dentro da tolerância.")
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MiniBtn("Copiar trecho", enabled = count > 0 && hi >= lo) {
                val n = ed.copyClip(bn, mn, lo, hi)
                note(if (n > 0) "$n key(s) copiadas ($lo→$hi)." else "Nenhuma key no trecho.")
            }
            MiniBtn("Colar em $lo", enabled = ed.clipboardKeyCount() > 0) {
                val n = ed.pasteClip(lo, mirror = false, repeat = 1, merge = false)
                if (n > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("$n key(s) coladas no quadro $lo. Desfazer disponível.") } else note("Nada colado.")
            }
            MiniBtn("Colar espelhado", enabled = ed.clipboardKeyCount() > 0) {
                val n = ed.pasteClip(lo, mirror = true, repeat = 1, merge = false)
                if (n > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("$n key(s) coladas com lados trocados e X invertido. Desfazer disponível.") } else note("Nada colado (ossos opostos ausentes?).")
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MiniBtn("Espelhar trecho", enabled = hi > lo && ed.keyCount() > 0) {
                val n = ed.mirrorRangeAll(lo, hi)
                note(if (n > 0) "Trecho espelhado ($n keys). Desfazer disponível." else "Nada a espelhar.")
            }
            MiniBtn("Deslocar −5", enabled = ed.keyCount() > 0) { if (ed.shiftRangeAll(lo, hi, -5) > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("Trecho deslocado 5 quadros para trás.") } }
            MiniBtn("Deslocar +5", enabled = ed.keyCount() > 0) { if (ed.shiftRangeAll(lo, hi, 5) > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("Trecho deslocado 5 quadros para frente.") } }
        }
        // v2.36.0/2.39.0: manter pose, vai-e-volta e piscar automático.
        Row(Modifier.fillMaxWidth().padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MiniBtn("Manter pose $lo→$hi", enabled = ed.keyCount() > 0 && hi != lo) {
                note(if (ed.holdPoseAll(lo, hi) > 0) "Pose do quadro $lo copiada para $hi. Desfazer disponível." else "Nada a copiar.")
                onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1))
            }
            MiniBtn("Vai-e-volta", enabled = ed.keyCount() > 0 && hi > lo) {
                note(if (ed.pingPongAll(lo, hi) > 0) "Trecho invertido acrescentado após $hi. Desfazer disponível." else "Nada a fazer.")
                onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1))
            }
            MiniBtn("Piscar auto (まばたき)", enabled = hi > lo) {
                val n = ed.autoBlinkAll("まばたき", lo, hi, 30, 1)
                note(if (n > 0) "$n keys de piscada geradas em まばたき. Desfazer disponível." else "Não foi possível gerar.")
                onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1))
            }
        }
        // v2.29.0: inserir frames vazios e reduzir keys (todas as trilhas, com Desfazer).
        Text("Inserir frames / reduzir keys", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Frames", color = Muted, fontSize = 11.sp, modifier = Modifier.width(48.dp))
            MiniBtn("−5", enabled = insertCount > 1) { insertCount = (insertCount - 5).coerceAtLeast(1) }
            Text("$insertCount", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp))
            MiniBtn("+5") { insertCount = (insertCount + 5).coerceAtMost(1000) }
            Spacer(Modifier.weight(1f))
            MiniBtn("Inserir em $lo", enabled = ed.keyCount() > 0) {
                val n = ed.insertFramesAll(lo, insertCount)
                if (n > 0) { onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1)); note("$insertCount frame(s) vazios inseridos no quadro $lo em todas as trilhas (ossos, morphs, IK, luz, sombra). Desfazer disponível.") }
                else note("Nada a inserir")
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(Triple("Reduzir suave", 0.005f, 0.25f), Triple("Reduzir médio", 0.02f, 0.5f), Triple("Reduzir forte", 0.06f, 1.5f)).forEach { (label, pos, ang) ->
                MiniBtn(label, enabled = ed.keyCount() >= 3) {
                    val r = ed.reduceKeysAll(pos, ang, pos / 4f)
                    note(if (r > 0) "$r key(s) redundantes removidas (todas as trilhas). Curvas Bézier não lineares foram preservadas. Desfazer disponível." else "Nenhuma key redundante nessa tolerância.")
                }
            }
        }
        Text("Reduzir considera só interpolação linear entre vizinhos; é uma limpeza aproximada. Confira a animação depois.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Retiming", color = Muted, fontSize = 11.sp, modifier = Modifier.width(60.dp))
            Slider(value = factor, onValueChange = { factor = (it * 20f).roundToInt() / 20f }, valueRange = 0.25f..4f, modifier = Modifier.weight(1f))
            Text("%.2fx".format(factor), color = Color.White, fontSize = 11.sp, modifier = Modifier.width(44.dp))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("Aplicar retiming", enabled = count > 0 && hi > lo && factor != 1f) {
                val r = ed.retimeKeys(bn, mn, lo, hi, factor)
                if (r > 0) { to = lo + Math.round((hi - lo) * factor); onTotal(ed.allKeyFrames().lastOrNull() ?: 0); note("Retiming: $r key(s) (as keys depois do trecho acompanham)") } else note("Nada alterado")
            }
            MiniBtn("Ir para o início") { onFrame(lo) }
        }
        Text(">1x deixa mais lento, <1x mais rápido. As keys depois do trecho nas mesmas trilhas são deslocadas junto. Tudo com desfazer.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))

        // v1.37.0: presets Bézier em lote no intervalo e nas trilhas ósseas selecionadas.
        Text("Presets Bézier em lote", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
        Text("Aplica a curva aos quatro canais de cada key de osso dentro do intervalo.", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            PRESETS.forEach { (label, preset) ->
                MiniBtn(label, enabled = ed.countKeys(bn, emptyList(), lo, hi) > 0) {
                    val changed = ed.setCurveRange(bn, lo, hi, -1, preset)
                    note("Preset '$label' aplicado a $changed key(s) ósseas. Desfazer disponível.")
                }
            }
        }

        // v1.37.0: repetição de ciclos e suavização de trilhas (uma operação por Undo).
        Text("Repetir / criar loop", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Ciclos", color = Muted, fontSize = 11.sp, modifier = Modifier.width(48.dp))
            MiniBtn("−", enabled = repeatCount > 1) { repeatCount = (repeatCount - 1).coerceAtLeast(1) }
            Text("$repeatCount", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp))
            MiniBtn("+", enabled = repeatCount < 20) { repeatCount = (repeatCount + 1).coerceAtMost(20) }
            Spacer(Modifier.weight(1f))
            MiniBtn("Repetir trecho", enabled = count > 0 && hi >= lo) {
                val span = hi - lo + 1
                val n = ed.repeatRange(bn, mn, lo, hi, repeatCount)
                if (n > 0) {
                    to = (hi.toLong() + span.toLong() * repeatCount).coerceAtMost(Int.MAX_VALUE - 1L).toInt()
                    onTotal(maxOf(2, (ed.allKeyFrames().lastOrNull() ?: 0) + 1))
                    note("Loop criado: $n keys duplicadas em $repeatCount ciclo(s); trilhas seguintes deslocadas. Desfazer restaura tudo.")
                } else note("Não há keys repetíveis neste trecho ou o intervalo excede o limite.")
            }
        }

        Text("Suavizar movimento", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Intensidade", color = Muted, fontSize = 11.sp, modifier = Modifier.width(72.dp))
            Slider(value = smoothStrength, onValueChange = { smoothStrength = it }, valueRange = 0.05f..1f, modifier = Modifier.weight(1f))
            Text("%.0f%%".format(smoothStrength * 100f), color = Color.White, fontSize = 11.sp, modifier = Modifier.width(42.dp))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Passes", color = Muted, fontSize = 11.sp, modifier = Modifier.width(48.dp))
            MiniBtn("−", enabled = smoothPasses > 1) { smoothPasses = (smoothPasses - 1).coerceAtLeast(1) }
            Text("$smoothPasses", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp))
            MiniBtn("+", enabled = smoothPasses < 8) { smoothPasses = (smoothPasses + 1).coerceAtMost(8) }
            Spacer(Modifier.weight(1f))
            MiniBtn("Suavizar trecho", enabled = count >= 3) {
                val n = ed.smoothRange(bn, mn, lo, hi, smoothStrength, smoothPasses)
                if (n > 0) note("Suavização aplicada em $n keys internas; extremos e tempo das keys preservados. Desfazer disponível.")
                else note("Cada trilha precisa ter ao menos 3 keys dentro do trecho.")
            }
        }
        Text("A repetição duplica os dados do intervalo e empurra o restante das mesmas trilhas. A suavização reduz oscilações entre keys existentes; não cria nem remove quadros. Ambas respeitam Undo/Redo.",
            color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp, bottom = 8.dp))
    }
}
