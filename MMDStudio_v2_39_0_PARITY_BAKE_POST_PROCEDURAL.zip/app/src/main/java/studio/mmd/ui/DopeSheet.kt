package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.edit.Editor
import studio.mmd.edit.KeyRef
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * v1.16.0 (Release 5, fatia 2): Dope Sheet visual — grade trilha × quadro.
 *
 * Gestos (um único detector, para não haver conflito entre eles):
 * - toque numa key: seleciona/desseleciona (soma à seleção) e leva o quadro até ela; no "Resumo" mexe em todas as keys do quadro;
 * - toque num nome de osso: seleciona o osso no viewport; toque na área vazia: leva o quadro até ali;
 * - arrastar uma key (ou a seleção) na horizontal: move as keys selecionadas, com a prévia em amarelo; ao soltar grava (1 passo de desfazer);
 * - arrastar na área vazia: rola (horizontal e vertical); 2 dedos: zoom horizontal ancorado entre os dedos;
 * - arrastar a régua (topo): move o quadro atual.
 * Tudo vale para keys reais do [Editor]; nada aqui é decorativo.
 */
private class DRow(val name: String, val morph: Boolean, val summary: Boolean, val frames: IntArray, val boneIdx: Int)

private val StepList = intArrayOf(1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1200)
private val KeyBone = Color(0xFFE6E6E6)
private val KeyMorph = Color(0xFF7FB8FF)
private val KeySel = Color(0xFFFFC107)

private fun refsAt(rows: List<DRow>, row: DRow, f: Int): List<KeyRef> =
    if (!row.summary) listOf(KeyRef(row.morph, row.name, f))
    else rows.filter { !it.summary && java.util.Arrays.binarySearch(it.frames, f) >= 0 }.map { KeyRef(it.morph, it.name, f) }

@Composable
private fun RowScope.WBtn(text: String, enabled: Boolean = true, on: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.weight(1f).background(if (on) Color(0xFF4A2A2A) else Color(0xFF26282D), RoundedCornerShape(6.dp))
        .clickable(enabled = enabled) { onClick() }.padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (!enabled) Color(0xFF5A5C62) else Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip)
    }
}

@Composable
fun DopeSheet(
    ed: Editor, frame: Int, selBone: Int,
    onSelBone: (Int) -> Unit, note: (String) -> Unit, onFrame: (Int) -> Unit, onTotal: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ver = ed.version
    val dens = LocalDensity.current.density
    var filter by remember { mutableIntStateOf(0) }      // 0 tudo, 1 ossos, 2 morphs, 3 osso selecionado
    var zoom by remember { mutableFloatStateOf(8f) }     // dp por quadro
    var sx by remember { mutableFloatStateOf(-1f) }      // primeiro quadro visível (fracionário)
    var sy by remember { mutableFloatStateOf(0f) }       // rolagem vertical em px
    var vw by remember { mutableFloatStateOf(0f) }
    var vh by remember { mutableFloatStateOf(0f) }
    var sel by remember { mutableStateOf(emptySet<KeyRef>()) }
    var dragDelta by remember { mutableIntStateOf(0) }

    val selName = ed.model.bones.getOrNull(selBone)?.name
    val rows: List<DRow> = remember(ver, filter, selBone, ed) {
        val idx = HashMap<String, Int>()
        ed.model.bones.forEachIndexed { i, b -> idx[b.name] = i }
        val list = ArrayList<DRow>()
        if (filter != 2) {
            val names: List<String> =
                if (filter == 3) listOfNotNull(selName).filter { ed.hasTrack(it) }
                else ed.boneTrackNames().sortedBy { idx[it] ?: Int.MAX_VALUE }
            for (n in names) list.add(DRow(n, false, false, ed.keyFramesOf(n), idx[n] ?: -1))
        }
        if (filter == 0 || filter == 2) for (n in ed.morphTrackNames()) list.add(DRow(n, true, false, ed.morphKeyFramesOf(n), -1))
        if (list.isNotEmpty()) {
            val u = java.util.TreeSet<Int>()
            for (r in list) for (f in r.frames) u.add(f)
            list.add(0, DRow("Resumo", false, true, u.toIntArray(), -1))
        }
        list
    }
    // depois de desfazer/refazer, keys selecionadas podem não existir mais
    val live: Set<KeyRef> = remember(sel, ver) { sel.filter { ed.hasKeyRef(it) }.toSet() }
    val selFrames: Set<Int> = remember(live) { live.map { it.frame }.toSet() }
    val lastKey = remember(ver) { ed.allKeyFrames().lastOrNull() ?: 0 }

    val rowsNow by rememberUpdatedState(rows)
    val liveNow by rememberUpdatedState(live)
    val onFrameNow by rememberUpdatedState(onFrame)
    val onSelBoneNow by rememberUpdatedState(onSelBone)
    val noteNow by rememberUpdatedState(note)
    val onTotalNow by rememberUpdatedState(onTotal)
    val edNow by rememberUpdatedState(ed)

    val labelDp = 88f; val headDp = 22f; val rowDp = 26f
    val dia = remember { Path() }
    val paint = remember { android.graphics.Paint().apply { isAntiAlias = true } }

    fun clampScroll(w: Float, h: Float, nRows: Int, ppf: Float) {
        val labelW = labelDp * dens
        val visFrames = (w - labelW) / ppf
        sx = sx.coerceIn(-2f, max(-2f, max(lastKey, frame).toFloat() + 20f - visFrames * 0.5f))
        val content = nRows * rowDp * dens
        val avail = h - headDp * dens
        sy = sy.coerceIn(0f, max(0f, content - avail))
    }

    Column(modifier.fillMaxSize()) {
        // ---- filtros e zoom
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            WBtn("Tudo", on = filter == 0) { filter = 0 }
            WBtn("Ossos", on = filter == 1) { filter = 1 }
            WBtn("Morphs", on = filter == 2) { filter = 2 }
            WBtn("Osso", on = filter == 3) { filter = 3 }
            WBtn("−") { val a = (vw - labelDp * dens) / 2f; val f = sx + a / (zoom * dens); zoom = (zoom / 1.4f).coerceIn(1.5f, 48f); sx = f - a / (zoom * dens); clampScroll(vw, vh, rows.size, zoom * dens) }
            WBtn("+") { val a = (vw - labelDp * dens) / 2f; val f = sx + a / (zoom * dens); zoom = (zoom * 1.4f).coerceIn(1.5f, 48f); sx = f - a / (zoom * dens); clampScroll(vw, vh, rows.size, zoom * dens) }
            WBtn("Fit") {
                val frames = max(lastKey + 6, 12)
                zoom = ((vw - labelDp * dens) / (frames * dens)).coerceIn(1.5f, 48f); sx = -1f
            }
            WBtn("⌖") { sx = frame - ((vw - labelDp * dens) / (zoom * dens)) / 2f; clampScroll(vw, vh, rows.size, zoom * dens) }
        }

        // ---- grade
        Canvas(
            Modifier.fillMaxWidth().weight(1f).padding(top = 4.dp).background(Color(0xFF101114), RoundedCornerShape(6.dp)).clipToBounds()
                .onSizeChanged { vw = it.width.toFloat(); vh = it.height.toFloat() }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val labelW = labelDp * dens; val headH = headDp * dens; val rowH = rowDp * dens
                        val slop = viewConfiguration.touchSlop
                        val rs = rowsNow

                        fun ppf() = zoom * dens
                        fun frameAtX(x: Float) = sx + (x - labelW) / ppf()

                        // quem foi tocado
                        var hitRow: DRow? = null; var hitFrame = -1
                        if (down.position.x >= labelW && down.position.y >= headH) {
                            val ri = floor((down.position.y - headH + sy) / rowH).toInt()
                            val row = rs.getOrNull(ri)
                            if (row != null) {
                                var bd = 20f * dens
                                for (f in row.frames) {
                                    val d = abs(labelW + (f - sx) * ppf() - down.position.x)
                                    if (d < bd) { bd = d; hitRow = row; hitFrame = f }
                                }
                            }
                        }
                        val inHeader = down.position.y < headH && down.position.x >= labelW
                        // modos: 0 indeciso, 1 rolar, 2 arrastar keys, 3 pinça, 4 régua
                        var mode = if (inHeader) 4 else 0
                        var total = Offset.Zero
                        var dragPx = 0f
                        var dragMin = 0
                        var dragSet: Set<KeyRef> = emptySet()
                        if (mode == 4) onFrameNow(max(0, frameAtX(down.position.x).roundToInt()))
                        down.consume()

                        while (true) {
                            val ev = awaitPointerEvent()
                            val pressed: List<PointerInputChange> = ev.changes.filter { it.pressed }
                            if (pressed.isEmpty()) {
                                // soltou tudo
                                if (mode == 0) {
                                    val hr = hitRow
                                    if (hr != null) {
                                        val refs = refsAt(rs, hr, hitFrame)
                                        val all = refs.isNotEmpty() && refs.all { it in liveNow }
                                        sel = if (all) liveNow - refs.toSet() else liveNow + refs
                                        onFrameNow(hitFrame)
                                        if (!hr.morph && !hr.summary && hr.boneIdx >= 0) onSelBoneNow(hr.boneIdx)
                                    } else if (down.position.x < labelW && down.position.y >= headH) {
                                        val ri = floor((down.position.y - headH + sy) / rowH).toInt()
                                        val row = rs.getOrNull(ri)
                                        if (row != null && !row.morph && !row.summary && row.boneIdx >= 0) onSelBoneNow(row.boneIdx)
                                    } else if (down.position.x >= labelW && down.position.y >= headH) {
                                        onFrameNow(max(0, frameAtX(down.position.x).roundToInt()))
                                    }
                                } else if (mode == 2) {
                                    val d = dragDelta
                                    dragDelta = 0
                                    if (d != 0) {
                                        val refs = dragSet.toList()
                                        val r = edNow.moveKeyRefs(refs, d)
                                        if (r < 0) noteNow("Não dá: alguma key iria para antes do quadro 0")
                                        else {
                                            sel = refs.map { it.copy(frame = it.frame + d) }.toSet()
                                            onTotalNow(edNow.allKeyFrames().lastOrNull() ?: 0)
                                            noteNow("$r key(s) movidas ${if (d > 0) "+" else ""}$d quadro(s)")
                                        }
                                    }
                                }
                                break
                            }
                            if (pressed.size >= 2) {
                                if (mode == 2) dragDelta = 0
                                mode = 3
                                val a = pressed[0]; val b = pressed[1]
                                val spanNow = max(abs(a.position.x - b.position.x), 48f)
                                val spanPrev = max(abs(a.previousPosition.x - b.previousPosition.x), 48f)
                                val cxNow = (a.position.x + b.position.x) / 2f; val cxPrev = (a.previousPosition.x + b.previousPosition.x) / 2f
                                val cyNow = (a.position.y + b.position.y) / 2f; val cyPrev = (a.previousPosition.y + b.previousPosition.y) / 2f
                                val fAt = sx + (cxPrev - labelW) / ppf()
                                zoom = (zoom * spanNow / spanPrev).coerceIn(1.5f, 48f)
                                sx = fAt - (cxNow - labelW) / ppf()
                                sy -= (cyNow - cyPrev)
                                clampScroll(size.width.toFloat(), size.height.toFloat(), rs.size, ppf())
                                a.consume(); b.consume()
                            } else {
                                val c = pressed[0]
                                if (mode == 3) { c.consume(); continue }
                                val dp = c.positionChange()
                                if (mode == 4) {
                                    onFrameNow(max(0, frameAtX(c.position.x).roundToInt()))
                                    c.consume(); continue
                                }
                                total += dp
                                if (mode == 0 && total.getDistance() > slop) {
                                    val hr = hitRow
                                    if (hr != null && abs(total.x) >= abs(total.y) * 0.6f) {
                                        // começa a arrastar keys: se a key tocada não está na seleção, a seleção passa a ser ela
                                        val refs = refsAt(rs, hr, hitFrame)
                                        if (!refs.all { it in liveNow }) sel = refs.toSet()
                                        val cur: Set<KeyRef> = if (refs.all { it in liveNow }) liveNow else refs.toSet()
                                        dragSet = cur
                                        dragMin = cur.minOfOrNull { it.frame } ?: 0
                                        dragPx = total.x - dp.x   // o dp deste evento é somado logo abaixo
                                        mode = 2
                                    } else mode = 1
                                }
                                if (mode == 1) {
                                    sx -= dp.x / ppf(); sy -= dp.y
                                    clampScroll(size.width.toFloat(), size.height.toFloat(), rs.size, ppf())
                                    c.consume()
                                } else if (mode == 2) {
                                    dragPx += dp.x
                                    dragDelta = max((dragPx / ppf()).roundToInt(), -dragMin)
                                    c.consume()
                                }
                            }
                        }
                    }
                }
        ) {
            val labelW = labelDp * dens; val headH = headDp * dens; val rowH = rowDp * dens
            val ppf = zoom * dens
            val w = size.width; val h = size.height
            val d = dragDelta

            // régua: escolhe o passo de modo que as marcas fiquem >= 44dp
            var step = StepList.last()
            for (s in StepList) if (s * ppf >= 44f * dens) { step = s; break }
            val f0 = sx; val f1 = sx + (w - labelW) / ppf

            clipRect(labelW, headH, w, h) {
                // linhas
                for (i in rows.indices) {
                    val y0 = headH + i * rowH - sy
                    if (y0 + rowH < headH || y0 > h) continue
                    val r = rows[i]
                    val bg = when {
                        r.summary -> Color(0xFF1F2024)
                        !r.morph && r.boneIdx == selBone && selBone >= 0 -> Color(0xFF3A2224)
                        i % 2 == 0 -> Color(0xFF15161A)
                        else -> Color(0xFF121317)
                    }
                    drawRect(bg, Offset(labelW, y0), Size(w - labelW, rowH))
                }
                // grade vertical
                var t = (ceil(f0 / step) * step).toInt()
                while (t <= f1) {
                    val x = labelW + (t - sx) * ppf
                    drawLine(Color(0x22FFFFFF), Offset(x, headH), Offset(x, h), 1f)
                    t += step
                }
                // keys
                val rad = 6f * dens
                for (i in rows.indices) {
                    val y0 = headH + i * rowH - sy
                    if (y0 + rowH < headH || y0 > h) continue
                    val r = rows[i]
                    val cy = y0 + rowH / 2f
                    val base = if (r.morph) KeyMorph else KeyBone
                    for (f in r.frames) {
                        val x = labelW + (f - sx) * ppf
                        if (x < labelW - rad - 2f || x > w + rad + 2f) continue
                        val isSel = if (r.summary) f in selFrames else (live.isNotEmpty() && KeyRef(r.morph, r.name, f) in live)
                        val rr = if (r.summary) rad * 0.9f else rad * 0.8f
                        fun diamond(cx: Float, c: Color) {
                            dia.reset()
                            dia.moveTo(cx, cy - rr); dia.lineTo(cx + rr, cy); dia.lineTo(cx, cy + rr); dia.lineTo(cx - rr, cy); dia.close()
                            drawPath(dia, c)
                        }
                        if (isSel && d != 0) {
                            diamond(x, base.copy(alpha = 0.3f))      // original (fantasma)
                            diamond(x + d * ppf, KeySel)              // prévia do destino
                        } else diamond(x, if (isSel) KeySel else base)
                    }
                }
                // quadro atual
                val px = labelW + (frame - sx) * ppf
                if (px in labelW..w) drawLine(Accent, Offset(px, headH), Offset(px, h), 2f)
            }

            // régua (por cima)
            drawRect(Color(0xFF1A1B1F), Offset(labelW, 0f), Size(w - labelW, headH))
            drawIntoCanvas { cv ->
                val n = cv.nativeCanvas
                paint.textSize = 10f * dens
                paint.color = android.graphics.Color.rgb(0x8A, 0x8D, 0x94)
                var t = (ceil(f0 / step) * step).toInt()
                while (t <= f1) {
                    val x = labelW + (t - sx) * ppf
                    if (x >= labelW) n.drawText("$t", x + 3f * dens, headH - 6f * dens, paint)
                    t += step
                }
            }
            val px = labelW + (frame - sx) * ppf
            if (px in labelW..w) {
                dia.reset(); dia.moveTo(px - 5f * dens, 0f); dia.lineTo(px + 5f * dens, 0f); dia.lineTo(px, headH * 0.6f); dia.close()
                drawPath(dia, Accent)
            }

            // coluna de nomes (por cima)
            drawRect(Color(0xFF17181B), Offset(0f, 0f), Size(labelW, h))
            clipRect(0f, headH, labelW, h) {
                drawIntoCanvas { cv ->
                    val n = cv.nativeCanvas
                    paint.textSize = 11f * dens
                    for (i in rows.indices) {
                        val y0 = headH + i * rowH - sy
                        if (y0 + rowH < headH || y0 > h) continue
                        val r = rows[i]
                        val isSelRow = !r.morph && !r.summary && r.boneIdx == selBone && selBone >= 0
                        paint.color = when {
                            isSelRow -> android.graphics.Color.rgb(0xFF, 0x8A, 0x80)
                            r.morph -> android.graphics.Color.rgb(0x7F, 0xB8, 0xFF)
                            r.summary -> android.graphics.Color.WHITE
                            else -> android.graphics.Color.rgb(0xDD, 0xDD, 0xDD)
                        }
                        val maxW = labelW - 8f * dens
                        val cnt = paint.breakText(r.name, true, maxW, null)
                        n.drawText(r.name.substring(0, cnt), 6f * dens, y0 + rowH / 2f + 4f * dens, paint)
                    }
                }
            }
            drawLine(Color(0xFF2A2C31), Offset(labelW, 0f), Offset(labelW, h), 1f)
        }

        // ---- informação
        val n = live.size
        Text(
            when {
                rows.isEmpty() -> "Sem keyframes neste filtro. Edite um osso/morph ou importe um VMD."
                dragDelta != 0 -> "Movendo ${if (dragDelta > 0) "+" else ""}$dragDelta quadro(s) — solte para gravar"
                n == 0 -> "Toque numa key para selecionar · arraste para mover · pinça = zoom · arraste o vazio = rolar"
                else -> "$n key(s) selecionada(s) · quadro $frame"
            },
            color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 3.dp)
        )

        // ---- seleção
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            WBtn("Linha", enabled = selName != null && ed.hasTrack(selName)) {
                val nm = selName ?: return@WBtn
                sel = live + ed.keyFramesOf(nm).map { KeyRef(false, nm, it) }
            }
            WBtn("Quadro") {
                sel = live + rows.filter { !it.summary && java.util.Arrays.binarySearch(it.frames, frame) >= 0 }.map { KeyRef(it.morph, it.name, frame) }
            }
            WBtn("Tudo") {
                val all = HashSet<KeyRef>(live)
                for (r in rows) if (!r.summary) for (f in r.frames) all.add(KeyRef(r.morph, r.name, f))
                sel = all
            }
            WBtn("Limpar", enabled = live.isNotEmpty()) { sel = emptySet() }
        }
        // ---- ações sobre a seleção (todas com desfazer)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            fun move(dlt: Int) {
                val refs = live.toList()
                val r = ed.moveKeyRefs(refs, dlt)
                if (r < 0) note("Não dá: alguma key iria para antes do quadro 0")
                else if (r > 0) { sel = refs.map { it.copy(frame = it.frame + dlt) }.toSet(); onTotal(ed.allKeyFrames().lastOrNull() ?: 0) }
            }
            WBtn("◀10", enabled = n > 0) { move(-10) }
            WBtn("◀1", enabled = n > 0) { move(-1) }
            WBtn("1▶", enabled = n > 0) { move(1) }
            WBtn("10▶", enabled = n > 0) { move(10) }
            WBtn("Copiar", enabled = n > 0) { note("${ed.copyKeyRefs(live)} key(s) copiadas") }
            WBtn("Colar", enabled = ed.hasKeyClip) {
                val c = ed.pasteKeys(frame)
                onTotal(ed.allKeyFrames().lastOrNull() ?: 0)
                note("$c key(s) coladas no quadro $frame")
            }
            WBtn("Apagar", enabled = n > 0) { val c = ed.deleteKeyRefs(live); sel = emptySet(); note("$c key(s) apagadas") }
        }
    }
}
