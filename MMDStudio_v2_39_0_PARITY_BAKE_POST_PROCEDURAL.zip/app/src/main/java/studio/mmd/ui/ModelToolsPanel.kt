package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.edit.ModelToolsSession
import studio.mmd.edit.ModelDiagnostics
import studio.mmd.edit.MeshTopologyAnalyzer
import studio.mmd.edit.copyPmxMaterial
import studio.mmd.edit.WeightPaintSession
import studio.mmd.edit.WeightPaintMode
import studio.mmd.edit.WeightTransferOptions
import studio.mmd.edit.SculptBrushMode
import studio.mmd.edit.SeamAwareUvUnwrapper
import studio.mmd.edit.MeshEditing
import studio.mmd.edit.MeshMaskPaintSession
import studio.mmd.edit.MeshMaskPaintMode
import studio.mmd.edit.MeshMaskFalloff
import studio.mmd.edit.MeshMaskDeformMode
import studio.mmd.edit.MeshMaskPresetCodec
import studio.mmd.rig.SkirtCorrectionRegion
import studio.mmd.rig.SkirtGuardRegionWeights
import studio.mmd.mmd.PmxMaterial
import studio.mmd.material.MaterialGraph
import studio.mmd.material.MaterialGraphLink
import studio.mmd.material.MaterialGraphNode
import studio.mmd.material.MaterialNodeKind
import studio.mmd.material.ShaderGraphCompiler
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxModelDoctor
import studio.mmd.mmd.PmxPhysicsDoctor
import studio.mmd.mmd.PmxMorphDoctor
import studio.mmd.mmd.PmxIssueSeverity
import studio.mmd.edit.PmxWeightDoctor
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ModelToolsTab { MESH, SELECT, MASK, WEIGHTS, UV, MATERIAL, SHADER, CHECK }

@Composable
fun ModelToolsPanel(
    model: PmxModel, onApply: (PmxModel) -> Unit, note: (String) -> Unit,
    modifier: Modifier = Modifier, weightSource: PmxModel? = null,
    onChooseWeightSource: () -> Unit = {}, onClearWeightSource: () -> Unit = {},
    onViewportPaintMode: (Boolean, Float, ((FloatArray) -> Unit)?, (() -> Unit)?) -> Unit = { _, _, _, _ -> },
    onMeshMaskPreview: (FloatArray) -> Unit = {},
    onExportMaskPreset: (ByteArray) -> Unit = {},
    onImportMaskPreset: () -> Unit = {},
    incomingMaskPreset: FloatArray? = null,
    onMaskPresetConsumed: () -> Unit = {}
) {
    val session = remember(model) { ModelToolsSession(model) }
    val weightSession = remember(model) { WeightPaintSession(model) }
    var weightRevision by remember(model) { mutableIntStateOf(0) }
    var selectedBone by remember(model) { mutableIntStateOf(0) }
    var targetWeight by remember(model) { mutableFloatStateOf(1f) }
    var brushStrength by remember(model) { mutableFloatStateOf(1f) }
    var brushX by remember(model) { mutableFloatStateOf(0f) }
    var brushY by remember(model) { mutableFloatStateOf(0f) }
    var brushZ by remember(model) { mutableFloatStateOf(0f) }
    var brushRadius by remember(model) { mutableFloatStateOf(0.5f) }
    var transferNeighbors by remember(model) { mutableIntStateOf(4) }
    var transferMaxDistance by remember(model) { mutableFloatStateOf(0f) }
    var weightMode by remember(model) { mutableStateOf(WeightPaintMode.REPLACE) }
    var viewportPaintOn by remember(model) { mutableStateOf(false) }
    val viewportStroke = remember(model) { ArrayList<FloatArray>() }
    val maskSession = remember(model) { MeshMaskPaintSession(model) }
    var maskRevision by remember(model) { mutableIntStateOf(0) }
    var maskPaintOn by remember(model) { mutableStateOf(false) }
    var maskRadius by remember(model) { mutableFloatStateOf(.28f) }
    var maskStrength by remember(model) { mutableFloatStateOf(.75f) }
    var maskTarget by remember(model) { mutableFloatStateOf(1f) }
    var maskMode by remember(model) { mutableStateOf(MeshMaskPaintMode.REPLACE) }
    var maskMirrorX by remember(model) { mutableStateOf(false) }
    var maskSurfaceConstrained by remember(model) { mutableStateOf(true) }
    var maskFalloff by remember(model) { mutableStateOf(MeshMaskFalloff.SMOOTH) }
    val maskStroke = remember(model) { ArrayList<FloatArray>() }
    LaunchedEffect(viewportPaintOn, maskPaintOn, brushRadius, selectedBone, targetWeight, brushStrength, weightMode,
        maskRadius, maskStrength, maskTarget, maskMode, maskMirrorX, maskSurfaceConstrained, maskFalloff, maskRevision) {
        val active = viewportPaintOn || maskPaintOn
        onViewportPaintMode(active, 46f,
            if (maskPaintOn) ({ point -> maskStroke.add(point.copyOf()) }) else if (viewportPaintOn) ({ point -> viewportStroke.add(point.copyOf()) }) else null,
            if (maskPaintOn) ({
                val points = maskStroke.toList(); maskStroke.clear()
                if (points.isNotEmpty()) {
                    val report = maskSession.paintStroke(points, session.positionsCopy(), maskRadius, maskStrength, maskTarget, maskMode, maskMirrorX, maskSurfaceConstrained, maskFalloff)
                    maskRevision++
                    note(if (maskSurfaceConstrained && model.vertexCount > 250_000) "Pincel geodésico limitado a 250 mil vértices por segurança de memória; desative o modo geodésico para pintar esta malha." else "Máscara pintada na viewport: ${report.affectedVertices} alterações · ${points.size} amostras")
                }
            }) else if (viewportPaintOn) ({
                val points = viewportStroke.toList(); viewportStroke.clear()
                if (points.isNotEmpty() && model.bones.isNotEmpty()) {
                    val report = weightSession.paintStroke(points, brushRadius, selectedBone.coerceIn(model.bones.indices), targetWeight, brushStrength, weightMode)
                    weightRevision++
                    note("Pintura na viewport: ${report.changed} alterações em ${points.size} amostras · uma operação Undo")
                }
            }) else null
        )
    }
    LaunchedEffect(incomingMaskPreset) {
        val imported = incomingMaskPreset
        if (imported != null) {
            if (maskSession.replace(imported)) {
                maskRevision++
                note("Preset de máscara importado · ${imported.size} vértices · ${imported.count { it > .05f }} influenciados")
            } else note("Preset não aplicado: a máscara não corresponde à malha atual")
            onMaskPresetConsumed()
        }
    }
    LaunchedEffect(maskRevision, model) {
        onMeshMaskPreview(maskSession.valuesCopy())
    }
    DisposableEffect(Unit) { onDispose { onViewportPaintMode(false, 46f, null, null); onMeshMaskPreview(floatArrayOf()) } }
    var selectionFirst by remember(model) { mutableIntStateOf(0) }
    var selectionLast by remember(model) { mutableIntStateOf((model.vertexCount - 1).coerceAtLeast(0)) }
    var selectionMaterial by remember(model) { mutableIntStateOf(0) }
    var selectionBone by remember(model) { mutableIntStateOf(0) }
    var selectionSeed by remember(model) { mutableIntStateOf(0) }
    var geodesicRadius by remember(model) { mutableFloatStateOf(.35f) }
    var maskThreshold by remember(model) { mutableFloatStateOf(.5f) }
    var maskRelaxIterations by remember(model) { mutableIntStateOf(4) }
    var maskRelaxStrength by remember(model) { mutableFloatStateOf(.35f) }
    var maskMaxDisplacement by remember(model) { mutableFloatStateOf(.025f) }
    var spikeThreshold by remember(model) { mutableFloatStateOf(1.6f) }
    var maskDeformMode by remember(model) { mutableStateOf(MeshMaskDeformMode.INFLATE) }
    var maskDeformStrength by remember(model) { mutableFloatStateOf(.55f) }
    var maskDeformLimit by remember(model) { mutableFloatStateOf(.035f) }
    var maskDeformMoveX by remember(model) { mutableFloatStateOf(.02f) }
    var maskDeformMoveY by remember(model) { mutableFloatStateOf(0f) }
    var maskDeformMoveZ by remember(model) { mutableFloatStateOf(0f) }
    var maskDeformScale by remember(model) { mutableFloatStateOf(.85f) }
    var maskDeformRotateX by remember(model) { mutableFloatStateOf(0f) }
    var maskDeformRotateY by remember(model) { mutableFloatStateOf(0f) }
    var maskDeformRotateZ by remember(model) { mutableFloatStateOf(0f) }
    var maskPreserveBoundary by remember(model) { mutableStateOf(true) }
    var extrudeDistance by remember(model) { mutableFloatStateOf(.2f) }
    var insetAmount by remember(model) { mutableFloatStateOf(0f) }
    var sculptX by remember(model) { mutableFloatStateOf(0f) }; var sculptY by remember(model) { mutableFloatStateOf(0f) }; var sculptZ by remember(model) { mutableFloatStateOf(0f) }
    var sculptScale by remember(model) { mutableFloatStateOf(1f) }; var sculptStrength by remember(model) { mutableFloatStateOf(0.35f) }
    var sculptRadius by remember(model) { mutableFloatStateOf(.55f) }
    var sculptMoveX by remember(model) { mutableFloatStateOf(.08f) }
    var sculptMoveY by remember(model) { mutableFloatStateOf(0f) }
    var sculptMoveZ by remember(model) { mutableFloatStateOf(0f) }
    var sculptMode by remember(model) { mutableStateOf(SculptBrushMode.INFLATE) }
    var revision by remember(model) { mutableIntStateOf(0) }
    var tab by remember(model) { mutableStateOf(ModelToolsTab.MESH) }
    var uvAxis by remember(model) { mutableIntStateOf(0) }
    var uvSeamAngle by remember(model) { mutableFloatStateOf(55f) }
    var uvSeams by remember(model) { mutableStateOf<Set<Long>>(emptySet()) }
    var uvBusy by remember(model) { mutableStateOf(false) }
    val panelScope = rememberCoroutineScope()
    var uvScaleU by remember(model) { mutableFloatStateOf(1f) }
    var uvScaleV by remember(model) { mutableFloatStateOf(1f) }
    var uvOffsetU by remember(model) { mutableFloatStateOf(0f) }
    var uvOffsetV by remember(model) { mutableFloatStateOf(0f) }
    var sx by remember(model) { mutableFloatStateOf(1f) }
    var sy by remember(model) { mutableFloatStateOf(1f) }
    var sz by remember(model) { mutableFloatStateOf(1f) }
    var rx by remember(model) { mutableFloatStateOf(0f) }
    var ry by remember(model) { mutableFloatStateOf(0f) }
    var rz by remember(model) { mutableFloatStateOf(0f) }
    var materialIndex by remember(model) { mutableIntStateOf(0) }
    val material = session.material(materialIndex)
    var diffuse by remember(model, materialIndex, revision) { mutableStateOf(material?.diffuse?.copyOf() ?: floatArrayOf(1f, 1f, 1f, 1f)) }
    var specular by remember(model, materialIndex, revision) { mutableStateOf(material?.specular?.copyOf() ?: floatArrayOf(0f, 0f, 0f)) }
    var ambient by remember(model, materialIndex, revision) { mutableStateOf(material?.ambient?.copyOf() ?: floatArrayOf(0f, 0f, 0f)) }
    var edge by remember(model, materialIndex, revision) { mutableStateOf(material?.edgeColor?.copyOf() ?: floatArrayOf(0f, 0f, 0f, 1f)) }
    var specPower by remember(model, materialIndex, revision) { mutableFloatStateOf(material?.specularPower ?: 0f) }
    var edgeSize by remember(model, materialIndex, revision) { mutableFloatStateOf(material?.edgeSize ?: 0f) }
    var baseTexture by remember(model, materialIndex, revision) { mutableIntStateOf(material?.textureIndex ?: -1) }
    var sphereTexture by remember(model, materialIndex, revision) { mutableIntStateOf(material?.sphereIndex ?: -1) }
    var sphereMode by remember(model, materialIndex, revision) { mutableIntStateOf(material?.sphereMode ?: 0) }
    var doubleSided by remember(model, materialIndex, revision) { mutableStateOf(material?.doubleSided ?: false) }
    var edgeEnabled by remember(model, materialIndex, revision) { mutableStateOf((material?.flags ?: 0) and 0x10 != 0) }
    var shaderMetallic by remember(model, materialIndex, revision) { mutableFloatStateOf(0.05f) }
    var shaderRoughness by remember(model, materialIndex, revision) { mutableFloatStateOf(sqrt(2f / ((material?.specularPower ?: 30f).coerceAtLeast(0f) + 2f)).coerceIn(.04f, 1f)) }
    var shaderMixEnabled by remember(model, materialIndex, revision) { mutableStateOf(false) }
    var shaderMultiplyEnabled by remember(model, materialIndex, revision) { mutableStateOf(false) }
    var shaderTintStyle by remember(model, materialIndex, revision) { mutableIntStateOf(0) }
    var shaderMixAmount by remember(model, materialIndex, revision) { mutableFloatStateOf(.2f) }
    @Suppress("UNUSED_VARIABLE") val redraw = revision

    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Malha", "Seleção", "Máscaras", "Pesos", "UV", "Materiais", "Shader", "Diagnóstico").forEachIndexed { i, label ->
                val t = ModelToolsTab.entries[i]
                FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(label, fontSize = 10.sp) })
            }
        }
        Spacer(Modifier.height(5.dp))
        when (tab) {
            ModelToolsTab.MESH -> {
                Text("BANCADA DE MALHA", color = Color.White, fontSize = 12.sp)
                Text("${session.vertexCount} vértices  ·  ${session.triangleCount} triângulos  ·  ${session.materialCount} materiais", color = Muted, fontSize = 10.sp)
                Spacer(Modifier.height(6.dp))
                Text("Transformação ao redor do centro da caixa", color = Muted, fontSize = 10.sp)
                ModelSlider("Escala X", sx, .05f..3f, { sx = it })
                ModelSlider("Escala Y", sy, .05f..3f, { sy = it })
                ModelSlider("Escala Z", sz, .05f..3f, { sz = it })
                ModelSlider("Rotação X", rx, -180f..180f, { rx = it }, "°")
                ModelSlider("Rotação Y", ry, -180f..180f, { ry = it }, "°")
                ModelSlider("Rotação Z", rz, -180f..180f, { rz = it }, "°")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { sx = 1f; sy = 1f; sz = 1f; rx = 0f; ry = 0f; rz = 0f }) { Text("Resetar") }
                    Button(onClick = { val r = session.transformGeometry(sx, sy, sz, rx, ry, rz); revision++; note(r.message) }) { Text("Aplicar transformação") }
                }
                OutlinedButton(onClick = { val r = session.recalculateNormals(); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Recalcular normais") }
                OutlinedButton(onClick = {
                    val r = MeshEditing.removeDegenerateFaces(model)
                    if (r.changedFaces > 0) onApply(r.model)
                    note(r.message)
                }, modifier = Modifier.fillMaxWidth()) { Text("Remover triângulos degenerados") }
                Text("A transformação global também alinha rig, morphs e física. Para edição localizada de vértices e faces, use Seleção.", color = Muted, fontSize = 9.sp)
            }
            ModelToolsTab.SELECT -> {
                Text("SELEÇÃO E ESCULTURA DE VÉRTICES", color = Color.White, fontSize = 12.sp)
                Text("${session.selectedCount} / ${session.vertexCount} vértices selecionados", color = Color(0xFF8ED7FF), fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { session.selectAll(); revision++ }, modifier = Modifier.weight(1f)) { Text("Todos") }
                    OutlinedButton(onClick = { session.invertSelection(); revision++ }, modifier = Modifier.weight(1f)) { Text("Inverter") }
                    OutlinedButton(onClick = { session.clearSelection(); revision++ }, modifier = Modifier.weight(1f)) { Text("Limpar") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { session.growSelection(); revision++ }, modifier = Modifier.weight(1f)) { Text("Expandir") }
                    OutlinedButton(onClick = { session.shrinkSelection(); revision++ }, modifier = Modifier.weight(1f)) { Text("Contrair") }
                    OutlinedButton(onClick = { session.selectBoundary(); revision++ }, modifier = Modifier.weight(1f)) { Text("Bordas") }
                }
                Text("Intervalo de índices", color = Muted, fontSize = 10.sp)
                ModelSlider("Início", selectionFirst.toFloat(), 0f..(model.vertexCount - 1).coerceAtLeast(0).toFloat(), { selectionFirst = it.roundToInt() }, "")
                ModelSlider("Fim", selectionLast.toFloat(), 0f..(model.vertexCount - 1).coerceAtLeast(0).toFloat(), { selectionLast = it.roundToInt() }, "")
                OutlinedButton(onClick = { session.selectRange(selectionFirst, selectionLast); revision++ }, modifier = Modifier.fillMaxWidth()) { Text("Selecionar intervalo") }
                Text("Por material", color = Muted, fontSize = 10.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    model.materials.forEachIndexed { i, m -> FilterChip(selected = selectionMaterial == i, onClick = { selectionMaterial = i }, label = { Text(m.name.ifBlank { "Mat ${i + 1}" }.take(14), fontSize = 9.sp) }) }
                }
                OutlinedButton(onClick = { if (model.materials.isNotEmpty()) { val n = session.selectByMaterial(selectionMaterial.coerceIn(model.materials.indices)); revision++; note("$n vértices selecionados pelo material") } }, modifier = Modifier.fillMaxWidth(), enabled = model.materials.isNotEmpty()) { Text("Selecionar material") }
                Text("Por osso", color = Muted, fontSize = 10.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    model.bones.forEachIndexed { i, b -> FilterChip(selected = selectionBone == i, onClick = { selectionBone = i }, label = { Text(b.name.take(14), fontSize = 9.sp) }) }
                }
                OutlinedButton(onClick = { if (model.bones.isNotEmpty()) { val n = session.selectByBone(selectionBone.coerceIn(model.bones.indices)); revision++; note("$n vértices selecionados pela influência do osso") } }, modifier = Modifier.fillMaxWidth(), enabled = model.bones.isNotEmpty()) { Text("Selecionar influência do osso") }
                Divider(color = Color.DarkGray)
                Text("SELEÇÃO TOPOLÓGICA / GEODÉSICA", color = Color.White, fontSize = 10.sp)
                ModelSlider("Vértice inicial", selectionSeed.toFloat(), 0f..(model.vertexCount - 1).coerceAtLeast(0).toFloat(), { selectionSeed = it.roundToInt().coerceIn(0, (model.vertexCount - 1).coerceAtLeast(0)) }, "")
                ModelSlider("Raio pela malha", geodesicRadius, .01f..3f, { geodesicRadius = it })
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(enabled = model.vertexCount > 0, onClick = { val n = session.selectConnectedComponent(selectionSeed.coerceIn(0, model.vertexCount - 1)); revision++; note("Componente conectado: $n vértices") }, modifier = Modifier.weight(1f)) { Text("Ilha conectada") }
                    OutlinedButton(enabled = model.vertexCount > 0, onClick = { val n = session.selectGeodesicRadius(selectionSeed.coerceIn(0, model.vertexCount - 1), geodesicRadius); revision++; note("Seleção geodésica: $n vértices") }, modifier = Modifier.weight(1f)) { Text("Raio geodésico") }
                }
                Divider(color = Color.DarkGray)
                Text("EDITOR DE FACES", color = Color.White, fontSize = 11.sp)
                Text("As operações consideram uma face selecionada quando seus três vértices estão na seleção. Os vértices não utilizados são preservados para não quebrar morphs PMX.", color = Muted, fontSize = 9.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(enabled = session.selectedCount >= 3, onClick = {
                        val r = MeshEditing.deleteFacesInsideSelection(model, session.selectedVertices())
                        if (r.changedFaces > 0) onApply(r.model)
                        note(r.message)
                    }, modifier = Modifier.weight(1f)) { Text("Apagar faces") }
                    OutlinedButton(enabled = session.selectedCount >= 3, onClick = {
                        val r = MeshEditing.flipFacesInsideSelection(model, session.selectedVertices())
                        if (r.changedFaces > 0) onApply(r.model)
                        note(r.message)
                    }, modifier = Modifier.weight(1f)) { Text("Inverter faces") }
                }
                ModelSlider("Altura da extrusão", extrudeDistance, -2f..2f, { extrudeDistance = it })
                ModelSlider("Inset do patch", insetAmount, 0f..0.9f, { insetAmount = it })
                Button(enabled = session.selectedCount >= 3 && (kotlin.math.abs(extrudeDistance) > 1e-5f || insetAmount > 1e-5f), onClick = {
                    val r = MeshEditing.extrudeFacesInsideSelection(model, session.selectedVertices(), extrudeDistance, insetAmount)
                    if (r.changedFaces > 0 && !r.aborted) onApply(r.model)
                    note(r.message)
                }, modifier = Modifier.fillMaxWidth()) { Text("Extrudar / Inset faces") }
                Divider(color = Color.DarkGray)
                Text("Escultura não destrutiva", color = Color.White, fontSize = 11.sp)
                ModelSlider("Mover X", sculptX, -10f..10f, { sculptX = it })
                ModelSlider("Mover Y", sculptY, -10f..10f, { sculptY = it })
                ModelSlider("Mover Z", sculptZ, -10f..10f, { sculptZ = it })
                ModelSlider("Escala", sculptScale, .1f..3f, { sculptScale = it })
                ModelSlider("Suavidade", sculptStrength, 0f..1f, { sculptStrength = it })
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = { val r = session.transformSelected(sculptX, sculptY, sculptZ, sculptScale); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Transformar") }
                    OutlinedButton(onClick = { val r = session.smoothSelected(3, sculptStrength); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Suavizar") }
                }
                OutlinedButton(onClick = { val r = session.inflateSelected(sculptStrength * .2f); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Inflar seleção") }
                Divider(color = Color.DarkGray)
                Text("PINCEL ESPACIAL DE ESCULTURA", color = Color.White, fontSize = 10.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    SculptBrushMode.entries.forEach { brush ->
                        FilterChip(selected = sculptMode == brush, onClick = { sculptMode = brush }, label = { Text(when (brush) {
                            SculptBrushMode.INFLATE -> "Inflar"; SculptBrushMode.SMOOTH -> "Suavizar"; SculptBrushMode.PINCH -> "Apertar"; SculptBrushMode.MOVE -> "Mover"
                        }, fontSize = 9.sp) })
                    }
                }
                ModelSlider("Raio", sculptRadius, .02f..4f, { sculptRadius = it })
                if (sculptMode == SculptBrushMode.MOVE) {
                    ModelSlider("Deslocamento X", sculptMoveX, -2f..2f, { sculptMoveX = it })
                    ModelSlider("Deslocamento Y", sculptMoveY, -2f..2f, { sculptMoveY = it })
                    ModelSlider("Deslocamento Z", sculptMoveZ, -2f..2f, { sculptMoveZ = it })
                }
                Button(onClick = {
                    val r = session.sculptBrush(sculptX, sculptY, sculptZ, sculptRadius, sculptStrength, sculptMode,
                        moveX = sculptMoveX, moveY = sculptMoveY, moveZ = sculptMoveZ)
                    revision++; note(r.message)
                }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar pincel espacial") }
                Text("Inflar segue a normal; Suavizar usa a vizinhança topológica; Apertar move para o centro; Mover desloca com intensidade e falloff. Um único Undo por aplicação.", color = Muted, fontSize = 9.sp)
            }
            ModelToolsTab.MASK -> {
                val currentMask = remember(maskRevision, model) { maskSession.valuesCopy() }
                Text("MESH MASK STUDIO · PINTURA DE INFLUÊNCIA", color = Color.White, fontSize = 12.sp)
                Text("Pinte uma máscara temporária por vértice com visualização em mapa de calor, simetria X, pincel geodésico, presets portáteis e correções localizadas sem mover a malha inteira.", color = Muted, fontSize = 9.sp)
                Text("${maskSession.paintedVertices} vértices com influência · média ${"%.3f".format(java.util.Locale.US, maskSession.meanValue)} · Histórico ${maskSession.historyEntries}/${maskSession.historyCapacity} · Undo ${if (maskSession.canUndo) "disponível" else "—"} · Redo ${if (maskSession.canRedo) "disponível" else "—"}", color = Color(0xFF8ED7FF), fontSize = 10.sp)
                ModelSlider("Raio do pincel", maskRadius, .02f..1.5f, { maskRadius = it })
                ModelSlider("Força", maskStrength, 0f..1f, { maskStrength = it })
                ModelSlider("Valor alvo", maskTarget, 0f..1f, { maskTarget = it })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(MeshMaskPaintMode.REPLACE to "Pintar", MeshMaskPaintMode.ADD to "Adicionar", MeshMaskPaintMode.SUBTRACT to "Apagar").forEach { (mode, label) ->
                        FilterChip(selected = maskMode == mode, onClick = { maskMode = mode }, label = { Text(label, fontSize = 9.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Espelhar pincel no eixo X", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    Switch(checked = maskMirrorX, onCheckedChange = { maskMirrorX = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pincel geodésico (segue a superfície)", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    Switch(checked = maskSurfaceConstrained, onCheckedChange = { maskSurfaceConstrained = it })
                }
                Text("Geodésico impede que o pincel atravesse o espaço entre camadas próximas e só se propaga por arestas conectadas. Por segurança de memória, o modo geodésico é limitado a 250 mil vértices.", color = Muted, fontSize = 9.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(MeshMaskFalloff.LINEAR to "Linear", MeshMaskFalloff.SMOOTH to "Suave", MeshMaskFalloff.SHARP to "Afiado", MeshMaskFalloff.CONSTANT to "Constante").forEach { (falloff, label) ->
                        FilterChip(selected = maskFalloff == falloff, onClick = { maskFalloff = falloff }, label = { Text(label, fontSize = 9.sp) })
                    }
                }
                Button(onClick = { maskPaintOn = !maskPaintOn; if (maskPaintOn) viewportPaintOn = false }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (maskPaintOn) "Encerrar pintura de máscara" else "Pintar máscara diretamente na viewport")
                }
                Text(if (maskPaintOn) "Pintura ativa: arraste o dedo sobre a roupa/personagem. O traço acompanha os pontos 3D e cada stroke gera uma operação Undo." else "A viewport seleciona a superfície visível sob o toque. O raio está em unidades locais do modelo.", color = Muted, fontSize = 9.sp)
                Divider(color = Color.DarkGray)
                Text("GERAÇÃO AUTOMÁTICA DE REGIÃO", color = Color.White, fontSize = 10.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(SkirtCorrectionRegion.ALL to "Toda", SkirtCorrectionRegion.FRONT to "Frente", SkirtCorrectionRegion.BACK to "Trás", SkirtCorrectionRegion.LEFT to "Esquerda", SkirtCorrectionRegion.RIGHT to "Direita").forEach { (region, label) ->
                        OutlinedButton(onClick = {
                            val generated = SkirtGuardRegionWeights.build(session.buildModel().positions, model.indices, region, .35f, 3, .25f)
                            if (maskSession.replace(generated)) maskRevision++
                            note("Máscara regional $label gerada · ${generated.count { it > .05f }} vértices influenciados")
                        }) { Text(label, fontSize = 9.sp) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { val n = maskSession.fillVertices(session.selectedVertices()); maskRevision++; note("Máscara preenchida em $n vértices selecionados") }, modifier = Modifier.weight(1f), enabled = session.selectedCount > 0) { Text("Preencher seleção") }
                    OutlinedButton(onClick = { val n = maskSession.fill(); maskRevision++; note("Máscara completa: $n vértices") }, modifier = Modifier.weight(1f)) { Text("Tudo 100%") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { maskSession.invert(); maskRevision++; note("Máscara invertida") }, modifier = Modifier.weight(1f)) { Text("Inverter") }
                    OutlinedButton(onClick = { val n = maskSession.clear(); maskRevision++; note("Máscara limpa: $n valores alterados") }, modifier = Modifier.weight(1f)) { Text("Limpar") }
                    OutlinedButton(onClick = { val n = maskSession.smooth(4, .35f, true); maskRevision++; note("Máscara suavizada: $n valores") }, modifier = Modifier.weight(1f)) { Text("Suavizar") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(enabled = maskSession.canUndo, onClick = { maskSession.undo(); maskRevision++ }, modifier = Modifier.weight(1f)) { Text("Undo máscara") }
                    OutlinedButton(enabled = maskSession.canRedo, onClick = { maskSession.redo(); maskRevision++ }, modifier = Modifier.weight(1f)) { Text("Redo máscara") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = {
                        runCatching { MeshMaskPresetCodec.encode(model, maskSession.valuesCopy()) }
                            .onSuccess { onExportMaskPreset(it); note("Preset .mmdmask pronto para exportação") }
                            .onFailure { note("Falha ao preparar preset: ${it.message ?: it.javaClass.simpleName}") }
                    }, modifier = Modifier.weight(1f)) { Text("Exportar preset") }
                    OutlinedButton(onClick = onImportMaskPreset, modifier = Modifier.weight(1f)) { Text("Importar preset") }
                }
                Text("Presets .mmdmask preservam valores por vértice e verificam checksum + geometria/topologia antes da importação.", color = Muted, fontSize = 9.sp)
                Divider(color = Color.DarkGray)
                Text("APLICAR À GEOMETRIA", color = Color.White, fontSize = 10.sp)
                ModelSlider("Limiar de seleção", maskThreshold, 0f..1f, { maskThreshold = it })
                OutlinedButton(onClick = { val n = session.selectByMask(currentMask, maskThreshold); revision++; note("Seleção a partir da máscara: $n vértices") }, modifier = Modifier.fillMaxWidth()) { Text("Selecionar vértices pela máscara") }
                ModelSlider("Iterações Taubin", maskRelaxIterations.toFloat(), 1f..16f, { maskRelaxIterations = it.roundToInt().coerceIn(1,16) }, "")
                ModelSlider("Força do relaxamento", maskRelaxStrength, .01f.. .85f, { maskRelaxStrength = it })
                ModelSlider("Limite de movimento", maskMaxDisplacement, .001f.. .12f, { maskMaxDisplacement = it })
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(enabled = maskSession.paintedVertices > 0, onClick = {
                        val r = session.relaxMasked(currentMask, maskRelaxIterations, maskRelaxStrength, maskMaxDisplacement, true)
                        revision++; note(r.message)
                    }, modifier = Modifier.weight(1f)) { Text("Relaxar pela máscara") }
                    OutlinedButton(enabled = maskSession.paintedVertices > 0, onClick = {
                        val r = session.relaxMasked(currentMask, 2, .2f, maskMaxDisplacement * .5f, true)
                        revision++; note("Micro relax: ${r.message}")
                    }, modifier = Modifier.weight(1f)) { Text("Micro relax") }
                }
                ModelSlider("Limiar de pico", spikeThreshold, .5f..4f, { spikeThreshold = it })
                OutlinedButton(enabled = maskSession.paintedVertices > 0, onClick = {
                    val r = session.removeSpikesMasked(currentMask, .7f, spikeThreshold, maskMaxDisplacement, true)
                    revision++; note(r.message)
                }, modifier = Modifier.fillMaxWidth()) { Text("Remover picos / espigões") }
                Divider(color = Color.DarkGray)
                Text("MASK SCULPT PRO · DEFORMAÇÃO LOCAL", color = Color(0xFF8ED7FF), fontSize = 11.sp)
                Text("Use a máscara pintada como influência contínua: branco move mais, cinza move parcialmente e preto fica travado.", color = Muted, fontSize = 9.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        MeshMaskDeformMode.INFLATE to "Inflar",
                        MeshMaskDeformMode.DEFLATE to "Encolher",
                        MeshMaskDeformMode.PINCH to "Pinçar",
                        MeshMaskDeformMode.MOVE to "Mover",
                        MeshMaskDeformMode.FLATTEN to "Achatar",
                        MeshMaskDeformMode.SCALE to "Escalar",
                        MeshMaskDeformMode.ROTATE to "Girar"
                    ).forEach { (mode, label) ->
                        FilterChip(selected = maskDeformMode == mode, onClick = { maskDeformMode = mode }, label = { Text(label, fontSize = 9.sp) })
                    }
                }
                ModelSlider("Força da deformação", maskDeformStrength, 0f..1f, { maskDeformStrength = it })
                ModelSlider("Deslocamento máximo por vértice", maskDeformLimit, .001f.. .25f, { maskDeformLimit = it })
                if (maskDeformMode == MeshMaskDeformMode.MOVE) {
                    Text("Deslocamento local do modelo", color = Muted, fontSize = 9.sp)
                    ModelSlider("Mover X", maskDeformMoveX, -.25f.. .25f, { maskDeformMoveX = it })
                    ModelSlider("Mover Y", maskDeformMoveY, -.25f.. .25f, { maskDeformMoveY = it })
                    ModelSlider("Mover Z", maskDeformMoveZ, -.25f.. .25f, { maskDeformMoveZ = it })
                }
                if (maskDeformMode == MeshMaskDeformMode.SCALE) {
                    ModelSlider("Escala local da região", maskDeformScale, .1f..3f, { maskDeformScale = it })
                }
                if (maskDeformMode == MeshMaskDeformMode.ROTATE) {
                    Text("Rotação em torno do centroide da máscara", color = Muted, fontSize = 9.sp)
                    ModelSlider("Girar X", maskDeformRotateX, -90f..90f, { maskDeformRotateX = it })
                    ModelSlider("Girar Y", maskDeformRotateY, -90f..90f, { maskDeformRotateY = it })
                    ModelSlider("Girar Z", maskDeformRotateZ, -90f..90f, { maskDeformRotateZ = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Proteger bordas abertas", color = Color.White, fontSize = 10.sp)
                    Switch(checked = maskPreserveBoundary, onCheckedChange = { maskPreserveBoundary = it })
                }
                Button(enabled = maskSession.paintedVertices > 0, onClick = {
                    val r = session.deformMasked(currentMask, maskDeformMode, maskDeformStrength, maskDeformLimit,
                        maskDeformMoveX, maskDeformMoveY, maskDeformMoveZ, maskPreserveBoundary,
                        maskDeformScale, maskDeformRotateX, maskDeformRotateY, maskDeformRotateZ)
                    revision++; note(r.message)
                }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar deformação à máscara") }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(enabled = session.canUndo, onClick = { if (session.undo()) revision++ }, modifier = Modifier.weight(1f)) { Text("Undo geometria") }
                    OutlinedButton(enabled = session.canRedo, onClick = { if (session.redo()) revision++ }, modifier = Modifier.weight(1f)) { Text("Redo geometria") }
                }
                Text("As operações preservam vértices fora da máscara e podem proteger bordas abertas. O histórico da máscara e o da geometria são separados. A máscara é temporária à sessão; salve o modelo para gravar as alterações no PMX.", color = Muted, fontSize = 9.sp)
            }
            ModelToolsTab.WEIGHTS -> {
                Text("WEIGHT PAINT · PESOS PMX", color = Color.White, fontSize = 12.sp)
                Text("Pintura por seleção de vértices; a geometria não precisa ser modificada.", color = Muted, fontSize = 10.sp)
                Text("Osso de destino", color = Muted, fontSize = 10.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    model.bones.forEachIndexed { i, b -> FilterChip(selected = selectedBone == i, onClick = { selectedBone = i }, label = { Text(b.name.take(16), fontSize = 9.sp) }) }
                }
                ModelSlider("Peso alvo", targetWeight, 0f..1f, { targetWeight = it })
                ModelSlider("Intensidade", brushStrength, 0f..1f, { brushStrength = it })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(WeightPaintMode.REPLACE, WeightPaintMode.ADD, WeightPaintMode.SUBTRACT).forEach { mode -> FilterChip(selected = weightMode == mode, onClick = { weightMode = mode }, label = { Text(when (mode) { WeightPaintMode.REPLACE -> "Substituir"; WeightPaintMode.ADD -> "Adicionar"; else -> "Subtrair" }, fontSize = 9.sp) }) }
                }
                Button(enabled = session.selectedCount > 0 && model.bones.isNotEmpty(), onClick = {
                    val r = weightSession.paintVertices(session.selectedVertices(), selectedBone.coerceIn(0, (model.bones.size - 1).coerceAtLeast(0)), targetWeight, brushStrength, weightMode)
                    weightRevision++; note("Pesos atualizados: ${r.changed} vértices")
                }, modifier = Modifier.fillMaxWidth()) { Text("Pintar vértices selecionados") }
                Divider(color = Color.DarkGray)
                Text("PINCEL ESPACIAL · COORDENADAS LOCAIS PMX", color = Color.White, fontSize = 10.sp)
                ModelSlider("Centro X", brushX, -20f..20f, { brushX = it })
                ModelSlider("Centro Y", brushY, -20f..20f, { brushY = it })
                ModelSlider("Centro Z", brushZ, -20f..20f, { brushZ = it })
                ModelSlider("Raio", brushRadius, .02f..5f, { brushRadius = it })
                Button(enabled = model.bones.isNotEmpty(), onClick = {
                    val r = weightSession.paintSphere(brushX, brushY, brushZ, brushRadius, selectedBone.coerceIn(0, model.bones.lastIndex), targetWeight, brushStrength, weightMode)
                    weightRevision++; note("Pincel espacial: ${r.changed} vértices dentro do raio")
                }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar pincel esférico") }
                Button(enabled = model.bones.isNotEmpty(), onClick = { viewportPaintOn = !viewportPaintOn; if (viewportPaintOn) maskPaintOn = false }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (viewportPaintOn) "Encerrar pintura na viewport" else "Pintar diretamente no personagem")
                }
                Text(if (viewportPaintOn) "Pintura ativa: arraste o dedo sobre os vértices visíveis. O stroke inteiro vira uma única operação Undo; pressione Salvar no projeto ao terminar." else "O pincel espacial calcula falloff suave no espaço local. A pintura direta seleciona o vértice visível mais próximo do toque e usa o mesmo falloff local.", color = Muted, fontSize = 9.sp)
                Divider(color = Color.DarkGray)
                Text("TRANSFERÊNCIA DE PESOS ENTRE PMX", color = Color.White, fontSize = 10.sp)
                if (weightSource == null) {
                    OutlinedButton(onClick = onChooseWeightSource, modifier = Modifier.fillMaxWidth()) { Text("Escolher PMX de origem") }
                    Text("Use um PMX com rig semelhante. Os ossos são associados por nome e os vértices por proximidade espacial.", color = Muted, fontSize = 9.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Origem: ${weightSource.name.ifBlank { "PMX" }}", color = Color(0xFF8ED7FF), fontSize = 10.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = onClearWeightSource) { Text("Remover") }
                    }
                    ModelSlider("Vizinhos", transferNeighbors.toFloat(), 1f..8f, { transferNeighbors = it.roundToInt() }, "")
                    ModelSlider("Distância máx.", transferMaxDistance, 0f..5f, { transferMaxDistance = it }, if (transferMaxDistance <= 0f) " livre" else "")
                    Button(onClick = {
                        runCatching {
                            val options = WeightTransferOptions(neighbors = transferNeighbors, maxDistance = if (transferMaxDistance <= 0f) Float.POSITIVE_INFINITY else transferMaxDistance)
                            weightSession.transferFrom(weightSource, options)
                        }.onSuccess { r ->
                            weightRevision++
                            note("Pesos transferidos: ${r.transferredVertices} vértices · ${r.fallbackVertices} fallback · ${r.unmatchedSourceBones.size} ossos sem correspondência · distância média ${"%.4f".format(r.averageMatchDistance)}")
                        }.onFailure { note("Falha na transferência de pesos: ${it.message ?: it.javaClass.simpleName}") }
                    }, modifier = Modifier.fillMaxWidth(), enabled = weightSource.bones.isNotEmpty() && model.bones.isNotEmpty()) { Text("Transferir pesos para este modelo") }
                    Text("A transferência preserva geometria, materiais, morphs e física do destino. Exige escala e orientação espacial compatíveis; confira o resultado antes de salvar.", color = Muted, fontSize = 9.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { val r = weightSession.normalizeAll(); weightRevision++; note("${r.changed} vértices normalizados") }, modifier = Modifier.weight(1f)) { Text("Normalizar tudo") }
                    OutlinedButton(onClick = { val r = weightSession.prune(.01f, 4); weightRevision++; note("${r.removedInfluences} influências removidas") }, modifier = Modifier.weight(1f)) { Text("Limpar pesos") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { val r = weightSession.smooth(3, .45f); weightRevision++; note("Pesos suavizados em ${r.changed} vértices") }, modifier = Modifier.weight(1f)) { Text("Suavizar tudo") }
                    OutlinedButton(onClick = { val r = weightSession.mirrorX(.002f, true); weightRevision++; note("Pesos espelhados em ${r.changed} vértices") }, modifier = Modifier.weight(1f)) { Text("Espelhar X") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(enabled = weightSession.canUndo, onClick = { weightSession.undo(); weightRevision++ }, modifier = Modifier.weight(1f)) { Text("Desfazer pesos") }
                    OutlinedButton(enabled = weightSession.canRedo, onClick = { weightSession.redo(); weightRevision++ }, modifier = Modifier.weight(1f)) { Text("Refazer pesos") }
                }
                Text("Operações aplicadas: $weightRevision · vértices selecionados: ${session.selectedCount}", color = Muted, fontSize = 9.sp)
            }
            ModelToolsTab.UV -> {
                Text("UV STUDIO · COSTURAS E ILHAS", color = Color.White, fontSize = 12.sp)
                Text("O unwrap LSCM separa charts pelas costuras, calcula coordenadas conformais por ilha e duplica vértices PMX quando um vértice pertence a ilhas diferentes. O packing reserva uma célula independente por ilha.", color = Muted, fontSize = 10.sp)
                ModelSlider("Ângulo de costura", uvSeamAngle, 5f..175f, { uvSeamAngle = it }, "°")
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick = {
                        uvSeams = uvSeams + SeamAwareUvUnwrapper.seamsByAngle(model, uvSeamAngle)
                        note("Costuras por ângulo: ${uvSeams.size} arestas no total")
                    }, modifier = Modifier.weight(1f)) { Text("Costuras por ângulo") }
                    OutlinedButton(onClick = {
                        uvSeams = uvSeams + SeamAwareUvUnwrapper.seamsAtMaterialBorders(model)
                        note("Costuras por material: ${uvSeams.size} arestas no total")
                    }, modifier = Modifier.weight(1f)) { Text("Por material") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick = { uvSeams = emptySet(); note("Costuras limpas") }, modifier = Modifier.weight(1f)) { Text("Limpar costuras") }
                    Text("${uvSeams.size} arestas marcadas", color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterVertically).weight(1f))
                }
                Button(enabled = !uvBusy && model.indices.size >= 3, onClick = {
                    panelScope.launch {
                        uvBusy = true
                        try {
                            val result = withContext(Dispatchers.Default) { SeamAwareUvUnwrapper.unwrap(model, uvSeams, .025f) }
                            if (result.aborted) note(result.warnings.firstOrNull() ?: "Unwrap cancelado por segurança")
                            else {
                                onApply(result.model)
                                note("UV LSCM concluído: ${result.islandCount} ilhas · ${result.splitVertices} vértices duplicados · ${result.solverFallbacks} fallbacks${if (result.warnings.isNotEmpty()) " · ${result.warnings.size} aviso(s)" else ""}")
                            }
                        } catch (e: Exception) {
                            note("Falha no unwrap UV: ${e.message ?: e.javaClass.simpleName}")
                        } finally { uvBusy = false }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (uvBusy) "Calculando ilhas…" else "Unwrap LSCM + empacotar ilhas") }
                Divider(color = Color.DarkGray)
                Text("Projeções e ajustes rápidos", color = Color.White, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("XZ", "XY", "ZY").forEachIndexed { i, label -> FilterChip(selected = uvAxis == i, onClick = { uvAxis = i }, label = { Text(label, fontSize = 10.sp) }) }
                }
                Button(onClick = { val r = session.planarUv(uvAxis); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Projeção planar") }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { val r = session.cylindricalUv(); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Cilíndrica") }
                    OutlinedButton(onClick = { val r = session.sphericalUv(); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Esférica") }
                }
                OutlinedButton(enabled = session.selectedCount > 0, onClick = { val r = session.normalizeSelectedUv(); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Normalizar UV da seleção") }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(enabled = session.selectedCount >= 3, onClick = { val r = session.relaxSelectedUv(8, .35f); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Relaxar ilha") }
                    OutlinedButton(enabled = model.materials.isNotEmpty(), onClick = { val r = session.materialAtlas(); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Atlas material") }
                }
                Text("O atlas por material continua disponível como método rápido. Para criar ilhas, costuras e vértices independentes, use o unwrap LSCM acima.", color = Muted, fontSize = 9.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { val r = session.flipUv(true); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Espelhar U") }
                    OutlinedButton(onClick = { val r = session.flipUv(false); revision++; note(r.message) }, modifier = Modifier.weight(1f)) { Text("Espelhar V") }
                }
                ModelSlider("Escala U", uvScaleU, .1f..8f, { uvScaleU = it })
                ModelSlider("Escala V", uvScaleV, .1f..8f, { uvScaleV = it })
                ModelSlider("Deslocar U", uvOffsetU, -2f..2f, { uvOffsetU = it })
                ModelSlider("Deslocar V", uvOffsetV, -2f..2f, { uvOffsetV = it })
                Button(onClick = { val r = session.transformUv(uvScaleU, uvScaleV, uvOffsetU, uvOffsetV); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar transformação UV") }
            }
            ModelToolsTab.MATERIAL -> {
                Text("MATERIAL STUDIO · PMX", color = Color.White, fontSize = 12.sp)
                if (session.materialCount == 0) Text("Este modelo não possui materiais.", color = Muted, fontSize = 11.sp)
                else {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        session.materials().forEachIndexed { i, m ->
                            FilterChip(selected = materialIndex == i, onClick = { materialIndex = i }, label = { Text(m.name.ifBlank { "Material ${i + 1}" }.take(12), fontSize = 9.sp) })
                        }
                    }
                    Text(material?.name ?: "Material", color = Color.White, fontSize = 11.sp)
                    Text("Textura base", color = Muted, fontSize = 10.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(selected = baseTexture == -1, onClick = { baseTexture = -1 }, label = { Text("Nenhuma", fontSize = 9.sp) })
                        model.textures.forEachIndexed { i, name -> FilterChip(selected = baseTexture == i, onClick = { baseTexture = i }, label = { Text("${i + 1}: ${name.substringAfterLast('/').take(12)}", fontSize = 9.sp) }) }
                    }
                    Text("Textura de esfera", color = Muted, fontSize = 10.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(selected = sphereTexture == -1, onClick = { sphereTexture = -1 }, label = { Text("Nenhuma", fontSize = 9.sp) })
                        model.textures.forEachIndexed { i, name -> FilterChip(selected = sphereTexture == i, onClick = { sphereTexture = i }, label = { Text("${i + 1}: ${name.substringAfterLast('/').take(12)}", fontSize = 9.sp) }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Desligado", "Multiplicar", "Adicionar", "Subtração").forEachIndexed { i, label -> FilterChip(selected = sphereMode == i, onClick = { sphereMode = i }, label = { Text(label, fontSize = 9.sp) }) }
                    }
                    OutlinedButton(onClick = { val r = session.setMaterialTextures(materialIndex, baseTexture, sphereTexture, sphereMode); revision++; note(r.message) }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar slots de textura") }
                    Text("Cor difusa", color = Muted, fontSize = 10.sp)
                    val channels = listOf("R", "G", "B", "A")
                    val diffuseValues = ensureChannels(diffuse, 4, 1f)
                    channels.forEachIndexed { i, ch -> ModelSlider(ch, diffuseValues[i], 0f..1f, { v -> diffuse = diffuseValues.copyOf().also { it[i] = v } }) }
                    Text("Especular", color = Muted, fontSize = 10.sp)
                    listOf("R", "G", "B").forEachIndexed { i, ch -> ModelSlider("S$ch", specular.getOrElse(i) { 0f }, 0f..1f, { v -> specular = ensureChannels(specular, 3, 0f).also { it[i] = v } }) }
                    Text("Ambiente", color = Muted, fontSize = 10.sp)
                    listOf("R", "G", "B").forEachIndexed { i, ch -> ModelSlider("A$ch", ambient.getOrElse(i) { 0f }, 0f..1f, { v -> ambient = ensureChannels(ambient, 3, 0f).also { it[i] = v } }) }
                    ModelSlider("Brilho especular", specPower, 0f..128f, { specPower = it })
                    ModelSlider("Espessura do contorno", edgeSize, 0f..8f, { edgeSize = it })
                    Text("Cor do contorno", color = Muted, fontSize = 10.sp)
                    val edgeValues = ensureChannels(edge, 4, 1f)
                    listOf("E-R", "E-G", "E-B", "E-A").forEachIndexed { i, ch -> ModelSlider(ch, edgeValues[i], 0f..1f, { v -> edge = edgeValues.copyOf().also { it[i] = v } }) }
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Duas faces", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f)); Switch(doubleSided, { doubleSided = it }) }
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Contorno PMX", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f)); Switch(edgeEnabled, { edgeEnabled = it }) }
                    Button(onClick = {
                        val old = session.material(materialIndex) ?: return@Button
                        var flags = old.flags
                        flags = if (doubleSided) flags or 1 else flags and 1.inv()
                        flags = if (edgeEnabled) flags or 0x10 else flags and 0x10.inv()
                        val updated = copyPmxMaterial(old, ensureChannels(diffuse, 4, 1f), ensureChannels(specular, 3, 0f), specPower, ensureChannels(ambient, 3, 0f), flags, ensureChannels(edge, 4, 1f), edgeSize)
                        val r = session.updateMaterial(materialIndex, updated); revision++; note(r.message)
                    }, modifier = Modifier.fillMaxWidth()) { Text("Aplicar propriedades do material") }
                }
            }
            ModelToolsTab.SHADER -> {
                Text("SHADER GRAPH · MATERIAL NODES", color = Color.White, fontSize = 12.sp)
                Text("Monte um pequeno grafo de superfície com nós de cor, valor, mistura e Principled. O compilador valida conexões/ciclos e converte a saída para propriedades PMX compatíveis.", color = Muted, fontSize = 10.sp)
                if (session.materialCount == 0) {
                    Text("Este modelo não possui materiais para receber o shader.", color = Muted, fontSize = 11.sp)
                } else {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        session.materials().forEachIndexed { i, m ->
                            FilterChip(selected = materialIndex == i, onClick = { materialIndex = i }, label = { Text(m.name.ifBlank { "Material ${i + 1}" }.take(12), fontSize = 9.sp) })
                        }
                    }
                    val visibleShaderNodes = buildList {
                        add("Color / Base Color")
                        if (shaderMixEnabled) { add("Value / Mix Factor"); add("Mix Color") }
                        if (shaderMultiplyEnabled) add("Multiply Color")
                        add("Value / Metallic"); add("Value / Roughness"); add("Principled BSDF"); add("Material Output")
                    }
                    Text("Grafo ativo · ${visibleShaderNodes.size} nós", color = Color.White, fontSize = 11.sp)
                    visibleShaderNodes.forEachIndexed { index, node ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Color(0xFF24272D), RoundedCornerShape(5.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Color(0xFF8ED7FF), fontSize = 10.sp, modifier = Modifier.width(20.dp))
                            Text(node, color = Color.White, fontSize = 10.sp)
                        }
                    }
                    ModelSlider("Metallic", shaderMetallic, 0f..1f, { shaderMetallic = it })
                    ModelSlider("Roughness", shaderRoughness, .04f..1f, { shaderRoughness = it })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Inserir Mix Color", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        Switch(checked = shaderMixEnabled, onCheckedChange = { shaderMixEnabled = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Inserir Multiply Color", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        Switch(checked = shaderMultiplyEnabled, onCheckedChange = { shaderMultiplyEnabled = it })
                    }
                    if (shaderMixEnabled || shaderMultiplyEnabled) {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(selected = shaderTintStyle == 0, onClick = { shaderTintStyle = 0 }, label = { Text("Quente", fontSize = 9.sp) })
                            FilterChip(selected = shaderTintStyle == 1, onClick = { shaderTintStyle = 1 }, label = { Text("Frio", fontSize = 9.sp) })
                            FilterChip(selected = shaderTintStyle == 2, onClick = { shaderTintStyle = 2 }, label = { Text("Dourado", fontSize = 9.sp) })
                        }
                        ModelSlider("Blend", shaderMixAmount, 0f..1f, { shaderMixAmount = it })
                    }
                    Button(onClick = {
                        val base = session.material(materialIndex) ?: return@Button
                        runCatching {
                            val basic = ShaderGraphCompiler.basic(base)
                            val nodes = basic.nodes.map { node ->
                                when (node.id) {
                                    "metallic" -> node.copy(value = shaderMetallic)
                                    "roughness" -> node.copy(value = shaderRoughness)
                                    else -> node
                                }
                            }.toMutableList()
                            val links = basic.links.toMutableList()
                            if (shaderMixEnabled || shaderMultiplyEnabled) {
                                val tint = when (shaderTintStyle) {
                                    1 -> floatArrayOf(.16f, .42f, .95f, 1f)
                                    2 -> floatArrayOf(.95f, .62f, .12f, 1f)
                                    else -> floatArrayOf(.95f, .28f, .12f, 1f)
                                }
                                nodes += MaterialGraphNode("tint-color", MaterialNodeKind.COLOR, tint)
                                var colorOutput = "base-color"
                                if (shaderMixEnabled) {
                                    nodes += MaterialGraphNode("mix-factor", MaterialNodeKind.VALUE, value = shaderMixAmount)
                                    nodes += MaterialGraphNode("mix-base", MaterialNodeKind.MIX)
                                    links.removeAll { it.toNode == "principled" && it.input == "baseColor" }
                                    links += MaterialGraphLink(colorOutput, "mix-base", "a")
                                    links += MaterialGraphLink("tint-color", "mix-base", "b")
                                    links += MaterialGraphLink("mix-factor", "mix-base", "factor")
                                    colorOutput = "mix-base"
                                }
                                if (shaderMultiplyEnabled) {
                                    nodes += MaterialGraphNode("multiply-base", MaterialNodeKind.MULTIPLY)
                                    links.removeAll { it.toNode == "principled" && it.input == "baseColor" }
                                    links += MaterialGraphLink(colorOutput, "multiply-base", "a")
                                    links += MaterialGraphLink("tint-color", "multiply-base", "b")
                                    colorOutput = "multiply-base"
                                }
                                links += MaterialGraphLink(colorOutput, "principled", "baseColor")
                            }
                            ShaderGraphCompiler.compile(MaterialGraph(nodes, links), base)
                        }.onSuccess { compiled ->
                            val r = session.updateMaterial(materialIndex, compiled.material)
                            revision++
                            note("Shader Graph compilado para PMX · ${compiled.evaluatedNodes} nós avaliados${if (compiled.warnings.isNotEmpty()) " · ${compiled.warnings.size} observações" else ""} · ${r.message}")
                        }.onFailure { note("Falha ao compilar Shader Graph: ${it.message ?: it.javaClass.simpleName}") }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Compilar e aplicar ao material PMX") }
                    Text("Limite atual: o grafo é compilado em diffuse/specular/ambient/specularPower PMX. A estrutura de nós, texturas procedurais, normal maps, emissive e shaders GPU arbitrários ainda não são serializados no arquivo PMX.", color = Muted, fontSize = 9.sp)
                }
            }
            ModelToolsTab.CHECK -> {
                val inspectedModel = remember(model, revision) { session.buildModel() }
                val report = remember(inspectedModel) { ModelDiagnostics.inspect(inspectedModel) }
                val topology = remember(inspectedModel) { MeshTopologyAnalyzer.inspect(inspectedModel) }
                val pmxAudit = remember(inspectedModel) { PmxModelDoctor.inspect(inspectedModel) }
                val weightAudit = remember(inspectedModel) { PmxWeightDoctor.inspect(inspectedModel) }
                Text("DIAGNÓSTICO DA MALHA", color = Color.White, fontSize = 12.sp)
                Text("${report.vertices} vértices · ${report.triangles} triângulos · ${report.materials} materiais", color = Muted, fontSize = 10.sp)
                DiagnosticLine("Índices inválidos", report.invalidIndices)
                DiagnosticLine("Triângulos degenerados", report.degenerateTriangles)
                DiagnosticLine("Normais inválidas", report.invalidNormals)
                DiagnosticLine("UV fora de 0..1", report.uvOutsideUnit)
                DiagnosticLine("Pesos inconsistentes", report.invalidWeights)
                DiagnosticLine("Posições não finitas", report.nonFinitePositions)
                DiagnosticLine("Índices por material", if (report.materialIndexMismatch) 1 else 0)
                Divider(color = Color.DarkGray)
                Text("TOPOLOGIA E UV", color = Color.White, fontSize = 10.sp)
                DiagnosticLine("Arestas de borda aberta", topology.boundaryEdges)
                DiagnosticLine("Arestas não-manifold", topology.nonManifoldEdges)
                DiagnosticLine("Orientação inconsistente", topology.inconsistentWindingEdges)
                DiagnosticLine("Componentes conectados", topology.connectedComponents)
                DiagnosticLine("Vértices isolados", topology.isolatedVertices)
                DiagnosticLine("Grupos de posições duplicadas", topology.duplicatePositionGroups)
                DiagnosticLine("Vértices duplicados", topology.duplicateVertices)
                DiagnosticLine("Triângulos com área UV zero", topology.zeroAreaUvTriangles)
                DiagnosticLine("Registros de triângulos inválidos", topology.invalidTriangleRecords)
                report.issues.forEach { Text("• $it", color = if (report.hasErrors) Color(0xFFFFC36A) else Color(0xFF83D99A), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp)) }
                Divider(color = Color.DarkGray)
                Text("PMX MODEL DOCTOR · INTEGRIDADE DO ARQUIVO", color = Color.White, fontSize = 10.sp)
                Text(pmxAudit.summary, color = if (pmxAudit.healthy) Color(0xFF83D99A) else Color(0xFFFFC36A), fontSize = 10.sp)
                Text("Ossos ${pmxAudit.boneCount} · morphs ${pmxAudit.morphCount} · rigid bodies ${pmxAudit.rigidBodyCount} · juntas ${pmxAudit.jointCount}", color = Muted, fontSize = 9.sp)
                pmxAudit.issues.take(12).forEach { item ->
                    val tint = when (item.severity) { PmxIssueSeverity.ERROR -> Color(0xFFFF7777); PmxIssueSeverity.WARNING -> Color(0xFFFFC36A); PmxIssueSeverity.INFO -> Muted }
                    Text("${item.severity.name}: ${item.message}", color = tint, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Divider(color = Color.DarkGray)
                Text("PHYSICS DOCTOR · PMX 2.0 / 2.1", color = Color.White, fontSize = 10.sp)
                val physicsAudit = remember(inspectedModel) { PmxPhysicsDoctor.inspect(inspectedModel) }
                Text(physicsAudit.summary, color = if (physicsAudit.healthy) Color(0xFF83D99A) else Color(0xFFFFC36A), fontSize = 10.sp)
                physicsAudit.issues.take(16).forEach { item ->
                    val tint = if (item.severity == studio.mmd.mmd.PmxPhysicsSeverity.ERROR) Color(0xFFFF7777) else Color(0xFFFFC36A)
                    Text("${item.severity.name}: ${item.message}", color = tint, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                }
                OutlinedButton(onClick = {
                    runCatching { PmxPhysicsDoctor.repair(inspectedModel) }
                        .onSuccess { result -> onApply(result.model); note("Physics Doctor: ${result.repairedRigidBodies} corpos rígidos e ${result.repairedJoints} juntas corrigidos · ${result.removedJoints} juntas órfãs removidas · soft bodies preservados") }
                        .onFailure { note("Physics Doctor cancelado: ${it.message ?: it.javaClass.simpleName}") }
                }, modifier = Modifier.fillMaxWidth()) { Text("Reparar parâmetros físicos seguros") }
                Text("A auditoria interpreta soft bodies PMX 2.1 e valida anchors/pins; isso não ativa uma simulação Bullet de soft body.", color = Muted, fontSize = 9.sp)
                Divider(color = Color.DarkGray)
                Text("MORPH DOCTOR · PMX 0–10", color = Color.White, fontSize = 10.sp)
                val morphAudit = remember(inspectedModel) { PmxMorphDoctor.inspect(inspectedModel) }
                Text(morphAudit.summary, color = if (morphAudit.healthy) Color(0xFF83D99A) else Color(0xFFFFC36A), fontSize = 10.sp)
                Text("Total ${morphAudit.totalMorphs} · folhas ${morphAudit.leafMorphs} · grupos ${morphAudit.groupMorphs} · flips ${morphAudit.flipMorphs} · registros de impulso ${morphAudit.impulseRecords}", color = Muted, fontSize = 9.sp)
                morphAudit.issues.take(20).forEach { item ->
                    val tint = when (item.severity) { PmxIssueSeverity.ERROR -> Color(0xFFFF7777); PmxIssueSeverity.WARNING -> Color(0xFFFFC36A); PmxIssueSeverity.INFO -> Muted }
                    Text("${item.severity.name}: ${item.message}", color = tint, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Divider(color = Color.DarkGray)
                Text("WEIGHT DOCTOR · SKINNING", color = Color.White, fontSize = 10.sp)
                Text("Com peso ${weightAudit.weightedVertices} · sem peso ${weightAudit.unweightedVertices} · refs ósseas inválidas ${weightAudit.invalidBoneReferences} · pesos inválidos ${weightAudit.invalidWeights} · soma divergente ${weightAudit.sumMismatch} · influência duplicada ${weightAudit.duplicateInfluences}", color = Muted, fontSize = 9.sp)
                OutlinedButton(
                    onClick = {
                        runCatching { PmxWeightDoctor.repair(inspectedModel) }
                            .onSuccess { result ->
                                onApply(result.model)
                                note("Weight Doctor: ${result.repairedVertices} vértices corrigidos · ${result.removedInfluences} influências removidas · ${result.leftUnweighted} ainda sem peso (sem inventar um osso fallback)")
                            }
                            .onFailure { note("Weight Doctor cancelado: ${it.message ?: it.javaClass.simpleName}") }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Reparar pesos inválidos e normalizar influências") }
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(enabled = session.canUndo, onClick = { session.undo(); revision++ }, modifier = Modifier.weight(1f)) { Text("Desfazer") }
            OutlinedButton(enabled = session.canRedo, onClick = { session.redo(); revision++ }, modifier = Modifier.weight(1f)) { Text("Refazer") }
            Button(onClick = {
                val base = session.buildModel(); val w = weightSession.buildModel()
                val merged = PmxModel(base.name, base.version, base.positions, base.normals, base.uvs,
                    w.boneIndices, w.boneWeights, base.indices, base.textures, base.materials, base.bones, base.morphs,
                    base.rigidBodies, base.joints, base.nameEn, base.comment, base.commentEn, base.displayFrames,
                    base.addUvCount, base.addUvs, w.weightTypes, base.sdef, base.edgeScale, base.textEncoding,
                    base.indexSizes, base.softBodyCount, base.softBodyRaw, base.warnings)
                onApply(merged)
            }, modifier = Modifier.weight(1.3f)) { Text("Salvar no projeto") }
        }
    }
}

@Composable
private fun ModelSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, suffix: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 10.sp, modifier = Modifier.width(82.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text("${((value * 100).roundToInt() / 100f)}$suffix", color = Color.White, fontSize = 9.sp, modifier = Modifier.width(42.dp))
    }
}

@Composable
private fun DiagnosticLine(label: String, count: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(count.toString(), color = if (count == 0) Color(0xFF83D99A) else Color(0xFFFFC36A), fontSize = 10.sp)
    }
}

private fun ensureChannels(values: FloatArray, size: Int, fallback: Float): FloatArray = FloatArray(size) { values.getOrElse(it) { fallback } }
