package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.mmd.PmxModel
import studio.mmd.rig.SkirtGuardAuto
import studio.mmd.rig.SkirtCorrectionRegion
import kotlin.math.roundToInt

data class ClothBakeSettings(
    val firstVertex: Int = 0,
    val lastVertex: Int = 0,
    /** Frame inicial do trecho a assar; quadros fora do intervalo são preservados do cache compatível. */
    val startFrame: Int = 0,
    val frames: Int = 90,
    val gravityY: Float = -9.81f,
    val windX: Float = 0f,
    val windY: Float = 0f,
    val windZ: Float = 0f,
    val substeps: Int = 4,
    val iterations: Int = 8,
    val selfCollision: Boolean = false,
    /** -3 saia auto, -2 influência de osso, -1 intervalo, >=0 material PMX. */
    val materialIndex: Int = -1,
    val boneIndex: Int = 0,
    val boneThreshold: Float = 0.05f,
    val surfaceCollision: Boolean = true,
    val followCharacterAnimation: Boolean = true,
    val boxCollision: Boolean = true,
    val collisionThickness: Float = 0.025f,
    /** Proteção automática de saia: gera cápsulas cinemáticas presas às pernas/quadril. */
    val skirtGuardEnabled: Boolean = true,
    val skirtGuardMargin: Float = 0.018f,
    /** Pós-correção limitada após o XPBD, sem modificar o PMX original. */
    val skirtGuardAutoFix: Boolean = true,
    val skirtGuardMaxCorrection: Float = 0.025f,
    /** Desenha os volumes anatômicos em tempo de playback no viewport. */
    val skirtGuardLiveOverlay: Boolean = false,
    /** Simulação XPBD reduzida da saia durante playback (somente preview, não export). */
    val skirtGuardLiveSimulation: Boolean = false,
    /** Colisão do preview com triângulos reais da superfície corporal deformada. */
    val skirtGuardBodySurfaceCollision: Boolean = true,
    /** Fração superior da saia usada como fallback de âncora quando não há pesos de cintura. */
    val skirtGuardAnchorBand: Float = 0.045f,
    /** Iterações físicas do preview por passo fixo. */
    val skirtGuardPlaybackIterations: Int = 5,
    /** Região angular onde o Auto-Fix tem influência; o falloff evita bordas duras. */
    val skirtGuardCorrectionRegion: SkirtCorrectionRegion = SkirtCorrectionRegion.ALL
)

@Composable
fun ClothPanel(
    model: PmxModel,
    settings: ClothBakeSettings,
    busy: Boolean,
    progress: Float,
    cachedFrames: Int,
    onSettings: (ClothBakeSettings) -> Unit,
    onBake: () -> Unit,
    onCancel: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier,
    analysisText: String? = null,
    onAnalyze: () -> Unit = {},
    onClearAnalysis: () -> Unit = {},
    canUndoCorrection: Boolean = false,
    canRedoCorrection: Boolean = false,
    correctionHistoryText: String? = null,
    onUndoCorrection: () -> Unit = {},
    onRedoCorrection: () -> Unit = {}
) {
    val maxVertex = (model.vertexCount - 1).coerceAtLeast(0)
    val skirtProfile = SkirtGuardAuto.profile(model)
    val first = settings.firstVertex.coerceIn(0, maxVertex)
    val last = settings.lastVertex.coerceIn(0, maxVertex)
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("CLOTH STUDIO · XPBD", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("${model.vertexCount} vértices", color = Muted, fontSize = 10.sp)
        }
        Text("Simulação CPU XPBD por quadro. Selecione a roupa por material, intervalo ou influência óssea; o restante fica ancorado. Com superfície corporal e seguimento animado ativos, o bake atualiza skinning/morphs e colisão triangular a cada quadro, usando a pose anterior para preservar a inércia e gravando o cache no espaço local pré-skinning.", color = Muted, fontSize = 10.sp)
        if (skirtProfile.detected) {
            Text("SKIRT GUARD AUTO · ${(skirtProfile.confidence * 100f).toInt()}% de confiança · ${skirtProfile.regions.size} região(ões) · ${skirtProfile.skirtVertexCount} vértices · ${skirtProfile.colliderHints.size} hints anatômicos", color = Color(0xFF9FE6B0), fontSize = 10.sp)
            Text("A detecção é executada no carregamento do PMX. O bake transforma os colisores de quadril/coxa/panturrilha junto com a pose e projeta a roupa para fora das cápsulas durante as iterações do solver.", color = Muted, fontSize = 9.sp)
        } else {
            Text("SKIRT GUARD AUTO · nenhuma saia reconhecida. Verifique nomes dos materiais e pesos do modelo.", color = Muted, fontSize = 9.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (skirtProfile.detected) FilterChip(selected = settings.materialIndex == -3, onClick = { onSettings(settings.copy(materialIndex = -3)) }, label = { Text("Saia detectada", fontSize = 9.sp) })
            FilterChip(selected = settings.materialIndex == -1, onClick = { onSettings(settings.copy(materialIndex = -1)) }, label = { Text("Intervalo", fontSize = 9.sp) })
            FilterChip(selected = settings.materialIndex == -2, onClick = { onSettings(settings.copy(materialIndex = -2)) }, label = { Text("Por osso", fontSize = 9.sp) })
            model.materials.forEachIndexed { index, material ->
                FilterChip(selected = settings.materialIndex == index, onClick = { onSettings(settings.copy(materialIndex = index)) }, label = { Text(material.name.ifBlank { "Material ${index + 1}" }, fontSize = 9.sp) })
            }
        }
        if (settings.materialIndex == -3) {
            Text("Seleção automática: ${skirtProfile.regions.joinToString { it.materialName }} · ${skirtProfile.skirtVertexCount} vértices de saia", color = Muted, fontSize = 9.sp)
        } else if (settings.materialIndex == -1) {
            ClothSlider("Primeiro vértice", first.toFloat(), 0f..maxVertex.toFloat(), { onSettings(settings.copy(firstVertex = it.roundToInt().coerceIn(0, maxVertex))) }, "")
            ClothSlider("Último vértice", last.toFloat(), 0f..maxVertex.toFloat(), { onSettings(settings.copy(lastVertex = it.roundToInt().coerceIn(0, maxVertex))) }, "")
            OutlinedButton(onClick = { onSettings(settings.copy(firstVertex = 0, lastVertex = maxVertex)) }, modifier = Modifier.fillMaxWidth()) { Text("Incluir todos os vértices") }
        } else if (settings.materialIndex == -2) {
            Text("Osso de referência", color = Muted, fontSize = 9.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                model.bones.forEachIndexed { index, bone ->
                    FilterChip(selected = settings.boneIndex == index, onClick = { onSettings(settings.copy(boneIndex = index)) }, label = { Text(bone.name.take(14), fontSize = 9.sp) })
                }
            }
            ClothSlider("Peso mínimo", settings.boneThreshold, 0.01f..1f, { onSettings(settings.copy(boneThreshold = it)) })
            Text("Vértices com influência igual ou superior ao limite serão simulados; os demais serão âncoras.", color = Muted, fontSize = 9.sp)
        } else {
            Text("Região por material: ${model.materials.getOrNull(settings.materialIndex)?.name ?: "inválido"} · vértices extraídos dos triângulos desse material.", color = Muted, fontSize = 9.sp)
        }
        ClothSlider("Quadro inicial", settings.startFrame.toFloat(), 0f..2400f, { onSettings(settings.copy(startFrame = it.roundToInt().coerceIn(0, 2400))) }, "")
        ClothSlider("Quadros do trecho", settings.frames.toFloat(), 1f..240f, { onSettings(settings.copy(frames = it.roundToInt().coerceIn(1, 240))) }, "")
        Text("Bake parcial aquece a simulação desde o quadro 0 e substitui somente o intervalo solicitado. Os quadros fora do trecho são preservados somente quando modelo, topologia, VMD e parâmetros físicos possuem a mesma assinatura. Se qualquer um deles mudar, faça um bake completo antes de continuar com intervalos parciais.", color = Color(0xFFFFC66D), fontSize = 9.sp)
        ClothSlider("Gravidade Y", settings.gravityY, -25f..5f, { onSettings(settings.copy(gravityY = it)) })
        ClothSlider("Vento X", settings.windX, -12f..12f, { onSettings(settings.copy(windX = it)) })
        ClothSlider("Vento Y", settings.windY, -12f..12f, { onSettings(settings.copy(windY = it)) })
        ClothSlider("Vento Z", settings.windZ, -12f..12f, { onSettings(settings.copy(windZ = it)) })
        ClothSlider("Subpassos", settings.substeps.toFloat(), 1f..12f, { onSettings(settings.copy(substeps = it.roundToInt().coerceIn(1, 12))) }, "")
        ClothSlider("Iterações", settings.iterations.toFloat(), 1f..24f, { onSettings(settings.copy(iterations = it.roundToInt().coerceIn(1, 24))) }, "")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Auto-colisão (até 2.048 vértices)", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.selfCollision, onCheckedChange = { onSettings(settings.copy(selfCollision = it)) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Colisão com superfície do corpo", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.surfaceCollision, onCheckedChange = { onSettings(settings.copy(surfaceCollision = it)) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Seguir animação, IK e morphs", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.followCharacterAnimation, onCheckedChange = { onSettings(settings.copy(followCharacterAnimation = it)) })
        }
        Text("No modo animado, a superfície da malha e colisores PMX ligados a ossos são atualizados por quadro. Corpos PMX dinâmicos (modos 1/2) não são re-simulados pelo bake de tecido; desligar colisão de superfície ou seguimento retorna ao modo local estático.", color = Muted, fontSize = 9.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Colisores caixa PMX", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.boxCollision, onCheckedChange = { onSettings(settings.copy(boxCollision = it)) })
        }
        ClothSlider("Espessura colisão", settings.collisionThickness, 0.005f..0.12f, { onSettings(settings.copy(collisionThickness = it)) })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Skirt Guard · colisão automática pernas/saia", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.skirtGuardEnabled, onCheckedChange = { onSettings(settings.copy(skirtGuardEnabled = it)) }, enabled = skirtProfile.detected)
        }
        if (settings.skirtGuardEnabled && skirtProfile.detected) {
            ClothSlider("Margem saia/perna", settings.skirtGuardMargin, 0f..0.08f, { onSettings(settings.copy(skirtGuardMargin = it)) })
            Text("Auto-connect cria cápsulas cinemáticas de quadril, coxas e panturrilhas. Colisores PMX cinemáticos já existentes não são duplicados. Os pesos e vértices originais permanecem intactos.", color = Muted, fontSize = 9.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Overlay ao vivo no playback", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Switch(checked = settings.skirtGuardLiveOverlay, onCheckedChange = { onSettings(settings.copy(skirtGuardLiveOverlay = it)) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Simular saia durante playback (preview CPU)", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Switch(checked = settings.skirtGuardLiveSimulation, onCheckedChange = { onSettings(settings.copy(skirtGuardLiveSimulation = it)) })
            }
            if (settings.skirtGuardLiveSimulation) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Colisão com superfície real do corpo", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                    Switch(checked = settings.skirtGuardBodySurfaceCollision, onCheckedChange = { onSettings(settings.copy(skirtGuardBodySurfaceCollision = it)) })
                }
                ClothSlider("Faixa de âncora da cintura", settings.skirtGuardAnchorBand, 0.01f..0.18f, { onSettings(settings.copy(skirtGuardAnchorBand = it)) })
                ClothSlider("Qualidade do preview", settings.skirtGuardPlaybackIterations.toFloat(), 2f..8f, { onSettings(settings.copy(skirtGuardPlaybackIterations = it.roundToInt().coerceIn(2, 8))) }, " it")
                Text("A superfície corporal usa até 1.800 triângulos próximos da saia, atualizados por skinning/morphs a cada passo. O solver usa passo fixo de 1/60 s e até 6 passos de recuperação por frame.", color = Muted, fontSize = 9.sp)
            }
            Text("Preview CPU limitado a 4.500 vértices da saia. Para render/export final, use Gerar bake XPBD. Desative em aparelhos com queda de FPS.", color = Muted, fontSize = 9.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto-Fix limitado no bake", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Switch(checked = settings.skirtGuardAutoFix, onCheckedChange = { onSettings(settings.copy(skirtGuardAutoFix = it)) })
            }
            if (settings.skirtGuardAutoFix) {
                ClothSlider("Limite Auto-Fix", settings.skirtGuardMaxCorrection, 0.002f..0.08f, { onSettings(settings.copy(skirtGuardMaxCorrection = it)) })
                Text("Região de correção (eixos locais PMX)", color = Muted, fontSize = 9.sp)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        SkirtCorrectionRegion.ALL to "Toda",
                        SkirtCorrectionRegion.FRONT to "Frente +Z",
                        SkirtCorrectionRegion.BACK to "Trás -Z",
                        SkirtCorrectionRegion.LEFT to "Esquerda -X",
                        SkirtCorrectionRegion.RIGHT to "Direita +X"
                    ).forEach { (region, label) ->
                        FilterChip(selected = settings.skirtGuardCorrectionRegion == region,
                            onClick = { onSettings(settings.copy(skirtGuardCorrectionRegion = region)) },
                            label = { Text(label, fontSize = 9.sp) })
                    }
                }
                Text("A região escolhida recebe o ajuste completo; áreas vizinhas recebem influência gradual. Toda continua sendo a opção neutra.", color = Muted, fontSize = 9.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(onClick = onAnalyze, modifier = Modifier.weight(1f)) { Text("Analisar pose atual") }
                OutlinedButton(onClick = onClearAnalysis, modifier = Modifier.weight(1f)) { Text("Limpar diagnóstico") }
            }
            if (!analysisText.isNullOrBlank()) Text(analysisText, color = Color(0xFFFFC66D), fontSize = 9.sp)

        }
        if (correctionHistoryText != null) {
            Text(correctionHistoryText, color = Color(0xFF9FE6B0), fontSize = 9.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(enabled = !busy && canUndoCorrection, onClick = onUndoCorrection, modifier = Modifier.weight(1f)) { Text("Desfazer Auto-Fix") }
                OutlinedButton(enabled = !busy && canRedoCorrection, onClick = onRedoCorrection, modifier = Modifier.weight(1f)) { Text("Refazer Auto-Fix") }
            }
        }
        Text("Cache atual: $cachedFrames quadros · limite: 20.000 vértices / 240 quadros", color = Muted, fontSize = 9.sp)
        if (busy) {
            LinearProgressIndicator(progress = progress.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
            Text("Bake ${(progress * 100f).toInt()}%", color = Muted, fontSize = 9.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(enabled = !busy && model.vertexCount in 3..20_000 && model.indices.size >= 3, onClick = onBake, modifier = Modifier.weight(1.4f)) {
                Text("Gerar bake XPBD")
            }
            if (busy) OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancelar") }
            else OutlinedButton(enabled = cachedFrames > 0, onClick = onClear, modifier = Modifier.weight(1f)) { Text("Limpar bake") }
        }
        Text("O bake é armazenado no espaço local pré-skinning. Com Seguir animação ativo, o solver transforma partículas e colisores por quadro, incluindo skinning e morphs, e converte o resultado de volta ao espaço local. Caixas, esferas e cápsulas PMX são mantidas como colisores auxiliares.", color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun ClothSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, suffix: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(94.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValue, valueRange = range, modifier = Modifier.weight(1f))
        Text("${(value * 100f).roundToInt() / 100f}$suffix", color = Color.White, fontSize = 9.sp, modifier = Modifier.width(42.dp))
    }
}
