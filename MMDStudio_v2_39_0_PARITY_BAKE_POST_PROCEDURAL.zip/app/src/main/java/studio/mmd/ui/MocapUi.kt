package studio.mmd.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import studio.mmd.edit.Editor
import studio.mmd.importer.ModelImporter
import studio.mmd.mocap.*

/**
 * "Animar a partir de vídeo": escolhe um vídeo da biblioteca (ou importa), processa em segundo plano com progresso
 * e grava os keyframes no Editor (um único passo de desfazer). "Prévia" processa só 5 s para conferir rápido.
 */
@Composable
fun MocapDialog(ed: Editor, currentFrame: Int, timelineFps: Int, onClose: () -> Unit, onDone: (String, Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { if (MocapLibrary.items.isEmpty()) withContext(Dispatchers.IO) { MocapLibrary.load(ctx) } }
    var sel by remember { mutableStateOf<MocapVideo?>(null) }
    var startS by remember { mutableStateOf(0f) }
    var endS by remember { mutableStateOf(0f) }
    var fps by remember { mutableStateOf(15) }
    var smooth by remember { mutableStateOf(0.5f) }
    var polish by remember { mutableStateOf(0.35f) }
    var allBones by remember { mutableStateOf(false) }
    var moveCenter by remember { mutableStateOf(true) }
    var swapMode by remember { mutableStateOf(0) }   // 0 auto, 1 normal, 2 invertido
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var stage by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var tagText by remember { mutableStateOf("") }
    val running = job?.isActive == true

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val v = withContext(Dispatchers.IO) { MocapLibrary.add(ctx, uri, ModelImporter.displayName(ctx, uri)) }
                sel = v; startS = 0f; endS = v.durationMs / 1000f; err = null
            } catch (e: Throwable) { err = "Erro ao importar: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    fun pick(v: MocapVideo) { sel = v; startS = 0f; endS = v.durationMs / 1000f; tagText = v.tags }

    fun run(preview: Boolean) {
        val v = sel ?: return
        val s = startS.coerceAtLeast(0f); var e = endS.coerceAtLeast(s + 0.3f)
        if (preview) e = minOf(e, s + 5f)
        val useFps = if (preview) minOf(fps, 10) else fps
        val insert = currentFrame
        val opts = MocapOptions(allBones, moveCenter, when (swapMode) { 1 -> false; 2 -> true; else -> null }, insert, timelineFps)
        err = null; stage = "Detectando o corpo no vídeo…"; progress = 0 to 1
        job = scope.launch {
            try {
                val file = MocapLibrary.fileOf(ctx, v)
                val frames = withContext(Dispatchers.Default) { MocapEngine.extract(file, s, e, useFps, smooth) { i, n -> progress = i to n } }
                stage = "Convertendo para os ossos do modelo…"
                val tracks = withContext(Dispatchers.Default) {
                    val raw = MocapRetarget.retarget(ed.model, frames, opts)
                    MotionCleanup.clean(raw, strength = polish, passes = 2, spikeThreshold = if (polish > 0.65f) 0.12f else 0f)
                }
                val last = insert + ((e - s) * timelineFps).toInt()
                val n = ed.applyMocap(tracks, insert, last)
                onDone("Mocap ${if (preview) "(prévia 5 s) " else ""}aplicado: $n keys em ${tracks.size} ossos, quadros $insert–$last.\nSuavização de entrada: %.0f%%. Desfazer descarta tudo de uma vez.".format(polish * 100f), last)
                onClose()
            } catch (c: CancellationException) { throw c
            } catch (t: Throwable) { err = t.message ?: t.javaClass.simpleName }
            finally { progress = null; stage = "" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!running) onClose() },
        title = { Text("Animar a partir de vídeo") },
        confirmButton = {
            if (running) TextButton(onClick = { job?.cancel() }) { Text("Cancelar") }
            else Row {
                TextButton(enabled = sel != null, onClick = { run(true) }) { Text("Prévia (5 s)") }
                TextButton(enabled = sel != null, onClick = { run(false) }) { Text("Gerar") }
            }
        },
        dismissButton = { if (!running) TextButton(onClick = onClose) { Text("Fechar") } },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                Text("Biblioteca de vídeos", fontSize = 12.sp)
                if (MocapLibrary.items.isEmpty()) Text("Nenhum vídeo ainda. Importe um vídeo de dança (uma pessoa, corpo inteiro visível, câmera parada).", fontSize = 11.sp, color = Color.Gray)
                for (v in MocapLibrary.items) {
                    Row(Modifier.fillMaxWidth().clickable(enabled = !running) { pick(v) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel === v, onClick = { if (!running) pick(v) })
                        Column(Modifier.weight(1f)) {
                            Text(v.name, fontSize = 13.sp, maxLines = 1)
                            Text("%.1fs".format(v.durationMs / 1000f) + (if (v.tags.isNotBlank()) " · ${v.tags}" else "") + (if (v.builtin) " · da casa" else ""), fontSize = 10.sp, color = Color.Gray)
                        }
                        if (!v.builtin) TextButton(enabled = !running, onClick = { MocapLibrary.remove(ctx, v); if (sel === v) sel = null }) { Text("Excluir", fontSize = 11.sp) }
                    }
                }
                OutlinedButton(enabled = !running, onClick = { picker.launch(arrayOf("video/*")) }) { Text("Importar vídeo…") }
                val v = sel
                if (v != null && !v.builtin) {
                    OutlinedTextField(tagText, { tagText = it; MocapLibrary.setTags(ctx, v, it); sel = MocapLibrary.items.firstOrNull { x -> x.id == v.id } },
                        label = { Text("Tags (separadas por vírgula)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                }
                if (v != null) {
                    val dur = maxOf(v.durationMs / 1000f, 0.5f)
                    Text("Trecho do vídeo: %.1fs → %.1fs (entra na timeline a partir do quadro $currentFrame)".format(startS, endS), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Slider(startS.coerceIn(0f, dur), { startS = it; if (endS < it + 0.5f) endS = minOf(dur, it + 0.5f) }, valueRange = 0f..dur, enabled = !running)
                    Slider(endS.coerceIn(0f, dur), { endS = maxOf(it, startS + 0.5f).coerceAtMost(dur) }, valueRange = 0f..dur, enabled = !running)
                    Text("Para refazer só um trecho: escolha o intervalo, posicione a timeline no quadro de início e gere de novo (as keys dos ossos do mocap nesse intervalo são substituídas).", fontSize = 10.sp, color = Color.Gray)
                    Text("Amostragem: $fps fps (mais = mais preciso e mais lento)", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (f in listOf(10, 15, 30)) FilterChip(selected = fps == f, onClick = { fps = f }, enabled = !running, label = { Text("$f") })
                    }
                    Text("Suavização da detecção: %.0f%%".format(smooth * 100), fontSize = 12.sp)
                    Slider(smooth, { smooth = it }, valueRange = 0f..1f, enabled = !running)
                    Text("Polimento final das curvas: %.0f%%".format(polish * 100), fontSize = 12.sp)
                    Slider(polish, { polish = it }, valueRange = 0f..1f, enabled = !running)
                    Text("O polimento reduz tremores e picos isolados mantendo o início e o fim do movimento.", fontSize = 10.sp, color = Color.Gray)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Todos os ossos mapeados (senão só os principais)", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Switch(allBones, { allBones = it }, enabled = !running)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Mover o センター (posição do corpo)", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Switch(moveCenter, { moveCenter = it }, enabled = !running)
                    }
                    Text("Lados: " + listOf("automático", "normal", "invertido")[swapMode] + " (toque para trocar — use se esquerda e direita saírem trocadas)", fontSize = 12.sp,
                        modifier = Modifier.clickable(enabled = !running) { swapMode = (swapMode + 1) % 3 }.padding(vertical = 6.dp))
                }
                val pg = progress
                if (running && pg != null) {
                    Text("$stage  ${pg.first}/${pg.second}", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    LinearProgressIndicator(progress = { if (pg.second > 0) pg.first.toFloat() / pg.second else 0f }, modifier = Modifier.fillMaxWidth())
                }
                err?.let { Text(it, color = Color(0xFFE57373), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        })
}
