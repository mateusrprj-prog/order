package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import studio.mmd.render.ViewPreset
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Um eixo do gizmo já projetado na tela (x p/ direita, y p/ cima, z = profundidade: >0 está virado para a câmera). */
data class GizmoAxis(val label: String, val preset: ViewPreset, val sx: Float, val sy: Float, val depth: Float, val positive: Boolean)

/** Matemática pura do gizmo (testável em JVM): projeta ±X, ±Y, ±Z segundo yaw/pitch da câmera de viewport. */
object GizmoMath {
    /** Eixo → vista: câmera em +Z = Frente, -Z = Trás, +X = Direita, -X = Esquerda, +Y = Topo, -Y = Base (mesmos ângulos de [ViewPreset]). */
    fun axes(yawDeg: Float, pitchDeg: Float): List<GizmoAxis> {
        val y = Math.toRadians(yawDeg.toDouble()); val p = Math.toRadians(pitchDeg.toDouble())
        val rx = cos(y); val ry = 0.0; val rz = -sin(y)                                   // direita da câmera
        val ux = -sin(p) * sin(y); val uy = cos(p); val uz = -sin(p) * cos(y)             // cima da câmera
        val fx = cos(p) * sin(y); val fy = sin(p); val fz = cos(p) * cos(y)               // do foco para a câmera
        fun ax(l: String, pr: ViewPreset, x: Double, yy: Double, z: Double, pos: Boolean) =
            GizmoAxis(l, pr, (x * rx + yy * ry + z * rz).toFloat(), (x * ux + yy * uy + z * uz).toFloat(), (x * fx + yy * fy + z * fz).toFloat(), pos)
        return listOf(
            ax("X", ViewPreset.RIGHT, 1.0, 0.0, 0.0, true), ax("", ViewPreset.LEFT, -1.0, 0.0, 0.0, false),
            ax("Y", ViewPreset.TOP, 0.0, 1.0, 0.0, true), ax("", ViewPreset.BOTTOM, 0.0, -1.0, 0.0, false),
            ax("Z", ViewPreset.FRONT, 0.0, 0.0, 1.0, true), ax("", ViewPreset.BACK, 0.0, 0.0, -1.0, false)
        )
    }
    /** Eixo tocado (px relativos ao centro; raio do gizmo em px), preferindo o mais próximo da câmera; null se nenhum. */
    fun hit(axes: List<GizmoAxis>, dx: Float, dy: Float, radius: Float, tapR: Float): GizmoAxis? =
        axes.filter { hypot(dx - it.sx * radius, dy + it.sy * radius) <= tapR }.maxByOrNull { it.depth }
}

/** Gizmo de orientação 3D (canto da viewport): mostra X/Y/Z; tocar num eixo vai para a vista ortogonal. Só mexe na câmera de viewport. */
@Composable
fun OrientationGizmo(yaw: Float, pitch: Float, size: Dp = 84.dp, onPreset: (ViewPreset) -> Unit, modifier: Modifier = Modifier) {
    val axes = GizmoMath.axes(yaw, pitch)
    Canvas(modifier.size(size).pointerInput(yaw, pitch) {
        detectTapGestures { off ->
            val r = this.size.width / 2f * 0.66f
            val h = GizmoMath.hit(axes, off.x - this.size.width / 2f, off.y - this.size.height / 2f, r, this.size.width * 0.17f)
            if (h != null) onPreset(h.preset)
        }
    }) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f); val r = this.size.width / 2f * 0.66f
        drawCircle(Color(0x66000000), this.size.width / 2f, c)
        val col = mapOf("X" to Color(0xFFE05555), "Y" to Color(0xFF6FCF6F), "Z" to Color(0xFF5599EE))
        val dotR = this.size.width * 0.12f
        for (a in axes.sortedBy { it.depth }) {
            val base = col[if (a.label.isNotEmpty()) a.label else when (a.preset) { ViewPreset.LEFT -> "X"; ViewPreset.BOTTOM -> "Y"; else -> "Z" }] ?: Color.White
            val p = Offset(c.x + a.sx * r, c.y - a.sy * r)
            val alpha = if (a.depth >= 0f) 1f else 0.45f
            if (a.positive) drawLine(base.copy(alpha = alpha), c, p, 3f)
            drawCircle(if (a.positive) base.copy(alpha = alpha) else base.copy(alpha = alpha * 0.55f), dotR, p)
            if (!a.positive) drawCircle(base.copy(alpha = alpha), dotR, p, style = Stroke(2f))
            if (a.label.isNotEmpty()) drawContext.canvas.nativeCanvas.drawText(a.label, p.x - dotR * 0.4f, p.y + dotR * 0.4f,
                android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = dotR * 1.3f; isFakeBoldText = true })
        }
    }
}
