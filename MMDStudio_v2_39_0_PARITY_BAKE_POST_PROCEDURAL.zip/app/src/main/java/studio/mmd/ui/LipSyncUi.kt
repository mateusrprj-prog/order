package studio.mmd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import studio.mmd.ai.LipSync
import studio.mmd.edit.Editor
import studio.mmd.export.AudioMux
import java.io.File

/**
 * "Lipsync automático": decodifica o áudio do projeto, analisa as vogais (あ い う え お) quadro a quadro e grava keyframes nos
 * morphs de vogal do modelo, num único passo de desfazer. Respeita o atraso do painel Áudio. Substitui as keys desses morphs
 * dentro do trecho do áudio.
 */
@Composable
fun LipSyncDialog(ed: Editor, audio: File, offsetMs: Int, fps: Int, onClose: () -> Unit, onDone: (String, Int) -> Unit) {
    val scope = rememberCoroutineScope()
    var sens by remember { mutableStateOf(0.5f) }
    var inten by remember { mutableStateOf(1f) }
    var stage by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    val running = job?.isActive == true
    val map = remember(ed.model) { LipSync.findMorphs(ed.model.morphs.map { it.name to it.nameEn }) }
    val missing = LipSync.VOWELS.filter { it !in map }

    fun run() {
        err = null; stage = "Decodificando o áudio…"
        val s = sens; val i = inten
        job = scope.launch {
            try {
                val r = withContext(Dispatchers.Default) {
                    val (pcm, rate, ch) = AudioMux.decodePcm(audio, 180_000_000L)       // até 3 min
                    stage = "Analisando as vogais…"
                    val (mono, sr) = LipSync.toMono(pcm, rate, ch)
                    LipSync.analyze(mono, sr, LipSync.Options(fps = fps, sensitivity = s, intensity = i, offsetMs = offsetMs))
                }
                val keys = LipSync.toMorphKeys(r, map)
                if (keys.isEmpty()) { err = "Nenhuma fala detectada. Aumente a sensibilidade ou confira o áudio."; return@launch }
                // apaga e regrava TODAS as vogais do modelo no trecho (as que ficaram sem fala também zeram)
                val all = LinkedHashMap<String, List<Pair<Int, Float>>>()
                for (nm in map.values) all[nm] = keys[nm] ?: emptyList()
                val n = ed.applyAnim(emptyMap(), all, r.from, r.to)
                val pct = if (r.total > 0) r.voiced * 100 / r.total else 0
                onDone("Lipsync: $n keys em ${keys.size} morphs, quadros ${r.from}–${r.to} (fala em $pct% do trecho).\nDesfazer descarta tudo de uma vez.", r.to)
                onClose()
            } catch (c: CancellationException) { throw c
            } catch (t: Throwable) { err = "Falhou: " + (t.message ?: t.javaClass.simpleName)
            } finally { stage = "" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!running) onClose() },
        title = { Text("Lipsync automático") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Usa o áudio do projeto (${audio.name}) e gera a boca nos morphs de vogal do modelo.", fontSize = 12.sp)
                if (map.isEmpty()) Text("Este modelo não tem morphs de vogal reconhecíveis (あ い う え お / a i u e o).", color = Color(0xFFFFC36A), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                else Text("Morphs usados: " + LipSync.VOWELS.filter { it in map }.joinToString { "${it.uppercase()}→${map[it]}" } +
                    (if (missing.isNotEmpty()) ". Sem morph para: ${missing.joinToString { it.uppercase() }} (essas vogais ficam sem boca)." else "."),
                    color = Color(0xFF9AA0A6), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                Text("Sensibilidade: %.0f%%".format(sens * 100), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                Slider(sens, { sens = it }, valueRange = 0f..1f, enabled = !running)
                Text("Abertura da boca: %.0f%%".format(inten * 100), fontSize = 12.sp)
                Slider(inten, { inten = it }, valueRange = 0.3f..1.5f, enabled = !running)
                Text("Atraso do áudio considerado: ${"%+.2f".format(offsetMs / 1000f)}s. As keys de ${map.values.joinToString().ifEmpty { "vogais" }} dentro do trecho do áudio serão substituídas (desfazer volta). " +
                    "Funciona melhor com voz limpa; música alta por cima gera vogais falsas. Máximo de 3 minutos.", fontSize = 10.sp, color = Color(0xFF9AA0A6), modifier = Modifier.padding(top = 6.dp))
                if (stage.isNotEmpty()) Text(stage, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = { TextButton(onClick = { run() }, enabled = !running && map.isNotEmpty()) { Text(if (running) "Gerando…" else "Gerar") } },
        dismissButton = { TextButton(onClick = { if (running) { job?.cancel(); stage = "" } else onClose() }) { Text(if (running) "Cancelar" else "Fechar") } }
    )
}
