package studio.mmd.render

import kotlin.math.abs

/**
 * v2.39.0 — Sombra projetada no chão (sombra de solo do MMD): matriz de projeção planar a partir da direção da luz
 * e utilitários de bordas (contorno) e toon. Matrizes 4x4 coluna-maior. Kotlin puro.
 */
object GroundShadow {
    /**
     * Matriz que achata a geometria no plano [plane] = (a, b, c, d) com a·x + b·y + c·z + d = 0, ao longo da direção
     * da luz [lightDir] (do objeto para a luz NÃO: direção em que a luz viaja). Devolve null se a luz for paralela ao plano.
     */
    fun planarMatrix(lightDir: FloatArray, plane: FloatArray = floatArrayOf(0f, 1f, 0f, 0f)): FloatArray? {
        if (lightDir.size < 3 || plane.size < 4 || lightDir.any { !it.isFinite() } || plane.any { !it.isFinite() }) return null
        val dot = plane[0] * lightDir[0] + plane[1] * lightDir[1] + plane[2] * lightDir[2]
        if (abs(dot) < 1e-5f) return null
        // Projeção ao longo de L: P' = P - L * (n·P + d) / (n·L)
        val m = FloatArray(16)
        val n = plane; val l = lightDir
        for (c in 0..3) for (r in 0..3) {
            val id = if (r == c) 1f else 0f
            val nc = if (c < 3) n[c] else n[3]
            val lr = if (r < 3) l[r] else 0f
            m[c * 4 + r] = id - lr * nc / dot
        }
        return m
    }

    /** Aplica a matriz a um ponto. */
    fun project(m: FloatArray, x: Float, y: Float, z: Float): FloatArray {
        val ox = m[0] * x + m[4] * y + m[8] * z + m[12]
        val oy = m[1] * x + m[5] * y + m[9] * z + m[13]
        val oz = m[2] * x + m[6] * y + m[10] * z + m[14]
        val ow = m[3] * x + m[7] * y + m[11] * z + m[15]
        return if (abs(ow - 1f) > 1e-6f && abs(ow) > 1e-8f) floatArrayOf(ox / ow, oy / ow, oz / ow) else floatArrayOf(ox, oy, oz)
    }

    /** Leve elevação para evitar z-fighting com o chão (aplicada ao plano). */
    fun liftedPlane(height: Float, bias: Float = 0.02f) = floatArrayOf(0f, 1f, 0f, -(height + bias))

    /** Opacidade da sombra pelo ângulo da luz com o chão: luz rasante fica mais fraca. */
    fun opacityFor(lightDir: FloatArray, base: Float = 0.5f): Float {
        if (lightDir.size < 3) return 0f
        val len = Math.sqrt((lightDir[0] * lightDir[0] + lightDir[1] * lightDir[1] + lightDir[2] * lightDir[2]).toDouble()).toFloat()
        if (len < 1e-6f || !len.isFinite()) return 0f
        val down = (-lightDir[1] / len).coerceIn(0f, 1f)
        return (base.coerceIn(0f, 1f) * (0.25f + 0.75f * down))
    }
}

/** Parâmetros de contorno (edge) por material do PMX: espessura e cor, ajustados pela distância da câmera. */
object EdgeOutline {
    /** Espessura em pixels de tela: [edgeSize] do material × escala × compensação pela distância (mais fino ao afastar). */
    fun thicknessPx(edgeSize: Float, distance: Float, screenHeightPx: Int, fovDeg: Float, userScale: Float = 1f): Float {
        if (!edgeSize.isFinite() || !distance.isFinite() || distance <= 0f || screenHeightPx < 1) return 0f
        val worldPerPx = 2f * distance * Math.tan(Math.toRadians((fovDeg.coerceIn(1f, 179f) / 2).toDouble())).toFloat() / screenHeightPx
        val wanted = edgeSize.coerceAtLeast(0f) * 0.02f * userScale.coerceIn(0f, 8f)
        return (wanted / worldPerPx).coerceIn(0f, 12f)
    }
}
