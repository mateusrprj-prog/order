package studio.mmd.render

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * v1.30.0 (P0 Navegação Livre): câmera de VIEWPORT do editor (yaw/pitch/distância/ponto de foco).
 * Matemática pura (sem Android) para ser testada em JVM. NÃO é a câmera VMD/cinematográfica e
 * NUNCA altera transformações de modelos, ossos, keyframes ou Undo: só muda como a cena é vista.
 * Compartilhada entre a thread de toque e a thread GL (campos @Volatile).
 */
class OrbitCamera {
    @Volatile var yaw = 30f
    @Volatile var pitch = 20f
    @Volatile var dist = 12f
    @Volatile var tx = 0f
    @Volatile var ty = 1f
    @Volatile var tz = 0f

    fun reset() { yaw = 30f; pitch = 20f; dist = 12f; tx = 0f; ty = 1f; tz = 0f }

    fun eye(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf(
            tx + dist * (cos(p) * sin(y)).toFloat(),
            ty + dist * sin(p).toFloat(),
            tz + dist * (cos(p) * cos(y)).toFloat()
        )
    }

    /** Vetor "direita" da câmera no mundo (unitário, horizontal). */
    fun right(): FloatArray {
        val y = Math.toRadians(yaw.toDouble())
        return floatArrayOf(cos(y).toFloat(), 0f, (-sin(y)).toFloat())
    }

    /** Vetor "cima" da câmera no mundo (unitário, perpendicular à direção de visada e a "direita"). */
    fun up(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf((-sin(p) * sin(y)).toFloat(), cos(p).toFloat(), (-sin(p) * cos(y)).toFloat())
    }

    /** Orbita ao redor do foco. dx>0 (dedo p/ direita) gira a vista; dy>0 (dedo p/ baixo) eleva a câmera. Sem inversões: pitch limitado a ±[PITCH_LIMIT]. */
    fun orbit(dxPx: Float, dyPx: Float, degPerPx: Float = DEG_PER_PX) {
        yaw = wrap(yaw - dxPx * degPerPx)
        pitch = (pitch + dyPx * degPerPx).coerceIn(-PITCH_LIMIT, PITCH_LIMIT)
    }

    /** Pan em espaço de câmera: o foco acompanha os dedos (o conteúdo "gruda" no dedo). Respeita yaw E pitch. */
    fun pan(dxPx: Float, dyPx: Float, viewHeightPx: Float = 1000f, fovYDeg: Float = 45f) {
        // unidades de mundo por pixel na distância do foco (perspectiva): 2*d*tan(fov/2)/altura
        val k = (2.0 * dist * Math.tan(Math.toRadians(fovYDeg / 2.0)) / max(viewHeightPx, 1f)).toFloat()
        val r = right(); val u = up()
        tx += (-r[0] * dxPx + u[0] * dyPx) * k
        ty += (-r[1] * dxPx + u[1] * dyPx) * k
        tz += (-r[2] * dxPx + u[2] * dyPx) * k
    }

    /** Pinça: scaleFactor>1 aproxima. Limites seguros (não atravessa o foco nem some com a cena). */
    fun zoom(scaleFactor: Float) {
        if (scaleFactor <= 0f || scaleFactor.isNaN()) return
        dist = (dist / scaleFactor).coerceIn(minDist, maxDist)
    }

    @Volatile var minDist = 0.3f
    @Volatile var maxDist = 400f

    /** Move o ponto de órbita para (x,y,z) mantendo yaw/pitch/distância (só a câmera se desloca). */
    fun focusOn(x: Float, y: Float, z: Float) { tx = x; ty = y; tz = z }

    /** Foca uma esfera (centro + raio): ajusta foco e distância para caber no campo de visão (sem mexer em yaw/pitch). */
    fun frameSphere(cx: Float, cy: Float, cz: Float, radius: Float, fovYDeg: Float = 45f, aspect: Float = 1f) {
        val r = max(radius, 0.05f)
        val half = Math.toRadians(fovYDeg / 2.0)
        val halfMin = if (aspect < 1f) Math.atan(Math.tan(half) * aspect) else half
        tx = cx; ty = cy; tz = cz
        dist = ((r / sin(halfMin)) * 1.15).toFloat().coerceIn(minDist, maxDist)
    }

    /** Enquadra uma caixa (min/max) — usa a esfera circunscrita. */
    fun frameBox(minX: Float, minY: Float, minZ: Float, maxX: Float, maxY: Float, maxZ: Float, fovYDeg: Float = 45f, aspect: Float = 1f) {
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f; val cz = (minZ + maxZ) / 2f
        val dx = maxX - minX; val dy = maxY - minY; val dz = maxZ - minZ
        frameSphere(cx, cy, cz, sqrt(dx * dx + dy * dy + dz * dz) / 2f, fovYDeg, aspect)
    }

    fun setAngles(newYaw: Float, newPitch: Float) { yaw = wrap(newYaw); pitch = newPitch.coerceIn(-89f, 89f) }

    /** Rótulo da vista ortogonal atual (se estiver exatamente num preset), senão null. */
    fun presetLabel(): String? = when {
        pitch >= 88.5f -> "Topo"
        pitch <= -88.5f -> "Base"
        abs(pitch) < 0.5f && abs(wrap(yaw)) < 0.5f -> "Frente"
        abs(pitch) < 0.5f && abs(abs(wrap(yaw)) - 180f) < 0.5f -> "Trás"
        abs(pitch) < 0.5f && abs(wrap(yaw) - 90f) < 0.5f -> "Direita"
        abs(pitch) < 0.5f && abs(wrap(yaw) + 90f) < 0.5f -> "Esquerda"
        else -> null
    }

    companion object {
        const val DEG_PER_PX = 0.4f
        const val PITCH_LIMIT = 89f
        fun wrap(a: Float): Float { var r = a % 360f; if (r > 180f) r -= 360f; if (r <= -180f) r += 360f; return r }
    }
}
