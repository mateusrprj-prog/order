package studio.mmd.ai

import org.json.JSONArray
import org.json.JSONObject
import studio.mmd.mmd.PmxModel
import studio.mmd.mocap.MocapOptions
import studio.mmd.mocap.MocapRetarget
import studio.mmd.mocap.PoseFrame
import java.io.IOException
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Animação a partir de texto. A IA (API da Anthropic, com a chave do próprio usuário) devolve uma sequência de poses como
 * DIREÇÕES dos membros (não ângulos de osso, que dependem de cada modelo). O app interpola essas direções a 30 quadros/s,
 * monta pontos de corpo sintéticos e reaproveita o MESMO retarget do mocap (MocapRetarget) para chegar aos ossos do modelo.
 */
object TextAnim {
    const val DEFAULT_MODEL = "claude-sonnet-5-5"
    private const val M2U = 12.5f   // 1 metro = 12,5 unidades MMD (1 unidade = 8 cm)

    class Result(
        val tracks: Map<String, List<Pair<Int, FloatArray>>>,
        val morphs: Map<String, List<Pair<Int, Float>>>,
        val last: Int, val title: String, val keyCount: Int
    )

    private val VEC = listOf("spine", "head", "l_arm", "l_forearm", "r_arm", "r_forearm", "l_thigh", "l_shin", "r_thigh", "r_shin", "l_foot", "r_foot")
    private fun defaults(): HashMap<String, FloatArray> = hashMapOf(
        "spine" to floatArrayOf(0f, 1f, 0f), "head" to floatArrayOf(0f, 1f, 0f),
        "l_arm" to floatArrayOf(0.25f, -1f, 0f), "l_forearm" to floatArrayOf(0.2f, -1f, -0.15f),
        "r_arm" to floatArrayOf(-0.25f, -1f, 0f), "r_forearm" to floatArrayOf(-0.2f, -1f, -0.15f),
        "l_thigh" to floatArrayOf(0.05f, -1f, 0f), "l_shin" to floatArrayOf(0.05f, -1f, 0.02f),
        "r_thigh" to floatArrayOf(-0.05f, -1f, 0f), "r_shin" to floatArrayOf(-0.05f, -1f, 0.02f),
        "l_foot" to floatArrayOf(0f, -0.35f, -1f), "r_foot" to floatArrayOf(0f, -0.35f, -1f)
    )

    /** Morphs que o app realmente aplica (grupo, vértice, osso), rostos primeiro. */
    fun morphNames(m: PmxModel): List<String> {
        val ok = m.morphs.filter { it.type == 0 || it.type == 1 || it.type == 2 || it.type == 3 || it.type == 8 || it.type == 9 }.filter { it.name.isNotBlank() }
        val face = ok.filter { it.panel in 1..4 }
        return (face + ok.filter { it.panel !in 1..4 }).map { it.name }.distinct().take(110)
    }

    fun systemPrompt(m: PmxModel): String = """
You are the animation director of a MikuMikuDance-style 3D animation app. The user describes a motion; you answer with ONE JSON object and nothing else (no prose, no markdown fences).

WORLD AXES (character standing at the origin): +X = the character's LEFT side, +Y = UP, +Z = BACKWARD. The character faces -Z, so forward = [0,0,-1].

Every key describes the pose with DIRECTION VECTORS (any length, they are normalized):
- "spine": hip -> neck direction. Upright [0,1,0]; lean forward [0,1,-0.3]; lean back [0,1,0.3]; lean to its left [0.3,1,0].
- "head": shoulders -> head direction, same convention as spine.
- "l_arm","r_arm": shoulder -> elbow. "l_forearm","r_forearm": elbow -> wrist. Relaxed arm hanging: l_arm [0.25,-1,0], r_arm [-0.25,-1,0]. Arm straight out to its side: left [1,0,0], right [-1,0,0]. Arm straight up [0,1,0]. Arm forward [0,0,-1]. Elbow bent 90 degrees with arm hanging: forearm [0,0,-1]. Waving: l_arm [1,0.3,0] with l_forearm [0.3,1,0].
- "l_thigh","r_thigh": hip -> knee. "l_shin","r_shin": knee -> ankle. Standing straight: [0,-1,0] for both. Leg lifted forward: thigh [0,-0.3,-1], shin [0,-1,0]. Knee bent while standing: thigh [0,-1,-0.5], shin [0,-1,0.8]. Knees only bend backward.
- "l_foot","r_foot": ankle -> toe. Flat on the floor [0,-0.3,-1]. On tiptoe [0,-1,-0.3].
- "twist": torso twist in degrees about +Y (right-hand rule: positive swings the character's left shoulder forward). "hips_yaw": same for the pelvis.
- "center": body offset from the starting position in METERS [x,y,z]. Jump up = y positive; step forward = z negative; shift to the character's left = x positive. Crouch: y about -0.2 to -0.4 with bent knees. Keep legs plausible for the height of the body.
- "morphs": {"name": weight 0..1} for facial expressions. Use ONLY names from the list at the end. Set the weight back to 0 when the expression ends.

OUTPUT FORMAT: {"title":"short name","keys":[{"t":0.0,"ease":"smooth", ...fields...}, ...]}
- "ease" is how the pose is reached from the previous key: "smooth" (default), "linear" or "hold" (snap at the key).
- The first key has t=0 and the full starting pose (all fields). Later keys list ONLY the fields that change; omitted fields keep their previous value.
- t is in seconds and strictly increasing. Total length must be close to the requested duration. Space keys 0.2-0.6 s apart, at most 60 keys.
- Make it expressive: anticipation before big moves, overshoot, weight shifts, arms counter-swinging the legs, head following the motion. For loops or cycles, finish on the starting pose.
- Stay anatomically plausible: knees bend backward, elbows bend forward, no limb passing through the body.

If the request is not about a body motion, still answer with a short neutral idle animation.

Morph names available in this model: ${morphNames(m).joinToString(", ")}
""".trimIndent()

    fun userPrompt(text: String, seconds: Float): String =
        "Animation request (may be in Portuguese): ${text.trim()}\nTarget duration: ${"%.1f".format(java.util.Locale.US, seconds)} seconds."

    /** Chama a API de mensagens da Anthropic e devolve o texto da resposta. */
    fun request(key: String, model: String, system: String, user: String): String {
        val c = java.net.URL("https://api.anthropic.com/v1/messages").openConnection() as java.net.HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 300000; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            val body = JSONObject().put("model", model).put("max_tokens", 12000).put("system", system)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException(friendly(code, raw))
            val j = JSONObject(raw)
            val arr = j.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) { val p = arr.getJSONObject(i); if (p.optString("type") == "text") sb.append(p.optString("text")) }
            if (j.optString("stop_reason") == "max_tokens") throw IOException("A resposta da IA foi cortada (animação longa demais). Tente uma duração menor.")
            return sb.toString()
        } catch (e: java.net.UnknownHostException) { throw IOException("Sem internet.")
        } catch (e: java.net.SocketTimeoutException) { throw IOException("A IA demorou demais. Tente de novo ou use uma duração menor.")
        } finally { c.disconnect() }
    }

    private fun friendly(code: Int, raw: String): String {
        val msg = try { JSONObject(raw).getJSONObject("error").optString("message") } catch (e: Exception) { "" }
        return when (code) {
            401 -> "Chave de API inválida (401). Confira a chave em console.anthropic.com."
            403 -> "Chave sem permissão para esse modelo (403). $msg"
            404 -> "Modelo não encontrado (404). Confira o nome do modelo. $msg"
            429 -> "Limite de uso ou sem créditos na conta da API (429). $msg"
            529, 503 -> "A API está sobrecarregada ($code). Tente de novo em instantes."
            else -> "Erro da API ($code). ${msg.take(200)}"
        }
    }

    // ------------------------------------------------------------------------------------------ interpretação

    private class St(val t: Float, val ease: Int, val vec: HashMap<String, FloatArray>, val twist: Float, val hips: Float,
                     val center: FloatArray, val morphs: HashMap<String, Float>)

    private fun arr3(a: JSONArray?): FloatArray? {
        if (a == null || a.length() < 3) return null
        val v = FloatArray(3) { a.optDouble(it, Double.NaN).toFloat() }
        return if (v.all { it.isFinite() }) v else null
    }
    private fun len(v: FloatArray) = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    private fun nrm(v: FloatArray): FloatArray { val l = len(v); return if (l < 1e-5f) floatArrayOf(0f, 1f, 0f) else floatArrayOf(v[0] / l, v[1] / l, v[2] / l) }
    private fun add(a: FloatArray, b: FloatArray, k: Float = 1f) = floatArrayOf(a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k)

    /** Extrai o objeto JSON da resposta (tolera ``` e texto em volta) e devolve os keyframes de ossos e morphs para o modelo. */
    fun build(model: PmxModel, text: String, startFrame: Int, fps: Int): Result {
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) throw IllegalStateException("A IA não devolveu um JSON de animação. Tente de novo.")
        val root = try { JSONObject(text.substring(a, b + 1)) } catch (e: Exception) { throw IllegalStateException("JSON da IA inválido (${e.message?.take(80)}). Tente de novo.") }
        val ks = root.optJSONArray("keys") ?: throw IllegalStateException("A resposta da IA não tem \"keys\".")
        val title = root.optString("title", "Animação IA").take(40)

        // keys -> estados completos (campos omitidos herdam o valor anterior)
        val raw = ArrayList<JSONObject>()
        for (i in 0 until ks.length()) ks.optJSONObject(i)?.let { if (it.has("t")) raw.add(it) }
        raw.sortBy { it.optDouble("t", 0.0) }
        if (raw.isEmpty()) throw IllegalStateException("A IA não devolveu nenhuma pose.")
        val t0 = raw[0].optDouble("t", 0.0).toFloat()
        val validMorph = model.morphs.map { it.name }.toHashSet()
        val states = ArrayList<St>()
        var vec = defaults(); var twist = 0f; var hips = 0f; var center = floatArrayOf(0f, 0f, 0f); var morphs = HashMap<String, Float>()
        for (k in raw) {
            val t = (k.optDouble("t", 0.0).toFloat() - t0).coerceIn(0f, 60f)
            if (states.isNotEmpty() && t <= states.last().t + 0.02f) continue
            vec = HashMap(vec.mapValues { it.value.copyOf() })
            for (n in VEC) arr3(k.optJSONArray(n))?.let { if (len(it) > 1e-4f) vec[n] = nrm(it) }
            if (k.has("twist")) twist = k.optDouble("twist", twist.toDouble()).toFloat().coerceIn(-120f, 120f)
            if (k.has("hips_yaw")) hips = k.optDouble("hips_yaw", hips.toDouble()).toFloat().coerceIn(-120f, 120f)
            arr3(k.optJSONArray("center"))?.let { center = floatArrayOf(it[0].coerceIn(-10f, 10f), it[1].coerceIn(-3f, 5f), it[2].coerceIn(-10f, 10f)) }
            morphs = HashMap(morphs)
            k.optJSONObject("morphs")?.let { mo ->
                for (nm in mo.keys()) if (nm in validMorph) morphs[nm] = mo.optDouble(nm, 0.0).toFloat().coerceIn(0f, 1f)
            }
            val ease = when (k.optString("ease", "smooth")) { "linear" -> 1; "hold" -> 2; else -> 0 }
            states.add(St(t, ease, vec, twist, hips, center, morphs))
        }
        if (states.size < 2) throw IllegalStateException("A IA devolveu poses de menos (precisa de pelo menos 2 keys).")

        // amostragem a [fps] quadros/s -> pontos de corpo sintéticos (índices do ML Kit) no sistema do MMD
        val dur = states.last().t
        val nFrames = (dur * fps).roundToInt().coerceIn(2, 60 * fps)
        val frames = ArrayList<PoseFrame>(nFrames + 1)
        val centerPts = ArrayList<Pair<Int, FloatArray>>()
        var k = 0
        for (fi in 0..nFrames) {
            val tt = fi.toFloat() / fps
            while (k + 1 < states.size && states[k + 1].t <= tt) k++
            val s0 = states[k]
            val cur: St; var u = 0f
            val s1 = if (k + 1 < states.size) states[k + 1] else null
            if (s1 == null) { cur = s0 } else {
                val lin = ((tt - s0.t) / (s1.t - s0.t)).coerceIn(0f, 1f)
                u = when (s1.ease) { 1 -> lin; 2 -> if (lin >= 1f) 1f else 0f; else -> lin * lin * (3f - 2f * lin) }
                cur = s0
            }
            fun v(n: String): FloatArray {
                val a0 = s0.vec.getValue(n); val b0 = s1?.vec?.getValue(n) ?: return a0
                val m = floatArrayOf(a0[0] + (b0[0] - a0[0]) * u, a0[1] + (b0[1] - a0[1]) * u, a0[2] + (b0[2] - a0[2]) * u)
                return if (len(m) < 1e-4f) b0 else nrm(m)
            }
            val tw = cur.twist + ((s1?.twist ?: cur.twist) - cur.twist) * u
            val hy = cur.hips + ((s1?.hips ?: cur.hips) - cur.hips) * u
            val ce = FloatArray(3) { cur.center[it] + ((s1?.center?.get(it) ?: cur.center[it]) - cur.center[it]) * u }

            val d = v("spine")
            val twr = Math.toRadians(tw.toDouble()); val axis = floatArrayOf(cos(twr).toFloat(), 0f, (-sin(twr)).toFloat())
            val dot = axis[0] * d[0] + axis[1] * d[1] + axis[2] * d[2]
            val sx = nrm(add(axis, d, -dot)).let { floatArrayOf(it[0] * 0.2f, it[1] * 0.2f, it[2] * 0.2f) }
            val shMid = floatArrayOf(d[0] * 0.5f, d[1] * 0.5f, d[2] * 0.5f)
            val shL = add(shMid, sx); val shR = add(shMid, sx, -1f)
            val hyr = Math.toRadians(hy.toDouble())
            val hx = floatArrayOf(cos(hyr).toFloat() * 0.09f, 0f, (-sin(hyr)).toFloat() * 0.09f)
            val hpL = hx; val hpR = floatArrayOf(-hx[0], -hx[1], -hx[2])
            val elL = add(shL, v("l_arm"), 0.28f); val wrL = add(elL, v("l_forearm"), 0.26f)
            val elR = add(shR, v("r_arm"), 0.28f); val wrR = add(elR, v("r_forearm"), 0.26f)
            val knL = add(hpL, v("l_thigh"), 0.4f); val anL = add(knL, v("l_shin"), 0.4f); val toL = add(anL, v("l_foot"), 0.15f)
            val knR = add(hpR, v("r_thigh"), 0.4f); val anR = add(knR, v("r_shin"), 0.4f); val toR = add(anR, v("r_foot"), 0.15f)
            val ear = add(shMid, v("head"), 0.25f)

            val p = FloatArray(33 * 3)
            fun put(i: Int, q: FloatArray) { p[i * 3] = q[0]; p[i * 3 + 1] = -q[1]; p[i * 3 + 2] = q[2] }   // MMD (y p/ cima) -> "imagem" (y p/ baixo)
            put(7, ear); put(8, ear)
            put(11, shL); put(12, shR); put(13, elL); put(14, elR); put(15, wrL); put(16, wrR)
            put(23, hpL); put(24, hpR); put(25, knL); put(26, knR); put(27, anL); put(28, anR); put(31, toL); put(32, toR)
            frames.add(PoseFrame(tt, p, FloatArray(33) { 1f }))
            centerPts.add((startFrame + fi) to floatArrayOf(ce[0] * M2U, ce[1] * M2U, ce[2] * M2U, 0f, 0f, 0f, 1f))
        }

        val tracks = HashMap<String, List<Pair<Int, FloatArray>>>()
        tracks.putAll(MocapRetarget.retarget(model, frames, MocapOptions(true, false, false, startFrame, fps)))
        if (model.bones.any { it.name == "センター" } && centerPts.any { abs(it.second[0]) + abs(it.second[1]) + abs(it.second[2]) > 1e-3f }) {
            tracks["センター"] = simplifyPos(centerPts, 0.04f)
        }

        // morphs: uma key por mudança (inclui o início e o fim de cada trecho constante)
        val mt = HashMap<String, List<Pair<Int, Float>>>()
        val names = states.flatMap { it.morphs.keys }.toSet()
        for (nm in names) {
            val w = states.map { it.morphs[nm] ?: 0f }
            if (w.all { it < 0.005f }) continue
            val out = ArrayList<Pair<Int, Float>>()
            for (i in w.indices) {
                val keep = i == 0 || i == w.lastIndex || w[i] != w[i - 1] || w[i] != w[i + 1]
                if (keep) out.add((startFrame + (states[i].t * fps).roundToInt()) to w[i])
            }
            mt[nm] = out
        }
        return Result(tracks, mt, startFrame + nFrames, title, states.size)
    }

    /** Remove keys de posição redundantes (Douglas-Peucker no tempo). */
    private fun simplifyPos(l: List<Pair<Int, FloatArray>>, tol: Float): List<Pair<Int, FloatArray>> {
        if (l.size <= 2) return l
        val keep = BooleanArray(l.size); keep[0] = true; keep[l.size - 1] = true
        val st = ArrayDeque<IntArray>(); st.addLast(intArrayOf(0, l.size - 1))
        while (st.isNotEmpty()) {
            val (a, b) = st.removeLast()
            if (b - a < 2) continue
            var worst = -1; var wv = 0f
            val fa = l[a].first; val fb = l[b].first
            for (i in a + 1 until b) {
                val t = if (fb == fa) 0f else (l[i].first - fa).toFloat() / (fb - fa)
                val p0 = l[a].second; val p1 = l[b].second; val p = l[i].second
                var e = 0f
                for (c in 0..2) { val dd = p[c] - (p0[c] + (p1[c] - p0[c]) * t); e += dd * dd }
                e = sqrt(e)
                if (e > wv) { wv = e; worst = i }
            }
            if (worst >= 0 && wv > tol) { keep[worst] = true; st.addLast(intArrayOf(a, worst)); st.addLast(intArrayOf(worst, b)) }
        }
        return l.filterIndexed { i, _ -> keep[i] }
    }
}
