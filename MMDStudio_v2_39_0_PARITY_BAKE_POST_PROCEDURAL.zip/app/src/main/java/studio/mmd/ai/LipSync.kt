package studio.mmd.ai

import kotlin.math.*

/**
 * v1.36.0 — Lipsync automático por áudio (lógica pura, sem Android; testável na JVM).
 *
 * Método: para cada quadro da timeline, uma janela de ~32 ms do áudio (mono) é analisada por LPC; do envelope espectral saem os
 * dois primeiros formantes (F1, F2), classificados na vogal japonesa mais próxima (あ い う え お). A abertura da boca vem da
 * energia (dB) relativa ao trecho mais forte do áudio. A saída são keyframes de peso por vogal, já esparsos, prontos para
 * `Editor.applyAnim`. Não reconhece palavras nem idioma: segue o som, então funciona com qualquer língua, mas é uma aproximação
 * (consoantes viram boca quase fechada; ruído/música forte podem gerar vogais falsas — a sensibilidade existe por isso).
 */
object LipSync {
    val VOWELS = listOf("a", "i", "u", "e", "o")

    class Options(
        val fps: Int = 30,
        /** 0..1: maior pega sons mais fracos (porta de ruído mais baixa). */
        val sensitivity: Float = 0.5f,
        /** 0..1.5: multiplica a abertura final (o peso nunca passa de 1). */
        val intensity: Float = 1f,
        /** Mesmo sentido do painel Áudio: positivo = o áudio entra depois da animação. */
        val offsetMs: Int = 0
    )

    class Result(
        /** vogal ("a","i","u","e","o") → keys (quadro, peso). Vogais sem fala ficam de fora. */
        val keys: Map<String, List<Pair<Int, Float>>>,
        /** Faixa de quadros analisada (o chamador apaga as keys antigas dos morphs dentro dela). */
        val from: Int, val to: Int,
        val voiced: Int, val total: Int
    ) { val isEmpty get() = keys.isEmpty() }

    // protótipos (F1, F2) em Hz das vogais do japonês
    private val proto = arrayOf(
        floatArrayOf(800f, 1350f),  // a
        floatArrayOf(300f, 2300f),  // i
        floatArrayOf(350f, 1250f),  // u
        floatArrayOf(520f, 1900f),  // e
        floatArrayOf(500f, 900f)    // o
    )
    // quanto a boca abre em cada vogal (a abre mais; i/u menos)
    private val openFactor = floatArrayOf(1.0f, 0.65f, 0.7f, 0.85f, 0.9f)

    /** PCM 16-bit little-endian intercalado → mono em [-1,1], com anti-alias simples e no máximo 16 kHz. Devolve (amostras, taxa). */
    fun toMono(pcm: ByteArray, rate: Int, channels: Int): Pair<FloatArray, Int> {
        val ch = max(1, channels)
        val frames = pcm.size / 2 / ch
        val mono = FloatArray(frames)
        for (i in 0 until frames) {
            var s = 0f
            for (c in 0 until ch) {
                val o = (i * ch + c) * 2
                s += ((pcm[o].toInt() and 0xFF) or (pcm[o + 1].toInt() shl 8)).toShort() / 32768f
            }
            mono[i] = s / ch
        }
        if (rate <= 16000) return mono to rate
        val ratio = rate / 16000f
        val n = (frames / ratio).toInt()
        val out = FloatArray(n)
        for (i in 0 until n) {
            val a = (i * ratio).toInt(); val b = min(frames, max(a + 1, ((i + 1) * ratio).toInt()))
            var s = 0f; for (k in a until b) s += mono[k]
            out[i] = s / (b - a)
        }
        return out to 16000
    }

    fun analyze(x: FloatArray, sr: Int, o: Options): Result {
        if (x.isEmpty() || sr < 4000) return Result(emptyMap(), 0, 0, 0, 0)
        val fps = max(1, o.fps)
        val offFr = o.offsetMs / 1000f * fps
        val durSec = x.size.toFloat() / sr
        val f0 = max(0, ceil(offFr).toInt())
        val f1 = floor(durSec * fps + offFr).toInt()
        if (f1 < f0) return Result(emptyMap(), 0, 0, 0, 0)
        val nF = f1 - f0 + 1
        val win = max(64, (0.032f * sr).toInt())
        val order = if (sr >= 16000) 14 else 10
        val hamming = FloatArray(win) { (0.54 - 0.46 * cos(2.0 * PI * it / (win - 1))).toFloat() }
        val buf = FloatArray(win); val ac = DoubleArray(order + 1)
        val db = FloatArray(nF); val label = IntArray(nF) { -1 }; val fric = BooleanArray(nF)
        val freqs = FloatArray(96) { 150f + (3300f - 150f) * it / 95f }
        val cosT = Array(freqs.size) { k -> DoubleArray(order + 1) { i -> cos(2.0 * PI * freqs[k] / sr * i) } }
        val sinT = Array(freqs.size) { k -> DoubleArray(order + 1) { i -> sin(2.0 * PI * freqs[k] / sr * i) } }
        val env = DoubleArray(freqs.size)

        for (j in 0 until nF) {
            val tc = (f0 + j - offFr) / fps                        // tempo no áudio (s)
            val start = (tc * sr).toInt() - win / 2
            var e = 0.0; var zc = 0
            for (i in 0 until win) { val idx = start + i; val v = if (idx in x.indices) x[idx] else 0f; buf[i] = v * hamming[i]; e += buf[i] * buf[i] }
            db[j] = (10.0 * log10(e / win + 1e-12)).toFloat()
            for (i in 1 until win) if ((buf[i] >= 0f) != (buf[i - 1] >= 0f)) zc++
            fric[j] = zc.toFloat() / win > 0.30f
            // pré-ênfase para realçar os formantes
            for (i in win - 1 downTo 1) buf[i] = buf[i] - 0.97f * buf[i - 1]
            for (k in 0..order) { var s = 0.0; for (i in k until win) s += buf[i].toDouble() * buf[i - k]; ac[k] = s }
            if (ac[0] < 1e-9) continue
            ac[0] *= 1.0001
            val a = levinson(ac, order) ?: continue
            for (k in freqs.indices) {
                var re = 1.0; var im = 0.0
                for (i in 1..order) { re += a[i] * cosT[k][i]; im -= a[i] * sinT[k][i] }
                env[k] = 1.0 / (re * re + im * im + 1e-12)
            }
            // picos do envelope
            var p1 = -1f; var p2 = -1f
            for (k in 1 until freqs.size - 1) {
                if (env[k] > env[k - 1] && env[k] >= env[k + 1]) {
                    val f = freqs[k]
                    if (p1 < 0f) { if (f >= 200f) p1 = f }
                    else if (p2 < 0f && f > p1 + 250f) p2 = f
                }
            }
            if (p1 < 0f) continue
            if (p2 < 0f) p2 = 1500f
            var best = 0; var bd = Float.MAX_VALUE
            for (v in 0..4) {
                val d1 = (p1 - proto[v][0]) / 150f; val d2 = (p2 - proto[v][1]) / 350f
                val d = d1 * d1 + d2 * d2
                if (d < bd) { bd = d; best = v }
            }
            label[j] = best
        }

        // abertura pela energia relativa
        val sorted = db.sortedArray()
        val ref = sorted[(0.95f * (nF - 1)).toInt()]
        val range = 18f + 22f * o.sensitivity.coerceIn(0f, 1f)
        val gate = ref - range
        // porta absoluta: áudio quase silencioso não vira fala
        val absGate = -62f
        val open = FloatArray(nF)
        var voiced = 0
        for (j in 0 until nF) {
            if (label[j] < 0 || db[j] < gate || db[j] < absGate) { label[j] = -1; continue }
            var op = ((db[j] - gate) / max(1f, ref - gate)).coerceIn(0f, 1f).pow(0.7f)
            if (fric[j]) { label[j] = 1; op *= 0.35f }             // sons de "s/sh/f": boca quase fechada
            open[j] = op; voiced++
        }
        // filtro de moda (3 quadros) nos rótulos para evitar tremedeira de vogal
        val lab2 = label.copyOf()
        for (j in 1 until nF - 1) {
            if (label[j] < 0) continue
            val l = label[j - 1]; val r = label[j + 1]
            if (l >= 0 && l == r && l != label[j]) lab2[j] = l
        }
        // pesos por vogal e suavização [.25 .5 .25]
        val inten = o.intensity.coerceIn(0f, 1.5f)
        val arr = Array(5) { FloatArray(nF) }
        for (j in 0 until nF) { val l = lab2[j]; if (l >= 0) arr[l][j] = (open[j] * openFactor[l] * inten).coerceIn(0f, 1f) }
        val sm = Array(5) { v ->
            FloatArray(nF) { j ->
                val p = if (j > 0) arr[v][j - 1] else 0f; val n = if (j < nF - 1) arr[v][j + 1] else 0f
                val r = 0.25f * p + 0.5f * arr[v][j] + 0.25f * n
                if (r < 0.04f) 0f else (round(r.coerceAtMost(1f) * 100f) / 100f)
            }
        }
        val keys = LinkedHashMap<String, List<Pair<Int, Float>>>()
        for (v in 0..4) {
            val s = sm[v]
            if (s.all { it == 0f }) continue
            val out = ArrayList<Pair<Int, Float>>()
            for (j in 0 until nF) {
                val p = if (j > 0) s[j - 1] else 0f; val n = if (j < nF - 1) s[j + 1] else 0f
                val keep = j == 0 || j == nF - 1 && s[j] != 0f ||
                    abs(s[j] - (p + n) / 2f) > 0.04f || (s[j] != 0f && (p == 0f || n == 0f)) || (s[j] == 0f && (p != 0f || n != 0f))
                if (keep) out.add((f0 + j) to s[j])
            }
            keys[VOWELS[v]] = out
        }
        return Result(keys, f0, f1, voiced, nF)
    }

    private fun levinson(r: DoubleArray, p: Int): DoubleArray? {
        val a = DoubleArray(p + 1); a[0] = 1.0
        var err = r[0]
        if (err <= 0) return null
        val tmp = DoubleArray(p + 1)
        for (i in 1..p) {
            var acc = r[i]
            for (j in 1 until i) acc += a[j] * r[i - j]
            val k = -acc / err
            for (j in 1 until i) tmp[j] = a[j] + k * a[i - j]
            for (j in 1 until i) a[j] = tmp[j]
            a[i] = k
            err *= (1 - k * k)
            if (err <= 1e-12) return null
        }
        return a
    }

    // ---------- mapeamento de vogais para morphs do modelo ----------
    private fun norm(s: String) = s.trim().lowercase().filter { !it.isWhitespace() && it != '_' && it != '-' }
    private val names = mapOf(
        "a" to listOf("あ", "a", "あー", "vowela", "moutha", "aa", "ah", "lipa", "visemea", "ア"),
        "i" to listOf("い", "i", "いー", "voweli", "mouthi", "ii", "ih", "lipi", "visemei", "イ"),
        "u" to listOf("う", "u", "うー", "vowelu", "mouthu", "uu", "oo", "lipu", "visemeu", "ウ"),
        "e" to listOf("え", "e", "えー", "vowele", "mouthe", "ee", "eh", "lipe", "visemee", "エ"),
        "o" to listOf("お", "o", "おー", "vowelo", "moutho", "oh", "lipo", "visemeo", "オ")
    )

    /** vogal → nome do morph do modelo (por nome JP ou EN exato, ignorando caixa/espaços). Só as encontradas entram. */
    fun findMorphs(morphs: List<Pair<String, String>>): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((v, cands) in names) {
            val set = cands.map { norm(it) }.toSet()
            val hit = morphs.firstOrNull { norm(it.first) in set } ?: morphs.firstOrNull { norm(it.second) in set }
            if (hit != null) out[v] = hit.first
        }
        return out
    }

    /** Converte o resultado em keys por nome de morph (só vogais que o modelo tem). */
    fun toMorphKeys(r: Result, map: Map<String, String>): Map<String, List<Pair<Int, Float>>> {
        val o = LinkedHashMap<String, List<Pair<Int, Float>>>()
        for ((v, ks) in r.keys) map[v]?.let { o[it] = ks }
        return o
    }
}
