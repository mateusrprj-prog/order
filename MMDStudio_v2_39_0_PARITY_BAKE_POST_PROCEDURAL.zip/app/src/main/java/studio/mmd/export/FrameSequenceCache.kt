package studio.mmd.export

import java.io.File
import java.util.zip.CRC32

/** Cache de PNGs por quadro com assinatura do trabalho e checksum; permite retomar exportação interrompida. */
class FrameSequenceCache(private val directory: File, signature: String) {
    val signature: String = signature
    init {
        require(signature.isNotBlank()) { "Assinatura do render vazia" }
        if (!directory.exists()) directory.mkdirs()
        val marker = File(directory, "job.signature")
        val existing = marker.takeIf { it.isFile }?.readText(Charsets.UTF_8)
        if (existing != signature) {
            directory.listFiles()?.forEach { it.deleteRecursively() }
            directory.mkdirs()
            val tmp = File(directory, "job.signature.tmp")
            tmp.writeText(signature, Charsets.UTF_8)
            if (!tmp.renameTo(marker)) { tmp.copyTo(marker, overwrite = true); tmp.delete() }
        }
    }

    fun writeFrame(frame: Int, png: ByteArray) {
        require(frame >= 0 && png.isNotEmpty()) { "Quadro ou PNG inválido" }
        val dataFile = frameFile(frame); val metaFile = metaFile(frame)
        val dataTmp = File(directory, dataFile.name + ".tmp")
        val metaTmp = File(directory, metaFile.name + ".tmp")
        dataTmp.writeBytes(png)
        val crc = CRC32().apply { update(png) }.value
        metaTmp.writeText("${png.size}:$crc", Charsets.US_ASCII)
        if (!dataTmp.renameTo(dataFile)) { dataTmp.copyTo(dataFile, overwrite = true); dataTmp.delete() }
        if (!metaTmp.renameTo(metaFile)) { metaTmp.copyTo(metaFile, overwrite = true); metaTmp.delete() }
    }

    fun readFrame(frame: Int): ByteArray? {
        if (frame < 0) return null
        val data = frameFile(frame); val meta = metaFile(frame)
        if (!data.isFile || !meta.isFile) return null
        return runCatching {
            val bytes = data.readBytes()
            val fields = meta.readText(Charsets.US_ASCII).split(':')
            require(fields.size == 2 && fields[0].toInt() == bytes.size)
            val crc = CRC32().apply { update(bytes) }.value
            require(fields[1].toLong() == crc)
            require(bytes.size >= 8 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte()) { "Arquivo não é PNG" }
            bytes
        }.getOrNull()
    }

    fun completedFrames(total: Int): Int = (0 until total.coerceAtLeast(0)).count { readFrame(it) != null }
    fun validFrames(total: Int): List<Int> = (0 until total.coerceAtLeast(0)).filter { readFrame(it) != null }
    fun clear() { directory.listFiles()?.forEach { it.deleteRecursively() }; directory.delete() }
    private fun frameFile(frame: Int) = File(directory, "frame_%06d.png".format(frame))
    private fun metaFile(frame: Int) = File(directory, "frame_%06d.crc".format(frame))
}
