package studio.mmd.export

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * v2.38.0 — Fundo de imagem/vídeo (AVI/imagem de fundo do MMD oficial), guias de enquadramento e presets de saída.
 * Kotlin puro. A decodificação de imagem/vídeo fica com quem integra; aqui há geometria, tempo e composição.
 */
enum class BgFit { CONTAIN, COVER, STRETCH, CENTER }
enum class BgLoop { ONCE, LOOP, PING_PONG }

class BgRect(val dx: Int, val dy: Int, val dw: Int, val dh: Int)

object BgLayer {
    /** Retângulo de destino (pode sair da tela em COVER/CENTER) para uma fonte [sw]x[sh] em uma saída [w]x[h]. */
    fun place(fit: BgFit, sw: Int, sh: Int, w: Int, h: Int, zoom: Float = 1f, panX: Float = 0f, panY: Float = 0f): BgRect {
        if (sw < 1 || sh < 1 || w < 1 || h < 1) return BgRect(0, 0, max(w, 0), max(h, 0))
        val z = if (zoom.isFinite()) zoom.coerceIn(0.1f, 10f) else 1f
        var rw: Float; var rh: Float
        when (fit) {
            BgFit.STRETCH -> { rw = w.toFloat(); rh = h.toFloat() }
            BgFit.CENTER -> { rw = sw.toFloat(); rh = sh.toFloat() }
            BgFit.CONTAIN -> { val s = min(w.toFloat() / sw, h.toFloat() / sh); rw = sw * s; rh = sh * s }
            BgFit.COVER -> { val s = max(w.toFloat() / sw, h.toFloat() / sh); rw = sw * s; rh = sh * s }
        }
        rw *= z; rh *= z
        val px = if (panX.isFinite()) panX else 0f; val py = if (panY.isFinite()) panY else 0f
        return BgRect(((w - rw) / 2f + px * w).roundToInt(), ((h - rh) / 2f + py * h).roundToInt(), rw.roundToInt().coerceAtLeast(1), rh.roundToInt().coerceAtLeast(1))
    }

    /**
     * Quadro do vídeo de fundo para o quadro de animação [frame]. [offsetFrames] atrasa/adianta o início,
     * [speed] > 0 acelera. Devolve o índice de quadro do vídeo (0..videoFrames-1).
     */
    fun videoFrame(frame: Int, fps: Float, videoFps: Float, videoFrames: Int, loop: BgLoop, offsetFrames: Int = 0, speed: Float = 1f): Int {
        if (videoFrames < 1 || !fps.isFinite() || fps <= 0f || !videoFps.isFinite() || videoFps <= 0f) return 0
        val sp = if (speed.isFinite() && speed > 0f) speed else 1f
        val t = (frame - offsetFrames).coerceAtLeast(0) / fps * sp
        val idx = (t * videoFps).toLong()
        return when (loop) {
            BgLoop.ONCE -> idx.coerceAtMost((videoFrames - 1).toLong()).toInt()
            BgLoop.LOOP -> (idx % videoFrames).toInt()
            BgLoop.PING_PONG -> {
                if (videoFrames == 1) 0 else { val period = 2L * (videoFrames - 1); val m = (idx % period).toInt(); if (m < videoFrames) m else (period - m).toInt() }
            }
        }
    }

    /**
     * Compõe o render (ARGB, alpha direto) sobre o fundo já redimensionado ao tamanho da saída. [bgOpacity] 0..1.
     * Onde o render é transparente aparece o fundo; o resultado sai opaco.
     */
    fun compositeOver(w: Int, h: Int, fg: IntArray, bg: IntArray, bgOpacity: Float = 1f): IntArray {
        require(w > 0 && h > 0 && fg.size == w * h && bg.size == w * h) { "Dimensões de imagem inválidas" }
        val bo = if (bgOpacity.isFinite()) bgOpacity.coerceIn(0f, 1f) else 1f
        val out = IntArray(fg.size)
        for (i in fg.indices) {
            val f = fg[i]; val b = bg[i]
            val a = ((f ushr 24) and 255) / 255f
            fun mix(sh: Int): Int { val fc = (f ushr sh) and 255; val bc = ((b ushr sh) and 255) * bo; return (fc * a + bc * (1f - a) + 0.5f).toInt().coerceIn(0, 255) }
            out[i] = (0xFF shl 24) or (mix(16) shl 16) or (mix(8) shl 8) or mix(0)
        }
        return out
    }

    /** Reamostra [src] (sw x sh) para o retângulo [r] dentro de uma tela w x h, vizinho mais próximo; fora da imagem fica [fill]. */
    fun render(src: IntArray, sw: Int, sh: Int, w: Int, h: Int, r: BgRect, fill: Int = 0xFF000000.toInt()): IntArray {
        require(sw > 0 && sh > 0 && src.size == sw * sh && w > 0 && h > 0) { "Dimensões de imagem inválidas" }
        val out = IntArray(w * h) { fill }
        for (y in 0 until h) {
            val v = y - r.dy
            if (v < 0 || v >= r.dh) continue
            val sy = (v.toLong() * sh / r.dh).toInt().coerceIn(0, sh - 1)
            for (x in 0 until w) {
                val u = x - r.dx
                if (u < 0 || u >= r.dw) continue
                out[y * w + x] = src[sy * sw + (u.toLong() * sw / r.dw).toInt().coerceIn(0, sw - 1)]
            }
        }
        return out
    }
}

class OutputPreset(val id: String, val label: String, val width: Int, val height: Int, val fps: Int) {
    val aspect get() = width.toFloat() / height
}

object OutputPresets {
    val ALL = listOf(
        OutputPreset("mmd_default", "MMD padrão 4:3 (1024×768)", 1024, 768, 30),
        OutputPreset("hd720", "HD 720p (1280×720)", 1280, 720, 30),
        OutputPreset("fhd", "Full HD (1920×1080)", 1920, 1080, 30),
        OutputPreset("fhd60", "Full HD 60 fps", 1920, 1080, 60),
        OutputPreset("qhd", "QHD (2560×1440)", 2560, 1440, 30),
        OutputPreset("uhd", "4K UHD (3840×2160)", 3840, 2160, 30),
        OutputPreset("vertical", "Vertical 9:16 (1080×1920)", 1080, 1920, 30),
        OutputPreset("square", "Quadrado 1:1 (1080×1080)", 1080, 1080, 30),
        OutputPreset("cinema", "Cinemascope 2.39:1 (1920×804)", 1920, 804, 24),
        OutputPreset("film24", "Cinema 24 fps (1920×1080)", 1920, 1080, 24)
    )

    fun byId(id: String) = ALL.firstOrNull { it.id == id }

    /** Mantém a proporção do [preset] dentro de [maxPixels] (limite de memória do aparelho), arredondando para par. */
    fun fitToBudget(preset: OutputPreset, maxPixels: Long): Pair<Int, Int> {
        if (maxPixels < 4) return 2 to 2
        val px = preset.width.toLong() * preset.height
        if (px <= maxPixels) return even(preset.width) to even(preset.height)
        val s = Math.sqrt(maxPixels.toDouble() / px)
        return even((preset.width * s).toInt()) to even((preset.height * s).toInt())
    }

    private fun even(v: Int) = max(2, v and 1.inv())
}

/** Guias de enquadramento (regra dos terços, áreas seguras, centro) como segmentos x0,y0,x1,y1 normalizados 0..1. */
object FrameGuides {
    fun thirds(): FloatArray = floatArrayOf(1f / 3, 0f, 1f / 3, 1f, 2f / 3, 0f, 2f / 3, 1f, 0f, 1f / 3, 1f, 1f / 3, 0f, 2f / 3, 1f, 2f / 3)
    fun center(): FloatArray = floatArrayOf(0.5f, 0f, 0.5f, 1f, 0f, 0.5f, 1f, 0.5f)
    /** Retângulo de área segura (0.9 = título, 0.93 = ação) como 4 segmentos. */
    fun safe(fraction: Float): FloatArray {
        val m = ((1f - fraction.coerceIn(0.5f, 1f)) / 2f)
        return floatArrayOf(m, m, 1 - m, m, 1 - m, m, 1 - m, 1 - m, 1 - m, 1 - m, m, 1 - m, m, 1 - m, m, m)
    }
    /** Máscara de letterbox para uma proporção alvo dentro da tela: devolve a faixa visível (x, y, w, h normalizados). */
    fun letterbox(targetAspect: Float, screenAspect: Float): FloatArray {
        if (!targetAspect.isFinite() || targetAspect <= 0f || !screenAspect.isFinite() || screenAspect <= 0f) return floatArrayOf(0f, 0f, 1f, 1f)
        return if (targetAspect >= screenAspect) { val h = screenAspect / targetAspect; floatArrayOf(0f, (1 - h) / 2, 1f, h) }
        else { val w = targetAspect / screenAspect; floatArrayOf((1 - w) / 2, 0f, w, 1f) }
    }
}
