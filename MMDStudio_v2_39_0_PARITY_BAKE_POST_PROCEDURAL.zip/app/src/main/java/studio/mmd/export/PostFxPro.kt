package studio.mmd.export

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * v2.38.0 — Efeitos de pós do MMD oficial que faltavam: bloom (brilho), profundidade de campo (DoF), desfoque de movimento
 * (acumulação de sub-quadros), correção de cor lift/gamma/gain, nitidez e anti-serrilhado (FXAA simplificado).
 *
 * CPU, determinístico, Kotlin puro; opera em ARGB de 8 bits por canal e preserva o alpha de entrada.
 * Complementa [PixelCompositor]; use depois dele ou no lugar dele na exportação.
 */
data class BloomConfig(val threshold: Float = 0.75f, val intensity: Float = 0.6f, val radius: Int = 8, val passes: Int = 2) {
    fun sanitized() = BloomConfig(
        threshold.fin(0.75f).coerceIn(0f, 1f), intensity.fin(0.6f).coerceIn(0f, 4f), radius.coerceIn(1, 64), passes.coerceIn(1, 4)
    )
}

data class DofConfig(
    /** Distância (unidades de cena) do plano de foco. */
    val focusDistance: Float = 30f,
    /** Largura da faixa totalmente nítida em torno do foco (unidades). */
    val focusRange: Float = 4f,
    /** Raio máximo do círculo de confusão em pixels. */
    val maxRadius: Int = 12,
    /** Quão rápido o desfoque cresce fora da faixa (1 = proporcional à distância relativa). */
    val falloff: Float = 1f
) {
    fun sanitized() = DofConfig(focusDistance.fin(30f).coerceAtLeast(0.01f), focusRange.fin(4f).coerceAtLeast(0f), maxRadius.coerceIn(0, 48), falloff.fin(1f).coerceIn(0.1f, 8f))
}

data class GradeConfig(
    /** Lift (sombras), gamma (meios-tons) e gain (altas-luzes) por canal RGB; neutro = 0, 1, 1. */
    val lift: FloatArray = floatArrayOf(0f, 0f, 0f),
    val gamma: FloatArray = floatArrayOf(1f, 1f, 1f),
    val gain: FloatArray = floatArrayOf(1f, 1f, 1f),
    /** Temperatura (-1 frio .. +1 quente) e matiz (-1 verde .. +1 magenta). */
    val temperature: Float = 0f,
    val tint: Float = 0f
) {
    val isNeutral get() = lift.all { it == 0f } && gamma.all { it == 1f } && gain.all { it == 1f } && temperature == 0f && tint == 0f
}

private fun Float.fin(d: Float) = if (isFinite()) this else d

object PostFxPro {

    private fun check(w: Int, h: Int, n: Int) = require(w > 0 && h > 0 && n == w * h) { "Dimensões de imagem inválidas" }

    private fun planes(src: IntArray): Array<FloatArray> {
        val r = FloatArray(src.size); val g = FloatArray(src.size); val b = FloatArray(src.size)
        for (i in src.indices) { val c = src[i]; r[i] = ((c ushr 16) and 255) / 255f; g[i] = ((c ushr 8) and 255) / 255f; b[i] = (c and 255) / 255f }
        return arrayOf(r, g, b)
    }

    private fun pack(src: IntArray, p: Array<FloatArray>): IntArray {
        val out = IntArray(src.size)
        for (i in src.indices) {
            val r = (p[0][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt(); val g = (p[1][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt(); val b = (p[2][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            out[i] = (src[i] and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
        return out
    }

    /** Desfoque de caixa separável com bordas replicadas; [radius] 0 devolve cópia. */
    fun boxBlur(w: Int, h: Int, plane: FloatArray, radius: Int): FloatArray {
        check(w, h, plane.size)
        if (radius <= 0) return plane.copyOf()
        val tmp = FloatArray(plane.size); val out = FloatArray(plane.size)
        val d = (radius * 2 + 1).toFloat()
        for (y in 0 until h) {
            val row = y * w
            var sum = 0f
            for (k in -radius..radius) sum += plane[row + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                sum += plane[row + (x + radius + 1).coerceAtMost(w - 1)] - plane[row + (x - radius).coerceAtLeast(0)]
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (k in -radius..radius) sum += tmp[k.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / d
                sum += tmp[(y + radius + 1).coerceAtMost(h - 1) * w + x] - tmp[(y - radius).coerceAtLeast(0) * w + x]
            }
        }
        return out
    }

    // ------------------------------------------------------------ bloom

    fun bloom(w: Int, h: Int, src: IntArray, config: BloomConfig): IntArray {
        check(w, h, src.size)
        val c = config.sanitized()
        if (c.intensity <= 0f) return src.copyOf()
        val p = planes(src)
        val bright = Array(3) { FloatArray(src.size) }
        val denom = (1f - c.threshold).coerceAtLeast(1e-3f)
        for (i in src.indices) {
            val l = 0.2126f * p[0][i] + 0.7152f * p[1][i] + 0.0722f * p[2][i]
            val k = ((l - c.threshold) / denom).coerceIn(0f, 1f)
            for (ch in 0..2) bright[ch][i] = p[ch][i] * k
        }
        val glow = Array(3) { ch ->
            var cur = bright[ch]
            repeat(c.passes) { cur = boxBlur(w, h, cur, c.radius) }
            cur
        }
        // Soma aditiva com compressão suave para não estourar tons já claros.
        val out = Array(3) { FloatArray(src.size) }
        for (ch in 0..2) for (i in src.indices) { val v = p[ch][i] + glow[ch][i] * c.intensity * 3f; out[ch][i] = v / (1f + max(0f, v - 1f)) }
        return pack(src, out)
    }

    // ------------------------------------------------------------ profundidade de campo

    /** Raio (px) do círculo de confusão para uma profundidade. 0 dentro da faixa de foco. */
    fun cocRadius(depth: Float, c: DofConfig): Float {
        val cfg = c.sanitized()
        if (!depth.isFinite()) return cfg.maxRadius.toFloat()
        val d = abs(depth - cfg.focusDistance) - cfg.focusRange / 2f
        if (d <= 0f) return 0f
        val rel = d / cfg.focusDistance * cfg.falloff
        return (rel * cfg.maxRadius * 2f).coerceIn(0f, cfg.maxRadius.toFloat())
    }

    /** Raio (px) de CoC por física de lente fina: [aperture] f-number, [focalMm], [sensorMm]; para ajustar o DofConfig a uma câmera real. */
    fun physicalCoc(depth: Float, focus: Float, focalMm: Float, fNumber: Float, sensorMm: Float, imageWidthPx: Int): Float {
        if (depth <= 0f || focus <= focalMm / 1000f || fNumber <= 0f || sensorMm <= 0f) return 0f
        val f = focalMm; val s1 = focus * 1000f; val s2 = depth * 1000f
        val cocMm = abs(s2 - s1) / s2 * (f * f) / (fNumber * (s1 - f))
        return (cocMm / sensorMm * imageWidthPx / 2f).coerceAtLeast(0f)
    }

    /**
     * DoF por camadas: gera versões desfocadas em raios crescentes e interpola por pixel conforme o CoC da profundidade.
     * [depth] tem a distância da câmera por pixel (mesmo tamanho da imagem).
     */
    fun depthOfField(w: Int, h: Int, src: IntArray, depth: FloatArray, config: DofConfig): IntArray {
        check(w, h, src.size)
        require(depth.size == src.size) { "Mapa de profundidade com tamanho diferente da imagem" }
        val c = config.sanitized()
        if (c.maxRadius == 0) return src.copyOf()
        val p = planes(src)
        val levels = ArrayList<Int>(); var r = 0
        while (r < c.maxRadius) { levels.add(r); r = if (r == 0) 1 else min(c.maxRadius, r * 2) }
        levels.add(c.maxRadius)
        val layers = levels.distinct().map { rad -> rad to Array(3) { ch -> boxBlur(w, h, p[ch], rad) } }
        val out = Array(3) { FloatArray(src.size) }
        for (i in src.indices) {
            val coc = cocRadius(depth[i], c)
            var lo = 0
            while (lo + 1 < layers.size && layers[lo + 1].first <= coc) lo++
            val hi = min(lo + 1, layers.size - 1)
            val span = (layers[hi].first - layers[lo].first).toFloat()
            val t = if (span <= 0f) 0f else ((coc - layers[lo].first) / span).coerceIn(0f, 1f)
            for (ch in 0..2) out[ch][i] = layers[lo].second[ch][i] * (1 - t) + layers[hi].second[ch][i] * t
        }
        return pack(src, out)
    }

    // ------------------------------------------------------------ desfoque de movimento

    /** Instantes (em quadros, relativos ao quadro atual) dos sub-quadros: obturador em graus (180 = meio quadro). Centrados em 0. */
    fun shutterOffsets(samples: Int, shutterAngleDeg: Float): FloatArray {
        val n = samples.coerceIn(1, 64)
        if (n == 1) return floatArrayOf(0f)
        val span = (shutterAngleDeg.fin(180f).coerceIn(0f, 720f)) / 360f
        return FloatArray(n) { (it / (n - 1f) - 0.5f) * span }
    }

    /** Média ponderada de sub-quadros renderizados em [shutterOffsets]. Pesos nulos = iguais. */
    fun accumulate(w: Int, h: Int, frames: List<IntArray>, weights: FloatArray? = null): IntArray {
        require(frames.isNotEmpty()) { "Sem sub-quadros" }
        for (f in frames) check(w, h, f.size)
        val n = frames.size
        val wt = FloatArray(n) { weights?.getOrNull(it)?.takeIf { v -> v.isFinite() && v >= 0f } ?: 1f }
        val total = wt.sum().takeIf { it > 1e-8f } ?: n.toFloat()
        val out = IntArray(w * h)
        for (i in out.indices) {
            var a = 0f; var r = 0f; var g = 0f; var b = 0f
            for (k in 0 until n) {
                val c = frames[k][i]; val q = wt[k]
                a += ((c ushr 24) and 255) * q; r += ((c ushr 16) and 255) * q; g += ((c ushr 8) and 255) * q; b += (c and 255) * q
            }
            out[i] = ((a / total + 0.5f).toInt().coerceIn(0, 255) shl 24) or ((r / total + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                ((g / total + 0.5f).toInt().coerceIn(0, 255) shl 8) or (b / total + 0.5f).toInt().coerceIn(0, 255)
        }
        return out
    }

    // ------------------------------------------------------------ cor

    fun colorGrade(w: Int, h: Int, src: IntArray, g: GradeConfig): IntArray {
        check(w, h, src.size)
        if (g.isNeutral) return src.copyOf()
        val p = planes(src)
        val warm = g.temperature.fin(0f).coerceIn(-1f, 1f) * 0.15f
        val tint = g.tint.fin(0f).coerceIn(-1f, 1f) * 0.10f
        for (i in src.indices) {
            for (ch in 0..2) {
                var v = p[ch][i]
                v = v * (g.gain.getOrElse(ch) { 1f }.fin(1f)) + g.lift.getOrElse(ch) { 0f }.fin(0f) * (1f - v)
                val gm = g.gamma.getOrElse(ch) { 1f }.fin(1f).coerceAtLeast(0.05f)
                v = v.coerceIn(0f, 1f).pow(1f / gm)
                p[ch][i] = v
            }
            p[0][i] += warm + tint * 0.5f; p[2][i] -= warm - tint * 0.5f; p[1][i] -= tint
        }
        return pack(src, p)
    }

    fun sharpen(w: Int, h: Int, src: IntArray, amount: Float, radius: Int = 1): IntArray {
        check(w, h, src.size)
        val a = amount.fin(0f).coerceIn(0f, 4f)
        if (a == 0f) return src.copyOf()
        val p = planes(src)
        val out = Array(3) { ch -> val blur = boxBlur(w, h, p[ch], radius.coerceIn(1, 8)); FloatArray(src.size) { p[ch][it] + (p[ch][it] - blur[it]) * a } }
        return pack(src, out)
    }

    /** Anti-serrilhado em tela: onde o contraste de luma é alto, mistura o pixel com a média dos vizinhos. */
    fun fxaa(w: Int, h: Int, src: IntArray, edgeThreshold: Float = 0.08f, strength: Float = 0.75f): IntArray {
        check(w, h, src.size)
        val p = planes(src)
        val luma = FloatArray(src.size) { 0.299f * p[0][it] + 0.587f * p[1][it] + 0.114f * p[2][it] }
        val out = Array(3) { p[it].copyOf() }
        val s = strength.fin(0.75f).coerceIn(0f, 1f); val th = edgeThreshold.fin(0.08f).coerceIn(0.01f, 1f)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val l = luma[i]; val n = luma[i - w]; val so = luma[i + w]; val e = luma[i + 1]; val wv = luma[i - 1]
            val range = max(max(n, so), max(max(e, wv), l)) - min(min(n, so), min(min(e, wv), l))
            if (range < th) continue
            val k = (s * ((range - th) / (range + 1e-6f) + 0.35f)).coerceIn(0f, 1f)
            for (ch in 0..2) {
                val avg = (p[ch][i - 1] + p[ch][i + 1] + p[ch][i - w] + p[ch][i + w] + p[ch][i] * 2f) / 6f
                out[ch][i] = p[ch][i] * (1 - k) + avg * k
            }
        }
        return pack(src, out)
    }
}
