package studio.mmd.export

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Ajustes não destrutivos de pós-produção aplicados somente durante a exportação. */
data class PostFxConfig(
    val enabled: Boolean = false,
    val exposure: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val vignette: Float = 0f,
    val grain: Float = 0f,
    val chromaticAberration: Float = 0f,
    val toneMap: Boolean = true,
    val seed: Int = 731
) {
    fun sanitized() = copy(
        exposure = exposure.finite(0f).coerceIn(-5f, 5f),
        contrast = contrast.finite(1f).coerceIn(0f, 3f),
        saturation = saturation.finite(1f).coerceIn(0f, 3f),
        vignette = vignette.finite(0f).coerceIn(0f, 1f),
        grain = grain.finite(0f).coerceIn(0f, 0.25f),
        chromaticAberration = chromaticAberration.finite(0f).coerceIn(0f, 8f)
    )
    private fun Float.finite(fallback: Float) = if (isFinite()) this else fallback
}

/** Compositor CPU determinístico; aceita ARGB pré-multiplicado ou normal e preserva alpha. */
object PixelCompositor {
    fun apply(width: Int, height: Int, source: IntArray, config: PostFxConfig): IntArray {
        require(width > 0 && height > 0 && source.size == width * height) { "Dimensões de imagem inválidas" }
        val c = config.sanitized()
        if (!c.enabled) return source.copyOf()
        val out = IntArray(source.size)
        val exposure = 2.0.pow(c.exposure.toDouble()).toFloat()
        val chroma = c.chromaticAberration.roundToIntSafe()
        val invW = 1f / max(width - 1, 1); val invH = 1f / max(height - 1, 1)
        for (y in 0 until height) for (x in 0 until width) {
            val idx = y * width + x
            val center = source[idx]
            var r = ((center ushr 16) and 255) / 255f
            var g = ((center ushr 8) and 255) / 255f
            var b = (center and 255) / 255f
            if (chroma > 0) {
                val left = source[y * width + max(0, x - chroma)]
                val right = source[y * width + min(width - 1, x + chroma)]
                r = ((left ushr 16) and 255) / 255f
                b = (right and 255) / 255f
            }
            r *= exposure; g *= exposure; b *= exposure
            val luma = .2126f * r + .7152f * g + .0722f * b
            r = luma + (r - luma) * c.saturation
            g = luma + (g - luma) * c.saturation
            b = luma + (b - luma) * c.saturation
            r = ((r - .18f) * c.contrast + .18f).coerceAtLeast(0f)
            g = ((g - .18f) * c.contrast + .18f).coerceAtLeast(0f)
            b = ((b - .18f) * c.contrast + .18f).coerceAtLeast(0f)
            if (c.toneMap) { r = aces(r); g = aces(g); b = aces(b) }
            val nx = x * invW * 2f - 1f; val ny = y * invH * 2f - 1f
            val radius = sqrt(nx * nx + ny * ny) / 1.41421356f
            val vig = (1f - c.vignette * radius * radius * .85f).coerceIn(0f, 1f)
            val noise = (hashNoise(idx, c.seed) - .5f) * c.grain
            r = (r * vig + noise).coerceIn(0f, 1f)
            g = (g * vig + noise).coerceIn(0f, 1f)
            b = (b * vig + noise).coerceIn(0f, 1f)
            val a = center ushr 24
            out[idx] = (a shl 24) or ((r * 255f + .5f).toInt() shl 16) or ((g * 255f + .5f).toInt() shl 8) or (b * 255f + .5f).toInt()
        }
        return out
    }

    private fun aces(x: Float): Float {
        val v = x.coerceAtLeast(0f)
        return ((v * (2.51f * v + .03f)) / (v * (2.43f * v + .59f) + .14f)).coerceIn(0f, 1f)
    }
    private fun hashNoise(index: Int, seed: Int): Float {
        var x = index * 0x45d9f3b + seed * 0x119de1f3
        x = (x xor (x ushr 16)) * 0x45d9f3b
        x = x xor (x ushr 16)
        return (x ushr 8).toFloat() / 16777215f
    }
    private fun Float.roundToIntSafe() = kotlin.math.floor(this + .5f).toInt()
}
