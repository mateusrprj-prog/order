package studio.mmd.util

/**
 * Logger simples por subsistema (v1.9.1). Guarda as últimas linhas em memória (exportáveis para diagnóstico)
 * e repassa ao Logcat quando roda no Android; em testes JVM só guarda no buffer.
 */
object Log {
    private const val MAX = 500
    private val lines = ArrayDeque<String>()

    @Synchronized private fun add(level: String, tag: String, msg: String) {
        lines.addLast("$level/$tag: $msg")
        while (lines.size > MAX) lines.removeFirst()
        try { android.util.Log.println(when (level) { "E" -> 6; "W" -> 5; else -> 4 }, "MMD-$tag", msg) } catch (_: Throwable) { /* JVM puro (testes) */ }
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) = add("E", tag, msg + (t?.let { " (${it.javaClass.simpleName}: ${it.message})" } ?: ""))

    @Synchronized fun dump(): String = lines.joinToString("\n")
    @Synchronized fun clear() = lines.clear()
}
