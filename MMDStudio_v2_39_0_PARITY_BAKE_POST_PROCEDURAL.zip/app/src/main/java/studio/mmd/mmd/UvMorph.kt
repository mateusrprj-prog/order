package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Morph de UV (PMX tipo 3, v1.12.3): deslocamentos U/V somados às coordenadas de textura dos vértices (peso * delta).
 * Morphs de UV adicional (tipos 4-7) NÃO são aplicados (o render não usa UVs adicionais).
 */
class UvMorph(val idx: IntArray, val d: FloatArray) {
    /** Soma o morph em [uv] (2 floats por vértice). Devolve true se algum vértice foi alterado. */
    fun apply(uv: FloatArray, w: Float): Boolean {
        if (w.isNaN() || w.isInfinite()) return false
        var any = false
        for (k in idx.indices) {
            val v = idx[k]
            if (v < 0 || v * 2 + 1 >= uv.size) continue
            uv[v * 2] += d[k * 2] * w; uv[v * 2 + 1] += d[k * 2 + 1] * w
            any = true
        }
        return any
    }

    companion object {
        /** Lê os bytes brutos preservados pelo parser. Tamanho do índice de vértice = raw.size / count - 16 (1, 2 ou 4 bytes, sem sinal). */
        fun decode(mo: PmxMorph): UvMorph? {
            val raw = mo.raw ?: return null
            if (mo.count <= 0 || raw.size % mo.count != 0) return null
            val size = raw.size / mo.count
            val vS = size - 16
            if (vS != 1 && vS != 2 && vS != 4) return null
            val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            val idx = IntArray(mo.count); val d = FloatArray(mo.count * 2)
            for (k in 0 until mo.count) {
                val o = k * size
                idx[k] = when (vS) { 1 -> bb.get(o).toInt() and 0xFF; 2 -> bb.getShort(o).toInt() and 0xFFFF; else -> bb.getInt(o) }
                d[k * 2] = bb.getFloat(o + vS); d[k * 2 + 1] = bb.getFloat(o + vS + 4)   // x, y do vec4 (z, w ignorados)
            }
            return UvMorph(idx, d)
        }
    }
}
