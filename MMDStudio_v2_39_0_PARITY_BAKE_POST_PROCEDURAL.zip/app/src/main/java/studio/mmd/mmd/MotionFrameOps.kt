package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * v2.29.0 — Operações de frame do MMD oficial (inserir/apagar frames, inverter trecho, reduzir keys).
 *
 * Tudo aqui é Kotlin puro (sem Android) e imutável: cada função devolve uma nova trilha/movimento.
 * Frames não finitos ou negativos nunca são produzidos; frames repetidos após a operação mantêm o último key.
 */
object MotionFrameOps {

    // ---------- utilidades internas ----------

    private class Key(val frame: Int, val v: FloatArray, val ip: ByteArray)

    private fun keysOf(t: VmdTrack): List<Key> {
        val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
        return List(n) { i -> Key(t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)) }
    }

    private fun build(list: List<Key>): VmdTrack {
        val sorted = list.sortedBy { it.frame }
        val out = ArrayList<Key>(sorted.size)
        for (k in sorted) {
            if (out.isNotEmpty() && out[out.size - 1].frame == k.frame) out[out.size - 1] = k else out.add(k)
        }
        val v = FloatArray(out.size * 7)
        val ip = ByteArray(out.size * 16)
        for (i in out.indices) {
            out[i].v.copyInto(v, i * 7)
            out[i].ip.copyInto(ip, i * 16)
        }
        return VmdTrack(IntArray(out.size) { out[it].frame }, v, ip)
    }

    /** Segmento Bézier invertido no tempo: (x1,y1,x2,y2) vira (1-x2,1-y2,1-x1,1-y1), em escala 0..127. */
    private fun flipIp(ip: ByteArray): ByteArray {
        val o = ByteArray(16)
        for (c in 0..3) {
            val x1 = ip[c].toInt() and 0xFF
            val y1 = ip[4 + c].toInt() and 0xFF
            val x2 = ip[8 + c].toInt() and 0xFF
            val y2 = ip[12 + c].toInt() and 0xFF
            o[c] = (127 - x2).coerceIn(0, 127).toByte()
            o[4 + c] = (127 - y2).coerceIn(0, 127).toByte()
            o[8 + c] = (127 - x1).coerceIn(0, 127).toByte()
            o[12 + c] = (127 - y1).coerceIn(0, 127).toByte()
        }
        return o
    }

    private fun isLinearIp(ip: ByteArray): Boolean {
        for (c in 0..3) {
            val x1 = ip[c].toInt() and 0xFF
            val y1 = ip[4 + c].toInt() and 0xFF
            val x2 = ip[8 + c].toInt() and 0xFF
            val y2 = ip[12 + c].toInt() and 0xFF
            if (abs(x1 - y1) > 8 || abs(x2 - y2) > 8) return false
        }
        return true
    }

    private fun insertMap(at: Int, count: Int): (Int) -> Int? {
        val a = at.coerceAtLeast(0); val c = count.coerceAtLeast(0)
        return { f -> if (f >= a) (f.toLong() + c).coerceAtMost(Int.MAX_VALUE.toLong()).toInt() else f }
    }

    private fun deleteMap(from: Int, count: Int): (Int) -> Int? {
        val a = from.coerceAtLeast(0); val c = count.coerceAtLeast(0)
        return { f -> if (f < a) f else if (f < a.toLong() + c) null else f - c }
    }

    // ---------- ossos ----------

    /** Aplica [map] ao frame de cada key; keys com resultado null são removidas. */
    fun remapTrack(t: VmdTrack, map: (Int) -> Int?): VmdTrack {
        val out = ArrayList<Key>()
        for (k in keysOf(t)) {
            val nf = map(k.frame) ?: continue
            if (nf < 0) continue
            out.add(Key(nf, k.v, k.ip))
        }
        return build(out)
    }

    /** Insere [count] frames vazios a partir de [atFrame]: keys em frames >= atFrame deslizam para frente. */
    fun insertFrames(t: VmdTrack, atFrame: Int, count: Int): VmdTrack = remapTrack(t, insertMap(atFrame, count))

    /** Remove o trecho [from, from+count) e puxa o resto para trás. */
    fun deleteFrames(t: VmdTrack, from: Int, count: Int): VmdTrack = remapTrack(t, deleteMap(from, count))

    /** Inverte no tempo os keys em [from, to] (inclusive), incluindo as curvas Bézier de cada segmento. */
    fun reverseRange(t: VmdTrack, from: Int, to: Int): VmdTrack {
        if (to <= from) return t
        val all = keysOf(t)
        val inside = all.filter { it.frame in from..to }.sortedBy { it.frame }
        val m = inside.size
        if (m < 2) return t
        val outside = all.filter { it.frame !in from..to }
        val rev = ArrayList<Key>(m)
        for (j in 0 until m) {
            val src = inside[m - 1 - j]
            val ip = if (j == 0) src.ip else flipIp(inside[m - j].ip)
            rev.add(Key(from + to - src.frame, src.v, ip))
        }
        return build(outside + rev)
    }

    class Reduction(val track: VmdTrack, val removed: Int)

    /**
     * Remove keys que a interpolação linear entre os vizinhos reproduz dentro da tolerância
     * (posição em unidades do modelo, rotação em graus). Com [respectCurves], keys com curva Bézier não linear
     * e os segmentos que terminam nelas são preservados. Primeiro e último key sempre ficam.
     */
    fun reduceKeys(t: VmdTrack, positionTol: Float = 0.01f, angleTolDeg: Float = 0.5f, respectCurves: Boolean = true): Reduction {
        val keys = keysOf(t).sortedBy { it.frame }
        val n = keys.size
        if (n < 3) return Reduction(t, 0)
        val pTol = if (positionTol.isFinite() && positionTol > 1e-9f) positionTol else 1e-9f
        val aTol = if (angleTolDeg.isFinite() && angleTolDeg > 1e-6f) angleTolDeg else 1e-6f
        val keep = BooleanArray(n)
        keep[0] = true; keep[n - 1] = true
        val stack = ArrayList<IntArray>()
        stack.add(intArrayOf(0, n - 1))
        while (stack.isNotEmpty()) {
            val r = stack.removeAt(stack.size - 1)
            val lo = r[0]; val hi = r[1]
            if (hi - lo < 2) continue
            var split = -1
            if (respectCurves && !isLinearIp(keys[hi].ip)) {
                split = lo + 1
            } else {
                var worst = 1f
                for (i in lo + 1 until hi) {
                    if (respectCurves && !isLinearIp(keys[i].ip)) { split = i; break }
                    val d = deviation(keys[lo], keys[hi], keys[i], pTol, aTol)
                    if (d > worst) { worst = d; split = i }
                }
            }
            if (split >= 0) {
                keep[split] = true
                stack.add(intArrayOf(lo, split))
                stack.add(intArrayOf(split, hi))
            }
        }
        val kept = ArrayList<Key>()
        for (i in 0 until n) if (keep[i]) kept.add(keys[i])
        return Reduction(build(kept), n - kept.size)
    }

    private fun deviation(a: Key, b: Key, k: Key, pTol: Float, aTol: Float): Float {
        val span = (b.frame - a.frame).toFloat()
        val t = if (span <= 0f) 0f else ((k.frame - a.frame) / span).coerceIn(0f, 1f)
        var d2 = 0f
        for (c in 0..2) {
            val e = k.v[c] - (a.v[c] + (b.v[c] - a.v[c]) * t)
            d2 += e * e
        }
        val posRatio = sqrt(d2) / pTol
        val q = slerp(a.v, b.v, t)
        var dot = 0f
        for (c in 0..3) dot += q[c] * k.v[3 + c]
        val ang = (2.0 * acos(abs(dot).coerceIn(0f, 1f).toDouble()) * 180.0 / Math.PI).toFloat()
        val angRatio = ang / aTol
        return if (posRatio > angRatio) posRatio else angRatio
    }

    /** slerp entre as rotações (índices 3..6 de dois vetores de key); resultado normalizado. */
    private fun slerp(a: FloatArray, b: FloatArray, t: Float): FloatArray {
        var dot = 0f
        for (c in 0..3) dot += a[3 + c] * b[3 + c]
        val sign = if (dot < 0f) -1f else 1f
        val d = abs(dot).coerceIn(0f, 1f)
        val o = FloatArray(4)
        if (d > 0.9995f) {
            for (c in 0..3) o[c] = a[3 + c] + (sign * b[3 + c] - a[3 + c]) * t
        } else {
            val th = acos(d.toDouble())
            val s = Math.sin(th)
            val wa = (Math.sin((1.0 - t) * th) / s).toFloat()
            val wb = (Math.sin(t * th) / s).toFloat()
            for (c in 0..3) o[c] = wa * a[3 + c] + wb * sign * b[3 + c]
        }
        val len = sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2] + o[3] * o[3])
        if (len > 1e-8f) for (c in 0..3) o[c] /= len else { o[0] = 0f; o[1] = 0f; o[2] = 0f; o[3] = 1f }
        return o
    }

    // ---------- morphs ----------

    fun remapMorph(t: VmdMorphTrack, map: (Int) -> Int?): VmdMorphTrack {
        val n = minOf(t.frames.size, t.w.size)
        val pairs = ArrayList<Pair<Int, Float>>()
        for (i in 0 until n) {
            val nf = map(t.frames[i]) ?: continue
            if (nf >= 0) pairs.add(nf to t.w[i])
        }
        pairs.sortBy { it.first }
        val out = ArrayList<Pair<Int, Float>>()
        for (p in pairs) { if (out.isNotEmpty() && out[out.size - 1].first == p.first) out[out.size - 1] = p else out.add(p) }
        return VmdMorphTrack(IntArray(out.size) { out[it].first }, FloatArray(out.size) { out[it].second })
    }

    fun insertFrames(t: VmdMorphTrack, atFrame: Int, count: Int): VmdMorphTrack = remapMorph(t, insertMap(atFrame, count))
    fun deleteFrames(t: VmdMorphTrack, from: Int, count: Int): VmdMorphTrack = remapMorph(t, deleteMap(from, count))

    fun reverseRange(t: VmdMorphTrack, from: Int, to: Int): VmdMorphTrack {
        if (to <= from) return t
        return remapMorph(t) { f -> if (f in from..to) from + to - f else f }
    }

    class MorphReduction(val track: VmdMorphTrack, val removed: Int)

    fun reduceKeys(t: VmdMorphTrack, tol: Float = 0.005f): MorphReduction {
        val n = minOf(t.frames.size, t.w.size)
        if (n < 3) return MorphReduction(t, 0)
        val e = if (tol.isFinite() && tol > 1e-9f) tol else 1e-9f
        val keep = BooleanArray(n)
        keep[0] = true; keep[n - 1] = true
        val stack = ArrayList<IntArray>()
        stack.add(intArrayOf(0, n - 1))
        while (stack.isNotEmpty()) {
            val r = stack.removeAt(stack.size - 1)
            val lo = r[0]; val hi = r[1]
            if (hi - lo < 2) continue
            var split = -1; var worst = e
            val span = (t.frames[hi] - t.frames[lo]).toFloat()
            for (i in lo + 1 until hi) {
                val u = if (span <= 0f) 0f else (t.frames[i] - t.frames[lo]) / span
                val d = abs(t.w[i] - (t.w[lo] + (t.w[hi] - t.w[lo]) * u))
                if (d > worst) { worst = d; split = i }
            }
            if (split >= 0) { keep[split] = true; stack.add(intArrayOf(lo, split)); stack.add(intArrayOf(split, hi)) }
        }
        val idx = (0 until n).filter { keep[it] }
        return MorphReduction(VmdMorphTrack(IntArray(idx.size) { t.frames[idx[it]] }, FloatArray(idx.size) { t.w[idx[it]] }), n - idx.size)
    }

    // ---------- câmera ----------

    fun remapCamera(c: VmdCamera, map: (Int) -> Int?): VmdCamera {
        val n = minOf(c.frames.size, c.dist.size, c.pos.size / 3, c.rot.size / 3, c.fov.size, c.ip.size / 24)
        val idx = ArrayList<Int>(); val nf = ArrayList<Int>()
        for (i in 0 until n) { val f = map(c.frames[i]) ?: continue; if (f >= 0) { idx.add(i); nf.add(f) } }
        val order = idx.indices.sortedBy { nf[it] }
        val keepOrder = ArrayList<Int>()
        for (o in order) { if (keepOrder.isNotEmpty() && nf[keepOrder[keepOrder.size - 1]] == nf[o]) keepOrder[keepOrder.size - 1] = o else keepOrder.add(o) }
        val m = keepOrder.size
        val frames = IntArray(m) { nf[keepOrder[it]] }
        val dist = FloatArray(m) { c.dist[idx[keepOrder[it]]] }
        val fov = FloatArray(m) { c.fov[idx[keepOrder[it]]] }
        val pos = FloatArray(m * 3); val rot = FloatArray(m * 3); val ip = ByteArray(m * 24)
        for (j in 0 until m) {
            val s = idx[keepOrder[j]]
            for (k in 0..2) { pos[j * 3 + k] = c.pos[s * 3 + k]; rot[j * 3 + k] = c.rot[s * 3 + k] }
            System.arraycopy(c.ip, s * 24, ip, j * 24, 24)
        }
        return VmdCamera(frames, dist, pos, rot, fov, ip)
    }

    fun insertFrames(c: VmdCamera, atFrame: Int, count: Int): VmdCamera = remapCamera(c, insertMap(atFrame, count))
    fun deleteFrames(c: VmdCamera, from: Int, count: Int): VmdCamera = remapCamera(c, deleteMap(from, count))

    // ---------- extras (IK, luz, sombra, visibilidade) ----------

    private fun plan(frames: IntArray, map: (Int) -> Int?): List<Pair<Int, Int>> {
        val r = ArrayList<Pair<Int, Int>>()
        for (i in frames.indices) { val nf = map(frames[i]) ?: continue; if (nf >= 0) r.add(i to nf) }
        r.sortBy { it.second }
        val out = ArrayList<Pair<Int, Int>>()
        for (p in r) { if (out.isNotEmpty() && out[out.size - 1].second == p.second) out[out.size - 1] = p else out.add(p) }
        return out
    }

    fun remapExtras(e: VmdExtras, map: (Int) -> Int?): VmdExtras {
        if (e.isEmpty) return e
        val ik = HashMap<String, VmdIkTrack>()
        for ((name, t) in e.ik) {
            val n = minOf(t.frames.size, t.on.size)
            val p = plan(t.frames.copyOf(n), map)
            ik[name] = VmdIkTrack(IntArray(p.size) { p[it].second }, BooleanArray(p.size) { t.on[p[it].first] })
        }
        val lights = e.lights?.let { l ->
            val n = minOf(l.frames.size, l.color.size / 3, l.dir.size / 3)
            val p = plan(l.frames.copyOf(n), map)
            val color = FloatArray(p.size * 3); val dir = FloatArray(p.size * 3)
            for (j in p.indices) for (k in 0..2) { color[j * 3 + k] = l.color[p[j].first * 3 + k]; dir[j * 3 + k] = l.dir[p[j].first * 3 + k] }
            VmdLightKeys(IntArray(p.size) { p[it].second }, color, dir)
        }
        val shadows = e.shadows?.let { s ->
            val n = minOf(s.frames.size, s.mode.size, s.dist.size)
            val p = plan(s.frames.copyOf(n), map)
            VmdShadowKeys(IntArray(p.size) { p[it].second }, ByteArray(p.size) { s.mode[p[it].first] }, FloatArray(p.size) { s.dist[p[it].first] })
        }
        val vis = e.visibility?.let { v ->
            val n = minOf(v.frames.size, v.visible.size)
            val p = plan(v.frames.copyOf(n), map)
            VmdVisibilityKeys(IntArray(p.size) { p[it].second }, BooleanArray(p.size) { v.visible[p[it].first] })
        }
        return VmdExtras(ik, lights, shadows, vis)
    }

    // ---------- movimento completo ----------

    fun remapMotion(m: VmdMotion, map: (Int) -> Int?): VmdMotion {
        val bones = m.bones.mapValues { remapTrack(it.value, map) }.filterValues { it.frames.isNotEmpty() }
        val morphs = m.morphs.mapValues { remapMorph(it.value, map) }.filterValues { it.frames.isNotEmpty() }
        val extras = remapExtras(m.extras, map)
        var mx = 0
        for (t in bones.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames[t.frames.size - 1])
        for (t in morphs.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames[t.frames.size - 1])
        return VmdMotion(m.modelName, bones, morphs, mx, m.warnings, extras)
    }

    fun insertFrames(m: VmdMotion, atFrame: Int, count: Int): VmdMotion = remapMotion(m, insertMap(atFrame, count))
    fun deleteFrames(m: VmdMotion, from: Int, count: Int): VmdMotion = remapMotion(m, deleteMap(from, count))

    fun reverseRange(m: VmdMotion, from: Int, to: Int): VmdMotion {
        if (to <= from) return m
        return VmdMotion(
            m.modelName,
            m.bones.mapValues { reverseRange(it.value, from, to) },
            m.morphs.mapValues { reverseRange(it.value, from, to) },
            m.maxFrame, m.warnings, m.extras
        )
    }

    /** Reduz todas as trilhas e devolve o movimento novo + total de keys removidas. */
    fun reduceMotion(m: VmdMotion, positionTol: Float = 0.01f, angleTolDeg: Float = 0.5f, morphTol: Float = 0.005f): Pair<VmdMotion, Int> {
        var removed = 0
        val bones = m.bones.mapValues { val r = reduceKeys(it.value, positionTol, angleTolDeg); removed += r.removed; r.track }
        val morphs = m.morphs.mapValues { val r = reduceKeys(it.value, morphTol); removed += r.removed; r.track }
        return VmdMotion(m.modelName, bones, morphs, m.maxFrame, m.warnings, m.extras) to removed
    }
}
