package studio.mmd.mmd

/** Auditoria detalhada dos morphs PMX, sem alterar nem descartar o payload original. */
data class PmxMorphIssue(
    val severity: PmxIssueSeverity,
    val code: String,
    val message: String,
    val morphIndex: Int
)

data class PmxMorphAuditReport(
    val totalMorphs: Int,
    val leafMorphs: Int,
    val groupMorphs: Int,
    val flipMorphs: Int,
    val impulseRecords: Int,
    val errorCount: Int,
    val warningCount: Int,
    val issues: List<PmxMorphIssue>
) {
    val healthy: Boolean get() = errorCount == 0
    val summary: String get() = when {
        errorCount > 0 -> "$errorCount erros e $warningCount avisos nos morphs PMX"
        warningCount > 0 -> "Morphs analisados com $warningCount avisos de compatibilidade"
        else -> "Morphs PMX consistentes"
    }
}

object PmxMorphDoctor {
    fun inspect(model: PmxModel): PmxMorphAuditReport {
        val issues = ArrayList<PmxMorphIssue>()
        fun add(severity: PmxIssueSeverity, code: String, message: String, index: Int) {
            issues += PmxMorphIssue(severity, code, message, index)
        }
        val n = model.morphs.size
        var groupCount = 0; var flipCount = 0; var leafCount = 0; var impulseRecords = 0
        model.morphs.forEachIndexed { i, morph ->
            when (morph.type) {
                0, 9 -> {
                    if (morph.type == 0) groupCount++ else flipCount++
                    val ids = morph.groupIdx; val rates = morph.groupRate
                    if (ids == null || rates == null || ids.size != rates.size) {
                        add(PmxIssueSeverity.ERROR, "group.shape", "Morph '${morph.name}' tem referências/taxas inconsistentes.", i)
                    } else {
                        ids.forEach { if (it !in 0 until n) add(PmxIssueSeverity.ERROR, "group.index", "Morph '${morph.name}' referencia morph inexistente ($it).", i) }
                        rates.forEach { if (!it.isFinite()) add(PmxIssueSeverity.ERROR, "group.weight", "Morph '${morph.name}' contém taxa não finita.", i) }
                        if (morph.type == 9 && ids.isEmpty()) add(PmxIssueSeverity.WARNING, "flip.empty", "Morph flip '${morph.name}' não possui opções.", i)
                    }
                }
                1 -> {
                    leafCount++
                    val ids = morph.vertexIdx; val deltas = morph.vertexDelta
                    if (ids == null || deltas == null || deltas.size != ids.size * 3) add(PmxIssueSeverity.ERROR, "vertex.shape", "Morph '${morph.name}' tem arrays de vértice incompatíveis.", i)
                    else {
                        ids.forEach { if (it !in 0 until model.vertexCount) add(PmxIssueSeverity.ERROR, "vertex.index", "Morph '${morph.name}' referencia vértice inexistente ($it).", i) }
                        if (deltas.any { !it.isFinite() }) add(PmxIssueSeverity.ERROR, "vertex.non_finite", "Morph '${morph.name}' contém delta não finito.", i)
                    }
                }
                2 -> {
                    leafCount++
                    val ids = morph.boneIdx; val trans = morph.boneTrans; val rot = morph.boneRot
                    if (ids == null || trans == null || rot == null || trans.size != ids.size * 3 || rot.size != ids.size * 4) add(PmxIssueSeverity.ERROR, "bone.shape", "Morph '${morph.name}' tem arrays ósseos incompatíveis.", i)
                    else {
                        ids.forEach { if (it !in model.bones.indices) add(PmxIssueSeverity.ERROR, "bone.index", "Morph '${morph.name}' referencia osso inexistente ($it).", i) }
                        if (trans.any { !it.isFinite() } || rot.any { !it.isFinite() }) add(PmxIssueSeverity.ERROR, "bone.non_finite", "Morph '${morph.name}' contém transformação não finita.", i)
                    }
                }
                3 -> {
                    leafCount++
                    val decoded = UvMorph.decode(morph)
                    if (decoded == null) add(PmxIssueSeverity.ERROR, "uv.raw", "Morph UV '${morph.name}' tem payload inválido ou incompleto.", i)
                    else {
                        decoded.idx.forEach { if (it !in 0 until model.vertexCount) add(PmxIssueSeverity.ERROR, "uv.index", "Morph '${morph.name}' referencia vértice inexistente ($it).", i) }
                        if (decoded.d.any { !it.isFinite() }) add(PmxIssueSeverity.ERROR, "uv.non_finite", "Morph UV '${morph.name}' contém delta não finito.", i)
                    }
                }
                in 4..7 -> {
                    leafCount++
                    val decoded = AdditionalUvMorph.decode(morph)
                    if (decoded == null) add(PmxIssueSeverity.ERROR, "add_uv.raw", "Morph UV adicional '${morph.name}' tem payload inválido.", i)
                    else {
                        decoded.vertexIndices.forEach { if (it !in 0 until model.vertexCount) add(PmxIssueSeverity.ERROR, "add_uv.index", "Morph '${morph.name}' referencia vértice inexistente ($it).", i) }
                        if (decoded.delta.any { !it.isFinite() }) add(PmxIssueSeverity.ERROR, "add_uv.non_finite", "Morph '${morph.name}' contém delta não finito.", i)
                        if (decoded.channel >= model.addUvCount) add(PmxIssueSeverity.WARNING, "add_uv.channel_missing", "Morph '${morph.name}' usa canal ${decoded.channel + 1}, mas o modelo declara ${model.addUvCount} UVs adicionais.", i)
                    }
                }
                8 -> {
                    leafCount++
                    val raw = morph.raw
                    val decoded = MaterialMorphs.decode(morph)
                    if (raw == null || decoded.size != morph.count) add(PmxIssueSeverity.ERROR, "material.raw", "Morph de material '${morph.name}' tem payload inválido.", i)
                    decoded.forEach { e ->
                        if (e.mat !in -1 until model.materials.size) add(PmxIssueSeverity.ERROR, "material.index", "Morph '${morph.name}' referencia material inexistente (${e.mat}).", i)
                        if (e.v.any { !it.isFinite() } || listOfNotNull(e.textureTint, e.sphereTint, e.toonTint).any { a -> a.any { !it.isFinite() } })
                            add(PmxIssueSeverity.ERROR, "material.non_finite", "Morph '${morph.name}' contém parâmetros de material não finitos.", i)
                    }
                }
                10 -> {
                    leafCount++
                    val result = PmxImpulseMorphs.decode(morph, model.rigidBodies.size)
                    impulseRecords += result.entries.size
                    if (result.entries.size != morph.count) {
                        val severity = if (result.entries.isEmpty()) PmxIssueSeverity.ERROR else PmxIssueSeverity.WARNING
                        result.warnings.forEach { add(severity, "impulse.record", "Morph '${morph.name}': $it", i) }
                    }
                }
                else -> add(PmxIssueSeverity.WARNING, "type.unknown", "Morph '${morph.name}' usa tipo PMX ${morph.type} desconhecido; payload deve ser preservado.", i)
            }
        }

        // O mesmo resolver utilizado pelo Animator detecta ciclos/índices inválidos em grupos e flips.
        val resolver = MorphResolver(model.morphs)
        val sink = object : MorphSink { override fun leaf(index: Int, weight: Float) { /* auditoria não aplica morph */ } }
        for (i in model.morphs.indices) if (model.morphs[i].type == 0 || model.morphs[i].type == 9) resolver.resolve(i, 1f, sink)
        if (resolver.cycles > 0) add(PmxIssueSeverity.ERROR, "graph.cycle", "Foram detectados ${resolver.cycles} ciclos em referências de grupo/flip.", -1)
        if (resolver.invalid > 0) add(PmxIssueSeverity.ERROR, "graph.invalid", "Foram detectadas ${resolver.invalid} referências inválidas em grupo/flip.", -1)

        val errors = issues.count { it.severity == PmxIssueSeverity.ERROR }
        val warnings = issues.count { it.severity == PmxIssueSeverity.WARNING }
        return PmxMorphAuditReport(n, leafCount, groupCount, flipCount, impulseRecords, errors, warnings, issues)
    }
}
