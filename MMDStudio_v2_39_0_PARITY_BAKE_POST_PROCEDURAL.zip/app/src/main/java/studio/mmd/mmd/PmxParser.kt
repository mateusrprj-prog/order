package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

class PmxFormatException(msg: String) : Exception(msg)

/**
 * Leitor de PMX 2.0 / 2.1.
 * v1.9.1: lê o arquivo inteiro (cabeçalho, vértices, faces, texturas, materiais, ossos, morphs, frames de exibição,
 * corpos rígidos, juntas), preserva os campos que o app ainda não usa e registra AVISOS em PmxModel.warnings
 * em vez de descartar dados em silêncio. Erros fatais dizem a seção e o offset.
 */
object PmxParser {
    private class R(bytes: ByteArray) {
        val b: ByteBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        fun u8() = b.get().toInt() and 0xFF
        fun u16() = b.short.toInt() and 0xFFFF
        fun i32() = b.int
        fun f() = b.float
        fun pos() = b.position()
        fun remaining() = b.remaining()
        fun skip(n: Int) { b.position(b.position() + n) }
        fun bytes(n: Int) = ByteArray(n).also { b.get(it) }
        fun sidx(size: Int) = when (size) { 1 -> b.get().toInt(); 2 -> b.short.toInt(); else -> b.int }
        fun uidx(size: Int) = when (size) { 1 -> u8(); 2 -> u16(); else -> b.int }
        /** Lê uma contagem e confere que há bytes suficientes para minBytes por item (evita alocações absurdas). */
        fun count(minBytes: Int = 1): Int {
            val n = i32()
            if (n < 0 || n.toLong() * minBytes > b.remaining()) throw PmxFormatException("Contagem inválida ($n) para os bytes restantes (${b.remaining()})")
            return n
        }
        fun text(enc: Int): String {
            val n = count()
            return String(bytes(n), if (enc == 0) Charsets.UTF_16LE else Charsets.UTF_8)
        }
        fun floats(n: Int) = FloatArray(n) { f() }
    }

    private class State { var section = "cabeçalho" }

    fun parse(data: ByteArray): PmxModel {
        val r = R(data); val st = State()
        try {
            val model = parseInternal(r, st, data)
            // v2.3.0: reconhecimento automático da saia e preparação de colisores ocorre
            // imediatamente no parser para cobrir importadores diretos e ZIP/PMX.
            studio.mmd.rig.SkirtGuardAuto.profile(model)
            return model
        }
        catch (e: PmxFormatException) { throw PmxFormatException("${e.message} [seção: ${st.section}, offset ${r.pos()} de ${data.size}]") }
        catch (e: Exception) { throw PmxFormatException("Arquivo PMX truncado ou inválido na seção '${st.section}' (offset ${r.pos()} de ${data.size}): ${e.javaClass.simpleName}") }
    }

    private fun parseInternal(r: R, st: State, source: ByteArray): PmxModel {
        val warn = ArrayList<String>()
        if (r.remaining() < 4 || String(r.bytes(4), Charsets.US_ASCII) != "PMX ") throw PmxFormatException("Não é um arquivo PMX (assinatura inválida)")
        val version = r.f()
        if (!(version >= 1.99f && version <= 2.11f)) warn.add("Versão PMX $version não validada (suportadas: 2.0 e 2.1); leitura em modo tolerante.")
        val gc = r.u8()
        if (gc < 8) throw PmxFormatException("Cabeçalho PMX inválido (configurações globais: $gc)")
        val g = IntArray(gc) { r.u8() }
        val enc = g[0]; val addUv = g[1]; val vS = g[2]; val tS = g[3]; val mS = g[4]; val bS = g[5]; val moS = g[6]; val rS = g[7]
        for (sz in intArrayOf(vS, tS, mS, bS, moS, rS)) if (sz != 1 && sz != 2 && sz != 4) throw PmxFormatException("Tamanho de índice inválido no cabeçalho: $sz")
        if (addUv !in 0..4) throw PmxFormatException("Quantidade de UVs adicionais inválida: $addUv")
        val name = r.text(enc); val nameEn = r.text(enc); val comment = r.text(enc); val commentEn = r.text(enc)

        // Vértices
        st.section = "vértices"
        val vc = r.count(37)
        val pos = FloatArray(vc * 3); val nrm = FloatArray(vc * 3); val uv = FloatArray(vc * 2)
        val uvx = FloatArray(vc * 4 * addUv)
        val bi = IntArray(vc * 4) { -1 }; val bw = FloatArray(vc * 4)
        val wt = ByteArray(vc); val edge = FloatArray(vc)
        var sdef: FloatArray? = null
        var nSdef = 0; var nQdef = 0; var nNorm = 0
        for (i in 0 until vc) {
            for (k in 0..2) pos[i * 3 + k] = r.f()
            for (k in 0..2) nrm[i * 3 + k] = r.f()
            uv[i * 2] = r.f(); uv[i * 2 + 1] = r.f()
            for (k in 0 until 4 * addUv) uvx[i * 4 * addUv + k] = r.f()
            val t = r.u8()
            if (t > 4) throw PmxFormatException("Tipo de peso desconhecido: $t (vértice $i)")
            wt[i] = t.toByte()
            when (t) {
                0 -> { bi[i * 4] = r.sidx(bS); bw[i * 4] = 1f }
                1, 3 -> {
                    bi[i * 4] = r.sidx(bS); bi[i * 4 + 1] = r.sidx(bS)
                    val w = r.f(); bw[i * 4] = w; bw[i * 4 + 1] = 1f - w
                    if (t == 3) {
                        nSdef++
                        val a = sdef ?: FloatArray(vc * 9).also { sdef = it }
                        for (k in 0 until 9) a[i * 9 + k] = r.f()   // C, R0, R1
                    }
                }
                else -> {
                    for (k in 0..3) bi[i * 4 + k] = r.sidx(bS)
                    var sum = 0f
                    for (k in 0..3) { val w = r.f(); bw[i * 4 + k] = w; if (bi[i * 4 + k] >= 0) sum += w }
                    if (t == 4) nQdef++
                    if (sum > 1e-6f && Math.abs(sum - 1f) > 1e-3f) { for (k in 0..3) bw[i * 4 + k] /= sum; nNorm++ }
                }
            }
            edge[i] = r.f()
        }
        if (nSdef > 0) warn.add("$nSdef vértices SDEF: deformação SDEF real na prévia/vídeo; GLB/FBX exportados usam BDEF2 (aproximação).")
        if (nQdef > 0) warn.add("$nQdef vértices QDEF: deformação por dual quaternion na prévia/vídeo; GLB/FBX exportados usam skinning linear (aproximação).")
        if (nNorm > 0) warn.add("$nNorm vértices tinham pesos BDEF4/QDEF que não somavam 1; foram normalizados.")

        // Faces
        st.section = "faces"
        val fc = r.count(vS)
        if (fc % 3 != 0) throw PmxFormatException("Número de índices não é múltiplo de 3 ($fc)")
        val indices = IntArray(fc) { r.uidx(vS) }
        for (ix in indices) if (ix < 0 || ix >= vc) throw PmxFormatException("Índice de vértice fora do intervalo ($ix, total $vc)")

        // Texturas
        st.section = "texturas"
        val textures = List(r.count(4)) { r.text(enc) }

        // Materiais
        st.section = "materiais"
        val materials = List(r.count(80)) {
            val n = r.text(enc); val ne = r.text(enc)
            val diffuse = r.floats(4); val spec = r.floats(3); val sp = r.f(); val amb = r.floats(3)
            val flags = r.u8(); val edgeC = r.floats(4); val edgeS = r.f()
            val tex = r.sidx(tS); val sph = r.sidx(tS); val sphMode = r.u8()
            val shared = r.u8() == 1
            val toon = if (shared) r.u8() else r.sidx(tS)
            val memo = r.text(enc)
            val ic = r.i32()
            PmxMaterial(n, ne, diffuse, spec, sp, amb, flags, edgeC, edgeS, tex, sph, sphMode, shared, toon, ic, memo)
        }
        val idxSum = materials.sumOf { it.indexCount.toLong() }
        if (idxSum != fc.toLong()) warn.add("Soma dos índices dos materiais ($idxSum) difere do total de índices de faces ($fc).")

        // Ossos
        st.section = "ossos"
        val bones = List(r.count(28)) {
            val n = r.text(enc); val ne = r.text(enc)
            val x = r.f(); val y = r.f(); val z = r.f()
            val parent = r.sidx(bS); val layer = r.i32(); val flags = r.u16()
            var tail = -1; var tailOff: FloatArray? = null
            if ((flags and 0x0001) != 0) tail = r.sidx(bS) else tailOff = r.floats(3)
            var ip = -1; var iw = 0f
            if ((flags and 0x0300) != 0) { ip = r.sidx(bS); iw = r.f() }
            var fixed: FloatArray? = null
            if ((flags and 0x0400) != 0) fixed = r.floats(3)
            var lx: FloatArray? = null; var lz: FloatArray? = null
            if ((flags and 0x0800) != 0) { lx = r.floats(3); lz = r.floats(3) }
            var ext = -1
            if ((flags and 0x2000) != 0) ext = r.i32()
            var ik: PmxIk? = null
            if ((flags and 0x0020) != 0) {
                val target = r.sidx(bS); val loop = r.i32(); val lim = r.f()
                val links = List(r.count(bS + 1)) {
                    val lb = r.sidx(bS); val has = r.u8() == 1
                    if (has) PmxIkLink(lb, true, r.floats(3), r.floats(3)) else PmxIkLink(lb, false, null, null)
                }
                ik = PmxIk(target, loop, lim, links)
            }
            PmxBone(n, ne, x, y, z, parent, layer, flags, tail, ip, iw, ik, tailOff, fixed, lx, lz, ext)
        }
        val nb = bones.size

        // Morphs
        st.section = "morphs"
        val morphs = List(r.count(14)) {
            val n = r.text(enc); val ne = r.text(enc); val panel = r.u8(); val type = r.u8()
            val cnt = r.count()
            fun raw(size: Int): ByteArray {
                val total = cnt.toLong() * size
                if (total > r.remaining()) throw PmxFormatException("Morph '$n' (tipo $type): $cnt elementos não cabem no arquivo")
                return r.bytes(total.toInt())
            }
            when (type) {
                0, 9 -> {
                    if (cnt.toLong() * (moS + 4) > r.remaining()) throw PmxFormatException("Morph '$n': elementos não cabem no arquivo")
                    val idx = IntArray(cnt); val rate = FloatArray(cnt)
                    for (k in 0 until cnt) { idx[k] = r.sidx(moS); rate[k] = r.f() }
                    PmxMorph(n, ne, panel, type, groupIdx = idx, groupRate = rate, count = cnt)
                }
                1 -> {
                    if (cnt.toLong() * (vS + 12) > r.remaining()) throw PmxFormatException("Morph '$n': elementos não cabem no arquivo")
                    val idx = IntArray(cnt); val d = FloatArray(cnt * 3)
                    for (k in 0 until cnt) { idx[k] = r.uidx(vS); for (c in 0..2) d[k * 3 + c] = r.f() }
                    PmxMorph(n, ne, panel, type, vertexIdx = idx, vertexDelta = d, count = cnt)
                }
                2 -> {
                    if (cnt.toLong() * (bS + 28) > r.remaining()) throw PmxFormatException("Morph '$n': elementos não cabem no arquivo")
                    val idx = IntArray(cnt); val t = FloatArray(cnt * 3); val q = FloatArray(cnt * 4)
                    for (k in 0 until cnt) {
                        idx[k] = r.sidx(bS)
                        for (c in 0..2) t[k * 3 + c] = r.f()
                        for (c in 0..3) q[k * 4 + c] = r.f()
                    }
                    PmxMorph(n, ne, panel, type, boneIdx = idx, boneTrans = t, boneRot = q, count = cnt)
                }
                3, 4, 5, 6, 7 -> PmxMorph(n, ne, panel, type, raw = raw(vS + 16), count = cnt)
                8 -> PmxMorph(n, ne, panel, type, raw = raw(mS + 113), count = cnt)
                10 -> PmxMorph(n, ne, panel, type, raw = raw(rS + 25), count = cnt)
                else -> throw PmxFormatException("Tipo de morph desconhecido: $type (morph '$n')")
            }
        }
        val nMorph = morphs.size
        val nUnused = morphs.count { it.type in 4..7 || it.type == 10 }
        if (nUnused > 0) warn.add("$nUnused morphs de UV adicional/impulso foram preservados, mas ainda não têm efeito na animação.")
        val nUv = morphs.count { it.type == 3 }
        if (nUv > 0) warn.add("$nUv morphs de UV (tipo 3) são aplicados nas coordenadas de textura.")
        val nMat = morphs.count { it.type == 8 }
        if (nMat > 0) warn.add("$nMat morphs de material são aplicados (cor, brilho, ambiente, borda); coeficientes de textura/esfera/toon são ignorados.")
        if (morphs.any { it.type == 9 }) warn.add("Morphs flip são avaliados (um elemento escolhido pela faixa do peso); a regra não foi comparada com o MMD oficial.")

        // Validação de índices (aviso, sem derrubar o modelo)
        var badW = 0
        for (i in 0 until vc * 4) if (bi[i] >= nb || bi[i] < -1) { bi[i] = -1; bw[i] = 0f; badW++ }
        if (badW > 0) warn.add("$badW pesos apontavam para ossos inexistentes e foram zerados.")
        val badParent = bones.count { it.parent >= nb || it.parent < -1 } + bones.count { it.inheritParent >= nb || it.inheritParent < -1 }
        if (badParent > 0) warn.add("$badParent referências de osso pai/herança fora do intervalo.")
        var badIk = 0
        for (b in bones) { val ik = b.ik ?: continue; if (ik.target >= nb || ik.target < -1) badIk++; for (l in ik.links) if (l.bone !in 0 until nb) badIk++ }
        if (badIk > 0) warn.add("$badIk referências de IK fora do intervalo.")
        val nt = textures.size
        val badTex = materials.count { it.textureIndex >= nt || it.sphereIndex >= nt || (!it.toonShared && it.toonIndex >= nt) }
        if (badTex > 0) warn.add("$badTex materiais apontam para texturas inexistentes.")
        var badMorphRef = 0
        for (m in morphs) {
            m.groupIdx?.forEach { if (it >= nMorph || it < -1) badMorphRef++ }
            m.vertexIdx?.forEach { if (it >= vc || it < 0) badMorphRef++ }
            m.boneIdx?.forEach { if (it >= nb || it < -1) badMorphRef++ }
        }
        if (badMorphRef > 0) warn.add("$badMorphRef elementos de morph com índice fora do intervalo (serão ignorados).")

        // Frames de exibição, corpos rígidos, juntas, soft bodies
        var frames: List<PmxDisplayFrame> = emptyList()
        var rigids: List<PmxRigid> = emptyList()
        var joints: List<PmxJoint> = emptyList()
        var complete = true
        var softCount = 0
        var softRaw: ByteArray? = null
        var softRawOffset = -1
        var softBodies: List<PmxSoftBody> = emptyList()
        try {
            st.section = "frames de exibição"
            frames = List(r.count(10)) {
                val fn = r.text(enc); val fne = r.text(enc); val sp = r.u8() == 1
                val els = ArrayList<IntArray>()
                repeat(r.count(1 + minOf(bS, moS))) { val ty = r.u8(); els.add(intArrayOf(ty, if (ty == 0) r.sidx(bS) else r.sidx(moS))) }
                PmxDisplayFrame(fn, fne, sp, els)
            }
            st.section = "corpos rígidos"
            rigids = List(r.count(60)) {
                val rn = r.text(enc); val rne = r.text(enc); val rb = r.sidx(bS); val grp = r.u8(); val mask = r.u16(); val shape = r.u8()
                val size = r.floats(3); val pp = r.floats(3); val rr = r.floats(3)
                val mass = r.f(); val ld = r.f(); val ad = r.f(); val rest = r.f(); val fr = r.f()
                val mode = r.u8()
                PmxRigid(rn, rne, rb, grp, shape, mass, ld, ad, mode, mask, size, pp, rr, rest, fr)
            }
            st.section = "juntas"
            joints = List(r.count(100)) {
                val jn = r.text(enc); val jne = r.text(enc); val jt = r.u8()
                val ja = r.sidx(rS); val jb = r.sidx(rS)
                PmxJoint(jn, ja, jb, r.floats(3), r.floats(3), r.floats(3), r.floats(3), r.floats(3), r.floats(3), r.floats(3), r.floats(3), jt, jne)
            }
        } catch (e: Exception) {
            complete = false
            warn.add("Seção '${st.section}' ilegível (offset ${r.pos()}): ${e.message ?: e.javaClass.simpleName}. " +
                "Ela e as seguintes foram ignoradas; o modelo abre sem elas" + (if (st.section != "frames de exibição") " (sem física completa)." else "."))
            if (st.section == "juntas") joints = emptyList()
            if (st.section == "corpos rígidos") { rigids = emptyList(); joints = emptyList() }
        }
        if (complete) {
            val badRb = rigids.count { it.bone >= nb || it.bone < -1 }
            if (badRb > 0) warn.add("$badRb corpos rígidos apontam para ossos inexistentes.")
            val badJ = joints.count { it.a !in 0 until rigids.size || it.b !in 0 until rigids.size }
            if (badJ > 0) warn.add("$badJ juntas apontam para corpos rígidos inexistentes.")
            st.section = "soft bodies"
            val rest = r.remaining()
            if (version >= 2.05f && rest >= 4) {
                try {
                    softCount = r.count(1)
                    if (softCount > 0) {
                        // O writer guarda o contador separadamente; o payload bruto começa logo depois dele.
                        softRawOffset = r.pos()
                        softBodies = List(softCount) {
                            val sn = r.text(enc); val sne = r.text(enc)
                            val shape = r.u8(); val material = r.sidx(mS); val group = r.u8(); val mask = r.u16(); val flags = r.u8()
                            val linkDistance = r.i32(); val clusters = r.i32(); val mass = r.f(); val margin = r.f(); val aero = r.i32()
                            val config = r.floats(12); val cluster = r.floats(6)
                            val iterations = IntArray(4) { r.i32() }; val stiffness = IntArray(3) { r.i32() }
                            val anchors = List(r.count(rS + vS + 1)) { PmxSoftBodyAnchor(r.sidx(rS), r.uidx(vS), r.u8() != 0) }
                            val pins = IntArray(r.count(vS)) { r.uidx(vS) }
                            PmxSoftBody(sn, sne, shape, material, group, mask, flags, linkDistance, clusters, mass, margin, aero,
                                config, cluster, iterations, stiffness, anchors, pins)
                        }
                        softRaw = source.copyOfRange(softRawOffset, r.pos())
                        warn.add("$softCount soft bodies PMX 2.1 interpretados estruturalmente; simulação PMX/Bullet ainda não habilitada.")
                    }
                    if (r.remaining() > 0) warn.add("${r.remaining()} bytes extras no fim do arquivo foram ignorados.")
                } catch (e: Exception) {
                    // Se o contador já foi lido, preserve exatamente o payload disponível, mesmo incompleto.
                    // Sem contador íntegro, não é seguro afirmar uma quantidade para reescrita estrutural.
                    softBodies = emptyList()
                    if (softCount > 0 && softRawOffset >= 0) softRaw = source.copyOfRange(softRawOffset, source.size)
                    warn.add("Soft bodies PMX 2.1 incompletos no offset ${r.pos()}: ${e.message ?: e.javaClass.simpleName}. " +
                        if (softRaw != null) "Payload raw preservado para round-trip; simulação/edição tipada desativada." else "Contador ausente ou inválido; o restante não pode ser reescrito como soft body com segurança.")
                }
            } else if (rest > 0) warn.add("$rest bytes extras no fim do arquivo foram ignorados.")
        }
        return PmxModel(name, version, pos, nrm, uv, bi, bw, indices, textures, materials, bones, morphs, rigids, joints,
            nameEn, comment, commentEn, frames, addUv, uvx, wt, sdef, edge,
            enc, intArrayOf(vS, tS, mS, bS, moS, rS), softCount, softRaw, warn, softBodies)
    }
}
