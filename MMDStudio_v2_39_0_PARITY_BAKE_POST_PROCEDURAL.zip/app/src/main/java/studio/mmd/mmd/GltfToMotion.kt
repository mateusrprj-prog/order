package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.roundToInt

/** Pose de repouso dos nós do glTF (necessária para converter animação absoluta glTF em offsets relativos ao repouso do MMD). [scale] = glTF metros -> unidades MMD. */
class GltfRig(val nodeParent: IntArray, val restT: Array<FloatArray>, val restQ: Array<FloatArray>, val scale: Float) {
    private val worldQ = arrayOfNulls<FloatArray>(nodeParent.size)
    /** Rotação de repouso global do nó (x,y,z,w). */
    fun restWorldQ(n: Int): FloatArray {
        if (n < 0 || n >= nodeParent.size) return floatArrayOf(0f, 0f, 0f, 1f)
        worldQ[n]?.let { return it }
        var guard = 0; val chain = ArrayList<Int>(); var c = n
        while (c >= 0 && guard++ < 1024) { chain.add(c); c = nodeParent[c] }
        var q = floatArrayOf(0f, 0f, 0f, 1f)
        for (i in chain.indices.reversed()) q = GltfToMotion.qmul(q, restQ[chain[i]])
        worldQ[n] = q; return q
    }
}

/** Converte um [GltfClip] em [VmdMotion] (um key por quadro), pronto para `Editor.load`. Kotlin puro. */
object GltfToMotion {
    class Result(val motion: VmdMotion, val warnings: List<String>)

    fun qmul(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2])
    fun qconj(a: FloatArray) = floatArrayOf(-a[0], -a[1], -a[2], a[3])
    fun qrot(q: FloatArray, v: FloatArray): FloatArray { val r = qmul(qmul(q, floatArrayOf(v[0], v[1], v[2], 0f)), qconj(q)); return floatArrayOf(r[0], r[1], r[2]) }

    private fun linearIp(): ByteArray { val a = ByteArray(16); for (i in 0..3) { a[i] = 20; a[4 + i] = 20; a[8 + i] = 107; a[12 + i] = 107 }; return a }

    /**
     * Convenções: glTF (Y cima, mão direita, metros) -> MMD (Z invertido, unidades MMD). Para cada osso:
     *  delta = qAnim * conj(qRepouso); rotação MMD = Rp * delta * conj(Rp), com Rp = rotação de repouso global do pai glTF; depois (x,y,z,w) -> (-x,-y,z,w).
     *  deslocamento MMD = Rp * (T - Trepouso) * escala, com Z invertido. Canais de escala, de nós que não são ossos e de ossos fora do modelo viram aviso.
     */
    fun convert(clip: GltfClip, rig: GltfRig, model: PmxModel, fps: Float = 30f): Result {
        val warns = ArrayList<String>()
        val byBone = LinkedHashMap<Int, MutableList<GltfChannel>>()
        var skipScale = 0; var skipNoBone = 0
        for (ch in clip.channels) {
            when {
                ch.path == "scale" -> skipScale++
                ch.bone < 0 || ch.bone >= model.bones.size -> skipNoBone++
                else -> byBone.getOrPut(ch.bone) { ArrayList() }.add(ch)
            }
        }
        if (skipScale > 0) warns.add("$skipScale canal(is) de escala ignorados (animação de escala ainda não suportada)")
        if (skipNoBone > 0) warns.add("$skipNoBone canal(is) em nós que não são ossos do modelo foram ignorados")
        val last = (clip.duration * fps).roundToInt().coerceAtLeast(0)
        val tracks = LinkedHashMap<String, VmdTrack>()
        val tmp = FloatArray(4)
        for ((bone, chs) in byBone) {
            val rotS = chs.firstOrNull { it.path == "rotation" }?.sampler
            val trS = chs.firstOrNull { it.path == "translation" }?.sampler
            val node = chs[0].node
            val rq = rig.restQ[node]; val rt = rig.restT[node]
            val rp = rig.restWorldQ(rig.nodeParent[node])
            val frames = IntArray(last + 1) { it }
            val v = FloatArray((last + 1) * 7)
            val prev = floatArrayOf(0f, 0f, 0f, 1f)
            for (f in 0..last) {
                val t = f / fps
                val qa = if (rotS != null) { rotS.eval(t, tmp); tmp.copyOf(4) } else rq.copyOf()
                var d = qmul(rp, qmul(qmul(qa, qconj(rq)), qconj(rp)))
                if (d[0] * prev[0] + d[1] * prev[1] + d[2] * prev[2] + d[3] * prev[3] < 0f) d = floatArrayOf(-d[0], -d[1], -d[2], -d[3])
                for (i in 0..3) prev[i] = d[i]
                var off = floatArrayOf(0f, 0f, 0f)
                if (trS != null) {
                    val tv = FloatArray(3); trS.eval(t, tv)
                    off = qrot(rp, floatArrayOf(tv[0] - rt[0], tv[1] - rt[1], tv[2] - rt[2]))
                }
                val o = f * 7
                v[o] = off[0] * rig.scale; v[o + 1] = off[1] * rig.scale; v[o + 2] = -off[2] * rig.scale
                v[o + 3] = -d[0]; v[o + 4] = -d[1]; v[o + 5] = d[2]; v[o + 6] = d[3]
            }
            val ip = ByteArray((last + 1) * 16); for (f in 0..last) System.arraycopy(linearIp(), 0, ip, f * 16, 16)
            tracks[model.bones[bone].name] = VmdTrack(frames, v, ip)
        }
        if (tracks.isEmpty()) warns.add("nenhum canal da animação '${clip.name}' pôde ser aplicado a ossos do modelo")
        return Result(VmdMotion(model.name, tracks, emptyMap(), last, warns), warns)
    }
}
