package studio.mmd.mmd

import kotlin.math.abs

/**
 * v2.36.0 — Seleção de ossos como no MMD oficial: caixa na viewport, laço, "selecionar filhos", lado oposto e grupos por região.
 * Kotlin puro. As matrizes 4x4 são coluna-maior (estilo OpenGL), como no resto do projeto.
 */
object BoneSelection {

    class Projected(val index: Int, val x: Float, val y: Float, val depth: Float, val visible: Boolean)

    /** Projeta posições de mundo (xyz intercalado) para pixels. [viewProj] 16 floats; y cresce para baixo no resultado. */
    fun project(world: FloatArray, viewProj: FloatArray, width: Int, height: Int): List<Projected> {
        if (viewProj.size < 16 || width < 1 || height < 1) return emptyList()
        val out = ArrayList<Projected>(world.size / 3)
        for (i in 0 until world.size / 3) {
            val x = world[i * 3]; val y = world[i * 3 + 1]; val z = world[i * 3 + 2]
            if (!x.isFinite() || !y.isFinite() || !z.isFinite()) { out.add(Projected(i, 0f, 0f, 0f, false)); continue }
            val cx = viewProj[0] * x + viewProj[4] * y + viewProj[8] * z + viewProj[12]
            val cy = viewProj[1] * x + viewProj[5] * y + viewProj[9] * z + viewProj[13]
            val cz = viewProj[2] * x + viewProj[6] * y + viewProj[10] * z + viewProj[14]
            val cw = viewProj[3] * x + viewProj[7] * y + viewProj[11] * z + viewProj[15]
            if (cw <= 1e-6f) { out.add(Projected(i, 0f, 0f, 0f, false)); continue }
            val nx = cx / cw; val ny = cy / cw; val nz = cz / cw
            out.add(Projected(i, (nx * 0.5f + 0.5f) * width, (1f - (ny * 0.5f + 0.5f)) * height, nz, nz in -1f..1f))
        }
        return out
    }

    /** Índices dos ossos visíveis cujo ponto cai no retângulo (limites em qualquer ordem). */
    fun box(points: List<Projected>, x0: Float, y0: Float, x1: Float, y1: Float): List<Int> {
        val lx = minOf(x0, x1); val hx = maxOf(x0, x1); val ly = minOf(y0, y1); val hy = maxOf(y0, y1)
        return points.filter { it.visible && it.x in lx..hx && it.y in ly..hy }.map { it.index }
    }

    /** Laço: polígono em pixels (par x,y intercalado), regra par-ímpar. Precisa de 3+ vértices. */
    fun lasso(points: List<Projected>, polygon: FloatArray): List<Int> {
        val n = polygon.size / 2
        if (n < 3) return emptyList()
        return points.filter { it.visible && inside(it.x, it.y, polygon, n) }.map { it.index }
    }

    private fun inside(px: Float, py: Float, poly: FloatArray, n: Int): Boolean {
        var c = false
        var j = n - 1
        for (i in 0 until n) {
            val xi = poly[i * 2]; val yi = poly[i * 2 + 1]; val xj = poly[j * 2]; val yj = poly[j * 2 + 1]
            if ((yi > py) != (yj > py) && px < (xj - xi) * (py - yi) / (yj - yi) + xi) c = !c
            j = i
        }
        return c
    }

    /** Ossos mais próximos do ponto (toque) dentro de [radius] pixels, do mais perto ao mais longe. */
    fun pick(points: List<Projected>, x: Float, y: Float, radius: Float, limit: Int = 1): List<Int> =
        points.filter { it.visible }
            .map { it to ((it.x - x) * (it.x - x) + (it.y - y) * (it.y - y)) }
            .filter { it.second <= radius * radius }
            .sortedWith(compareBy({ it.second }, { it.first.depth }))
            .take(limit.coerceAtLeast(1)).map { it.first.index }

    /** Expande a seleção com todos os descendentes. [parents] tem o índice pai de cada osso (-1 = raiz). */
    fun withDescendants(selected: Collection<Int>, parents: IntArray): Set<Int> {
        val out = LinkedHashSet<Int>()
        val children = HashMap<Int, MutableList<Int>>()
        for (i in parents.indices) if (parents[i] in parents.indices) children.getOrPut(parents[i]) { ArrayList() }.add(i)
        val stack = ArrayDeque<Int>()
        for (s in selected) if (s in parents.indices) stack.addLast(s)
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            if (!out.add(c)) continue
            children[c]?.forEach { stack.addLast(it) }
        }
        return out
    }

    /** Sobe até a raiz de cada osso selecionado (cadeia de ancestrais), útil para travar a hierarquia. */
    fun withAncestors(selected: Collection<Int>, parents: IntArray): Set<Int> {
        val out = LinkedHashSet<Int>()
        for (s in selected) {
            var c = s; var guard = 0
            while (c in parents.indices && guard++ <= parents.size) { out.add(c); c = parents[c] }
        }
        return out
    }

    /** Acrescenta o osso do outro lado de cada osso selecionado que o tenha no modelo. */
    fun withOpposites(selected: Collection<String>, known: Set<String>): Set<String> {
        val out = LinkedHashSet<String>(selected)
        for (n in selected) SideNames.opposite(n)?.let { if (it in known) out.add(it) }
        return out
    }

    enum class Region(val label: String) { HEAD("Cabeça"), TORSO("Tronco"), ARM_L("Braço esq."), ARM_R("Braço dir."), HAND_L("Mão esq."), HAND_R("Mão dir."), LEG_L("Perna esq."), LEG_R("Perna dir."), CENTER("Centro/IK"), OTHER("Outros") }

    /** Classifica o osso por nome (JP/EN) para grupos de seleção rápida. */
    fun regionOf(name: String): Region {
        val n = name
        val l = n.contains('左') || Regex("(?i)(?<![a-z])l(?![a-z])|left").containsMatchIn(n)
        val r = n.contains('右') || Regex("(?i)(?<![a-z])r(?![a-z])|right").containsMatchIn(n)
        fun has(vararg k: String) = k.any { n.contains(it, ignoreCase = true) }
        return when {
            has("親指", "人指", "中指", "薬指", "小指", "thumb", "index", "middle", "ring", "pinky", "finger") -> if (r && !l) Region.HAND_R else Region.HAND_L
            has("手首", "手", "wrist", "hand") && !has("手首先") -> if (r && !l) Region.HAND_R else Region.HAND_L
            has("腕", "ひじ", "肩", "arm", "elbow", "shoulder") -> if (r && !l) Region.ARM_R else Region.ARM_L
            has("足", "ひざ", "脚", "leg", "knee", "foot", "ankle", "toe", "thigh") -> if (r && !l) Region.LEG_R else Region.LEG_L
            has("頭", "首", "目", "head", "neck", "eye") -> Region.HEAD
            has("上半身", "下半身", "腰", "spine", "chest", "hip", "pelvis", "torso") -> Region.TORSO
            has("センター", "グルーブ", "全ての親", "ＩＫ", "IK", "center", "groove", "master") -> Region.CENTER
            else -> Region.OTHER
        }
    }

    fun group(names: Collection<String>): Map<Region, List<String>> {
        val m = java.util.EnumMap<Region, MutableList<String>>(Region::class.java)
        for (n in names) m.getOrPut(regionOf(n)) { ArrayList() }.add(n)
        return m
    }

    /** Compara conjuntos de seleção sem se importar com a ordem (para testes e Desfazer de seleção). */
    fun sameSet(a: Collection<Int>, b: Collection<Int>) = a.size == b.size && a.toSet() == b.toSet()
    fun near(a: Float, b: Float, eps: Float = 1e-4f) = abs(a - b) <= eps
}
