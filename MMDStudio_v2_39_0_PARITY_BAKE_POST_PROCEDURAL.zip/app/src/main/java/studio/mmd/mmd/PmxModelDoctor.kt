package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.sqrt

/** Severidade de uma ocorrência encontrada na auditoria estrutural do PMX. */
enum class PmxIssueSeverity { ERROR, WARNING, INFO }

data class PmxModelIssue(
    val severity: PmxIssueSeverity,
    val code: String,
    val message: String,
    val elementIndex: Int = -1
)

data class PmxModelAuditReport(
    val vertexCount: Int,
    val triangleCount: Int,
    val materialCount: Int,
    val boneCount: Int,
    val morphCount: Int,
    val rigidBodyCount: Int,
    val jointCount: Int,
    val errorCount: Int,
    val warningCount: Int,
    val issues: List<PmxModelIssue>
) {
    val healthy: Boolean get() = errorCount == 0
    val summary: String get() = when {
        errorCount > 0 -> "$errorCount erros e $warningCount avisos · exportação PMX requer revisão"
        warningCount > 0 -> "Estrutura válida com $warningCount avisos de compatibilidade/qualidade"
        else -> "Estrutura PMX consistente · nenhuma ocorrência detectada"
    }
}

/**
 * Auditor estrutural independente do parser e do renderer. Não modifica o PMX.
 * A validação cobre arrays, topologia, materiais, skinning, hierarquia, morphs e física.
 * Avisos são usados para dados válidos mas que podem ter comportamento aproximado no app.
 */
object PmxModelDoctor {
    fun inspect(model: PmxModel): PmxModelAuditReport {
        val out = ArrayList<PmxModelIssue>()
        fun issue(severity: PmxIssueSeverity, code: String, message: String, index: Int = -1) {
            out += PmxModelIssue(severity, code, message, index)
        }
        val n = model.vertexCount
        if (model.positions.size % 3 != 0) issue(PmxIssueSeverity.ERROR, "positions.shape", "O array de posições não contém triplas XYZ.")
        fun exact(name: String, actual: Int, expected: Int) {
            if (actual != expected) issue(PmxIssueSeverity.ERROR, "$name.shape", "$name tem $actual valores; esperado $expected.")
        }
        exact("normals", model.normals.size, n * 3)
        exact("uvs", model.uvs.size, n * 2)
        exact("boneIndices", model.boneIndices.size, n * 4)
        exact("boneWeights", model.boneWeights.size, n * 4)
        if (model.weightTypes.isNotEmpty()) exact("weightTypes", model.weightTypes.size, n)
        model.sdef?.let { exact("sdef", it.size, n * 9); if (it.any { v -> !v.isFinite() }) issue(PmxIssueSeverity.ERROR, "sdef.non_finite", "Parâmetros SDEF contêm valores não finitos.") }
        if (model.addUvCount !in 0..4) issue(PmxIssueSeverity.ERROR, "uv.extra.count", "Quantidade de UVs adicionais fora do intervalo PMX (0..4).")
        else if (model.addUvCount > 0) {
            exact("addUvs", model.addUvs.size, n * model.addUvCount * 4)
            if (model.addUvs.any { !it.isFinite() }) issue(PmxIssueSeverity.ERROR, "uv.extra.non_finite", "UVs adicionais contêm valores não finitos.")
        }
        if (model.edgeScale.isNotEmpty() && model.edgeScale.size != n) issue(PmxIssueSeverity.ERROR, "edge.scale.shape", "O array de escala de borda não corresponde à quantidade de vértices.")
        if (model.edgeScale.any { !it.isFinite() }) issue(PmxIssueSeverity.ERROR, "edge.scale.non_finite", "Escala de borda contém valores não finitos.")
        if (model.textEncoding !in 0..1) issue(PmxIssueSeverity.ERROR, "header.encoding", "Codificação de texto PMX inválida.")
        if (model.indexSizes.isNotEmpty() && (model.indexSizes.size < 6 || model.indexSizes.take(6).any { it !in setOf(1,2,4) }))
            issue(PmxIssueSeverity.ERROR, "header.index_sizes", "Tamanhos de índice do cabeçalho PMX inválidos.")
        if (model.version !in 2.0f..2.1f) issue(PmxIssueSeverity.WARNING, "header.version", "Versão ${model.version} fora das versões PMX 2.0/2.1 mais comuns.")
        if (model.indices.size % 3 != 0) issue(PmxIssueSeverity.ERROR, "indices.triangle_shape", "A lista de índices não termina em um triângulo completo.")

        var nonFinitePosition = 0
        for (i in model.positions.indices) if (!model.positions[i].isFinite()) nonFinitePosition++
        if (nonFinitePosition > 0) issue(PmxIssueSeverity.ERROR, "positions.non_finite", "$nonFinitePosition componentes de posição não são finitas.")
        var nonFiniteNormals = 0
        for (i in model.normals.indices) if (!model.normals[i].isFinite()) nonFiniteNormals++
        if (nonFiniteNormals > 0) issue(PmxIssueSeverity.ERROR, "normals.non_finite", "$nonFiniteNormals componentes de normal não são finitas.")
        var invalidIndices = 0
        for (idx in model.indices) if (idx !in 0 until n) invalidIndices++
        if (invalidIndices > 0) issue(PmxIssueSeverity.ERROR, "indices.range", "$invalidIndices índices apontam para fora da malha.")

        var degenerate = 0
        val usable = model.positions.size >= n * 3
        if (usable) for (i in 0 until model.indices.size - 2 step 3) {
            val a = model.indices[i]; val b = model.indices[i + 1]; val c = model.indices[i + 2]
            if (a !in 0 until n || b !in 0 until n || c !in 0 until n) continue
            if (a == b || b == c || c == a) { degenerate++; continue }
            val ao = a * 3; val bo = b * 3; val co = c * 3
            val abx = model.positions[bo] - model.positions[ao]; val aby = model.positions[bo + 1] - model.positions[ao + 1]; val abz = model.positions[bo + 2] - model.positions[ao + 2]
            val acx = model.positions[co] - model.positions[ao]; val acy = model.positions[co + 1] - model.positions[ao + 1]; val acz = model.positions[co + 2] - model.positions[ao + 2]
            val x = aby * acz - abz * acy; val y = abz * acx - abx * acz; val z = abx * acy - aby * acx
            val area2 = x * x + y * y + z * z
            if (!area2.isFinite() || area2 < 1e-14f) degenerate++
        }
        if (degenerate > 0) issue(PmxIssueSeverity.WARNING, "mesh.degenerate", "$degenerate triângulos degenerados ou com área praticamente zero.")

        val materialSum = model.materials.sumOf { it.indexCount.toLong() }
        if (model.materials.any { it.indexCount < 0 || it.indexCount % 3 != 0 })
            issue(PmxIssueSeverity.ERROR, "material.index_count", "Há materiais com indexCount negativo ou não divisível por 3.")
        if (materialSum != model.indices.size.toLong())
            issue(PmxIssueSeverity.ERROR, "material.partition", "A soma dos índices por material ($materialSum) difere da malha (${model.indices.size}).")
        model.materials.forEachIndexed { i, m ->
            if (m.textureIndex !in -1 until model.textures.size) issue(PmxIssueSeverity.ERROR, "material.texture", "Textura base inválida no material '${m.name}'.", i)
            if (m.sphereIndex !in -1 until model.textures.size) issue(PmxIssueSeverity.ERROR, "material.sphere", "Textura sphere inválida no material '${m.name}'.", i)
            if (m.toonShared && m.toonIndex !in 0..9) issue(PmxIssueSeverity.ERROR, "material.toon_shared", "Toon compartilhado fora do intervalo 0..9 no material '${m.name}'.", i)
            if (!m.toonShared && m.toonIndex !in -1 until model.textures.size) issue(PmxIssueSeverity.ERROR, "material.toon_texture", "Textura toon inválida no material '${m.name}'.", i)
            if (!m.specularPower.isFinite() || !m.edgeSize.isFinite() || m.diffuse.any { !it.isFinite() } || m.specular.any { !it.isFinite() } || m.ambient.any { !it.isFinite() })
                issue(PmxIssueSeverity.ERROR, "material.non_finite", "Material '${m.name}' contém parâmetros não finitos.", i)
        }

        // Skinning: verifica referências, pesos e soma; a auditoria mais específica de distribuição fica no Weight Doctor.
        val skinArrays = model.boneIndices.size >= n * 4 && model.boneWeights.size >= n * 4
        if (model.weightTypes.isNotEmpty()) {
            val invalidTypes = model.weightTypes.count { (it.toInt() and 0xff) !in 0..4 }
            if (invalidTypes > 0) issue(PmxIssueSeverity.ERROR, "skinning.type", "$invalidTypes vértices usam tipos de skinning fora de BDEF1/BDEF2/BDEF4/SDEF/QDEF.")
        }
        if (skinArrays) {
            var bad = 0; var unweighted = 0; var sumMismatch = 0
            for (v in 0 until n) {
                val base = v * 4; var sum = 0f; var has = false; var invalid = false
                for (k in 0..3) {
                    val bi = model.boneIndices[base + k]; val bw = model.boneWeights[base + k]
                    if (!bw.isFinite() || bw < 0f) invalid = true
                    if (bw.isFinite() && bw > 1e-6f) {
                        has = true; sum += bw
                        if (bi !in model.bones.indices) invalid = true
                    }
                }
                if (!has) unweighted++ else if (sum.isFinite() && abs(sum - 1f) > 0.03f) sumMismatch++
                if (invalid) bad++
            }
            if (bad > 0) issue(PmxIssueSeverity.ERROR, "skinning.invalid", "$bad vértices têm pesos inválidos ou referências a ossos inexistentes.")
            if (sumMismatch > 0) issue(PmxIssueSeverity.WARNING, "skinning.sum", "$sumMismatch vértices têm soma de pesos diferente de 1.")
            if (unweighted > 0) issue(PmxIssueSeverity.WARNING, "skinning.unweighted", "$unweighted vértices não têm influência óssea válida.")
        }

        val boneCount = model.bones.size
        model.bones.forEachIndexed { i, b ->
            if (b.parent !in -1 until boneCount || b.parent == i) issue(PmxIssueSeverity.ERROR, "bone.parent", "Pai inválido em '${b.name}'.", i)
            if ((b.flags and 0x0001) != 0 && b.tailBone !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "bone.tail", "Osso '${b.name}' aponta para uma cauda óssea inexistente.", i)
            if ((b.flags and 0x0300) != 0 && b.inheritParent !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "bone.inherit", "Osso '${b.name}' tem herança sem osso de origem válido.", i)
            if (!b.x.isFinite() || !b.y.isFinite() || !b.z.isFinite() || !b.inheritWeight.isFinite()) issue(PmxIssueSeverity.ERROR, "bone.non_finite", "Osso '${b.name}' contém coordenadas ou herança não finitas.", i)
            if (b.ik != null) {
                if (b.ik.target !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "bone.ik.target", "Alvo IK inválido em '${b.name}'.", i)
                if (b.ik.loopCount < 0 || !b.ik.limitAngle.isFinite()) issue(PmxIssueSeverity.ERROR, "bone.ik.settings", "Configuração IK inválida em '${b.name}'.", i)
                b.ik.links.forEach { link ->
                    if (link.bone !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "bone.ik.link", "Link IK inválido em '${b.name}'.", i)
                    if (link.hasLimit && (link.min == null || link.max == null || link.min.size < 3 || link.max.size < 3 || link.min.any { !it.isFinite() } || link.max.any { !it.isFinite() }))
                        issue(PmxIssueSeverity.ERROR, "bone.ik.limit", "Limites IK incompletos ou não finitos em '${b.name}'.", i)
                }
            }
        }
        // Ciclos de pai: DFS com estados 0=novo, 1=pilha, 2=concluído.
        val state = IntArray(boneCount)
        fun visit(start: Int) {
            var cur = start
            val path = ArrayList<Int>()
            while (cur in 0 until boneCount && state[cur] == 0) {
                state[cur] = 1; path += cur
                cur = model.bones[cur].parent
            }
            if (cur in 0 until boneCount && state[cur] == 1)
                issue(PmxIssueSeverity.ERROR, "bone.parent_cycle", "Ciclo detectado na hierarquia de ossos (envolve '${model.bones[cur].name}').", cur)
            path.forEach { state[it] = 2 }
        }
        for (i in 0 until boneCount) if (state[i] == 0) visit(i)

        val morphCount = model.morphs.size
        model.morphs.forEachIndexed { i, m ->
            when (m.type) {
                0, 9 -> {
                    val gi = m.groupIdx; val gr = m.groupRate
                    if (gi == null || gr == null || gi.size != gr.size) issue(PmxIssueSeverity.ERROR, "morph.group.shape", "Morph '${m.name}' tem elementos de grupo/flip inconsistentes.", i)
                    else {
                        gi.forEach { if (it !in 0 until morphCount) issue(PmxIssueSeverity.ERROR, "morph.group.reference", "Morph '${m.name}' aponta para morph inexistente.", i) }
                        if (gr.any { !it.isFinite() }) issue(PmxIssueSeverity.ERROR, "morph.group.non_finite", "Morph '${m.name}' contém taxas não finitas.", i)
                    }
                }
                1 -> {
                    val vi = m.vertexIdx; val vd = m.vertexDelta
                    if (vi == null || vd == null || vd.size != vi.size * 3) issue(PmxIssueSeverity.ERROR, "morph.vertex.shape", "Morph de vértice '${m.name}' tem dados incompletos.", i)
                    else {
                        vi.forEach { if (it !in 0 until n) issue(PmxIssueSeverity.ERROR, "morph.vertex.reference", "Morph '${m.name}' aponta para vértice inexistente.", i) }
                        if (vd.any { !it.isFinite() }) issue(PmxIssueSeverity.ERROR, "morph.vertex.non_finite", "Morph '${m.name}' contém deltas não finitos.", i)
                    }
                }
                2 -> {
                    val bi = m.boneIdx; val bt = m.boneTrans; val br = m.boneRot
                    if (bi == null || bt == null || br == null || bt.size != bi.size * 3 || br.size != bi.size * 4) issue(PmxIssueSeverity.ERROR, "morph.bone.shape", "Morph ósseo '${m.name}' tem dados incompletos.", i)
                    else {
                        bi.forEach { if (it !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "morph.bone.reference", "Morph '${m.name}' aponta para osso inexistente.", i) }
                        if (bt.any { !it.isFinite() } || br.any { !it.isFinite() }) issue(PmxIssueSeverity.ERROR, "morph.bone.non_finite", "Morph '${m.name}' contém transformações não finitas.", i)
                    }
                }
                in 3..8, 10 -> if (m.raw == null && m.count > 0) issue(PmxIssueSeverity.WARNING, "morph.raw.missing", "Morph '${m.name}' tem tipo ${m.type} sem payload bruto preservado.", i)
                else -> issue(PmxIssueSeverity.WARNING, "morph.type.unknown", "Morph '${m.name}' usa tipo ${m.type} não reconhecido.", i)
            }
        }

        model.displayFrames.forEachIndexed { frameIndex, frame ->
            frame.elements.forEach { pair ->
                if (pair.size < 2) issue(PmxIssueSeverity.ERROR, "display.element.shape", "Frame de exibição '${frame.name}' contém elemento incompleto.", frameIndex)
                else if (pair[0] == 0 && pair[1] !in 0 until boneCount) issue(PmxIssueSeverity.ERROR, "display.bone.reference", "Frame '${frame.name}' aponta para osso inexistente.", frameIndex)
                else if (pair[0] == 1 && pair[1] !in 0 until morphCount) issue(PmxIssueSeverity.ERROR, "display.morph.reference", "Frame '${frame.name}' aponta para morph inexistente.", frameIndex)
                else if (pair[0] !in 0..1) issue(PmxIssueSeverity.WARNING, "display.element.type", "Frame '${frame.name}' contém tipo de elemento desconhecido.", frameIndex)
            }
        }
        model.rigidBodies.forEachIndexed { i, r ->
            if (r.bone !in -1 until boneCount) issue(PmxIssueSeverity.ERROR, "rigid.bone", "Corpo rígido '${r.name}' referencia osso inexistente.", i)
            if (r.group !in 0..15 || r.mask !in 0..65535) issue(PmxIssueSeverity.ERROR, "rigid.filter", "Filtro de colisão inválido em '${r.name}'.", i)
            if (r.shape !in 0..2 || r.mode !in 0..2) issue(PmxIssueSeverity.ERROR, "rigid.type", "Forma ou modo inválido em '${r.name}'.", i)
            if (!r.mass.isFinite() || r.mass < 0f || !r.size.all(Float::isFinite) || !r.pos.all(Float::isFinite) || !r.rot.all(Float::isFinite))
                issue(PmxIssueSeverity.ERROR, "rigid.non_finite", "Corpo rígido '${r.name}' contém parâmetros inválidos.", i)
        }
        model.joints.forEachIndexed { i, j ->
            if (j.a !in 0 until model.rigidBodies.size || j.b !in 0 until model.rigidBodies.size)
                issue(PmxIssueSeverity.ERROR, "joint.rigid_reference", "Junta '${j.name}' referencia corpo rígido inexistente.", i)
            val arrays = listOf(j.pos, j.rot, j.posMin, j.posMax, j.rotMin, j.rotMax, j.springPos, j.springRot)
            if (arrays.any { it.size < 3 || it.any { f -> !f.isFinite() } }) issue(PmxIssueSeverity.ERROR, "joint.parameters", "Junta '${j.name}' tem parâmetros incompletos ou não finitos.", i)
        }
        if (model.softBodyCount > 0 && (model.softBodyRaw == null || model.softBodyRaw.isEmpty()))
            issue(PmxIssueSeverity.WARNING, "softbody.payload", "O cabeçalho informa soft bodies, mas o payload bruto não está disponível.")
        if (model.warnings.isNotEmpty()) model.warnings.forEach { issue(PmxIssueSeverity.INFO, "import.warning", it) }
        val errors = out.count { it.severity == PmxIssueSeverity.ERROR }
        val warnings = out.count { it.severity == PmxIssueSeverity.WARNING }
        return PmxModelAuditReport(n, model.indices.size / 3, model.materials.size, boneCount, morphCount,
            model.rigidBodies.size, model.joints.size, errors, warnings, out)
    }
}
