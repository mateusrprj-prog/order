package studio.mmd.mmd

import kotlin.math.abs

/** Diagnóstico de corpos rígidos, juntas e soft bodies PMX. Não executa simulação. */
enum class PmxPhysicsSeverity { ERROR, WARNING }
data class PmxPhysicsIssue(val severity: PmxPhysicsSeverity, val code: String, val message: String, val elementIndex: Int = -1)
data class PmxPhysicsReport(
    val rigidBodies: Int, val joints: Int, val softBodies: Int,
    val errors: Int, val warnings: Int, val issues: List<PmxPhysicsIssue>
) { val healthy get() = errors == 0; val summary get() = "$rigidBodies rigid bodies · $joints juntas · $softBodies soft bodies · $errors erros · $warnings avisos" }
data class PmxPhysicsRepairResult(val model: PmxModel, val repairedRigidBodies: Int, val repairedJoints: Int, val removedJoints: Int)

object PmxPhysicsDoctor {
    fun inspect(model: PmxModel): PmxPhysicsReport {
        val out = ArrayList<PmxPhysicsIssue>()
        fun add(sev: PmxPhysicsSeverity, code: String, msg: String, i: Int = -1) { out += PmxPhysicsIssue(sev, code, msg, i) }
        model.rigidBodies.forEachIndexed { i, r ->
            if (r.bone !in -1 until model.bones.size) add(PmxPhysicsSeverity.ERROR, "rigid.bone", "Corpo rígido '${r.name}' referencia osso inexistente.", i)
            if (r.group !in 0..15) add(PmxPhysicsSeverity.ERROR, "rigid.group", "Grupo de colisão de '${r.name}' fora de 0..15.", i)
            if (r.shape !in 0..2) add(PmxPhysicsSeverity.ERROR, "rigid.shape", "Forma desconhecida em '${r.name}'.", i)
            if (r.mode !in 0..2) add(PmxPhysicsSeverity.ERROR, "rigid.mode", "Modo físico desconhecido em '${r.name}'.", i)
            if (r.size.size < 3 || r.size.take(3).any { !it.isFinite() || it <= 0f }) add(PmxPhysicsSeverity.ERROR, "rigid.size", "Dimensões inválidas em '${r.name}'.", i)
            if (!r.mass.isFinite() || r.mass < 0f) add(PmxPhysicsSeverity.ERROR, "rigid.mass", "Massa inválida em '${r.name}'.", i)
            if (!r.linearDamping.isFinite() || r.linearDamping !in 0f..1f) add(PmxPhysicsSeverity.WARNING, "rigid.linear_damping", "Amortecimento linear fora de 0..1 em '${r.name}'.", i)
            if (!r.angularDamping.isFinite() || r.angularDamping !in 0f..1f) add(PmxPhysicsSeverity.WARNING, "rigid.angular_damping", "Amortecimento angular fora de 0..1 em '${r.name}'.", i)
            if (!r.restitution.isFinite() || r.restitution !in 0f..1f) add(PmxPhysicsSeverity.WARNING, "rigid.restitution", "Restituição fora de 0..1 em '${r.name}'.", i)
            if (!r.friction.isFinite() || r.friction !in 0f..1f) add(PmxPhysicsSeverity.WARNING, "rigid.friction", "Atrito fora de 0..1 em '${r.name}'.", i)
            if (r.pos.size < 3 || r.rot.size < 3 || r.pos.take(3).any { !it.isFinite() } || r.rot.take(3).any { !it.isFinite() }) add(PmxPhysicsSeverity.ERROR, "rigid.transform", "Transformação inválida em '${r.name}'.", i)
        }
        val jointTypes = if (model.version >= 2.05f) 0..5 else 0..0
        model.joints.forEachIndexed { i, j ->
            if (j.type !in jointTypes) add(PmxPhysicsSeverity.ERROR, "joint.type", "Tipo de junta ${j.type} inválido para PMX ${model.version} em '${j.name}'.", i)
            if (j.a !in model.rigidBodies.indices || j.b !in model.rigidBodies.indices || j.a == j.b) add(PmxPhysicsSeverity.ERROR, "joint.references", "Junta '${j.name}' referencia corpos inválidos ou o mesmo corpo.", i)
            val arrays = listOf(j.pos, j.rot, j.posMin, j.posMax, j.rotMin, j.rotMax, j.springPos, j.springRot)
            if (arrays.any { it.size < 3 || it.take(3).any { v -> !v.isFinite() } }) add(PmxPhysicsSeverity.ERROR, "joint.non_finite", "Junta '${j.name}' contém vetores incompletos ou não finitos.", i)
            else {
                if ((0..2).any { j.posMin[it] > j.posMax[it] || j.rotMin[it] > j.rotMax[it] }) add(PmxPhysicsSeverity.WARNING, "joint.range", "Limites mínimo/máximo invertidos em '${j.name}'.", i)
                if ((j.springPos + j.springRot).take(6).any { it < 0f }) add(PmxPhysicsSeverity.WARNING, "joint.spring", "Junta '${j.name}' contém mola negativa.", i)
            }
        }
        model.softBodies.forEachIndexed { i, sb ->
            if (sb.shape !in 0..1) add(PmxPhysicsSeverity.ERROR, "soft.shape", "Shape desconhecido em '${sb.name}'.", i)
            if (sb.material !in model.materials.indices) add(PmxPhysicsSeverity.ERROR, "soft.material", "Material inexistente em '${sb.name}'.", i)
            if (sb.flags and 0xF8 != 0) add(PmxPhysicsSeverity.WARNING, "soft.flags", "Flags reservadas ativadas em '${sb.name}'.", i)
            if (sb.group !in 0..15) add(PmxPhysicsSeverity.ERROR, "soft.group", "Grupo de colisão inválido em '${sb.name}'.", i)
            if (!sb.totalMass.isFinite() || sb.totalMass < 0f || !sb.collisionMargin.isFinite() || sb.collisionMargin < 0f) add(PmxPhysicsSeverity.ERROR, "soft.mass_margin", "Massa ou margem inválida em '${sb.name}'.", i)
            if (sb.aeroModel !in 0..4) add(PmxPhysicsSeverity.ERROR, "soft.aero", "Modelo aerodinâmico inválido em '${sb.name}'.", i)
            if (sb.config.size != 12 || sb.config.any { !it.isFinite() } || sb.cluster.size != 6 || sb.cluster.any { !it.isFinite() }) add(PmxPhysicsSeverity.ERROR, "soft.config", "Coeficientes inválidos em '${sb.name}'.", i)
            if (sb.anchors.any { it.rigidBody !in model.rigidBodies.indices || it.vertex !in 0 until model.vertexCount }) add(PmxPhysicsSeverity.ERROR, "soft.anchor", "Anchor de '${sb.name}' referencia corpo/vértice inexistente.", i)
            if (sb.pins.any { it !in 0 until model.vertexCount }) add(PmxPhysicsSeverity.ERROR, "soft.pin", "Pin de '${sb.name}' referencia vértice inexistente.", i)
            if (sb.iterations.size != 4 || sb.iterations.any { it < 0 } || sb.materialStiffness.size != 3 || sb.materialStiffness.any { it < 0 }) add(PmxPhysicsSeverity.WARNING, "soft.iterations", "Iterações/stiffness inválidas em '${sb.name}'.", i)
        }
        if (model.softBodyCount > 0 && model.softBodies.isEmpty()) add(PmxPhysicsSeverity.WARNING, "soft.unparsed", "Soft bodies existem apenas como bytes brutos; recarregue o PMX com o leitor estruturado para auditoria de campos.")
        return PmxPhysicsReport(model.rigidBodies.size, model.joints.size, model.softBodyCount, out.count { it.severity == PmxPhysicsSeverity.ERROR }, out.count { it.severity == PmxPhysicsSeverity.WARNING }, out)
    }

    /** Repara apenas valores cujo default/correção é inequívoco; remove juntas órfãs e não inventa corpos. */
    fun repair(model: PmxModel): PmxPhysicsRepairResult {
        var rbFixed = 0; var jointFixed = 0; var removed = 0
        val rigids = model.rigidBodies.map { r ->
            val size = FloatArray(3) { k -> r.size.getOrNull(k)?.takeIf { it.isFinite() && it > 1e-4f } ?: 0.01f }
            val pos = FloatArray(3) { k -> r.pos.getOrNull(k)?.takeIf { it.isFinite() } ?: 0f }
            val rot = FloatArray(3) { k -> r.rot.getOrNull(k)?.takeIf { it.isFinite() } ?: 0f }
            val fixed = PmxRigid(r.name, r.nameEn, r.bone.takeIf { it in -1 until model.bones.size } ?: -1,
                r.group.coerceIn(0, 15), r.shape.coerceIn(0, 2), r.mass.takeIf { it.isFinite() && it >= 0f } ?: 0f,
                (r.linearDamping.takeIf { it.isFinite() } ?: 0f).coerceIn(0f, 1f),
                (r.angularDamping.takeIf { it.isFinite() } ?: 0f).coerceIn(0f, 1f), r.mode.coerceIn(0, 2),
                r.mask and 0xFFFF, size, pos, rot,
                (r.restitution.takeIf { it.isFinite() } ?: 0f).coerceIn(0f, 1f),
                (r.friction.takeIf { it.isFinite() } ?: 0.5f).coerceIn(0f, 1f))
            if (fixed !== r && (fixed.bone != r.bone || fixed.group != r.group || fixed.shape != r.shape || fixed.mass != r.mass ||
                fixed.linearDamping != r.linearDamping || fixed.angularDamping != r.angularDamping || fixed.mode != r.mode ||
                !fixed.size.contentEquals(r.size) || !fixed.pos.contentEquals(r.pos) || !fixed.rot.contentEquals(r.rot) || fixed.restitution != r.restitution || fixed.friction != r.friction)) rbFixed++
            fixed
        }
        val joints = model.joints.mapNotNull { j ->
            val typeValid = if (model.version >= 2.05f) j.type in 0..5 else j.type == 0
            if (j.a !in rigids.indices || j.b !in rigids.indices || j.a == j.b || !typeValid) { removed++; return@mapNotNull null }
            fun vec(a: FloatArray, fallback: Float = 0f) = FloatArray(3) { k -> a.getOrNull(k)?.takeIf { it.isFinite() } ?: fallback }
            val p0 = vec(j.pos); val r0 = vec(j.rot); val pmin = vec(j.posMin); val pmax = vec(j.posMax)
            val rmin = vec(j.rotMin); val rmax = vec(j.rotMax)
            for (k in 0..2) { if (pmin[k] > pmax[k]) { val t = pmin[k]; pmin[k] = pmax[k]; pmax[k] = t }; if (rmin[k] > rmax[k]) { val t = rmin[k]; rmin[k] = rmax[k]; rmax[k] = t } }
            val sp = vec(j.springPos).map { it.coerceAtLeast(0f) }.toFloatArray()
            val sr = vec(j.springRot).map { it.coerceAtLeast(0f) }.toFloatArray()
            val clean = PmxJoint(j.name, j.a, j.b, p0, r0, pmin, pmax, rmin, rmax, sp, sr, j.type.coerceIn(0, 5), j.nameEn)
            if (listOf(j.pos,j.rot,j.posMin,j.posMax,j.rotMin,j.rotMax,j.springPos,j.springRot).any { it.size < 3 || it.take(3).any { v -> !v.isFinite() } } || j.springPos.any { it < 0f } || j.springRot.any { it < 0f } ||
                (0..2).any { pmin[it] != j.posMin.getOrNull(it) || pmax[it] != j.posMax.getOrNull(it) || rmin[it] != j.rotMin.getOrNull(it) || rmax[it] != j.rotMax.getOrNull(it) } || j.type !in 0..5) jointFixed++
            clean
        }
        val repaired = PmxModel(model.name, model.version, model.positions, model.normals, model.uvs, model.boneIndices, model.boneWeights,
            model.indices, model.textures, model.materials, model.bones, model.morphs, rigids, joints,
            model.nameEn, model.comment, model.commentEn, model.displayFrames, model.addUvCount, model.addUvs, model.weightTypes,
            model.sdef, model.edgeScale, model.textEncoding, model.indexSizes, model.softBodyCount, model.softBodyRaw, model.warnings, model.softBodies)
        return PmxPhysicsRepairResult(repaired, rbFixed, jointFixed, removed)
    }
}
