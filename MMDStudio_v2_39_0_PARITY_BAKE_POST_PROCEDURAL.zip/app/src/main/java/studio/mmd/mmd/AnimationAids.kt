package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * v2.32.0 — Ajudas de animação do MMD oficial: forma de onda do áudio por quadro, marcadores de batida e onion skin.
 * Kotlin puro; quem integra decodifica o áudio para PCM 16 bits e desenha o resultado.
 */
object WaveformPeaks {

    /** Pico (0..1) de cada quadro. [pcm] é PCM 16 bits intercalado; [channels] >= 1. */
    fun peaks(pcm: ShortArray, channels: Int, sampleRate: Int, fps: Int, totalFrames: Int): FloatArray {
        if (channels < 1 || sampleRate < 1 || fps < 1 || totalFrames < 1) return FloatArray(0)
        val out = FloatArray(totalFrames)
        val perFrame = sampleRate.toDouble() / fps
        val frames = pcm.size / channels
        for (f in 0 until totalFrames) {
            val a = (f * perFrame).toLong()
            val b = ((f + 1) * perFrame).toLong().coerceAtMost(frames.toLong())
            if (a >= frames) break
            var peak = 0
            var i = a
            while (i < b) {
                for (c in 0 until channels) {
                    val v = abs(pcm[(i * channels + c).toInt()].toInt())
                    if (v > peak) peak = v
                }
                i++
            }
            out[f] = (peak / 32768f).coerceIn(0f, 1f)
        }
        return out
    }

    /** RMS (0..1) de cada quadro, melhor que o pico para detectar batidas. */
    fun rms(pcm: ShortArray, channels: Int, sampleRate: Int, fps: Int, totalFrames: Int): FloatArray {
        if (channels < 1 || sampleRate < 1 || fps < 1 || totalFrames < 1) return FloatArray(0)
        val out = FloatArray(totalFrames)
        val perFrame = sampleRate.toDouble() / fps
        val frames = pcm.size / channels
        for (f in 0 until totalFrames) {
            val a = (f * perFrame).toLong()
            val b = ((f + 1) * perFrame).toLong().coerceAtMost(frames.toLong())
            if (a >= frames) break
            var sum = 0.0; var n = 0
            var i = a
            while (i < b) {
                for (c in 0 until channels) { val v = pcm[(i * channels + c).toInt()] / 32768.0; sum += v * v; n++ }
                i++
            }
            if (n > 0) out[f] = sqrt(sum / n).toFloat().coerceIn(0f, 1f)
        }
        return out
    }
}

object BeatMarkers {
    /**
     * Detecta batidas por fluxo de energia: um quadro é batida se a energia sobe acima de [sensitivity] vezes a média
     * móvel dos [window] quadros anteriores e é máximo local. [minGapFrames] evita batidas coladas.
     */
    fun detect(rms: FloatArray, window: Int = 12, sensitivity: Float = 1.5f, minGapFrames: Int = 6, floor: Float = 0.02f): IntArray {
        if (rms.size < 3) return IntArray(0)
        val w = window.coerceAtLeast(2)
        val out = ArrayList<Int>()
        var last = -minGapFrames
        for (i in 1 until rms.size - 1) {
            val from = (i - w).coerceAtLeast(0)
            var avg = 0f
            for (j in from until i) avg += rms[j]
            avg /= (i - from).coerceAtLeast(1)
            val v = rms[i]
            if (v >= floor && v > avg * sensitivity && v >= rms[i - 1] && v > rms[i + 1] && i - last >= minGapFrames) {
                out.add(i); last = i
            }
        }
        return out.toIntArray()
    }

    /** BPM estimado pela mediana dos intervalos entre batidas; 0 se houver menos de 3 batidas. */
    fun estimateBpm(beats: IntArray, fps: Int): Float {
        if (beats.size < 3 || fps < 1) return 0f
        val d = IntArray(beats.size - 1) { beats[it + 1] - beats[it] }.sorted()
        val med = d[d.size / 2]
        if (med <= 0) return 0f
        var bpm = 60f * fps / med
        while (bpm < 70f) bpm *= 2f
        while (bpm > 190f) bpm /= 2f
        return bpm
    }

    /** Ajusta [frame] para a batida mais próxima dentro de [radius] quadros; devolve o mesmo frame se não houver. */
    fun snap(frame: Int, beats: IntArray, radius: Int = 3): Int {
        var best = frame; var bd = radius + 1
        for (b in beats) { val d = abs(b - frame); if (d < bd) { bd = d; best = b } }
        return if (bd <= radius) best else frame
    }
}

/** Onion skin: quais quadros fantasma desenhar antes/depois do quadro atual e com que opacidade. */
object OnionSkin {
    class Ghost(val frame: Int, val alpha: Float, val before: Boolean)

    fun plan(current: Int, before: Int, after: Int, step: Int, maxFrame: Int, baseAlpha: Float = 0.35f): List<Ghost> {
        val s = step.coerceAtLeast(1)
        val out = ArrayList<Ghost>()
        for (i in 1..before.coerceIn(0, 12)) {
            val f = current - i * s
            if (f < 0) break
            out.add(Ghost(f, (baseAlpha / i).coerceIn(0.02f, 1f), true))
        }
        for (i in 1..after.coerceIn(0, 12)) {
            val f = current + i * s
            if (f > maxFrame) break
            out.add(Ghost(f, (baseAlpha / i).coerceIn(0.02f, 1f), false))
        }
        return out
    }
}
