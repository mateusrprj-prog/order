package studio.mmd.mmd

/** Fonte do toon-map associada a um material PMX. */
enum class PmxToonSource { NONE, SHARED, TEXTURE, INVALID }

data class PmxToonBinding(val source: PmxToonSource, val index: Int = -1) {
    val enabled: Boolean get() = source == PmxToonSource.SHARED || source == PmxToonSource.TEXTURE
}

/** Resolve o campo de referência de toon PMX 2.0/2.1 sem confundir byte compartilhado com índice de textura. */
object PmxToonBindingResolver {
    fun resolve(material: PmxMaterial, textureCount: Int): PmxToonBinding {
        if (material.toonShared) return if (material.toonIndex in 0..9)
            PmxToonBinding(PmxToonSource.SHARED, material.toonIndex)
        else PmxToonBinding(PmxToonSource.INVALID, material.toonIndex)
        if (material.toonIndex == -1) return PmxToonBinding(PmxToonSource.NONE)
        return if (material.toonIndex in 0 until textureCount)
            PmxToonBinding(PmxToonSource.TEXTURE, material.toonIndex)
        else PmxToonBinding(PmxToonSource.INVALID, material.toonIndex)
    }
}
