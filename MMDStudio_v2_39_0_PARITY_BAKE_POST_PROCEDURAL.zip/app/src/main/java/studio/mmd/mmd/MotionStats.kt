package studio.mmd.mmd

import kotlin.math.abs

/** v2.39.0 — Estatísticas e utilitários de leitura de um movimento (painel de informações do MMD). Kotlin puro. */
object MotionStats {
    class TrackInfo(val name: String, val keys: Int, val first: Int, val last: Int, val isMorph: Boolean)
    class Summary(val boneTracks: Int, val morphTracks: Int, val boneKeys: Int, val morphKeys: Int, val lastFrame: Int, val busiest: List<TrackInfo>, val emptyFrames: Int)

    fun summarize(m: VmdMotion, topN: Int = 8): Summary {
        val infos = ArrayList<TrackInfo>()
        var bk = 0; var mk = 0; var last = 0
        val used = HashSet<Int>()
        for ((n, t) in m.bones) { if (t.frames.isEmpty()) continue; bk += t.frames.size; infos.add(TrackInfo(n, t.frames.size, t.frames.first(), t.frames.last(), false)); last = maxOf(last, t.frames.last()); t.frames.forEach { used.add(it) } }
        for ((n, t) in m.morphs) { if (t.frames.isEmpty()) continue; mk += t.frames.size; infos.add(TrackInfo(n, t.frames.size, t.frames.first(), t.frames.last(), true)); last = maxOf(last, t.frames.last()); t.frames.forEach { used.add(it) } }
        val empty = if (last <= 0) 0 else (0..last).count { it !in used }
        return Summary(infos.count { !it.isMorph }, infos.count { it.isMorph }, bk, mk, last, infos.sortedByDescending { it.keys }.take(topN.coerceAtLeast(1)), empty)
    }

    /** Duração em segundos de [frames] a [fps]. */
    fun seconds(frames: Int, fps: Int) = if (fps < 1) 0f else frames.coerceAtLeast(0).toFloat() / fps

    /** "mm:ss:ff" como no MMD. */
    fun timecode(frame: Int, fps: Int): String {
        val f = frame.coerceAtLeast(0); val r = fps.coerceAtLeast(1)
        val s = f / r
        return "%02d:%02d:%02d".format(s / 60, s % 60, f % r)
    }

    /** Frame a partir de "mm:ss:ff" ou "ss:ff" ou número simples; null se inválido. */
    fun parseTimecode(text: String, fps: Int): Int? {
        val r = fps.coerceAtLeast(1)
        val p = text.trim().split(':')
        val n = p.map { it.trim().toIntOrNull() ?: return null }
        if (n.any { it < 0 }) return null
        return when (n.size) { 1 -> n[0]; 2 -> n[0] * r + n[1]; 3 -> (n[0] * 60 + n[1]) * r + n[2]; else -> null }
    }

    /** Movimento mais rápido: para cada osso, maior deslocamento por quadro; ajuda a achar glitches. Retorna (osso, frame, velocidade). */
    fun fastest(m: VmdMotion, limit: Int = 5): List<Triple<String, Int, Float>> {
        val out = ArrayList<Triple<String, Int, Float>>()
        for ((n, t) in m.bones) {
            val c = minOf(t.frames.size, t.v.size / 7)
            var best = 0f; var bf = 0
            for (i in 1 until c) {
                val df = (t.frames[i] - t.frames[i - 1]).coerceAtLeast(1)
                var d2 = 0f; for (k in 0..2) { val e = t.v[i * 7 + k] - t.v[(i - 1) * 7 + k]; d2 += e * e }
                val v = Math.sqrt(d2.toDouble()).toFloat() / df
                if (v > best) { best = v; bf = t.frames[i] }
            }
            if (best > 0f) out.add(Triple(n, bf, best))
        }
        return out.sortedByDescending { it.third }.take(limit.coerceAtLeast(1))
    }

    fun near(a: Float, b: Float, e: Float = 1e-4f) = abs(a - b) <= e
}
