package studio.mmd.mmd

import kotlin.math.acos
import kotlin.math.sin
import kotlin.math.sqrt

/** Interpolação glTF 2.0 de um canal de animação (Release 9). Kotlin puro, sem Android: testável em JVM. */
enum class GltfInterp { STEP, LINEAR, CUBICSPLINE;
    companion object { fun parse(s: String?): GltfInterp? = when (s ?: "LINEAR") { "STEP" -> STEP; "LINEAR" -> LINEAR; "CUBICSPLINE" -> CUBICSPLINE; else -> null } }
}

/**
 * [times] em segundos, estritamente crescentes. [values]: [comps] floats por key (STEP/LINEAR) ou 3*[comps] (CUBICSPLINE: in-tangente, valor, out-tangente).
 * [rotation] = quaternion (x,y,z,w): usa slerp no LINEAR e normaliza no CUBICSPLINE.
 */
class GltfSampler(val times: FloatArray, val values: FloatArray, val comps: Int, val interp: GltfInterp, val rotation: Boolean = false) {
    init {
        require(comps > 0) { "comps inválido" }
        require(times.isNotEmpty()) { "sampler sem keys" }
        val per = if (interp == GltfInterp.CUBICSPLINE) 3 * comps else comps
        require(values.size == times.size * per) { "tamanho dos valores (${values.size}) não bate com ${times.size} keys" }
        for (i in 1 until times.size) require(times[i] > times[i - 1]) { "tempos não crescentes na key $i" }
        if (interp == GltfInterp.CUBICSPLINE) require(times.size >= 2) { "CUBICSPLINE exige 2+ keys" }
    }

    val duration: Float get() = times.last()

    private fun v(k: Int, off: Int = 0): Int = if (interp == GltfInterp.CUBICSPLINE) (k * 3 + 1 + off) * comps else k * comps

    /** Avalia no tempo [t] (fora do intervalo fica na primeira/última key, sem extrapolar). Escreve em [out] (tamanho >= comps). */
    fun eval(t: Float, out: FloatArray) {
        val n = times.size
        if (t <= times[0] || n == 1) { copy(0, out); return }
        if (t >= times[n - 1]) { copy(n - 1, out); return }
        var lo = 0; var hi = n - 1
        while (hi - lo > 1) { val m = (lo + hi) ushr 1; if (times[m] <= t) lo = m else hi = m }
        val dt = times[hi] - times[lo]; val s = (t - times[lo]) / dt
        when (interp) {
            GltfInterp.STEP -> copy(lo, out)
            GltfInterp.LINEAR -> {
                if (rotation && comps == 4) slerp(values, v(lo), v(hi), s, out)
                else for (c in 0 until comps) out[c] = values[v(lo) + c] * (1 - s) + values[v(hi) + c] * s
            }
            GltfInterp.CUBICSPLINE -> {
                val s2 = s * s; val s3 = s2 * s
                val h00 = 2 * s3 - 3 * s2 + 1; val h10 = s3 - 2 * s2 + s; val h01 = -2 * s3 + 3 * s2; val h11 = s3 - s2
                for (c in 0 until comps) {
                    val p0 = values[v(lo) + c]; val m0 = values[v(lo, 1) + c] * dt   // out-tangente da key anterior
                    val p1 = values[v(hi) + c]; val m1 = values[v(hi, -1) + c] * dt   // in-tangente da próxima
                    out[c] = h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1
                }
                if (rotation && comps == 4) normalize(out)
            }
        }
    }

    private fun copy(k: Int, out: FloatArray) { for (c in 0 until comps) out[c] = values[v(k) + c] }

    companion object {
        fun normalize(q: FloatArray) {
            val l = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
            if (l < 1e-8f) { q[0] = 0f; q[1] = 0f; q[2] = 0f; q[3] = 1f } else for (i in 0 until 4) q[i] /= l
        }
        fun slerp(a: FloatArray, ia: Int, ib: Int, s: Float, out: FloatArray) {
            var dot = a[ia] * a[ib] + a[ia + 1] * a[ib + 1] + a[ia + 2] * a[ib + 2] + a[ia + 3] * a[ib + 3]
            val sg = if (dot < 0f) -1f else 1f; dot *= sg   // caminho mais curto
            val w0: Float; val w1: Float
            if (dot > 0.9995f) { w0 = 1 - s; w1 = s }
            else { val th = acos(dot.coerceAtMost(1f)); val sn = sin(th); w0 = sin((1 - s) * th) / sn; w1 = sin(s * th) / sn }
            for (i in 0 until 4) out[i] = w0 * a[ia + i] + w1 * sg * a[ib + i]
            normalize(out)
        }
    }
}

/** Um canal de animação glTF: alvo (nó + propriedade) e o amostrador. [bone] = índice do osso do [PmxModel] importado (-1 = nó que não é osso). */
class GltfChannel(val node: Int, val nodeName: String, val bone: Int, val path: String, val sampler: GltfSampler)

/** Uma animação do arquivo (glTF "animation"). Ainda NÃO é aplicada ao Animator (fatia 9.3). */
class GltfClip(val name: String, val channels: List<GltfChannel>) {
    val duration: Float get() = channels.maxOfOrNull { it.sampler.duration } ?: 0f
}
