package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * v2.36.0 — Matemática do manipulador de ossos do MMD oficial: eixos locais/globais/de vista, arrasto → rotação,
 * ângulo no anel e snap. Quaternions em (x, y, z, w). Kotlin puro.
 */
object GizmoMath {

    fun normalize(v: FloatArray): FloatArray {
        val l = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        return if (l < 1e-8f || !l.isFinite()) floatArrayOf(0f, 0f, 0f) else floatArrayOf(v[0] / l, v[1] / l, v[2] / l)
    }

    fun cross(a: FloatArray, b: FloatArray) = floatArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
    fun dot(a: FloatArray, b: FloatArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

    fun quatAxisAngle(axis: FloatArray, rad: Float): FloatArray {
        val a = normalize(axis)
        if (!rad.isFinite() || (a[0] == 0f && a[1] == 0f && a[2] == 0f)) return floatArrayOf(0f, 0f, 0f, 1f)
        val s = sin(rad / 2)
        return floatArrayOf(a[0] * s, a[1] * s, a[2] * s, cos(rad / 2))
    }

    /** Produto de Hamilton a·b (aplica b e depois a, na convenção v' = a·b·v). */
    fun quatMul(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
    )

    fun quatConj(q: FloatArray) = floatArrayOf(-q[0], -q[1], -q[2], q[3])

    fun rotate(q: FloatArray, v: FloatArray): FloatArray {
        val p = floatArrayOf(v[0], v[1], v[2], 0f)
        val r = quatMul(quatMul(q, p), quatConj(q))
        return floatArrayOf(r[0], r[1], r[2])
    }

    /** Base ortonormal local do osso a partir dos eixos X e Z do PMX (flag de eixo local): colunas X, Y = Z×X, Z. */
    fun localBasis(xAxis: FloatArray, zAxis: FloatArray): Array<FloatArray> {
        val x = normalize(xAxis)
        var z = normalize(zAxis)
        var y = cross(z, x)
        if (dot(y, y) < 1e-8f) return arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f))
        y = normalize(y)
        z = normalize(cross(x, y))
        return arrayOf(x, y, z)
    }

    /** Vetor de mundo → coordenadas da base local. */
    fun toLocal(basis: Array<FloatArray>, v: FloatArray) = floatArrayOf(dot(basis[0], v), dot(basis[1], v), dot(basis[2], v))

    /** Coordenadas locais → vetor de mundo. */
    fun toWorld(basis: Array<FloatArray>, l: FloatArray) = floatArrayOf(
        basis[0][0] * l[0] + basis[1][0] * l[1] + basis[2][0] * l[2],
        basis[0][1] * l[0] + basis[1][1] * l[1] + basis[2][1] * l[2],
        basis[0][2] * l[0] + basis[1][2] * l[1] + basis[2][2] * l[2]
    )

    enum class AxisMode { GLOBAL, LOCAL, VIEW }

    /** Converte um delta de mundo no delta a gravar na key, conforme o modo de eixo ([viewBasis] = direita, cima, frente da câmera). */
    fun deltaForMode(mode: AxisMode, worldDelta: FloatArray, localBasis: Array<FloatArray>?, viewBasis: Array<FloatArray>?): FloatArray = when (mode) {
        AxisMode.GLOBAL -> worldDelta.copyOf(3)
        AxisMode.LOCAL -> if (localBasis != null) toLocal(localBasis, worldDelta) else worldDelta.copyOf(3)
        AxisMode.VIEW -> if (viewBasis != null) toLocal(viewBasis, worldDelta) else worldDelta.copyOf(3)
    }

    /** Arrasto de tela (pixels) → rotação de trackball: dx gira em torno do "cima" da vista, dy em torno da "direita". */
    fun dragToRotation(dx: Float, dy: Float, viewRight: FloatArray, viewUp: FloatArray, radPerPixel: Float = 0.01f): FloatArray {
        if (!dx.isFinite() || !dy.isFinite()) return floatArrayOf(0f, 0f, 0f, 1f)
        val yaw = quatAxisAngle(viewUp, dx * radPerPixel)
        val pitch = quatAxisAngle(viewRight, dy * radPerPixel)
        return quatMul(yaw, pitch)
    }

    /** Ângulo com sinal (rad) de [p0] para [p1] em torno de [c] na tela (anel de rotação do MMD). */
    fun ringAngle(cx: Float, cy: Float, x0: Float, y0: Float, x1: Float, y1: Float): Float {
        val ax = x0 - cx; val ay = y0 - cy; val bx = x1 - cx; val by = y1 - cy
        if (ax * ax + ay * ay < 1e-6f || bx * bx + by * by < 1e-6f) return 0f
        return atan2(ax * by - ay * bx, ax * bx + ay * by)
    }

    fun snap(value: Float, step: Float): Float = if (step > 0f && value.isFinite()) (value / step).roundToInt() * step else value

    /** Distância entre ponto e o segmento a-b em 2D (para escolher o eixo clicado no gizmo). */
    fun distToSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l2 = dx * dx + dy * dy
        val t = if (l2 < 1e-9f) 0f else (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
        val qx = ax + dx * t; val qy = ay + dy * t
        return sqrt((px - qx) * (px - qx) + (py - qy) * (py - qy))
    }

    /** Qual dos 3 eixos (pontas projetadas em [ends], x,y por eixo) está mais perto do toque dentro de [tol] px; -1 se nenhum. */
    fun pickAxis(px: Float, py: Float, ox: Float, oy: Float, ends: FloatArray, tol: Float): Int {
        var best = -1; var bd = tol
        for (i in 0 until minOf(3, ends.size / 2)) {
            val d = distToSegment(px, py, ox, oy, ends[i * 2], ends[i * 2 + 1])
            if (d <= bd) { bd = d; best = i }
        }
        return best
    }

    fun near(a: Float, b: Float, eps: Float = 1e-4f) = abs(a - b) <= eps
}

/** Marcadores e faixa de trabalho da timeline (nomear frames, saltar entre marcas, exportar só um trecho). */
class TimelineMarker(val frame: Int, val label: String, val color: Int = 0xFFFFC107.toInt())

object TimelineMarkers {
    fun add(list: List<TimelineMarker>, frame: Int, label: String, color: Int = 0xFFFFC107.toInt()): List<TimelineMarker> {
        if (frame < 0) return list
        return (list.filter { it.frame != frame } + TimelineMarker(frame, label.trim().take(40), color)).sortedBy { it.frame }
    }

    fun remove(list: List<TimelineMarker>, frame: Int) = list.filter { it.frame != frame }

    fun next(list: List<TimelineMarker>, frame: Int): TimelineMarker? = list.filter { it.frame > frame }.minByOrNull { it.frame }
    fun prev(list: List<TimelineMarker>, frame: Int): TimelineMarker? = list.filter { it.frame < frame }.maxByOrNull { it.frame }

    /** Uma linha por marcador: frame<TAB>cor hex<TAB>rótulo (TAB/quebra de linha viram espaço). */
    fun encode(list: List<TimelineMarker>): String =
        list.sortedBy { it.frame }.joinToString("\n") { "${it.frame}\t${Integer.toHexString(it.color)}\t${it.label.replace('\t', ' ').replace('\n', ' ')}" }

    fun decode(text: String): List<TimelineMarker> {
        val out = ArrayList<TimelineMarker>()
        for (line in text.lines()) {
            val p = line.split('\t', limit = 3)
            if (p.size < 3) continue
            val f = p[0].trim().toIntOrNull() ?: continue
            if (f < 0) continue
            val c = p[1].trim().toLongOrNull(16)?.toInt() ?: 0xFFFFC107.toInt()
            out.add(TimelineMarker(f, p[2].take(40), c))
        }
        return out.distinctBy { it.frame }.sortedBy { it.frame }
    }
}

/** Faixa de trabalho [start, end] usada por exportação e loop de reprodução. */
class WorkRange(start: Int, end: Int, val total: Int) {
    val start: Int = start.coerceIn(0, maxOf(0, total))
    val end: Int = end.coerceIn(this.start, maxOf(this.start, total))
    val length get() = end - start + 1
    fun contains(f: Int) = f in start..end
    /** Próximo quadro na reprodução em loop dentro da faixa. */
    fun advance(f: Int, loop: Boolean): Int = if (f + 1 <= end) f + 1 else if (loop) start else end
}
