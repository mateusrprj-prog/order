package studio.mmd.mmd

/** Modos de desenho PMX 2.1: ponto (bit 6) tem precedência sobre linha (bit 7). */
enum class PmxPrimitiveMode { TRIANGLES, POINTS, LINES }

object PmxPrimitiveDraw {
    const val FLAG_VERTEX_COLOR = 0x20
    const val FLAG_POINT_DRAWING = 0x40
    const val FLAG_LINE_DRAWING = 0x80

    fun modeFromFlags(flags: Int): PmxPrimitiveMode = when {
        flags and FLAG_POINT_DRAWING != 0 -> PmxPrimitiveMode.POINTS
        flags and FLAG_LINE_DRAWING != 0 -> PmxPrimitiveMode.LINES
        else -> PmxPrimitiveMode.TRIANGLES
    }

    /** Expande [A,B,C] em segmentos AB, BC, CA preservando a ordem e os offsets por material. */
    fun expandTriangleEdges(indices: IntArray): IntArray {
        require(indices.size % 3 == 0) { "Índices de superfície devem formar triângulos" }
        val out = IntArray(indices.size * 2)
        var o = 0
        for (i in indices.indices step 3) {
            val a = indices[i]; val b = indices[i + 1]; val c = indices[i + 2]
            out[o++] = a; out[o++] = b
            out[o++] = b; out[o++] = c
            out[o++] = c; out[o++] = a
        }
        return out
    }
}
