package studio.mmd.mmd

/**
 * v2.37.0 — Mesclar movimentos (carregar um segundo VMD sobre o atual, como no MMD oficial), com deslocamento de tempo,
 * filtro de trilhas, recorte e mapeamento de nomes. Kotlin puro e imutável.
 */
object MotionMerge {
    enum class Conflict { OVERLAY_WINS, BASE_WINS, REPLACE_TRACK }

    class Options(
        val offsetFrames: Int = 0,
        val boneFilter: Set<String>? = null,
        val morphFilter: Set<String>? = null,
        val from: Int = 0,
        val to: Int = Int.MAX_VALUE,
        val conflict: Conflict = Conflict.OVERLAY_WINS,
        /** Se não nulo, ignora ossos ausentes do modelo e conta como ignorados. */
        val knownBones: Set<String>? = null,
        val knownMorphs: Set<String>? = null,
        val renames: Map<String, String> = emptyMap()
    )

    class Result(val motion: VmdMotion, val merged: Int, val skipped: Int)

    fun merge(base: VmdMotion, overlay: VmdMotion, o: Options = Options()): Result {
        var merged = 0; var skipped = 0
        val bones = LinkedHashMap<String, VmdTrack>(base.bones)
        for ((rawName, t) in overlay.bones) {
            val name = o.renames[rawName] ?: rawName
            if (o.boneFilter != null && rawName !in o.boneFilter && name !in o.boneFilter) continue
            if (o.knownBones != null && name !in o.knownBones) { skipped += t.frames.size; continue }
            val cut = cutBone(t, o)
            if (cut == null) continue
            val shifted = shiftBone(cut, o.offsetFrames) ?: continue
            merged += shifted.frames.size
            bones[name] = mergeBone(bones[name], shifted, o.conflict)
        }
        val morphs = LinkedHashMap<String, VmdMorphTrack>(base.morphs)
        for ((rawName, t) in overlay.morphs) {
            val name = o.renames[rawName] ?: rawName
            if (o.morphFilter != null && rawName !in o.morphFilter && name !in o.morphFilter) continue
            if (o.knownMorphs != null && name !in o.knownMorphs) { skipped += t.frames.size; continue }
            val idx = (0 until minOf(t.frames.size, t.w.size)).filter { t.frames[it] in o.from..o.to && t.frames[it] + o.offsetFrames >= 0 }
            if (idx.isEmpty()) continue
            val shifted = VmdMorphTrack(IntArray(idx.size) { t.frames[idx[it]] + o.offsetFrames }, FloatArray(idx.size) { t.w[idx[it]] })
            merged += idx.size
            morphs[name] = mergeMorph(morphs[name], shifted, o.conflict)
        }
        var mx = base.maxFrame
        for (t in bones.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames.last())
        for (t in morphs.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames.last())
        return Result(VmdMotion(base.modelName, bones, morphs, mx, base.warnings, base.extras), merged, skipped)
    }

    private fun cutBone(t: VmdTrack, o: Options): VmdTrack? {
        val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
        val idx = (0 until n).filter { t.frames[it] in o.from..o.to }
        if (idx.isEmpty()) return null
        val v = FloatArray(idx.size * 7); val ip = ByteArray(idx.size * 16)
        for ((j, i) in idx.withIndex()) { t.v.copyInto(v, j * 7, i * 7, i * 7 + 7); t.ip.copyInto(ip, j * 16, i * 16, i * 16 + 16) }
        return VmdTrack(IntArray(idx.size) { t.frames[idx[it]] }, v, ip)
    }

    private fun shiftBone(t: VmdTrack, d: Int): VmdTrack? {
        if (d == 0) return t
        val idx = t.frames.indices.filter { t.frames[it] + d >= 0 }
        if (idx.isEmpty()) return null
        val v = FloatArray(idx.size * 7); val ip = ByteArray(idx.size * 16)
        for ((j, i) in idx.withIndex()) { t.v.copyInto(v, j * 7, i * 7, i * 7 + 7); t.ip.copyInto(ip, j * 16, i * 16, i * 16 + 16) }
        return VmdTrack(IntArray(idx.size) { t.frames[idx[it]] + d }, v, ip)
    }

    private fun mergeBone(a: VmdTrack?, b: VmdTrack, c: Conflict): VmdTrack {
        if (a == null || c == Conflict.REPLACE_TRACK) return b
        val map = java.util.TreeMap<Int, Pair<FloatArray, ByteArray>>()
        for (i in a.frames.indices) map[a.frames[i]] = a.v.copyOfRange(i * 7, i * 7 + 7) to a.ip.copyOfRange(i * 16, i * 16 + 16)
        for (i in b.frames.indices) {
            if (c == Conflict.BASE_WINS && map.containsKey(b.frames[i])) continue
            map[b.frames[i]] = b.v.copyOfRange(i * 7, i * 7 + 7) to b.ip.copyOfRange(i * 16, i * 16 + 16)
        }
        val fr = map.keys.toIntArray(); val v = FloatArray(fr.size * 7); val ip = ByteArray(fr.size * 16)
        var k = 0
        for ((_, p) in map) { p.first.copyInto(v, k * 7); p.second.copyInto(ip, k * 16); k++ }
        return VmdTrack(fr, v, ip)
    }

    private fun mergeMorph(a: VmdMorphTrack?, b: VmdMorphTrack, c: Conflict): VmdMorphTrack {
        if (a == null || c == Conflict.REPLACE_TRACK) return b
        val map = java.util.TreeMap<Int, Float>()
        for (i in a.frames.indices) map[a.frames[i]] = a.w[i]
        for (i in b.frames.indices) { if (c == Conflict.BASE_WINS && map.containsKey(b.frames[i])) continue; map[b.frames[i]] = b.w[i] }
        val fr = map.keys.toIntArray()
        return VmdMorphTrack(fr, FloatArray(fr.size) { map.getValue(fr[it]) })
    }
}
