package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Pose editável de uma câmera VMD. A rotação usa radianos, como no arquivo MMD. */
data class CameraPose(
    val distance: Float = 30f,
    val x: Float = 0f, val y: Float = 10f, val z: Float = 0f,
    val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f,
    val fov: Float = 45f
) {
    fun sanitized() = copy(
        distance = distance.takeIf { it.isFinite() }?.coerceIn(0.1f, 10000f) ?: 30f,
        x = x.finiteOrZero().coerceIn(-100000f, 100000f),
        y = y.finiteOrZero().coerceIn(-100000f, 100000f),
        z = z.finiteOrZero().coerceIn(-100000f, 100000f),
        rx = rx.finiteOrZero().coerceIn(-100f, 100f),
        ry = ry.finiteOrZero().coerceIn(-100f, 100f),
        rz = rz.finiteOrZero().coerceIn(-100f, 100f),
        fov = fov.takeIf { it.isFinite() }?.coerceIn(1f, 179f) ?: 45f
    )
    private fun Float.finiteOrZero() = if (isFinite()) this else 0f
}

/** Operações não destrutivas sobre keyframes de câmera do VMD. Frames mantêm ordenação crescente. */
object CameraMotionTools {
    private data class Key(val frame: Int, val pose: CameraPose, val ip: ByteArray)
    private val sjis = Charset.forName("Shift_JIS")
    private fun linearIp() = ByteArray(24).also { a ->
        for (c in 0 until 6) { a[c * 4] = 20; a[c * 4 + 1] = 107; a[c * 4 + 2] = 20; a[c * 4 + 3] = 107 }
    }

    fun sample(camera: VmdCamera?, frame: Float): CameraPose {
        if (camera == null || camera.frames.isEmpty()) return CameraPose()
        val out = FloatArray(8)
        camera.evaluate(frame.coerceAtLeast(0f), out)
        return CameraPose(out[0], out[1], out[2], out[3], out[4], out[5], out[6], out[7]).sanitized()
    }

    fun hasKey(camera: VmdCamera?, frame: Int): Boolean = camera?.frames?.binarySearch(frame)?.let { it >= 0 } ?: false

    fun put(camera: VmdCamera?, frame: Int, pose: CameraPose): VmdCamera {
        require(frame >= 0) { "O quadro da câmera não pode ser negativo" }
        val old = keys(camera).toMutableList()
        val i = old.binarySearchBy(frame) { it.frame }
        val existingIp = if (i >= 0) old[i].ip.copyOf() else linearIp()
        val key = Key(frame, pose.sanitized(), existingIp)
        if (i >= 0) old[i] = key else old.add(-i - 1, key)
        return fromKeys(old)
    }

    fun remove(camera: VmdCamera?, frame: Int): VmdCamera? {
        val old = keys(camera).toMutableList()
        val i = old.binarySearchBy(frame) { it.frame }
        if (i < 0) return camera
        old.removeAt(i)
        return if (old.isEmpty()) null else fromKeys(old)
    }

    /** Ajusta a interpolação de todas as seis dimensões nos keyframes do intervalo. */
    fun setLinear(camera: VmdCamera?, from: Int, to: Int): VmdCamera? {
        if (camera == null) return null
        val lo = min(from, to); val hi = max(from, to)
        return fromKeys(keys(camera).map { if (it.frame in lo..hi) it.copy(ip = linearIp()) else it })
    }

    /** Inverte os valores no tempo sem mover os quadros; também reverte os handles Bézier. */
    fun reverse(camera: VmdCamera?, from: Int, to: Int): VmdCamera? {
        if (camera == null) return null
        val lo = min(from, to); val hi = max(from, to)
        val all = keys(camera).toMutableList()
        val indices = all.indices.filter { all[it].frame in lo..hi }
        if (indices.size < 2) return camera
        val source = indices.map { all[it] }.reversed()
        indices.forEachIndexed { n, idx ->
            val targetFrame = all[idx].frame
            all[idx] = source[n].copy(frame = targetFrame, ip = reverseIp(source[n].ip))
        }
        return fromKeys(all)
    }

    /** Suaviza valores de câmera sem alterar os quadros nem as curvas. As bordas ficam preservadas. */
    fun smooth(camera: VmdCamera?, from: Int, to: Int, strength: Float = 0.5f, passes: Int = 1): VmdCamera? {
        if (camera == null) return null
        val lo = min(from, to); val hi = max(from, to)
        var all = keys(camera).toMutableList()
        val amount = strength.coerceIn(0f, 1f)
        repeat(passes.coerceIn(1, 8)) {
            val next = all.toMutableList()
            for (i in 1 until all.lastIndex) {
                val k = all[i]
                if (k.frame !in lo..hi || all[i - 1].frame !in lo..hi || all[i + 1].frame !in lo..hi) continue
                val left = all[i - 1]; val right = all[i + 1]
                val a = left.pose; val b = right.pose; val p = k.pose
                val span = (right.frame - left.frame).coerceAtLeast(1)
                val t = ((k.frame - left.frame).toFloat() / span).coerceIn(0f, 1f)
                fun avg(x: Float, y: Float, current: Float) = current + ((x + (y - x) * t) - current) * amount
                fun angle(x: Float, y: Float, current: Float): Float {
                    var delta = (y - x) % (Math.PI.toFloat() * 2f)
                    if (delta > Math.PI.toFloat()) delta -= Math.PI.toFloat() * 2f
                    if (delta < -Math.PI.toFloat()) delta += Math.PI.toFloat() * 2f
                    val target = x + delta * t
                    var correction = (target - current) % (Math.PI.toFloat() * 2f)
                    if (correction > Math.PI.toFloat()) correction -= Math.PI.toFloat() * 2f
                    if (correction < -Math.PI.toFloat()) correction += Math.PI.toFloat() * 2f
                    return current + correction * amount
                }
                next[i] = k.copy(pose = CameraPose(
                    avg(a.distance, b.distance, p.distance), avg(a.x, b.x, p.x), avg(a.y, b.y, p.y), avg(a.z, b.z, p.z),
                    angle(a.rx, b.rx, p.rx), angle(a.ry, b.ry, p.ry), angle(a.rz, b.rz, p.rz), avg(a.fov, b.fov, p.fov)
                ).sanitized())
            }
            all = next
        }
        return fromKeys(all)
    }

    /** Produz um VMD v2 válido apenas com a seção de câmera, pronto para persistir/importar. */
    fun toVmd(camera: VmdCamera, modelName: String = "MMD Studio Camera"): ByteArray {
        require(camera.frames.size <= 1_000_000) { "Quantidade excessiva de keys de câmera" }
        val n = camera.frames.size
        require(camera.dist.size >= n && camera.pos.size >= n * 3 && camera.rot.size >= n * 3 && camera.fov.size >= n && camera.ip.size >= n * 24) {
            "Dados de câmera incompletos"
        }
        val out = ByteBuffer.allocate(30 + 20 + 4 + 4 + 4 + n * 61 + 12).order(ByteOrder.LITTLE_ENDIAN)
        fun fixed(value: String, length: Int) {
            val src = value.toByteArray(sjis); val dst = ByteArray(length)
            System.arraycopy(src, 0, dst, 0, min(src.size, length)); out.put(dst)
        }
        fixed("Vocaloid Motion Data 0002", 30); fixed(modelName, 20)
        out.putInt(0) // bones
        out.putInt(0) // morphs
        out.putInt(n) // cameras
        for (i in 0 until n) {
            require(camera.frames[i] >= 0 && (i == 0 || camera.frames[i] > camera.frames[i - 1])) { "Frames de câmera devem ser únicos e crescentes" }
            out.putInt(camera.frames[i]); out.putFloat(camera.dist[i].takeIf { it.isFinite() } ?: 30f)
            for (c in 0..2) out.putFloat(camera.pos[i * 3 + c].takeIf { it.isFinite() } ?: 0f)
            for (c in 0..2) out.putFloat(camera.rot[i * 3 + c].takeIf { it.isFinite() } ?: 0f)
            out.put(camera.ip, i * 24, 24)
            out.putInt(camera.fov[i].takeIf { it.isFinite() }?.toInt()?.coerceIn(1, 179) ?: 45)
            out.put(0.toByte()) // perspectiva ativada
        }
        out.putInt(0); out.putInt(0); out.putInt(0) // luz, sombra, IK
        return out.array()
    }

    private fun reverseIp(ip: ByteArray): ByteArray {
        val out = ip.copyOf()
        for (c in 0 until 6) {
            val o = c * 4
            val x1 = ip[o].toInt() and 0xff; val x2 = ip[o + 1].toInt() and 0xff
            val y1 = ip[o + 2].toInt() and 0xff; val y2 = ip[o + 3].toInt() and 0xff
            out[o] = (127 - x2).coerceIn(0, 127).toByte()
            out[o + 1] = (127 - x1).coerceIn(0, 127).toByte()
            out[o + 2] = (127 - y2).coerceIn(0, 127).toByte()
            out[o + 3] = (127 - y1).coerceIn(0, 127).toByte()
        }
        return out
    }

    private fun keys(camera: VmdCamera?): List<Key> {
        if (camera == null) return emptyList()
        return camera.frames.indices.map { i ->
            val p = CameraPose(camera.dist[i], camera.pos[i * 3], camera.pos[i * 3 + 1], camera.pos[i * 3 + 2],
                camera.rot[i * 3], camera.rot[i * 3 + 1], camera.rot[i * 3 + 2], camera.fov[i]).sanitized()
            Key(camera.frames[i], p, camera.ip.copyOfRange(i * 24, i * 24 + 24))
        }.sortedBy { it.frame }
    }

    private fun fromKeys(keys: List<Key>): VmdCamera {
        val s = keys.sortedBy { it.frame }.distinctBy { it.frame }
        val n = s.size; val dist = FloatArray(n); val pos = FloatArray(n * 3); val rot = FloatArray(n * 3)
        val fov = FloatArray(n); val ip = ByteArray(n * 24)
        s.forEachIndexed { i, k ->
            dist[i] = k.pose.distance; pos[i * 3] = k.pose.x; pos[i * 3 + 1] = k.pose.y; pos[i * 3 + 2] = k.pose.z
            rot[i * 3] = k.pose.rx; rot[i * 3 + 1] = k.pose.ry; rot[i * 3 + 2] = k.pose.rz
            fov[i] = k.pose.fov
            (if (k.ip.size == 24) k.ip else linearIp()).copyInto(ip, i * 24)
        }
        return VmdCamera(IntArray(n) { s[it].frame }, dist, pos, rot, fov, ip)
    }
}
