package studio.mmd.mmd

import kotlin.math.max
import kotlin.math.sqrt

/**
 * v1.14.0: leitor de Wavefront .obj (+ .mtl opcional) → [PmxModel] estático com um único osso "raiz"
 * (dá para mover, girar e animar o objeto inteiro). Suporta v/vt/vn, faces com 3+ vértices (triangulação em leque),
 * índices negativos, usemtl/mtllib, Kd, d/Tr e map_Kd. Ignora curvas, superfícies e grupos (avisa).
 * Conversão: Y para cima, mão direita → mão esquerda do MMD (Z invertido, triângulos invertidos); tamanho fora de 0,3–3,2 unidades
 * é reescalado para ~1,6 m; senão 1 unidade OBJ = 1 m = 12,5 unidades MMD (convenção 8 cm do GlbExporter).
 */
object ObjParser {
    private class Mtl(val name: String, var kd: FloatArray = floatArrayOf(0.8f, 0.8f, 0.8f, 1f), var tex: String = "")

    fun parse(data: ByteArray, mtl: (String) -> ByteArray? = { null }): PmxModel {
        val warnings = ArrayList<String>()
        val text = String(data, Charsets.UTF_8)
        val vp = ArrayList<Float>(); val vt = ArrayList<Float>(); val vn = ArrayList<Float>()
        val mats = LinkedHashMap<String, Mtl>()
        val matList = ArrayList<Mtl>()
        fun matOf(n: String): Mtl = mats.getOrPut(n) { Mtl(n) }
        // faces agrupadas por material (ordem de aparecimento)
        class Face(val v: IntArray, val t: IntArray, val n: IntArray)
        val faces = LinkedHashMap<String, ArrayList<Face>>()
        var cur = "" ; faces[cur] = ArrayList()
        var skipped = 0; var curves = false
        for (raw in text.lineSequence()) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val p = line.split(Regex("\\s+"))
            when (p[0]) {
                "v" -> if (p.size >= 4) { vp.add(p[1].toFloatOrNull() ?: 0f); vp.add(p[2].toFloatOrNull() ?: 0f); vp.add(p[3].toFloatOrNull() ?: 0f) }
                "vt" -> if (p.size >= 3) { vt.add(p[1].toFloatOrNull() ?: 0f); vt.add(p[2].toFloatOrNull() ?: 0f) }
                "vn" -> if (p.size >= 4) { vn.add(p[1].toFloatOrNull() ?: 0f); vn.add(p[2].toFloatOrNull() ?: 0f); vn.add(p[3].toFloatOrNull() ?: 0f) }
                "usemtl" -> { cur = line.substring(6).trim(); faces.getOrPut(cur) { ArrayList() } }
                "mtllib" -> {
                    val fname = line.substring(6).trim().replace('\\', '/').substringAfterLast('/')
                    val b = try { mtl(fname) } catch (e: Exception) { null }
                    if (b == null) warnings.add("arquivo de materiais $fname não encontrado; cores padrão")
                    else parseMtl(String(b, Charsets.UTF_8), mats)
                }
                "f" -> {
                    if (p.size < 4) { skipped++; continue }
                    val n = p.size - 1
                    val fv = IntArray(n); val ft = IntArray(n); val fn = IntArray(n)
                    var ok = true
                    for (k in 0 until n) {
                        val s = p[k + 1].split('/')
                        fv[k] = resolve(s.getOrNull(0), vp.size / 3); ft[k] = resolve(s.getOrNull(1), vt.size / 2); fn[k] = resolve(s.getOrNull(2), vn.size / 3)
                        if (fv[k] < 0) ok = false
                    }
                    if (ok) faces.getOrPut(cur) { ArrayList() }.add(Face(fv, ft, fn)) else skipped++
                }
                "l", "curv", "curv2", "surf", "p" -> curves = true
            }
        }
        if (skipped > 0) warnings.add("$skipped face(s) inválida(s) ignorada(s)")
        if (curves) warnings.add("linhas/curvas/superfícies do .obj ignoradas")
        if (vp.isEmpty()) throw PmxFormatException("Nenhum vértice (v) encontrado no .obj")

        val pos = ArrayList<Float>(); val nrm = ArrayList<Float>(); val uv = ArrayList<Float>(); val indices = ArrayList<Int>()
        val materials = ArrayList<PmxMaterial>(); val texNames = ArrayList<String>()
        val key = HashMap<Triple<Int, Int, Int>, Int>()
        var anyNormal = false
        for ((mname, fl) in faces) {
            if (fl.isEmpty()) continue
            val before = indices.size
            for (f in fl) {
                fun vtx(k: Int): Int = key.getOrPut(Triple(f.v[k], f.t[k], f.n[k])) {
                    val vi = f.v[k]
                    pos.add(vp[vi * 3]); pos.add(vp[vi * 3 + 1]); pos.add(-vp[vi * 3 + 2])
                    if (f.n[k] >= 0) { anyNormal = true; val ni = f.n[k]; nrm.add(vn[ni * 3]); nrm.add(vn[ni * 3 + 1]); nrm.add(-vn[ni * 3 + 2]) } else { nrm.add(0f); nrm.add(0f); nrm.add(0f) }
                    if (f.t[k] >= 0) { uv.add(vt[f.t[k] * 2]); uv.add(1f - vt[f.t[k] * 2 + 1]) } else { uv.add(0f); uv.add(0f) } // OBJ tem V para cima
                    pos.size / 3 - 1
                }
                val i0 = vtx(0)
                for (k in 1 until f.v.size - 1) { val a = vtx(k); val b = vtx(k + 1); indices.add(i0); indices.add(b); indices.add(a) } // ordem invertida (Z invertido)
            }
            val m = mats[mname]
            val dif = m?.kd ?: floatArrayOf(0.8f, 0.8f, 0.8f, 1f)
            var ti = -1
            if (m != null && m.tex.isNotEmpty()) { ti = texNames.indexOf(m.tex); if (ti < 0) { texNames.add(m.tex); ti = texNames.size - 1 } }
            val nm = mname.ifBlank { "mat${materials.size}" }
            materials.add(PmxMaterial(nm, nm, dif, FloatArray(3), 5f, floatArrayOf(dif[0], dif[1], dif[2]), 1, floatArrayOf(0f, 0f, 0f, 1f), 1f, ti, -1, 0, true, 0, indices.size - before))
        }
        if (indices.isEmpty()) throw PmxFormatException("Nenhuma face encontrada no .obj")
        val vc = pos.size / 3
        val nr = FloatArray(vc * 3) { nrm[it] }
        // normais ausentes (faces sem vn): calcula por face e acumula nos vértices
        if (!anyNormal || (0 until vc).any { nr[it * 3] == 0f && nr[it * 3 + 1] == 0f && nr[it * 3 + 2] == 0f }) {
            val acc = FloatArray(vc * 3)
            var t = 0
            while (t + 2 < indices.size) {
                val a = indices[t]; val b = indices[t + 1]; val c = indices[t + 2]; t += 3
                val ux = pos[b * 3] - pos[a * 3]; val uy = pos[b * 3 + 1] - pos[a * 3 + 1]; val uz = pos[b * 3 + 2] - pos[a * 3 + 2]
                val wx = pos[c * 3] - pos[a * 3]; val wy = pos[c * 3 + 1] - pos[a * 3 + 1]; val wz = pos[c * 3 + 2] - pos[a * 3 + 2]
                val nx = uy * wz - uz * wy; val ny = uz * wx - ux * wz; val nz = ux * wy - uy * wx
                for (v in intArrayOf(a, b, c)) { acc[v * 3] += nx; acc[v * 3 + 1] += ny; acc[v * 3 + 2] += nz }
            }
            for (v in 0 until vc) if (nr[v * 3] == 0f && nr[v * 3 + 1] == 0f && nr[v * 3 + 2] == 0f) {
                val l = sqrt(acc[v * 3] * acc[v * 3] + acc[v * 3 + 1] * acc[v * 3 + 1] + acc[v * 3 + 2] * acc[v * 3 + 2])
                if (l > 1e-12f) { nr[v * 3] = acc[v * 3] / l; nr[v * 3 + 1] = acc[v * 3 + 1] / l; nr[v * 3 + 2] = acc[v * 3 + 2] / l } else nr[v * 3 + 1] = 1f
            }
            if (!anyNormal) warnings.add("sem normais no .obj: calculadas pelas faces")
        } else {
            // normais do arquivo: normaliza
            for (v in 0 until vc) { val l = sqrt(nr[v * 3] * nr[v * 3] + nr[v * 3 + 1] * nr[v * 3 + 1] + nr[v * 3 + 2] * nr[v * 3 + 2]); if (l > 1e-8f) { nr[v * 3] /= l; nr[v * 3 + 1] /= l; nr[v * 3 + 2] /= l } }
        }
        // escala
        val mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE); val mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (v in 0 until vc) for (c in 0..2) { val t = pos[v * 3 + c]; if (t < mn[c]) mn[c] = t; if (t > mx[c]) mx[c] = t }
        val ext = max(mx[0] - mn[0], max(mx[1] - mn[1], mx[2] - mn[2]))
        var s = 12.5f
        if ((ext > 3.2f || ext < 0.3f) && ext > 1e-6f) { s = 20f / ext; warnings.add("tamanho fora do normal (%.3g unidades): reescalado para ~1,6 m".format(ext)) }
        val bone = PmxBone("raiz", "raiz", 0f, 0f, 0f, -1, 0, 0x0002 or 0x0004 or 0x0008 or 0x0010, -1, -1, 0f, null)
        return PmxModel("obj", 2f, FloatArray(vc * 3) { pos[it] * s }, nr, FloatArray(vc * 2) { uv[it] },
            IntArray(vc * 4) { if (it % 4 == 0) 0 else -1 }, FloatArray(vc * 4) { if (it % 4 == 0) 1f else 0f },
            indices.toIntArray(), texNames, materials, listOf(bone), emptyList(), warnings = warnings)
    }

    private fun resolve(s: String?, n: Int): Int {
        if (s.isNullOrEmpty()) return -1
        val v = s.toIntOrNull() ?: return -1
        val i = if (v < 0) n + v else v - 1
        return if (i in 0 until n) i else -1
    }

    private fun parseMtl(t: String, out: LinkedHashMap<String, Mtl>) {
        var cur: Mtl? = null
        for (raw in t.lineSequence()) {
            val line = raw.substringBefore('#').trim(); if (line.isEmpty()) continue
            val p = line.split(Regex("\\s+"))
            when (p[0].lowercase()) {
                "newmtl" -> { val n = line.substring(6).trim(); cur = out.getOrPut(n) { Mtl(n) } }
                "kd" -> if (p.size >= 4) cur?.let { val a = it.kd[3]; it.kd = floatArrayOf(p[1].toFloatOrNull() ?: 0.8f, p[2].toFloatOrNull() ?: 0.8f, p[3].toFloatOrNull() ?: 0.8f, a) }
                "d" -> if (p.size >= 2) cur?.let { it.kd = floatArrayOf(it.kd[0], it.kd[1], it.kd[2], (p[1].toFloatOrNull() ?: 1f).coerceIn(0f, 1f)) }
                "tr" -> if (p.size >= 2) cur?.let { it.kd = floatArrayOf(it.kd[0], it.kd[1], it.kd[2], 1f - (p[1].toFloatOrNull() ?: 0f).coerceIn(0f, 1f)) }
                "map_kd" -> cur?.let { it.tex = line.substringAfter(' ').trim().split(Regex("\\s+")).last().replace('\\', '/').substringAfterLast('/') }
            }
        }
    }
}
