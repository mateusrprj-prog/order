package studio.mmd.mmd

import kotlin.math.sqrt

/**
 * v2.36.0 — Ferramentas de pose: amostrar toda a pose, mistura A↔B, manter pose, vai-e-volta (ping-pong) e diferenças.
 * Kotlin puro e imutável.
 */
object PoseTools {

    /** Pose completa (7 floats por osso) de todos os ossos animados no quadro [frame]. */
    fun sampleAll(m: VmdMotion, frame: Float): Map<String, FloatArray> {
        val out = LinkedHashMap<String, FloatArray>()
        for ((n, t) in m.bones) if (t.frames.isNotEmpty()) out[n] = MotionBake.sample(t, frame)
        return out
    }

    fun sampleMorphs(m: VmdMotion, frame: Float): Map<String, Float> {
        val out = LinkedHashMap<String, Float>()
        for ((n, t) in m.morphs) if (t.frames.isNotEmpty()) out[n] = MotionBake.sampleMorph(t, frame)
        return out
    }

    private fun slerpQ(a: FloatArray, b: FloatArray, t: Float): FloatArray {
        var dot = a[3] * b[3] + a[4] * b[4] + a[5] * b[5] + a[6] * b[6]
        val sg = if (dot < 0f) -1f else 1f
        dot = kotlin.math.abs(dot).coerceIn(0f, 1f)
        val o = FloatArray(4)
        if (dot > 0.9995f) for (c in 0..3) o[c] = a[3 + c] + (sg * b[3 + c] - a[3 + c]) * t
        else {
            val th = Math.acos(dot.toDouble()); val s = Math.sin(th)
            val wa = (Math.sin((1 - t) * th) / s).toFloat(); val wb = (Math.sin(t * th) / s).toFloat()
            for (c in 0..3) o[c] = wa * a[3 + c] + wb * sg * b[3 + c]
        }
        val l = sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2] + o[3] * o[3])
        if (l > 1e-8f) for (c in 0..3) o[c] /= l else { o[0] = 0f; o[1] = 0f; o[2] = 0f; o[3] = 1f }
        return o
    }

    /** Mistura duas poses: posição linear, rotação slerp. Ossos só em uma das poses vêm dela quando [w] ~ lado dela. */
    fun blend(a: Map<String, FloatArray>, b: Map<String, FloatArray>, w: Float): Map<String, FloatArray> {
        val t = if (w.isFinite()) w.coerceIn(0f, 1f) else 0f
        val out = LinkedHashMap<String, FloatArray>()
        for (n in (a.keys + b.keys)) {
            val pa = a[n]; val pb = b[n]
            out[n] = when {
                pa != null && pb != null -> {
                    val q = slerpQ(pa, pb, t)
                    floatArrayOf(pa[0] + (pb[0] - pa[0]) * t, pa[1] + (pb[1] - pa[1]) * t, pa[2] + (pb[2] - pa[2]) * t, q[0], q[1], q[2], q[3])
                }
                pa != null -> pa.copyOf()
                else -> pb!!.copyOf()
            }
        }
        return out
    }

    /** Escreve [pose] como keys (curva linear) no quadro [frame]; mantém as demais keys. */
    fun applyPose(m: VmdMotion, frame: Int, pose: Map<String, FloatArray>): VmdMotion {
        if (frame < 0 || pose.isEmpty()) return m
        val bones = LinkedHashMap<String, VmdTrack>(m.bones)
        for ((n, v) in pose) {
            if (v.size < 7) continue
            val t = bones[n]
            val clip = MotionClip(1, mapOf(n to listOf(ClipBoneKey(0, v.copyOf(7), byteArrayOf(20, 20, 20, 20, 20, 20, 20, 20, 107, 107, 107, 107, 107, 107, 107, 107)))), emptyMap())
            val base = VmdMotion(m.modelName, if (t != null) mapOf(n to t) else emptyMap(), emptyMap(), m.maxFrame)
            val r = MotionClipboard.paste(base, clip, frame, PasteMode.MERGE).motion
            bones[n] = r.bones.getValue(n)
        }
        var mx = m.maxFrame
        for (t in bones.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames[t.frames.size - 1])
        return VmdMotion(m.modelName, bones, m.morphs, mx, m.warnings, m.extras)
    }

    /** "Manter pose": a pose do quadro [from] é gravada também em [to] (todas as trilhas animadas, ossos e morphs). */
    fun hold(m: VmdMotion, from: Int, to: Int): VmdMotion {
        if (from < 0 || to < 0 || from == to) return m
        val withBones = applyPose(m, to, sampleAll(m, from.toFloat()))
        val morphs = LinkedHashMap<String, VmdMorphTrack>(withBones.morphs)
        for ((n, w) in sampleMorphs(m, from.toFloat())) {
            val t = morphs.getValue(n)
            val map = java.util.TreeMap<Int, Float>()
            for (i in 0 until minOf(t.frames.size, t.w.size)) map[t.frames[i]] = t.w[i]
            map[to] = w
            val fr = map.keys.toIntArray()
            morphs[n] = VmdMorphTrack(fr, FloatArray(fr.size) { map.getValue(fr[it]) })
        }
        var mx = withBones.maxFrame
        for (t in morphs.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames[t.frames.size - 1])
        return VmdMotion(withBones.modelName, withBones.bones, morphs, mx, withBones.warnings, withBones.extras)
    }

    /** Vai-e-volta: acrescenta, logo após [to], o trecho [from, to] invertido no tempo (loop sem salto). Keys posteriores deslizam. */
    fun pingPong(m: VmdMotion, from: Int, to: Int): VmdMotion {
        if (from < 0 || to <= from) return m
        val clip = MotionClipboard.copy(m, from, to)
        if (clip.isEmpty) return m
        val len = to - from
        val empty = VmdMotion(m.modelName, emptyMap(), emptyMap(), 0)
        val placed = MotionClipboard.paste(empty, clip, to).motion
        val rev = MotionFrameOps.reverseRange(placed, to, to + len)
        val revClip = MotionClipboard.copy(rev, to, to + len)
        val hi = maxOf(m.maxFrame, to + 1)
        val tail = MotionClipboard.copy(m, to + 1, hi)
        val head = MotionClipboard.clearRange(m, to + 1, hi)
        val mid = MotionClipboard.paste(head, revClip, to, PasteMode.MERGE).motion
        return if (tail.isEmpty) mid else MotionClipboard.paste(mid, tail, to + len + 1, PasteMode.MERGE).motion
    }

    /** Ossos que mais diferem entre duas poses (distância de posição + ângulo em graus), do maior para o menor. */
    fun biggestDifferences(a: Map<String, FloatArray>, b: Map<String, FloatArray>, limit: Int = 10): List<Pair<String, Float>> {
        val r = ArrayList<Pair<String, Float>>()
        for ((n, pa) in a) {
            val pb = b[n] ?: continue
            var d2 = 0f
            for (c in 0..2) { val e = pa[c] - pb[c]; d2 += e * e }
            val ang = MotionBake.angleBetween(pa.copyOfRange(3, 7), pb.copyOfRange(3, 7))
            r.add(n to (sqrt(d2) + ang / 10f))
        }
        return r.sortedByDescending { it.second }.take(limit.coerceAtLeast(1))
    }
}
