package studio.mmd.mmd

import java.io.ByteArrayOutputStream

/**
 * Escritor de PMX 2.0 / 2.1 (v1.10.0, Release 2). Faz o caminho inverso de PmxParser:
 * parse(write(parse(x))) deve ser igual a parse(x) em todos os campos que o modelo guarda.
 * Texto sai na mesma codificação e os índices no mesmo tamanho do arquivo original (necessário porque os
 * morphs de UV/material/impulso e os soft bodies são bytes brutos que embutem índices).
 * Tudo que não pôde ser gravado como no original vira aviso em Output.warnings.
 */
object PmxWriter {
    class Output(val bytes: ByteArray, val warnings: List<String>)

    private class Out {
        val o = ByteArrayOutputStream(1 shl 16)
        fun u8(v: Int) { o.write(v and 0xFF) }
        fun u16(v: Int) { o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }
        fun i32(v: Int) { o.write(v and 0xFF); o.write((v shr 8) and 0xFF); o.write((v shr 16) and 0xFF); o.write((v ushr 24) and 0xFF) }
        fun f(v: Float) { i32(java.lang.Float.floatToRawIntBits(v)) }
        fun f3(a: FloatArray?, off: Int) { for (k in 0..2) f(if (a != null && a.size >= off + 3) a[off + k] else 0f) }
        fun raw(b: ByteArray) { o.write(b, 0, b.size) }
        /** Índice de 1, 2 ou 4 bytes (mesmos bytes para com e sem sinal). */
        fun idx(size: Int, v: Int) { if (size == 1) u8(v) else if (size == 2) u16(v) else i32(v) }
        fun text(s: String, enc: Int) {
            val b = s.toByteArray(if (enc == 0) Charsets.UTF_16LE else Charsets.UTF_8)
            i32(b.size); raw(b)
        }
    }

    private fun unsignedSize(count: Int): Int = if (count <= 256) 1 else if (count <= 65536) 2 else 4
    private fun signedSize(count: Int): Int = if (count <= 128) 1 else if (count <= 32768) 2 else 4

    /**
     * Nomes de arquivo (com '/') para as texturas ao exportar um zip: remove "..", "." e partes vazias (zip-slip),
     * troca .tga por .png quando os bytes já são PNG (o importador converte TGA) e garante nomes únicos.
     * Nome vazio continua vazio (textura sem arquivo).
     */
    fun textureFileNames(names: List<String>, data: List<ByteArray?>): List<String> {
        val used = HashSet<String>()
        val out = ArrayList<String>()
        for (i in names.indices) {
            val parts = names[i].replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." && it != ".." }
            var p = parts.joinToString("/")
            if (p.isEmpty()) { out.add(""); continue }
            val d = data.getOrNull(i)
            if (d != null && d.size > 4 && p.lowercase().endsWith(".tga") && (d[0].toInt() and 0xFF) == 0x89 && d[1] == 'P'.code.toByte()) {
                p = p.substring(0, p.length - 4) + ".png"
            }
            var q = p; var k = 1
            val ext = p.substringAfterLast('.', "")
            val stem = if (ext.isEmpty()) p else p.substring(0, p.length - ext.length - 1)
            while (!used.add(q.lowercase())) { q = stem + "_" + k + (if (ext.isEmpty()) "" else "." + ext); k++ }
            out.add(q)
        }
        return out
    }

    /** textureNames: nomes a gravar na lista de texturas (ex.: .tga convertido para .png); null = os nomes do modelo. */
    fun write(model: PmxModel, textureNames: List<String>? = null): Output {
        val warn = ArrayList<String>()
        val vc = model.vertexCount
        require(model.normals.size == vc * 3) { "Normais não batem com o número de vértices" }
        require(model.uvs.size == vc * 2) { "UVs não batem com o número de vértices" }
        require(model.indices.size % 3 == 0) { "Número de índices de face não é múltiplo de 3" }
        for (ix in model.indices) require(ix >= 0 && ix < vc) { "Índice de face fora do intervalo ($ix, total $vc)" }
        val texNames: List<String> = textureNames ?: model.textures
        require(texNames.size == model.textures.size) { "Lista de nomes de textura com tamanho diferente da do modelo" }

        var bones: List<PmxBone> = model.bones
        val noBones = bones.isEmpty()
        if (noBones) {
            bones = listOf(PmxBone("センター", "Center", 0f, 0f, 0f, -1, 0, 0x001F, -1, -1, 0f, null))
            warn.add("O modelo não tinha ossos: foi criado um osso raiz \"センター\" e todos os vértices foram ligados a ele.")
        }
        val nb = bones.size

        // Tamanhos de índice: os do arquivo original, ou maiores se o modelo cresceu.
        val st = model.indexSizes
        val have = st.size == 6 && st.all { it == 1 || it == 2 || it == 4 }
        val vS = if (have) maxOf(st[0], unsignedSize(vc)) else unsignedSize(vc)
        val tS = if (have) maxOf(st[1], signedSize(model.textures.size)) else signedSize(model.textures.size)
        val mS = if (have) maxOf(st[2], signedSize(model.materials.size)) else signedSize(model.materials.size)
        val bS = if (have) maxOf(st[3], signedSize(nb)) else signedSize(nb)
        val moS = if (have) maxOf(st[4], signedSize(model.morphs.size)) else signedSize(model.morphs.size)
        val rS = if (have) maxOf(st[5], signedSize(model.rigidBodies.size)) else signedSize(model.rigidBodies.size)
        val sbRaw = model.softBodyRaw
        val hasRaw = model.morphs.any { it.raw != null } || (sbRaw != null && model.softBodies.isEmpty())
        if (hasRaw) {
            if (!have || vS != st[0] || mS != st[2] || rS != st[5] || bS != st[3] || tS != st[1]) {
                throw IllegalStateException("O modelo tem morphs de UV/material/impulso ou soft bodies (bytes brutos) e cresceu além do tamanho de índice original; exportação recusada para não corromper o arquivo.")
            }
        }

        val enc = if (model.textEncoding == 1) 1 else 0
        val ver = if ((model.version >= 2.05f && model.version <= 2.11f) || model.softBodies.isNotEmpty()) 2.1f else 2.0f
        if (model.version < 1.99f || model.version > 2.11f) warn.add("Versão ${model.version} do modelo gravada como PMX $ver.")
        val addUv = model.addUvCount.coerceIn(0, 4)
        val uvxOk = model.addUvs.size == vc * 4 * addUv
        if (addUv > 0 && !uvxOk) warn.add("UVs adicionais inconsistentes com os vértices; gravados como zero.")

        val w = Out()
        w.raw("PMX ".toByteArray(Charsets.US_ASCII)); w.f(ver)
        w.u8(8); w.u8(enc); w.u8(addUv); w.u8(vS); w.u8(tS); w.u8(mS); w.u8(bS); w.u8(moS); w.u8(rS)
        w.text(model.name, enc); w.text(model.nameEn, enc); w.text(model.comment, enc); w.text(model.commentEn, enc)

        // Vértices
        w.i32(vc)
        val wtOk = model.weightTypes.size == vc
        val biOk = model.boneIndices.size >= vc * 4 && model.boneWeights.size >= vc * 4
        val sd = model.sdef
        val ids = IntArray(4); val ws = FloatArray(4)
        for (i in 0 until vc) {
            w.f3(model.positions, i * 3); w.f3(model.normals, i * 3); w.f(model.uvs[i * 2]); w.f(model.uvs[i * 2 + 1])
            for (k in 0 until 4 * addUv) w.f(if (uvxOk) model.addUvs[i * 4 * addUv + k] else 0f)
            if (biOk) { for (k in 0..3) { ids[k] = model.boneIndices[i * 4 + k]; ws[k] = model.boneWeights[i * 4 + k] } }
            else { ids[0] = 0; ids[1] = -1; ids[2] = -1; ids[3] = -1; ws[0] = 1f; ws[1] = 0f; ws[2] = 0f; ws[3] = 0f }
            var t: Int
            if (wtOk) {
                t = model.weightTypes[i].toInt()
                if (t < 0 || t > 4) t = 2
                if (t == 3 && sd == null) t = 1
            } else {
                var n = 0; var first = -1; var second = -1
                for (k in 0..3) if (ids[k] >= 0) { n++; if (first < 0) first = k else if (second < 0) second = k }
                if (n <= 1) {
                    t = 0
                    if (first > 0) { ids[0] = ids[first]; ws[0] = 1f }
                } else if (n == 2) {
                    t = 1
                    val a = ids[first]; val b = ids[second]; val wa = ws[first]; val wb = ws[second]
                    val sum = wa + wb
                    ids[0] = a; ids[1] = b; ws[0] = if (sum > 1e-6f) wa / sum else 0.5f
                } else t = 2
            }
            w.u8(t)
            if (t == 0) w.idx(bS, ids[0])
            else if (t == 1 || t == 3) {
                w.idx(bS, ids[0]); w.idx(bS, ids[1]); w.f(ws[0])
                if (t == 3) for (k in 0 until 9) w.f(if (sd != null) sd[i * 9 + k] else 0f)
            } else {
                for (k in 0..3) w.idx(bS, ids[k])
                for (k in 0..3) w.f(ws[k])
            }
            w.f(if (model.edgeScale.size == vc) model.edgeScale[i] else 1f)
        }

        // Faces
        w.i32(model.indices.size)
        for (ix in model.indices) w.idx(vS, ix)

        // Texturas
        w.i32(texNames.size)
        for (t in texNames) w.text(t, enc)

        // Materiais
        w.i32(model.materials.size)
        var idxSum = 0L
        for (m in model.materials) {
            w.text(m.name, enc); w.text(m.nameEn, enc)
            w.f3(m.diffuse, 0); w.f(if (m.diffuse.size > 3) m.diffuse[3] else 1f)
            w.f3(m.specular, 0); w.f(m.specularPower); w.f3(m.ambient, 0)
            w.u8(m.flags)
            w.f3(m.edgeColor, 0); w.f(if (m.edgeColor.size > 3) m.edgeColor[3] else 1f); w.f(m.edgeSize)
            w.idx(tS, m.textureIndex); w.idx(tS, m.sphereIndex); w.u8(m.sphereMode)
            w.u8(if (m.toonShared) 1 else 0)
            if (m.toonShared) w.u8(m.toonIndex) else w.idx(tS, m.toonIndex)
            w.text(m.memo, enc); w.i32(m.indexCount)
            idxSum += m.indexCount
        }
        if (idxSum != model.indices.size.toLong()) warn.add("Soma dos índices dos materiais ($idxSum) difere do total de faces (${model.indices.size}); gravado como está.")

        // Ossos
        w.i32(nb)
        for (b in bones) {
            w.text(b.name, enc); w.text(b.nameEn, enc)
            w.f(b.x); w.f(b.y); w.f(b.z)
            w.idx(bS, b.parent); w.i32(b.layer)
            var flags = b.flags
            if (b.ik != null) flags = flags or 0x0020
            w.u16(flags)
            if ((flags and 0x0001) != 0) w.idx(bS, b.tailBone) else w.f3(b.tailOffset, 0)
            if ((flags and 0x0300) != 0) { w.idx(bS, b.inheritParent); w.f(b.inheritWeight) }
            else if (b.inheritParent >= 0) warn.add("Osso \"${b.name}\": herança sem flag de herança; não gravada.")
            if ((flags and 0x0400) != 0) w.f3(b.fixedAxis, 0)
            if ((flags and 0x0800) != 0) { w.f3(b.localAxisX, 0); w.f3(b.localAxisZ, 0) }
            if ((flags and 0x2000) != 0) w.i32(b.externalKey)
            if ((flags and 0x0020) != 0) {
                val ik = b.ik
                if (ik == null) { w.idx(bS, -1); w.i32(0); w.f(0f); w.i32(0) }
                else {
                    w.idx(bS, ik.target); w.i32(ik.loopCount); w.f(ik.limitAngle); w.i32(ik.links.size)
                    for (l in ik.links) {
                        w.idx(bS, l.bone)
                        if (l.hasLimit) { w.u8(1); w.f3(l.min, 0); w.f3(l.max, 0) } else w.u8(0)
                    }
                }
            }
        }

        // Morphs
        w.i32(model.morphs.size)
        for (m in model.morphs) {
            w.text(m.name, enc); w.text(m.nameEn, enc); w.u8(m.panel); w.u8(m.type)
            val gi = m.groupIdx; val gr = m.groupRate
            val vi = m.vertexIdx; val vd = m.vertexDelta
            val bi = m.boneIdx; val bt = m.boneTrans; val br = m.boneRot
            val rawB = m.raw
            if ((m.type == 0 || m.type == 9) && gi != null && gr != null) {
                w.i32(gi.size)
                for (k in gi.indices) { w.idx(moS, gi[k]); w.f(gr[k]) }
            } else if (m.type == 1 && vi != null && vd != null) {
                w.i32(vi.size)
                for (k in vi.indices) { w.idx(vS, vi[k]); w.f3(vd, k * 3) }
            } else if (m.type == 2 && bi != null && bt != null && br != null) {
                w.i32(bi.size)
                for (k in bi.indices) { w.idx(bS, bi[k]); w.f3(bt, k * 3); for (c in 0..3) w.f(br[k * 4 + c]) }
            } else if (rawB != null) {
                w.i32(m.count); w.raw(rawB)
            } else {
                w.i32(0)
                warn.add("Morph \"${m.name}\" (tipo ${m.type}) sem dados; gravado vazio.")
            }
        }

        // Frames de exibição
        val frames: List<PmxDisplayFrame> = if (model.displayFrames.isNotEmpty()) model.displayFrames else {
            warn.add("O modelo não tinha frames de exibição; foram gerados Root, Expressões e Ossos.")
            val fr = ArrayList<PmxDisplayFrame>()
            fr.add(PmxDisplayFrame("Root", "Root", true, listOf(intArrayOf(0, 0))))
            fr.add(PmxDisplayFrame("表情", "Exp", true, List(model.morphs.size) { intArrayOf(1, it) }))
            if (nb > 1) fr.add(PmxDisplayFrame("ボーン", "Bones", false, List(nb - 1) { intArrayOf(0, it + 1) }))
            fr
        }
        w.i32(frames.size)
        for (f in frames) {
            w.text(f.name, enc); w.text(f.nameEn, enc); w.u8(if (f.special) 1 else 0)
            w.i32(f.elements.size)
            for (e in f.elements) { w.u8(e[0]); if (e[0] == 0) w.idx(bS, e[1]) else w.idx(moS, e[1]) }
        }

        // Corpos rígidos
        w.i32(model.rigidBodies.size)
        for (r in model.rigidBodies) {
            w.text(r.name, enc); w.text(r.nameEn, enc); w.idx(bS, r.bone); w.u8(r.group); w.u16(r.mask); w.u8(r.shape)
            w.f3(r.size, 0); w.f3(r.pos, 0); w.f3(r.rot, 0)
            w.f(r.mass); w.f(r.linearDamping); w.f(r.angularDamping); w.f(r.restitution); w.f(r.friction)
            w.u8(r.mode)
        }

        // Juntas
        w.i32(model.joints.size)
        for (j in model.joints) {
            w.text(j.name, enc); w.text(j.nameEn, enc); w.u8(j.type)
            w.idx(rS, j.a); w.idx(rS, j.b)
            w.f3(j.pos, 0); w.f3(j.rot, 0); w.f3(j.posMin, 0); w.f3(j.posMax, 0)
            w.f3(j.rotMin, 0); w.f3(j.rotMax, 0); w.f3(j.springPos, 0); w.f3(j.springRot, 0)
        }

        // Soft bodies PMX 2.1: registro estruturado quando disponível; compatibilidade raw para modelos legados.
        if (ver >= 2.05f) {
            if (model.softBodies.isNotEmpty()) {
                w.i32(model.softBodies.size)
                for (sb in model.softBodies) {
                    w.text(sb.name, enc); w.text(sb.nameEn, enc); w.u8(sb.shape); w.idx(mS, sb.material)
                    w.u8(sb.group); w.u16(sb.collisionMask); w.u8(sb.flags); w.i32(sb.linkDistance); w.i32(sb.clusterCount)
                    w.f(sb.totalMass); w.f(sb.collisionMargin); w.i32(sb.aeroModel)
                    for (i in 0 until 12) w.f(sb.config.getOrElse(i) { 0f })
                    for (i in 0 until 6) w.f(sb.cluster.getOrElse(i) { 0f })
                    for (i in 0 until 4) w.i32(sb.iterations.getOrElse(i) { 0 })
                    for (i in 0 until 3) w.i32(sb.materialStiffness.getOrElse(i) { 0 })
                    w.i32(sb.anchors.size); for (a in sb.anchors) { w.idx(rS, a.rigidBody); w.idx(vS, a.vertex); w.u8(if (a.nearMode) 1 else 0) }
                    w.i32(sb.pins.size); for (v in sb.pins) w.idx(vS, v)
                }
            } else if (model.softBodyCount > 0 && sbRaw != null) { w.i32(model.softBodyCount); w.raw(sbRaw) }
            else {
                w.i32(0)
                if (model.softBodyCount > 0) warn.add("${model.softBodyCount} soft bodies sem dados brutos; não gravados.")
            }
        }
        return Output(w.o.toByteArray(), warn)
    }
}
