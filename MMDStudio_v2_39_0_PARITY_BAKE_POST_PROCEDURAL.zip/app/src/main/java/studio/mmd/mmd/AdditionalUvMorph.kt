package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Morph de UV adicional PMX (tipos 4..7). Preserva os quatro componentes do vec4. */
class AdditionalUvMorph(val channel: Int, val vertexIndices: IntArray, val delta: FloatArray) {
    init { require(channel in 0..3); require(delta.size == vertexIndices.size * 4) }

    /** addUvs usa layout PMX intercalado por vértice: vertex * (channelCount*4) + channel*4. */
    fun apply(addUvs: FloatArray, channelCount: Int, weight: Float): Boolean {
        if (!weight.isFinite() || channel !in 0 until channelCount) return false
        val stride = channelCount * 4
        var changed = false
        for (i in vertexIndices.indices) {
            val vertex = vertexIndices[i]
            val offset = vertex * stride + channel * 4
            if (vertex < 0 || offset < 0 || offset + 3 >= addUvs.size) continue
            val d = i * 4
            for (c in 0..3) {
                val value = addUvs[offset + c] + delta[d + c] * weight
                if (value.isFinite()) addUvs[offset + c] = value
            }
            changed = true
        }
        return changed
    }

    companion object {
        /** Cada elemento contém índice de vértice + vec4 (16 bytes). */
        fun decode(morph: PmxMorph): AdditionalUvMorph? {
            if (morph.type !in 4..7) return null
            val raw = morph.raw ?: return null
            if (morph.count <= 0 || raw.size % morph.count != 0) return null
            val elementSize = raw.size / morph.count
            val indexSize = elementSize - 16
            if (indexSize !in intArrayOf(1, 2, 4)) return null
            val buffer = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            val indices = IntArray(morph.count)
            val delta = FloatArray(morph.count * 4)
            for (i in 0 until morph.count) {
                val offset = i * elementSize
                indices[i] = when (indexSize) {
                    1 -> buffer.get(offset).toInt() and 0xff
                    2 -> buffer.getShort(offset).toInt() and 0xffff
                    else -> buffer.getInt(offset)
                }
                for (c in 0..3) delta[i * 4 + c] = buffer.getFloat(offset + indexSize + c * 4)
            }
            return AdditionalUvMorph(morph.type - 4, indices, delta)
        }
    }
}
