package studio.mmd.mmd

import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * v1.14.0: leitor de glTF 2.0 (.glb binário e .gltf JSON) que converte para o [PmxModel] interno,
 * assim esqueleto, edição de keyframes, restrições, física, exportações e vídeo funcionam sem mudanças.
 *
 * O que entra: malhas (POSITION, NORMAL, TEXCOORD_0, JOINTS_0, WEIGHTS_0, índices), materiais (cor base, textura base, dupla face,
 * alpha), esqueleto (nós das skins, hierarquia e posição de repouso) e texturas (embutidas no GLB, data URI ou arquivo externo).
 * Modelo sem skin ganha um único osso "raiz" (mover/girar/escalar o objeto inteiro).
 * O que NÃO entra (vira aviso, nunca some em silêncio): animações do arquivo, morph targets, sparse accessors, câmeras/luzes, KHR_* de material.
 * Conversão: glTF é Y para cima, mão direita, metros; o MMD é mão esquerda (Z invertido). 1 unidade MMD = 8 cm (mesma convenção do GlbExporter).
 */
object GlbParser {
    class Parsed(val model: PmxModel, /** Bytes das imagens embutidas (GLB/data URI); null = procurar pelo nome (zip). */ val embedded: List<ByteArray?>, /** Animações do arquivo (9.2): lidas e validadas, ainda não aplicadas. */ val clips: List<GltfClip> = emptyList(), /** Repouso dos nós, para converter os clips (9.3). */ val rig: GltfRig? = null)

    private const val MMD_UNIT = 0.08f

    private class Acc(val view: Int, val off: Int, val comp: Int, val count: Int, val type: String, val norm: Boolean)

    fun parse(data: ByteArray, resolve: (String) -> ByteArray? = { null }): Parsed {
        val warnings = ArrayList<String>()
        var json: JSONObject
        var bin: ByteArray? = null
        if (data.size >= 12 && data[0] == 'g'.code.toByte() && data[1] == 'l'.code.toByte() && data[2] == 'T'.code.toByte() && data[3] == 'F'.code.toByte()) {
            val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            val ver = bb.getInt(4)
            if (ver != 2) throw PmxFormatException("GLB versão $ver não suportada (só glTF 2.0)")
            var p = 12; var js: String? = null
            while (p + 8 <= data.size) {
                val len = bb.getInt(p); val type = bb.getInt(p + 4); p += 8
                if (len < 0 || p + len > data.size) { warnings.add("GLB truncado: bloco incompleto ignorado"); break }
                if (type == 0x4E4F534A && js == null) js = String(data, p, len, Charsets.UTF_8)
                else if (type == 0x004E4942 && bin == null) bin = data.copyOfRange(p, p + len)
                p += (len + 3) and 3.inv()
            }
            json = try { JSONObject(js ?: throw PmxFormatException("GLB sem bloco JSON")) } catch (e: PmxFormatException) { throw e } catch (e: Exception) { throw PmxFormatException("JSON do GLB inválido") }
        } else {
            json = try { JSONObject(String(data, Charsets.UTF_8)) } catch (e: Exception) { throw PmxFormatException("Arquivo glTF inválido (não é JSON nem GLB)") }
            if (!json.has("asset")) throw PmxFormatException("Arquivo glTF sem o campo \"asset\"")
        }
        val ver = json.optJSONObject("asset")?.optString("version", "2.0") ?: "2.0"
        if (!ver.startsWith("2")) throw PmxFormatException("glTF versão $ver não suportada (só 2.0)")

        // ---- buffers
        val bufs = ArrayList<ByteArray?>()
        val jb = json.optJSONArray("buffers") ?: JSONArray()
        for (i in 0 until jb.length()) {
            val o = jb.getJSONObject(i); val uri = o.optString("uri", "")
            bufs.add(when {
                uri.isEmpty() -> if (i == 0) bin else null
                uri.startsWith("data:") -> decodeDataUri(uri)
                else -> resolve(decodeUri(uri))
            })
            if (bufs[i] == null) warnings.add("buffer $i não encontrado (${if (uri.isEmpty()) "GLB sem bloco BIN" else uri}); malhas que dependem dele ficam de fora")
        }
        val views = json.optJSONArray("bufferViews") ?: JSONArray()
        val accs = json.optJSONArray("accessors") ?: JSONArray()

        fun viewBytes(v: Int): Triple<ByteArray, Int, Int>? { // dados, offset, stride
            if (v !in 0 until views.length()) return null
            val o = views.getJSONObject(v)
            val b = bufs.getOrNull(o.optInt("buffer", 0)) ?: return null
            val off = o.optInt("byteOffset", 0)
            if (off < 0 || off > b.size) return null
            return Triple(b, off, o.optInt("byteStride", 0))
        }
        fun acc(i: Int): Acc? {
            if (i !in 0 until accs.length()) return null
            val a = accs.getJSONObject(i)
            if (a.has("sparse")) warnings.add("accessor $i usa sparse (ignorado)")
            return Acc(a.optInt("bufferView", -1), a.optInt("byteOffset", 0), a.optInt("componentType"), a.optInt("count"), a.optString("type"), a.optBoolean("normalized", false))
        }
        fun ncomp(t: String) = when (t) { "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; "MAT4" -> 16; else -> 0 }
        fun csize(c: Int) = when (c) { 5120, 5121 -> 1; 5122, 5123 -> 2; 5125, 5126 -> 4; else -> 0 }

        /** Lê um accessor como floats (inteiros normalizados viram 0..1 / -1..1 quando [normalized]; senão valores brutos). */
        fun readF(i: Int): FloatArray? {
            val a = acc(i) ?: return null
            val nc = ncomp(a.type); val cs = csize(a.comp)
            if (nc == 0 || cs == 0 || a.count < 0) return null
            val out = FloatArray(a.count * nc)
            if (a.view < 0) return out // sem bufferView = zeros (regra do glTF)
            val (b, vo, st) = viewBytes(a.view) ?: return null
            val stride = if (st > 0) st else nc * cs
            val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            for (e in 0 until a.count) {
                val base = vo + a.off + e * stride
                if (base < 0 || base + nc * cs > b.size) return null
                for (c in 0 until nc) {
                    val p = base + c * cs
                    out[e * nc + c] = when (a.comp) {
                        5126 -> bb.getFloat(p)
                        5121 -> (b[p].toInt() and 0xFF).let { if (a.norm) it / 255f else it.toFloat() }
                        5120 -> b[p].toInt().let { if (a.norm) max(it / 127f, -1f) else it.toFloat() }
                        5123 -> (bb.getShort(p).toInt() and 0xFFFF).let { if (a.norm) it / 65535f else it.toFloat() }
                        5122 -> bb.getShort(p).toInt().let { if (a.norm) max(it / 32767f, -1f) else it.toFloat() }
                        else -> (bb.getInt(p).toLong() and 0xFFFFFFFFL).toFloat()
                    }
                }
            }
            return out
        }
        /** Índices inteiros exatos (usa Int direto, sem passar por Float). */
        fun readI(i: Int): IntArray? {
            val a = acc(i) ?: return null
            val cs = csize(a.comp)
            if (cs == 0 || a.comp == 5126 || a.count < 0) return null
            val out = IntArray(a.count)
            if (a.view < 0) return out
            val (b, vo, st) = viewBytes(a.view) ?: return null
            val stride = if (st > 0) st else cs
            val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            for (e in 0 until a.count) {
                val p = vo + a.off + e * stride
                if (p < 0 || p + cs > b.size) return null
                out[e] = when (a.comp) { 5121 -> b[p].toInt() and 0xFF; 5123 -> bb.getShort(p).toInt() and 0xFFFF; 5120 -> b[p].toInt(); 5122 -> bb.getShort(p).toInt(); else -> bb.getInt(p) }
            }
            return out
        }

        // ---- nós: matrizes locais/mundiais
        val nodes = json.optJSONArray("nodes") ?: JSONArray()
        val nn = nodes.length()
        val nParent = IntArray(nn) { -1 }
        for (i in 0 until nn) { val ch = nodes.getJSONObject(i).optJSONArray("children") ?: continue; for (k in 0 until ch.length()) { val c = ch.optInt(k, -1); if (c in 0 until nn && c != i) nParent[c] = i } }
        val local = Array(nn) { localMatrix(nodes.getJSONObject(it)) }
        val world = arrayOfNulls<FloatArray>(nn)
        fun worldOf(i: Int, depth: Int = 0): FloatArray {
            world[i]?.let { return it }
            val p = nParent[i]
            val w = if (p < 0 || depth > 512) local[i] else mul(worldOf(p, depth + 1), local[i])
            world[i] = w; return w
        }

        // ---- ossos: todos os nós de todas as skins + osso "raiz" (índice 0) para o que não tem skin
        val skins = json.optJSONArray("skins") ?: JSONArray()
        val boneOfNode = HashMap<Int, Int>()
        val bNode = ArrayList<Int>() // nó de cada osso (-1 = raiz)
        bNode.add(-1)
        for (s in 0 until skins.length()) {
            val j = skins.getJSONObject(s).optJSONArray("joints") ?: continue
            for (k in 0 until j.length()) { val nd = j.optInt(k, -1); if (nd in 0 until nn && nd !in boneOfNode) { boneOfNode[nd] = bNode.size; bNode.add(nd) } }
        }
        val usedNames = HashSet<String>()
        fun uniq(base: String): String { var n = base.ifBlank { "osso" }; var k = 2; while (!usedNames.add(n)) n = "${base}_${k++}"; return n }

        // ---- malhas
        val pos = ArrayList<Float>(); val nrm = ArrayList<Float>(); val uv = ArrayList<Float>()
        val bi = ArrayList<Int>(); val bw = ArrayList<Float>()
        val indices = ArrayList<Int>(); val materials = ArrayList<PmxMaterial>()
        val texNames = ArrayList<String>(); val texEmbedded = ArrayList<ByteArray?>()
        val imgs = json.optJSONArray("images") ?: JSONArray()
        val texs = json.optJSONArray("textures") ?: JSONArray()
        val imgToTex = HashMap<Int, Int>()
        fun texIndex(t: Int): Int {
            if (t !in 0 until texs.length()) return -1
            val img = texs.getJSONObject(t).optInt("source", -1)
            if (img !in 0 until imgs.length()) return -1
            imgToTex[img]?.let { return it }
            val o = imgs.getJSONObject(img); val uri = o.optString("uri", "")
            val mime = o.optString("mimeType", "")
            val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
            var name = "imagem$img.$ext"; var bytes: ByteArray? = null
            when {
                uri.startsWith("data:") -> bytes = decodeDataUri(uri)
                uri.isNotEmpty() -> { name = decodeUri(uri); bytes = null }
                o.has("bufferView") -> { val v = viewBytes(o.getInt("bufferView")); val len = views.optJSONObject(o.getInt("bufferView"))?.optInt("byteLength", 0) ?: 0
                    if (v != null && len > 0 && v.second + len <= v.first.size) bytes = v.first.copyOfRange(v.second, v.second + len) }
            }
            if (uri.isEmpty() && bytes == null) warnings.add("imagem $img sem dados; material fica sem textura")
            texNames.add(name); texEmbedded.add(bytes)
            imgToTex[img] = texNames.size - 1
            return texNames.size - 1
        }
        val mats = json.optJSONArray("materials") ?: JSONArray()
        var morphWarned = false; var vcount = 0; var skippedPrims = 0

        val meshNodes = ArrayList<Pair<Int, Int>>() // (nó, malha); nó -1 = malha sem nó (usa identidade)
        for (i in 0 until nn) { val m = nodes.getJSONObject(i).optInt("mesh", -1); if (m >= 0) meshNodes.add(i to m) }
        if (meshNodes.isEmpty()) { val ms = json.optJSONArray("meshes"); if (ms != null) for (m in 0 until ms.length()) meshNodes.add(-1 to m) }
        val meshes = json.optJSONArray("meshes") ?: JSONArray()
        var usedRoot = false

        for ((nd, mi) in meshNodes) {
            val mesh = meshes.optJSONObject(mi) ?: continue
            val skinIdx = if (nd >= 0) nodes.getJSONObject(nd).optInt("skin", -1) else -1
            val joints = if (skinIdx in 0 until skins.length()) skins.getJSONObject(skinIdx).optJSONArray("joints") else null
            val w = if (nd >= 0) worldOf(nd) else IDENT
            val prims = mesh.optJSONArray("primitives") ?: continue
            for (pi in 0 until prims.length()) {
                val pr = prims.getJSONObject(pi); val at = pr.optJSONObject("attributes") ?: continue
                val mode = pr.optInt("mode", 4)
                if (mode !in 4..6) { skippedPrims++; continue }
                val p = readF(at.optInt("POSITION", -1))
                if (p == null) { skippedPrims++; continue }
                val vn = p.size / 3
                if (vn == 0) continue
                if (pr.has("targets") && !morphWarned) { morphWarned = true; warnings.add("morph targets do glTF ignorados") }
                var idx = if (pr.has("indices")) readI(pr.getInt("indices")) else IntArray(vn) { it }
                if (idx == null) { skippedPrims++; continue }
                idx = when (mode) { 5 -> strip(idx); 6 -> fan(idx); else -> idx }
                val tri = idx.size / 3 * 3
                var bad = false
                for (k in 0 until tri) if (idx[k] < 0 || idx[k] >= vn) { bad = true; break }
                if (bad) { warnings.add("primitiva com índice fora do intervalo ignorada"); skippedPrims++; continue }
                val nrmIn = if (at.has("NORMAL")) readF(at.getInt("NORMAL")) else null
                val uvIn = if (at.has("TEXCOORD_0")) readF(at.getInt("TEXCOORD_0")) else null
                val jIn = if (joints != null && at.has("JOINTS_0")) readF(at.getInt("JOINTS_0")).let { f -> f?.let { a -> IntArray(a.size) { a[it].toInt() } } } else null
                val wIn = if (joints != null && at.has("WEIGHTS_0")) readF(at.getInt("WEIGHTS_0")) else null
                val skinned = jIn != null && wIn != null && jIn.size >= vn * 4 && wIn.size >= vn * 4
                if (joints != null && !skinned) warnings.add("malha com skin sem JOINTS_0/WEIGHTS_0: presa ao osso raiz")
                if (at.has("JOINTS_1")) warnings.add("JOINTS_1/WEIGHTS_1 (mais de 4 ossos por vértice) ignorados")
                if (!skinned) usedRoot = true

                val base = vcount
                val nrmFinal = if (nrmIn != null && nrmIn.size >= vn * 3) nrmIn else computeNormals(p, idx, vn)
                for (v in 0 until vn) {
                    var x = p[v * 3]; var y = p[v * 3 + 1]; var z = p[v * 3 + 2]
                    var nx = nrmFinal[v * 3]; var ny = nrmFinal[v * 3 + 1]; var nz = nrmFinal[v * 3 + 2]
                    if (!skinned) { // peças sem skin: aplica a matriz do nó (posição e normal)
                        val q = xf(w, x, y, z); x = q[0]; y = q[1]; z = q[2]
                        val r = xfDir(w, nx, ny, nz); nx = r[0]; ny = r[1]; nz = r[2]
                    }
                    pos.add(x); pos.add(y); pos.add(-z)                   // metros, Z invertido (convertido p/ unidades MMD depois)
                    val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it < 1e-8f) 1f else it }
                    nrm.add(nx / l); nrm.add(ny / l); nrm.add(-nz / l)
                    if (uvIn != null && uvIn.size >= (v + 1) * 2) { uv.add(uvIn[v * 2]); uv.add(uvIn[v * 2 + 1]) } else { uv.add(0f); uv.add(0f) }
                    if (skinned) {
                        var sum = 0f; val tb = IntArray(4) { -1 }; val tw = FloatArray(4)
                        for (k in 0..3) {
                            val ji = jIn!![v * 4 + k]; val wt = wIn!![v * 4 + k]
                            val nodeIdx = joints!!.optInt(ji, -1)
                            val bone = boneOfNode[nodeIdx]
                            if (bone != null && wt > 0f) { tb[k] = bone; tw[k] = wt; sum += wt }
                        }
                        if (sum <= 1e-6f) { tb[0] = 0; tw[0] = 1f; sum = 1f; usedRoot = true }
                        for (k in 0..3) { bi.add(tb[k]); bw.add(tw[k] / sum) }
                    } else { bi.add(0); bi.add(-1); bi.add(-1); bi.add(-1); bw.add(1f); bw.add(0f); bw.add(0f); bw.add(0f) }
                }
                // Z invertido => inverte a ordem dos triângulos (a, c, b)
                var k = 0
                while (k < tri) { indices.add(base + idx[k]); indices.add(base + idx[k + 2]); indices.add(base + idx[k + 1]); k += 3 }
                vcount += vn

                val mo = if (pr.has("material")) mats.optJSONObject(pr.getInt("material")) else null
                val pbr = mo?.optJSONObject("pbrMetallicRoughness")
                val bc = pbr?.optJSONArray("baseColorFactor")
                val dif = floatArrayOf(bc?.optDouble(0, 1.0)?.toFloat() ?: 1f, bc?.optDouble(1, 1.0)?.toFloat() ?: 1f, bc?.optDouble(2, 1.0)?.toFloat() ?: 1f, bc?.optDouble(3, 1.0)?.toFloat() ?: 1f)
                if (mo?.optString("alphaMode", "OPAQUE") == "MASK") dif[3] = 1f
                val ti = pbr?.optJSONObject("baseColorTexture")?.let { texIndex(it.optInt("index", -1)) } ?: -1
                val name = mo?.optString("name", "")?.ifBlank { null } ?: "mat${materials.size}"
                materials.add(PmxMaterial(name, name, dif, FloatArray(3), 5f, floatArrayOf(dif[0], dif[1], dif[2]),
                    if (mo?.optBoolean("doubleSided", false) == true) 1 else 0, floatArrayOf(0f, 0f, 0f, 1f), 1f, ti, -1, 0, true, 0, tri))
            }
        }
        if (vcount == 0 || indices.isEmpty()) throw PmxFormatException("Nenhuma malha com triângulos encontrada no arquivo glTF")
        if (skippedPrims > 0) warnings.add("$skippedPrims primitiva(s) ignorada(s) (modo não triangular, dados ausentes ou inválidos)")
        if (json.has("cameras")) warnings.add("câmeras do glTF ignoradas")
        val reqExt = json.optJSONArray("extensionsRequired")
        if (reqExt != null && reqExt.length() > 0) warnings.add("extensões exigidas pelo arquivo não suportadas: " + (0 until reqExt.length()).joinToString { reqExt.optString(it) })

        // ---- escala/auto-ajuste (metros -> unidades MMD); modelo fora de 0,3..3,2 m é reescalado para ~1,6 m
        val bonePosM = Array(bNode.size) { b -> if (bNode[b] < 0) floatArrayOf(0f, 0f, 0f) else { val m = worldOf(bNode[b]); floatArrayOf(m[12], m[13], -m[14]) } }
        var s = 1f / MMD_UNIT
        var mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE); var mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (v in 0 until vcount) for (c in 0..2) { val t = pos[v * 3 + c]; if (t < mn[c]) mn[c] = t; if (t > mx[c]) mx[c] = t }
        val ext = max(mx[0] - mn[0], max(mx[1] - mn[1], mx[2] - mn[2]))
        if (ext > 3.2f || ext < 0.3f) { if (ext > 1e-6f) { s = 20f / ext; warnings.add("tamanho fora do normal (%.3g unidades): reescalado para ~1,6 m".format(ext)) } }
        val outPos = FloatArray(vcount * 3) { pos[it] * s }
        val outNrm = FloatArray(vcount * 3) { nrm[it] }

        // ---- ossos finais
        val flags = 0x0002 or 0x0004 or 0x0008 or 0x0010
        val bones = ArrayList<PmxBone>()
        val rootName = uniq("raiz")
        // ancestral-osso mais próximo de cada osso
        for (b in bNode.indices) {
            val nd = bNode[b]
            val name = if (nd < 0) rootName else uniq(nodes.getJSONObject(nd).optString("name", "").ifBlank { "osso$b" })
            var parent = -1
            if (nd >= 0) { var a = nParent[nd]; var guard = 0; while (a >= 0 && guard++ < 512) { val pb = boneOfNode[a]; if (pb != null) { parent = pb; break }; a = nParent[a] } }
            val p = bonePosM[b]
            bones.add(PmxBone(name, name, p[0] * s, p[1] * s, p[2] * s, parent, 0, flags, -1, -1, 0f, null))
        }
        if (!usedRoot && bones.size > 1) { /* osso raiz sem vértices: mantido (índice 0 é referenciado como fallback); inofensivo */ }

        // ---- animações (9.2): lê samplers/channels; o que não for válido vira aviso
        val clips = ArrayList<GltfClip>()
        val anims = json.optJSONArray("animations")
        if (anims != null) for (ai in 0 until anims.length()) {
            val ao = anims.optJSONObject(ai) ?: continue
            val an = ao.optString("name", "").ifBlank { "anim" }
            val sams = ao.optJSONArray("samplers") ?: JSONArray()
            val chs = ao.optJSONArray("channels") ?: JSONArray()
            val cache = HashMap<Int, Triple<FloatArray, FloatArray, GltfInterp>?>()
            fun sampler(si: Int): Triple<FloatArray, FloatArray, GltfInterp>? = cache.getOrPut(si) {
                val so = sams.optJSONObject(si) ?: return@getOrPut null
                val interp = GltfInterp.parse(so.optString("interpolation", "LINEAR")) ?: return@getOrPut null
                val tm = readF(so.optInt("input", -1)) ?: return@getOrPut null
                val vl = readF(so.optInt("output", -1)) ?: return@getOrPut null
                Triple(tm, vl, interp)
            }
            val list = ArrayList<GltfChannel>(); var bad = 0
            for (ci in 0 until chs.length()) {
                val co = chs.optJSONObject(ci) ?: run { bad++; null } ?: continue
                val tg = co.optJSONObject("target"); val path = tg?.optString("path", "") ?: ""
                val nd = tg?.optInt("node", -1) ?: -1
                if (nd !in 0 until nodes.length()) { bad++; warnings.add("animação '$an' canal $ci: alvo sem nó (ignorado)"); continue }
                val comps = when (path) { "translation", "scale" -> 3; "rotation" -> 4; else -> 0 }
                if (comps == 0) { bad++; warnings.add("animação '$an' canal $ci: propriedade '$path' não suportada (ignorado)"); continue }
                val tr = sampler(co.optInt("sampler", -1))
                if (tr == null) { bad++; warnings.add("animação '$an' canal $ci: sampler inválido (ignorado)"); continue }
                val smp = try { GltfSampler(tr.first, tr.second, comps, tr.third, rotation = path == "rotation") }
                    catch (e: IllegalArgumentException) { bad++; warnings.add("animação '$an' canal $ci: ${e.message} (ignorado)"); continue }
                list.add(GltfChannel(nd, nodes.getJSONObject(nd).optString("name", ""), boneOfNode[nd] ?: -1, path, smp))
            }
            if (list.isNotEmpty()) clips.add(GltfClip(an, list)) else warnings.add("animação '$an' sem canais utilizáveis")
        }
        if (clips.isNotEmpty()) warnings.add("${clips.size} animação(ões) do glTF lidas (${clips.sumOf { it.channels.size }} canais)")
        val restT = Array(nn) { i -> val o = nodes.getJSONObject(i); val m = o.optJSONArray("matrix")
            if (m != null && m.length() == 16) floatArrayOf(m.optDouble(12, 0.0).toFloat(), m.optDouble(13, 0.0).toFloat(), m.optDouble(14, 0.0).toFloat())
            else o.optJSONArray("translation")?.let { floatArrayOf(it.optDouble(0, 0.0).toFloat(), it.optDouble(1, 0.0).toFloat(), it.optDouble(2, 0.0).toFloat()) } ?: floatArrayOf(0f, 0f, 0f) }
        val restQ = Array(nn) { i -> val o = nodes.getJSONObject(i)
            val r = if (o.has("matrix")) null else o.optJSONArray("rotation")
            if (r == null) floatArrayOf(0f, 0f, 0f, 1f) else floatArrayOf(r.optDouble(0, 0.0).toFloat(), r.optDouble(1, 0.0).toFloat(), r.optDouble(2, 0.0).toFloat(), r.optDouble(3, 1.0).toFloat()).also { GltfSampler.normalize(it) } }
        if ((0 until nn).any { nodes.getJSONObject(it).has("matrix") } && clips.isNotEmpty()) warnings.add("nós com 'matrix' no glTF: rotação de repouso tratada como identidade (animação pode sair torta)")
        val name = json.optJSONObject("scene")?.optString("name") ?: (json.optJSONArray("scenes")?.optJSONObject(json.optInt("scene", 0))?.optString("name") ?: "")
        val model = PmxModel(name.ifBlank { "glTF" }, 2f, outPos, outNrm, FloatArray(vcount * 2) { uv[it] },
            IntArray(vcount * 4) { bi[it] }, FloatArray(vcount * 4) { bw[it] }, indices.toIntArray(), texNames, materials, bones, emptyList(), warnings = warnings)
        return Parsed(model, texEmbedded, clips, GltfRig(nParent, restT, restQ, s))
    }

    // ---------- utilidades ----------
    private val IDENT = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)

    private fun decodeUri(u: String): String = try { java.net.URLDecoder.decode(u.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { u }

    private fun decodeDataUri(u: String): ByteArray? = try {
        val c = u.indexOf(','); if (c < 0) null
        else if (u.substring(0, c).contains(";base64")) java.util.Base64.getMimeDecoder().decode(u.substring(c + 1))
        else java.net.URLDecoder.decode(u.substring(c + 1), "ISO-8859-1").toByteArray(Charsets.ISO_8859_1)
    } catch (e: Exception) { null }

    private fun strip(i: IntArray): IntArray { val o = ArrayList<Int>(); for (k in 0 until i.size - 2) { if (k % 2 == 0) { o.add(i[k]); o.add(i[k + 1]); o.add(i[k + 2]) } else { o.add(i[k + 1]); o.add(i[k]); o.add(i[k + 2]) } }; return o.toIntArray() }
    private fun fan(i: IntArray): IntArray { val o = ArrayList<Int>(); for (k in 1 until i.size - 1) { o.add(i[0]); o.add(i[k]); o.add(i[k + 1]) }; return o.toIntArray() }

    private fun computeNormals(p: FloatArray, idx: IntArray, vn: Int): FloatArray {
        val n = FloatArray(vn * 3)
        var t = 0
        while (t + 2 < idx.size) {
            val a = idx[t]; val b = idx[t + 1]; val c = idx[t + 2]; t += 3
            val ux = p[b * 3] - p[a * 3]; val uy = p[b * 3 + 1] - p[a * 3 + 1]; val uz = p[b * 3 + 2] - p[a * 3 + 2]
            val vx = p[c * 3] - p[a * 3]; val vy = p[c * 3 + 1] - p[a * 3 + 1]; val vz = p[c * 3 + 2] - p[a * 3 + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            for (v in intArrayOf(a, b, c)) { n[v * 3] += nx; n[v * 3 + 1] += ny; n[v * 3 + 2] += nz }
        }
        for (v in 0 until vn) { val l = sqrt(n[v * 3] * n[v * 3] + n[v * 3 + 1] * n[v * 3 + 1] + n[v * 3 + 2] * n[v * 3 + 2]); if (l < 1e-12f) { n[v * 3 + 1] = 1f } else { n[v * 3] /= l; n[v * 3 + 1] /= l; n[v * 3 + 2] /= l } }
        return n
    }

    /** Matriz 4x4 coluna-maior (como no glTF) a partir de `matrix` ou de TRS. */
    private fun localMatrix(o: JSONObject): FloatArray {
        o.optJSONArray("matrix")?.let { a -> if (a.length() == 16) return FloatArray(16) { a.optDouble(it, 0.0).toFloat() } }
        val t = o.optJSONArray("translation"); val r = o.optJSONArray("rotation"); val sc = o.optJSONArray("scale")
        val tx = t?.optDouble(0, 0.0)?.toFloat() ?: 0f; val ty = t?.optDouble(1, 0.0)?.toFloat() ?: 0f; val tz = t?.optDouble(2, 0.0)?.toFloat() ?: 0f
        var qx = r?.optDouble(0, 0.0)?.toFloat() ?: 0f; var qy = r?.optDouble(1, 0.0)?.toFloat() ?: 0f; var qz = r?.optDouble(2, 0.0)?.toFloat() ?: 0f; var qw = r?.optDouble(3, 1.0)?.toFloat() ?: 1f
        val ql = sqrt(qx * qx + qy * qy + qz * qz + qw * qw); if (ql > 1e-8f) { qx /= ql; qy /= ql; qz /= ql; qw /= ql } else { qx = 0f; qy = 0f; qz = 0f; qw = 1f }
        val sx = sc?.optDouble(0, 1.0)?.toFloat() ?: 1f; val sy = sc?.optDouble(1, 1.0)?.toFloat() ?: 1f; val sz = sc?.optDouble(2, 1.0)?.toFloat() ?: 1f
        val m = FloatArray(16)
        m[0] = (1 - 2 * (qy * qy + qz * qz)) * sx; m[1] = (2 * (qx * qy + qz * qw)) * sx; m[2] = (2 * (qx * qz - qy * qw)) * sx
        m[4] = (2 * (qx * qy - qz * qw)) * sy; m[5] = (1 - 2 * (qx * qx + qz * qz)) * sy; m[6] = (2 * (qy * qz + qx * qw)) * sy
        m[8] = (2 * (qx * qz + qy * qw)) * sz; m[9] = (2 * (qy * qz - qx * qw)) * sz; m[10] = (1 - 2 * (qx * qx + qy * qy)) * sz
        m[12] = tx; m[13] = ty; m[14] = tz; m[15] = 1f
        return m
    }

    /** a * b (coluna-maior). */
    internal fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(16)
        for (c in 0..3) for (rr in 0..3) { var s = 0f; for (k in 0..3) s += a[k * 4 + rr] * b[c * 4 + k]; r[c * 4 + rr] = s }
        return r
    }
    private fun xf(m: FloatArray, x: Float, y: Float, z: Float) = floatArrayOf(m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14])
    private fun xfDir(m: FloatArray, x: Float, y: Float, z: Float) = floatArrayOf(m[0] * x + m[4] * y + m[8] * z, m[1] * x + m[5] * y + m[9] * z, m[2] * x + m[6] * y + m[10] * z)
}
