package studio.mmd.mmd

/**
 * v2.31.0 — Ações prontas do rig de câmera que gravam keys de VMD (órbita, tremor assado, dolly zoom).
 * Todas partem da pose da câmera no quadro inicial, mesclam só o trecho afetado e preservam os keys fora dele.
 */
object CameraRigActions {

    private fun deg(r: Float) = Math.toDegrees(r.toDouble()).toFloat()

    /** Órbita a partir do quadro [startFrame] por [frames] quadros, girando [turnDeg] graus a partir do yaw atual. */
    fun orbitFrom(camera: VmdCamera?, startFrame: Int, frames: Int, turnDeg: Float = 360f, keys: Int = 12): VmdCamera {
        val s = startFrame.coerceAtLeast(0)
        val p = CameraMotionTools.sample(camera, s.toFloat())
        val gen = CameraRig.orbit(floatArrayOf(p.x, p.y, p.z), p.distance, deg(p.rx), deg(p.ry), deg(p.ry) + turnDeg, frames.coerceAtLeast(2), p.fov, keys)
        var cam = CameraMotionTools.put(camera, s, p)
        for (i in gen.frames.indices) {
            val f = s + gen.frames[i]
            cam = CameraMotionTools.put(cam, f, CameraPose(p.distance, p.x, p.y, p.z, gen.rot[i * 3], gen.rot[i * 3 + 1], gen.rot[i * 3 + 2], p.fov))
        }
        return cam
    }

    /** Assa o tremor em keys a cada [step] quadros entre [from] e [to]; devolve null se não houver câmera. */
    fun shakeRange(camera: VmdCamera?, shake: CameraRig.Shake, from: Int, to: Int, step: Int = 2, fps: Float = 30f): VmdCamera? {
        if (camera == null || to <= from) return camera
        var cam: VmdCamera = camera
        val st = step.coerceAtLeast(1)
        val out = FloatArray(8)
        var f = from.coerceAtLeast(0)
        while (f <= to) {
            val p = CameraMotionTools.sample(cam, f.toFloat())
            out[0] = p.distance; out[1] = p.x; out[2] = p.y; out[3] = p.z; out[4] = p.rx; out[5] = p.ry; out[6] = p.rz; out[7] = p.fov
            CameraRig.applyShake(out, shake, f.toFloat(), fps)
            cam = CameraMotionTools.put(cam, f, CameraPose(out[0], out[1], out[2], out[3], out[4], out[5], out[6], out[7]))
            f += st
        }
        return cam
    }

    /** Dolly zoom a partir de [frame]: a distância é multiplicada por [factor] em [frames] quadros e o FOV compensa. */
    fun dollyFrom(camera: VmdCamera?, frame: Int, frames: Int, factor: Float): VmdCamera {
        val s = frame.coerceAtLeast(0)
        val p = CameraMotionTools.sample(camera, s.toFloat())
        val base = CameraMotionTools.put(camera, s, p)
        val f = if (factor.isFinite() && factor > 0.05f) factor else 0.5f
        return CameraRig.dollyZoomKeys(base, s, s + frames.coerceAtLeast(2), p.distance, p.distance * f, p.fov, 8)
    }

    /** v2.33.0: insere [count] frames vazios em [frame] na câmera (keys >= frame deslizam). */
    fun insertAt(camera: VmdCamera?, frame: Int, count: Int): VmdCamera? =
        if (camera == null || count <= 0) camera else MotionFrameOps.insertFrames(camera, frame, count)

    /** v2.33.0: apaga [count] frames a partir de [frame] e fecha o espaço. */
    fun deleteAt(camera: VmdCamera?, frame: Int, count: Int): VmdCamera? =
        if (camera == null || count <= 0) camera else MotionFrameOps.deleteFrames(camera, frame, count)

    /**
     * v2.33.0: remove keys que a interpolação linear entre vizinhos reproduz (distância, centro, rotação em rad, FOV).
     * Keys com curva Bézier não linear em qualquer canal são preservadas. Devolve a câmera nova e o total removido.
     */
    fun reduce(camera: VmdCamera?, posTol: Float = 0.05f, angTolRad: Float = 0.01f, fovTol: Float = 0.2f): Pair<VmdCamera?, Int> {
        val c = camera ?: return null to 0
        val n = minOf(c.frames.size, c.dist.size, c.pos.size / 3, c.rot.size / 3, c.fov.size, c.ip.size / 24)
        if (n < 3) return c to 0
        fun linear(k: Int): Boolean {
            for (ch in 0 until 6) {
                val o = k * 24 + ch * 4
                // Layout do VMD de câmera: x1, x2, y1, y2 por canal.
                val x1 = c.ip[o].toInt() and 0xFF; val x2 = c.ip[o + 1].toInt() and 0xFF
                val y1 = c.ip[o + 2].toInt() and 0xFF; val y2 = c.ip[o + 3].toInt() and 0xFF
                if (Math.abs(x1 - y1) > 8 || Math.abs(x2 - y2) > 8) return false
            }
            return true
        }
        val keep = BooleanArray(n) { true }
        var last = 0
        for (i in 1 until n - 1) {
            val next = i + 1
            if (!linear(i) || !linear(next)) { last = i; continue }
            val span = (c.frames[next] - c.frames[last]).toFloat()
            if (span <= 0f) { last = i; continue }
            val t = (c.frames[i] - c.frames[last]) / span
            var ok = Math.abs(c.dist[i] - (c.dist[last] + (c.dist[next] - c.dist[last]) * t)) <= posTol * 4f &&
                Math.abs(c.fov[i] - (c.fov[last] + (c.fov[next] - c.fov[last]) * t)) <= fovTol
            for (a in 0..2) {
                if (Math.abs(c.pos[i * 3 + a] - (c.pos[last * 3 + a] + (c.pos[next * 3 + a] - c.pos[last * 3 + a]) * t)) > posTol) ok = false
                if (Math.abs(c.rot[i * 3 + a] - (c.rot[last * 3 + a] + (c.rot[next * 3 + a] - c.rot[last * 3 + a]) * t)) > angTolRad) ok = false
            }
            if (ok) keep[i] = false else last = i
        }
        val idx = (0 until n).filter { keep[it] }
        if (idx.size == n) return c to 0
        val m = idx.size
        val pos = FloatArray(m * 3); val rot = FloatArray(m * 3); val ip = ByteArray(m * 24)
        for (j in 0 until m) {
            val s = idx[j]
            for (a in 0..2) { pos[j * 3 + a] = c.pos[s * 3 + a]; rot[j * 3 + a] = c.rot[s * 3 + a] }
            System.arraycopy(c.ip, s * 24, ip, j * 24, 24)
        }
        return VmdCamera(IntArray(m) { c.frames[idx[it]] }, FloatArray(m) { c.dist[idx[it]] }, pos, rot, FloatArray(m) { c.fov[idx[it]] }, ip) to (n - m)
    }
}
