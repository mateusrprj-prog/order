package studio.mmd.mmd

/** Diagnóstico da pista de câmera VMD, separado das pistas de ossos e morphs. */
data class VmdCameraAuditReport(
    val keyCount: Int,
    val malformedArrays: Int,
    val negativeFrames: Int,
    val duplicateFrames: Int,
    val unorderedFrames: Int,
    val nonFiniteValues: Int,
    val invalidFov: Int,
    val malformedInterpolation: Int
) {
    val healthy: Boolean get() = malformedArrays == 0 && negativeFrames == 0 && duplicateFrames == 0 &&
        unorderedFrames == 0 && nonFiniteValues == 0 && invalidFov == 0 && malformedInterpolation == 0
}

data class VmdCameraRepairResult(
    val camera: VmdCamera,
    val before: VmdCameraAuditReport,
    val repairedKeys: Int,
    val removedKeys: Int
)

/**
 * Valida e normaliza dados numéricos de câmera VMD sem alterar a intenção da tomada:
 * mantém os valores válidos, ordena e consolida keys duplicadas e corrige apenas campos
 * estruturalmente inválidos. A última key de cada quadro vence em duplicatas.
 */
object VmdCameraDoctor {
    fun inspect(camera: VmdCamera): VmdCameraAuditReport {
        val n = camera.frames.size
        var arrays = 0; var negative = 0; var duplicate = 0; var unordered = 0
        var nonFinite = 0; var fovBad = 0; var ipBad = 0
        if (camera.dist.size != n || camera.pos.size != n * 3 || camera.rot.size != n * 3 ||
            camera.fov.size != n || camera.ip.size != n * 24) arrays++
        for (i in 0 until n) {
            if (camera.frames[i] < 0) negative++
            if (i > 0) {
                if (camera.frames[i] < camera.frames[i - 1]) unordered++
                if (camera.frames[i] == camera.frames[i - 1]) duplicate++
            }
            val values = floatArrayOf(
                camera.dist.getOrElse(i) { Float.NaN },
                camera.pos.getOrElse(i * 3) { Float.NaN }, camera.pos.getOrElse(i * 3 + 1) { Float.NaN }, camera.pos.getOrElse(i * 3 + 2) { Float.NaN },
                camera.rot.getOrElse(i * 3) { Float.NaN }, camera.rot.getOrElse(i * 3 + 1) { Float.NaN }, camera.rot.getOrElse(i * 3 + 2) { Float.NaN },
                camera.fov.getOrElse(i) { Float.NaN }
            )
            nonFinite += values.count { !it.isFinite() }
            val f = camera.fov.getOrNull(i)
            if (f != null && (!f.isFinite() || f !in 1f..179f)) fovBad++
        }
        if (camera.ip.size != n * 24) ipBad++
        if (camera.ip.any { (it.toInt() and 0xff) > 127 }) ipBad++
        return VmdCameraAuditReport(n, arrays, negative, duplicate, unordered, nonFinite, fovBad, ipBad)
    }

    fun repair(camera: VmdCamera): VmdCameraRepairResult {
        val before = inspect(camera)
        val sourceCount = minOf(camera.frames.size, camera.dist.size, camera.pos.size / 3, camera.rot.size / 3, camera.fov.size)
        data class Key(val frame: Int, val distance: Float, val position: FloatArray, val rotation: FloatArray, val fov: Float, val interpolation: ByteArray)
        val keys = LinkedHashMap<Int, Key>()
        var repaired = 0
        var removed = 0
        for (i in 0 until sourceCount) {
            val rawFrame = camera.frames[i]
            val frame = rawFrame.coerceAtLeast(0)
            val distance = camera.dist[i].takeIf { it.isFinite() } ?: 0f
            val position = FloatArray(3) { c -> camera.pos[i * 3 + c].takeIf { it.isFinite() } ?: 0f }
            val rotation = FloatArray(3) { c -> camera.rot[i * 3 + c].takeIf { it.isFinite() } ?: 0f }
            val rawFov = camera.fov[i]
            val fov = (rawFov.takeIf { it.isFinite() } ?: 45f).coerceIn(1f, 179f)
            val ip = ByteArray(24) { c ->
                val fallback = when (c % 4) { 0, 2 -> 20; else -> 107 }
                val raw = camera.ip.getOrNull(i * 24 + c)?.toInt()?.and(0xff) ?: fallback
                raw.coerceIn(0, 127).toByte()
            }
            val differs = frame != rawFrame || distance != camera.dist[i] ||
                (0..2).any { position[it] != camera.pos[i * 3 + it] || rotation[it] != camera.rot[i * 3 + it] } ||
                fov != rawFov || (0 until 24).any { ip[it] != camera.ip.getOrNull(i * 24 + it) }
            if (differs) repaired++
            if (keys.containsKey(frame)) removed++
            keys[frame] = Key(frame, distance, position, rotation, fov, ip)
        }
        removed += (camera.frames.size - sourceCount).coerceAtLeast(0)
        val sorted = keys.toSortedMap().values.toList()
        val n = sorted.size
        val frames = IntArray(n); val dist = FloatArray(n); val pos = FloatArray(n * 3)
        val rot = FloatArray(n * 3); val fov = FloatArray(n); val ip = ByteArray(n * 24)
        sorted.forEachIndexed { i, k ->
            frames[i] = k.frame; dist[i] = k.distance; fov[i] = k.fov
            k.position.copyInto(pos, i * 3); k.rotation.copyInto(rot, i * 3); k.interpolation.copyInto(ip, i * 24)
        }
        return VmdCameraRepairResult(VmdCamera(frames, dist, pos, rot, fov, ip), before, repaired, removed)
    }
}
