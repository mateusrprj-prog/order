package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.sqrt

/** Resultado da checagem de integridade de curvas VMD. */
data class VmdMotionAuditReport(
    val boneTracks: Int,
    val morphTracks: Int,
    val boneKeys: Int,
    val morphKeys: Int,
    val malformedTracks: Int,
    val negativeFrames: Int,
    val duplicateFrames: Int,
    val unorderedFrames: Int,
    val nonFiniteValues: Int,
    val invalidQuaternions: Int,
    val nonUnitQuaternions: Int,
    val malformedInterpolation: Int
) {
    val healthy: Boolean get() = malformedTracks == 0 && negativeFrames == 0 && duplicateFrames == 0 && unorderedFrames == 0 && nonFiniteValues == 0 && invalidQuaternions == 0 && nonUnitQuaternions == 0 && malformedInterpolation == 0
}

data class VmdMotionRepairResult(val motion: VmdMotion, val before: VmdMotionAuditReport, val repairedKeys: Int, val removedKeys: Int)

/**
 * Ferramentas de diagnóstico/reparo não destrutivo para curvas VMD já interpretadas.
 * A reparação estabiliza a estrutura numérica, mantém nomes de ossos/morphs e preserva
 * luz, sombra e IK extras; não tenta retarget nem altera a intenção artística da animação.
 */
object VmdMotionDoctor {
    fun inspect(motion: VmdMotion): VmdMotionAuditReport {
        var malformed = 0; var negative = 0; var duplicates = 0; var unordered = 0
        var nonFinite = 0; var invalidQ = 0; var nonUnitQ = 0; var malformedIp = 0
        var boneKeys = 0; var morphKeys = 0
        for ((_, t) in motion.bones) {
            val n = t.frames.size; boneKeys += n
            if (t.v.size != n * 7 || t.ip.size != n * 16) malformed++
            if (t.ip.size != n * 16) malformedIp++
            if (t.ip.any { (it.toInt() and 0xff) > 127 }) malformedIp++
            for (i in t.frames.indices) {
                if (t.frames[i] < 0) negative++
                if (i > 0) { if (t.frames[i] < t.frames[i - 1]) unordered++; if (t.frames[i] == t.frames[i - 1]) duplicates++ }
                val o = i * 7
                if (o + 6 >= t.v.size) continue
                for (k in 0..6) if (!t.v[o + k].isFinite()) nonFinite++
                val q = t.v.copyOfRange(o + 3, o + 7)
                val len = sqrt(q.sumOf { (it * it).toDouble() }).toFloat()
                if (!len.isFinite() || len < 1e-8f) invalidQ++ else if (abs(len - 1f) > .002f) nonUnitQ++
            }
        }
        for ((_, t) in motion.morphs) {
            val n = t.frames.size; morphKeys += n
            if (t.w.size != n) malformed++
            for (i in t.frames.indices) {
                if (t.frames[i] < 0) negative++
                if (i > 0) { if (t.frames[i] < t.frames[i - 1]) unordered++; if (t.frames[i] == t.frames[i - 1]) duplicates++ }
                if (i < t.w.size && !t.w[i].isFinite()) nonFinite++
            }
        }
        // Curvas extras também fazem parte da timeline VMD e não podem ser ignoradas pelo diagnóstico.
        for ((_, t) in motion.extras.ik) {
            if (t.frames.size != t.on.size) malformed++
            val n = minOf(t.frames.size, t.on.size)
            for (i in 0 until n) {
                if (t.frames[i] < 0) negative++
                if (i > 0) { if (t.frames[i] < t.frames[i - 1]) unordered++; if (t.frames[i] == t.frames[i - 1]) duplicates++ }
            }
        }
        motion.extras.lights?.let { l ->
            if (l.color.size != l.frames.size * 3 || l.dir.size != l.frames.size * 3) malformed++
            if (l.color.any { !it.isFinite() } || l.dir.any { !it.isFinite() }) nonFinite++
            for (i in l.frames.indices) { if (l.frames[i] < 0) negative++; if (i > 0) { if (l.frames[i] < l.frames[i-1]) unordered++; if (l.frames[i] == l.frames[i-1]) duplicates++ } }
        }
        motion.extras.shadows?.let { sh ->
            if (sh.mode.size != sh.frames.size || sh.dist.size != sh.frames.size) malformed++
            if (sh.dist.any { !it.isFinite() }) nonFinite++
            for (i in sh.frames.indices) { if (sh.frames[i] < 0) negative++; if (i > 0) { if (sh.frames[i] < sh.frames[i-1]) unordered++; if (sh.frames[i] == sh.frames[i-1]) duplicates++ } }
        }
        motion.extras.visibility?.let { vis ->
            if (vis.frames.size != vis.visible.size) malformed++
            for (i in vis.frames.indices) { if (vis.frames[i] < 0) negative++; if (i > 0) { if (vis.frames[i] < vis.frames[i-1]) unordered++; if (vis.frames[i] == vis.frames[i-1]) duplicates++ } }
        }
        return VmdMotionAuditReport(motion.bones.size, motion.morphs.size, boneKeys, morphKeys, malformed,
            negative, duplicates, unordered, nonFinite, invalidQ, nonUnitQ, malformedIp)
    }

    fun repair(motion: VmdMotion): VmdMotionRepairResult {
        val before = inspect(motion)
        var repaired = 0; var removed = 0
        val fixedBones = LinkedHashMap<String, VmdTrack>()
        for ((name, track) in motion.bones.toSortedMap()) {
            val count = minOf(track.frames.size, track.v.size / 7)
            var trackChanged = track.frames.size != count || track.v.size != track.frames.size * 7 || track.ip.size != track.frames.size * 16
            val keys = LinkedHashMap<Int, Pair<FloatArray, ByteArray>>()
            for (i in 0 until count) {
                val rawFrame = track.frames[i]
                val frame = rawFrame.coerceAtLeast(0)
                if (frame != rawFrame) trackChanged = true
                val value = FloatArray(7) { c -> track.v[i * 7 + c].takeIf { it.isFinite() } ?: 0f }
                if ((0..6).any { !track.v[i * 7 + it].isFinite() }) trackChanged = true
                var qx = value[3]; var qy = value[4]; var qz = value[5]; var qw = value[6]
                val qLen = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
                if (!qLen.isFinite() || qLen < 1e-8f) { qx = 0f; qy = 0f; qz = 0f; qw = 1f; trackChanged = true }
                else { if (abs(qLen - 1f) > 1e-6f) trackChanged = true; qx /= qLen; qy /= qLen; qz /= qLen; qw /= qLen }
                value[3] = qx; value[4] = qy; value[5] = qz; value[6] = qw
                val interpolation = ByteArray(16) { k ->
                    val raw = track.ip.getOrNull(i * 16 + k)?.toInt()?.and(0xff) ?: when (k % 4) { 0, 1 -> 20; else -> 107 }
                    if (raw !in 0..127) trackChanged = true
                    raw.coerceIn(0, 127).toByte()
                }
                if (keys.containsKey(frame)) { removed++; trackChanged = true }
                keys[frame] = value to interpolation // a última key do arquivo vence duplicatas
            }
            removed += (track.frames.size - count).coerceAtLeast(0)
            val sorted = keys.toSortedMap().entries.toList()
            if (sorted.indices.any { idx -> sorted[idx].key != track.frames.getOrNull(idx) }) trackChanged = true
            val values = FloatArray(sorted.size * 7); val ip = ByteArray(sorted.size * 16); val frames = IntArray(sorted.size)
            var previousQ: FloatArray? = null
            sorted.forEachIndexed { idx, entry ->
                frames[idx] = entry.key
                val v = entry.value.first.copyOf()
                previousQ?.let { p ->
                    val dot = p[0] * v[3] + p[1] * v[4] + p[2] * v[5] + p[3] * v[6]
                    if (dot < 0f) for (c in 3..6) v[c] = -v[c]
                }
                floatArrayOf(v[3], v[4], v[5], v[6]).also { previousQ = it }
                v.copyInto(values, idx * 7); entry.value.second.copyInto(ip, idx * 16)
            }
            if (trackChanged) repaired += sorted.size
            fixedBones[name] = VmdTrack(frames, values, ip)
        }

        val fixedMorphs = LinkedHashMap<String, VmdMorphTrack>()
        for ((name, track) in motion.morphs.toSortedMap()) {
            val count = minOf(track.frames.size, track.w.size)
            var trackChanged = track.frames.size != count || track.w.size != count
            val keys = LinkedHashMap<Int, Float>()
            for (i in 0 until count) {
                val frame = track.frames[i].coerceAtLeast(0)
                val weight = track.w[i].takeIf { it.isFinite() } ?: 0f
                if (frame != track.frames[i] || weight != track.w[i]) trackChanged = true
                if (keys.containsKey(frame)) { removed++; trackChanged = true }
                keys[frame] = weight
            }
            removed += (track.frames.size - count).coerceAtLeast(0) + (track.w.size - count).coerceAtLeast(0)
            val sorted = keys.toSortedMap().entries.toList()
            fixedMorphs[name] = VmdMorphTrack(IntArray(sorted.size) { sorted[it].key }, FloatArray(sorted.size) { sorted[it].value })
            if (trackChanged) repaired += sorted.size
        }

        // Extras são preservados, mas suas sequências IK também são ordenadas e deduplicadas.
        val ik = LinkedHashMap<String, VmdIkTrack>()
        for ((name, track) in motion.extras.ik.toSortedMap()) {
            val n = minOf(track.frames.size, track.on.size); val keys = LinkedHashMap<Int, Boolean>()
            for (i in 0 until n) keys[track.frames[i].coerceAtLeast(0)] = track.on[i]
            val sorted = keys.toSortedMap().entries.toList()
            removed += track.frames.size - n + (n - sorted.size)
            ik[name] = VmdIkTrack(IntArray(sorted.size) { sorted[it].key }, BooleanArray(sorted.size) { sorted[it].value })
        }
        // Normaliza os canais extras: sort estável, última chave vence em duplicatas e valores finitos.
        val fixedLights = motion.extras.lights?.let { l ->
            val n = minOf(l.frames.size, l.color.size / 3, l.dir.size / 3)
            val keyed = LinkedHashMap<Int, Pair<FloatArray, FloatArray>>()
            for (i in 0 until n) {
                val col = FloatArray(3) { c -> l.color[i * 3 + c].takeIf { it.isFinite() }?.coerceIn(0f, 4f) ?: 1f }
                val dir = FloatArray(3) { c -> l.dir[i * 3 + c].takeIf { it.isFinite() } ?: 0f }
                keyed[l.frames[i].coerceAtLeast(0)] = col to dir
            }
            val sorted = keyed.toSortedMap().entries.toList()
            VmdLightKeys(IntArray(sorted.size) { sorted[it].key }, FloatArray(sorted.size * 3) { sorted[it / 3].value.first[it % 3] }, FloatArray(sorted.size * 3) { sorted[it / 3].value.second[it % 3] })
        }
        val fixedShadows = motion.extras.shadows?.let { sh ->
            val n = minOf(sh.frames.size, sh.mode.size, sh.dist.size)
            val keyed = LinkedHashMap<Int, Pair<Byte, Float>>()
            for (i in 0 until n) keyed[sh.frames[i].coerceAtLeast(0)] = sh.mode[i].toInt().coerceIn(0, 2).toByte() to (sh.dist[i].takeIf { it.isFinite() }?.coerceAtLeast(0f) ?: 0f)
            val sorted = keyed.toSortedMap().entries.toList()
            VmdShadowKeys(IntArray(sorted.size) { sorted[it].key }, ByteArray(sorted.size) { sorted[it].value.first }, FloatArray(sorted.size) { sorted[it].value.second })
        }
        val fixedVisibility = motion.extras.visibility?.let { vis ->
            val n = minOf(vis.frames.size, vis.visible.size)
            val keyed = LinkedHashMap<Int, Boolean>()
            for (i in 0 until n) keyed[vis.frames[i].coerceAtLeast(0)] = vis.visible[i]
            val sorted = keyed.toSortedMap().entries.toList()
            VmdVisibilityKeys(IntArray(sorted.size) { sorted[it].key }, BooleanArray(sorted.size) { sorted[it].value })
        }
        // Mantém todos os canais extras, inclusive visibilidade global; eles não são descartáveis no reparo.
        val extras = VmdExtras(ik, fixedLights, fixedShadows, fixedVisibility)
        val extraMax = listOfNotNull(
            ik.values.flatMap { it.frames.asIterable() }.maxOrNull(),
            fixedLights?.frames?.maxOrNull(), fixedShadows?.frames?.maxOrNull(), fixedVisibility?.frames?.maxOrNull()
        ).maxOrNull() ?: 0
        val maxFrame = maxOf(
            motion.maxFrame, extraMax,
            fixedBones.values.flatMap { it.frames.asIterable() }.maxOrNull() ?: 0,
            fixedMorphs.values.flatMap { it.frames.asIterable() }.maxOrNull() ?: 0
        )
        val warnings = motion.warnings.toMutableList()
        if (removed > 0 || repaired > 0) warnings += "Motion Doctor: $repaired curvas reescritas e $removed keys inválidas/duplicadas removidas ou consolidadas."
        val fixed = VmdMotion(motion.modelName, fixedBones, fixedMorphs, maxFrame, warnings, extras)
        return VmdMotionRepairResult(fixed, before, repaired, removed)
    }
}
