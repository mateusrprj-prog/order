package studio.mmd.mmd

import kotlin.math.*
import studio.mmd.edit.Euler
import studio.mmd.rig.CType
import studio.mmd.rig.Constraint
import studio.mmd.rig.RigState
import studio.mmd.rig.Secondary

/**
 * Avalia a pose do modelo em um frame: amostra o VMD (Bézier/slerp), aplica morphs, FK, IK (CCD com limites),
 * "append" de rotação/translação (ossos D/twist) e skinning linear (BDEF1/2/4) na CPU; SDEF real só no shader (render/SceneGLView) + referência em Sdef.kt.
 * Trabalha em coordenadas MMD; a saída já é convertida para GL (Z invertido, escala).
 */
/** Pool compartilhado para o skinning em CPU (usa até 4 threads; o resto do trabalho fica na thread GL). */
private object SkinPool {
    val threads = (Runtime.getRuntime().availableProcessors()).coerceIn(1, 4)
    val ex: java.util.concurrent.ExecutorService = java.util.concurrent.Executors.newFixedThreadPool(maxOf(1, threads - 1)) { r ->
        Thread(r, "skin").apply { isDaemon = true }
    }
}

class Animator(private val m: PmxModel, private val scale: Float, rigConfig: studio.mmd.rig.RigConfig = RigState.main) {
    /** v1.26.0: configuração de rig (restrições/secundário/física/cache) deste personagem. */
    var rig: studio.mmd.rig.RigConfig = rigConfig
    companion object { /** Floats por osso na textura de matrizes: 4 texels RGBA (3 linhas da matriz + quaternion). */ const val ROW = 16 }
    @Volatile var motion: VmdMotion? = null
        set(v) { field = v; bind(v) }

    private val n = m.bones.size
    /** v1.13.0: IK ligado/desligado do VMD por osso de IK (null = sempre ligado). */
    private val ikTracks = arrayOfNulls<VmdIkTrack>(m.bones.size)
    private val bpos = FloatArray(n * 3)
    private val rot = FloatArray(n * 4); private val tr = FloatArray(n * 3)
    private val rotF = FloatArray(n * 4); private val trF = FloatArray(n * 3)
    private val gq = FloatArray(n * 4); private val gt = FloatArray(n * 3)
    private val mat = FloatArray(n * 12)
    private val work = FloatArray(m.positions.size)
    private val tracks = arrayOfNulls<VmdTrack>(n)
    private val mTracks = arrayOfNulls<VmdMorphTrack>(m.morphs.size)
    private val sQ = FloatArray(4); private val sQ2 = FloatArray(4)
    private val clothMatrixScratch = FloatArray(12)
    private val clothQuatScratchA = FloatArray(4); private val clothQuatScratchB = FloatArray(4)
    private val v1 = FloatArray(3); private val v2 = FloatArray(3)

    init { for (i in 0 until n) { bpos[i * 3] = m.bones[i].x; bpos[i * 3 + 1] = m.bones[i].y; bpos[i * 3 + 2] = m.bones[i].z } }

    private val topo: IntArray = run {
        val order = (0 until n).sortedWith(compareBy<Int>({ m.bones[it].layer }, { it }))
        val seen = BooleanArray(n); val res = ArrayList<Int>(n)
        fun visit(b: Int) {
            if (b !in 0 until n || seen[b]) return
            seen[b] = true
            visit(m.bones[b].parent); visit(m.bones[b].inheritParent)
            res.add(b)
        }
        for (b in order) visit(b)
        res.toIntArray()
    }

    private fun bind(mo: VmdMotion?) {
        secLast = Float.NaN
        for (i in 0 until n) tracks[i] = mo?.bones?.get(m.bones[i].name)
        for (i in m.morphs.indices) mTracks[i] = mo?.morphs?.get(m.morphs[i].name)
        for (i in 0 until n) ikTracks[i] = if (m.bones[i].ik != null) mo?.extras?.ik?.get(m.bones[i].name) else null
    }

    // ---------- matemática de quaternions (x,y,z,w em arrays) ----------
    private fun qmul(a: FloatArray, ao: Int, b: FloatArray, bo: Int, o: FloatArray, oo: Int) {
        val ax = a[ao]; val ay = a[ao + 1]; val az = a[ao + 2]; val aw = a[ao + 3]
        val bx = b[bo]; val by = b[bo + 1]; val bz = b[bo + 2]; val bw = b[bo + 3]
        o[oo] = aw * bx + ax * bw + ay * bz - az * by
        o[oo + 1] = aw * by - ax * bz + ay * bw + az * bx
        o[oo + 2] = aw * bz + ax * by - ay * bx + az * bw
        o[oo + 3] = aw * bw - ax * bx - ay * by - az * bz
    }

    /** Rotaciona o vetor (vx,vy,vz) por q (ou pelo conjugado) e escreve o resultado em o a partir de oo. */
    private fun qrot(q: FloatArray, qo: Int, vx: Float, vy: Float, vz: Float, conj: Boolean, o: FloatArray, oo: Int) {
        val x = q[qo] * (if (conj) -1f else 1f); val y = q[qo + 1] * (if (conj) -1f else 1f); val z = q[qo + 2] * (if (conj) -1f else 1f); val w = q[qo + 3]
        val tx = 2 * (y * vz - z * vy); val ty = 2 * (z * vx - x * vz); val tz = 2 * (x * vy - y * vx)
        o[oo] = vx + w * tx + (y * tz - z * ty)
        o[oo + 1] = vy + w * ty + (z * tx - x * tz)
        o[oo + 2] = vz + w * tz + (x * ty - y * tx)
    }

    /** q^w (potência), caminho mais curto. */
    private fun qpow(q: FloatArray, qo: Int, w: Float, o: FloatArray) {
        var x = q[qo]; var y = q[qo + 1]; var z = q[qo + 2]; var qw = q[qo + 3]
        if (qw < 0) { x = -x; y = -y; z = -z; qw = -qw }
        val len = sqrt(x * x + y * y + z * z)
        if (len < 1e-8f) { o[0] = 0f; o[1] = 0f; o[2] = 0f; o[3] = 1f; return }
        val ang = 2 * atan2(len, qw) * w
        val s = sin(ang / 2) / len
        o[0] = x * s; o[1] = y * s; o[2] = z * s; o[3] = cos(ang / 2)
    }

    private fun bez(ip: ByteArray, i1: Int, i2: Int, i3: Int, i4: Int, s: Float): Float {
        val x1 = (ip[i1].toInt() and 0xFF) / 127f; val y1 = (ip[i2].toInt() and 0xFF) / 127f
        val x2 = (ip[i3].toInt() and 0xFF) / 127f; val y2 = (ip[i4].toInt() and 0xFF) / 127f
        if (x1 == y1 && x2 == y2) return s
        var lo = 0f; var hi = 1f; var t = s
        for (k in 0 until 18) {
            t = (lo + hi) / 2
            val u = 1 - t
            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
            if (x < s) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
    }

    private fun find(frames: IntArray, f: Float): Int {
        var lo = 0; var hi = frames.size - 1; var r = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (frames[mid] <= f) { r = mid; lo = mid + 1 } else hi = mid - 1 }
        return r
    }

    private fun sampleBone(t: VmdTrack, f: Float, b: Int) {
        val i = find(t.frames, f)
        if (i < 0 || i == t.frames.size - 1) {
            val a = (if (i < 0) 0 else i) * 7
            for (c in 0..2) tr[b * 3 + c] = t.v[a + c]
            for (c in 0..3) rot[b * 4 + c] = t.v[a + 3 + c]
            return
        }
        val a = i * 7; val bb = (i + 1) * 7; val ip = (i + 1) * 16
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i])
        val sx = bez(t.ip, ip, ip + 4, ip + 8, ip + 12, s)
        val sy = bez(t.ip, ip + 1, ip + 5, ip + 9, ip + 13, s)
        val sz = bez(t.ip, ip + 2, ip + 6, ip + 10, ip + 14, s)
        val sr = bez(t.ip, ip + 3, ip + 7, ip + 11, ip + 15, s)
        tr[b * 3] = t.v[a] + (t.v[bb] - t.v[a]) * sx
        tr[b * 3 + 1] = t.v[a + 1] + (t.v[bb + 1] - t.v[a + 1]) * sy
        tr[b * 3 + 2] = t.v[a + 2] + (t.v[bb + 2] - t.v[a + 2]) * sz
        var dot = 0f
        for (c in 0..3) dot += t.v[a + 3 + c] * t.v[bb + 3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) {
            val q = t.v[a + 3 + c] * (1 - sr) + t.v[bb + 3 + c] * sg * sr
            rot[b * 4 + c] = q; len += q * q
        }
        len = sqrt(len); if (len > 1e-8f) for (c in 0..3) rot[b * 4 + c] /= len
    }

    private fun sampleMorph(t: VmdMorphTrack, f: Float): Float {
        val i = find(t.frames, f)
        if (i < 0) return t.w[0]
        if (i == t.frames.size - 1) return t.w[i]
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i])
        return t.w[i] + (t.w[i + 1] - t.w[i]) * s
    }

    private val resolver = MorphResolver(m.morphs)
    private val impulseDispatcher = PmxImpulseMorphDispatcher(m)
    // v1.12.1: morphs de material (tipo 8) decodificados uma vez; o acúmulo é refeito a cada pose
    private val matElems: Array<List<MatMorphElem>?> = Array(m.morphs.size) { i -> if (m.morphs[i].type == 8) MaterialMorphs.decode(m.morphs[i]) else null }
    val matMorph = MaterialMorphState(m.materials.size)
    // v1.12.3: morphs de UV (tipo 3). uvWork só existe se o modelo tem algum; é refeito a cada pose
    private val uvElems: Array<UvMorph?> = Array(m.morphs.size) { i -> if (m.morphs[i].type == 3) UvMorph.decode(m.morphs[i]) else null }
    private val hasUvMorph = uvElems.any { it != null }
    private val uvWork = FloatArray(if (hasUvMorph) m.uvs.size else 0)
    // PMX tipos 4..7: morphs nos canais vec4 de UV adicional.
    private val additionalUvElems: Array<AdditionalUvMorph?> = Array(m.morphs.size) { i -> AdditionalUvMorph.decode(m.morphs[i]) }
    private val hasAdditionalUvMorph = additionalUvElems.any { it != null } && m.addUvCount > 0 && m.addUvs.size == m.vertexCount * m.addUvCount * 4
    private val additionalUvWork = FloatArray(if (hasAdditionalUvMorph) m.addUvs.size else 0)
    var additionalUvMorphed = false
        private set
    val morphedAdditionalUvs: FloatArray get() = additionalUvWork
    val hasAdditionalUvMorphs: Boolean get() = hasAdditionalUvMorph
    /** Verdadeiro se o último evaluate* aplicou algum morph de UV. */
    var uvMorphed = false
        private set
    /** UVs (2 por vértice) já com morphs de UV; só válido se [hasUvMorphs]. */
    val morphedUvs: FloatArray get() = uvWork
    val hasUvMorphs: Boolean get() = hasUvMorph
    private val morphSink = object : MorphSink { override fun leaf(index: Int, weight: Float) { applyLeafMorph(index, weight) } }

    /** Resolve grupo/flip (ver MorphResolver) e aplica só os morphs folha. */
    private fun applyMorph(mi: Int, w: Float) = resolver.resolve(mi, w, morphSink)

    private fun applyLeafMorph(mi: Int, w: Float) {
        val mo = m.morphs[mi]
        when (mo.type) {
            1 -> { val idx = mo.vertexIdx!!; val d = mo.vertexDelta!!
                if (idx.isNotEmpty()) vertexMorphed = true
                for (k in idx.indices) { val v = idx[k]; if (v < 0 || v * 3 + 2 >= work.size) continue
                    work[v * 3] += d[k * 3] * w; work[v * 3 + 1] += d[k * 3 + 1] * w; work[v * 3 + 2] += d[k * 3 + 2] * w } }
            2 -> { val idx = mo.boneIdx!!
                for (k in idx.indices) { val b = idx[k]; if (b !in 0 until n) continue
                    for (c in 0..2) tr[b * 3 + c] += mo.boneTrans!![k * 3 + c] * w
                    System.arraycopy(mo.boneRot!!, k * 4, sQ2, 0, 4)
                    qpow(sQ2, 0, w, sQ); qmul(rot, b * 4, sQ, 0, sQ2, 0); System.arraycopy(sQ2, 0, rot, b * 4, 4) } }
            3 -> { val u = uvElems[mi] ?: return; if (u.apply(uvWork, w)) uvMorphed = true }
            in 4..7 -> { val u = additionalUvElems[mi] ?: return; if (hasAdditionalUvMorph && u.apply(additionalUvWork, m.addUvCount, w)) additionalUvMorphed = true }
            8 -> { val es = matElems[mi] ?: return; for (k in es.indices) matMorph.apply(es[k], w) }
        }
    }

    // ---------- esqueleto ----------
    private fun global(b: Int, append: Boolean) {
        val bone = m.bones[b]
        System.arraycopy(rot, b * 4, sQ, 0, 4)
        var tx = tr[b * 3]; var ty = tr[b * 3 + 1]; var tz = tr[b * 3 + 2]
        val s = bone.inheritParent
        if (append && s in 0 until n && s != b && bone.inheritWeight != 0f) {
            if (bone.flags and 0x0100 != 0) { qpow(rotF, s * 4, bone.inheritWeight, sQ2); qmul(sQ, 0, sQ2, 0, sQ, 0) }
            if (bone.flags and 0x0200 != 0) { tx += trF[s * 3] * bone.inheritWeight; ty += trF[s * 3 + 1] * bone.inheritWeight; tz += trF[s * 3 + 2] * bone.inheritWeight }
        }
        System.arraycopy(sQ, 0, rotF, b * 4, 4)
        trF[b * 3] = tx; trF[b * 3 + 1] = ty; trF[b * 3 + 2] = tz
        val p = bone.parent
        if (p !in 0 until n || p == b) {
            System.arraycopy(sQ, 0, gq, b * 4, 4)
            gt[b * 3] = bone.x + tx; gt[b * 3 + 1] = bone.y + ty; gt[b * 3 + 2] = bone.z + tz
        } else {
            val ox = bone.x - bpos[p * 3] + tx; val oy = bone.y - bpos[p * 3 + 1] + ty; val oz = bone.z - bpos[p * 3 + 2] + tz
            qrot(gq, p * 4, ox, oy, oz, false, gt, b * 3)
            gt[b * 3] += gt[p * 3]; gt[b * 3 + 1] += gt[p * 3 + 1]; gt[b * 3 + 2] += gt[p * 3 + 2]
            qmul(gq, p * 4, sQ, 0, gq, b * 4)
        }
    }

    private fun refreshChain(ik: PmxIk) {
        for (k in ik.links.indices.reversed()) { val lb = ik.links[k].bone; if (lb in 0 until n) global(lb, false) }
        val stack = ArrayList<Int>(); var b = ik.target
        while (b in 0 until n && ik.links.none { it.bone == b } && stack.size < 64) { stack.add(b); b = m.bones[b].parent }
        for (k in stack.indices.reversed()) global(stack[k], false)
    }

    private fun solveIk(ikBone: Int, ik: PmxIk) {
        val tb = ik.target
        if (tb !in 0 until n) return
        for (iter in 0 until min(ik.loopCount, 64)) {
            for (link in ik.links) {
                val lb = link.bone
                if (lb !in 0 until n) continue
                qrot(gq, lb * 4, gt[tb * 3] - gt[lb * 3], gt[tb * 3 + 1] - gt[lb * 3 + 1], gt[tb * 3 + 2] - gt[lb * 3 + 2], true, v1, 0)
                qrot(gq, lb * 4, gt[ikBone * 3] - gt[lb * 3], gt[ikBone * 3 + 1] - gt[lb * 3 + 1], gt[ikBone * 3 + 2] - gt[lb * 3 + 2], true, v2, 0)
                val l1 = sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2]); val l2 = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
                if (l1 < 1e-8f || l2 < 1e-8f) continue
                for (c in 0..2) { v1[c] /= l1; v2[c] /= l2 }
                val dot = (v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]).coerceIn(-1f, 1f)
                if (dot > 0.999999f) continue
                val ang = min(acos(dot), ik.limitAngle)
                var ax = v1[1] * v2[2] - v1[2] * v2[1]; var ay = v1[2] * v2[0] - v1[0] * v2[2]; var az = v1[0] * v2[1] - v1[1] * v2[0]
                val al = sqrt(ax * ax + ay * ay + az * az)
                if (al < 1e-8f) continue
                ax /= al; ay /= al; az /= al
                val mn = link.min; val mx = link.max
                if (link.hasLimit && mn != null && mx != null && mn[1] == 0f && mx[1] == 0f && mn[2] == 0f && mx[2] == 0f) {
                    ax = if (ax >= 0) 1f else -1f; ay = 0f; az = 0f
                }
                val sn = sin(ang / 2)
                sQ[0] = ax * sn; sQ[1] = ay * sn; sQ[2] = az * sn; sQ[3] = cos(ang / 2)
                qmul(rot, lb * 4, sQ, 0, sQ2, 0)
                System.arraycopy(sQ2, 0, rot, lb * 4, 4)
                if (link.hasLimit && mn != null && mx != null) clampRotVec(lb, mn, mx)
                refreshChain(ik)
            }
            val dx = gt[tb * 3] - gt[ikBone * 3]; val dy = gt[tb * 3 + 1] - gt[ikBone * 3 + 1]; val dz = gt[tb * 3 + 2] - gt[ikBone * 3 + 2]
            if (dx * dx + dy * dy + dz * dz < 1e-8f) break
        }
    }

    private fun clampRotVec(b: Int, mn: FloatArray, mx: FloatArray) {
        var x = rot[b * 4]; var y = rot[b * 4 + 1]; var z = rot[b * 4 + 2]; var w = rot[b * 4 + 3]
        if (w < 0) { x = -x; y = -y; z = -z; w = -w }
        val len = sqrt(x * x + y * y + z * z)
        if (len < 1e-8f) return
        val ang = 2 * atan2(len, w)
        val rx = (x / len * ang).coerceIn(min(mn[0], mx[0]), max(mn[0], mx[0]))
        val ry = (y / len * ang).coerceIn(min(mn[1], mx[1]), max(mn[1], mx[1]))
        val rz = (z / len * ang).coerceIn(min(mn[2], mx[2]), max(mn[2], mx[2]))
        val a2 = sqrt(rx * rx + ry * ry + rz * rz)
        if (a2 < 1e-8f) { rot[b * 4] = 0f; rot[b * 4 + 1] = 0f; rot[b * 4 + 2] = 0f; rot[b * 4 + 3] = 1f; return }
        val s = sin(a2 / 2) / a2
        rot[b * 4] = rx * s; rot[b * 4 + 1] = ry * s; rot[b * 4 + 2] = rz * s; rot[b * 4 + 3] = cos(a2 / 2)
    }

    /** Prepara o skinning para um quadro sem alocar buffers GL; usado pelo bake físico com colisão animada. */
    fun prepareClothPose(frame: Float) {
        pose(frame)
        buildMatrices()
    }

    /** Matriz blended por vértice, em coordenadas MMD e sem a escala final do viewport. */
    private fun blendedSkinMatrix(vertex: Int, out: FloatArray): Boolean {
        require(vertex in 0 until m.vertexCount)
        out.fill(0f)
        var total = 0f
        for (k in 0..3) {
            val bone = m.boneIndices.getOrElse(vertex * 4 + k) { -1 }
            val weight = m.boneWeights.getOrElse(vertex * 4 + k) { 0f }
            if (bone !in 0 until n || !weight.isFinite() || weight == 0f) continue
            val source = bone * 12
            for (c in 0 until 12) out[c] += mat[source + c] * weight
            total += weight
        }
        if (total <= 1e-8f) {
            out[0] = 1f; out[4] = 1f; out[8] = 1f
            return false
        }
        return true
    }

    /** Transforma um ponto local para o espaço deformado do personagem (MMD XYZ). [out] precisa ter 3 floats. */
    fun skinPointToModel(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        require(out.size >= 3)
        val mtx = clothMatrixScratch
        if (!blendedSkinMatrix(vertex, mtx)) { out[0] = x; out[1] = y; out[2] = z; return }
        out[0] = mtx[0] * x + mtx[1] * y + mtx[2] * z + mtx[9]
        out[1] = mtx[3] * x + mtx[4] * y + mtx[5] * z + mtx[10]
        out[2] = mtx[6] * x + mtx[7] * y + mtx[8] * z + mtx[11]
    }

    /** Inversa do blended skinning, usada para devolver a roupa ao espaço local pré-skinning. */
    fun unskinPointFromModel(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        require(out.size >= 3)
        val mtx = clothMatrixScratch
        if (!blendedSkinMatrix(vertex, mtx)) { out[0] = x; out[1] = y; out[2] = z; return }
        val a = mtx[0]; val b = mtx[1]; val c = mtx[2]
        val d = mtx[3]; val e = mtx[4]; val f = mtx[5]
        val g = mtx[6]; val h = mtx[7]; val i = mtx[8]
        val det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
        if (!det.isFinite() || kotlin.math.abs(det) < 1e-9f) { out[0] = x; out[1] = y; out[2] = z; return }
        val px = x - mtx[9]; val py = y - mtx[10]; val pz = z - mtx[11]
        val inv = 1f / det
        out[0] = ((e * i - f * h) * px + (c * h - b * i) * py + (b * f - c * e) * pz) * inv
        out[1] = ((f * g - d * i) * px + (a * i - c * g) * py + (c * d - a * f) * pz) * inv
        out[2] = ((d * h - e * g) * px + (b * g - a * h) * py + (a * e - b * d) * pz) * inv
    }

    /** Transforma um ponto definido no espaço de repouso do osso para o espaço MMD deformado. */
    fun bonePointToModel(bone: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        require(bone in 0 until n && out.size >= 3)
        qrot(gq, bone * 4, x - bpos[bone * 3], y - bpos[bone * 3 + 1], z - bpos[bone * 3 + 2], false, out, 0)
        out[0] += gt[bone * 3]; out[1] += gt[bone * 3 + 1]; out[2] += gt[bone * 3 + 2]
    }

    /** Transforma direção no referencial do osso, sem translação. */
    fun boneVectorToModel(bone: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        require(bone in 0 until n && out.size >= 3)
        qrot(gq, bone * 4, x, y, z, false, out, 0)
    }

    /** Compõe uma rotação Euler XYZ local com a rotação animada do osso e devolve Euler XYZ. */
    fun boneEulerToModel(bone: Int, rx: Float, ry: Float, rz: Float, out: FloatArray) {
        require(bone in 0 until n && out.size >= 3)
        val hx = rx * 0.5f; val hy = ry * 0.5f; val hz = rz * 0.5f
        val qx = sin(hx); val qy = sin(hy); val qz = sin(hz)
        val wx = cos(hx); val wy = cos(hy); val wz = cos(hz)
        // qBody = qz * qy * qx (mesma ordem PMX XYZ usada pelo editor de colisores).
        val tx = wy * qx; val ty = qy * wx; val tz = -qy * qx; val tw = wy * wx
        clothQuatScratchA[0] = wz * tx - qz * ty
        clothQuatScratchA[1] = wz * ty + qz * tx
        clothQuatScratchA[2] = wz * tz + qz * tw
        clothQuatScratchA[3] = wz * tw - qz * tz
        qmul(gq, bone * 4, clothQuatScratchA, 0, clothQuatScratchB, 0)
        val x = clothQuatScratchB[0]; val y = clothQuatScratchB[1]; val z = clothQuatScratchB[2]; val w = clothQuatScratchB[3]
        out[0] = atan2(2f * (w * x + y * z), 1f - 2f * (x * x + y * y))
        out[1] = asin((2f * (w * y - z * x)).coerceIn(-1f, 1f))
        out[2] = atan2(2f * (w * z + x * y), 1f - 2f * (y * y + z * z))
    }

    /** Rotação/escala blended sem translação; vetores de velocidade usam este caminho. */
    fun skinVectorToModel(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        val mtx = clothMatrixScratch
        if (!blendedSkinMatrix(vertex, mtx)) { out[0] = x; out[1] = y; out[2] = z; return }
        out[0] = mtx[0] * x + mtx[1] * y + mtx[2] * z
        out[1] = mtx[3] * x + mtx[4] * y + mtx[5] * z
        out[2] = mtx[6] * x + mtx[7] * y + mtx[8] * z
    }

    fun unskinVectorFromModel(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
        val mtx = clothMatrixScratch
        if (!blendedSkinMatrix(vertex, mtx)) { out[0] = x; out[1] = y; out[2] = z; return }
        val a = mtx[0]; val b = mtx[1]; val c = mtx[2]; val d = mtx[3]; val e = mtx[4]; val f = mtx[5]; val g = mtx[6]; val h = mtx[7]; val i = mtx[8]
        val det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
        if (!det.isFinite() || kotlin.math.abs(det) < 1e-9f) { out[0] = x; out[1] = y; out[2] = z; return }
        val inv = 1f / det
        out[0] = ((e * i - f * h) * x + (c * h - b * i) * y + (b * f - c * e) * z) * inv
        out[1] = ((f * g - d * i) * x + (a * i - c * g) * y + (c * d - a * f) * z) * inv
        out[2] = ((d * h - e * g) * x + (b * g - a * h) * y + (a * e - b * d) * z) * inv
    }

    /** Posições globais de todos os ossos em coordenadas MMD após prepareClothPose/evaluate. */
    fun bonePositionsMmd(out: FloatArray) {
        require(out.size >= n * 3)
        for (b in 0 until n) {
            out[b * 3] = gt[b * 3]
            out[b * 3 + 1] = gt[b * 3 + 1]
            out[b * 3 + 2] = gt[b * 3 + 2]
        }
    }

    /** Posição global (já em coordenadas GL) de cada osso após o último evaluate(). Chamar só na thread GL. */
    fun boneGl(out: FloatArray) {
        for (b in 0 until n) {
            out[b * 3] = gt[b * 3] * scale
            out[b * 3 + 1] = gt[b * 3 + 1] * scale
            out[b * 3 + 2] = -gt[b * 3 + 2] * scale
        }
    }

    /** Matriz 4x4 (coluna-maior, coordenadas GL) da transformação global do osso [b] após o último evaluate(). Thread GL. */
    fun boneMatrixGl(b: Int, o: FloatArray) {
        val x = -gq[b * 4]; val y = -gq[b * 4 + 1]; val z = gq[b * 4 + 2]; val w = gq[b * 4 + 3]
        o[0] = 1 - 2 * (y * y + z * z); o[1] = 2 * (x * y + z * w); o[2] = 2 * (x * z - y * w); o[3] = 0f
        o[4] = 2 * (x * y - z * w); o[5] = 1 - 2 * (x * x + z * z); o[6] = 2 * (y * z + x * w); o[7] = 0f
        o[8] = 2 * (x * z + y * w); o[9] = 2 * (y * z - x * w); o[10] = 1 - 2 * (x * x + y * y); o[11] = 0f
        o[12] = gt[b * 3] * scale; o[13] = gt[b * 3 + 1] * scale; o[14] = -gt[b * 3 + 2] * scale; o[15] = 1f
    }

    /** Rotaciona o vetor (coordenadas MMD, espaço global) para o espaço local do pai do osso [b]. Thread GL, após evaluate(). */
    fun toParentSpace(b: Int, vx: Float, vy: Float, vz: Float, out: FloatArray) {
        val p = m.bones[b].parent
        if (p !in 0 until n || p == b) { out[0] = vx; out[1] = vy; out[2] = vz }
        else qrot(gq, p * 4, vx, vy, vz, true, out, 0)
    }

    /** Calcula a pose em [frame] e escreve posição/normal (offsets 0..5 de cada vértice de 8 floats) em [out]. */
    fun evaluate(frame: Float, out: FloatArray) {
        pose(frame)
        buildMatrices()
        skin(out)
    }

    /** Verdadeiro se o último evaluate* aplicou algum morph de vértice (aí [morphedPositions] difere do repouso). */
    var vertexMorphed = false
        private set
    /** Posições (coordenadas MMD, 3 por vértice) já com morphs de vértice. Válido após evaluate*. */
    val morphedPositions: FloatArray get() = work

    /**
     * Pose + matrizes de osso para skinning na GPU: 3 linhas vec4 por osso (12 floats), já em GL
     * (escala e Z invertido embutidos). Mesmo resultado do skinning em CPU, sem tocar nos vértices.
     */
    fun evaluateRows(frame: Float, rows: FloatArray) {
        pose(frame); buildMatrices()
        val s = scale
        for (b in 0 until n) {
            val o = b * ROW; val k = b * 12
            rows[o] = mat[k] * s; rows[o + 1] = mat[k + 1] * s; rows[o + 2] = mat[k + 2] * s; rows[o + 3] = mat[k + 9] * s
            rows[o + 4] = mat[k + 3] * s; rows[o + 5] = mat[k + 4] * s; rows[o + 6] = mat[k + 5] * s; rows[o + 7] = mat[k + 10] * s
            rows[o + 8] = -mat[k + 6] * s; rows[o + 9] = -mat[k + 7] * s; rows[o + 10] = -mat[k + 8] * s; rows[o + 11] = -mat[k + 11] * s
            // 4º texel (v1.12.0, SDEF): rotação global do osso (quaternion xyzw, coordenadas MMD)
            rows[o + 12] = gq[b * 4]; rows[o + 13] = gq[b * 4 + 1]; rows[o + 14] = gq[b * 4 + 2]; rows[o + 15] = gq[b * 4 + 3]
        }
    }

    /** Matrizes de repouso (identidade com escala/Z invertido), para desenhar o modelo antes de existir movimento. */
    fun restRows(rows: FloatArray) {
        java.util.Arrays.fill(rows, 0f)
        for (b in 0 until n) { val o = b * ROW; rows[o] = scale; rows[o + 5] = scale; rows[o + 10] = -scale; rows[o + 15] = 1f }
    }

    /** Só a pose (FK, IK, morphs de osso, append), sem skinning. Usado na exportação; depois leia com [local]. */
    fun evaluatePose(frame: Float) = pose(frame)

    /**
     * Transformação local do osso [b] em relação ao pai, em coordenadas MMD, após evaluatePose/evaluate.
     * o[0..2] = translação (já inclui o offset de repouso), o[3..6] = quaternion xyzw.
     */
    fun local(b: Int, o: FloatArray) {
        val p = m.bones[b].parent
        if (p !in 0 until n || p == b) {
            o[0] = gt[b * 3]; o[1] = gt[b * 3 + 1]; o[2] = gt[b * 3 + 2]
            for (c in 0..3) o[3 + c] = gq[b * 4 + c]
        } else {
            qrot(gq, p * 4, gt[b * 3] - gt[p * 3], gt[b * 3 + 1] - gt[p * 3 + 1], gt[b * 3 + 2] - gt[p * 3 + 2], true, o, 0)
            sQ[0] = -gq[p * 4]; sQ[1] = -gq[p * 4 + 1]; sQ[2] = -gq[p * 4 + 2]; sQ[3] = gq[p * 4 + 3]
            qmul(sQ, 0, gq, b * 4, o, 3)
        }
    }

    /** Pose em [frame]. Com movimento secundário ligado, avança a simulação (ou reaquece após um salto na timeline). */
    private fun pose(frame: Float) {
        syncSecondary()
        val sim = hasSec || physOn()
        if (!sim) { secLast = Float.NaN; secDt = 0f; phys?.reset(); poseCore(frame); return }
        if (secLast.isNaN() || frame < secLast - 1e-4f || frame - secLast > 4f) {
            java.util.Arrays.fill(secInit, false); phys?.reset()
            var f = max(0f, frame - 12f)
            secDt = 0f; poseCore(f)
            while (frame - f > 1e-3f) { val nf = min(f + 1f, frame); secDt = (nf - f) / 30f; poseCore(nf); f = nf }
            secLast = frame
            return
        }
        secDt = if (frame == secLast) 0f else (frame - secLast) / 30f
        poseCore(frame); secLast = frame
    }

    // ---------- movimento secundário (mola sobre a rotação global do osso) ----------
    private class SC(val k: Float, val c: Float, val inten: Float)
    private var secSrc: List<Secondary>? = null
    private var secBy: Array<SC?> = arrayOfNulls(n)
    private var hasSec = false
    private var secLast = Float.NaN
    private var secDt = 0f
    private val secS = FloatArray(n * 4); private val secW = FloatArray(n * 3); private val secInit = BooleanArray(n)
    private val tq = FloatArray(4); private val eq = FloatArray(4); private val rq = FloatArray(4)

    private fun syncSecondary() {
        val src = rig.secondary
        if (src === secSrc) return
        secSrc = src; secBy = arrayOfNulls(n); hasSec = false; secLast = Float.NaN
        java.util.Arrays.fill(secInit, false)
        for (g in src) {
            if (!g.enabled) continue
            val set = HashSet<Int>()
            for (nm in g.bones) boneIdx[nm]?.let { set.add(it) }
            for (b in set) {
                var depth = 0; var p = m.bones[b].parent
                while (p in 0 until n && depth < 64) { if (p in set) depth++; p = m.bones[p].parent }
                val k = g.stiffness.coerceIn(5f, 1000f) / (1f + g.delay.coerceIn(0f, 1f) * depth)
                secBy[b] = SC(k, 2f * g.damping.coerceIn(0f, 2f) * sqrt(k), g.intensity.coerceIn(0f, 1f))
                hasSec = true
            }
        }
    }

    private fun applySec(b: Int, sc: SC) {
        val p = m.bones[b].parent
        val hasP = p in 0 until n && p != b
        if (hasP) qmul(gq, p * 4, rot, b * 4, tq, 0) else System.arraycopy(rot, b * 4, tq, 0, 4)
        if (!secInit[b]) {
            System.arraycopy(tq, 0, secS, b * 4, 4)
            secW[b * 3] = 0f; secW[b * 3 + 1] = 0f; secW[b * 3 + 2] = 0f; secInit[b] = true
        } else if (secDt > 0f) {
            val ns = max(1, ceil(secDt * 240f).toInt()); val h = secDt / ns
            for (step in 0 until ns) {
                eq[0] = -secS[b * 4]; eq[1] = -secS[b * 4 + 1]; eq[2] = -secS[b * 4 + 2]; eq[3] = secS[b * 4 + 3]
                qmul(tq, 0, eq, 0, rq, 0)
                if (rq[3] < 0) for (c in 0..3) rq[c] = -rq[c]
                val sl = sqrt(rq[0] * rq[0] + rq[1] * rq[1] + rq[2] * rq[2])
                if (sl > 1e-6f) {
                    val ax = rq[0] / sl; val ay = rq[1] / sl; val az = rq[2] / sl
                    var ang = 2f * atan2(sl, rq[3])
                    if (ang > 1.2f) {
                        val ex = ang - 1.2f; val sn = sin(ex / 2)
                        eq[0] = ax * sn; eq[1] = ay * sn; eq[2] = az * sn; eq[3] = cos(ex / 2)
                        qmul(eq, 0, secS, b * 4, secS, b * 4); ang = 1.2f
                    }
                    val acc = sc.k * ang
                    secW[b * 3] += (acc * ax - sc.c * secW[b * 3]) * h
                    secW[b * 3 + 1] += (acc * ay - sc.c * secW[b * 3 + 1]) * h
                    secW[b * 3 + 2] += (acc * az - sc.c * secW[b * 3 + 2]) * h
                } else {
                    val f = max(0f, 1f - sc.c * h)
                    secW[b * 3] *= f; secW[b * 3 + 1] *= f; secW[b * 3 + 2] *= f
                }
                var wx = secW[b * 3]; var wy = secW[b * 3 + 1]; var wz = secW[b * 3 + 2]
                var wl = sqrt(wx * wx + wy * wy + wz * wz)
                if (wl > 30f) { val f = 30f / wl; wx *= f; wy *= f; wz *= f; wl = 30f; secW[b * 3] = wx; secW[b * 3 + 1] = wy; secW[b * 3 + 2] = wz }
                if (wl > 1e-6f) {
                    val a2 = wl * h; val sn = sin(a2 / 2)
                    eq[0] = wx / wl * sn; eq[1] = wy / wl * sn; eq[2] = wz / wl * sn; eq[3] = cos(a2 / 2)
                    qmul(eq, 0, secS, b * 4, secS, b * 4)
                    val l = sqrt(secS[b * 4] * secS[b * 4] + secS[b * 4 + 1] * secS[b * 4 + 1] + secS[b * 4 + 2] * secS[b * 4 + 2] + secS[b * 4 + 3] * secS[b * 4 + 3])
                    if (l > 1e-8f) for (c in 0..3) secS[b * 4 + c] /= l
                }
            }
        }
        // saída: mistura do alvo (T) com o osso atrasado (S), pelo peso de intensidade
        var dot = 0f
        for (c in 0..3) dot += tq[c] * secS[b * 4 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val v = tq[c] * (1 - sc.inten) + secS[b * 4 + c] * sg * sc.inten; rq[c] = v; len += v * v }
        len = sqrt(len)
        if (len < 1e-8f) return
        for (c in 0..3) rq[c] /= len
        if (hasP) { eq[0] = -gq[p * 4]; eq[1] = -gq[p * 4 + 1]; eq[2] = -gq[p * 4 + 2]; eq[3] = gq[p * 4 + 3]; qmul(eq, 0, rq, 0, rot, b * 4) }
        else System.arraycopy(rq, 0, rot, b * 4, 4)
    }


    // ---------- colisão do movimento secundário com os colisores do corpo (v1.35.1) ----------
    private val colPlan by lazy { try { studio.mmd.rig.BodyColliders.plan(m).colliders } catch (_: Throwable) { emptyList() } }
    /** Vetor de repouso do osso até a ponta (filho, tail, ou extrapolado do pai). */
    private val secTail: FloatArray by lazy {
        val t = FloatArray(n * 3); val hasKid = BooleanArray(n)
        val firstKid = IntArray(n) { -1 }
        for (i in 0 until n) { val pp = m.bones[i].parent; if (pp in 0 until n && pp != i && firstKid[pp] < 0) firstKid[pp] = i }
        for (b in 0 until n) {
            val bn = m.bones[b]
            val tb = if (bn.flags and 1 != 0) bn.tailBone else -1
            val kid = if (tb in 0 until n && tb != b) tb else firstKid[b]
            if (kid in 0 until n) { t[b * 3] = m.bones[kid].x - bn.x; t[b * 3 + 1] = m.bones[kid].y - bn.y; t[b * 3 + 2] = m.bones[kid].z - bn.z; hasKid[b] = true }
            else if (bn.flags and 1 == 0 && bn.tailOffset != null && bn.tailOffset.size >= 3) { t[b * 3] = bn.tailOffset[0]; t[b * 3 + 1] = bn.tailOffset[1]; t[b * 3 + 2] = bn.tailOffset[2]; hasKid[b] = true }
            else { val pp = bn.parent; if (pp in 0 until n && pp != b) { t[b * 3] = (bn.x - m.bones[pp].x) * 0.8f; t[b * 3 + 1] = (bn.y - m.bones[pp].y) * 0.8f; t[b * 3 + 2] = (bn.z - m.bones[pp].z) * 0.8f } }
        }
        t
    }
    private val cap = FloatArray(6); private val cv = FloatArray(3); private val cw = FloatArray(4)

    private fun secCollide() = colPlan.isNotEmpty() && rig.phys.collisions

    /** Pontas da cápsula [c] na pose atual (coordenadas MMD) em [cap]. */
    private fun capWorld(c: studio.mmd.rig.BodyCollider) {
        val cb = c.bone
        for (e in 0..1) {
            val pt = if (e == 0) c.a else c.b
            qrot(gq, cb * 4, pt[0] - bpos[cb * 3], pt[1] - bpos[cb * 3 + 1], pt[2] - bpos[cb * 3 + 2], false, cv, 0)
            cap[e * 3] = gt[cb * 3] + cv[0]; cap[e * 3 + 1] = gt[cb * 3 + 1] + cv[1]; cap[e * 3 + 2] = gt[cb * 3 + 2] + cv[2]
        }
    }

    /**
     * Se a ponta (ou o meio) do osso [b] entrou numa cápsula do corpo, gira o osso em torno da própria raiz até a ponta sair.
     * Só mexe na rotação local do osso secundário (a perna e a animação não mudam); sem estado, então é determinístico.
     */
    private fun secPush(b: Int) {
        val hx = gt[b * 3]; val hy = gt[b * 3 + 1]; val hz = gt[b * 3 + 2]
        qrot(gq, b * 4, secTail[b * 3], secTail[b * 3 + 1], secTail[b * 3 + 2], false, cv, 0)
        val vx = cv[0]; val vy = cv[1]; val vz = cv[2]
        val len = sqrt(vx * vx + vy * vy + vz * vz)
        if (len < 1e-5f) return
        var bestPen = 0f; var bdx = 0f; var bdy = 0f; var bdz = 0f; var bt = 1f
        for (c in colPlan) {
            if (c.bone !in 0 until n || c.bone == b) continue
            capWorld(c)
            val ax = cap[0]; val ay = cap[1]; val az = cap[2]
            val sx = cap[3] - ax; val sy = cap[4] - ay; val sz = cap[5] - az
            val sl = sx * sx + sy * sy + sz * sz
            val r = c.radius * (rig.phys.colliderScale[c.key] ?: 1f).coerceIn(studio.mmd.rig.PhysConfig.SCALE_MIN, studio.mmd.rig.PhysConfig.SCALE_MAX) + len * 0.02f
            for (t in floatArrayOf(0.5f, 1f)) {
                val px = hx + vx * t; val py = hy + vy * t; val pz = hz + vz * t
                var u = if (sl > 1e-9f) ((px - ax) * sx + (py - ay) * sy + (pz - az) * sz) / sl else 0f
                u = u.coerceIn(0f, 1f)
                val dx = px - (ax + sx * u); val dy = py - (ay + sy * u); val dz = pz - (az + sz * u)
                val d = sqrt(dx * dx + dy * dy + dz * dz)
                val pen = r - d
                if (pen > bestPen && d > 1e-5f) { bestPen = pen; bdx = dx / d; bdy = dy / d; bdz = dz / d; bt = t }
            }
        }
        if (bestPen <= 0f) return
        // ponto de teste empurrado para fora; novo vetor raiz→ponta mantém o comprimento
        val tx = vx * bt + bdx * bestPen; val ty = vy * bt + bdy * bestPen; val tz = vz * bt + bdz * bestPen
        val tl = sqrt(tx * tx + ty * ty + tz * tz)
        if (tl < 1e-6f) return
        val ux = vx * bt; val uy = vy * bt; val uz = vz * bt; val ul = sqrt(ux * ux + uy * uy + uz * uz)
        if (ul < 1e-6f) return
        // arco mais curto de u para t (limitado a ~1 rad)
        var nx = uy * tz - uz * ty; var ny = uz * tx - ux * tz; var nz = ux * ty - uy * tx
        val dot = (ux * tx + uy * ty + uz * tz) / (ul * tl)
        val nl = sqrt(nx * nx + ny * ny + nz * nz)
        if (nl < 1e-7f) return
        nx /= nl; ny /= nl; nz /= nl
        val ang = min(acos(dot.coerceIn(-1f, 1f)), 1.0f)
        val sn = sin(ang / 2)
        cw[0] = nx * sn; cw[1] = ny * sn; cw[2] = nz * sn; cw[3] = cos(ang / 2)
        qmul(cw, 0, gq, b * 4, eq, 0)                       // nova rotação global do osso
        val p = m.bones[b].parent
        if (p in 0 until n && p != b) { rq[0] = -gq[p * 4]; rq[1] = -gq[p * 4 + 1]; rq[2] = -gq[p * 4 + 2]; rq[3] = gq[p * 4 + 3]; qmul(rq, 0, eq, 0, rot, b * 4) }
        else System.arraycopy(eq, 0, rot, b * 4, 4)
    }

    // ---------- física real (corpos rígidos + juntas do PMX) ----------
    private val phys: studio.mmd.rig.PhysEngine? = try { studio.mmd.rig.PhysEngine.create(m) } catch (e: Throwable) { null }
    private fun physOn() = phys != null && rig.phys.enabled

    /** Dispara explicitamente um morph PMX de impulso, inclusive quando referenciado por grupo/flip.
     * A chamada é orientada a evento: não ocorre em cada redraw, evitando acumular força ao redesenhar o mesmo frame.
     * Retorna a quantidade de registros aceitos pelo motor físico.
     */
    fun fireImpulseMorph(morphIndex: Int, weight: Float = 1f): Int {
        val engine = phys ?: return 0
        if (!rig.phys.enabled || !weight.isFinite() || weight == 0f) return 0
        var applied = 0
        val sink = object : MorphSink {
            override fun leaf(index: Int, resolvedWeight: Float) {
                applied += impulseDispatcher.dispatchLeaf(index, resolvedWeight) { entry, w ->
                    engine.applyImpulse(entry.rigidBody, entry.local, entry.velocity, entry.torque, w)
                }
            }
        }
        resolver.resolve(morphIndex, weight, sink)
        return applied
    }

    // v1.14.0: cache da física (bake). Com cache válido a simulação não roda: a pose vem do cache, igual em qualquer taxa de prévia.
    /** Falso no próprio bake (ele precisa simular de verdade). */
    @Volatile var useCache = true
    private var curFrame = 0f
    private var usedCache = false
    /** Reinicia o estado dinâmico quando o perfil de física/secundário deste personagem muda. */
    fun resetDynamics() {
        secLast = Float.NaN
        secDt = 0f
        java.util.Arrays.fill(secInit, false)
        phys?.reset()
        usedCache = false
    }
    private var sigRef: VmdMotion? = null; private var sigVal = 0L
    private val cDriven = BooleanArray(n); private val cFull = BooleanArray(n)
    private val cQ = FloatArray(n * 4); private val cT = FloatArray(n * 3)

    /** Chave do estado que a física depende (animação, configuração, restrições, movimento secundário). */
    fun physKey(): Long {
        val mo = motion
        if (mo !== sigRef) { sigRef = mo; sigVal = studio.mmd.rig.PhysBake.signature(mo) }
        return studio.mmd.rig.PhysBake.combine(sigVal, rig.phys, rig.list, rig.secondary)
    }
    /** Ossos controlados pela física (null se o modelo não tem física). */
    fun physDrivenBones(): IntArray? { val e = phys ?: return null; val l = (0 until n).filter { e.driven[it] }; return if (l.isEmpty()) null else l.toIntArray() }
    fun physFullFlags(bones: IntArray): BooleanArray { val e = phys; return BooleanArray(bones.size) { e != null && e.full[bones[it]] } }
    /** Copia a pose global (q 4 + t 3) dos [bones] para [out] a partir de [off]. */
    fun copyDriven(bones: IntArray, out: FloatArray, off: Int) {
        for (k in bones.indices) { val b = bones[k]; val o = off + k * 7
            for (c in 0..3) out[o + c] = gq[b * 4 + c]
            for (c in 0..2) out[o + 4 + c] = gt[b * 3 + c] }
    }

    private fun cacheFor(): studio.mmd.rig.PhysCache? {
        if (!useCache) return null
        val c = rig.physCache ?: return null
        if (c.model !== m || c.key != physKey()) return null
        if (curFrame > c.frames - 1 + 0.5f) return null // além do que foi assado: simula ao vivo
        return c
    }

    private fun fillFromCache(c: studio.mmd.rig.PhysCache) {
        java.util.Arrays.fill(cDriven, false)
        val f = curFrame.coerceIn(0f, (c.frames - 1).toFloat())
        val f0 = floor(f).toInt(); val f1 = min(f0 + 1, c.frames - 1); val t = f - f0
        val per = c.stride
        for (k in c.bones.indices) {
            val b = c.bones[k]; val a = f0 * per + k * 7; val d = f1 * per + k * 7
            var dot = 0f; for (i in 0..3) dot += c.data[a + i] * c.data[d + i]
            val sg = if (dot < 0f) -1f else 1f
            var len = 0f
            for (i in 0..3) { val v = c.data[a + i] * (1 - t) + c.data[d + i] * sg * t; cQ[b * 4 + i] = v; len += v * v }
            len = sqrt(len); if (len < 1e-8f) { cQ[b * 4] = 0f; cQ[b * 4 + 1] = 0f; cQ[b * 4 + 2] = 0f; cQ[b * 4 + 3] = 1f } else for (i in 0..3) cQ[b * 4 + i] /= len
            for (i in 0..2) cT[b * 3 + i] = c.data[a + 4 + i] * (1 - t) + c.data[d + 4 + i] * t
            cDriven[b] = true; cFull[b] = c.full[k]
        }
    }

    private fun applyDriven(driven: BooleanArray, full: BooleanArray, oq: FloatArray, ot: FloatArray) {
        for (b in topo) {
            global(b, true)
            if (driven[b]) {
                System.arraycopy(oq, b * 4, gq, b * 4, 4)
                if (full[b]) System.arraycopy(ot, b * 3, gt, b * 3, 3)
            }
        }
    }

    private fun physStep() {
        val e = phys ?: return
        val c = cacheFor()
        if (c != null) { usedCache = true; fillFromCache(c); applyDriven(cDriven, cFull, cQ, cT); return }
        if (usedCache) { e.reset(); usedCache = false } // saiu do trecho assado: recomeça a simulação a partir da pose atual
        e.step(secDt, gq, gt, rig.phys)
        applyDriven(e.driven, e.full, e.outQ, e.outT)
    }

    private fun poseCore(frame: Float) {
        curFrame = frame
        for (b in 0 until n) {
            rot[b * 4] = 0f; rot[b * 4 + 1] = 0f; rot[b * 4 + 2] = 0f; rot[b * 4 + 3] = 1f
            tr[b * 3] = 0f; tr[b * 3 + 1] = 0f; tr[b * 3 + 2] = 0f
            tracks[b]?.let { sampleBone(it, frame, b) }
        }
        System.arraycopy(m.positions, 0, work, 0, work.size)
        vertexMorphed = false; matMorph.reset()
        uvMorphed = false; if (hasUvMorph) System.arraycopy(m.uvs, 0, uvWork, 0, uvWork.size)
        additionalUvMorphed = false; if (hasAdditionalUvMorph) System.arraycopy(m.addUvs, 0, additionalUvWork, 0, additionalUvWork.size)
        for (i in m.morphs.indices) { val t = mTracks[i] ?: continue; val w = sampleMorph(t, frame); if (w != 0f) applyMorph(i, w) }
        for (b in topo) global(b, false)
        for (b in 0 until n) m.bones[b].ik?.let { val t = ikTracks[b]; if (t == null || t.at(frame)) solveIk(b, it) }
        syncConstraints()
        if (hasCons || hasSec) { for (b in topo) { consBy[b]?.let { applyCons(b, it) }; secBy[b]?.let { applySec(b, it) }; global(b, true) } }
        else for (b in topo) global(b, true)
        // v1.35.1: a saia (ossos secundários) não atravessa quadril/pernas; 2ª passada com as pernas já finais
        if (hasSec && rig.phys.bodyColliders && secCollide()) for (b in topo) { if (secBy[b] != null) secPush(b); global(b, true) }
        if (physOn()) physStep()
    }

    // ---------- Action Constraints (rig) ----------
    private class CC(val b: Int, val type: Int, val ti: Int, val axis: Int, val w: Float, val mn: List<Float>, val mx: List<Float>)
    private var consSrc: List<Constraint>? = null
    private var consBy: Array<ArrayList<CC>?> = arrayOfNulls(n)
    private var hasCons = false
    private val boneIdx: Map<String, Int> by lazy { HashMap<String, Int>().also { mp -> for (i in 0 until n) mp.putIfAbsent(m.bones[i].name, i) } }
    private val cq = FloatArray(4)

    /** Recompila a lista de restrições (nomes → índices) quando ela muda. */
    private fun syncConstraints() {
        val src = rig.list
        if (src === consSrc) return
        consSrc = src
        consBy = arrayOfNulls(n); hasCons = false
        for (c in src) {
            if (!c.enabled) continue
            val b = boneIdx[c.bone] ?: continue
            val needT = c.type == CType.LOOK_AT || c.type == CType.COPY_ROT || c.type == CType.COPY_POS
            val ti = if (needT) (boneIdx[c.target] ?: continue) else -1
            if (ti == b) continue
            (consBy[b] ?: ArrayList<CC>().also { consBy[b] = it }).add(CC(b, c.type, ti, c.axis, c.weight.coerceIn(0f, 1f), c.min, c.max))
            hasCons = true
        }
    }

    /** nlerp de rot[b] em direção a q (peso w), caminho mais curto. */
    private fun blendRot(b: Int, q: FloatArray, w: Float) {
        var dot = 0f
        for (c in 0..3) dot += rot[b * 4 + c] * q[c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val v = rot[b * 4 + c] * (1 - w) + q[c] * sg * w; cq[c] = v; len += v * v }
        len = sqrt(len)
        if (len < 1e-8f) return
        for (c in 0..3) rot[b * 4 + c] = cq[c] / len
    }

    private fun applyCons(b: Int, list: List<CC>) {
        val bone = m.bones[b]
        for (c in list) when (c.type) {
            CType.LIMIT_ROT -> {
                val e = Euler.euler(floatArrayOf(rot[b * 4], rot[b * 4 + 1], rot[b * 4 + 2], rot[b * 4 + 3]))
                var ch = false
                for (k in 0..2) {
                    val lo = min(c.mn[k], c.mx[k]); val hi = max(c.mn[k], c.mx[k])
                    val v = e[k].coerceIn(lo, hi); if (v != e[k]) { e[k] = v; ch = true }
                }
                if (ch) { val q = Euler.quat(e[0], e[1], e[2]); for (k in 0..3) rot[b * 4 + k] = q[k] }
            }
            CType.LIMIT_POS -> for (k in 0..2) {
                val lo = min(c.mn[k], c.mx[k]); val hi = max(c.mn[k], c.mx[k])
                tr[b * 3 + k] = tr[b * 3 + k].coerceIn(lo, hi)
            }
            CType.COPY_ROT -> blendRot(b, floatArrayOf(rot[c.ti * 4], rot[c.ti * 4 + 1], rot[c.ti * 4 + 2], rot[c.ti * 4 + 3]), c.w)
            CType.COPY_POS -> for (k in 0..2) tr[b * 3 + k] += (tr[c.ti * 3 + k] - tr[b * 3 + k]) * c.w
            CType.LOOK_AT -> {
                val p = bone.parent
                // posição global atual do osso (o pai já foi calculado nesta passada)
                val px: Float; val py: Float; val pz: Float
                if (p !in 0 until n || p == b) { px = bone.x + tr[b * 3]; py = bone.y + tr[b * 3 + 1]; pz = bone.z + tr[b * 3 + 2] }
                else {
                    qrot(gq, p * 4, bone.x - bpos[p * 3] + tr[b * 3], bone.y - bpos[p * 3 + 1] + tr[b * 3 + 1], bone.z - bpos[p * 3 + 2] + tr[b * 3 + 2], false, v1, 0)
                    px = gt[p * 3] + v1[0]; py = gt[p * 3 + 1] + v1[1]; pz = gt[p * 3 + 2] + v1[2]
                }
                val dx = gt[c.ti * 3] - px; val dy = gt[c.ti * 3 + 1] - py; val dz = gt[c.ti * 3 + 2] - pz
                if (p !in 0 until n || p == b) { v2[0] = dx; v2[1] = dy; v2[2] = dz } else qrot(gq, p * 4, dx, dy, dz, true, v2, 0)
                val dl = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
                if (dl < 1e-6f) continue
                val tx = v2[0] / dl; val ty = v2[1] / dl; val tz = v2[2] / dl
                val ax = when (c.axis) { 0 -> 1f; 1 -> -1f; else -> 0f }
                val ay = when (c.axis) { 2 -> 1f; 3 -> -1f; else -> 0f }
                val az = when (c.axis) { 4 -> 1f; 5 -> -1f; else -> 0f }
                // arco mais curto de (ax,ay,az) até (tx,ty,tz)
                val d = (ax * tx + ay * ty + az * tz).coerceIn(-1f, 1f)
                var qx = ay * tz - az * ty; var qy = az * tx - ax * tz; var qz = ax * ty - ay * tx
                var qw = 1f + d
                if (qw < 1e-6f) { // vetores opostos: gira 180° em torno de um eixo perpendicular
                    if (abs(ax) > 0.5f) { qx = 0f; qy = 1f; qz = 0f } else { qx = 1f; qy = 0f; qz = 0f }
                    qw = 0f
                }
                val ql = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
                sQ[0] = qx / ql; sQ[1] = qy / ql; sQ[2] = qz / ql; sQ[3] = qw / ql
                blendRot(b, sQ, c.w)
            }
        }
    }

    private fun buildMatrices() {
        for (b in 0 until n) {
            val x = gq[b * 4]; val y = gq[b * 4 + 1]; val z = gq[b * 4 + 2]; val w = gq[b * 4 + 3]
            val o = b * 12
            mat[o] = 1 - 2 * (y * y + z * z); mat[o + 1] = 2 * (x * y - z * w); mat[o + 2] = 2 * (x * z + y * w)
            mat[o + 3] = 2 * (x * y + z * w); mat[o + 4] = 1 - 2 * (x * x + z * z); mat[o + 5] = 2 * (y * z - x * w)
            mat[o + 6] = 2 * (x * z - y * w); mat[o + 7] = 2 * (y * z + x * w); mat[o + 8] = 1 - 2 * (x * x + y * y)
            val px = bpos[b * 3]; val py = bpos[b * 3 + 1]; val pz = bpos[b * 3 + 2]
            mat[o + 9] = gt[b * 3] - (mat[o] * px + mat[o + 1] * py + mat[o + 2] * pz)
            mat[o + 10] = gt[b * 3 + 1] - (mat[o + 3] * px + mat[o + 4] * py + mat[o + 5] * pz)
            mat[o + 11] = gt[b * 3 + 2] - (mat[o + 6] * px + mat[o + 7] * py + mat[o + 8] * pz)
        }
    }

    private fun skin(out: FloatArray) {
        val vc = m.vertexCount
        val parts = SkinPool.threads
        if (parts <= 1 || vc < 20000) { skinRange(out, 0, vc); return }
        val step = (vc + parts - 1) / parts
        val futs = ArrayList<java.util.concurrent.Future<*>>()
        for (p in 1 until parts) {
            val s = p * step; val e = minOf(vc, s + step)
            if (s < e) futs.add(SkinPool.ex.submit(Runnable { skinRange(out, s, e) }))
        }
        skinRange(out, 0, minOf(vc, step))
        for (f in futs) f.get()
    }

    private fun skinRange(out: FloatArray, from: Int, to: Int) {
        val bi = m.boneIndices; val bw = m.boneWeights; val nr = m.normals
        for (i in from until to) {
            val x = work[i * 3]; val y = work[i * 3 + 1]; val z = work[i * 3 + 2]
            val nx = nr[i * 3]; val ny = nr[i * 3 + 1]; val nz = nr[i * 3 + 2]
            var ox = 0f; var oy = 0f; var oz = 0f; var onx = 0f; var ony = 0f; var onz = 0f; var tw = 0f
            for (k in 0..3) {
                val b = bi[i * 4 + k]; val w = bw[i * 4 + k]
                if (b !in 0 until n || w == 0f) continue
                val o = b * 12; tw += w
                ox += w * (mat[o] * x + mat[o + 1] * y + mat[o + 2] * z + mat[o + 9])
                oy += w * (mat[o + 3] * x + mat[o + 4] * y + mat[o + 5] * z + mat[o + 10])
                oz += w * (mat[o + 6] * x + mat[o + 7] * y + mat[o + 8] * z + mat[o + 11])
                onx += w * (mat[o] * nx + mat[o + 1] * ny + mat[o + 2] * nz)
                ony += w * (mat[o + 3] * nx + mat[o + 4] * ny + mat[o + 5] * nz)
                onz += w * (mat[o + 6] * nx + mat[o + 7] * ny + mat[o + 8] * nz)
            }
            if (tw == 0f) { ox = x; oy = y; oz = z; onx = nx; ony = ny; onz = nz }
            val p = i * 8
            out[p] = ox * scale; out[p + 1] = oy * scale; out[p + 2] = -oz * scale
            out[p + 3] = onx; out[p + 4] = ony; out[p + 5] = -onz
        }
    }
}
