package studio.mmd.mmd

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * v2.35.0 — Bake de interpolação e curva automática (MMD oficial: "補間曲線" + conversão para keys por quadro).
 *
 * Kotlin puro e imutável. A avaliação da curva é idêntica à do Animator (Bézier 0..127 resolvida por bisseção em x,
 * a curva de cada segmento fica no key de chegada, quatro canais: X, Y, Z, rotação).
 */
object InterpCurve {
    /** Mesma fórmula do Animator: devolve o progresso (0..1) do canal para o tempo normalizado [s]. */
    fun eval(x1: Int, y1: Int, x2: Int, y2: Int, s: Float): Float {
        if (!s.isFinite()) return 0f
        val sc = s.coerceIn(0f, 1f)
        val ax = (x1 and 0xFF) / 127f; val ay = (y1 and 0xFF) / 127f
        val bx = (x2 and 0xFF) / 127f; val by = (y2 and 0xFF) / 127f
        if (ax == ay && bx == by) return sc
        var lo = 0f; var hi = 1f; var t = sc
        for (k in 0 until 18) {
            t = (lo + hi) / 2
            val u = 1 - t
            val x = 3 * u * u * t * ax + 3 * u * t * t * bx + t * t * t
            if (x < sc) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * ay + 3 * u * t * t * by + t * t * t
    }

    fun eval(c: CurvePreset, s: Float) = eval(c.x1, c.y1, c.x2, c.y2, s)

    /** Valor do canal [ch] (0..3) da curva guardada no key [k] da trilha. */
    fun evalKey(ip: ByteArray, k: Int, ch: Int, s: Float): Float {
        val o = k * 16
        if (o < 0 || o + 15 >= ip.size) return s.coerceIn(0f, 1f)
        return eval(ip[o + ch].toInt() and 0xFF, ip[o + 4 + ch].toInt() and 0xFF, ip[o + 8 + ch].toInt() and 0xFF, ip[o + 12 + ch].toInt() and 0xFF, s)
    }

    /**
     * Ajusta uma Bézier (x1,y1,x2,y2 em 0..127) a amostras de progresso. [s] são tempos normalizados crescentes em (0,1) e
     * [p] o progresso desejado de cada um (0 = início, 1 = fim). Devolve a curva e o erro máximo (em unidade de progresso).
     * Busca: melhor preset como semente + descida por coordenadas com passos 16, 8, 4, 2, 1.
     */
    fun fit(s: FloatArray, p: FloatArray, accept: Float = 0.004f): Pair<IntArray, Float> {
        val n = minOf(s.size, p.size)
        var best = intArrayOf(20, 20, 107, 107)
        var bestErr = errorOf(best, s, p, n)
        for (c in CurvePreset.values()) {
            val cand = intArrayOf(c.x1, c.y1, c.x2, c.y2)
            val e = errorOf(cand, s, p, n)
            if (e < bestErr) { bestErr = e; best = cand }
        }
        var r = descend(best, bestErr, s, p, n)
        best = r.first; bestErr = r.second
        if (bestErr > accept) {
            // Grade grossa 5^4 + descida a partir das melhores sementes, para fugir de mínimos locais.
            val vals = intArrayOf(0, 32, 64, 96, 127)
            val seeds = ArrayList<Pair<IntArray, Float>>()
            for (a in vals) for (b in vals) for (c in vals) for (d in vals) {
                val cand = intArrayOf(a, b, c, d)
                seeds.add(cand to errorOf(cand, s, p, n))
            }
            seeds.sortBy { it.second }
            for (k in 0 until minOf(4, seeds.size)) {
                r = descend(seeds[k].first, seeds[k].second, s, p, n)
                if (r.second < bestErr) { best = r.first; bestErr = r.second }
                if (bestErr <= accept) break
            }
        }
        return best to bestErr
    }

    private fun descend(start: IntArray, startErr: Float, s: FloatArray, p: FloatArray, n: Int): Pair<IntArray, Float> {
        var best = start; var bestErr = startErr
        var step = 16
        while (step >= 1) {
            var improved = true
            var guard = 0
            while (improved && guard++ < 40) {
                improved = false
                for (i in 0..3) for (d in intArrayOf(-step, step)) {
                    val cand = best.copyOf()
                    cand[i] = (cand[i] + d).coerceIn(0, 127)
                    if (cand[i] == best[i]) continue
                    val e = errorOf(cand, s, p, n)
                    if (e < bestErr - 1e-6f) { bestErr = e; best = cand; improved = true }
                }
            }
            step /= 2
        }
        return best to bestErr
    }

    private fun errorOf(c: IntArray, s: FloatArray, p: FloatArray, n: Int): Float {
        var worst = 0f
        for (i in 0 until n) {
            val d = abs(eval(c[0], c[1], c[2], c[3], s[i]) - p[i])
            if (d > worst) worst = d
        }
        return worst
    }
}

object MotionBake {
    private val LINEAR = byteArrayOf(20, 20, 20, 20, 20, 20, 20, 20, 107, 107, 107, 107, 107, 107, 107, 107)

    private fun find(frames: IntArray, f: Float): Int {
        var lo = 0; var hi = frames.size - 1; var r = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (frames[mid] <= f) { r = mid; lo = mid + 1 } else hi = mid - 1 }
        return r
    }

    /** Pose (7 floats: xyz + quat xyzw) da trilha no quadro [f], igual à do Animator. Trilha vazia devolve a identidade. */
    fun sample(t: VmdTrack, f: Float): FloatArray {
        val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
        val out = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)
        if (n == 0 || !f.isFinite()) return out
        val i = find(t.frames.copyOf(n), f)
        if (i < 0 || i == n - 1) {
            val a = (if (i < 0) 0 else i) * 7
            for (c in 0..6) out[c] = t.v[a + c]
            return out
        }
        val a = i * 7; val b = (i + 1) * 7
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i]).toFloat()
        for (c in 0..2) out[c] = t.v[a + c] + (t.v[b + c] - t.v[a + c]) * InterpCurve.evalKey(t.ip, i + 1, c, s)
        val sr = InterpCurve.evalKey(t.ip, i + 1, 3, s)
        var dot = 0f
        for (c in 0..3) dot += t.v[a + 3 + c] * t.v[b + 3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val q = t.v[a + 3 + c] * (1 - sr) + t.v[b + 3 + c] * sg * sr; out[3 + c] = q; len += q * q }
        len = sqrt(len)
        if (len > 1e-8f) for (c in 3..6) out[c] /= len
        return out
    }

    fun sampleMorph(t: VmdMorphTrack, f: Float): Float {
        val n = minOf(t.frames.size, t.w.size)
        if (n == 0 || !f.isFinite()) return 0f
        val i = find(t.frames.copyOf(n), f)
        if (i < 0) return t.w[0]
        if (i == n - 1) return t.w[i]
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i]).toFloat()
        return t.w[i] + (t.w[i + 1] - t.w[i]) * s
    }

    /**
     * Converte o trecho [from, to] em um key a cada [step] quadros (curva linear em cada um), preservando fora do trecho.
     * Os extremos do trecho sempre ganham key. Depois do bake, a animação é visualmente a mesma, mas sem depender de Bézier.
     */
    fun bakeTrack(t: VmdTrack, from: Int, to: Int, step: Int = 1): VmdTrack {
        val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
        if (n < 2 || to <= from) return t
        val st = step.coerceAtLeast(1)
        val frames = ArrayList<Int>(); val v = ArrayList<FloatArray>(); val ip = ArrayList<ByteArray>()
        for (i in 0 until n) if (t.frames[i] < from) { frames.add(t.frames[i]); v.add(t.v.copyOfRange(i * 7, i * 7 + 7)); ip.add(t.ip.copyOfRange(i * 16, i * 16 + 16)) }
        var f = from
        while (true) {
            val pose = sample(t, f.toFloat())
            frames.add(f); v.add(pose); ip.add(LINEAR.copyOf())
            if (f >= to) break
            f = minOf(f + st, to)
        }
        for (i in 0 until n) if (t.frames[i] > to) { frames.add(t.frames[i]); v.add(t.v.copyOfRange(i * 7, i * 7 + 7)); ip.add(t.ip.copyOfRange(i * 16, i * 16 + 16)) }
        return pack(frames, v, ip)
    }

    fun bakeMorph(t: VmdMorphTrack, from: Int, to: Int, step: Int = 1): VmdMorphTrack {
        val n = minOf(t.frames.size, t.w.size)
        if (n < 2 || to <= from) return t
        val st = step.coerceAtLeast(1)
        val fr = ArrayList<Int>(); val w = ArrayList<Float>()
        for (i in 0 until n) if (t.frames[i] < from) { fr.add(t.frames[i]); w.add(t.w[i]) }
        var f = from
        while (true) { fr.add(f); w.add(sampleMorph(t, f.toFloat())); if (f >= to) break; f = minOf(f + st, to) }
        for (i in 0 until n) if (t.frames[i] > to) { fr.add(t.frames[i]); w.add(t.w[i]) }
        return VmdMorphTrack(fr.toIntArray(), w.toFloatArray())
    }

    /** Bake de todas as trilhas. Devolve o movimento novo e quantos keys foram adicionados (pode ser negativo). */
    fun bakeMotion(m: VmdMotion, from: Int, to: Int, step: Int = 1): Pair<VmdMotion, Int> {
        var before = 0; var after = 0
        val bones = m.bones.mapValues { before += it.value.frames.size; val r = bakeTrack(it.value, from, to, step); after += r.frames.size; r }
        val morphs = m.morphs.mapValues { before += it.value.frames.size; val r = bakeMorph(it.value, from, to, step); after += r.frames.size; r }
        var mx = m.maxFrame
        for (t in bones.values) if (t.frames.isNotEmpty()) mx = maxOf(mx, t.frames[t.frames.size - 1])
        return VmdMotion(m.modelName, bones, morphs, mx, m.warnings, m.extras) to (after - before)
    }

    // ---------------------------------------------------------------- curva automática

    class AutoCurveResult(val track: VmdTrack, val removed: Int, val maxPositionError: Float, val maxAngleErrorDeg: Float)

    /**
     * Inverso do bake: percorre keys densos e funde trechos em segmentos com uma Bézier por canal quando a curva
     * reproduz os keys removidos dentro de [positionTol] (unidades do modelo) e [angleTolDeg]. Primeiro e último ficam.
     */
    fun autoCurve(t: VmdTrack, positionTol: Float = 0.02f, angleTolDeg: Float = 0.75f, maxSpan: Int = 120): AutoCurveResult {
        val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
        if (n < 3) return AutoCurveResult(t, 0, 0f, 0f)
        val pTol = if (positionTol.isFinite() && positionTol > 1e-6f) positionTol else 1e-6f
        val aTol = if (angleTolDeg.isFinite() && angleTolDeg > 1e-4f) angleTolDeg else 1e-4f
        val keepFrames = ArrayList<Int>(); val keepV = ArrayList<FloatArray>(); val keepIp = ArrayList<ByteArray>()
        keepFrames.add(t.frames[0]); keepV.add(t.v.copyOfRange(0, 7)); keepIp.add(LINEAR.copyOf())
        var maxP = 0f; var maxA = 0f
        var i = 0
        while (i < n - 1) {
            var bestJ = i + 1
            var bestIp: ByteArray = t.ip.copyOfRange((i + 1) * 16, (i + 1) * 16 + 16)
            var bestP = 0f; var bestA = 0f
            var j = i + 2
            while (j < n && j - i <= maxSpan) {
                val r = fitSegment(t, i, j, pTol, aTol) ?: break
                bestJ = j; bestIp = r.ip; bestP = r.posErr; bestA = r.angErr
                j++
            }
            keepFrames.add(t.frames[bestJ]); keepV.add(t.v.copyOfRange(bestJ * 7, bestJ * 7 + 7)); keepIp.add(bestIp)
            if (bestP > maxP) maxP = bestP
            if (bestA > maxA) maxA = bestA
            i = bestJ
        }
        return AutoCurveResult(pack(keepFrames, keepV, keepIp), n - keepFrames.size, maxP, maxA)
    }

    private class Seg(val ip: ByteArray, val posErr: Float, val angErr: Float)

    private fun fitSegment(t: VmdTrack, i: Int, j: Int, pTol: Float, aTol: Float): Seg? {
        val f0 = t.frames[i]; val f1 = t.frames[j]
        if (f1 <= f0) return null
        val m = j - i - 1
        val s = FloatArray(m) { (t.frames[i + 1 + it] - f0).toFloat() / (f1 - f0) }
        val ip = ByteArray(16)
        var posErr = 0f
        for (c in 0..2) {
            val a = t.v[i * 7 + c]; val b = t.v[j * 7 + c]; val d = b - a
            val curve: IntArray
            if (abs(d) < 1e-6f) {
                curve = intArrayOf(20, 20, 107, 107)
                for (k in 0 until m) { val e = abs(t.v[(i + 1 + k) * 7 + c] - a); if (e > pTol) return null; if (e > posErr) posErr = e }
            } else {
                val p = FloatArray(m) { (t.v[(i + 1 + it) * 7 + c] - a) / d }
                val fit = InterpCurve.fit(s, p)
                curve = fit.first
                for (k in 0 until m) {
                    val e = abs(t.v[(i + 1 + k) * 7 + c] - (a + d * InterpCurve.eval(curve[0], curve[1], curve[2], curve[3], s[k])))
                    if (e > pTol) return null
                    if (e > posErr) posErr = e
                }
            }
            setCurve(ip, c, curve)
        }
        val q0 = t.v.copyOfRange(i * 7 + 3, i * 7 + 7)
        var q1 = t.v.copyOfRange(j * 7 + 3, j * 7 + 7)
        if (dot4(q0, q1) < 0f) q1 = FloatArray(4) { -q1[it] }
        val total = angleBetween(q0, q1)
        val curve: IntArray
        var angErr = 0f
        if (total < 1e-4f) {
            curve = intArrayOf(20, 20, 107, 107)
            for (k in 0 until m) { val e = angleBetween(q0, t.v.copyOfRange((i + 1 + k) * 7 + 3, (i + 1 + k) * 7 + 7)); if (e > aTol) return null; if (e > angErr) angErr = e }
        } else {
            val p = FloatArray(m) { k -> nlerpParam(q0, q1, alignTo(q0, t.v.copyOfRange((i + 1 + k) * 7 + 3, (i + 1 + k) * 7 + 7)), total) }
            curve = InterpCurve.fit(s, p).first
            for (k in 0 until m) {
                val w = InterpCurve.eval(curve[0], curve[1], curve[2], curve[3], s[k])
                val qm = nlerp(q0, q1, w)
                val e = angleBetween(qm, t.v.copyOfRange((i + 1 + k) * 7 + 3, (i + 1 + k) * 7 + 7))
                if (e > aTol) return null
                if (e > angErr) angErr = e
            }
        }
        setCurve(ip, 3, curve)
        return Seg(ip, posErr, angErr)
    }

    private fun setCurve(ip: ByteArray, c: Int, v: IntArray) {
        ip[c] = v[0].toByte(); ip[4 + c] = v[1].toByte(); ip[8 + c] = v[2].toByte(); ip[12 + c] = v[3].toByte()
    }

    private fun dot4(a: FloatArray, b: FloatArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]
    private fun alignTo(ref: FloatArray, q: FloatArray) = if (dot4(ref, q) < 0f) FloatArray(4) { -q[it] } else q

    /** Ângulo (graus) da rotação relativa entre dois quaternions unitários. */
    fun angleBetween(a: FloatArray, b: FloatArray): Float {
        val d = abs(dot4(a, b)).coerceIn(0f, 1f)
        return (2.0 * acos(d.toDouble()) * 180.0 / Math.PI).toFloat()
    }

    /** Parâmetro w tal que nlerp(q0,q1,w) fica mais próximo de [q]; o Animator interpola por lerp normalizado, não por slerp. */
    private fun nlerpParam(q0: FloatArray, q1: FloatArray, q: FloatArray, totalDeg: Float): Float {
        val c = dot4(q0, q1)
        val a = dot4(q, q0); val b = dot4(q, q1)
        if (totalDeg < 0.5f || 1f - c < 1e-6f || a + b < 1e-6f) return (angleBetween(q0, q) / totalDeg).coerceIn(0f, 1f)
        val lambda = (1f + c) / (a + b)
        return (((lambda * (b - a)) / (1f - c) + 1f) / 2f).coerceIn(0f, 1f)
    }

    private fun nlerp(a: FloatArray, b: FloatArray, t: Float): FloatArray {
        val o = FloatArray(4) { a[it] * (1 - t) + b[it] * t }
        val l = sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2] + o[3] * o[3])
        if (l > 1e-8f) for (c in 0..3) o[c] /= l
        return o
    }

    private fun pack(frames: List<Int>, v: List<FloatArray>, ip: List<ByteArray>): VmdTrack {
        val order = frames.indices.sortedBy { frames[it] }
        val fr = ArrayList<Int>(); val vv = ArrayList<FloatArray>(); val ii = ArrayList<ByteArray>()
        for (o in order) {
            if (fr.isNotEmpty() && fr[fr.size - 1] == frames[o]) { vv[vv.size - 1] = v[o]; ii[ii.size - 1] = ip[o] }
            else { fr.add(frames[o]); vv.add(v[o]); ii.add(ip[o]) }
        }
        val fv = FloatArray(fr.size * 7); val fi = ByteArray(fr.size * 16)
        for (k in fr.indices) { vv[k].copyInto(fv, k * 7); ii[k].copyInto(fi, k * 16) }
        return VmdTrack(fr.toIntArray(), fv, fi)
    }
}
