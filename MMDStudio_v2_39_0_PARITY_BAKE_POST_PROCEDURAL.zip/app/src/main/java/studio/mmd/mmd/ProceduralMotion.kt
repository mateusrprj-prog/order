package studio.mmd.mmd

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * v2.39.0 — Movimento procedural determinístico (equivalente aos plugins de uso comum do MMD): piscar automático,
 * respiração, balanço ocioso e movimento sutil do olhar. Tudo gera keys por seed; o mesmo seed dá o mesmo resultado.
 * Kotlin puro.
 */
object ProceduralMotion {

    private fun hash(seed: Int, a: Int): Float {
        var h = seed * 374761393 + a * 668265263
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777215f
    }

    /**
     * Piscadas: intervalos aleatórios entre [minGap] e [maxGap] quadros; cada piscada fecha em [closeFrames], fica
     * [holdFrames] e abre em [openFrames]. Opcionalmente uma em [doubleBlinkChance] é dupla.
     */
    fun autoBlink(
        from: Int, to: Int, fps: Int = 30, seed: Int = 1, minGapSec: Float = 2f, maxGapSec: Float = 6f,
        closeFrames: Int = 2, holdFrames: Int = 1, openFrames: Int = 3, doubleBlinkChance: Float = 0.12f, peak: Float = 1f
    ): VmdMorphTrack {
        if (from < 0 || to <= from || fps < 1) return VmdMorphTrack(IntArray(0), FloatArray(0))
        val map = java.util.TreeMap<Int, Float>()
        val lo = (minGapSec.coerceAtLeast(0.3f) * fps).toInt().coerceAtLeast(1)
        val hi = (maxGapSec.coerceAtLeast(minGapSec) * fps).toInt().coerceAtLeast(lo + 1)
        val c = closeFrames.coerceIn(1, 10); val hd = holdFrames.coerceIn(0, 10); val o = openFrames.coerceIn(1, 15)
        val pk = peak.coerceIn(0f, 1f)
        var f = from + lo; var i = 0
        map[from] = 0f
        while (f + c + hd + o < to) {
            fun blinkAt(s: Int): Int {
                map[s] = 0f; map[s + c] = pk; if (hd > 0) map[s + c + hd] = pk; map[s + c + hd + o] = 0f
                return s + c + hd + o
            }
            var end = blinkAt(f)
            if (hash(seed, i * 7 + 3) < doubleBlinkChance.coerceIn(0f, 1f) && end + 3 + c + hd + o < to) end = blinkAt(end + 3)
            f = end + lo + (hash(seed, i * 7 + 1) * (hi - lo)).toInt(); i++
        }
        map[to] = 0f
        val fr = map.keys.toIntArray()
        return VmdMorphTrack(fr, FloatArray(fr.size) { map.getValue(fr[it]) })
    }

    private fun quatX(deg: Float): FloatArray { val h = Math.toRadians(deg.toDouble()) / 2; return floatArrayOf(sin(h).toFloat(), 0f, 0f, cos(h).toFloat()) }
    private fun quatY(deg: Float): FloatArray { val h = Math.toRadians(deg.toDouble()) / 2; return floatArrayOf(0f, sin(h).toFloat(), 0f, cos(h).toFloat()) }
    private fun quatZ(deg: Float): FloatArray { val h = Math.toRadians(deg.toDouble()) / 2; return floatArrayOf(0f, 0f, sin(h).toFloat(), cos(h).toFloat()) }
    private fun mul(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
    )

    private fun track(frames: List<Int>, v: List<FloatArray>): VmdTrack {
        val n = frames.size
        val fv = FloatArray(n * 7); val ip = ByteArray(n * 16) { if (it % 16 < 8) 20 else 107 }
        for (i in 0 until n) v[i].copyInto(fv, i * 7)
        return VmdTrack(frames.toIntArray(), fv, ip)
    }

    /**
     * Respiração: oscila a rotação X do osso (ex.: 上半身) com [amplitudeDeg] e período [periodSec]; um key a cada [stepFrames].
     * [base] é a rotação de repouso (quaternion xyzw) à qual o movimento é aplicado.
     */
    fun breathing(from: Int, to: Int, fps: Int = 30, amplitudeDeg: Float = 1.2f, periodSec: Float = 4f, stepFrames: Int = 5, base: FloatArray = floatArrayOf(0f, 0f, 0f, 1f), seed: Int = 1): VmdTrack {
        if (from < 0 || to <= from || fps < 1) return track(emptyList(), emptyList())
        val step = stepFrames.coerceIn(1, 30); val period = (periodSec.coerceIn(0.5f, 30f) * fps)
        val frames = ArrayList<Int>(); val vals = ArrayList<FloatArray>()
        var f = from
        val phase = hash(seed, 99) * 2f * PI.toFloat()
        while (true) {
            val a = amplitudeDeg * sin(2f * PI.toFloat() * (f - from) / period + phase)
            val q = mul(base, quatX(a))
            frames.add(f); vals.add(floatArrayOf(0f, 0f, 0f, q[0], q[1], q[2], q[3]))
            if (f >= to) break
            f = minOf(f + step, to)
        }
        return track(frames, vals)
    }

    /** Balanço ocioso do corpo: ruído suave em Z e Y (graus), mais lento que a respiração. */
    fun idleSway(from: Int, to: Int, fps: Int = 30, amplitudeDeg: Float = 1.5f, stepFrames: Int = 15, base: FloatArray = floatArrayOf(0f, 0f, 0f, 1f), seed: Int = 7): VmdTrack {
        if (from < 0 || to <= from || fps < 1) return track(emptyList(), emptyList())
        val step = stepFrames.coerceIn(2, 90)
        val frames = ArrayList<Int>(); val vals = ArrayList<FloatArray>()
        var f = from; var i = 0
        while (true) {
            val z = (hash(seed, i * 2) - 0.5f) * 2f * amplitudeDeg
            val y = (hash(seed, i * 2 + 1) - 0.5f) * amplitudeDeg
            val q = mul(base, mul(quatY(y), quatZ(z)))
            frames.add(f); vals.add(floatArrayOf(0f, 0f, 0f, q[0], q[1], q[2], q[3]))
            if (f >= to) break
            f = minOf(f + step, to); i++
        }
        // Fecha o ciclo: último key igual ao primeiro para repetir sem salto.
        vals[vals.size - 1] = vals[0].copyOf()
        val t = track(frames, vals)
        return smoothCurves(t)
    }

    /** Sacadas do olhar: pequenos deslocamentos de rotação (graus) do osso do olho em intervalos irregulares. */
    fun eyeSaccades(from: Int, to: Int, fps: Int = 30, rangeDeg: Float = 2.5f, seed: Int = 3, minGapSec: Float = 0.6f, maxGapSec: Float = 2.5f): VmdTrack {
        if (from < 0 || to <= from || fps < 1) return track(emptyList(), emptyList())
        val lo = (minGapSec.coerceAtLeast(0.1f) * fps).toInt().coerceAtLeast(1)
        val hi = (maxGapSec.coerceAtLeast(minGapSec) * fps).toInt().coerceAtLeast(lo + 1)
        val frames = ArrayList<Int>(); val vals = ArrayList<FloatArray>()
        frames.add(from); vals.add(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f))
        var f = from + lo; var i = 0
        while (f < to) {
            val yaw = (hash(seed, i * 3) - 0.5f) * 2f * rangeDeg
            val pitch = (hash(seed, i * 3 + 1) - 0.5f) * rangeDeg
            val q = mul(quatY(yaw), quatX(pitch))
            frames.add(f - 1); vals.add(vals.last().copyOf())     // segura o olhar anterior até o instante da sacada
            frames.add(f); vals.add(floatArrayOf(0f, 0f, 0f, q[0], q[1], q[2], q[3]))
            f += lo + (hash(seed, i * 3 + 2) * (hi - lo)).toInt(); i++
        }
        frames.add(to); vals.add(vals.last().copyOf())
        return track(frames, vals)
    }

    /** Suaviza todas as curvas da trilha para ease-in-out (movimento orgânico). */
    fun smoothCurves(t: VmdTrack): VmdTrack = CurvePreset.apply(t, CurvePreset.EASE_IN_OUT, 1, (t.frames.size - 1).coerceAtLeast(1))

    /** Lábios/boca e olhos: aplica ruído de peso em um morph (ex.: bochecha) para tirar o aspecto estático. */
    fun morphNoise(from: Int, to: Int, base: Float, amount: Float, stepFrames: Int = 20, seed: Int = 5): VmdMorphTrack {
        if (from < 0 || to <= from) return VmdMorphTrack(IntArray(0), FloatArray(0))
        val step = stepFrames.coerceIn(2, 120)
        val fr = ArrayList<Int>(); val w = ArrayList<Float>()
        var f = from; var i = 0
        while (true) {
            fr.add(f); w.add((base + (hash(seed, i) - 0.5f) * 2f * amount).coerceIn(0f, 1f))
            if (f >= to) break
            f = minOf(f + step, to); i++
        }
        return VmdMorphTrack(fr.toIntArray(), w.toFloatArray())
    }

    fun rms(values: FloatArray): Float { if (values.isEmpty()) return 0f; var s = 0f; for (v in values) s += v * v; return sqrt(s / values.size) }
}
