package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Registro folha do morph de impulso PMX (tipo 10). Vetores estão nas unidades originais do PMX. */
data class PmxImpulseMorphEntry(
    val rigidBody: Int,
    val local: Boolean,
    val velocity: FloatArray,
    val torque: FloatArray
)

data class PmxImpulseDecodeResult(
    val entries: List<PmxImpulseMorphEntry>,
    val warnings: List<String>,
    val elementSize: Int
)

/** Decodificação validada dos registros de impulso PMX. O bloco raw original continua no PmxMorph para round-trip. */
object PmxImpulseMorphs {
    private const val FIXED_BYTES = 25 // flag local + 6 floats

    fun decode(morph: PmxMorph, rigidBodyCount: Int): PmxImpulseDecodeResult {
        val raw = morph.raw ?: return PmxImpulseDecodeResult(emptyList(), listOf("Morph sem bloco raw"), 0)
        if (morph.count <= 0) return PmxImpulseDecodeResult(emptyList(), if (raw.isEmpty()) emptyList() else listOf("Contagem não positiva com bytes presentes"), 0)
        if (raw.size % morph.count != 0) return PmxImpulseDecodeResult(emptyList(), listOf("Tamanho raw não divisível pela contagem"), 0)
        val elementSize = raw.size / morph.count
        val indexSize = elementSize - FIXED_BYTES
        if (indexSize != 1 && indexSize != 2 && indexSize != 4) {
            return PmxImpulseDecodeResult(emptyList(), listOf("Tamanho de índice PMX inválido: $indexSize"), elementSize)
        }
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val entries = ArrayList<PmxImpulseMorphEntry>(morph.count)
        val warnings = ArrayList<String>()
        for (k in 0 until morph.count) {
            var o = k * elementSize
            val body = when (indexSize) {
                1 -> bb.get(o).toInt() // signed index
                2 -> bb.getShort(o).toInt()
                else -> bb.getInt(o)
            }
            o += indexSize
            val localByte = bb.get(o).toInt() and 0xFF; o++
            val velocity = FloatArray(3) { c -> bb.getFloat(o + c * 4) }; o += 12
            val torque = FloatArray(3) { c -> bb.getFloat(o + c * 4) }
            if (body !in 0 until rigidBodyCount) { warnings.add("Registro $k: corpo rígido $body fora de 0..${rigidBodyCount - 1}"); continue }
            if (localByte !in 0..1) { warnings.add("Registro $k: flag local inválida $localByte"); continue }
            if (velocity.any { !it.isFinite() } || torque.any { !it.isFinite() }) {
                warnings.add("Registro $k: vetor de impulso não finito"); continue
            }
            entries.add(PmxImpulseMorphEntry(body, localByte == 1, velocity, torque))
        }
        return PmxImpulseDecodeResult(entries, warnings, elementSize)
    }
}

/** Sink de física. Retorna false quando o corpo não aceita o impulso (por exemplo, corpo cinemático). */
fun interface PmxImpulseSink {
    fun apply(entry: PmxImpulseMorphEntry, weight: Float): Boolean
}

/** Cache de decodificação e despacho explícito. Não dispara em redesenhos da viewport; o chamador dispara o evento. */
class PmxImpulseMorphDispatcher(model: PmxModel) {
    private val decoded: Array<PmxImpulseDecodeResult?> = Array(model.morphs.size) { i ->
        if (model.morphs[i].type == 10) PmxImpulseMorphs.decode(model.morphs[i], model.rigidBodies.size) else null
    }

    fun dispatchLeaf(morphIndex: Int, weight: Float, sink: PmxImpulseSink): Int {
        if (!weight.isFinite() || weight == 0f || morphIndex !in decoded.indices) return 0
        val records = decoded[morphIndex]?.entries ?: return 0
        var applied = 0
        for (entry in records) if (sink.apply(entry, weight)) applied++
        return applied
    }

    fun diagnostics(morphIndex: Int): PmxImpulseDecodeResult? = decoded.getOrNull(morphIndex)
}
