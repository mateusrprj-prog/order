package studio.mmd.mmd

/** Recebe cada morph "folha" (vértice ou osso) com o peso já resolvido. */
interface MorphSink { fun leaf(index: Int, weight: Float) }

/**
 * Resolve morphs de grupo (tipo 0) e flip (tipo 9) em morphs folha com peso final (v1.11.0).
 * - Grupo: propaga peso * taxa de cada elemento; encadeamento sem limite fixo de profundidade.
 * - Flip: o peso escolhe UM elemento: índice = floor(peso * n), limitado a n-1; peso <= 0 não aplica nada;
 *   o morph escolhido recebe a taxa do elemento (não multiplicada pelo peso do flip).
 *   ATENÇÃO: a regra de seleção do flip segue a leitura comum da especificação PMX 2.1 e NÃO foi comparada com o MMD oficial.
 * - Ciclos e referências inválidas são ignorados e contados em [cycles] / [invalid] (sem recursão infinita).
 * Sem alocação por chamada (o conjunto "no caminho atual" é reutilizado).
 */
class MorphResolver(private val morphs: List<PmxMorph>) {
    private val onPath = BooleanArray(morphs.size)
    var cycles = 0; private set
    var invalid = 0; private set

    fun resetCounters() { cycles = 0; invalid = 0 }

    fun resolve(index: Int, weight: Float, sink: MorphSink) {
        if (index < 0 || index >= morphs.size) { invalid++; return }
        if (weight.isNaN() || weight.isInfinite()) { invalid++; return }
        val mo = morphs[index]
        when (mo.type) {
            0 -> {
                val idx = mo.groupIdx; val rate = mo.groupRate
                if (idx == null || rate == null) return
                if (onPath[index]) { cycles++; return }
                onPath[index] = true
                for (k in idx.indices) resolve(idx[k], weight * rate[k], sink)
                onPath[index] = false
            }
            9 -> {
                val idx = mo.groupIdx; val rate = mo.groupRate
                if (idx == null || rate == null || idx.isEmpty() || weight <= 0f) return
                if (onPath[index]) { cycles++; return }
                onPath[index] = true
                val pick = minOf((weight * idx.size).toInt(), idx.size - 1)
                resolve(idx[pick], rate[pick], sink)
                onPath[index] = false
            }
            else -> sink.leaf(index, weight)
        }
    }
}
