package studio.mmd.mmd

/**
 * v2.35.0 — Copiar/colar trecho de animação, com colar espelhado e deslocamento (MMD oficial: copiar/colar frames e "反転ペースト").
 * Kotlin puro e imutável. A área de transferência guarda os keys relativos ao primeiro quadro copiado.
 */
object SideNames {
    private val sepL = Regex("(?<![A-Za-z])L(?![A-Za-z])")
    private val sepR = Regex("(?<![A-Za-z])R(?![A-Za-z])")

    /** Nome do outro lado (左/右, Left/Right, left/right, L/R isolados) ou null se o nome não tem lado. */
    fun opposite(n: String): String? {
        val t = when {
            n.contains('左') -> n.replace('左', '右')
            n.contains('右') -> n.replace('右', '左')
            n.contains("Left") -> n.replace("Left", "Right")
            n.contains("Right") -> n.replace("Right", "Left")
            n.contains("left") -> n.replace("left", "right")
            n.contains("right") -> n.replace("right", "left")
            sepL.containsMatchIn(n) || sepR.containsMatchIn(n) -> n.replace(Regex("(?<![A-Za-z])[LR](?![A-Za-z])")) { if (it.value == "L") "R" else "L" }
            else -> return null
        }
        return if (t != n) t else null
    }

    /** Espelho no plano X=0: posição (-x,y,z), rotação (qx,-qy,-qz,qw). */
    fun mirrorV(v: FloatArray): FloatArray = floatArrayOf(-v[0], v[1], v[2], v[3], -v[4], -v[5], v[6])

    /** Troca as curvas X e reordena nada mais: o espelho em X mantém as curvas de cada canal. */
    fun mirrorIp(ip: ByteArray): ByteArray = ip.copyOf()
}

class ClipBoneKey(val rel: Int, val v: FloatArray, val ip: ByteArray)
class ClipMorphKey(val rel: Int, val w: Float)

class MotionClip(
    val length: Int,
    val bones: Map<String, List<ClipBoneKey>>,
    val morphs: Map<String, List<ClipMorphKey>>
) {
    val keyCount get() = bones.values.sumOf { it.size } + morphs.values.sumOf { it.size }
    val isEmpty get() = keyCount == 0
}

enum class PasteMode { REPLACE_RANGE, MERGE }

object MotionClipboard {

    /** Copia as keys em [from, to] (inclusive) das trilhas escolhidas ([boneFilter]/[morphFilter] null = todas). */
    fun copy(m: VmdMotion, from: Int, to: Int, boneFilter: Collection<String>? = null, morphFilter: Collection<String>? = null): MotionClip {
        if (to < from || from < 0) return MotionClip(0, emptyMap(), emptyMap())
        val bones = LinkedHashMap<String, List<ClipBoneKey>>()
        for ((name, t) in m.bones) {
            if (boneFilter != null && name !in boneFilter) continue
            val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
            val l = ArrayList<ClipBoneKey>()
            for (i in 0 until n) if (t.frames[i] in from..to) l.add(ClipBoneKey(t.frames[i] - from, t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
            if (l.isNotEmpty()) bones[name] = l
        }
        val morphs = LinkedHashMap<String, List<ClipMorphKey>>()
        for ((name, t) in m.morphs) {
            if (morphFilter != null && name !in morphFilter) continue
            val n = minOf(t.frames.size, t.w.size)
            val l = ArrayList<ClipMorphKey>()
            for (i in 0 until n) if (t.frames[i] in from..to) l.add(ClipMorphKey(t.frames[i] - from, t.w[i]))
            if (l.isNotEmpty()) morphs[name] = l
        }
        return MotionClip(to - from + 1, bones, morphs)
    }

    class PasteResult(val motion: VmdMotion, val written: Int, val skipped: Int)

    /**
     * Cola [clip] a partir de [atFrame], repetindo [repeat] vezes em sequência. Com [mirror], keys de ossos com lado
     * vão para o osso oposto (se [knownBones] o contém) com X invertido; ossos centrais só têm X invertido.
     * REPLACE_RANGE apaga antes as keys da trilha de destino dentro do trecho colado; MERGE só sobrescreve os mesmos quadros.
     */
    fun paste(
        m: VmdMotion, clip: MotionClip, atFrame: Int, mode: PasteMode = PasteMode.REPLACE_RANGE,
        mirror: Boolean = false, repeat: Int = 1, knownBones: Set<String>? = null
    ): PasteResult {
        if (clip.isEmpty || atFrame < 0) return PasteResult(m, 0, 0)
        val reps = repeat.coerceIn(1, 200)
        var written = 0; var skipped = 0
        val boneKeys = HashMap<String, MutableMap<Int, Pair<FloatArray, ByteArray>>>()
        for ((n, t) in m.bones) {
            val map = java.util.TreeMap<Int, Pair<FloatArray, ByteArray>>()
            val c = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
            for (i in 0 until c) map[t.frames[i]] = t.v.copyOfRange(i * 7, i * 7 + 7) to t.ip.copyOfRange(i * 16, i * 16 + 16)
            boneKeys[n] = map
        }
        val morphKeys = HashMap<String, MutableMap<Int, Float>>()
        for ((n, t) in m.morphs) {
            val map = java.util.TreeMap<Int, Float>()
            for (i in 0 until minOf(t.frames.size, t.w.size)) map[t.frames[i]] = t.w[i]
            morphKeys[n] = map
        }
        for (r in 0 until reps) {
            val base = atFrame.toLong() + r.toLong() * clip.length
            if (base + clip.length > Int.MAX_VALUE) break
            val b0 = base.toInt()
            for ((name, keys) in clip.bones) {
                var target = name
                if (mirror) {
                    val opp = SideNames.opposite(name)
                    if (opp != null) { if (knownBones != null && opp !in knownBones) { skipped += keys.size; continue }; target = opp }
                }
                if (knownBones != null && target !in knownBones) { skipped += keys.size; continue }
                val map = boneKeys.getOrPut(target) { java.util.TreeMap() }
                if (mode == PasteMode.REPLACE_RANGE) map.keys.removeAll(map.keys.filter { it in b0 until b0 + clip.length }.toSet())
                for (k in keys) {
                    val v = if (mirror) SideNames.mirrorV(k.v) else k.v.copyOf()
                    map[b0 + k.rel] = v to SideNames.mirrorIp(k.ip)
                    written++
                }
            }
            for ((name, keys) in clip.morphs) {
                val map = morphKeys.getOrPut(name) { java.util.TreeMap() }
                if (mode == PasteMode.REPLACE_RANGE) map.keys.removeAll(map.keys.filter { it in b0 until b0 + clip.length }.toSet())
                for (k in keys) { map[b0 + k.rel] = k.w; written++ }
            }
        }
        val bones = LinkedHashMap<String, VmdTrack>()
        var mx = 0
        for ((n, map) in boneKeys) {
            if (map.isEmpty()) continue
            val fr = map.keys.toIntArray()
            val v = FloatArray(fr.size * 7); val ip = ByteArray(fr.size * 16)
            var i = 0
            for ((_, p) in map) { p.first.copyInto(v, i * 7); p.second.copyInto(ip, i * 16); i++ }
            bones[n] = VmdTrack(fr, v, ip); mx = maxOf(mx, fr[fr.size - 1])
        }
        val morphs = LinkedHashMap<String, VmdMorphTrack>()
        for ((n, map) in morphKeys) {
            if (map.isEmpty()) continue
            val fr = map.keys.toIntArray()
            morphs[n] = VmdMorphTrack(fr, FloatArray(fr.size) { map.getValue(fr[it]) }); mx = maxOf(mx, fr[fr.size - 1])
        }
        return PasteResult(VmdMotion(m.modelName, bones, morphs, maxOf(mx, m.maxFrame), m.warnings, m.extras), written, skipped)
    }

    /** Desloca todas as keys do trecho [from, to] por [delta] quadros (positivo = para frente), sobrescrevendo o destino. */
    fun shiftRange(m: VmdMotion, from: Int, to: Int, delta: Int): VmdMotion {
        if (delta == 0 || to < from || from < 0) return m
        val clip = copy(m, from, to)
        if (clip.isEmpty) return m
        val cleared = clearRange(m, from, to)
        val dest = (from + delta).coerceAtLeast(0)
        return paste(cleared, clip, dest, PasteMode.REPLACE_RANGE).motion
    }

    /** Remove todas as keys no trecho [from, to]. */
    fun clearRange(m: VmdMotion, from: Int, to: Int): VmdMotion {
        val bones = LinkedHashMap<String, VmdTrack>()
        for ((n, t) in m.bones) {
            val c = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
            val idx = (0 until c).filter { t.frames[it] !in from..to }
            if (idx.isEmpty()) continue
            val v = FloatArray(idx.size * 7); val ip = ByteArray(idx.size * 16)
            for ((j, i) in idx.withIndex()) { t.v.copyInto(v, j * 7, i * 7, i * 7 + 7); t.ip.copyInto(ip, j * 16, i * 16, i * 16 + 16) }
            bones[n] = VmdTrack(IntArray(idx.size) { t.frames[idx[it]] }, v, ip)
        }
        val morphs = LinkedHashMap<String, VmdMorphTrack>()
        for ((n, t) in m.morphs) {
            val c = minOf(t.frames.size, t.w.size)
            val idx = (0 until c).filter { t.frames[it] !in from..to }
            if (idx.isEmpty()) continue
            morphs[n] = VmdMorphTrack(IntArray(idx.size) { t.frames[idx[it]] }, FloatArray(idx.size) { t.w[idx[it]] })
        }
        return VmdMotion(m.modelName, bones, morphs, m.maxFrame, m.warnings, m.extras)
    }

    /**
     * Espelha o trecho [from, to] no lugar: cada osso com lado recebe as keys do osso oposto invertidas (e vice-versa);
     * ossos centrais têm só X/rotação espelhados. Equivale ao "反転" aplicado a uma faixa de frames.
     */
    fun mirrorRange(m: VmdMotion, from: Int, to: Int, knownBones: Set<String>? = null): PasteResult {
        val clip = copy(m, from, to)
        if (clip.isEmpty) return PasteResult(m, 0, 0)
        val cleared = clearRange(m, from, to)
        // Ossos sem par (ou com par ausente no modelo) ficam intocados quando espelhar não for possível.
        val keepUntouched = HashMap<String, List<ClipBoneKey>>()
        val usable = LinkedHashMap<String, List<ClipBoneKey>>()
        for ((n, k) in clip.bones) {
            val opp = SideNames.opposite(n)
            if (opp != null && knownBones != null && opp !in knownBones) keepUntouched[n] = k else usable[n] = k
        }
        val pasted = paste(cleared, MotionClip(clip.length, usable, clip.morphs), from, PasteMode.REPLACE_RANGE, mirror = true, knownBones = knownBones)
        if (keepUntouched.isEmpty()) return pasted
        val back = paste(pasted.motion, MotionClip(clip.length, keepUntouched, emptyMap()), from, PasteMode.MERGE, mirror = false, knownBones = knownBones)
        return PasteResult(back.motion, pasted.written + back.written, pasted.skipped + back.skipped)
    }
}
