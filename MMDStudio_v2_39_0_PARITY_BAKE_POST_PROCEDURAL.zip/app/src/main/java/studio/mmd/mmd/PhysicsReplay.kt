package studio.mmd.mmd

import kotlin.math.abs

/**
 * v2.39.0 — Política de reinício da física ao navegar na timeline (o MMD zera a física ao pular de quadro).
 * Decide se é preciso reiniciar e quantos quadros de aquecimento simular antes do quadro alvo para a roupa/cabelo
 * chegarem a um estado plausível. Kotlin puro.
 */
object PhysicsReplay {
    enum class Action { CONTINUE, RESET_AND_WARM, RESET_ONLY }
    class Plan(val action: Action, val warmStartFrame: Int, val warmFrames: Int)

    /**
     * [previous] = último quadro simulado (null = nunca), [target] = quadro pedido.
     * Avanço normal (1..[maxStep] quadros) continua; saltos ou retrocessos reiniciam. Com [warmFrames] > 0 aquece antes.
     */
    fun plan(previous: Int?, target: Int, playing: Boolean, maxStep: Int = 3, warmFrames: Int = 20): Plan {
        val t = target.coerceAtLeast(0)
        if (previous != null) {
            val d = t - previous
            if (d == 0) return Plan(Action.CONTINUE, t, 0)
            if (d in 1..maxStep.coerceAtLeast(1)) return Plan(Action.CONTINUE, previous, d)
            if (playing && d in 1..(maxStep * 4)) return Plan(Action.CONTINUE, previous, d)
        }
        val warm = warmFrames.coerceIn(0, 240).coerceAtMost(t)
        return if (warm == 0) Plan(Action.RESET_ONLY, t, 0) else Plan(Action.RESET_AND_WARM, t - warm, warm)
    }

    /** Quadros a simular numa exportação para o quadro [first]: aquece os [warmFrames] anteriores (nunca antes de 0). */
    fun exportWarmup(first: Int, warmFrames: Int): IntRange {
        val s = (first - warmFrames.coerceIn(0, 600)).coerceAtLeast(0)
        return s until first.coerceAtLeast(0)
    }

    fun isJump(prev: Int, cur: Int, threshold: Int = 4) = abs(cur - prev) > threshold
}
