package studio.mmd.mmd

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/**
 * v2.37.0 — Planos de câmera e cortes secos (técnica padrão do MMD: key de retenção + key de destino com curva em degrau).
 * Kotlin puro.
 */
object CameraShots {
    enum class Shot(val label: String, val distance: Float, val fov: Float, val pitchDeg: Float, val heightFactor: Float) {
        CLOSE_UP("Close-up", 9f, 28f, 0f, 0.93f),
        MEDIUM("Plano médio", 20f, 35f, 0f, 0.65f),
        FULL("Corpo inteiro", 34f, 40f, 0f, 0.5f),
        WIDE("Aberto", 60f, 45f, 5f, 0.45f),
        LOW_ANGLE("Contra-plongée", 26f, 40f, -22f, 0.45f),
        HIGH_ANGLE("Plongée", 30f, 40f, 28f, 0.5f),
        DUTCH("Holandês", 24f, 40f, 0f, 0.6f)
    }

    /** Pose de câmera para o plano em torno do personagem de altura [charHeight] centrado em (cx, cz), olhando de [yawDeg]. */
    fun pose(shot: Shot, charHeight: Float, cx: Float = 0f, cz: Float = 0f, yawDeg: Float = 0f): CameraPose {
        val h = if (charHeight.isFinite() && charHeight > 1f) charHeight else 20f
        val scale = h / 20f
        val dolly = shot.distance * scale
        val rz = if (shot == Shot.DUTCH) Math.toRadians(14.0).toFloat() else 0f
        return CameraPose(dolly, cx, h * shot.heightFactor, cz, Math.toRadians(shot.pitchDeg.toDouble()).toFloat(), Math.toRadians(yawDeg.toDouble()).toFloat(), rz, shot.fov).sanitized()
    }

    /** Distância para enquadrar um objeto de altura [height] preenchendo [fill] (0..1) da altura da tela com o [fovDeg] vertical. */
    fun distanceToFrame(height: Float, fovDeg: Float, fill: Float = 0.8f): Float {
        val f = fill.coerceIn(0.05f, 1f)
        val half = Math.toRadians((fovDeg.coerceIn(1f, 179f) / 2).toDouble())
        return (height / f / 2f / tan(half)).toFloat()
    }

    /**
     * Corte seco no quadro [frame]: mantém a pose atual no quadro anterior e salta para [pose] sem interpolação.
     * Se [frame] <= 0 só grava a pose.
     */
    fun cut(camera: VmdCamera?, frame: Int, pose: CameraPose): VmdCamera {
        if (frame <= 0) return CameraMotionTools.put(camera, 0, pose)
        var cam = camera
        if (cam != null && cam.frames.isNotEmpty() && !CameraMotionTools.hasKey(cam, frame - 1)) {
            cam = CameraMotionTools.put(cam, frame - 1, CameraMotionTools.sample(cam, (frame - 1).toFloat()))
        }
        cam = CameraMotionTools.put(cam, frame, pose)
        val k = cam.frames.indexOf(frame)
        val ip = cam.ip.copyOf()
        for (c in 0 until 6) { val o = k * 24 + c * 4; ip[o] = 127; ip[o + 1] = 127; ip[o + 2] = 0; ip[o + 3] = 0 }
        return VmdCamera(cam.frames, cam.dist, cam.pos, cam.rot, cam.fov, ip)
    }

    /** Sequência de planos: um corte a cada [every] quadros começando em [start], percorrendo [shots] em ciclo até [end]. */
    fun cutSequence(camera: VmdCamera?, shots: List<Shot>, start: Int, end: Int, every: Int, charHeight: Float, yawStepDeg: Float = 0f): VmdCamera? {
        if (shots.isEmpty() || every < 1 || end < start) return camera
        var cam = camera
        var f = start; var i = 0
        while (f <= end) {
            cam = cut(cam, f, pose(shots[i % shots.size], charHeight, yawDeg = yawStepDeg * i))
            f += every; i++
        }
        return cam
    }

    fun pan(camera: VmdCamera?, from: Int, to: Int, dxUnits: Float, dyUnits: Float): VmdCamera? {
        if (to <= from) return camera
        val a = CameraMotionTools.sample(camera, from.toFloat())
        var cam = CameraMotionTools.put(camera, from, a)
        val yaw = a.ry
        val dx = dxUnits * cos(yaw) ; val dz = -dxUnits * sin(yaw)
        cam = CameraMotionTools.put(cam, to, a.copy(x = a.x + dx, y = a.y + dyUnits, z = a.z + dz))
        return cam
    }
}
