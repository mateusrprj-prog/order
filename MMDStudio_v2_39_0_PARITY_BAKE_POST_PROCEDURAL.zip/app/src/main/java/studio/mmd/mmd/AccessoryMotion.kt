package studio.mmd.mmd

import kotlin.math.cos
import kotlin.math.sin

/**
 * v2.37.0 — Animação de acessórios (.x/props) como no MMD oficial: posição, rotação, escala (Si), transparência (Tr),
 * visibilidade, sombra e pai externo por keys. Kotlin puro.
 *
 * Posição/rotação/escala/opacidade interpolam com a curva de easing da key de chegada; visibilidade, sombra e pai são em degrau.
 */
class AccessoryKey(
    val frame: Int,
    val pos: FloatArray = floatArrayOf(0f, 0f, 0f),
    /** Rotação Euler em graus (X, Y, Z), aplicada na ordem Ry·Rx·Rz como no renderer de props. */
    val rotDeg: FloatArray = floatArrayOf(0f, 0f, 0f),
    val scale: Float = 1f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val shadow: Boolean = true,
    val parentModel: Int = -1,
    val parentBone: Int = -1,
    /** Easing do segmento que chega nesta key (x1,y1,x2,y2 em 0..127). */
    val curve: IntArray = intArrayOf(20, 20, 107, 107)
)

class AccessorySample(
    val pos: FloatArray, val rotDeg: FloatArray, val scale: Float, val opacity: Float,
    val visible: Boolean, val shadow: Boolean, val parentModel: Int, val parentBone: Int
)

class AccessoryTrack(val id: String, keys: List<AccessoryKey>) {
    val keys: List<AccessoryKey> = keys.filter { it.frame >= 0 }.sortedBy { it.frame }.fold(ArrayList<AccessoryKey>()) { acc, k ->
        if (acc.isNotEmpty() && acc.last().frame == k.frame) acc[acc.size - 1] = k else acc.add(k); acc
    }
    val maxFrame get() = if (keys.isEmpty()) 0 else keys.last().frame

    fun sample(frame: Float): AccessorySample? {
        if (keys.isEmpty() || !frame.isFinite()) return null
        var i = -1
        for (k in keys.indices) { if (keys[k].frame <= frame) i = k else break }
        if (i < 0) return of(keys[0], keys[0], 0f)
        if (i == keys.size - 1) return of(keys[i], keys[i], 0f)
        val a = keys[i]; val b = keys[i + 1]
        val s = (frame - a.frame) / (b.frame - a.frame).toFloat()
        return of(a, b, InterpCurve.eval(b.curve[0], b.curve[1], b.curve[2], b.curve[3], s))
    }

    private fun of(a: AccessoryKey, b: AccessoryKey, w: Float): AccessorySample {
        fun l(x: Float, y: Float) = x + (y - x) * w
        return AccessorySample(
            FloatArray(3) { l(a.pos[it], b.pos[it]) }, FloatArray(3) { l(a.rotDeg[it], b.rotDeg[it]) },
            l(a.scale, b.scale).coerceAtLeast(0f), l(a.opacity, b.opacity).coerceIn(0f, 1f),
            a.visible, a.shadow, a.parentModel, a.parentBone
        )
    }

    fun put(key: AccessoryKey) = AccessoryTrack(id, keys + key)
    fun remove(frame: Int) = AccessoryTrack(id, keys.filter { it.frame != frame })
    fun insertFrames(at: Int, count: Int) = AccessoryTrack(id, keys.map { if (it.frame >= at) copy(it, it.frame + count.coerceAtLeast(0)) else it })
    fun deleteFrames(from: Int, count: Int) = AccessoryTrack(id, keys.filter { it.frame < from || it.frame >= from + count }
        .map { if (it.frame >= from + count) copy(it, it.frame - count) else it })

    private fun copy(k: AccessoryKey, frame: Int) = AccessoryKey(frame, k.pos, k.rotDeg, k.scale, k.opacity, k.visible, k.shadow, k.parentModel, k.parentBone, k.curve)

    /** Cria um fade-in/out de opacidade: sobe de 0 a 1 em [inFrames] a partir do primeiro key e desce nos últimos [outFrames]. */
    fun withFade(inFrames: Int, outFrames: Int): AccessoryTrack {
        if (keys.isEmpty()) return this
        var t = this
        val first = keys.first(); val last = keys.last()
        if (inFrames > 0) {
            t = t.put(copyOp(first, first.frame, 0f))
            t = t.put(copyOp(sampleOr(t, first.frame + inFrames), first.frame + inFrames, 1f))
        }
        if (outFrames > 0 && last.frame - outFrames > first.frame) {
            t = t.put(copyOp(sampleOr(t, last.frame - outFrames), last.frame - outFrames, 1f))
            t = t.put(copyOp(last, last.frame, 0f))
        }
        return t
    }

    private fun sampleOr(t: AccessoryTrack, f: Int): AccessoryKey {
        val s = t.sample(f.toFloat()) ?: return AccessoryKey(f)
        return AccessoryKey(f, s.pos, s.rotDeg, s.scale, s.opacity, s.visible, s.shadow, s.parentModel, s.parentBone)
    }

    private fun copyOp(k: AccessoryKey, frame: Int, op: Float) = AccessoryKey(frame, k.pos, k.rotDeg, k.scale, op, k.visible, k.shadow, k.parentModel, k.parentBone, k.curve)

    /** Chaves de pai externo como AttachTrack (offset identidade) para o resolvedor de [OuterParent]. */
    fun toAttachTrack(childModel: Int): AttachTrack {
        val out = ArrayList<AttachKey>()
        var last: Pair<Int, Int>? = null
        for (k in keys) {
            val cur = k.parentModel to k.parentBone
            if (last == null || last != cur) { out.add(AttachKey(k.frame, k.parentModel, k.parentBone)); last = cur }
        }
        return AttachTrack(childModel, -1, out)
    }

    companion object {
        /** Matriz 4x4 coluna-maior T·Ry·Rx·Rz·S da amostra. */
        fun matrix(s: AccessorySample): FloatArray {
            val rx = Math.toRadians(s.rotDeg[0].toDouble()); val ry = Math.toRadians(s.rotDeg[1].toDouble()); val rz = Math.toRadians(s.rotDeg[2].toDouble())
            val cx = cos(rx).toFloat(); val sx = sin(rx).toFloat(); val cy = cos(ry).toFloat(); val sy = sin(ry).toFloat(); val cz = cos(rz).toFloat(); val sz = sin(rz).toFloat()
            val ryM = floatArrayOf(cy, 0f, -sy, 0f, 0f, 1f, 0f, 0f, sy, 0f, cy, 0f, 0f, 0f, 0f, 1f)
            val rxM = floatArrayOf(1f, 0f, 0f, 0f, 0f, cx, sx, 0f, 0f, -sx, cx, 0f, 0f, 0f, 0f, 1f)
            val rzM = floatArrayOf(cz, sz, 0f, 0f, -sz, cz, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
            val r = OuterParent.mul(OuterParent.mul(ryM, rxM), rzM)
            for (c in 0..2) for (rr in 0..2) r[c * 4 + rr] *= s.scale
            r[12] = s.pos[0]; r[13] = s.pos[1]; r[14] = s.pos[2]
            return r
        }

        /** Texto: id na primeira linha e uma key por linha com 17 campos separados por TAB. */
        fun encode(t: AccessoryTrack): String = buildString {
            append(t.id.replace('\n', ' ').replace('\t', ' '))
            for (k in t.keys) {
                append('\n')
                append(listOf(k.frame, k.pos[0], k.pos[1], k.pos[2], k.rotDeg[0], k.rotDeg[1], k.rotDeg[2], k.scale, k.opacity,
                    if (k.visible) 1 else 0, if (k.shadow) 1 else 0, k.parentModel, k.parentBone, k.curve[0], k.curve[1], k.curve[2], k.curve[3]).joinToString("\t"))
            }
        }

        fun decode(text: String): AccessoryTrack? {
            val lines = text.lines()
            if (lines.isEmpty() || lines[0].isBlank()) return null
            val keys = ArrayList<AccessoryKey>()
            for (l in lines.drop(1)) {
                val p = l.split('\t')
                if (p.size < 17) continue
                val f = p[0].toIntOrNull() ?: continue
                val n = p.drop(1).map { it.toFloatOrNull() ?: return@map null }
                if (n.any { it == null || !it.isFinite() }) continue
                val v = n.map { it!! }
                keys.add(AccessoryKey(f, floatArrayOf(v[0], v[1], v[2]), floatArrayOf(v[3], v[4], v[5]), v[6], v[7].coerceIn(0f, 1f), v[8] != 0f, v[9] != 0f,
                    v[10].toInt(), v[11].toInt(), intArrayOf(v[12].toInt().coerceIn(0, 127), v[13].toInt().coerceIn(0, 127), v[14].toInt().coerceIn(0, 127), v[15].toInt().coerceIn(0, 127))))
            }
            return AccessoryTrack(lines[0], keys)
        }
    }
}
