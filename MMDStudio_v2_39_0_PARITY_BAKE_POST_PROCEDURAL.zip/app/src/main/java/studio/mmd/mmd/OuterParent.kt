package studio.mmd.mmd

/**
 * v2.30.0 — Pai externo (外部親) do MMD oficial.
 *
 * Uma trilha liga um osso de um modelo/acessório ("filho") a um osso de outro modelo ("pai") por keys em degrau.
 * Cada key guarda o deslocamento (offset) entre pai e filho no instante da troca, então o objeto não pula quando
 * a troca acontece (ex.: espada passando da mão direita para a esquerda). Matrizes 4x4 em coluna-maior (estilo OpenGL).
 *
 * Kotlin puro. Não toca em renderer, Animator nem UI; quem integra fornece as matrizes de mundo.
 */
class AttachKey(
    val frame: Int,
    /** Índice do modelo pai na cena; -1 = mundo (sem pai). */
    val parentModel: Int,
    /** Índice do osso pai; -1 = origem do modelo pai. */
    val parentBone: Int,
    /** Offset pai→filho (16 floats) ou null para identidade. */
    val offset: FloatArray? = null
)

class AttachTrack(val childModel: Int, val childBone: Int, keys: List<AttachKey>) {
    val keys: List<AttachKey> = keys.sortedBy { it.frame }

    /** Key ativa no quadro (a última com frame <= quadro); antes do primeiro key o filho fica solto no mundo. */
    fun activeAt(frame: Float): AttachKey? {
        var found: AttachKey? = null
        for (k in keys) { if (k.frame <= frame) found = k else break }
        return found
    }
}

object OuterParent {

    val IDENTITY: FloatArray get() = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)

    fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        for (c in 0..3) for (r in 0..3) {
            var s = 0f
            for (k in 0..3) s += a[k * 4 + r] * b[c * 4 + k]
            o[c * 4 + r] = s
        }
        return o
    }

    /** Inversa 4x4 geral; null se a matriz for singular ou tiver valores não finitos. */
    fun invert(m: FloatArray): FloatArray? {
        if (m.size < 16 || m.any { !it.isFinite() }) return null
        val a = DoubleArray(16) { m[it].toDouble() }
        val inv = DoubleArray(16)
        inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10]
        inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10]
        inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9]
        inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9]
        inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10]
        inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10]
        inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9]
        inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9]
        inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6]
        inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6]
        inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5]
        inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5]
        inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6]
        inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6]
        inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5]
        inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5]
        val det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12]
        if (!det.isFinite() || Math.abs(det) < 1e-12) return null
        val id = 1.0 / det
        return FloatArray(16) { (inv[it] * id).toFloat() }
    }

    /**
     * Cria um key que mantém o filho exatamente onde está no mundo no quadro da troca:
     * offset = inverse(parentWorld) * childWorld. Para soltar no mundo use [releaseKey].
     * Devolve null se a matriz do pai não for invertível.
     */
    fun holdKey(frame: Int, parentModel: Int, parentBone: Int, parentWorld: FloatArray, childWorld: FloatArray): AttachKey? {
        val inv = invert(parentWorld) ?: return null
        if (childWorld.size < 16 || childWorld.any { !it.isFinite() }) return null
        return AttachKey(frame.coerceAtLeast(0), parentModel, parentBone, mul(inv, childWorld))
    }

    /** Key que solta o filho no mundo, preservando a pose de mundo (offset = childWorld). */
    fun releaseKey(frame: Int, childWorld: FloatArray): AttachKey? {
        if (childWorld.size < 16 || childWorld.any { !it.isFinite() }) return null
        return AttachKey(frame.coerceAtLeast(0), -1, -1, childWorld.copyOf(16))
    }

    /**
     * Matriz de mundo do filho no quadro. [parentWorld] devolve a matriz de mundo (modelo, osso) naquele quadro,
     * ou null se o pai não existir. Retorna null quando não há key ativa (o filho segue sua própria animação).
     */
    fun resolve(track: AttachTrack, frame: Float, parentWorld: (model: Int, bone: Int) -> FloatArray?): FloatArray? {
        val k = track.activeAt(frame) ?: return null
        val off = k.offset?.takeIf { it.size >= 16 && it.all { v -> v.isFinite() } } ?: IDENTITY
        if (k.parentModel < 0) return off.copyOf(16)
        val p = parentWorld(k.parentModel, k.parentBone) ?: return null
        if (p.size < 16) return null
        return mul(p, off)
    }

    /** Impede ciclos: um modelo/osso nunca pode ser pai (direto ou indireto) de si mesmo. */
    fun createsCycle(tracks: List<AttachTrack>, candidate: AttachTrack): Boolean {
        val all = tracks.filter { it.childModel != candidate.childModel || it.childBone != candidate.childBone } + candidate
        for (start in candidate.keys) {
            if (start.parentModel < 0) continue
            var model = start.parentModel
            val seen = HashSet<Int>()
            seen.add(candidate.childModel)
            while (true) {
                if (!seen.add(model)) return true
                val next = all.filter { it.childModel == model }.flatMap { it.keys }.firstOrNull { it.parentModel >= 0 } ?: break
                model = next.parentModel
            }
        }
        return false
    }

    // ---------- texto compacto para salvar no projeto ----------

    /** Uma linha por trilha: "child:model:bone|frame,parentModel,parentBone,o0 o1 ...;..." */
    fun encode(t: AttachTrack): String {
        val sb = StringBuilder()
        sb.append(t.childModel).append(':').append(t.childBone).append('|')
        t.keys.forEachIndexed { i, k ->
            if (i > 0) sb.append(';')
            sb.append(k.frame).append(',').append(k.parentModel).append(',').append(k.parentBone).append(',')
            val o = k.offset
            if (o != null && o.size >= 16) sb.append(o.joinToString(" ") { java.lang.Float.toString(it) })
        }
        return sb.toString()
    }

    fun decode(line: String): AttachTrack? {
        return try {
            val bar = line.indexOf('|')
            if (bar < 0) return null
            val head = line.substring(0, bar).split(':')
            if (head.size != 2) return null
            val keys = ArrayList<AttachKey>()
            val body = line.substring(bar + 1)
            if (body.isNotEmpty()) for (part in body.split(';')) {
                val f = part.split(',', limit = 4)
                if (f.size < 3) return null
                val off = if (f.size == 4 && f[3].isNotBlank()) {
                    val v = f[3].trim().split(' ').map { it.toFloat() }
                    if (v.size != 16 || v.any { !it.isFinite() }) return null
                    v.toFloatArray()
                } else null
                keys.add(AttachKey(f[0].toInt(), f[1].toInt(), f[2].toInt(), off))
            }
            AttachTrack(head[0].toInt(), head[1].toInt(), keys)
        } catch (e: NumberFormatException) {
            null
        }
    }
}
