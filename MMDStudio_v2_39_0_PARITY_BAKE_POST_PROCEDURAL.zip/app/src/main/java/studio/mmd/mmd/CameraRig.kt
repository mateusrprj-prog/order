package studio.mmd.mmd

import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.sin
import kotlin.math.tan

/**
 * v2.31.0 — Rig de câmera estilo MMD oficial (seguir osso, tremor, dolly zoom, órbita) + presets de curva.
 *
 * Trabalha sobre o vetor que [VmdCamera.evaluate] já produz: out = [dist, cx, cy, cz, rx, ry, rz, fov(graus)].
 * Tudo é determinístico pelo quadro (scrub e bake dão o mesmo resultado) e puro (sem Android).
 */
object CameraRig {

    // ---------- seguir osso (modelo/osso como alvo do centro da câmera) ----------

    /**
     * Move o centro da câmera em direção a [target] (posição de mundo do osso) somada a [offset].
     * [weight] 0..1 (1 = centro totalmente preso ao osso; ignora o centro do VMD naquele eixo ligado em [axes]).
     */
    fun follow(out: FloatArray, target: FloatArray?, offset: FloatArray = floatArrayOf(0f, 0f, 0f), weight: Float = 1f, axes: BooleanArray = booleanArrayOf(true, true, true)) {
        if (out.size < 8 || target == null || target.size < 3) return
        val w = if (weight.isFinite()) weight.coerceIn(0f, 1f) else 0f
        for (c in 0..2) {
            if (c < axes.size && !axes[c]) continue
            val t = target[c] + (if (c < offset.size) offset[c] else 0f)
            if (!t.isFinite()) continue
            out[1 + c] = out[1 + c] + (t - out[1 + c]) * w
        }
    }

    // ---------- tremor de câmera ----------

    /** Amplitudes em unidades do modelo (posição) e graus (rotação). [decayFrames] > 0 faz o tremor sumir ao longo do tempo. */
    class Shake(
        val posAmp: Float = 0.3f, val rotAmpDeg: Float = 0.4f, val frequencyHz: Float = 6f,
        val seed: Int = 1, val startFrame: Int = 0, val durationFrames: Int = 60, val decayFrames: Int = 0
    )

    private fun hash01(a: Int, b: Int): Float {
        var h = a * 374761393 + b * 668265263
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777215f
    }

    /** Soma de três senoides com fases/frequências sorteadas por seed e eixo; saída em -1..1. */
    private fun noise(seed: Int, axis: Int, t: Float): Float {
        var s = 0f
        for (k in 0..2) {
            val phase = hash01(seed * 31 + axis, k) * (2f * PI.toFloat())
            val fm = 1f + k * 0.77f + hash01(seed + 97, axis * 3 + k) * 0.35f
            s += sin(2f * PI.toFloat() * fm * t + phase) / (k + 1)
        }
        return s / 1.83f
    }

    fun applyShake(out: FloatArray, shake: Shake, frame: Float, fps: Float = 30f) {
        if (out.size < 8 || !frame.isFinite() || !(fps > 0f)) return
        val local = frame - shake.startFrame
        if (local < 0f || local > shake.durationFrames) return
        var amp = 1f
        if (shake.decayFrames > 0) amp = (1f - local / shake.decayFrames).coerceIn(0f, 1f)
        if (shake.durationFrames > 0) {
            val fade = (shake.durationFrames - local).coerceAtLeast(0f) / 4f
            amp *= fade.coerceIn(0f, 1f)   // últimos 4 quadros: some suavemente, sem salto
        }
        val t = local / fps * shake.frequencyHz
        for (c in 0..2) {
            out[1 + c] += noise(shake.seed, c, t) * shake.posAmp * amp
            out[4 + c] += (noise(shake.seed, 3 + c, t) * shake.rotAmpDeg * amp) * (PI.toFloat() / 180f)
        }
    }

    // ---------- dolly zoom ("efeito Vertigo") ----------

    /** FOV (graus) que mantém o sujeito com o mesmo tamanho na tela quando a distância muda de [dist0] para [dist]. */
    fun dollyZoomFov(fov0Deg: Float, dist0: Float, dist: Float): Float {
        if (!(fov0Deg > 0f && fov0Deg < 180f && dist0 > 0f && dist > 0f)) return fov0Deg
        val half = fov0Deg * (PI.toFloat() / 180f) / 2f
        val f = 2f * atan(tan(half) * dist0 / dist) * (180f / PI.toFloat())
        return if (f.isFinite()) f.coerceIn(1f, 179f) else fov0Deg
    }

    /** Gera keys de dolly zoom entre dois quadros: a distância vai de [distA] a [distB] e o FOV acompanha. */
    fun dollyZoomKeys(base: VmdCamera, startFrame: Int, endFrame: Int, distA: Float, distB: Float, fov0Deg: Float, steps: Int = 8): VmdCamera {
        var cam = base
        val n = steps.coerceIn(2, 240)
        val sample = FloatArray(8)
        for (i in 0..n) {
            val t = i / n.toFloat()
            val f = (startFrame + (endFrame - startFrame) * t).toInt().coerceAtLeast(0)
            cam.evaluate(f.toFloat(), sample)
            val d = distA + (distB - distA) * t
            cam = CameraMotionTools.put(
                cam, f,
                CameraPose(distance = d, x = sample[1], y = sample[2], z = sample[3], rx = sample[4], ry = sample[5], rz = sample[6], fov = dollyZoomFov(fov0Deg, distA, d))
            )
        }
        return cam
    }

    // ---------- órbita ----------

    /**
     * Gera uma câmera que orbita [center] (cx, cy, cz) de [startDeg] a [endDeg] ao longo de [frames] quadros.
     * O yaw vai em rot.y (rad); pitch fixo em rot.x. O sinal segue a convenção do VMD usada por [VmdCamera.evaluate];
     * não foi comparado com o MMD oficial.
     */
    fun orbit(center: FloatArray, distance: Float, pitchDeg: Float, startDeg: Float, endDeg: Float, frames: Int, fovDeg: Float = 45f, keys: Int = 12): VmdCamera {
        val n = keys.coerceIn(2, 360)
        val total = frames.coerceAtLeast(1)
        val deg = (PI / 180.0).toFloat()
        val fr = IntArray(n) { (total * it / (n - 1).toFloat()).toInt() }
        for (i in 1 until n) if (fr[i] <= fr[i - 1]) fr[i] = fr[i - 1] + 1
        val dist = FloatArray(n) { distance.coerceIn(0.1f, 10000f) }
        val pos = FloatArray(n * 3); val rot = FloatArray(n * 3); val fov = FloatArray(n) { fovDeg.coerceIn(1f, 179f) }
        val ip = ByteArray(n * 24)
        for (i in 0 until n) {
            val t = i / (n - 1).toFloat()
            pos[i * 3] = center.getOrElse(0) { 0f }; pos[i * 3 + 1] = center.getOrElse(1) { 10f }; pos[i * 3 + 2] = center.getOrElse(2) { 0f }
            rot[i * 3] = pitchDeg * deg
            rot[i * 3 + 1] = (startDeg + (endDeg - startDeg) * t) * deg
            rot[i * 3 + 2] = 0f
            for (c in 0 until 6) { val o = i * 24 + c * 4; ip[o] = 20; ip[o + 1] = 107; ip[o + 2] = 20; ip[o + 3] = 107 }
        }
        return VmdCamera(fr, dist, pos, rot, fov, ip)
    }
}

/**
 * Presets de curva do editor de interpolação do MMD oficial. Valores 0..127 (x1, y1, x2, y2) por canal.
 */
enum class CurvePreset(val x1: Int, val y1: Int, val x2: Int, val y2: Int) {
    LINEAR(20, 20, 107, 107),
    EASE_IN(64, 0, 127, 64),
    EASE_OUT(0, 64, 64, 127),
    EASE_IN_OUT(64, 0, 64, 127),
    FAST_START(0, 127, 64, 127),
    SLOW_END(0, 64, 40, 127),
    OVERSHOOT_LIKE(30, 0, 100, 127),
    STEP_LIKE(127, 0, 127, 0);

    companion object {
        /**
         * Aplica o preset nos keys [fromKey, toKey] (índices) da trilha, nos canais escolhidos
         * (0 = X, 1 = Y, 2 = Z, 3 = rotação). A curva de um segmento fica no key de chegada.
         */
        fun apply(t: VmdTrack, preset: CurvePreset, fromKey: Int, toKey: Int, channels: BooleanArray = booleanArrayOf(true, true, true, true)): VmdTrack {
            val n = minOf(t.frames.size, t.v.size / 7, t.ip.size / 16)
            if (n == 0) return t
            val ip = t.ip.copyOf()
            val lo = fromKey.coerceIn(0, n - 1); val hi = toKey.coerceIn(0, n - 1)
            for (k in lo..hi) {
                for (c in 0..3) {
                    if (c < channels.size && !channels[c]) continue
                    val o = k * 16
                    ip[o + c] = preset.x1.toByte(); ip[o + 4 + c] = preset.y1.toByte()
                    ip[o + 8 + c] = preset.x2.toByte(); ip[o + 12 + c] = preset.y2.toByte()
                }
            }
            return VmdTrack(t.frames, t.v, ip)
        }
    }
}
