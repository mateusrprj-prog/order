package studio.mmd.mocap

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Pós-processamento de keyframes de mocap: normalização de quaternion, continuidade de hemisfério,
 * remoção de picos isolados e suavização temporal configurável. Mantém quadros e nomes dos ossos.
 */
object MotionCleanup {
    fun clean(
        tracks: Map<String, List<Pair<Int, FloatArray>>>,
        strength: Float = 0.35f,
        passes: Int = 2,
        spikeThreshold: Float = 0.0f
    ): Map<String, List<Pair<Int, FloatArray>>> {
        val amount = strength.coerceIn(0f, 1f)
        val guard = spikeThreshold.coerceAtLeast(0f)
        if (tracks.isEmpty()) return tracks
        return tracks.mapValues { (_, source) ->
            if (source.isEmpty()) return@mapValues emptyList()
            var keys = source.sortedBy { it.first }.map { it.first to it.second.copyOf() }
            keys = sanitize(keys)
            if (keys.size < 3 || (amount <= 0f && guard <= 0f)) return@mapValues keys
            repeat(passes.coerceIn(1, 8)) {
                val next = keys.toMutableList()
                for (i in 1 until keys.lastIndex) {
                    val beforeKey = keys[i - 1]; val currentKey = keys[i]; val afterKey = keys[i + 1]
                    val before = beforeKey.second; val current = currentKey.second; val after = afterKey.second
                    if (before.size < 7 || current.size < 7 || after.size < 7) continue
                    val span = (afterKey.first - beforeKey.first).coerceAtLeast(1)
                    val time = ((currentKey.first - beforeKey.first).toFloat() / span).coerceIn(0f, 1f)
                    val mid = FloatArray(3) { before[it] + (after[it] - before[it]) * time }
                    val dx = current[0] - mid[0]; val dy = current[1] - mid[1]; val dz = current[2] - mid[2]
                    val deviation = sqrt(dx * dx + dy * dy + dz * dz)
                    var posBlend = amount
                    if (guard > 0f && deviation > guard) posBlend = max(posBlend, ((deviation - guard) / max(deviation, 1e-6f)).coerceIn(0f, 1f))
                    val out = current.copyOf()
                    for (c in 0..2) out[c] = current[c] + (mid[c] - current[c]) * posBlend
                    val q0 = floatArrayOf(before[3], before[4], before[5], before[6])
                    val q1 = floatArrayOf(after[3], after[4], after[5], after[6])
                    val qm = slerp(q0, q1, time)
                    val qc = floatArrayOf(current[3], current[4], current[5], current[6])
                    val q = slerp(qc, qm, amount)
                    for (c in 0..3) out[3 + c] = q[c]
                    next[i] = keys[i].first to out
                }
                keys = sanitize(next)
            }
            keys
        }
    }

    private fun sanitize(source: List<Pair<Int, FloatArray>>): List<Pair<Int, FloatArray>> {
        val out = source.map { (frame, original) ->
            val v = original.copyOf()
            if (v.size >= 7) {
                for (i in 0..2) if (!v[i].isFinite()) v[i] = 0f
                var len = 0f
                for (i in 3..6) { if (!v[i].isFinite()) v[i] = 0f; len += v[i] * v[i] }
                len = sqrt(len)
                if (len < 1e-8f) { v[3] = 0f; v[4] = 0f; v[5] = 0f; v[6] = 1f }
                else for (i in 3..6) v[i] /= len
            }
            frame to v
        }.sortedBy { it.first }.toMutableList()
        for (i in 1 until out.size) {
            val prev = out[i - 1].second; val cur = out[i].second
            if (prev.size < 7 || cur.size < 7) continue
            val dot = prev[3] * cur[3] + prev[4] * cur[4] + prev[5] * cur[5] + prev[6] * cur[6]
            if (dot < 0f) for (c in 3..6) cur[c] = -cur[c]
        }
        return out
    }

    private fun slerp(a0: FloatArray, b0: FloatArray, t0: Float): FloatArray {
        val a = normalized(a0); val b = normalized(b0); val t = t0.coerceIn(0f, 1f)
        var dot = 0f
        for (i in 0..3) dot += a[i] * b[i]
        val target = b.copyOf()
        if (dot < 0f) { dot = -dot; for (i in 0..3) target[i] = -target[i] }
        if (dot > 0.9995f) return normalized(FloatArray(4) { a[it] + (target[it] - a[it]) * t })
        val theta = kotlin.math.acos(dot.coerceIn(-1f, 1f)); val sinTheta = kotlin.math.sin(theta)
        val wa = kotlin.math.sin((1f - t) * theta) / sinTheta
        val wb = kotlin.math.sin(t * theta) / sinTheta
        return normalized(FloatArray(4) { a[it] * wa + target[it] * wb })
    }

    private fun normalized(q: FloatArray): FloatArray {
        val len = sqrt(q.sumOf { (it * it).toDouble() }.toFloat()).coerceAtLeast(1e-8f)
        return FloatArray(4) { q[it] / len }
    }
}
