package studio.mmd.scene

import org.json.JSONArray
import org.json.JSONObject

/** Transformação de um alvo da cena. Em personagens, não altera a pose nem as chaves dos ossos. */
data class RootTransform(
    val x: Float = 0f, val y: Float = 0f, val z: Float = 0f,
    val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f,
    val scale: Float = 1f
) {
    fun normalized(): RootTransform = copy(
        x = finite(x), y = finite(y), z = finite(z),
        rx = finite(rx), ry = finite(ry), rz = finite(rz),
        scale = (if (scale.isFinite()) scale else 1f).coerceIn(0.05f, 20f)
    )

    companion object {
        // Não reduzir ângulos para ±180°: 360°, 720° etc. são necessários para giros completos animados.
        private fun finite(v: Float): Float = if (v.isFinite()) v.coerceIn(-100000f, 100000f) else 0f
    }
}

data class RootTransformKey(val frame: Int, val transform: RootTransform)
data class RootTransformEntry(val targetId: String, val base: RootTransform = RootTransform(), val keys: List<RootTransformKey> = emptyList())

/** Estado animável e persistente por alvo: "model", "char:<id>" ou "prop:<id>" (objeto adicionado em Cena). */
data class RootTransformState(val entries: List<RootTransformEntry> = emptyList()) {
    fun entry(targetId: String): RootTransformEntry? = entries.firstOrNull { it.targetId == targetId }
    fun base(targetId: String): RootTransform = entry(targetId)?.base ?: RootTransform()
    fun keyFrames(targetId: String): IntArray = entry(targetId)?.keys?.map { it.frame }?.distinct()?.sorted()?.toIntArray() ?: intArrayOf()
    fun hasKey(targetId: String, frame: Int): Boolean = entry(targetId)?.keys?.any { it.frame == frame } == true

    fun ensure(targetId: String, initial: RootTransform = RootTransform()): RootTransformState {
        if (entry(targetId) != null) return this
        return copy(entries = entries + RootTransformEntry(targetId, initial.normalized()))
    }

    /** Editar num frame com key existente atualiza essa key; caso contrário altera a transformação-base. */
    fun edit(targetId: String, frame: Int, transform: RootTransform): RootTransformState {
        val e = entry(targetId) ?: RootTransformEntry(targetId)
        val v = transform.normalized()
        val keyMode = e.keys.isNotEmpty()
        val keys = if (keyMode) (e.keys.filterNot { it.frame == frame } + RootTransformKey(frame.coerceAtLeast(0), v)).sortedBy { it.frame } else e.keys
        val updated = e.copy(base = if (keyMode) e.base else v, keys = keys)
        return put(updated)
    }

    fun addKey(targetId: String, frame: Int): RootTransformState {
        val e = entry(targetId) ?: RootTransformEntry(targetId)
        val value = sample(targetId, frame)
        return put(e.copy(keys = (e.keys.filterNot { it.frame == frame } + RootTransformKey(frame.coerceAtLeast(0), value)).sortedBy { it.frame }))
    }

    fun removeKey(targetId: String, frame: Int): RootTransformState {
        val e = entry(targetId) ?: return this
        return put(e.copy(keys = e.keys.filterNot { it.frame == frame }))
    }

    fun removeTarget(targetId: String): RootTransformState =
        copy(entries = entries.filterNot { it.targetId == targetId })

    /** Duplica estado base e keyframes para um novo personagem (ex.: duplicar no Outliner). */
    fun duplicateTarget(sourceId: String, newId: String): RootTransformState {
        val source = entry(sourceId) ?: return this
        return put(source.copy(targetId = newId, keys = source.keys.toList()))
    }

    fun sample(targetId: String, frame: Int): RootTransform {
        val e = entry(targetId) ?: return RootTransform()
        val keys = e.keys.sortedBy { it.frame }
        if (keys.isEmpty()) return e.base
        val before = keys.lastOrNull { it.frame <= frame }
        val after = keys.firstOrNull { it.frame > frame }
        if (before == null) {
            val first = keys.first()
            if (first.frame <= 0) return first.transform
            return interpolate(e.base, first.transform, (frame.toFloat() / first.frame).coerceIn(0f, 1f))
        }
        if (after == null) return before.transform
        val span = (after.frame - before.frame).coerceAtLeast(1)
        return interpolate(before.transform, after.transform, ((frame - before.frame).toFloat() / span).coerceIn(0f, 1f))
    }

    private fun put(value: RootTransformEntry): RootTransformState =
        copy(entries = (entries.filterNot { it.targetId == value.targetId } + value).sortedBy { it.targetId })

    companion object {
        private fun angle(a: Float, b: Float, t: Float): Float = a + (b - a) * t

        private fun interpolate(a: RootTransform, b: RootTransform, t: Float) = RootTransform(
            a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t,
            angle(a.rx, b.rx, t), angle(a.ry, b.ry, t), angle(a.rz, b.rz, t),
            a.scale + (b.scale - a.scale) * t
        )
    }
}

object RootTransformCodec {
    const val FILE = "root_transforms.json"
    const val VERSION = 1

    fun encode(state: RootTransformState): String {
        val entries = JSONArray()
        state.entries.forEach { e ->
            fun putTransform(t: RootTransform) = JSONObject()
                .put("x", t.x.toDouble()).put("y", t.y.toDouble()).put("z", t.z.toDouble())
                .put("rx", t.rx.toDouble()).put("ry", t.ry.toDouble()).put("rz", t.rz.toDouble())
                .put("scale", t.scale.toDouble())
            val keys = JSONArray()
            e.keys.sortedBy { it.frame }.forEach { k -> keys.put(JSONObject().put("frame", k.frame).put("transform", putTransform(k.transform))) }
            entries.put(JSONObject().put("targetId", e.targetId).put("base", putTransform(e.base)).put("keys", keys))
        }
        return JSONObject().put("formatVersion", VERSION).put("entries", entries).toString()
    }

    fun decode(text: String): RootTransformState {
        return try {
            val root = JSONObject(text)
            if (root.optInt("formatVersion", 0) > VERSION) {
                RootTransformState()
            } else {
                fun readTransform(j: JSONObject?): RootTransform {
                    if (j == null) return RootTransform()
                    return RootTransform(
                        j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(),
                        j.optDouble("rx", 0.0).toFloat(), j.optDouble("ry", 0.0).toFloat(), j.optDouble("rz", 0.0).toFloat(),
                        j.optDouble("scale", 1.0).toFloat()
                    ).normalized()
                }
                val a = root.optJSONArray("entries") ?: JSONArray()
                val result = ArrayList<RootTransformEntry>()
                val seen = HashSet<String>()
                for (i in 0 until a.length()) {
                    val j = a.optJSONObject(i) ?: continue
                    val id = j.optString("targetId", "")
                    if (id.isBlank() || !seen.add(id)) continue
                    val keysArray = j.optJSONArray("keys") ?: JSONArray()
                    val keys = ArrayList<RootTransformKey>()
                    val seenFrames = HashSet<Int>()
                    for (k in 0 until keysArray.length()) {
                        val key = keysArray.optJSONObject(k) ?: continue
                        val frame = key.optInt("frame", -1)
                        if (frame < 0 || !seenFrames.add(frame)) continue
                        keys.add(RootTransformKey(frame, readTransform(key.optJSONObject("transform"))))
                    }
                    result.add(RootTransformEntry(id, readTransform(j.optJSONObject("base")), keys.sortedBy { it.frame }))
                }
                RootTransformState(result)
            }
        } catch (_: Throwable) {
            RootTransformState()
        }
    }
}
