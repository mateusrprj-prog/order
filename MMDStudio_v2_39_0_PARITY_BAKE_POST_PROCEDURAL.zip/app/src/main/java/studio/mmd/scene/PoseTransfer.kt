package studio.mmd.scene

import studio.mmd.cartoon.Built
import studio.mmd.cartoon.CartoonMerge
import studio.mmd.edit.BKey
import studio.mmd.edit.MKey
import studio.mmd.edit.PoseSnap
import studio.mmd.mmd.VmdMotion
import kotlin.math.sqrt

/**
 * v1.29.9 (8.3d-A) — poses entre personagens. A biblioteca de poses (PoseLib) é do projeto, então uma pose salva do principal
 * pode ser aplicada num extra (e vice-versa). Extras não têm Editor: aqui a pose é lida/gravada direto no VmdMotion deles. Puro (JVM).
 */
object PoseTransfer {
    private val LINEAR_IP = ByteArray(16) { if (it < 8) 20 else 107 }

    /** Foto da pose do movimento [mo] no quadro [frame] (interpolação linear entre keys; curvas Bézier ignoradas). Movimento nulo = pose vazia. */
    fun capture(mo: VmdMotion?, frame: Int, name: String): PoseSnap {
        val bones = HashMap<String, FloatArray>(); val morphs = HashMap<String, Float>()
        if (mo != null) {
            for ((n, t) in mo.bones) if (t.frames.isNotEmpty()) bones[n] = sampleBone(t.frames, t.v, frame.toFloat())
            for ((n, t) in mo.morphs) if (t.frames.isNotEmpty()) { val w = sampleMorph(t.frames, t.w, frame.toFloat()); if (w != 0f || t.frames.isNotEmpty()) morphs[n] = w }
        }
        return PoseSnap(name, bones, morphs)
    }

    /** Grava a pose como key no quadro [frame] do movimento [old] (nulo = extra parado). Ossos/morphs que o modelo não tem são ignorados. */
    fun apply(old: VmdMotion?, pose: PoseSnap, frame: Int, validBones: Set<String>?, validMorphs: Set<String>?): CartoonMerge.Result {
        val b = Built(pose.bones.mapValues { (_, v) -> listOf(BKey(frame, v.copyOf(), LINEAR_IP.copyOf())) },
            pose.morphs.mapValues { (_, w) -> listOf(MKey(frame, w)) }, frame, frame)
        return CartoonMerge.merge(old, b, validBones, validMorphs)
    }

    /** Fração (0..1) dos ossos da pose que existem no modelo de destino; 1 se a pose não tem ossos. */
    fun compat(pose: PoseSnap, validBones: Set<String>): Float =
        if (pose.bones.isEmpty()) 1f else pose.bones.keys.count { it in validBones }.toFloat() / pose.bones.size

    private fun sampleBone(fr: IntArray, v: FloatArray, f: Float): FloatArray {
        val o = FloatArray(7)
        var i = -1
        for (k in fr.indices) if (fr[k] <= f) i = k else break
        if (i < 0) { v.copyInto(o, 0, 0, 7); return o }
        if (i == fr.size - 1) { v.copyInto(o, 0, i * 7, i * 7 + 7); return o }
        val s = (f - fr[i]) / (fr[i + 1] - fr[i]).toFloat()
        for (c in 0..2) o[c] = v[i * 7 + c] + (v[(i + 1) * 7 + c] - v[i * 7 + c]) * s
        var dot = 0f
        for (c in 0..3) dot += v[i * 7 + 3 + c] * v[(i + 1) * 7 + 3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val q = v[i * 7 + 3 + c] * (1 - s) + v[(i + 1) * 7 + 3 + c] * sg * s; o[3 + c] = q; len += q * q }
        len = sqrt(len)
        if (len > 1e-8f) for (c in 3..6) o[c] /= len
        return o
    }

    private fun sampleMorph(fr: IntArray, w: FloatArray, f: Float): Float {
        var i = -1
        for (k in fr.indices) if (fr[k] <= f) i = k else break
        if (i < 0) return w[0]
        if (i == fr.size - 1) return w[i]
        val s = (f - fr[i]) / (fr[i + 1] - fr[i]).toFloat()
        return w[i] + (w[i + 1] - w[i]) * s
    }
}
