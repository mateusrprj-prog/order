package studio.mmd.scene

import studio.mmd.project.PropMeta

/**
 * v1.29.8 (8.4b, última fatia): a hierarquia do Outliner passa a vir do Scene Graph.
 * O estado do projeto (modelo principal, acessórios, extras do Elenco, grupos do Outliner) é projetado num [SceneGraph]
 * (ids = chaves de camada: "model", "prop:<id>", "char:<id>", "grp:<id>"). Kotlin puro, testável na JVM.
 *  - acessório preso a osso  -> filho do modelo principal, com attachBone;
 *  - membro de grupo (solto) -> filho do nó de grupo;
 *  - acessório preso a osso que também está num grupo: vale o osso (a dependência manda; o grupo é só organização).
 */
object SceneHierarchy {
    const val MAIN = "model"

    fun build(modelName: String, hasModel: Boolean, props: List<PropMeta>, cast: List<CastMeta>, out: OutlinerState): SceneGraph {
        val groupOf = HashMap<String, String>()
        for (g in out.groups) for (m in g.members) groupOf.putIfAbsent(m, g.id)
        val list = ArrayList<SceneNode>()
        for (g in out.groups) list.add(SceneNode(g.id, g.name, NodeType.GROUP))
        if (hasModel) list.add(SceneNode(MAIN, modelName.ifBlank { "Personagem" }, NodeType.CHARACTER, parentId = groupOf[MAIN], asset = "model"))
        for (p in props) {
            val key = "prop:" + p.id
            val attached = p.bone.isNotEmpty() && hasModel
            list.add(SceneNode(key, p.name, NodeType.PROP, parentId = if (attached) MAIN else groupOf[key],
                local = Transform(p.x, p.y, p.z, p.rx, p.ry, p.rz, p.s, p.s, p.s), asset = p.id + "." + p.ext, attachBone = if (attached) p.bone else ""))
        }
        for (c in cast) {
            val key = "char:" + c.id
            list.add(SceneNode(key, c.name, NodeType.CHARACTER, parentId = groupOf[key], local = Transform(c.x, c.y, c.z, 0f, c.ry, 0f, c.s, c.s, c.s), asset = c.id + "." + c.ext))
        }
        val ids = list.map { it.id }.toSet()
        // referência inválida nunca entra: pai que não existe vira raiz
        val fixed = list.map { if (it.parentId != null && it.parentId !in ids) it.copy(parentId = null, attachBone = "") else it }
        return SceneGraph(fixed, if (hasModel) MAIN else cast.firstOrNull()?.let { "char:" + it.id })
    }

    /** Chaves de camada que dependem de outro nó por osso (mostrar recuadas no Outliner). */
    fun attachedKeys(g: SceneGraph): Set<String> = g.nodes.filter { it.attachBone.isNotEmpty() }.map { it.id }.toSet()

    /** Problemas de integridade: pai inexistente, ciclo, osso sem pai personagem. Vazio = grafo consistente. */
    fun problems(g: SceneGraph): List<String> {
        val out = ArrayList<String>(); val ids = g.nodes.map { it.id }.toSet()
        for (n in g.nodes) {
            if (n.parentId != null && n.parentId !in ids) out.add("${n.id}: pai inexistente ${n.parentId}")
            if (n.attachBone.isNotEmpty() && g.get(n.parentId ?: "")?.type != NodeType.CHARACTER) out.add("${n.id}: osso sem pai personagem")
            var cur = n.parentId; var guard = 0
            while (cur != null && guard++ <= g.nodes.size) cur = g.get(cur)?.parentId
            if (guard > g.nodes.size) out.add("${n.id}: ciclo na hierarquia")
        }
        return out
    }

    /** Remove só o nó [id] e solta os filhos dele para a raiz (sem osso), em vez de apagá-los: nenhuma referência inválida sobra. */
    fun removeKeepingChildren(g: SceneGraph, id: String): SceneGraph {
        if (g.get(id) == null) return g
        val nodes = g.nodes.filter { it.id != id }.map { if (it.parentId == id) it.copy(parentId = null, attachBone = "") else it }
        val active = if (g.activeId == id) nodes.firstOrNull { it.type == NodeType.CHARACTER }?.id else g.activeId
        return SceneGraph(nodes, active)
    }
}
