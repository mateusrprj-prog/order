package studio.mmd.scene

/**
 * v1.29.11 — 8.3d-B1: base lógica do "personagem ativo de edição". Puro (sem Android/Compose), testável em JVM.
 * O principal usa o id [MAIN]; extras usam o id do Elenco (CastMeta.id). A UI (B2) e o renderer (B3) consomem isto.
 */
object ActiveCharacter {
    const val MAIN = "model"

    /** Resolve o ativo: se o pedido não existe mais (excluído/não abriu), volta ao principal. */
    fun resolve(requested: String?, castIds: Collection<String>): String =
        if (requested == null || requested == MAIN || requested !in castIds) MAIN else requested

    /** Rótulo para a UI ("Principal" ou o nome do extra). */
    fun label(id: String, castNames: Map<String, String>, mainName: String): String =
        if (id == MAIN) mainName.ifBlank { "Principal" } else castNames[id] ?: "Personagem"

    /** Só edita se não estiver bloqueado no Outliner. [lockedIds] usa os mesmos ids do Elenco (o principal = [MAIN]). */
    fun canEdit(id: String, lockedIds: Set<String>): Boolean = id !in lockedIds
}

/**
 * Uma sessão de edição (ex.: um Editor) por personagem EXTRA, criada sob demanda. Genérica em [T] para não depender do
 * Editor (que usa Compose). Garante: editar um extra nunca toca a sessão de outro, e só grava o que foi mexido.
 */
class EditSessions<T : Any>(private val create: (id: String) -> T?) {
    private val map = LinkedHashMap<String, T>()
    private val dirty = LinkedHashSet<String>()

    /** Sessão do personagem (cria na 1ª vez). null se [create] não conseguir (ex.: modelo não abriu). */
    fun get(id: String): T? = map[id] ?: create(id)?.also { map[id] = it }
    fun has(id: String) = id in map
    fun openIds(): List<String> = map.keys.toList()

    fun markDirty(id: String) { if (id in map) dirty.add(id) }
    fun isDirty(id: String) = id in dirty
    fun dirtyIds(): List<String> = dirty.toList()

    /** Grava só os sujos via [save]; quem gravar com sucesso (true) deixa de ser sujo. Devolve quantos gravou. */
    fun flush(save: (id: String, session: T) -> Boolean): Int {
        var n = 0
        for (id in dirty.toList()) { val s = map[id] ?: run { dirty.remove(id); null } ?: continue; if (save(id, s)) { dirty.remove(id); n++ } }
        return n
    }

    /** Descarta a sessão (personagem excluído, ou movimento trocado por fora, p.ex. Cartoon/pose/“Trocar movimento”). */
    fun drop(id: String) { map.remove(id); dirty.remove(id) }
    fun clear() { map.clear(); dirty.clear() }
}
