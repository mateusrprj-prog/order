package studio.mmd.scene

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.29.0 (Release 8, fatia 8.4a): estado do Outliner, em Kotlin puro (sem android.*), testável na JVM.
 *
 * As chaves são as MESMAS do painel de camadas e do renderer ("model", "prop:<id>", "char:<id>", ...), então nada é duplicado:
 * o que já existe (modelo, props, elenco) continua sendo a fonte da verdade; aqui ficam só as propriedades de organização
 * que o app não tinha: nome do modelo, bloqueio, visibilidade no render, grupos e ordem. Persistido em `outliner.json`.
 *
 * Tudo é imutável: cada operação devolve um novo [OutlinerState].
 */
data class OutGroup(val id: String, val name: String, val members: List<String>, val collapsed: Boolean = false)

/** Uma linha já ordenada. [group] = true: cabeçalho de grupo (key = id do grupo). [indent] 0 = raiz, 1 = dentro de grupo. */
data class OutRow(val key: String, val group: Boolean, val indent: Int)

data class OutlinerState(
    val names: Map<String, String> = emptyMap(),
    val locked: Set<String> = emptySet(),
    val renderOff: Set<String> = emptySet(),
    val groups: List<OutGroup> = emptyList(),
    val order: List<String> = emptyList()
) {
    companion object {
        const val GROUP_PREFIX = "grp:"
        /** Só estes tipos de camada podem ser trancados/agrupados/reordenados/excluídos; luz, câmera e áudio são únicos e fixos. */
        fun lockable(key: String) = key.startsWith("prop:") || key.startsWith("char:")
        fun groupable(key: String) = key == "model" || lockable(key)
        fun isGroup(key: String) = key.startsWith(GROUP_PREFIX)
    }

    fun groupOf(key: String): OutGroup? = groups.firstOrNull { key in it.members }
    fun group(id: String): OutGroup? = groups.firstOrNull { it.id == id }
    fun isLocked(key: String): Boolean = key in locked
    fun nameOf(key: String, fallback: String): String = names[key]?.takeIf { it.isNotBlank() } ?: fallback

    fun rename(key: String, name: String): OutlinerState {
        val n = name.trim()
        if (n.isEmpty()) return this
        return if (isGroup(key)) copy(groups = groups.map { if (it.id == key) it.copy(name = n) else it }) else copy(names = names + (key to n))
    }

    fun toggleLock(key: String): OutlinerState {
        if (!lockable(key)) return this
        return copy(locked = if (key in locked) locked - key else locked + key)
    }

    fun toggleRenderOff(key: String): OutlinerState = copy(renderOff = if (key in renderOff) renderOff - key else renderOff + key)

    fun toggleCollapse(groupId: String): OutlinerState =
        copy(groups = groups.map { if (it.id == groupId) it.copy(collapsed = !it.collapsed) else it })

    /** Cria um grupo com [keys] (tira cada uma do grupo antigo). Chaves não agrupáveis e repetidas são ignoradas. Vazio = sem mudança. */
    fun makeGroup(keys: List<String>, id: String, name: String): OutlinerState {
        val ks = keys.filter { groupable(it) }.distinct()
        if (ks.isEmpty() || groups.any { it.id == id }) return this
        val cleaned = groups.map { it.copy(members = it.members.filter { m -> m !in ks }) }.filter { it.members.isNotEmpty() }
        val gid = if (isGroup(id)) id else GROUP_PREFIX + id
        return copy(groups = cleaned + OutGroup(gid, name.trim().ifEmpty { "Grupo" }, ks), order = order.filter { it !in ks })
    }

    /** Coloca [key] no grupo existente [groupId] (tirando do anterior). */
    fun addToGroup(key: String, groupId: String): OutlinerState {
        if (!groupable(key) || group(groupId) == null) return this
        val g2 = groups.map { it.copy(members = it.members.filter { m -> m != key }) }
            .map { if (it.id == groupId) it.copy(members = it.members + key) else it }
            .filter { it.members.isNotEmpty() || it.id == groupId }
        return copy(groups = g2, order = order.filter { it != key })
    }

    fun removeFromGroup(key: String): OutlinerState {
        if (groupOf(key) == null) return this
        return copy(groups = groups.map { it.copy(members = it.members.filter { m -> m != key }) }.filter { it.members.isNotEmpty() })
    }

    /** Desfaz o grupo: os membros voltam para a raiz (nenhum objeto é apagado). */
    fun ungroup(groupId: String): OutlinerState = copy(groups = groups.filter { it.id != groupId }, order = order.filter { it != groupId })

    /** Remove tudo que se refere a [key] (objeto excluído): nome, bloqueio, render, grupo e ordem. Sem referência inválida. */
    fun forget(key: String): OutlinerState = copy(
        names = names - key, locked = locked - key, renderOff = renderOff - key, order = order - key,
        groups = groups.map { it.copy(members = it.members.filter { m -> m != key }) }.filter { it.members.isNotEmpty() }
    )

    /** Remove referências a chaves que não existem mais (ex.: personagem que não abriu, arquivo apagado). */
    fun prune(valid: Set<String>): OutlinerState = copy(
        names = names.filterKeys { it in valid }, locked = locked.filter { it in valid }.toSet(), renderOff = renderOff.filter { it in valid }.toSet(),
        groups = groups.map { it.copy(members = it.members.filter { m -> m in valid }) }.filter { it.members.isNotEmpty() },
        order = order.filter { it in valid || group(it) != null }
    )

    /**
     * Linhas na ordem final. [natural] = chaves existentes na ordem padrão do app. Itens sem posição em [order] mantêm a ordem natural
     * (depois dos que têm). Grupos recolhidos mostram só o cabeçalho.
     */
    fun arrange(natural: List<String>): List<OutRow> {
        val valid = natural.toSet()
        val live = groups.map { it.copy(members = it.members.filter { m -> m in valid }) }.filter { it.members.isNotEmpty() }
        val grouped = live.flatMap { it.members }.toSet()
        val top = ArrayList<String>()
        top.addAll(natural.filter { it !in grouped })
        top.addAll(live.map { it.id })
        val pos = HashMap<String, Int>(); order.forEachIndexed { i, k -> pos[k] = i }
        val sorted = top.withIndex().sortedWith(compareBy({ pos[it.value] ?: Int.MAX_VALUE }, { it.index })).map { it.value }
        val out = ArrayList<OutRow>()
        for (k in sorted) {
            val g = live.firstOrNull { it.id == k }
            if (g == null) out.add(OutRow(k, false, 0))
            else { out.add(OutRow(g.id, true, 0)); if (!g.collapsed) g.members.forEach { out.add(OutRow(it, false, 1)) } }
        }
        return out
    }

    /** Sobe (-1) ou desce (+1) [key] entre os irmãos (mesmo grupo, ou raiz). Só reordena itens agrupáveis ou grupos. */
    fun move(key: String, delta: Int, natural: List<String>): OutlinerState {
        if (!(groupable(key) || isGroup(key))) return this
        val g = groupOf(key)
        if (g != null) {
            val i = g.members.indexOf(key); val j = (i + delta).coerceIn(0, g.members.size - 1)
            if (i == j) return this
            val m = g.members.toMutableList(); val t = m[i]; m[i] = m[j]; m[j] = t
            return copy(groups = groups.map { if (it.id == g.id) it.copy(members = m) else it })
        }
        val rootKeys = arrange(natural).filter { it.indent == 0 }.map { it.key }
        val i = rootKeys.indexOf(key); if (i < 0) return this
        val j = (i + delta).coerceIn(0, rootKeys.size - 1); if (i == j) return this
        val m = rootKeys.toMutableList(); val t = m[i]; m[i] = m[j]; m[j] = t
        return copy(order = m)
    }

    // ---------------- persistência (outliner.json)
    fun toJson(): String {
        val gs = JSONArray(); groups.forEach { g ->
            gs.put(JSONObject().put("id", g.id).put("name", g.name).put("collapsed", g.collapsed).put("members", JSONArray(g.members)))
        }
        val nm = JSONObject(); names.forEach { (k, v) -> nm.put(k, v) }
        return JSONObject().put("formatVersion", 1).put("names", nm).put("locked", JSONArray(locked.toList()))
            .put("renderOff", JSONArray(renderOff.toList())).put("groups", gs).put("order", JSONArray(order)).toString()
    }

    class Loaded(val state: OutlinerState, val warnings: List<String>)

    object Codec {
        const val FILE = "outliner.json"
        private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optString(it, "").takeIf { s -> s.isNotEmpty() } }

        /** Tolerante: JSON ruim ou de versão nova vira estado vazio + aviso; nunca exceção. */
        fun fromJson(text: String): Loaded {
            val w = ArrayList<String>()
            val r = try { JSONObject(text) } catch (e: Exception) { return Loaded(OutlinerState(), listOf("outliner.json ilegível: ${e.message}")) }
            if (r.optInt("formatVersion", 0) > 1) return Loaded(OutlinerState(), listOf("outliner.json é de versão mais nova; organização ignorada"))
            val names = HashMap<String, String>(); r.optJSONObject("names")?.let { o -> o.keys().forEach { k -> o.optString(k, "").takeIf { v -> v.isNotBlank() }?.let { v -> names[k] = v } } }
            val seen = HashSet<String>(); val groups = ArrayList<OutGroup>(); val used = HashSet<String>()
            val ga = r.optJSONArray("groups")
            if (ga != null) for (i in 0 until ga.length()) {
                val j = ga.optJSONObject(i) ?: continue
                val id = j.optString("id", ""); if (id.isEmpty() || !seen.add(id)) { w.add("grupo $i inválido ou repetido"); continue }
                val ms = strings(j.optJSONArray("members")).filter { used.add(it) }
                if (ms.isEmpty()) continue
                groups.add(OutGroup(id, j.optString("name", "Grupo").ifBlank { "Grupo" }, ms, j.optBoolean("collapsed", false)))
            }
            return Loaded(OutlinerState(names, strings(r.optJSONArray("locked")).toSet(), strings(r.optJSONArray("renderOff")).toSet(), groups, strings(r.optJSONArray("order"))), w)
        }
    }
}

/**
 * v1.29.1 (8.4b): histórico genérico de desfazer/refazer por instantâneos (imutáveis). [push] guarda o estado ANTES de uma mudança
 * e zera o refazer; [undo]/[redo] recebem o estado atual e devolvem o que deve ser restaurado (null = nada a fazer).
 */
class History<T>(private val limit: Int = 50) {
    private val past = ArrayList<T>()
    private val future = ArrayList<T>()
    val canUndo get() = past.isNotEmpty()
    val canRedo get() = future.isNotEmpty()
    fun push(before: T) { past.add(before); if (past.size > limit) past.removeAt(0); future.clear() }
    fun undo(current: T): T? { if (past.isEmpty()) return null; future.add(current); return past.removeAt(past.size - 1) }
    fun redo(current: T): T? { if (future.isEmpty()) return null; past.add(current); return future.removeAt(future.size - 1) }
    fun clear() { past.clear(); future.clear() }
}
