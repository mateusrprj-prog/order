package studio.mmd.scene

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.27.0 (Release 8, fatia 8.3c): personagem EXTRA da cena (além do modelo principal).
 * Cada um tem arquivo de modelo próprio (`cast/<id>.<ext>`), movimento próprio (`cast/<id>.vmd`, opcional) e transformação própria.
 * [x],[y],[z] em unidades do viewport; [ry] = giro em graus no eixo Y; [s] = escala uniforme. [motion] = nome mostrado do movimento ("" = parado).
 */
data class CastMeta(
    val id: String, val name: String, val ext: String,
    val x: Float = 0f, val y: Float = 0f, val z: Float = 0f, val ry: Float = 0f, val s: Float = 1f,
    val motion: String = ""
)

/** Leitura/gravação do `cast.json`. Tolerante: entrada inválida vira lista vazia + aviso, nunca exceção. */
object CastCodec {
    const val FILE = "cast.json"
    const val VERSION = 1

    class Loaded(val cast: List<CastMeta>, val warnings: List<String>)

    fun toJson(list: List<CastMeta>): String {
        val a = JSONArray()
        list.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("ext", c.ext)
                .put("x", c.x.toDouble()).put("y", c.y.toDouble()).put("z", c.z.toDouble())
                .put("ry", c.ry.toDouble()).put("s", c.s.toDouble()).put("motion", c.motion))
        }
        return JSONObject().put("formatVersion", VERSION).put("cast", a).toString()
    }

    fun fromJson(text: String): Loaded {
        val warns = ArrayList<String>()
        val root = try { JSONObject(text) } catch (e: Exception) { return Loaded(emptyList(), listOf("cast.json ilegível: ${e.message}")) }
        val ver = root.optInt("formatVersion", 0)
        if (ver > VERSION) return Loaded(emptyList(), listOf("cast.json é de uma versão mais nova ($ver); personagens extras ignorados"))
        val a = root.optJSONArray("cast") ?: return Loaded(emptyList(), listOf("cast.json sem lista 'cast'"))
        val out = ArrayList<CastMeta>(); val seen = HashSet<String>()
        for (i in 0 until a.length()) {
            val j = a.optJSONObject(i)
            if (j == null) { warns.add("item $i do elenco não é um objeto"); continue }
            val id = j.optString("id", "")
            if (id.isEmpty()) { warns.add("item $i do elenco sem id"); continue }
            if (!seen.add(id)) { warns.add("id duplicado no elenco: $id"); continue }
            out.add(CastMeta(id, j.optString("name", "personagem"), j.optString("ext", "zip"),
                j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(),
                j.optDouble("ry", 0.0).toFloat(), j.optDouble("s", 1.0).toFloat().coerceIn(0.05f, 20f), j.optString("motion", "")))
        }
        return Loaded(out, warns)
    }

    /** Relógio global: a duração da cena é a maior entre a atual e a de cada movimento (quadros de 30 fps). */
    fun totalFrames(current: Int, motionMaxFrames: List<Int>): Int = maxOf(current, (motionMaxFrames.maxOrNull() ?: -1) + 1)
}
