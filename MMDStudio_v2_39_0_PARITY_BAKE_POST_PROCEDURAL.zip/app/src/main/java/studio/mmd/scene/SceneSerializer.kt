package studio.mmd.scene

import org.json.JSONArray
import org.json.JSONObject

/** Resultado de ler um scenegraph.json: o grafo + avisos do que foi corrigido (nada é descartado em silêncio). */
data class SceneLoad(val graph: SceneGraph, val warnings: List<String>)

/** Formato do scenegraph.json (versão própria, independente do project.json). Não usa o scene.json antigo, que guarda só os props. */
object SceneSerializer {
    const val VERSION = 1
    const val FILE = "scenegraph.json"

    fun toJson(g: SceneGraph): String {
        val arr = JSONArray()
        for (n in g.nodes) {
            val t = n.local
            arr.put(JSONObject().put("id", n.id).put("name", n.name).put("type", n.type.name)
                .put("parent", n.parentId ?: JSONObject.NULL).put("visible", n.visible).put("locked", n.locked)
                .put("asset", n.asset).put("bone", n.attachBone)
                .put("t", JSONArray(listOf(t.px, t.py, t.pz, t.rx, t.ry, t.rz, t.sx, t.sy, t.sz).map { it.toDouble() })))
        }
        return JSONObject().put("version", VERSION).put("active", g.activeId ?: JSONObject.NULL).put("nodes", arr).toString()
    }

    /** Lança IllegalArgumentException se o texto não for um grafo válido (JSON quebrado, versão mais nova). Problemas parciais viram avisos. */
    fun fromJson(text: String): SceneLoad {
        val j = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("scenegraph.json ilegível: ${e.message}") }
        val ver = j.optInt("version", 0)
        if (ver < 1) throw IllegalArgumentException("scenegraph.json sem versão")
        if (ver > VERSION) throw IllegalArgumentException("scenegraph.json criado por versão mais nova do app (formato $ver)")
        val warns = ArrayList<String>()
        val arr = j.optJSONArray("nodes") ?: throw IllegalArgumentException("scenegraph.json sem lista de nós")
        val raw = ArrayList<SceneNode>(); val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: run { warns.add("nó #$i ignorado: não é objeto"); null } ?: continue
            val id = o.optString("id", "")
            if (id.isBlank()) { warns.add("nó #$i ignorado: sem id"); continue }
            if (!seen.add(id)) { warns.add("nó '$id' duplicado ignorado"); continue }
            val type = try { NodeType.valueOf(o.optString("type", "")) } catch (e: Exception) { warns.add("nó '$id' ignorado: tipo desconhecido '${o.optString("type")}'"); continue }
            val tv = o.optJSONArray("t")
            val f = FloatArray(9) { k -> if (tv != null && k < tv.length()) tv.optDouble(k, if (k >= 6) 1.0 else 0.0).toFloat() else if (k >= 6) 1f else 0f }
            raw.add(SceneNode(id, o.optString("name", id), type, if (o.isNull("parent")) null else o.optString("parent", "").ifBlank { null },
                o.optBoolean("visible", true), o.optBoolean("locked", false), Transform(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8]),
                o.optString("asset", ""), o.optString("bone", "")))
        }
        // pais inexistentes ou ciclos: o nó vai para a raiz, com aviso
        val ids = raw.map { it.id }.toSet()
        val byId = raw.associateBy { it.id }
        val fixed = raw.map { n ->
            var cur: SceneNode? = n; var guard = 0; var cyc = false
            while (cur?.parentId != null && guard++ <= raw.size) cur = byId[cur.parentId]
            if (guard > raw.size) cyc = true
            when {
                n.parentId != null && n.parentId !in ids -> { warns.add("nó '${n.id}': pai '${n.parentId}' não existe; movido para a raiz"); n.copy(parentId = null, attachBone = "") }
                cyc -> { warns.add("nó '${n.id}': ciclo de hierarquia; movido para a raiz"); n.copy(parentId = null, attachBone = "") }
                n.attachBone.isNotEmpty() && n.parentId?.let { byId[it] }?.type != NodeType.CHARACTER -> { warns.add("nó '${n.id}': osso sem pai personagem; ligação removida"); n.copy(attachBone = "") }
                else -> n
            }
        }
        var active = if (j.isNull("active")) null else j.optString("active", "").ifBlank { null }
        if (active != null && fixed.none { it.id == active && it.type == NodeType.CHARACTER }) {
            warns.add("personagem ativo '$active' inválido; usando o primeiro personagem"); active = null
        }
        if (active == null) active = fixed.firstOrNull { it.type == NodeType.CHARACTER }?.id
        return SceneLoad(SceneGraph(fixed, active), warns)
    }
}
