package studio.mmd.scene

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v1.29.10 — 8.3d-C: empacota os VMDs de todos os personagens (principal + extras) num .zip. Puro (sem Android). */
object CastExport {
    /** Nome de arquivo seguro e único dentro do zip: troca caracteres proibidos e acrescenta _2, _3… em repetidos. */
    fun uniqueNames(names: List<String>): List<String> {
        val used = HashSet<String>(); val out = ArrayList<String>()
        for (raw in names) {
            val base = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "personagem" }
            var n = base; var i = 2
            while (!used.add(n.lowercase())) n = "${base}_${i++}"
            out.add(n)
        }
        return out
    }

    /** [items] = (nome do personagem, bytes do VMD). Gera "<nome>.vmd" para cada um. */
    fun zip(items: List<Pair<String, ByteArray>>): ByteArray {
        val names = uniqueNames(items.map { it.first })
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            items.forEachIndexed { i, it ->
                z.putNextEntry(ZipEntry(names[i] + ".vmd")); z.write(it.second); z.closeEntry()
            }
        }
        return bo.toByteArray()
    }
}
