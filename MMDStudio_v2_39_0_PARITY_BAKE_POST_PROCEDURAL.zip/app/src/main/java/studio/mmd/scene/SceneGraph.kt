package studio.mmd.scene

import studio.mmd.project.PropMeta

/** v1.18.0 (Release 8, fatia 1): Scene Graph em Kotlin puro (sem android.*), para ser testável na JVM. */
enum class NodeType { CHARACTER, PROP, GROUP, CAMERA, LIGHT, AUDIO, EFFECT }

/** Transformação local: posição, rotação em graus (ordem Rz*Ry*Rx) e escala por eixo. */
data class Transform(
    val px: Float = 0f, val py: Float = 0f, val pz: Float = 0f,
    val rx: Float = 0f, val ry: Float = 0f, val rz: Float = 0f,
    val sx: Float = 1f, val sy: Float = 1f, val sz: Float = 1f
) {
    /** Matriz 4x4 coluna-principal (mesmo layout de android.opengl.Matrix): T * Rz * Ry * Rx * S. */
    fun toMatrix(): FloatArray {
        val t = Mat.translation(px, py, pz)
        val r = Mat.mul(Mat.rotZ(rz), Mat.mul(Mat.rotY(ry), Mat.rotX(rx)))
        return Mat.mul(t, Mat.mul(r, Mat.scale(sx, sy, sz)))
    }
    companion object { val IDENTITY = Transform() }
}

/**
 * Um nó da cena. [asset] = nome do arquivo do modelo/objeto dentro da pasta do projeto (vazio para grupo/câmera/luz).
 * [attachBone]: se não vazio, o nó segue esse osso do pai (que deve ser um CHARACTER); a matriz do osso é resolvida pelo renderer, não aqui.
 */
data class SceneNode(
    val id: String, val name: String, val type: NodeType, val parentId: String? = null,
    val visible: Boolean = true, val locked: Boolean = false, val local: Transform = Transform.IDENTITY,
    val asset: String = "", val attachBone: String = ""
)

/** Resultado de uma operação que pode falhar sem lançar exceção. */
sealed class GraphResult {
    data class Ok(val graph: SceneGraph) : GraphResult()
    data class Err(val reason: String) : GraphResult()
}

/**
 * Cena imutável: toda edição devolve um novo SceneGraph (facilita desfazer/refazer depois).
 * A ordem da lista [nodes] é a ordem entre irmãos. [activeId] = personagem ativo (ou null).
 */
data class SceneGraph(val nodes: List<SceneNode> = emptyList(), val activeId: String? = null) {
    private val byId: Map<String, SceneNode> = nodes.associateBy { it.id }

    fun get(id: String): SceneNode? = byId[id]
    fun roots(): List<SceneNode> = nodes.filter { it.parentId == null }
    fun children(id: String): List<SceneNode> = nodes.filter { it.parentId == id }
    fun characters(): List<SceneNode> = nodes.filter { it.type == NodeType.CHARACTER }

    /** Ids do nó e de todos os descendentes (o próprio nó primeiro). */
    fun subtree(id: String): List<String> {
        if (byId[id] == null) return emptyList()
        val out = ArrayList<String>(); val stack = ArrayDeque<String>(); stack.addLast(id)
        while (stack.isNotEmpty()) {
            val c = stack.removeFirst(); out.add(c)
            children(c).forEach { stack.addLast(it.id) }
        }
        return out
    }

    /** Matriz global = produto das matrizes locais da raiz até o nó. Id inexistente = identidade. */
    fun globalMatrix(id: String): FloatArray {
        val chain = ArrayList<SceneNode>(); var cur = byId[id]; var guard = 0
        while (cur != null && guard++ <= nodes.size) { chain.add(cur); cur = cur.parentId?.let { byId[it] } }
        var m = Mat.identity()
        for (n in chain.asReversed()) m = Mat.mul(m, n.local.toMatrix())
        return m
    }

    /** Visível de fato: o nó e todos os ancestrais visíveis. */
    fun effectivelyVisible(id: String): Boolean {
        var cur = byId[id] ?: return false; var guard = 0
        while (guard++ <= nodes.size) {
            if (!cur.visible) return false
            cur = cur.parentId?.let { byId[it] } ?: return true
        }
        return false
    }

    /** Trancado de fato: o nó ou algum ancestral trancado. */
    fun effectivelyLocked(id: String): Boolean {
        var cur = byId[id] ?: return false; var guard = 0
        while (guard++ <= nodes.size) {
            if (cur.locked) return true
            cur = cur.parentId?.let { byId[it] } ?: return false
        }
        return true
    }

    // ---------------- edição

    fun add(node: SceneNode): GraphResult {
        if (node.id.isBlank()) return GraphResult.Err("id vazio")
        if (byId.containsKey(node.id)) return GraphResult.Err("id já existe: ${node.id}")
        if (node.parentId != null && !byId.containsKey(node.parentId)) return GraphResult.Err("pai inexistente: ${node.parentId}")
        if (node.attachBone.isNotEmpty()) {
            val p = node.parentId?.let { byId[it] }
            if (p == null || p.type != NodeType.CHARACTER) return GraphResult.Err("osso só pode ser usado com pai do tipo personagem")
        }
        val g = copy(nodes = nodes + node)
        return GraphResult.Ok(if (g.activeId == null && node.type == NodeType.CHARACTER) g.copy(activeId = node.id) else g)
    }

    /** Remove o nó e todos os descendentes. Se o ativo for removido, o primeiro personagem restante passa a ser o ativo. */
    fun remove(id: String): GraphResult {
        if (byId[id] == null) return GraphResult.Err("nó inexistente: $id")
        val gone = subtree(id).toSet()
        val left = nodes.filter { it.id !in gone }
        val act = if (activeId != null && activeId in gone) left.firstOrNull { it.type == NodeType.CHARACTER }?.id else activeId
        return GraphResult.Ok(SceneGraph(left, act))
    }

    private fun update(id: String, f: (SceneNode) -> SceneNode): GraphResult {
        if (byId[id] == null) return GraphResult.Err("nó inexistente: $id")
        return GraphResult.Ok(copy(nodes = nodes.map { if (it.id == id) f(it) else it }))
    }

    fun rename(id: String, name: String): GraphResult =
        if (name.isBlank()) GraphResult.Err("nome vazio") else update(id) { it.copy(name = name.trim()) }

    fun setVisible(id: String, v: Boolean) = update(id) { it.copy(visible = v) }
    fun setLocked(id: String, v: Boolean) = update(id) { it.copy(locked = v) }

    /** Trocar a transformação de um nó trancado (ou filho de um trancado) é recusado. */
    fun setTransform(id: String, t: Transform): GraphResult =
        if (byId[id] != null && effectivelyLocked(id)) GraphResult.Err("nó trancado: $id") else update(id) { it.copy(local = t) }

    fun setActive(id: String): GraphResult {
        val n = byId[id] ?: return GraphResult.Err("nó inexistente: $id")
        if (n.type != NodeType.CHARACTER) return GraphResult.Err("só personagem pode ser ativo")
        return GraphResult.Ok(copy(activeId = id))
    }

    /** Muda o pai (null = raiz). Recusa ciclo e pai inexistente. Se [bone] não for vazio, o novo pai precisa ser personagem. A matriz local é mantida (não compensa a global). */
    fun reparent(id: String, newParent: String?, bone: String = ""): GraphResult {
        if (byId[id] == null) return GraphResult.Err("nó inexistente: $id")
        if (newParent != null) {
            val p = byId[newParent] ?: return GraphResult.Err("pai inexistente: $newParent")
            if (newParent in subtree(id)) return GraphResult.Err("ciclo: o pai não pode ser o próprio nó ou um descendente")
            if (bone.isNotEmpty() && p.type != NodeType.CHARACTER) return GraphResult.Err("osso só pode ser usado com pai do tipo personagem")
        } else if (bone.isNotEmpty()) return GraphResult.Err("osso exige um pai")
        return update(id) { it.copy(parentId = newParent, attachBone = bone) }
    }

    /** Move o nó entre os irmãos: [delta] -1 sobe, +1 desce (limitado às pontas). */
    fun move(id: String, delta: Int): GraphResult {
        val n = byId[id] ?: return GraphResult.Err("nó inexistente: $id")
        val sib = nodes.filter { it.parentId == n.parentId }
        val from = sib.indexOfFirst { it.id == id }
        val to = (from + delta).coerceIn(0, sib.size - 1)
        if (to == from) return GraphResult.Ok(this)
        val other = sib[to]
        val list = nodes.toMutableList()
        val a = list.indexOfFirst { it.id == id }; val b = list.indexOfFirst { it.id == other.id }
        val tmp = list[a]; list[a] = list[b]; list[b] = tmp
        return GraphResult.Ok(copy(nodes = list))
    }

    /** Agrupa os nós (mesmo pai) dentro de um novo GROUP criado nesse pai. */
    fun group(ids: List<String>, groupId: String, name: String): GraphResult {
        if (ids.isEmpty()) return GraphResult.Err("nada para agrupar")
        val ns = ids.map { byId[it] ?: return GraphResult.Err("nó inexistente: $it") }
        val parent = ns.first().parentId
        if (ns.any { it.parentId != parent }) return GraphResult.Err("os nós precisam ter o mesmo pai")
        if (ns.any { it.attachBone.isNotEmpty() }) return GraphResult.Err("nó preso a osso não pode ser agrupado")
        val added = add(SceneNode(groupId, name, NodeType.GROUP, parent))
        var g = (added as? GraphResult.Ok)?.graph ?: return added
        for (i in ids) g = (g.reparent(i, groupId) as? GraphResult.Ok)?.graph ?: return GraphResult.Err("falha ao agrupar $i")
        return GraphResult.Ok(g)
    }

    /**
     * Duplica o nó e todos os descendentes, com ids novos gerados por [newId] e nome "<nome> (cópia)".
     * A cópia fica como irmã logo no fim da lista; a ligação com o asset é a mesma (o estado mutável é por nó, não pelo arquivo).
     */
    fun duplicate(id: String, newId: () -> String): GraphResult {
        if (byId[id] == null) return GraphResult.Err("nó inexistente: $id")
        val ids = subtree(id); val map = HashMap<String, String>()
        for (old in ids) { val n = newId(); if (n.isBlank() || byId.containsKey(n) || map.containsValue(n)) return GraphResult.Err("id novo inválido"); map[old] = n }
        val copies = ids.map { old ->
            val n = byId.getValue(old)
            n.copy(id = map.getValue(old), name = if (old == id) n.name + " (cópia)" else n.name,
                parentId = if (old == id) n.parentId else n.parentId?.let { map[it] ?: it })
        }
        return GraphResult.Ok(copy(nodes = nodes + copies))
    }

    companion object {
        const val MAIN_CHARACTER_ID = "char-main"

        /**
         * Migração de projeto v1 (modelo principal + props em scene.json antigo) para o Scene Graph.
         * Props presos a osso ficam filhos do personagem principal, com [SceneNode.attachBone].
         */
        fun fromLegacy(modelName: String, hasModel: Boolean, props: List<PropMeta>): SceneGraph {
            val list = ArrayList<SceneNode>()
            if (hasModel) list.add(SceneNode(MAIN_CHARACTER_ID, modelName.ifBlank { "Personagem" }, NodeType.CHARACTER, asset = "model"))
            for (p in props) {
                val attached = p.bone.isNotEmpty() && hasModel
                list.add(SceneNode(
                    id = p.id, name = p.name, type = NodeType.PROP,
                    parentId = if (attached) MAIN_CHARACTER_ID else null,
                    local = Transform(p.x, p.y, p.z, p.rx, p.ry, p.rz, p.s, p.s, p.s),
                    asset = p.id + "." + p.ext, attachBone = if (attached) p.bone else ""
                ))
            }
            return SceneGraph(list, if (hasModel) MAIN_CHARACTER_ID else null)
        }
    }
}

/** Álgebra 4x4 coluna-principal (índice = coluna*4 + linha). */
internal object Mat {
    fun identity() = FloatArray(16).also { it[0] = 1f; it[5] = 1f; it[10] = 1f; it[15] = 1f }
    fun translation(x: Float, y: Float, z: Float) = identity().also { it[12] = x; it[13] = y; it[14] = z }
    fun scale(x: Float, y: Float, z: Float) = identity().also { it[0] = x; it[5] = y; it[10] = z }
    fun rotX(deg: Float): FloatArray { val a = Math.toRadians(deg.toDouble()); val c = Math.cos(a).toFloat(); val s = Math.sin(a).toFloat()
        return identity().also { it[5] = c; it[6] = s; it[9] = -s; it[10] = c } }
    fun rotY(deg: Float): FloatArray { val a = Math.toRadians(deg.toDouble()); val c = Math.cos(a).toFloat(); val s = Math.sin(a).toFloat()
        return identity().also { it[0] = c; it[2] = -s; it[8] = s; it[10] = c } }
    fun rotZ(deg: Float): FloatArray { val a = Math.toRadians(deg.toDouble()); val c = Math.cos(a).toFloat(); val s = Math.sin(a).toFloat()
        return identity().also { it[0] = c; it[1] = s; it[4] = -s; it[5] = c } }
    fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        for (c in 0..3) for (r in 0..3) { var s = 0f; for (k in 0..3) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s }
        return o
    }
}
