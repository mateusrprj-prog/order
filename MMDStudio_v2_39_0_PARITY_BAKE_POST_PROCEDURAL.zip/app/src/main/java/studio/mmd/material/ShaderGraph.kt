package studio.mmd.material

import studio.mmd.mmd.PmxMaterial
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/** Grafo de material portável para Android/PMX. O backend PMX faz bake de propriedades compatíveis. */
enum class MaterialNodeKind { COLOR, VALUE, MULTIPLY, MIX, PRINCIPLED, OUTPUT }

data class MaterialGraphNode(
    val id: String,
    val kind: MaterialNodeKind,
    val color: FloatArray = floatArrayOf(0.8f, 0.8f, 0.8f, 1f),
    val value: Float = 0.5f
)
data class MaterialGraphLink(val fromNode: String, val toNode: String, val input: String)
data class MaterialGraph(val nodes: List<MaterialGraphNode>, val links: List<MaterialGraphLink>)
data class ShaderGraphResult(val material: PmxMaterial, val warnings: List<String>, val evaluatedNodes: Int)

private sealed interface GraphValue {
    data class Color(val rgba: FloatArray) : GraphValue
    data class Scalar(val value: Float) : GraphValue
    data class Surface(val color: FloatArray, val metallic: Float, val roughness: Float) : GraphValue
}

/** Avaliador DAG com detecção de ciclos, sockets tipados e fallback seguro para entradas desconectadas. */
object ShaderGraphCompiler {
    fun basic(material: PmxMaterial): MaterialGraph = MaterialGraph(
        nodes = listOf(
            MaterialGraphNode("base-color", MaterialNodeKind.COLOR, material.diffuse.copyOf()),
            MaterialGraphNode("metallic", MaterialNodeKind.VALUE, value = 0.05f),
            MaterialGraphNode("roughness", MaterialNodeKind.VALUE, value = sqrt(2f / (material.specularPower.coerceAtLeast(0f) + 2f)).coerceIn(0.04f, 1f)),
            MaterialGraphNode("principled", MaterialNodeKind.PRINCIPLED),
            MaterialGraphNode("output", MaterialNodeKind.OUTPUT)
        ),
        links = listOf(
            MaterialGraphLink("base-color", "principled", "baseColor"),
            MaterialGraphLink("metallic", "principled", "metallic"),
            MaterialGraphLink("roughness", "principled", "roughness"),
            MaterialGraphLink("principled", "output", "surface")
        )
    )

    fun compile(graph: MaterialGraph, base: PmxMaterial): ShaderGraphResult {
        val nodes = graph.nodes.associateBy { it.id }
        require(nodes.size == graph.nodes.size) { "O grafo possui IDs de nós duplicados" }
        require(nodes.keys.none { it.isBlank() }) { "ID de nó vazio" }
        val incoming = graph.links.associateBy { it.toNode to it.input }
        val cache = HashMap<String, GraphValue>()
        val visiting = HashSet<String>()
        val warnings = ArrayList<String>()
        var evaluated = 0
        lateinit var evaluator: (MaterialGraphNode) -> GraphValue
        fun input(node: MaterialGraphNode, socket: String, fallback: GraphValue): GraphValue {
            val link = incoming[node.id to socket] ?: return fallback
            val upstream = nodes[link.fromNode] ?: throw IllegalArgumentException("Link aponta para nó inexistente: ${link.fromNode}")
            return evaluator(upstream)
        }
        fun color(value: GraphValue, fallback: FloatArray): FloatArray = when (value) {
            is GraphValue.Color -> value.rgba
            is GraphValue.Surface -> value.color
            is GraphValue.Scalar -> floatArrayOf(value.value, value.value, value.value, 1f)
        }.let { FloatArray(4) { i -> it.getOrElse(i) { fallback.getOrElse(i) { 1f } }.takeIf(Float::isFinite) ?: fallback.getOrElse(i) { 1f } } }
        fun scalar(value: GraphValue, fallback: Float): Float = when (value) {
            is GraphValue.Scalar -> value.value
            is GraphValue.Color -> (value.rgba.getOrElse(0) { fallback } + value.rgba.getOrElse(1) { fallback } + value.rgba.getOrElse(2) { fallback }) / 3f
            is GraphValue.Surface -> value.roughness
        }.takeIf(Float::isFinite) ?: fallback
        evaluator = { node ->
            cache[node.id] ?: run {
                require(visiting.add(node.id)) { "Ciclo detectado no Shader Graph em ${node.id}" }
                val result = when (node.kind) {
                    MaterialNodeKind.COLOR -> GraphValue.Color(FloatArray(4) { i -> node.color.getOrElse(i) { if (i == 3) 1f else 0f }.coerceIn(0f, 1f) })
                    MaterialNodeKind.VALUE -> GraphValue.Scalar(node.value.takeIf(Float::isFinite) ?: 0f)
                    MaterialNodeKind.MULTIPLY -> {
                        val a = input(node, "a", GraphValue.Color(floatArrayOf(1f, 1f, 1f, 1f)))
                        val b = input(node, "b", GraphValue.Color(floatArrayOf(1f, 1f, 1f, 1f)))
                        val ca = color(a, floatArrayOf(1f, 1f, 1f, 1f)); val cb = color(b, floatArrayOf(1f, 1f, 1f, 1f))
                        GraphValue.Color(FloatArray(4) { (ca[it] * cb[it]).coerceIn(0f, 1f) })
                    }
                    MaterialNodeKind.MIX -> {
                        val a = color(input(node, "a", GraphValue.Color(floatArrayOf(0f, 0f, 0f, 1f))), floatArrayOf(0f, 0f, 0f, 1f))
                        val b = color(input(node, "b", GraphValue.Color(floatArrayOf(1f, 1f, 1f, 1f))), floatArrayOf(1f, 1f, 1f, 1f))
                        val t = scalar(input(node, "factor", GraphValue.Scalar(node.value)), node.value).coerceIn(0f, 1f)
                        GraphValue.Color(FloatArray(4) { (a[it] * (1f - t) + b[it] * t).coerceIn(0f, 1f) })
                    }
                    MaterialNodeKind.PRINCIPLED -> {
                        val c = color(input(node, "baseColor", GraphValue.Color(base.diffuse)), base.diffuse)
                        val metal = scalar(input(node, "metallic", GraphValue.Scalar(0f)), 0f).coerceIn(0f, 1f)
                        val rough = scalar(input(node, "roughness", GraphValue.Scalar(0.5f)), 0.5f).coerceIn(0.04f, 1f)
                        GraphValue.Surface(c, metal, rough)
                    }
                    MaterialNodeKind.OUTPUT -> input(node, "surface", GraphValue.Surface(base.diffuse.copyOf(), 0f, 0.5f))
                }
                visiting.remove(node.id); cache[node.id] = result; evaluated++; result
            }
        }
        // Avalia todos os nós para detectar ciclos mesmo em ramos não ligados à saída.
        graph.nodes.forEach { evaluator(it) }
        val output = graph.nodes.lastOrNull { it.kind == MaterialNodeKind.OUTPUT }
            ?: throw IllegalArgumentException("O Shader Graph precisa de um nó Output")
        val result = evaluator(output)
        val surface = when (result) {
            is GraphValue.Surface -> result
            is GraphValue.Color -> GraphValue.Surface(result.rgba, 0f, 0.5f)
            is GraphValue.Scalar -> GraphValue.Surface(floatArrayOf(result.value, result.value, result.value, 1f), 0f, 0.5f)
        }
        val diffuse = surface.color.copyOf()
        val dielectric = 0.04f
        val specular = FloatArray(3) { i -> (dielectric * (1f - surface.metallic) + diffuse.getOrElse(i) { 0f } * surface.metallic).coerceIn(0f, 1f) }
        val power = (2f / surface.roughness.coerceIn(0.04f, 1f).pow(2) - 2f).coerceIn(0f, 128f)
        val ambient = FloatArray(3) { i -> diffuse.getOrElse(i) { 0f } * (0.04f + 0.08f * (1f - surface.metallic)) }
        if (surface.metallic > 0f) warnings += "PMX não possui canal metallic nativo; metallic foi aproximado pelo especular"
        warnings += "Texturas, normal maps e efeitos de superfície avançados continuam dependentes do renderer PMX"
        val material = PmxMaterial(base.name, base.nameEn, diffuse, specular, power, ambient, base.flags, base.edgeColor.copyOf(), base.edgeSize,
            base.textureIndex, base.sphereIndex, base.sphereMode, base.toonShared, base.toonIndex, base.indexCount, base.memo)
        return ShaderGraphResult(material, warnings, evaluated)
    }
}
