package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.VmdCamera
import studio.mmd.mmd.VmdCameraDoctor

class VmdCameraDoctorTest {
    @Test fun sortsDeduplicatesAndRepairsMalformedCameraKeys() {
        val camera = VmdCamera(
            intArrayOf(3, -1, 2, 2),
            floatArrayOf(2f, 1f, Float.POSITIVE_INFINITY, 4f),
            FloatArray(12) { if (it == 0) Float.NaN else it.toFloat() },
            FloatArray(12),
            floatArrayOf(45f, 220f, Float.NaN, 30f),
            ByteArray(96) { if (it % 24 == 0) 0xff.toByte() else 120.toByte() }
        )
        val before = VmdCameraDoctor.inspect(camera)
        assertTrue(before.duplicateFrames > 0)
        assertTrue(before.unorderedFrames > 0)
        assertTrue(before.nonFiniteValues > 0)
        assertTrue(before.invalidFov > 0)
        assertTrue(before.malformedInterpolation > 0)

        val fixed = VmdCameraDoctor.repair(camera)
        assertArrayEquals(intArrayOf(0, 2, 3), fixed.camera.frames)
        assertTrue(fixed.camera.fov.all { it in 1f..179f })
        assertTrue(VmdCameraDoctor.inspect(fixed.camera).healthy)
    }

    @Test fun completesTruncatedCameraInterpolationWithoutLosingKeys() {
        val camera = VmdCamera(intArrayOf(0, 10), floatArrayOf(0f, 2f), FloatArray(6), FloatArray(6),
            floatArrayOf(45f, 60f), ByteArray(24) { 30 })
        val fixed = VmdCameraDoctor.repair(camera).camera
        assertEquals(2, fixed.frames.size)
        assertEquals(48, fixed.ip.size)
        assertTrue(VmdCameraDoctor.inspect(fixed).healthy)
    }
}
