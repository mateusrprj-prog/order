package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test
import studio.mmd.mmd.GltfInterp
import studio.mmd.mmd.GltfSampler
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class GltfSamplerTest {
    private fun ev(s: GltfSampler, t: Float): FloatArray { val o = FloatArray(s.comps); s.eval(t, o); return o }

    @Test fun linearInterpolaEClampa() {
        val s = GltfSampler(floatArrayOf(0f, 2f), floatArrayOf(0f, 10f, 4f, 20f), 2, GltfInterp.LINEAR)
        assertEquals(2f, ev(s, 1f)[0], 1e-5f); assertEquals(15f, ev(s, 1f)[1], 1e-5f)
        assertEquals(0f, ev(s, -3f)[0], 0f); assertEquals(4f, ev(s, 9f)[0], 0f)
        assertEquals(2f, s.duration, 0f)
    }

    @Test fun stepMantemValorAnterior() {
        val s = GltfSampler(floatArrayOf(0f, 1f, 2f), floatArrayOf(1f, 2f, 3f), 1, GltfInterp.STEP)
        assertEquals(1f, ev(s, 0.99f)[0], 0f); assertEquals(2f, ev(s, 1f)[0], 0f); assertEquals(2f, ev(s, 1.99f)[0], 0f)
    }

    @Test fun slerpMeioCaminhoEixoZ() {
        val h = Math.sin(Math.toRadians(45.0)).toFloat(); val c = Math.cos(Math.toRadians(45.0)).toFloat()
        // 0° e 90° em Z -> meio = 45° (z=sin22.5, w=cos22.5)
        val s = GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, h, c), 4, GltfInterp.LINEAR, rotation = true)
        val q = ev(s, 0.5f)
        assertEquals(sin(Math.toRadians(22.5)).toFloat(), q[2], 1e-4f); assertEquals(cos(Math.toRadians(22.5)).toFloat(), q[3], 1e-4f)
    }

    @Test fun slerpUsaCaminhoMaisCurto() {
        // q e -q são a mesma rotação: no meio deve continuar identidade, não passar por 180°
        val s = GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, -1f), 4, GltfInterp.LINEAR, rotation = true)
        val q = ev(s, 0.5f)
        assertEquals(1f, abs(q[3]), 1e-4f); assertEquals(0f, q[2], 1e-4f)
    }

    @Test fun cubicPassaPelasKeysEUsaTangentes() {
        // 1 comp, 2 keys: [in0,val0,out0, in1,val1,out1]; tangentes nulas => smoothstep; meio = média
        val z = GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(0f, 0f, 0f, 0f, 10f, 0f), 1, GltfInterp.CUBICSPLINE)
        assertEquals(0f, ev(z, 0f)[0], 1e-5f); assertEquals(10f, ev(z, 1f)[0], 1e-5f); assertEquals(5f, ev(z, 0.5f)[0], 1e-4f)
        assertEquals(1.5625f, ev(z, 0.25f)[0], 1e-4f) // smoothstep(0.25)=0.15625
        // tangente de saída positiva na key 0 faz a curva subir mais rápido no começo que a de tangente nula
        val t = GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(0f, 0f, 20f, 0f, 10f, 0f), 1, GltfInterp.CUBICSPLINE)
        assertEquals(true, ev(t, 0.1f)[0] > ev(z, 0.1f)[0])
    }

    @Test fun cubicRotacaoSaiNormalizada() {
        val v = floatArrayOf(0f,0f,0f,0f, 0f,0f,0f,1f, 0f,0f,0f,0f,  0f,0f,0f,0f, 0f,0f,1f,0f, 0f,0f,0f,0f)
        val q = ev(GltfSampler(floatArrayOf(0f, 1f), v, 4, GltfInterp.CUBICSPLINE, rotation = true), 0.5f)
        assertEquals(1f, q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3], 1e-4f)
    }

    @Test fun dadosInvalidosSaoRecusados() {
        for (mk in listOf<() -> GltfSampler>(
            { GltfSampler(floatArrayOf(), floatArrayOf(), 1, GltfInterp.LINEAR) },
            { GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(1f), 1, GltfInterp.LINEAR) },
            { GltfSampler(floatArrayOf(1f, 1f), floatArrayOf(1f, 2f), 1, GltfInterp.LINEAR) },
            { GltfSampler(floatArrayOf(0f), floatArrayOf(0f, 0f, 0f), 1, GltfInterp.CUBICSPLINE) })) {
            try { mk(); fail("devia recusar") } catch (e: IllegalArgumentException) { }
        }
        assertEquals(null, GltfInterp.parse("BEZIER")); assertEquals(GltfInterp.LINEAR, GltfInterp.parse(null))
    }
}
