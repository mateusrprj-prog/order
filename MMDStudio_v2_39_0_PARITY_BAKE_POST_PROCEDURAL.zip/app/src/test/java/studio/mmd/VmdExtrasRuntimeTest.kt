package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class VmdExtrasRuntimeTest {
    private fun vmd(extras: VmdExtras): ByteArray {
        val signature = ByteArray(30)
        "Vocaloid Motion Data 0002".toByteArray(Charsets.US_ASCII).copyInto(signature)
        val out = ByteBuffer.allocate(30 + 20 + 12 + extras.byteSize()).order(ByteOrder.LITTLE_ENDIAN)
        out.put(signature); out.put(ByteArray(20))
        out.putInt(0); out.putInt(0); out.putInt(0) // ossos, morphs e câmera
        extras.write(out)
        assertEquals(out.capacity(), out.position())
        return out.array()
    }

    @Test fun lightShadowAndVisibilityReadBackWithIndependentFrames() {
        val extras = VmdExtras(
            ik = mapOf("leg" to VmdIkTrack(intArrayOf(3), booleanArrayOf(false))),
            lights = VmdLightKeys(intArrayOf(0,10), floatArrayOf(1f,0f,0f,0f,0f,1f), floatArrayOf(0f,0f,-1f,0f,1f,0f)),
            shadows = VmdShadowKeys(intArrayOf(0,6), byteArrayOf(0,2), floatArrayOf(0f,123f)),
            visibility = VmdVisibilityKeys(intArrayOf(2,8), booleanArrayOf(false,true))
        )
        val parsed = VmdParser.parse(vmd(extras))
        assertFalse(parsed.extras.visibility!!.at(4f))
        assertTrue(parsed.extras.visibility!!.at(9f))
        assertEquals(2, parsed.extras.evaluateShadow(7f)!!.mode)
        assertEquals(10, parsed.maxFrame)
        assertEquals(.5f, parsed.extras.evaluateLight(5f)!!.color[0], .00001f)
    }

    @Test fun motionDoctorPreservesAndNormalizesExtraChannels() {
        val source = VmdMotion("test", emptyMap(), emptyMap(), 0, extras = VmdExtras(
            ik = mapOf("leg" to VmdIkTrack(intArrayOf(3), booleanArrayOf(false))),
            shadows = VmdShadowKeys(intArrayOf(8,2,2), byteArrayOf(9,0,1), floatArrayOf(Float.NaN,1f,2f)),
            visibility = VmdVisibilityKeys(intArrayOf(9,2,2), booleanArrayOf(true,false,true))
        ))
        val fixed = VmdMotionDoctor.repair(source).motion
        assertTrue(fixed.extras.visibility!!.at(3f)) // a última chave duplicada no frame 2 vence
        assertEquals(1, fixed.extras.shadows!!.mode[0].toInt())
        assertTrue(fixed.extras.shadows!!.dist.all { it.isFinite() && it >= 0f })
        assertTrue(fixed.maxFrame >= 9)
        val output = vmd(fixed.extras)
        assertNotNull(VmdParser.parse(output).extras.visibility)
    }
}
