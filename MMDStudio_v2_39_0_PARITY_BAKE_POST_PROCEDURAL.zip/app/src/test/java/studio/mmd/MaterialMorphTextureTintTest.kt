package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MaterialMorphTextureTintTest {
    private fun morph(additive: Boolean = false): PmxMorph {
        val mSize = 2
        val raw = ByteBuffer.allocate(mSize + 113).order(ByteOrder.LITTLE_ENDIAN)
        raw.putShort(0); raw.put(if (additive) 1 else 0)
        repeat(16) { raw.putFloat(if (it % 4 == 3) 1f else 0f) }
        // texture tint
        for (v in floatArrayOf(0.5f,0.6f,0.7f,0.8f)) raw.putFloat(v)
        // sphere tint
        for (v in floatArrayOf(0.2f,0.3f,0.4f,0.5f)) raw.putFloat(v)
        // toon tint
        for (v in floatArrayOf(0.8f,0.7f,0.6f,0.9f)) raw.putFloat(v)
        return PmxMorph("t","t",0,8,raw=raw.array(),count=1)
    }

    @Test fun decoderReadsThreeExtraTintVectors() {
        val e=MaterialMorphs.decode(morph()).single()
        assertArrayEquals(floatArrayOf(0.5f,0.6f,0.7f,0.8f),e.textureTint!!,0f)
        assertArrayEquals(floatArrayOf(0.2f,0.3f,0.4f,0.5f),e.sphereTint!!,0f)
        assertArrayEquals(floatArrayOf(0.8f,0.7f,0.6f,0.9f),e.toonTint!!,0f)
    }

    @Test fun multiplyMorphAccumulatesTintFactors() {
        val state=MaterialMorphState(1); state.apply(MaterialMorphs.decode(morph()).single(),0.5f)
        val out=FloatArray(12); state.finalizeExtra(out)
        assertEquals(0.75f,out[0],1e-6f); assertEquals(0.6f,out[4],1e-6f); assertEquals(0.9f,out[8],1e-6f)
    }

    @Test fun additiveMorphUsesWhiteNeutralAndAddsTintValues() {
        val state=MaterialMorphState(1); state.apply(MaterialMorphs.decode(morph(true)).single(),0.5f)
        val out=FloatArray(12); state.finalizeExtra(out)
        assertEquals(1.25f,out[0],1e-6f); assertEquals(1.1f,out[4],1e-6f); assertEquals(1.4f,out[8],1e-6f)
    }

    @Test fun resetRestoresNeutralTints() {
        val state=MaterialMorphState(1); state.apply(MaterialMorphs.decode(morph()).single(),1f)
        state.reset(); val out=FloatArray(12); state.finalizeExtra(out)
        assertArrayEquals(FloatArray(12){1f},out,0f)
    }
}
