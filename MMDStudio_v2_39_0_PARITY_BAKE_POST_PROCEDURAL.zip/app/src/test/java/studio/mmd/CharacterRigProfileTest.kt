package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.rig.*

class CharacterRigProfileTest {
    @Test fun profileRoundTripKeepsIndependentPhysicsAndSecondarySettings() {
        val source = RigConfig().apply {
            list = listOf(Constraint("c1", "左足", CType.LIMIT_ROT, weight = 0.7f))
            secondary = listOf(Secondary("s1", "Saia", listOf("左スカート", "右スカート"), intensity = 0.9f, stiffness = 88f))
            phys = PhysConfig(enabled = true, gravity = 0.65f, stiffness = 1.8f, damping = 1.25f, wind = 0.4f, collisions = false)
        }
        val loaded = CharacterRigProfileCodec.decode(CharacterRigProfileCodec.encode(source))
        assertEquals(source.list, loaded.list)
        assertEquals(source.secondary, loaded.secondary)
        assertEquals(source.phys, loaded.phys)
        assertNull(loaded.physCache) // cache é transitório e sempre refeito por personagem
    }

    @Test fun decodingTwoProfilesNeverSharesMutableRigConfig() {
        val encoded = CharacterRigProfileCodec.encode(RigConfig().apply { phys = PhysConfig(enabled = true) })
        val a = CharacterRigProfileCodec.decode(encoded)
        val b = CharacterRigProfileCodec.decode(encoded)
        a.phys = a.phys.copy(gravity = 0.2f)
        a.secondary = listOf(Secondary("x", "Saia", listOf("saia")))
        assertEquals(1f, b.phys.gravity)
        assertTrue(b.secondary.isEmpty())
    }

    @Test fun unknownNewerProfileFallsBackSafely() {
        assertFalse(CharacterRigProfileCodec.safeDecode("{\"formatVersion\":99}").phys.enabled)
    }
}