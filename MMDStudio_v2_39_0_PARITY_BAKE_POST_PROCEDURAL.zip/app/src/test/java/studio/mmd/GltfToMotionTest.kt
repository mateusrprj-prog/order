package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import studio.mmd.mmd.*
import kotlin.math.cos
import kotlin.math.sin

class GltfToMotionTest {
    private fun bone(name: String, parent: Int) = PmxBone(name, name, 0f, 0f, 0f, parent, 0, 0x1e, -1, -1, 0f, null)
    private fun model(vararg names: String) = PmxModel("m", 2f, FloatArray(0), FloatArray(0), FloatArray(0), IntArray(0), FloatArray(0), IntArray(0),
        emptyList(), emptyList(), names.mapIndexed { i, n -> bone(n, i - 1) }, emptyList())
    private fun rig(parent: IntArray, q: Array<FloatArray>, t: Array<FloatArray> = Array(parent.size) { floatArrayOf(0f, 0f, 0f) }, s: Float = 10f) = GltfRig(parent, t, q, s)
    private val I = floatArrayOf(0f, 0f, 0f, 1f)
    private fun rotQ(ax: FloatArray, deg: Double): FloatArray { val h = Math.toRadians(deg) / 2; return floatArrayOf(ax[0] * sin(h).toFloat(), ax[1] * sin(h).toFloat(), ax[2] * sin(h).toFloat(), cos(h).toFloat()) }
    private fun rotClip(node: Int, bone: Int, q1: FloatArray, q0: FloatArray = I) =
        GltfClip("c", listOf(GltfChannel(node, "n", bone, "rotation", GltfSampler(floatArrayOf(0f, 1f), q0 + q1, 4, GltfInterp.LINEAR, true))))

    @Test fun rotacaoEmZMantemSinalEZ() {
        val r = GltfToMotion.convert(rotClip(0, 0, rotQ(floatArrayOf(0f, 0f, 1f), 90.0)), rig(intArrayOf(-1), arrayOf(I)), model("a"))
        val t = r.motion.bones.getValue("a"); assertEquals(31, t.frames.size); assertEquals(30, r.motion.maxFrame)
        val v = t.v; val o = 30 * 7
        assertEquals(0.7071f, v[o + 5], 1e-3f); assertEquals(0.7071f, v[o + 6], 1e-3f)
    }

    @Test fun rotacaoEmXInverteSinalPeloEixoZInvertido() {
        val r = GltfToMotion.convert(rotClip(0, 0, rotQ(floatArrayOf(1f, 0f, 0f), 30.0)), rig(intArrayOf(-1), arrayOf(I)), model("a"))
        assertEquals(-sin(Math.toRadians(15.0)).toFloat(), r.motion.bones.getValue("a").v[30 * 7 + 3], 1e-4f)
    }

    @Test fun repousoDoPaiRodaOEixoDoDelta() {
        // nó 0 (pai) em repouso girado 90° em Y; filho gira 30° em X no próprio frame -> eixo no frame do MMD = Rp*X = -Z
        val qp = rotQ(floatArrayOf(0f, 1f, 0f), 90.0)
        val rg = rig(intArrayOf(-1, 0), arrayOf(qp, I))
        val r = GltfToMotion.convert(rotClip(1, 1, rotQ(floatArrayOf(1f, 0f, 0f), 30.0)), rg, model("pai", "filho"))
        val v = r.motion.bones.getValue("filho").v; val o = 30 * 7
        assertEquals(0f, v[o + 3], 1e-4f); assertEquals(0f, v[o + 4], 1e-4f)
        assertEquals(-sin(Math.toRadians(15.0)).toFloat(), v[o + 5], 1e-4f); assertEquals(cos(Math.toRadians(15.0)).toFloat(), v[o + 6], 1e-4f)
    }

    @Test fun translacaoViraOffsetRelativoAoRepousoComEscalaEZInvertido() {
        val tr = GltfChannel(0, "n", 0, "translation", GltfSampler(floatArrayOf(0f, 1f), floatArrayOf(1f, 2f, 3f, 1f, 4f, 5f), 3, GltfInterp.LINEAR))
        val rg = rig(intArrayOf(-1), arrayOf(I), arrayOf(floatArrayOf(1f, 2f, 3f)), 10f)
        val v = GltfToMotion.convert(GltfClip("c", listOf(tr)), rg, model("a")).motion.bones.getValue("a").v
        assertEquals(0f, v[0], 1e-5f); assertEquals(0f, v[2], 1e-5f)          // quadro 0 = repouso
        val o = 30 * 7; assertEquals(0f, v[o], 1e-5f); assertEquals(20f, v[o + 1], 1e-4f); assertEquals(-20f, v[o + 2], 1e-4f)
        assertEquals(1f, v[o + 6], 1e-5f) // sem canal de rotação: identidade
    }

    @Test fun escalaEForaDoModeloViramAviso() {
        val sc = GltfChannel(0, "n", 0, "scale", GltfSampler(floatArrayOf(0f), floatArrayOf(1f, 1f, 1f), 3, GltfInterp.LINEAR))
        val fora = GltfChannel(1, "x", -1, "rotation", GltfSampler(floatArrayOf(0f), floatArrayOf(0f, 0f, 0f, 1f), 4, GltfInterp.LINEAR, true))
        val r = GltfToMotion.convert(GltfClip("c", listOf(sc, fora)), rig(intArrayOf(-1, -1), arrayOf(I, I)), model("a"))
        assertTrue(r.motion.bones.isEmpty()); assertTrue(r.warnings.any { it.contains("escala") }); assertTrue(r.warnings.any { it.contains("não são ossos") })
    }

    @Test fun continuidadeDeSinalDoQuaternion() {
        // 0° -> 350° em Z passando pelo caminho curto: nenhum salto de sinal entre quadros vizinhos
        val q = floatArrayOf(0f, 0f, 1f, 0f)
        val r = GltfToMotion.convert(rotClip(0, 0, q), rig(intArrayOf(-1), arrayOf(I)), model("a"))
        val v = r.motion.bones.getValue("a").v
        for (f in 1..30) assertTrue(v[f * 7 + 3] * v[(f - 1) * 7 + 3] + v[f * 7 + 4] * v[(f - 1) * 7 + 4] + v[f * 7 + 5] * v[(f - 1) * 7 + 5] + v[f * 7 + 6] * v[(f - 1) * 7 + 6] >= -1e-4f)
    }
}
