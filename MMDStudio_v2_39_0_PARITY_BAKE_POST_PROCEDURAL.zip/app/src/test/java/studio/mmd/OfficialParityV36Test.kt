package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class OfficialParityV36Test {
    private val ident = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    private fun track(frames: IntArray, x: FloatArray): VmdTrack {
        val n = frames.size
        val v = FloatArray(n * 7) { if (it % 7 == 0) x[it / 7] else if (it % 7 == 6) 1f else 0f }
        val ip = ByteArray(n * 16) { val k = it % 16; if (k < 8) 20 else 107 }
        return VmdTrack(frames, v, ip)
    }

    @Test fun projectBoxLassoPick() {
        // ortográfica identidade: x,y em [-1,1] → tela 200x100
        val pts = BoneSelection.project(floatArrayOf(0f, 0f, 0f, 0.5f, 0.5f, 0f, -0.9f, -0.9f, 0f, 5f, 5f, 0f), ident, 200, 100)
        assertEquals(4, pts.size)
        assertEquals(100f, pts[0].x, 1e-3f); assertEquals(50f, pts[0].y, 1e-3f)
        assertTrue(!pts[3].let { it.x in 0f..200f })   // fora do frustum horizontal mas "visible" depende de z
        assertEquals(listOf(0, 1), BoneSelection.box(pts, 90f, 10f, 160f, 60f))
        assertEquals(listOf(0), BoneSelection.box(pts, 90f, 40f, 110f, 60f))
        val poly = floatArrayOf(80f, 30f, 120f, 30f, 120f, 70f, 80f, 70f)
        assertEquals(listOf(0), BoneSelection.lasso(pts, poly))
        assertTrue(BoneSelection.lasso(pts, floatArrayOf(0f, 0f, 1f, 1f)).isEmpty())
        assertEquals(listOf(1), BoneSelection.pick(pts, 148f, 27f, 10f))
        assertTrue(BoneSelection.pick(pts, 0f, 99f, 3f).isEmpty())
    }

    @Test fun behindCameraNotVisible() {
        val vp = ident.copyOf(); vp[15] = -1f   // w = -1 → atrás
        val pts = BoneSelection.project(floatArrayOf(0f, 0f, 0f), vp, 10, 10)
        assertFalse(pts[0].visible)
        assertTrue(BoneSelection.box(pts, 0f, 0f, 10f, 10f).isEmpty())
    }

    @Test fun hierarchySelection() {
        val parents = intArrayOf(-1, 0, 1, 1, 0)
        assertEquals(setOf(1, 2, 3), BoneSelection.withDescendants(listOf(1), parents))
        assertEquals(setOf(3, 1, 0), BoneSelection.withAncestors(listOf(3), parents))
        assertEquals(setOf("左腕", "右腕"), BoneSelection.withOpposites(listOf("左腕"), setOf("左腕", "右腕")))
        assertEquals(setOf("左腕"), BoneSelection.withOpposites(listOf("左腕"), setOf("左腕")))
        // ciclo malicioso não trava
        assertEquals(setOf(0, 1), BoneSelection.withAncestors(listOf(0), intArrayOf(1, 0)))
    }

    @Test fun regions() {
        assertEquals(BoneSelection.Region.ARM_L, BoneSelection.regionOf("左腕"))
        assertEquals(BoneSelection.Region.LEG_R, BoneSelection.regionOf("右足"))
        assertEquals(BoneSelection.Region.HAND_R, BoneSelection.regionOf("右人指１"))
        assertEquals(BoneSelection.Region.HEAD, BoneSelection.regionOf("頭"))
        assertEquals(BoneSelection.Region.CENTER, BoneSelection.regionOf("センター"))
        assertEquals(BoneSelection.Region.OTHER, BoneSelection.regionOf("スカート"))
        assertEquals(2, BoneSelection.group(listOf("左腕", "左ひじ", "頭"))[BoneSelection.Region.ARM_L]!!.size)
    }

    @Test fun blendAndApply() {
        val a = mapOf("a" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f))
        val b = mapOf("a" to floatArrayOf(10f, 0f, 0f, 0f, 1f, 0f, 0f), "b" to floatArrayOf(1f, 1f, 1f, 0f, 0f, 0f, 1f))
        val m = PoseTools.blend(a, b, 0.5f)
        assertEquals(5f, m.getValue("a")[0], 1e-5f)
        assertEquals(0.7071f, m.getValue("a")[4], 1e-3f)
        assertEquals(1f, m.getValue("b")[0], 0f)
        val mo = VmdMotion("m", mapOf("a" to track(intArrayOf(0, 10), floatArrayOf(0f, 10f))), emptyMap(), 10)
        val r = PoseTools.applyPose(mo, 20, mapOf("a" to floatArrayOf(7f, 0f, 0f, 0f, 0f, 0f, 1f)))
        assertArrayEquals(intArrayOf(0, 10, 20), r.bones.getValue("a").frames)
        assertEquals(20, r.maxFrame)
    }

    @Test fun holdCopiesPoseAndMorph() {
        val mo = VmdMotion("m", mapOf("a" to track(intArrayOf(0, 10), floatArrayOf(2f, 8f))), mapOf("あ" to VmdMorphTrack(intArrayOf(0, 10), floatArrayOf(0.2f, 0.9f))), 10)
        val h = PoseTools.hold(mo, 0, 30)
        assertEquals(2f, MotionBake.sample(h.bones.getValue("a"), 30f)[0], 1e-5f)
        assertEquals(0.2f, h.morphs.getValue("あ").w.last(), 1e-6f)
        assertEquals(30, h.maxFrame)
    }

    @Test fun pingPongAppendsReverse() {
        val mo = VmdMotion("m", mapOf("a" to track(intArrayOf(0, 10, 40), floatArrayOf(0f, 10f, 99f))), emptyMap(), 40)
        val p = PoseTools.pingPong(mo, 0, 10)
        val t = p.bones.getValue("a")
        assertArrayEquals(intArrayOf(0, 10, 20, 50), t.frames)
        assertEquals(0f, t.v[14], 1e-6f)      // volta ao início em 20
        assertEquals(99f, t.v[21], 1e-6f)     // keys posteriores deslizaram +10
        assertEquals(5f, MotionBake.sample(t, 15f)[0], 1e-4f)
    }

    @Test fun differences() {
        val a = mapOf("x" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f), "y" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f))
        val b = mapOf("x" to floatArrayOf(5f, 0f, 0f, 0f, 0f, 0f, 1f), "y" to floatArrayOf(0.1f, 0f, 0f, 0f, 0f, 0f, 1f))
        assertEquals("x", PoseTools.biggestDifferences(a, b, 1)[0].first)
    }

    @Test fun gizmoBasisAndModes() {
        val b = GizmoMath.localBasis(floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f))
        // X local = Y mundo
        val l = GizmoMath.toLocal(b, floatArrayOf(0f, 2f, 0f))
        assertEquals(2f, l[0], 1e-5f)
        val w = GizmoMath.toWorld(b, l)
        assertEquals(2f, w[1], 1e-5f)
        val fallback = GizmoMath.localBasis(floatArrayOf(0f, 0f, 0f), floatArrayOf(0f, 0f, 0f))
        assertEquals(1f, fallback[0][0], 0f)
        val d = GizmoMath.deltaForMode(GizmoMath.AxisMode.GLOBAL, floatArrayOf(1f, 2f, 3f), null, null)
        assertArrayEquals(floatArrayOf(1f, 2f, 3f), d, 0f)
    }

    @Test fun gizmoRotationAndRing() {
        val q = GizmoMath.quatAxisAngle(floatArrayOf(0f, 1f, 0f), (Math.PI / 2).toFloat())
        val r = GizmoMath.rotate(q, floatArrayOf(1f, 0f, 0f))
        assertEquals(0f, r[0], 1e-5f); assertEquals(-1f, r[2], 1e-5f)
        val drag = GizmoMath.dragToRotation(100f, 0f, floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), 0.01f)
        assertEquals(Math.sin(0.5), drag[1].toDouble(), 1e-5)
        assertEquals(0f, GizmoMath.dragToRotation(Float.NaN, 0f, floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f))[1], 0f)
        assertEquals((Math.PI / 2).toFloat(), GizmoMath.ringAngle(0f, 0f, 1f, 0f, 0f, 1f), 1e-5f)
        assertEquals(0f, GizmoMath.ringAngle(0f, 0f, 0f, 0f, 1f, 1f), 0f)
        assertEquals(15f, GizmoMath.snap(13f, 15f), 0f)
        assertEquals(1, GizmoMath.pickAxis(50f, 2f, 0f, 0f, floatArrayOf(0f, 50f, 100f, 0f, 0f, 0f), 6f))
        assertEquals(-1, GizmoMath.pickAxis(50f, 40f, 0f, 0f, floatArrayOf(0f, 50f, 100f, 0f, 0f, 0f), 6f))
    }

    @Test fun markersRoundTripAndNavigation() {
        var l = TimelineMarkers.add(emptyList(), 30, "Refrão")
        l = TimelineMarkers.add(l, 10, "Intro\tx")
        l = TimelineMarkers.add(l, 30, "Refrão 2")
        assertEquals(2, l.size)
        assertEquals(30, TimelineMarkers.next(l, 10)!!.frame)
        assertNull(TimelineMarkers.next(l, 30))
        assertEquals(10, TimelineMarkers.prev(l, 30)!!.frame)
        val d = TimelineMarkers.decode(TimelineMarkers.encode(l))
        assertEquals(2, d.size); assertEquals("Refrão 2", d[1].label); assertEquals("Intro x", d[0].label)
        assertEquals(1, TimelineMarkers.remove(l, 10).size)
        assertTrue(TimelineMarkers.decode("lixo\nx\ty\tz\n-1\t0\tneg").isEmpty())
    }

    @Test fun workRange() {
        val r = WorkRange(50, 10, 100)
        assertEquals(50, r.start); assertEquals(50, r.end)
        val w = WorkRange(10, 20, 100)
        assertEquals(11, w.length); assertEquals(10, w.advance(20, true)); assertEquals(20, w.advance(20, false)); assertEquals(16, w.advance(15, true))
    }
}
