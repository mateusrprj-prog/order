package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import studio.mmd.project.PropMeta
import studio.mmd.scene.*

/** v1.18.0 (Release 8, fatia 1). Escritos sem Kotlin/Gradle no ambiente: nunca executados. */
class SceneGraphTest {
    private fun ch(id: String, parent: String? = null) = SceneNode(id, id, NodeType.CHARACTER, parent, asset = "$id.pmx")
    private fun pr(id: String, parent: String? = null, bone: String = "") = SceneNode(id, id, NodeType.PROP, parent, attachBone = bone)
    private fun ok(r: GraphResult): SceneGraph = (r as? GraphResult.Ok)?.graph ?: fail("esperava Ok, veio $r").let { throw IllegalStateException() }
    private fun err(r: GraphResult) { assertTrue("esperava Err, veio $r", r is GraphResult.Err) }
    private fun three(): SceneGraph {
        var g = SceneGraph()
        for (id in listOf("a", "b", "c")) g = ok(g.add(ch(id)))
        return g
    }

    @Test fun firstCharacterBecomesActiveAndSwitchWorks() {
        var g = three()
        assertEquals("a", g.activeId)
        g = ok(g.setActive("c")); assertEquals("c", g.activeId)
        err(g.setActive("zzz"))
        g = ok(g.add(pr("p"))); err(g.setActive("p"))
    }

    @Test fun rejectsDuplicateIdMissingParentAndBadBone() {
        val g = three()
        err(g.add(ch("a")))
        err(g.add(pr("x", parent = "nope")))
        err(g.add(pr("x", parent = null, bone = "mao")))
        val g2 = ok(g.add(pr("p")))
        err(g2.add(pr("y", parent = "p", bone = "mao")))   // pai não é personagem
        ok(g2.add(pr("y", parent = "a", bone = "mao")))
    }

    @Test fun removeDeletesSubtreeAndFixesActive() {
        var g = three()
        g = ok(g.add(pr("p", parent = "a")))
        g = ok(g.remove("a"))
        assertNull(g.get("a")); assertNull(g.get("p"))
        assertEquals("b", g.activeId)
        err(g.remove("a"))
    }

    @Test fun reparentRejectsCycles() {
        var g = three()
        g = ok(g.reparent("b", "a")); g = ok(g.reparent("c", "b"))
        err(g.reparent("a", "c")); err(g.reparent("a", "a"))
        g = ok(g.reparent("c", null)); assertNull(g.get("c")!!.parentId)
        err(g.reparent("b", null, "osso"))
    }

    @Test fun duplicateCopiesSubtreeWithNewIds() {
        var g = three()
        g = ok(g.add(pr("p", parent = "a")))
        var n = 0
        g = ok(g.duplicate("a") { "d${n++}" })
        assertEquals(6, g.nodes.size)
        assertEquals("a (cópia)", g.get("d0")!!.name)
        assertEquals("d0", g.get("d1")!!.parentId)       // filho copiado aponta para a cópia do pai
        assertEquals("a", g.get("p")!!.parentId)         // original intacto
    }

    @Test fun duplicateIsIndependentOfOriginal() {
        var g = three(); var n = 0
        g = ok(g.duplicate("a") { "d${n++}" })
        g = ok(g.setTransform("d0", Transform(px = 5f)))
        assertEquals(0f, g.get("a")!!.local.px, 0f)
        assertEquals(5f, g.get("d0")!!.local.px, 0f)
    }

    @Test fun moveReordersSiblingsOnly() {
        var g = three()
        g = ok(g.move("c", -1)); assertEquals(listOf("a", "c", "b"), g.nodes.map { it.id })
        g = ok(g.move("a", -5)); assertEquals(listOf("a", "c", "b"), g.nodes.map { it.id })
        g = ok(g.move("b", +1)); assertEquals(listOf("a", "c", "b"), g.nodes.map { it.id })
    }

    @Test fun groupWrapsNodesAndRequiresSameParent() {
        var g = three()
        g = ok(g.group(listOf("a", "b"), "grp", "Grupo"))
        assertEquals("grp", g.get("a")!!.parentId); assertEquals("grp", g.get("b")!!.parentId); assertNull(g.get("c")!!.parentId)
        err(g.group(listOf("a", "c"), "g2", "X"))
        err(g.group(emptyList(), "g3", "X"))
    }

    @Test fun lockBlocksTransformAndVisibilityIsInherited() {
        var g = three()
        g = ok(g.reparent("b", "a")); g = ok(g.setLocked("a", true))
        err(g.setTransform("b", Transform(px = 1f)))
        g = ok(g.setLocked("a", false)); g = ok(g.setTransform("b", Transform(px = 1f)))
        g = ok(g.setVisible("a", false))
        assertFalse(g.effectivelyVisible("b")); assertTrue(g.effectivelyVisible("c"))
    }

    @Test fun globalMatrixComposesParentAndChild() {
        var g = SceneGraph()
        g = ok(g.add(SceneNode("p", "p", NodeType.GROUP, local = Transform(px = 10f, sx = 2f, sy = 2f, sz = 2f))))
        g = ok(g.add(SceneNode("c", "c", NodeType.PROP, "p", local = Transform(px = 1f))))
        val m = g.globalMatrix("c")
        assertEquals(12f, m[12], 1e-4f)      // 10 + 2*1
        assertEquals(2f, m[0], 1e-4f)        // escala herdada
        val id = g.globalMatrix("nada"); assertEquals(1f, id[0], 0f); assertEquals(0f, id[12], 0f)
    }

    @Test fun rotationZ90MapsXtoY() {
        val m = Transform(rz = 90f).toMatrix()
        val x = m[0] * 1f; val y = m[1] * 1f   // primeira coluna = imagem de (1,0,0)
        assertEquals(0f, x, 1e-5f); assertEquals(1f, y, 1e-5f)
    }

    @Test fun jsonRoundTripPreservesEverything() {
        var g = three()
        g = ok(g.add(SceneNode("p", "Espada", NodeType.PROP, "a", visible = false, locked = true,
            local = Transform(1f, 2f, 3f, 10f, 20f, 30f, 1f, 2f, 3f), asset = "p.pmx", attachBone = "mao")))
        g = ok(g.setActive("b"))
        val l = SceneSerializer.fromJson(SceneSerializer.toJson(g))
        assertTrue(l.warnings.isEmpty()); assertEquals(g, l.graph)
    }

    @Test fun corruptedAndNewerFilesAreRejected() {
        for (t in listOf("", "{", "{\"nodes\":[]}", "{\"version\":99,\"nodes\":[]}", "{\"version\":1}")) {
            try { SceneSerializer.fromJson(t); fail("devia rejeitar: $t") } catch (e: IllegalArgumentException) { /* esperado */ }
        }
    }

    @Test fun partialDamageBecomesWarningsNotSilentLoss() {
        val t = """{"version":1,"active":"ghost","nodes":[
            {"id":"a","type":"CHARACTER","name":"A","parent":null},
            {"id":"a","type":"CHARACTER","name":"dup"},
            {"id":"x","type":"UFO"},
            {"id":"o","type":"PROP","parent":"sumiu","bone":"mao"},
            {"id":"c1","type":"GROUP","parent":"c2"},{"id":"c2","type":"GROUP","parent":"c1"}]}"""
        val l = SceneSerializer.fromJson(t)
        assertTrue(l.warnings.size >= 5)
        assertEquals(setOf("a", "o", "c1", "c2"), l.graph.nodes.map { it.id }.toSet())
        assertNull(l.graph.get("o")!!.parentId); assertEquals("", l.graph.get("o")!!.attachBone)
        assertNull(l.graph.get("c1")!!.parentId)
        assertEquals("a", l.graph.activeId)
    }

    @Test fun legacyMigrationKeepsModelAndAttachedProps() {
        val props = listOf(
            PropMeta("p1", "Chão", "pmx", 1f, 2f, 3f, 2f),
            PropMeta("p2", "Espada", "glb", 0f, 0f, 0f, 1f, bone = "右手", rx = 5f))
        val g = SceneGraph.fromLegacy("Miku", true, props)
        assertEquals(3, g.nodes.size); assertEquals(SceneGraph.MAIN_CHARACTER_ID, g.activeId)
        val sw = g.get("p2")!!
        assertEquals(SceneGraph.MAIN_CHARACTER_ID, sw.parentId); assertEquals("右手", sw.attachBone); assertEquals(5f, sw.local.rx, 0f)
        assertNull(g.get("p1")!!.parentId); assertEquals(2f, g.get("p1")!!.local.sx, 0f); assertEquals("p1.pmx", g.get("p1")!!.asset)
        // sem modelo: prop "preso" não pode ficar sem pai
        val g2 = SceneGraph.fromLegacy("", false, props)
        assertNull(g2.get("p2")!!.parentId); assertEquals("", g2.get("p2")!!.attachBone); assertNull(g2.activeId)
        assertNotNull(SceneSerializer.fromJson(SceneSerializer.toJson(g)).graph.get("p2"))
    }
}
