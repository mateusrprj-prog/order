package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.MeshMaskPaintMode
import studio.mmd.edit.MeshMaskDeformMode
import studio.mmd.edit.MeshMaskPaintSession
import studio.mmd.edit.ModelToolsSession
import studio.mmd.mmd.PmxModel

class MeshMaskStudioTest {
    private fun square(): PmxModel = PmxModel(
        "mask-square", 2.1f,
        floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 1f,1f,0f),
        FloatArray(12) { if (it % 3 == 2) 1f else 0f }, FloatArray(8),
        IntArray(16) { -1 }, FloatArray(16), intArrayOf(0,1,2, 1,3,2),
        emptyList(), emptyList(), emptyList(), emptyList()
    )

    private fun tetraSpike(): PmxModel = PmxModel(
        "mask-tetra", 2.1f,
        floatArrayOf(2f,2f,2f, 0f,0f,0f, 1f,0f,0f, 0f,1f,0f),
        FloatArray(12), FloatArray(8), IntArray(16) { -1 }, FloatArray(16),
        intArrayOf(0,2,1, 0,1,3, 0,3,2, 1,2,3),
        emptyList(), emptyList(), emptyList(), emptyList()
    )

    @Test fun viewportMaskStrokeSupportsMirrorAndUndoRedo() {
        val m = square(); val mask = MeshMaskPaintSession(m)
        val report = mask.paintStroke(listOf(floatArrayOf(0f,0f,0f)), radius = .2f, mirrorX = true)
        val values = mask.valuesCopy()
        assertTrue(report.changedVertices >= 2)
        assertTrue(values[0] > .9f)
        assertTrue(values[1] > .9f)
        assertTrue(mask.undo())
        assertTrue(mask.valuesCopy().all { it == 0f })
        assertTrue(mask.redo())
        assertTrue(mask.valuesCopy()[0] > .9f)
    }

    @Test fun maskClampModesSmoothAndThresholdAreStable() {
        val m = square(); val mask = MeshMaskPaintSession(m)
        mask.fillVertices(intArrayOf(0,1), .6f)
        mask.paintStroke(listOf(floatArrayOf(0f,0f,0f)), radius = .2f, target = 1f, mode = MeshMaskPaintMode.ADD)
        assertTrue(mask.valuesCopy().all { it in 0f..1f })
        assertArrayEquals(intArrayOf(0,1), mask.thresholdVertices(.5f))
        mask.smooth(3, .4f, keepZero = true)
        assertTrue(mask.valuesCopy().all { it.isFinite() && it in 0f..1f })
    }

    @Test fun geodesicSelectionUsesMeshPathsAndConnectedComponents() {
        val session = ModelToolsSession(square())
        assertEquals(3, session.selectGeodesicRadius(0, 1.1f))
        assertEquals(4, session.selectConnectedComponent(0))
        val disconnected = PmxModel("two-islands", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 5f,0f,0f, 6f,0f,0f, 5f,1f,0f),
            FloatArray(18), FloatArray(12), IntArray(24) { -1 }, FloatArray(24), intArrayOf(0,1,2, 3,4,5),
            emptyList(), emptyList(), emptyList(), emptyList())
        assertEquals(3, ModelToolsSession(disconnected).selectConnectedComponent(4))
    }

    @Test fun maskedRelaxDoesNotMoveUnpaintedVerticesAndHonorsDisplacementCap() {
        val m = PmxModel("closed-tetra", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 0f,0f,1f),
            FloatArray(12), FloatArray(8), IntArray(16) { -1 }, FloatArray(16),
            intArrayOf(0,2,1, 0,1,3, 0,3,2, 1,2,3), emptyList(), emptyList(), emptyList(), emptyList())
        val session = ModelToolsSession(m)
        val mask = floatArrayOf(1f,0f,0f,0f)
        val before = session.positionsCopy()
        val report = session.relaxMasked(mask, iterations = 4, strength = .8f, maxDisplacement = .01f, preserveBoundary = true)
        val after = session.positionsCopy()
        assertTrue(report.changed > 0)
        for (v in 1..3) for (k in 0..2) assertEquals(before[v*3+k], after[v*3+k], 0f)
        val dx=after[0]-before[0]; val dy=after[1]-before[1]; val dz=after[2]-before[2]
        assertTrue(kotlin.math.sqrt(dx*dx+dy*dy+dz*dz) <= .010001f)
        assertTrue(session.undo())
        assertArrayEquals(before, session.positionsCopy(), 0f)
    }

    @Test fun spikeRemovalFindsLocalOutlierAndLeavesMaskedOthers() {
        val m = tetraSpike(); val session = ModelToolsSession(m)
        val before = session.positionsCopy()
        val mask = floatArrayOf(1f,0f,0f,0f)
        val report = session.removeSpikesMasked(mask, strength = 1f, thresholdRatio = 1f, maxCorrection = .05f, preserveBoundary = false)
        val after = session.positionsCopy()
        assertEquals(1, report.changed)
        assertTrue(after[0] < before[0])
        for (v in 1..3) for (k in 0..2) assertEquals(before[v*3+k], after[v*3+k], 0f)
    }
    @Test fun maskedDeformationLeavesZeroWeightVerticesUntouchedAndSupportsUndoRedo() {
        val model = PmxModel("closed", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 0f,0f,1f),
            FloatArray(12), FloatArray(8), IntArray(16) { -1 }, FloatArray(16),
            intArrayOf(0,2,1, 0,1,3, 0,3,2, 1,2,3), emptyList(), emptyList(), emptyList(), emptyList())
        val session = ModelToolsSession(model)
        val mask = floatArrayOf(1f,0f,0f,0f)
        val before = session.positionsCopy()
        val report = session.deformMasked(mask, MeshMaskDeformMode.MOVE, 1f, .01f, .2f, 0f, 0f, false)
        val after = session.positionsCopy()
        assertEquals(1, report.changed)
        assertEquals(.01f, after[0] - before[0], .00001f)
        for (v in 1..3) for (axis in 0..2) assertEquals(before[v * 3 + axis], after[v * 3 + axis], 0f)
        assertTrue(session.undo())
        assertArrayEquals(before, session.positionsCopy(), 0f)
        assertTrue(session.redo())
        assertArrayEquals(after, session.positionsCopy(), 0f)
    }

    @Test fun maskedDeformationModesStayFiniteAndRespectPerVertexLimit() {
        val model = PmxModel("closed", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 0f,0f,1f),
            FloatArray(12), FloatArray(8), IntArray(16) { -1 }, FloatArray(16),
            intArrayOf(0,2,1, 0,1,3, 0,3,2, 1,2,3), emptyList(), emptyList(), emptyList(), emptyList())
        for (mode in MeshMaskDeformMode.values()) {
            val session = ModelToolsSession(model)
            val before = session.positionsCopy()
            val mask = floatArrayOf(1f, .75f, .5f, 0f)
            val report = session.deformMasked(mask, mode, 1f, .02f, .4f, -.3f, .2f, false, 1.4f, 37f, -24f, 51f)
            assertTrue("$mode should affect weighted vertices", report.changed > 0)
            val after = session.positionsCopy()
            for (i in after.indices) assertTrue("$mode produced non-finite position", after[i].isFinite())
            for (v in 0 until 4) {
                val dx = after[v*3] - before[v*3]
                val dy = after[v*3+1] - before[v*3+1]
                val dz = after[v*3+2] - before[v*3+2]
                assertTrue("$mode exceeded displacement cap", kotlin.math.sqrt(dx*dx+dy*dy+dz*dz) <= .02001f)
            }
            for (axis in 0..2) assertEquals(before[9+axis], after[9+axis], 0f)
        }
    }

    @Test fun maskedDeformationProtectsOpenMeshBoundary() {
        val model = square()
        val session = ModelToolsSession(model)
        val before = session.positionsCopy()
        val result = session.deformMasked(FloatArray(4) { 1f }, MeshMaskDeformMode.MOVE, 1f, .05f, .03f, 0f, 0f, true)
        assertEquals(0, result.changed)
        assertArrayEquals(before, session.positionsCopy(), 0f)
        val unprotected = ModelToolsSession(model)
        assertTrue(unprotected.deformMasked(FloatArray(4) { 1f }, MeshMaskDeformMode.MOVE, 1f, .05f, .03f, 0f, 0f, false).changed > 0)
    }

    @Test fun maskedDeformationRejectsMismatchedMaskAndSanitizesMaskWeights() {
        val session = ModelToolsSession(square())
        try {
            session.deformMasked(floatArrayOf(1f), MeshMaskDeformMode.INFLATE)
            fail("expected invalid mask size")
        } catch (_: IllegalArgumentException) { }
        val result = session.deformMasked(floatArrayOf(Float.NaN, .5f, -4f, 0f), MeshMaskDeformMode.MOVE,
            1f, .01f, .01f, 0f, 0f, false)
        assertEquals(1, result.changed)
        assertTrue(session.positionsCopy().all { it.isFinite() })
    }

    @Test fun maskedRotationUsesLocalEulerAxisAroundWeightedCentroid() {
        val model = PmxModel("closed", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 0f,0f,1f),
            FloatArray(12), FloatArray(8), IntArray(16) { -1 }, FloatArray(16),
            intArrayOf(0,2,1, 0,1,3, 0,3,2, 1,2,3), emptyList(), emptyList(), emptyList(), emptyList())
        val session = ModelToolsSession(model)
        val result = session.deformMasked(floatArrayOf(1f,1f,0f,0f), MeshMaskDeformMode.ROTATE,
            1f, .5f, preserveBoundary = false, rotateZ = 90f)
        val after = session.positionsCopy()
        assertTrue(result.changed > 0)
        assertTrue("positive Z rotation should move the negative-X endpoint toward negative Y", after[1] < 0f)
        assertTrue(after.all { it.isFinite() })
    }

}
