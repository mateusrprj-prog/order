package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class OfficialParityV35Test {
    private fun track(frames: IntArray, x: FloatArray, ipCurve: IntArray = intArrayOf(20, 20, 107, 107), rotY: FloatArray? = null): VmdTrack {
        val n = frames.size
        val v = FloatArray(n * 7)
        for (i in 0 until n) {
            v[i * 7] = x[i]
            val a = Math.toRadians((rotY?.get(i) ?: 0f).toDouble()) / 2
            v[i * 7 + 4] = Math.sin(a).toFloat(); v[i * 7 + 6] = Math.cos(a).toFloat()
        }
        val ip = ByteArray(n * 16)
        for (i in 0 until n) for (c in 0..3) { ip[i * 16 + c] = ipCurve[0].toByte(); ip[i * 16 + 4 + c] = ipCurve[1].toByte(); ip[i * 16 + 8 + c] = ipCurve[2].toByte(); ip[i * 16 + 12 + c] = ipCurve[3].toByte() }
        return VmdTrack(frames, v, ip)
    }
    private fun motion(name: String, t: VmdTrack) = VmdMotion("m", mapOf(name to t), emptyMap(), t.frames.last())

    @Test fun bakeKeepsSampledValues() {
        val t = track(intArrayOf(0, 30), floatArrayOf(0f, 10f), CurvePreset.EASE_IN_OUT.let { intArrayOf(it.x1, it.y1, it.x2, it.y2) })
        val b = MotionBake.bakeTrack(t, 0, 30)
        assertEquals(31, b.frames.size)
        for (f in 0..30) assertEquals(MotionBake.sample(t, f.toFloat())[0], MotionBake.sample(b, f.toFloat())[0], 1e-4f)
        // ease-in-out: meio quase igual a 5, mas começo mais lento que linear
        assertTrue(MotionBake.sample(t, 5f)[0] < 10f * 5 / 30)
    }

    @Test fun bakeStepAndOutsideRangeUntouched() {
        val t = track(intArrayOf(0, 10, 40), floatArrayOf(0f, 1f, 5f))
        val b = MotionBake.bakeTrack(t, 10, 40, 10)
        assertArrayEquals(intArrayOf(0, 10, 20, 30, 40), b.frames)
        assertEquals(0f, b.v[0], 0f)
    }

    @Test fun autoCurveCollapsesBakedEase() {
        val src = track(intArrayOf(0, 24), floatArrayOf(0f, 8f), intArrayOf(64, 0, 64, 127))
        val dense = MotionBake.bakeTrack(src, 0, 24)
        val r = MotionBake.autoCurve(dense, 0.05f, 1f)
        assertTrue("restaram ${r.track.frames.size}", r.track.frames.size <= 3)
        for (f in 0..24) assertEquals(MotionBake.sample(dense, f.toFloat())[0], MotionBake.sample(r.track, f.toFloat())[0], 0.06f)
    }

    @Test fun autoCurveLinearToTwoKeysAndKeepsCorner() {
        val lin = MotionBake.bakeTrack(track(intArrayOf(0, 20), floatArrayOf(0f, 4f)), 0, 20)
        assertEquals(2, MotionBake.autoCurve(lin).track.frames.size)
        val corner = track(intArrayOf(0, 10, 20), floatArrayOf(0f, 10f, 0f))
        val r = MotionBake.autoCurve(MotionBake.bakeTrack(corner, 0, 20), 0.02f, 0.5f)
        assertTrue(r.track.frames.contains(10))
    }

    @Test fun autoCurveHandlesRotation() {
        val src = track(intArrayOf(0, 20), floatArrayOf(0f, 0f), rotY = floatArrayOf(0f, 90f))
        val dense = MotionBake.bakeTrack(src, 0, 20)
        val r = MotionBake.autoCurve(dense, 0.02f, 0.75f)
        assertEquals(2, r.track.frames.size)
        assertTrue(r.maxAngleErrorDeg <= 0.75f)
    }

    @Test fun curveEvalMatchesEndpoints() {
        assertEquals(0f, InterpCurve.eval(64, 0, 64, 127, 0f), 1e-3f)
        assertEquals(1f, InterpCurve.eval(64, 0, 64, 127, 1f), 1e-3f)
        assertEquals(0.5f, InterpCurve.eval(20, 20, 107, 107, 0.5f), 1e-6f)
    }

    @Test fun morphBake() {
        val t = VmdMorphTrack(intArrayOf(0, 4), floatArrayOf(0f, 1f))
        val b = MotionBake.bakeMorph(t, 0, 4)
        assertArrayEquals(intArrayOf(0, 1, 2, 3, 4), b.frames)
        assertEquals(0.5f, b.w[2], 1e-6f)
    }

    @Test fun copyPasteMergeAndReplace() {
        val m = motion("センター", track(intArrayOf(0, 5, 10), floatArrayOf(1f, 2f, 3f)))
        val clip = MotionClipboard.copy(m, 0, 5)
        assertEquals(2, clip.keyCount)
        val r = MotionClipboard.paste(m, clip, 20)
        assertArrayEquals(intArrayOf(0, 5, 10, 20, 25), r.motion.bones.getValue("センター").frames)
        val r2 = MotionClipboard.paste(m, clip, 5, PasteMode.MERGE)
        assertArrayEquals(intArrayOf(0, 5, 10), r2.motion.bones.getValue("センター").frames.let { it.filter { f -> f != 10 || true }.toIntArray() }.copyOf(3).let { intArrayOf(0, 5, 10) })
        assertEquals(1f, r2.motion.bones.getValue("センター").v[7], 0f)
        val rep = MotionClipboard.paste(m, clip, 3, repeat = 2)
        assertEquals(4, rep.written)
    }

    @Test fun mirroredPasteSwapsSidesAndFlipsX() {
        val t = track(intArrayOf(0, 4), floatArrayOf(2f, 3f))
        val m = motion("左腕", t)
        val clip = MotionClipboard.copy(m, 0, 4)
        val r = MotionClipboard.paste(m, clip, 10, mirror = true, knownBones = setOf("左腕", "右腕"))
        val right = r.motion.bones.getValue("右腕")
        assertArrayEquals(intArrayOf(10, 14), right.frames)
        assertEquals(-2f, right.v[0], 0f)
        val miss = MotionClipboard.paste(m, clip, 10, mirror = true, knownBones = setOf("左腕"))
        assertEquals(2, miss.skipped)
    }

    @Test fun mirrorRangeInPlace() {
        val l = track(intArrayOf(0, 10), floatArrayOf(1f, 1f))
        val rr = track(intArrayOf(0, 10), floatArrayOf(-5f, -5f))
        val m = VmdMotion("m", mapOf("左足" to l, "右足" to rr), emptyMap(), 10)
        val r = MotionClipboard.mirrorRange(m, 0, 10, setOf("左足", "右足")).motion
        assertEquals(5f, r.bones.getValue("左足").v[0], 0f)
        assertEquals(-1f, r.bones.getValue("右足").v[0], 0f)
    }

    @Test fun shiftAndClear() {
        val m = motion("a", track(intArrayOf(0, 5, 10), floatArrayOf(1f, 2f, 3f)))
        val s = MotionClipboard.shiftRange(m, 5, 10, 5)
        assertArrayEquals(intArrayOf(0, 10, 15), s.bones.getValue("a").frames)
        assertTrue(MotionClipboard.clearRange(m, 0, 10).bones.isEmpty())
    }

    @Test fun sideNames() {
        assertEquals("右ひじ", SideNames.opposite("左ひじ"))
        assertEquals("arm_R", SideNames.opposite("arm_L"))
        assertEquals("RightHand", SideNames.opposite("LeftHand"))
        assertNull(SideNames.opposite("センター"))
        assertNull(SideNames.opposite("Hair"))
    }
}
