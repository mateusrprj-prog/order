package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class PmxModelDoctorTest {
    private fun bone(name: String, parent: Int = -1) = PmxBone(name, name, 0f, 0f, 0f, parent, 0, 0, -1, -1, 0f, null)
    private fun material(count: Int = 3) = PmxMaterial("mat", "mat", floatArrayOf(1f,1f,1f,1f), floatArrayOf(0f,0f,0f), 0f,
        floatArrayOf(0f,0f,0f), 0, floatArrayOf(0f,0f,0f,1f), 0f, -1, -1, 0, true, 0, count)
    private fun valid() = PmxModel("valid", 2.1f,
        floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f),
        floatArrayOf(0f,0f,1f, 0f,0f,1f, 0f,0f,1f), FloatArray(6),
        intArrayOf(0,-1,-1,-1, 0,-1,-1,-1, 0,-1,-1,-1),
        floatArrayOf(1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f),
        intArrayOf(0,1,2), emptyList(), listOf(material()), listOf(bone("root")), emptyList())

    @Test fun cleanPmxHasNoStructuralErrors() {
        val report = PmxModelDoctor.inspect(valid())
        assertTrue(report.healthy)
        assertEquals(0, report.errorCount)
        assertEquals(0, report.warningCount)
    }

    @Test fun catchesBrokenMaterialPartitionBoneCyclesAndSkinning() {
        val m = valid()
        val broken = PmxModel(m.name, m.version, m.positions, m.normals, m.uvs,
            intArrayOf(4,-1,-1,-1, 0,-1,-1,-1, 0,-1,-1,-1),
            floatArrayOf(0.5f,0f,0f,0f, 0.7f,0f,0f,0f, 1f,0f,0f,0f),
            intArrayOf(0,1,8), emptyList(), listOf(material(6)),
            listOf(bone("root", 1), bone("cycle", 0)), emptyList())
        val report = PmxModelDoctor.inspect(broken)
        assertFalse(report.healthy)
        assertTrue(report.issues.any { it.code == "indices.range" })
        assertTrue(report.issues.any { it.code == "material.partition" })
        assertTrue(report.issues.any { it.code == "bone.parent_cycle" })
        assertTrue(report.issues.any { it.code == "skinning.invalid" })
    }

    @Test fun flagsMorphReferencesAndNonFiniteData() {
        val m = valid()
        val badMorph = PmxMorph("m", "m", 0, 1, vertexIdx = intArrayOf(99), vertexDelta = floatArrayOf(Float.NaN,0f,0f))
        val broken = PmxModel(m.name,m.version,floatArrayOf(0f,0f,0f, Float.NaN,0f,0f, 0f,1f,0f),m.normals,m.uvs,
            m.boneIndices,m.boneWeights,m.indices,m.textures,m.materials,m.bones,listOf(badMorph))
        val report = PmxModelDoctor.inspect(broken)
        assertTrue(report.issues.any { it.code == "positions.non_finite" })
        assertTrue(report.issues.any { it.code == "morph.vertex.reference" })
    }
}
