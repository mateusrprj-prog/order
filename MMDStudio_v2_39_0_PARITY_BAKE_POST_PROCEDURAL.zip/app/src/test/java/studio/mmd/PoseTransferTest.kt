package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.PoseSnap
import studio.mmd.mmd.*
import studio.mmd.scene.PoseTransfer

class PoseTransferTest {
    private val ID = ByteArray(16) { if (it < 8) 20 else 107 }
    private fun motion(): VmdMotion {
        val v = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f, 10f, 20f, 0f, 0f, 0f, 0f, 1f)
        return VmdMotion("m", mapOf("センター" to VmdTrack(intArrayOf(0, 10), v, ID + ID)),
            mapOf("笑い" to VmdMorphTrack(intArrayOf(0, 10), floatArrayOf(0f, 1f))), 10)
    }
    @Test fun captureInterpolatesBetweenKeys() {
        val p = PoseTransfer.capture(motion(), 5, "x")
        assertEquals(5f, p.bones.getValue("センター")[0], 1e-5f); assertEquals(10f, p.bones.getValue("センター")[1], 1e-5f)
        assertEquals(0.5f, p.morphs.getValue("笑い"), 1e-5f)
    }
    @Test fun captureBeforeFirstAndAfterLastHolds() {
        assertEquals(10f, PoseTransfer.capture(motion(), 99, "x").bones.getValue("センター")[0], 0f)
        assertEquals(0f, PoseTransfer.capture(motion(), 0, "x").bones.getValue("センター")[0], 0f)
    }
    @Test fun captureOfNullIsEmpty() { val p = PoseTransfer.capture(null, 3, "x"); assertTrue(p.bones.isEmpty() && p.morphs.isEmpty()) }
    @Test fun applyWritesOneKeyAndKeepsTheRest() {
        val pose = PoseSnap("p", mapOf("センター" to floatArrayOf(1f, 2f, 3f, 0f, 0f, 0f, 1f)), mapOf("笑い" to 0.7f))
        val r = PoseTransfer.apply(motion(), pose, 5, null, null)
        assertEquals(2, r.written)
        assertEquals(listOf(0, 5, 10), r.motion.bones.getValue("センター").frames.toList())
        assertEquals(2f, r.motion.bones.getValue("センター").v[1 * 7 + 1], 1e-5f)   // key do quadro 5 é a do meio
        assertEquals(listOf(0, 5, 10), r.motion.morphs.getValue("笑い").frames.toList())
    }
    @Test fun applyOnStoppedExtraCreatesMotion() {
        val pose = PoseSnap("p", mapOf("首" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)), emptyMap())
        val r = PoseTransfer.apply(null, pose, 12, null, null)
        assertEquals(12, r.motion.maxFrame); assertEquals(listOf(12), r.motion.bones.getValue("首").frames.toList())
    }
    @Test fun applyIgnoresBonesMissingInTarget() {
        val pose = PoseSnap("p", mapOf("首" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f), "翼" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)), emptyMap())
        val r = PoseTransfer.apply(null, pose, 0, setOf("首"), emptySet())
        assertEquals(1, r.boneKeys); assertFalse(r.motion.bones.containsKey("翼"))
        assertEquals(0.5f, PoseTransfer.compat(pose, setOf("首")), 0f)
    }
}
