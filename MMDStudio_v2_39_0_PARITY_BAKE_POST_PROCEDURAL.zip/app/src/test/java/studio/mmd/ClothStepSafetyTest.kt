package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.rig.*

class ClothStepSafetyTest {
    @Test fun extremeImpulseRollsBackWholeSolverStep() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f,0f,0f, 1f,0f,0f), intArrayOf(), particleMass = 1f)
        val before = solver.snapshotPositions()
        val result = solver.stepGuarded(1f / 60f, gravityY = 0f, windX = 1e30f, groundY = null,
            safety = ClothStepSafetyConfig(maxDisplacementPerStep = .1f, maxSpeed = 10f))
        assertFalse(result.report.accepted)
        assertTrue(result.report.nonFiniteParticles > 0 || result.report.excessiveDisplacementParticles > 0 || result.report.excessiveSpeedParticles > 0)
        assertArrayEquals(before, result.positions, 0f)
        assertArrayEquals(before, solver.snapshotPositions(), 0f)
    }

    @Test fun normalStepPassesGuardAndKeepsFiniteCoordinates() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f,1f,0f, 1f,1f,0f), intArrayOf(), particleMass = 1f)
        val result = solver.stepGuarded(1f / 60f, gravityY = -9.81f, groundY = null)
        assertTrue(result.report.accepted)
        assertTrue(result.positions.all { it.isFinite() })
        assertEquals(2, result.report.checkedParticles)
    }

    @Test fun resetClearsLastSafetyReportAndRestoresRestPose() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f,1f,0f, 1f,1f,0f), intArrayOf(), particleMass = 1f)
        solver.stepGuarded(1f / 60f, gravityY = -9.81f, groundY = null)
        assertNotNull(solver.lastStepSafetyReport)
        solver.reset()
        assertNull(solver.lastStepSafetyReport)
        assertArrayEquals(floatArrayOf(0f,1f,0f, 1f,1f,0f), solver.snapshotPositions(), 0f)
    }

    @Test fun skinnedSafetyGuardRestoresLocalStateAfterWorldSpaceFailure() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f,0f,0f), intArrayOf())
        val before = solver.snapshotPositions()
        val identity = object : ClothSkinTransform {
            override fun toWorldPosition(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
            override fun toWorldPreviousPosition(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
            override fun toWorldPreviousVector(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
            override fun toLocalPosition(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
            override fun toWorldVector(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
            override fun toLocalVector(vertex:Int,x:Float,y:Float,z:Float,out:FloatArray) { out[0]=x;out[1]=y;out[2]=z }
        }
        val result = solver.stepSkinned(1f/60f, identity, gravityY=0f, windX=1e30f, groundY=null,
            safety=ClothStepSafetyConfig(maxDisplacementPerStep=.1f,maxSpeed=10f))
        assertArrayEquals(before, result, 0f)
        assertFalse(solver.lastStepSafetyReport!!.accepted)
        assertArrayEquals(before, solver.snapshotPositions(), 0f)
    }
}
