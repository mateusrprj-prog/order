package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.rig.*

class SkirtGuardQualityTest {
    @Test fun qualityDetectsDegenerateAndInvalidTriangles() {
        val p = floatArrayOf(0f,0f,0f, 1f,0f,0f, 2f,0f,0f, Float.NaN,0f,0f)
        val report = SkirtGuardMeshQuality.analyze(p, intArrayOf(0,1,2, 0,1,9, 0,1,3))
        assertEquals(1, report.degenerateTriangles)
        assertEquals(2, report.invalidTriangles)
        assertEquals(1, report.nonFiniteVertices)
        assertFalse(report.valid)
    }

    @Test fun edgeStretchUsesReferenceMesh() {
        val reference = floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f)
        val moved = floatArrayOf(0f,0f,0f, 3f,0f,0f, 0f,1f,0f)
        val q = SkirtGuardMeshQuality.analyze(moved, intArrayOf(0,1,2), reference, stretchThreshold = 2f)
        assertTrue(q.stretchedEdges >= 1)
        assertTrue(q.maxEdge >= 3f)
    }

    @Test fun regionalMaskIsFiniteBoundedAndRespectBaseMask() {
        val p = floatArrayOf(-1f,0f,-1f, 1f,0f,-1f, -1f,0f,1f, 1f,0f,1f)
        val idx = intArrayOf(0,1,2, 1,3,2)
        val base = floatArrayOf(1f,0f,1f,1f)
        val weights = SkirtGuardRegionWeights.build(p, idx, SkirtCorrectionRegion.FRONT, 0.2f, 4, 0.35f, base)
        assertEquals(0f, weights[1], 0f)
        assertTrue(weights.all { it.isFinite() && it in 0f..1f })
        assertNotEquals(0f, weights[3])
    }

    @Test fun noDiffusionProducesDeterministicRegionWeights() {
        val p = floatArrayOf(-1f,0f,0f, 1f,0f,0f, 0f,0f,1f)
        val a = SkirtGuardRegionWeights.build(p, intArrayOf(0,1,2), SkirtCorrectionRegion.RIGHT)
        val b = SkirtGuardRegionWeights.build(p, intArrayOf(0,1,2), SkirtCorrectionRegion.RIGHT)
        assertArrayEquals(a, b, 0f)
        assertTrue(a[1] > a[0])
    }
}
