package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import kotlin.math.abs
import kotlin.math.tan

class OfficialParityV29Test {

    private fun linearIp(): ByteArray {
        val b = ByteArray(16)
        for (c in 0..3) { b[c] = 20; b[4 + c] = 20; b[8 + c] = 107; b[12 + c] = 107 }
        return b
    }

    private fun track(frames: IntArray, x: FloatArray, ipOf: (Int) -> ByteArray = { linearIp() }): VmdTrack {
        val v = FloatArray(frames.size * 7)
        val ip = ByteArray(frames.size * 16)
        for (i in frames.indices) {
            v[i * 7] = x[i]; v[i * 7 + 6] = 1f
            ipOf(i).copyInto(ip, i * 16)
        }
        return VmdTrack(frames, v, ip)
    }

    @Test fun insertAndDeleteFramesShiftKeys() {
        val t = track(intArrayOf(0, 10, 20), floatArrayOf(0f, 1f, 2f))
        val ins = MotionFrameOps.insertFrames(t, 10, 5)
        assertArrayEquals(intArrayOf(0, 15, 25), ins.frames)
        val del = MotionFrameOps.deleteFrames(ins, 10, 10)
        assertArrayEquals(intArrayOf(0, 15), del.frames)
    }

    @Test fun deleteRangeDropsKeysInsideAndPullsRest() {
        val t = track(intArrayOf(0, 10, 20, 30), floatArrayOf(0f, 1f, 2f, 3f))
        val d = MotionFrameOps.deleteFrames(t, 10, 10)
        assertArrayEquals(intArrayOf(0, 10, 20), d.frames)
        assertEquals(2f, d.v[7], 1e-6f)    // o key do frame 20 (x=2) virou frame 10
        assertEquals(3f, d.v[14], 1e-6f)   // o key do frame 30 (x=3) virou frame 20
    }

    @Test fun reverseRangeMirrorsTimeAndFlipsCurves() {
        val ease = ByteArray(16)
        for (c in 0..3) { ease[c] = 64; ease[4 + c] = 0; ease[8 + c] = 127; ease[12 + c] = 64 }
        val t = track(intArrayOf(0, 10, 20), floatArrayOf(0f, 5f, 9f)) { i -> if (i == 2) ease else linearIp() }
        val r = MotionFrameOps.reverseRange(t, 0, 20)
        assertArrayEquals(intArrayOf(0, 10, 20), r.frames)
        assertEquals(9f, r.v[0], 1e-6f); assertEquals(5f, r.v[7], 1e-6f); assertEquals(0f, r.v[14], 1e-6f)
        // segmento 10→20 original (ease) agora é o segmento 0→10, guardado no key do frame 10, invertido
        assertEquals(127 - 127, r.ip[16 + 0].toInt() and 0xFF)      // x1 = 127 - x2
        assertEquals(127 - 64, r.ip[16 + 4].toInt() and 0xFF)       // y1 = 127 - y2
        assertEquals(127 - 64, r.ip[16 + 8].toInt() and 0xFF)       // x2 = 127 - x1
        assertEquals(127 - 0, r.ip[16 + 12].toInt() and 0xFF)       // y2 = 127 - y1
    }

    @Test fun reduceKeysRemovesCollinearAndKeepsCorner() {
        val t = track(intArrayOf(0, 5, 10, 15, 20), floatArrayOf(0f, 1f, 2f, 3f, 10f))
        val r = MotionFrameOps.reduceKeys(t, positionTol = 0.01f, angleTolDeg = 0.5f)
        assertTrue(r.removed >= 2)
        assertTrue(r.track.frames.contains(0)); assertTrue(r.track.frames.contains(20))
        assertTrue("o canto (frame 15) deve ficar", r.track.frames.contains(15))
        assertFalse(r.track.frames.contains(5))
    }

    @Test fun reduceKeysRespectsNonLinearCurves() {
        val curved = ByteArray(16)
        for (c in 0..3) { curved[c] = 0; curved[4 + c] = 100; curved[8 + c] = 100; curved[12 + c] = 0 }
        val t = track(intArrayOf(0, 5, 10), floatArrayOf(0f, 1f, 2f)) { i -> if (i == 1) curved else linearIp() }
        val r = MotionFrameOps.reduceKeys(t, 0.01f, 0.5f, respectCurves = true)
        assertEquals(0, r.removed)
    }

    @Test fun morphOpsWork() {
        val m = VmdMorphTrack(intArrayOf(0, 10, 20, 30), floatArrayOf(0f, 0.5f, 1f, 1f))
        assertArrayEquals(intArrayOf(0, 15, 25, 35), MotionFrameOps.insertFrames(m, 10, 5).frames)
        val rev = MotionFrameOps.reverseRange(m, 0, 30)
        assertArrayEquals(intArrayOf(0, 10, 20, 30), rev.frames)
        assertEquals(1f, rev.w[0], 1e-6f); assertEquals(0f, rev.w[3], 1e-6f)
        val red = MotionFrameOps.reduceKeys(m, 0.01f)
        assertEquals(1, red.removed)   // o key 10 é colinear entre 0 e 20
    }

    @Test fun cameraInsertShiftsAllChannels() {
        val frames = intArrayOf(0, 20)
        val ip = ByteArray(48) { 20 }
        val cam = VmdCamera(frames, floatArrayOf(30f, 15f), floatArrayOf(0f, 5f, 0f, 10f, 15f, 2f), FloatArray(6), floatArrayOf(45f, 60f), ip)
        val s = MotionFrameOps.insertFrames(cam, 10, 7)
        assertArrayEquals(intArrayOf(0, 27), s.frames)
        assertEquals(15f, s.dist[1], 1e-6f)
        assertEquals(15f, s.pos[4], 1e-6f)
    }

    @Test fun motionInsertShiftsExtrasToo() {
        val bones = mapOf("センター" to track(intArrayOf(0, 10), floatArrayOf(0f, 1f)))
        val ik = mapOf("左足ＩＫ" to VmdIkTrack(intArrayOf(0, 10), booleanArrayOf(true, false)))
        val m = VmdMotion("m", bones, emptyMap(), 10, emptyList(), VmdExtras(ik = ik))
        val n = MotionFrameOps.insertFrames(m, 5, 10)
        assertEquals(20, n.maxFrame)
        assertArrayEquals(intArrayOf(0, 20), n.extras.ik["左足ＩＫ"]!!.frames)
        assertFalse(n.extras.ik["左足ＩＫ"]!!.at(20f))
    }

    @Test fun holdKeyKeepsWorldPositionAcrossParentSwitch() {
        val parentA = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 3f, 0f, 0f, 1f)   // pai em x=3
        val child = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 5f, 2f, 0f, 1f)     // filho em (5,2,0)
        val k = OuterParent.holdKey(10, 1, 0, parentA, child)!!
        val track = AttachTrack(0, 0, listOf(k))
        // pai se move para x=8: o filho acompanha, mantendo o deslocamento (+2,+2,0)
        val parentLater = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 8f, 0f, 0f, 1f)
        val w = OuterParent.resolve(track, 12f) { _, _ -> parentLater }!!
        assertEquals(10f, w[12], 1e-4f); assertEquals(2f, w[13], 1e-4f)
        // no próprio frame da troca, com o pai na mesma pose, o filho fica onde estava
        val w0 = OuterParent.resolve(track, 10f) { _, _ -> parentA }!!
        assertEquals(5f, w0[12], 1e-4f); assertEquals(2f, w0[13], 1e-4f)
        // antes do primeiro key não há pai ativo
        assertNull(OuterParent.resolve(track, 5f) { _, _ -> parentA })
    }

    @Test fun attachTrackEncodeDecodeRoundTrip() {
        val off = FloatArray(16) { if (it % 5 == 0) 1f else 0f }; off[12] = 1.5f
        val t = AttachTrack(2, 7, listOf(AttachKey(0, -1, -1, null), AttachKey(30, 1, 12, off)))
        val d = OuterParent.decode(OuterParent.encode(t))!!
        assertEquals(2, d.childModel); assertEquals(7, d.childBone)
        assertEquals(2, d.keys.size)
        assertEquals(30, d.keys[1].frame); assertEquals(12, d.keys[1].parentBone)
        assertEquals(1.5f, d.keys[1].offset!![12], 1e-6f)
        assertNull(OuterParent.decode("lixo"))
    }

    @Test fun invertIsCorrectForAffine() {
        val m = floatArrayOf(2f, 0f, 0f, 0f, 0f, 3f, 0f, 0f, 0f, 0f, 4f, 0f, 1f, 2f, 3f, 1f)
        val inv = OuterParent.invert(m)!!
        val id = OuterParent.mul(m, inv)
        for (i in 0 until 16) assertEquals(OuterParent.IDENTITY[i], id[i], 1e-5f)
        assertNull(OuterParent.invert(FloatArray(16)))
    }

    @Test fun shakeIsDeterministicAndBounded() {
        val s = CameraRig.Shake(posAmp = 0.5f, rotAmpDeg = 1f, frequencyHz = 6f, seed = 7, startFrame = 10, durationFrames = 30)
        val a = floatArrayOf(30f, 0f, 10f, 0f, 0f, 0f, 0f, 45f)
        val b = a.copyOf()
        CameraRig.applyShake(a, s, 20f); CameraRig.applyShake(b, s, 20f)
        assertArrayEquals(a, b, 0f)
        val outside = floatArrayOf(30f, 0f, 10f, 0f, 0f, 0f, 0f, 45f)
        CameraRig.applyShake(outside, s, 5f)
        assertEquals(0f, outside[1], 0f)
        for (f in 10..40) {
            val o = floatArrayOf(30f, 0f, 10f, 0f, 0f, 0f, 0f, 45f)
            CameraRig.applyShake(o, s, f.toFloat())
            assertTrue(abs(o[1]) <= 0.5f * 1.01f)
        }
    }

    @Test fun dollyZoomKeepsSubjectSizeConstant() {
        val f0 = 40f
        val f = CameraRig.dollyZoomFov(f0, 20f, 40f)
        val a = tan(Math.toRadians(f0.toDouble()) / 2) * 20.0
        val b = tan(Math.toRadians(f.toDouble()) / 2) * 40.0
        assertEquals(a, b, 1e-3)
    }

    @Test fun followMovesCenterTowardTarget() {
        val o = floatArrayOf(30f, 0f, 10f, 0f, 0f, 0f, 0f, 45f)
        CameraRig.follow(o, floatArrayOf(10f, 20f, 30f), floatArrayOf(0f, 1f, 0f), 0.5f)
        assertEquals(5f, o[1], 1e-5f); assertEquals(15.5f, o[2], 1e-5f); assertEquals(15f, o[3], 1e-5f)
    }

    @Test fun orbitCoversRequestedAngles() {
        val c = CameraRig.orbit(floatArrayOf(0f, 10f, 0f), 25f, -10f, 0f, 90f, 120, keys = 5)
        assertEquals(5, c.frames.size); assertEquals(0, c.frames[0]); assertEquals(120, c.frames[4])
        assertEquals(Math.toRadians(90.0).toFloat(), c.rot[4 * 3 + 1], 1e-5f)
    }

    @Test fun curvePresetApplyWritesChosenChannelsOnly() {
        val t = track(intArrayOf(0, 10, 20), floatArrayOf(0f, 1f, 2f))
        val r = CurvePreset.apply(t, CurvePreset.EASE_IN_OUT, 1, 2, booleanArrayOf(true, false, false, false))
        assertEquals(64, r.ip[16].toInt() and 0xFF)        // key 1, canal X, x1
        assertEquals(20, r.ip[17].toInt() and 0xFF)        // canal Y intacto
        assertEquals(20, r.ip[0].toInt() and 0xFF)         // key 0 intacto
    }

    @Test fun waveformPeaksAndBeats() {
        val sr = 3000; val fps = 30
        val pcm = ShortArray(sr * 2)    // 2 s, mono; um pulso a cada 0,5 s
        for (beat in 0 until 4) { val s0 = beat * sr / 2; for (i in 0 until 100) pcm[s0 + i] = 20000 }
        val p = WaveformPeaks.peaks(pcm, 1, sr, fps, 60)
        assertTrue(p[0] > 0.5f); assertEquals(0f, p[3], 1e-6f)
        val rms = WaveformPeaks.rms(pcm, 1, sr, fps, 60)
        val beats = BeatMarkers.detect(rms, window = 8, sensitivity = 1.3f, minGapFrames = 6)
        assertTrue("esperava ~4 batidas, veio ${beats.size}", beats.size in 3..4)
        assertEquals(15, BeatMarkers.snap(14, intArrayOf(0, 15, 30), 3))
        assertEquals(40, BeatMarkers.snap(40, intArrayOf(0, 15, 30), 3))
        assertTrue(BeatMarkers.estimateBpm(intArrayOf(0, 15, 30, 45), 30) in 100f..140f)
    }

    @Test fun onionSkinPlanFadesAndClamps() {
        val g = OnionSkin.plan(current = 2, before = 3, after = 2, step = 2, maxFrame = 5)
        assertEquals(listOf(0, 4), g.map { it.frame })     // antes: só o frame 0 cabe; depois: 4 cabe, 6 passa do máximo
        assertTrue(g.all { it.alpha in 0.02f..1f })
    }

    @Test fun cameraRigActionsMergeOnlyTheAffectedRange() {
        val base = CameraMotionTools.put(null, 0, CameraPose(distance = 30f, y = 10f, fov = 45f))
        val orbit = CameraRigActions.orbitFrom(base, 10, 120, 360f, 12)
        assertTrue(orbit.frames.contains(0))          // key antigo preservado
        assertTrue(orbit.frames.contains(10)); assertTrue(orbit.frames.contains(130))
        val shaken = CameraRigActions.shakeRange(base, CameraRig.Shake(startFrame = 0, durationFrames = 20), 0, 20, 2)!!
        assertTrue(shaken.frames.size >= 10)
        assertNull(CameraRigActions.shakeRange(null, CameraRig.Shake(), 0, 10))
        val dolly = CameraRigActions.dollyFrom(base, 0, 60, 0.5f)
        val out = FloatArray(8)
        dolly.evaluate(60f, out)
        assertEquals(15f, out[0], 0.01f)
        val a = tan(Math.toRadians(45.0) / 2) * 30.0
        val b = tan(Math.toRadians(out[7].toDouble()) / 2) * out[0]
        assertEquals(a, b, 0.05)
    }
}
