package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.cartoon.*
import studio.mmd.edit.Euler
import studio.mmd.mmd.*

/** v1.29.6 — sinais de eixo do Cartoon MEDIDOS com o Animator real (MMD: o personagem olha para -Z; Y para cima; esquerda = +X). */
class CartoonAxisTest {
    private fun bone(n: String, x: Float, y: Float, z: Float, p: Int, ik: PmxIk? = null) = PmxBone(n, n, x, y, z, p, 0, 0x001F, -1, -1, 0f, ik)
    private val bs = listOf(
        bone("センター", 0f, 8f, 0f, -1), bone("上半身", 0f, 10f, 0f, 0), bone("首", 0f, 13f, 0f, 1),
        bone("左腕", 1.5f, 12.5f, 0f, 1), bone("左ひじ", 4f, 12.5f, 0f, 3), bone("左手首", 6.5f, 12.5f, 0f, 4),
        bone("下半身", 0f, 8f, 0f, 0), bone("左足", 0.8f, 7.5f, 0f, 6), bone("左ひざ", 0.8f, 4f, 0f, 7), bone("左足首", 0.8f, 1f, 0f, 8),
        bone("左足ＩＫ", 0.8f, 1f, 0f, 0, PmxIk(9, 40, 0.5f, listOf(PmxIkLink(8, false, null, null), PmxIkLink(7, false, null, null)))))
    private val model = PmxModel("t", 2f, FloatArray(0), FloatArray(0), FloatArray(0), IntArray(0), FloatArray(0), IntArray(0), emptyList(), emptyList(), bs, emptyList())

    /** Desloca [watch] (x,y,z em coordenadas MMD) ao aplicar [pb] no quadro 0. */
    private fun delta(pb: CartoonBuiltin.PB, watch: String, ikOn: Boolean = false): FloatArray {
        val tracks = HashMap<String, VmdTrack>()
        for ((n, a) in pb.r) { val q = Euler.quat(a[0], a[1], a[2]); tracks[n] = VmdTrack(intArrayOf(0), floatArrayOf(a[3], a[4], a[5], q[0], q[1], q[2], q[3]), ByteArray(16)) }
        val an = Animator(model, 1f); an.motion = VmdMotion("t", tracks, emptyMap(), 0, emptyList(), if (ikOn) VmdExtras.EMPTY else VmdExtras(ik = mapOf("左足ＩＫ" to VmdIkTrack(intArrayOf(0), booleanArrayOf(false)))))
        an.evaluatePose(0f)
        val out = FloatArray(bs.size * 3); an.boneGl(out)
        val i = bs.indexOfFirst { it.name == watch }
        return floatArrayOf(out[i * 3] - bs[i].x, out[i * 3 + 1] - bs[i].y, -out[i * 3 + 2] - bs[i].z)
    }

    @Test fun armUpRaisesTheWrist() { assertTrue(delta(CartoonBuiltin.PB().arms(30f), "左手首")[1] > 1f) }
    @Test fun armForwardGoesToMinusZ() { assertTrue(delta(CartoonBuiltin.PB().arms(0f, 30f), "左手首")[2] < -1f) }
    @Test fun leanForwardMovesNeckToMinusZ() { assertTrue(delta(CartoonBuiltin.PB().lean(20f), "首")[2] < -1f) }
    @Test fun legSwingForwardMovesAnkleToMinusZ() { assertTrue(delta(CartoonBuiltin.PB().legs(30f, 0f), "左足首")[2] < -1f) }
    @Test fun kneeBendMovesAnkleBackward() { assertTrue(delta(CartoonBuiltin.PB().legs(0f, 0f, 40f, 0f), "左足首")[2] > 1f) }

    /** O sintoma original: com o IK ligado, o IK refaz a perna e o movimento FK some ("pés não mexem"). */
    @Test fun legIkOnCancelsTheFkSwing() {
        val on = delta(CartoonBuiltin.PB().legs(30f, 0f), "左足首", ikOn = true)
        val off = delta(CartoonBuiltin.PB().legs(30f, 0f), "左足首", ikOn = false)
        assertTrue("com IK ligado o tornozelo quase não sai do lugar", Math.abs(on[2]) < 0.5f)
        assertTrue(off[2] < -1f)
    }
    @Test fun ikDrivingFindsLegIkOnly() {
        assertEquals(listOf("左足ＩＫ"), ikBonesDriving(model, listOf("左足", "左腕")))
        assertEquals(emptyList<String>(), ikBonesDriving(model, listOf("左腕", "首")))
    }
    @Test fun ikRangeOffThenRestores() {
        val t = IkRange.off(emptyMap(), listOf("左足ＩＫ"), 10, 40).getValue("左足ＩＫ")
        assertTrue(t.at(0f)); assertTrue(t.at(9f)); assertFalse(t.at(10f)); assertFalse(t.at(40f)); assertTrue(t.at(41f))
    }
    @Test fun ikRangeKeepsPreviousOffState() {
        val old = mapOf("a" to VmdIkTrack(intArrayOf(0, 100), booleanArrayOf(false, true)))
        val t = IkRange.off(old, listOf("a"), 10, 20).getValue("a")
        assertFalse(t.at(5f)); assertFalse(t.at(15f)); assertFalse(t.at(21f)); assertTrue(t.at(100f))
    }
}
