package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AdditionalUvMorphTest {
    private fun morph(type: Int, indexSize: Int = 2): PmxMorph {
        val b=ByteBuffer.allocate(indexSize+16).order(ByteOrder.LITTLE_ENDIAN)
        when(indexSize){1->b.put(0);2->b.putShort(0);else->b.putInt(0)}
        for(v in floatArrayOf(0.1f,0.2f,0.3f,0.4f)) b.putFloat(v)
        return PmxMorph("uv$type","uv$type",0,type,raw=b.array(),count=1)
    }
    @Test fun decoderMapsTypesToChannels(){
        for(type in 4..7) assertEquals(type-4,AdditionalUvMorph.decode(morph(type))!!.channel)
    }
    @Test fun allFourVectorComponentsAreApplied(){
        val state=FloatArray(2*2*4)
        val m=AdditionalUvMorph.decode(morph(4))!!
        assertTrue(m.apply(state,2,0.5f))
        assertArrayEquals(floatArrayOf(0.05f,0.1f,0.15f,0.2f),state.copyOfRange(0,4),1e-6f)
    }
    @Test fun channelOffsetUsesVertexMajorLayout(){
        val state=FloatArray(2*2*4)
        val m=AdditionalUvMorph.decode(morph(5))!!
        m.apply(state,2,1f)
        assertArrayEquals(floatArrayOf(0.1f,0.2f,0.3f,0.4f),state.copyOfRange(4,8),1e-6f)
    }
    @Test fun invalidChannelCountDoesNotWrite(){
        val state=FloatArray(4); val m=AdditionalUvMorph.decode(morph(7))!!
        assertFalse(m.apply(state,1,1f)); assertArrayEquals(FloatArray(4),state,0f)
    }
}
