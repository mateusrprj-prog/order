package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import studio.mmd.rig.*

/** v2.7.0 — CCD de cápsulas, correção regional, undo/redo e cache vinculado ao VMD/solver. */
class SkirtGuardAdvancedTest {
    @Test fun sweptCapsuleCatchesFastPassThrough() {
        val cloth = ClothXpbd.fromMesh(
            floatArrayOf(0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f),
            intArrayOf(0, 1, 2)
        )
        val before = ClothCapsule(-0.22f, -0.2f, 0f, -0.22f, 0.2f, 0f, 0.07f)
        val after = ClothCapsule(0.22f, -0.2f, 0f, 0.22f, 0.2f, 0f, 0.07f)
        cloth.setSweptCapsules(listOf(before), listOf(after))
        val result = cloth.step(1f / 60f, gravityY = 0f, substeps = 1, iterations = 2, damping = 0f, groundY = null)
        assertTrue(result.all(Float::isFinite))
        // O volume passa pelo vértice e termina do outro lado: o teste varrido deve impedir que ele fique no ponto original.
        assertTrue(kotlin.math.abs(result[0]) > 0.12f || kotlin.math.abs(result[2]) > 0.12f)
    }

    @Test fun regionalAutoFixLeavesOppositeHemisphereUntouched() {
        val original = floatArrayOf(0f, 0f, 0.2f, 0f, 0f, -0.2f)
        val originalCopy = original.copyOf()
        val capsule = ClothCapsule(0f, -1f, 0f, 0f, 1f, 0f, 0.5f)
        val report = SkirtGuardStudio.autoFix(
            original, intArrayOf(0, 1), listOf(capsule), maxDisplacement = 0.15f,
            strength = 1f, passes = 2, region = SkirtCorrectionRegion.FRONT
        )
        assertTrue(report.positions[2] > original[2])
        assertEquals(original[5], report.positions[5], 0f)
        assertArrayEquals(originalCopy, original, 0f) // input permanece imutável
    }

    @Test fun correctionHistoryUndoRedoAndComparisonAreIndependent() {
        val history = SkirtGuardCorrectionHistory(maxEntries = 3, maxStoredFloats = 100)
        val before = floatArrayOf(0f, 1f, 2f)
        val after = floatArrayOf(0.2f, 1.1f, 2.2f)
        assertTrue(history.record(before, after))
        assertNull(history.undo(floatArrayOf(99f, 1f, 2f))) // impede aplicar snapshot sobre outro bake
        assertTrue(history.canUndo)
        val undo = history.undo(after)!!
        assertArrayEquals(before, undo, 0f)
        assertTrue(history.canRedo)
        assertNull(history.redo(after)) // a pilha também valida o estado de origem
        assertTrue(history.canRedo)
        val redo = history.redo(undo)!!
        assertArrayEquals(after, redo, 0f)
        redo[0] = 99f
        assertEquals(0.2f, history.comparison()!!.after[0], 0f)
    }

    @Test fun clothCacheV4BindsMotionAndSimulationSignatures() {
        val cache = ClothBakeCache(1, 30, listOf(floatArrayOf(1f, 2f, 3f)), 11L, 22L, 33L)
        val decoded = ClothCacheCodec.decode(ClothCacheCodec.encode(cache))
        assertEquals(11L, decoded.modelHash)
        assertEquals(22L, decoded.simulationHash)
        assertEquals(33L, decoded.motionHash)
        assertEquals(4, decoded.signatureVersion)
        assertTrue(ClothCacheCodec.isCompatible(decoded, 1, 30, 11L, 22L, 33L))
        assertFalse(ClothCacheCodec.isCompatible(decoded, 1, 30, 11L, 22L, 34L))
        assertFalse(ClothCacheCodec.isCompatible(decoded, 1, 30, 11L, 23L, 33L))
        try {
            ClothCacheCodec.mergeFrameRange(decoded, 1, listOf(floatArrayOf(4f, 5f, 6f)), 1, 30, 11L,
                floatArrayOf(0f, 0f, 0f), simulationHash = 99L, motionHash = 33L)
            fail("Não pode mesclar frames de outro perfil físico")
        } catch (expected: IllegalArgumentException) { assertTrue(expected.message!!.contains("cache anterior")) }
    }

    @Test fun legacyCacheVersionsRemainReadableButAreNotTrustedForV27PartialBake() {
        fun legacy(version: Int): ByteArray {
            val header = when (version) { 1 -> 32; 2 -> 40; 3 -> 56; else -> error("version") }
            val buffer = java.nio.ByteBuffer.allocate(header + 12 + 4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buffer.put(byteArrayOf(77, 77, 68, 67, 76, 84, 72, 49))
            buffer.putInt(version); buffer.putInt(1); buffer.putInt(30); buffer.putInt(1); buffer.putLong(12L)
            if (version >= 2) buffer.putLong(77L)
            if (version >= 3) { buffer.putLong(88L); buffer.putLong(99L) }
            buffer.putFloat(1f); buffer.putFloat(2f); buffer.putFloat(3f)
            val crc = java.util.zip.CRC32(); crc.update(buffer.array(), 0, buffer.position())
            buffer.putInt(crc.value.toInt())
            return buffer.array()
        }
        val v1 = ClothCacheCodec.decode(legacy(1))
        val v2 = ClothCacheCodec.decode(legacy(2))
        val v3 = ClothCacheCodec.decode(legacy(3))
        assertEquals(0L, v1.modelHash)
        assertEquals(77L, v2.modelHash)
        assertEquals(0L, v1.simulationHash)
        assertEquals(0L, v2.motionHash)
        assertEquals(88L, v3.simulationHash)
        assertEquals(99L, v3.motionHash)
        assertEquals(3, v3.signatureVersion)
        assertFalse(ClothCacheCodec.isCompatible(v2, 1, 30, 77L, 22L, 33L))
        assertFalse(ClothCacheCodec.isCompatible(v3, 1, 30, 77L, 88L, 99L))
    }

    @Test fun historyCanRedoAtCapacityWithoutDuplicatingEntries() {
        val history = SkirtGuardCorrectionHistory(maxEntries = 1, maxStoredFloats = 100)
        val a = floatArrayOf(0f, 0f, 0f)
        val b = floatArrayOf(1f, 0f, 0f)
        assertTrue(history.record(a, b))
        assertArrayEquals(a, history.undo(b)!!, 0f)
        assertTrue(history.canRedo)
        assertArrayEquals(b, history.redo(a)!!, 0f)
        assertEquals(1, history.size)
        assertFalse(history.canRedo)
    }

    @Test fun pmxSignatureTracksSkinWeightsAndMorphDeltas() {
        fun model(weight: Float, delta: Float): studio.mmd.mmd.PmxModel = studio.mmd.mmd.PmxModel(
            "fixture", 2.0f,
            floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f),
            FloatArray(9), FloatArray(6),
            intArrayOf(0, -1, -1, -1, 0, -1, -1, -1, 0, -1, -1, -1),
            floatArrayOf(weight, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f),
            intArrayOf(0, 1, 2), emptyList(), emptyList(),
            listOf(studio.mmd.mmd.PmxBone("root", "root", 0f, 0f, 0f, -1, 0, 0, -1, -1, 0f, null)),
            listOf(studio.mmd.mmd.PmxMorph("morph", "morph", 1, 1,
                vertexIdx = intArrayOf(0), vertexDelta = floatArrayOf(delta, 0f, 0f), count = 1))
        )
        val base = ClothCacheCodec.modelSignature(model(1f, 0.1f))
        assertNotEquals(base, ClothCacheCodec.modelSignature(model(0.8f, 0.1f)))
        assertNotEquals(base, ClothCacheCodec.modelSignature(model(1f, 0.2f)))
    }

    @Test fun vmdSignatureChangesWhenCurveDataChanges() {
        val a = VmdMotion("m", mapOf("センター" to VmdTrack(intArrayOf(0), floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f), ByteArray(16))), emptyMap(), 0)
        val b = VmdMotion("m", mapOf("センター" to VmdTrack(intArrayOf(0), floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 1f), ByteArray(16))), emptyMap(), 0)
        assertNotEquals(ClothCacheCodec.motionSignature(a), ClothCacheCodec.motionSignature(b))
    }

    @Test fun clothQualityReportFlagsStretchWithoutNonFiniteValues() {
        val cloth = ClothXpbd.fromMesh(floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f), intArrayOf(0, 1, 2))
        val report = cloth.qualityReport()
        assertEquals(3, report.vertexCount)
        assertEquals(0, report.invalidVertices)
        assertTrue(report.checkedEdges >= 3)
        assertTrue(report.maxStretchRatio >= 1f)
    }
}
