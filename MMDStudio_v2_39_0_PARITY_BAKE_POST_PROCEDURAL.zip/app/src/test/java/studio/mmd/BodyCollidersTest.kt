package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.Euler
import studio.mmd.mmd.*
import studio.mmd.rig.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** v1.34.0 — colisores corporais gerados do esqueleto e integração com o motor de física. */
class BodyCollidersTest {
    private fun bone(n: String, x: Float, y: Float, z: Float, p: Int, en: String = n) = PmxBone(n, en, x, y, z, p, 0, 0x001F, -1, -1, 0f, null)
    private fun rigid(n: String, b: Int, mode: Int, group: Int = 0, shape: Int = 0, size: FloatArray = floatArrayOf(0.3f, 0f, 0f), pos: FloatArray = FloatArray(3)) =
        PmxRigid(n, "", b, group, shape, 1f, 0.5f, 0.5f, mode, 0, size, pos)

    // 0 センター, 1 下半身, 2 左足, 3 左ひざ, 4 左足首, 5 右足, 6 右ひざ, 7 右足首, 8 左足ＩＫ, 9 左足D, 10 スカート(osso da saia)
    private fun bones() = listOf(
        bone("センター", 0f, 10.5f, 0f, -1), bone("下半身", 0f, 10.5f, 0f, 0),
        bone("左足", 0.9f, 10f, 0f, 1), bone("左ひざ", 0.9f, 5f, 0.2f, 2), bone("左足首", 0.9f, 1f, 0f, 3),
        bone("右足", -0.9f, 10f, 0f, 1), bone("右ひざ", -0.9f, 5f, 0.2f, 5), bone("右足首", -0.9f, 1f, 0f, 6),
        bone("左足ＩＫ", 0.9f, 0f, 0f, 0), bone("左足D", 0.9f, 10f, 0f, 1),
        bone("スカート", 0.9f, 8f, 0f, 1)
    )

    /** Vértices em anel (raio r) ao redor do segmento a→b, pesados 100% no osso dado. */
    private fun ring(bone: Int, a: FloatArray, b: FloatArray, r: Float, count: Int, out: MutableList<FloatArray>, w: MutableList<Int>) {
        for (k in 0 until count) {
            val t = 0.1f + 0.8f * (k % 10) / 9f; val ang = (k * 0.7f)
            out.add(floatArrayOf(a[0] + (b[0] - a[0]) * t + r * cos(ang), a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t + r * sin(ang)))
            w.add(bone)
        }
    }

    private fun model(withVerts: Boolean = true, rbs: List<PmxRigid> = emptyList(), joints: List<PmxJoint> = emptyList(), b: List<PmxBone> = bones()): PmxModel {
        val pts = ArrayList<FloatArray>(); val wb = ArrayList<Int>()
        if (withVerts) {
            ring(2, floatArrayOf(0.9f, 10f, 0f), floatArrayOf(0.9f, 5f, 0.2f), 1.1f, 60, pts, wb)
            ring(3, floatArrayOf(0.9f, 5f, 0.2f), floatArrayOf(0.9f, 1f, 0f), 0.7f, 60, pts, wb)
        }
        val nv = pts.size
        val pos = FloatArray(nv * 3); val bi = IntArray(nv * 4) { -1 }; val bw = FloatArray(nv * 4)
        for (v in 0 until nv) { for (k in 0..2) pos[v * 3 + k] = pts[v][k]; bi[v * 4] = wb[v]; bw[v * 4] = 1f }
        return PmxModel("t", 2f, pos, FloatArray(nv * 3), FloatArray(nv * 2), bi, bw, IntArray(nv) { it }, emptyList(), emptyList(), b, emptyList(), rigidBodies = rbs, joints = joints)
    }

    @Test fun generatesPelvisThighsAndCalvesWithMeasuredRadius() {
        val p = BodyColliders.generate(model())
        assertEquals(setOf("pelvis", "thigh_E", "thigh_D", "calf_E", "calf_D"), p.colliders.map { it.key }.toSet())
        val th = p.colliders.first { it.key == "thigh_E" }
        assertEquals(2, th.bone); assertTrue(th.measured)
        assertEquals(1.1f, th.radius, 0.05f)                       // mediana dos vértices do anel
        val len = sqrt(0.9f * 0 + 25f + 0.04f)
        assertEquals(len - 2 * th.radius, th.length, 0.05f)         // trecho reto + 2 pontas cobrem joelho↔quadril
        assertEquals(7.5f, th.center[1], 1e-3f)
        val calf = p.colliders.first { it.key == "calf_E" }
        assertEquals(3, calf.bone); assertEquals(0.7f, calf.radius, 0.05f)
        // coxa direita não tem vértices pesados: raio por proporção, marcado como não medido
        val thR = p.colliders.first { it.key == "thigh_D" }
        assertFalse(thR.measured); assertEquals(5.0f * 0.20f, thR.radius, 0.05f)
        assertEquals(1, p.colliders.first { it.key == "pelvis" }.bone)   // preso ao 下半身
        assertTrue(p.missing.isEmpty())
    }

    @Test fun ikAndDeformBonesAreNeverUsed() {
        // só ossos IK/D/saia para a perna esquerda
        val b = listOf(bone("センター", 0f, 10f, 0f, -1), bone("左足ＩＫ", 1f, 0f, 0f, 0), bone("左足D", 1f, 10f, 0f, 0), bone("左ひざD", 1f, 5f, 0f, 2), bone("スカート前", 0f, 8f, 0f, 0), bone("左足捩", 1f, 9f, 0f, 0))
        val p = BodyColliders.generate(model(false, b = b))
        assertTrue(p.colliders.isEmpty())
        assertTrue(p.missing.isNotEmpty())
    }

    @Test fun englishNamesWithSideSuffixAndPrefixWork() {
        val b = listOf(
            bone("a", 0f, 10.5f, 0f, -1, "pelvis"),
            bone("b", 1f, 10f, 0f, 0, "thigh_L"), bone("c", 1f, 5f, 0f, 1, "knee_L"), bone("d", 1f, 1f, 0f, 2, "ankle_L"),
            bone("e", -1f, 10f, 0f, 0, "Right Thigh"), bone("f", -1f, 5f, 0f, 4, "Right Knee"), bone("g", -1f, 1f, 0f, 5, "Right Ankle")
        )
        val p = BodyColliders.generate(model(false, b = b))
        assertEquals(setOf("pelvis", "thigh_E", "thigh_D", "calf_E", "calf_D"), p.colliders.map { it.key }.toSet())
        assertEquals(1, p.colliders.first { it.key == "thigh_E" }.bone)
        assertEquals(4, p.colliders.first { it.key == "thigh_D" }.bone)
        assertNull(BodyColliders.roleOf("hairs", "hair_L"))
        assertNull(BodyColliders.roleOf("x", "football"))   // "foot" só casa como palavra inteira
    }

    @Test fun elementsAlreadyCoveredByModelKinematicBodiesAreSkipped() {
        val rbs = listOf(rigid("coxaE", 2, 0, group = 3), rigid("quadril", 1, 0, group = 3), rigid("tornozelo", 4, 0, group = 3), rigid("saia", 10, 1, group = 5))
        val p = BodyColliders.generate(model(rbs = rbs))
        assertEquals(setOf("thigh_D", "calf_E", "calf_D"), p.colliders.map { it.key }.toSet())
        assertTrue(p.covered.containsAll(listOf("Coxa esq.", "Quadril")))
        assertEquals(3, p.group)          // herda o grupo de colisão dos corpos do corpo
    }

    @Test fun capsuleAxisAlignsWithBoneDirection() {
        fun check(dx: Float, dy: Float, dz: Float) {
            val r = BodyColliders.alignY(dx, dy, dz)
            val q = Euler.quat(Math.toDegrees(r[0].toDouble()).toFloat(), Math.toDegrees(r[1].toDouble()).toFloat(), Math.toDegrees(r[2].toDouble()).toFloat())
            // gira (0,1,0) por q
            val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
            val ax = 2 * (x * y - z * w); val ay = 1 - 2 * (x * x + z * z); val az = 2 * (y * z + x * w)
            val l = sqrt(dx * dx + dy * dy + dz * dz)
            assertEquals(1f, abs(ax * dx / l + ay * dy / l + az * dz / l), 1e-3f)   // paralelo (sentido irrelevante)
        }
        check(0f, -1f, 0f); check(1f, 0f, 0f); check(0f, 0f, 2f); check(0.3f, -5f, 0.4f); check(-1.8f, 0f, 0.1f); check(1f, 1f, 1f)
    }

    @Test fun rigidsAreKinematicCapsulesBoundToBones() {
        val p = BodyColliders.generate(model())
        val rs = p.rigids()
        assertEquals(p.colliders.size, rs.size)
        for ((i, r) in rs.withIndex()) {
            assertEquals(0, r.mode); assertEquals(2, r.shape); assertEquals(p.colliders[i].bone, r.bone)
            assertEquals(p.colliders[i].radius, r.size[0], 0f); assertEquals(p.colliders[i].length, r.size[1], 0f)
        }
    }

    @Test fun planIsCachedPerModelAndEmptyModelIsSafe() {
        val m = model()
        assertSame(BodyColliders.plan(m), BodyColliders.plan(m))
        val e = PmxModel("e", 2f, FloatArray(0), FloatArray(0), FloatArray(0), IntArray(0), FloatArray(0), IntArray(0), emptyList(), emptyList(), emptyList(), emptyList())
        assertTrue(BodyColliders.plan(e).colliders.isEmpty())
    }

    /** Corpo dinâmico (saia) começa dentro da coxa. Com colisores do corpo ele é empurrado para fora do raio; sem eles, fica. */
    private fun skirtDistanceFromThighAxis(bodyColliders: Boolean, scale: Map<String, Float> = emptyMap()): Float {
        val b = bones()
        // âncora cinemática no quadril + corpo dinâmico da saia (esfera r=0.3) em x=0.9, y=8, z=0.05 (dentro da coxa) ligado por junta frouxa
        val rbs = listOf(rigid("âncora", 1, 0, group = 7, size = floatArrayOf(0.2f, 0f, 0f), pos = floatArrayOf(0f, 10.5f, 0f)),
            rigid("saia", 10, 1, group = 1, size = floatArrayOf(0.3f, 0f, 0f), pos = floatArrayOf(0.9f, 8f, 0.05f)))
        val z3 = FloatArray(3)
        val big = floatArrayOf(50f, 50f, 50f); val nbig = floatArrayOf(-50f, -50f, -50f)
        val j = PmxJoint("j", 0, 1, floatArrayOf(0.9f, 8f, 0.05f), z3, nbig, big, nbig, big, z3, z3)
        val m = model(rbs = rbs, joints = listOf(j), b = b)
        val eng = PhysEngine.create(m)!!
        val nb = b.size
        val gq = FloatArray(nb * 4); for (i in 0 until nb) gq[i * 4 + 3] = 1f
        val gt = FloatArray(nb * 3); for (i in 0 until nb) { gt[i * 3] = b[i].x; gt[i * 3 + 1] = b[i].y; gt[i * 3 + 2] = b[i].z }
        val cfg = PhysConfig(enabled = true, gravity = 0f, ground = false, collisions = true, bodyColliders = bodyColliders, colliderScale = scale)
        for (f in 0 until 120) eng.step(1f / 30f, gq, gt, cfg)
        assertTrue(eng.driven[10])
        // posição do osso da saia = posição do corpo (offset zero no repouso)
        val x = eng.outT[10 * 3]; val y = eng.outT[10 * 3 + 1]; val z = eng.outT[10 * 3 + 2]
        // distância ao eixo da coxa (0.9,10,0)→(0.9,5,0.2)
        val ax = 0f; val ay = -5f; val az = 0.2f; val l2 = ax * ax + ay * ay + az * az
        val rx = x - 0.9f; val ry = y - 10f; val rz = z
        val t = ((rx * ax + ry * ay + rz * az) / l2).coerceIn(0f, 1f)
        val px = rx - ax * t; val py = ry - ay * t; val pz = rz - az * t
        return sqrt(px * px + py * py + pz * pz)
    }

    @Test fun engineUsesBodyCollidersOnlyWhenEnabled() {
        val off = skirtDistanceFromThighAxis(false)
        val on = skirtDistanceFromThighAxis(true)
        assertTrue("sem colisores a saia fica dentro da coxa ($off)", off < 0.5f)
        assertTrue("com colisores a saia sai do raio da coxa + sua esfera ($on)", on > 1.1f + 0.3f - 0.05f)
    }

    @Test fun physConfigCodecKeepsBodyCollidersAndOldProjectsDefaultOff() {
        val c = PhysConfig(enabled = true, bodyColliders = true)
        assertTrue(PhysIo.fromJson(PhysIo.toJson(c)).bodyColliders)
        assertFalse(PhysIo.fromJson("{\"on\":true,\"g\":1.0,\"k\":1.0,\"d\":1.0,\"w\":0.0,\"ground\":true,\"col\":true}").bodyColliders)
        assertNotEquals(c.hashCode(), c.copy(bodyColliders = false).hashCode())   // muda a assinatura do cache da física
    }

    @Test fun perColliderScaleChangesHowFarTheSkirtIsPushed() {
        val normal = skirtDistanceFromThighAxis(true)
        val big = skirtDistanceFromThighAxis(true, mapOf("thigh_E" to 1.5f))
        val small = skirtDistanceFromThighAxis(true, mapOf("thigh_E" to 0.5f))
        assertTrue("maior empurra mais ($big > $normal)", big > normal + 0.3f)
        assertTrue("menor empurra menos ($small < $normal)", small < normal - 0.3f)
        assertEquals(normal, skirtDistanceFromThighAxis(true, mapOf("calf_D" to 1.5f)), 0.05f)   // outro colisor não interfere
    }

    @Test fun colliderScaleSurvivesCodecAndIsClamped() {
        val c = PhysConfig(enabled = true, bodyColliders = true, colliderScale = mapOf("thigh_E" to 1.25f, "pelvis" to 0.8f))
        assertEquals(c.colliderScale, PhysIo.fromJson(PhysIo.toJson(c)).colliderScale)
        assertEquals(PhysConfig.SCALE_MAX, PhysIo.fromJson("{\"bs\":{\"x\":99}}").colliderScale["x"]!!, 0f)
        assertTrue(PhysIo.fromJson("{\"on\":true}").colliderScale.isEmpty())
        assertNotEquals(c.hashCode(), c.copy(colliderScale = emptyMap()).hashCode())
    }

    // v1.35.1 — a saia (osso secundário) não atravessa a coxa quando os colisores do corpo estão ligados
    private fun skirtTailDistFromThigh(bodyCol: Boolean): Float {
        val bs = bones().dropLast(1) + listOf(bone("スカート", 2.0f, 8f, 0f, 1), bone("スカート先", 1.2f, 6f, 0f, 10))
        val an = Animator(model(b = bs), 1f, RigConfig().also {
            it.secondary = listOf(Secondary("s", "saia", listOf("スカート"), intensity = 0f))
            it.phys = PhysConfig(enabled = false, collisions = true, bodyColliders = bodyCol)
        })
        for (f in 0..3) an.evaluatePose(f.toFloat())
        val out = FloatArray(bs.size * 3); an.boneGl(out)
        val x = out[11 * 3]; val z = -out[11 * 3 + 2]; val y = out[11 * 3 + 1]
        val axZ = 0.2f * (10f - y) / 5f
        return sqrt((x - 0.9f) * (x - 0.9f) + (z - axZ) * (z - axZ))
    }

    @Test fun skirtBoneIsPushedOutOfThighOnlyWhenBodyCollidersOn() {
        val off = skirtTailDistFromThigh(false); val on = skirtTailDistFromThigh(true)
        assertTrue("sem colisores a ponta fica dentro da coxa ($off)", off < 0.6f)
        assertTrue("com colisores sai da coxa ($on)", on > 1.0f)
    }
}
