package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.export.*

class OfficialParityV38Test {
    private fun solid(w: Int, h: Int, c: Int) = IntArray(w * h) { c }
    private fun lum(c: Int) = (((c ushr 16) and 255) + ((c ushr 8) and 255) + (c and 255)) / 3

    @Test fun bloomSpreadsBrightOnly() {
        val w = 21; val h = 21
        val img = solid(w, h, 0xFF101010.toInt())
        img[10 * w + 10] = 0xFFFFFFFF.toInt()
        val out = PostFxPro.bloom(w, h, img, BloomConfig(0.8f, 1f, 4, 2))
        assertTrue(lum(out[10 * w + 13]) > lum(img[10 * w + 13]))         // vizinho ganhou brilho
        assertEquals(lum(img[0]), lum(out[0]))                              // longe fica igual
        assertEquals(0xFF, (out[10 * w + 10] ushr 24) and 255)              // alpha preservado
        assertArrayEquals(img, PostFxPro.bloom(w, h, img, BloomConfig(0.8f, 0f)))
        val dark = solid(w, h, 0xFF303030.toInt())
        assertArrayEquals(dark, PostFxPro.bloom(w, h, dark, BloomConfig(0.8f, 1f)))   // nada acima do limiar
    }

    @Test fun dofBlursOutOfFocusOnly() {
        val w = 32; val h = 8
        val img = IntArray(w * h) { if ((it % w) % 2 == 0) 0xFFFFFFFF.toInt() else 0xFF000000.toInt() }
        val depth = FloatArray(w * h) { if (it % w < 16) 30f else 120f }   // esquerda em foco, direita longe
        val out = PostFxPro.depthOfField(w, h, img, depth, DofConfig(30f, 2f, 6))
        assertEquals(img[3], out[3])                                        // em foco: intacto
        val varBefore = (20..27).map { lum(img[it]) }.toSet().size
        val spread = (20..27).map { lum(out[it]) }.let { (it.max() - it.min()) }
        assertEquals(2, varBefore)
        assertTrue("desfocou o fundo: $spread", spread < 255 / 2)
        assertEquals(0f, PostFxPro.cocRadius(30f, DofConfig(30f, 2f, 6)), 0f)
        assertEquals(6f, PostFxPro.cocRadius(Float.NaN, DofConfig(30f, 2f, 6)), 0f)
        assertTrue(PostFxPro.cocRadius(60f, DofConfig(30f, 2f, 10)) > PostFxPro.cocRadius(40f, DofConfig(30f, 2f, 10)))
        assertArrayEquals(img, PostFxPro.depthOfField(w, h, img, depth, DofConfig(30f, 2f, 0)))
        try { PostFxPro.depthOfField(w, h, img, FloatArray(3), DofConfig()); fail() } catch (e: IllegalArgumentException) { }
    }

    @Test fun physicalCocGrowsAwayFromFocus() {
        val near = PostFxPro.physicalCoc(3f, 5f, 50f, 1.8f, 36f, 1920)
        val far = PostFxPro.physicalCoc(40f, 5f, 50f, 1.8f, 36f, 1920)
        val inFocus = PostFxPro.physicalCoc(5f, 5f, 50f, 1.8f, 36f, 1920)
        assertEquals(0f, inFocus, 1e-6f)
        assertTrue(near > 0f && far > 0f)
        assertEquals(0f, PostFxPro.physicalCoc(-1f, 5f, 50f, 1.8f, 36f, 1920), 0f)
    }

    @Test fun motionBlurAccumulation() {
        val w = 2; val h = 1
        val a = intArrayOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt()); val b = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt())
        val out = PostFxPro.accumulate(w, h, listOf(a, b))
        assertEquals(128, out[0] and 255); assertEquals(128, out[1] and 255)
        val w2 = PostFxPro.accumulate(w, h, listOf(a, b), floatArrayOf(3f, 1f))
        assertEquals(64, w2[0] and 255)
        val off = PostFxPro.shutterOffsets(5, 180f)
        assertEquals(5, off.size); assertEquals(-0.25f, off[0], 1e-6f); assertEquals(0.25f, off[4], 1e-6f); assertEquals(0f, off[2], 1e-6f)
        assertArrayEquals(floatArrayOf(0f), PostFxPro.shutterOffsets(1, 180f), 0f)
        try { PostFxPro.accumulate(w, h, emptyList()); fail() } catch (e: IllegalArgumentException) { }
    }

    @Test fun gradeNeutralIsIdentityAndWarmShifts() {
        val img = solid(4, 4, 0xFF808080.toInt())
        assertArrayEquals(img, PostFxPro.colorGrade(4, 4, img, GradeConfig()))
        val warm = PostFxPro.colorGrade(4, 4, img, GradeConfig(temperature = 1f))
        assertTrue(((warm[0] ushr 16) and 255) > (warm[0] and 255))
        val bright = PostFxPro.colorGrade(4, 4, img, GradeConfig(gain = floatArrayOf(1.5f, 1.5f, 1.5f)))
        assertTrue((bright[0] and 255) > 0x80)
        val lifted = PostFxPro.colorGrade(4, 4, solid(4, 4, 0xFF000000.toInt()), GradeConfig(lift = floatArrayOf(0.2f, 0.2f, 0.2f)))
        assertTrue((lifted[0] and 255) > 40)
    }

    @Test fun sharpenAndFxaa() {
        val w = 8; val h = 1
        val edge = IntArray(w) { if (it < 4) 0xFF404040.toInt() else 0xFFC0C0C0.toInt() }
        val s = PostFxPro.sharpen(w, h, edge, 1f)
        assertTrue((s[3] and 255) < 0x40 && (s[4] and 255) > 0xC0)
        assertArrayEquals(edge, PostFxPro.sharpen(w, h, edge, 0f))
        val w2 = 6; val h2 = 6
        val stair = IntArray(w2 * h2) { if ((it % w2) > (it / w2)) 0xFFFFFFFF.toInt() else 0xFF000000.toInt() }
        val f = PostFxPro.fxaa(w2, h2, stair)
        var changed = 0; for (i in stair.indices) if (stair[i] != f[i]) changed++
        assertTrue(changed > 0)
        val flat = solid(w2, h2, 0xFF123456.toInt())
        assertArrayEquals(flat, PostFxPro.fxaa(w2, h2, flat))
    }

    @Test fun bgPlacement() {
        val c = BgLayer.place(BgFit.CONTAIN, 100, 100, 200, 100)
        assertEquals(100, c.dw); assertEquals(50, c.dx)
        val v = BgLayer.place(BgFit.COVER, 100, 100, 200, 100)
        assertEquals(200, v.dw); assertEquals(200, v.dh); assertEquals(-50, v.dy)
        val s = BgLayer.place(BgFit.STRETCH, 10, 10, 200, 100)
        assertEquals(200, s.dw); assertEquals(100, s.dh)
        val z = BgLayer.place(BgFit.CENTER, 50, 50, 100, 100, zoom = 2f)
        assertEquals(100, z.dw); assertEquals(0, z.dx)
        assertEquals(0, BgLayer.place(BgFit.COVER, 0, 0, 10, 10).dx)
    }

    @Test fun bgVideoTiming() {
        assertEquals(15, BgLayer.videoFrame(30, 30f, 15f, 100, BgLoop.ONCE))
        assertEquals(99, BgLayer.videoFrame(3000, 30f, 30f, 100, BgLoop.ONCE))
        assertEquals(0, BgLayer.videoFrame(100, 30f, 30f, 100, BgLoop.LOOP))
        assertEquals(98, BgLayer.videoFrame(100, 30f, 30f, 100, BgLoop.PING_PONG))
        assertEquals(0, BgLayer.videoFrame(5, 30f, 30f, 100, BgLoop.ONCE, offsetFrames = 10))
        assertEquals(20, BgLayer.videoFrame(10, 30f, 30f, 100, BgLoop.ONCE, speed = 2f))
        assertEquals(0, BgLayer.videoFrame(5, 0f, 30f, 100, BgLoop.LOOP))
    }

    @Test fun bgCompositeAndRender() {
        val fg = intArrayOf(0x00000000, 0xFFFF0000.toInt(), 0x80FF0000.toInt())
        val bg = intArrayOf(0xFF0000FF.toInt(), 0xFF0000FF.toInt(), 0xFF0000FF.toInt())
        val o = BgLayer.compositeOver(3, 1, fg, bg)
        assertEquals(0xFF0000FF.toInt(), o[0]); assertEquals(0xFFFF0000.toInt(), o[1])
        assertEquals(0xFF, (o[2] ushr 24) and 255)
        assertTrue(((o[2] ushr 16) and 255) in 120..135)
        val half = BgLayer.compositeOver(3, 1, fg, bg, 0.5f)
        assertEquals(0x80, half[0] and 255)
        val src = intArrayOf(1, 2, 3, 4)
        val r = BgLayer.render(src, 2, 2, 4, 4, BgRect(0, 0, 4, 4), 0)
        assertEquals(1, r[0]); assertEquals(2, r[3]); assertEquals(3, r[12]); assertEquals(4, r[15])
        val off = BgLayer.render(src, 2, 2, 4, 4, BgRect(2, 2, 2, 2), 9)
        assertEquals(9, off[0]); assertEquals(1, off[10])
    }

    @Test fun presetsAndGuides() {
        assertEquals(1920, OutputPresets.byId("fhd")!!.width)
        assertNull(OutputPresets.byId("x"))
        val (w, h) = OutputPresets.fitToBudget(OutputPresets.byId("uhd")!!, 2_000_000L)
        assertTrue(w.toLong() * h <= 2_000_000L && w % 2 == 0 && h % 2 == 0)
        assertEquals(1920 to 1080, OutputPresets.fitToBudget(OutputPresets.byId("fhd")!!, 10_000_000L))
        assertEquals(16, FrameGuides.thirds().size)
        val lb = FrameGuides.letterbox(2.39f, 16f / 9f)
        assertEquals(1f, lb[2], 0f); assertTrue(lb[3] < 1f && lb[1] > 0f)
        val pb = FrameGuides.letterbox(1f, 16f / 9f)
        assertTrue(pb[2] < 1f)
        assertEquals(0.05f, FrameGuides.safe(0.9f)[0], 1e-6f)
    }
}
