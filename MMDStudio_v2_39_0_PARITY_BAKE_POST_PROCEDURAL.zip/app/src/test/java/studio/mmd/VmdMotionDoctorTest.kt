package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class VmdMotionDoctorTest {
    @Test fun sortsKeysRemovesDuplicatesAndNormalizesQuaternion() {
        val values = floatArrayOf(
            0f,0f,0f, 0f,0f,0f,2f,
            1f,0f,0f, 0f,0f,0f,1f,
            2f,0f,0f, 0f,0f,0f,1f,
            3f,0f,0f, 0f,0f,0f,1f
        )
        val track = VmdTrack(intArrayOf(5,2,2,-1), values, ByteArray(64) { 120 })
        val motion = VmdMotion("test", mapOf("bone" to track), mapOf("morph" to VmdMorphTrack(intArrayOf(2,0,0), floatArrayOf(Float.NaN,.5f,.75f))), 5)
        val before = VmdMotionDoctor.inspect(motion)
        assertTrue(before.unorderedFrames > 0)
        assertTrue(before.duplicateFrames > 0)
        assertTrue(before.negativeFrames > 0)
        assertTrue(before.nonUnitQuaternions > 0)
        val fixed = VmdMotionDoctor.repair(motion)
        val out = fixed.motion.bones.getValue("bone")
        assertArrayEquals(intArrayOf(0,2,5), out.frames)
        assertEquals(48, out.ip.size)
        assertEquals(1f, out.v[6], 1e-6f)
        assertTrue(fixed.motion.morphs.getValue("morph").w.all { it.isFinite() })
        assertTrue(VmdMotionDoctor.inspect(fixed.motion).healthy)
    }

    @Test fun malformedInterpolationIsCompletedWithLinearDefaults() {
        val track = VmdTrack(intArrayOf(0,10), floatArrayOf(0f,0f,0f,0f,0f,0f,1f, 1f,0f,0f,0f,0f,0f,1f), byteArrayOf(1,2,3))
        val result = VmdMotionDoctor.repair(VmdMotion("x", mapOf("b" to track), emptyMap(), 10))
        assertEquals(32, result.motion.bones.getValue("b").ip.size)
        assertEquals(20, result.motion.bones.getValue("b").ip[4].toInt() and 0xff)
        assertEquals(107, result.motion.bones.getValue("b").ip[6].toInt() and 0xff)
    }

    @Test fun leavesMotionSourceAndExtraMetadataIntact() {
        val original = VmdMotion("x", emptyMap(), emptyMap(), 0, listOf("existing"), VmdExtras())
        val result = VmdMotionDoctor.repair(original).motion
        assertEquals(listOf("existing"), result.warnings)
        assertTrue(original.bones.isEmpty())
    }
}
