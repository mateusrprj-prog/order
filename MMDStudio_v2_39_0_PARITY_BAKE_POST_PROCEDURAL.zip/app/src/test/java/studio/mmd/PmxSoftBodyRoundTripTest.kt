package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class PmxSoftBodyRoundTripTest {
    @Test fun parsesAndWritesTypedSoftBodyFields() {
        val material = PmxMaterial("cloth","cloth",floatArrayOf(1f,1f,1f,1f),floatArrayOf(0f,0f,0f),0f,floatArrayOf(0f,0f,0f),0,floatArrayOf(0f,0f,0f,1f),0f,-1,-1,0,true,0,3)
        val rigid = PmxRigid("anchor","anchor",0,0,0,0f,0f,0f,0,size=floatArrayOf(.1f,.1f,.1f),pos=FloatArray(3),rot=FloatArray(3))
        val sb = PmxSoftBody("skirt","skirt",0,0,1,0xFFFE,3,2,4,1.5f,0.02f,1,
            FloatArray(12) { it / 20f }, FloatArray(6) { it / 10f }, intArrayOf(4,5,6,7), intArrayOf(10,11,12),
            listOf(PmxSoftBodyAnchor(0,1,true)), intArrayOf(0,2))
        val model = PmxModel("soft",2.1f,floatArrayOf(0f,0f,0f,1f,0f,0f,0f,1f,0f),floatArrayOf(0f,0f,1f,0f,0f,1f,0f,0f,1f),FloatArray(6),
            intArrayOf(0,-1,-1,-1,0,-1,-1,-1,0,-1,-1,-1),floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f,0f,0f,0f),intArrayOf(0,1,2),emptyList(),listOf(material),
            listOf(PmxBone("root","root",0f,0f,0f,-1,0,0,-1,-1,0f,null)),emptyList(),listOf(rigid),emptyList(),softBodyCount=1,softBodies=listOf(sb))
        val bytes = PmxWriter.write(model).bytes
        val parsed = PmxParser.parse(bytes)
        assertEquals(1, parsed.softBodies.size)
        val read = parsed.softBodies.single()
        assertEquals("skirt", read.name)
        assertEquals(1.5f, read.totalMass, 0f)
        assertEquals(0, read.anchors.single().rigidBody)
        assertEquals(1, read.anchors.size)
        assertArrayEquals(intArrayOf(0,2), read.pins)
        assertArrayEquals(sb.iterations, read.iterations)
        val second = PmxParser.parse(PmxWriter.write(parsed).bytes)
        assertEquals(read.name, second.softBodies.single().name)
        assertArrayEquals(read.config, second.softBodies.single().config, 0f)

        // Um bloco truncado não pode sumir silenciosamente: manter a contagem e o payload parcial raw.
        val truncated = bytes.copyOf(bytes.size - 3)
        val damaged = PmxParser.parse(truncated)
        assertTrue(damaged.softBodies.isEmpty())
        assertEquals(1, damaged.softBodyCount)
        val raw = damaged.softBodyRaw
        assertTrue(raw != null && raw.isNotEmpty())
        val rewritten = PmxWriter.write(damaged).bytes
        assertTrue(raw!!.contentEquals(rewritten.copyOfRange(rewritten.size - raw.size, rewritten.size)))
    }
}
