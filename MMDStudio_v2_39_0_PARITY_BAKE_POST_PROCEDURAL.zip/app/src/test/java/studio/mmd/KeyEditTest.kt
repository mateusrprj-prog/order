package studio.mmd

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import studio.mmd.edit.Editor
import studio.mmd.edit.KeyRef
import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxModel

/** v1.15.0 (Release 5): mover/copiar/apagar/retiming de keys por trecho. v1.16.0: keys individuais (dope sheet). Nunca executados (sem Kotlin/Gradle no ambiente de escrita). */
class KeyEditTest {
    private fun bone(n: String) = PmxBone(n, n, 0f, 0f, 0f, -1, 0, 0x001A, -1, -1, 0f, null)
    private fun editor(): Editor {
        val m = PmxModel("t", 2f, FloatArray(3), FloatArray(3), FloatArray(2), IntArray(4) { if (it == 0) 0 else -1 }, FloatArray(4) { if (it == 0) 1f else 0f },
            IntArray(0), emptyList(), emptyList(), listOf(bone("a"), bone("b")), emptyList())
        return Editor(m)
    }
    private fun keys(e: Editor, n: String) = e.keyFramesOf(n).toList()

    @Test fun moveShiftsOnlyTheRangeAndUndoRestores() {
        val e = editor()
        for (f in intArrayOf(0, 5, 10, 20)) e.zeroBones(listOf("a"), f)
        assertEquals(2, e.moveKeys(listOf("a"), emptyList(), 5, 10, 3))
        assertEquals(listOf(0, 8, 13, 20), keys(e, "a"))
        assertTrue(e.undo())
        assertEquals(listOf(0, 5, 10, 20), keys(e, "a"))
    }

    @Test fun moveBeforeZeroIsRefusedAndChangesNothing() {
        val e = editor(); e.zeroBones(listOf("a"), 2)
        assertEquals(-1, e.moveKeys(listOf("a"), emptyList(), 0, 10, -5))
        assertEquals(listOf(2), keys(e, "a"))
    }

    @Test fun copyPasteKeepsRelativeSpacingAndDeleteRemoves() {
        val e = editor()
        e.zeroBones(listOf("a"), 10); e.zeroBones(listOf("a"), 14)
        assertEquals(2, e.copyKeys(listOf("a"), emptyList(), 10, 14))
        assertTrue(e.hasKeyClip)
        assertEquals(2, e.pasteKeys(30))
        assertEquals(listOf(10, 14, 30, 34), keys(e, "a"))
        assertEquals(2, e.deleteRange(listOf("a"), emptyList(), 10, 14))
        assertEquals(listOf(30, 34), keys(e, "a"))
    }

    @Test fun retimeScalesRangeAndRipplesLaterKeys() {
        val e = editor()
        for (f in intArrayOf(0, 5, 10, 20)) e.zeroBones(listOf("a"), f)
        e.zeroBones(listOf("b"), 5)
        assertEquals(4, e.retimeKeys(listOf("a"), emptyList(), 0, 10, 2f))
        assertEquals(listOf(0, 10, 20, 30), keys(e, "a"))   // 20 deslocou +10 (ripple)
        assertEquals(listOf(5), keys(e, "b"))                // outra trilha intocada
        assertEquals(0, e.retimeKeys(listOf("a"), emptyList(), 0, 10, 50f))   // fator fora de 0,1–10
    }

    @Test fun countOnlyCountsSelectedTracks() {
        val e = editor(); e.zeroBones(listOf("a"), 3); e.zeroBones(listOf("b"), 3)
        assertEquals(1, e.countKeys(listOf("a"), emptyList(), 0, 5))
        assertEquals(2, e.countKeys(listOf("a", "b"), emptyList(), 0, 5))
        assertFalse(e.hasKeyClip)
    }

    // ---------------------------------------------------------------- v1.16.0: keys individuais (dope sheet)

    private fun b(n: String, f: Int) = KeyRef(false, n, f)
    private fun m(n: String, f: Int) = KeyRef(true, n, f)

    @Test fun moveRefsMovesOnlyThoseKeysAcrossBonesAndMorphsAndUndoRestores() {
        val e = editor()
        for (f in intArrayOf(0, 5, 10)) e.zeroBones(listOf("a"), f)
        e.zeroBones(listOf("b"), 5)
        e.zeroMorph("mx", 5)
        assertEquals(3, e.moveKeyRefs(listOf(b("a", 5), b("b", 5), m("mx", 5)), 4))
        assertEquals(listOf(0, 9, 10), keys(e, "a"))          // só a key 5 de "a" andou
        assertEquals(listOf(9), keys(e, "b"))
        assertEquals(listOf(9), e.morphKeyFramesOf("mx").toList())
        assertTrue(e.undo())                                   // UM passo desfaz tudo
        assertEquals(listOf(0, 5, 10), keys(e, "a"))
        assertEquals(listOf(5), keys(e, "b"))
        assertEquals(listOf(5), e.morphKeyFramesOf("mx").toList())
    }

    @Test fun moveRefsOntoUnmovedKeyReplacesItAndMovingTogetherKeepsBoth() {
        val e = editor()
        for (f in intArrayOf(0, 5, 10)) e.zeroBones(listOf("a"), f)
        assertEquals(1, e.moveKeyRefs(listOf(b("a", 5)), 5))   // cai em cima da key 10 (não movida) -> substitui
        assertEquals(listOf(0, 10), keys(e, "a"))
        val e2 = editor()
        for (f in intArrayOf(0, 5, 10)) e2.zeroBones(listOf("a"), f)
        assertEquals(2, e2.moveKeyRefs(listOf(b("a", 5), b("a", 10)), 5))   // 5->10 e 10->15: nenhuma se perde
        assertEquals(listOf(0, 10, 15), keys(e2, "a"))
    }

    @Test fun moveRefsBeforeZeroIsRefusedAndIgnoresMissingKeys() {
        val e = editor(); e.zeroBones(listOf("a"), 2)
        assertEquals(-1, e.moveKeyRefs(listOf(b("a", 2)), -3))
        assertEquals(listOf(2), keys(e, "a"))
        assertEquals(0, e.moveKeyRefs(listOf(b("a", 7), b("zz", 1)), 3))   // keys inexistentes: nada acontece
        assertEquals(listOf(2), keys(e, "a"))
        assertFalse(e.hasKeyRef(b("a", 7)))
        assertTrue(e.hasKeyRef(b("a", 2)))
    }

    @Test fun deleteRefsRemovesOnlyThoseAndUndoRestores() {
        val e = editor()
        for (f in intArrayOf(1, 2, 3)) e.zeroBones(listOf("a"), f)
        e.zeroMorph("mx", 2)
        assertEquals(2, e.deleteKeyRefs(listOf(b("a", 2), m("mx", 2), b("a", 99))))
        assertEquals(listOf(1, 3), keys(e, "a"))
        assertEquals(0, e.morphKeyFramesOf("mx").size)
        assertTrue(e.undo())
        assertEquals(listOf(1, 2, 3), keys(e, "a"))
        assertEquals(listOf(2), e.morphKeyFramesOf("mx").toList())
    }

    @Test fun copyRefsKeepsRelativeSpacingAndPastesAtFrame() {
        val e = editor()
        for (f in intArrayOf(10, 13, 20)) e.zeroBones(listOf("a"), f)
        e.zeroMorph("mx", 13)
        assertEquals(3, e.copyKeyRefs(listOf(b("a", 10), b("a", 13), m("mx", 13))))
        assertTrue(e.hasKeyClip)
        assertEquals(3, e.pasteKeys(40))
        assertEquals(listOf(10, 13, 20, 40, 43), keys(e, "a"))
        assertEquals(listOf(13, 43), e.morphKeyFramesOf("mx").toList())
        assertEquals(0, e.copyKeyRefs(listOf(b("a", 99))))      // nada existe -> não copia
    }

    // v1.24.0: aplicar outro clip substitui as keys MAS é um passo de desfazer (a nota de prioridades proíbe destruir keys).
    @Test fun replaceUndoableSwapsKeysAndUndoRestoresThem() {
        val e = editor()
        for (f in intArrayOf(0, 5)) e.zeroBones(listOf("a"), f)
        val ip = ByteArray(16) { 20 }
        val tr = studio.mmd.mmd.VmdTrack(intArrayOf(0, 10, 20), FloatArray(21) { if (it % 7 == 6) 1f else 0f }, ByteArray(48) { 20 })
        val mo = studio.mmd.mmd.VmdMotion("c", mapOf("b" to tr, "fantasma" to tr), emptyMap(), 20)
        e.replaceUndoable(mo)
        assertEquals(emptyList<Int>(), keys(e, "a"))              // keys antigas foram substituídas
        assertEquals(listOf(0, 10, 20), keys(e, "b"))             // clip novo entrou
        assertEquals(3, e.lastSkippedBoneKeys)                    // "fantasma" não existe no modelo
        assertTrue(e.undo())
        assertEquals(listOf(0, 5), keys(e, "a"))                  // voltou
        assertEquals(emptyList<Int>(), keys(e, "b"))
        assertTrue(e.redo())
        assertEquals(listOf(0, 10, 20), keys(e, "b"))
    }
}
