package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class PmxToonBindingTest {
    private fun material(shared: Boolean, index: Int) = PmxMaterial(
        "toon", "toon", floatArrayOf(1f,1f,1f,1f), floatArrayOf(0f,0f,0f), 0f,
        floatArrayOf(0f,0f,0f), 0, floatArrayOf(0f,0f,0f,1f), 0f,
        -1, -1, 0, shared, index, 3
    )

    @Test fun sharedToonUsesInternalIndex() {
        val binding = PmxToonBindingResolver.resolve(material(true, 7), 4)
        assertEquals(PmxToonSource.SHARED, binding.source)
        assertEquals(7, binding.index)
        assertTrue(binding.enabled)
    }

    @Test fun customToonUsesTextureIndex() {
        val binding = PmxToonBindingResolver.resolve(material(false, 2), 3)
        assertEquals(PmxToonSource.TEXTURE, binding.source)
        assertEquals(2, binding.index)
    }

    @Test fun missingAndInvalidToonAreDistinguished() {
        assertEquals(PmxToonSource.NONE, PmxToonBindingResolver.resolve(material(false, -1), 0).source)
        assertEquals(PmxToonSource.INVALID, PmxToonBindingResolver.resolve(material(false, 4), 2).source)
        assertEquals(PmxToonSource.INVALID, PmxToonBindingResolver.resolve(material(true, 10), 20).source)
    }
}
