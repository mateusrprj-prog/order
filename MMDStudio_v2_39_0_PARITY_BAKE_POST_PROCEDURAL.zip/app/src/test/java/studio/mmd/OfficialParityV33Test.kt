package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class OfficialParityV33Test {
    private fun cam(frames: IntArray, dist: FloatArray, y: FloatArray): VmdCamera {
        val n = frames.size
        val ip = ByteArray(n * 24)
        for (i in 0 until n) for (c in 0 until 6) { val o = i * 24 + c * 4; ip[o] = 20; ip[o + 1] = 107; ip[o + 2] = 20; ip[o + 3] = 107 }
        val pos = FloatArray(n * 3) { if (it % 3 == 1) y[it / 3] else 0f }
        return VmdCamera(frames, dist, pos, FloatArray(n * 3), FloatArray(n) { 45f }, ip)
    }

    @Test fun cameraReduceRemovesLinearMiddleKey() {
        val c = cam(intArrayOf(0, 10, 20), floatArrayOf(30f, 25f, 20f), floatArrayOf(10f, 10f, 10f))
        val r = CameraRigActions.reduce(c)
        assertEquals(1, r.second)
        assertArrayEquals(intArrayOf(0, 20), r.first!!.frames)
    }

    @Test fun cameraReduceKeepsRealCorners() {
        val c = cam(intArrayOf(0, 10, 20), floatArrayOf(30f, 30f, 10f), floatArrayOf(10f, 10f, 10f))
        assertEquals(0, CameraRigActions.reduce(c).second)
        assertEquals(0, CameraRigActions.reduce(null).second)
    }

    @Test fun cameraInsertAndDeleteAt() {
        val c = cam(intArrayOf(0, 10, 20), floatArrayOf(30f, 25f, 20f), floatArrayOf(10f, 10f, 10f))
        assertArrayEquals(intArrayOf(0, 40, 50), CameraRigActions.insertAt(c, 5, 30)!!.frames)
        assertArrayEquals(intArrayOf(0, 10), CameraRigActions.deleteAt(c, 10, 10)!!.frames)
        assertNull(CameraRigActions.insertAt(null, 0, 5))
    }
}
