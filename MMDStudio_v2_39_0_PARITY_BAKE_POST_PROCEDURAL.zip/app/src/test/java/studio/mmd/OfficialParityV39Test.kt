package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import studio.mmd.render.*

class OfficialParityV39Test {
    @Test fun autoBlinkDeterministicAndBounded() {
        val a = ProceduralMotion.autoBlink(0, 900, seed = 4)
        val b = ProceduralMotion.autoBlink(0, 900, seed = 4)
        assertArrayEquals(a.frames, b.frames)
        assertFalse(ProceduralMotion.autoBlink(0, 900, seed = 5).frames.contentEquals(a.frames))
        assertTrue(a.frames.size > 8)
        assertTrue(a.w.all { it in 0f..1f })
        assertTrue(a.frames.all { it in 0..900 })
        for (i in 1 until a.frames.size) assertTrue(a.frames[i] > a.frames[i - 1])
        assertEquals(0f, a.w.first(), 0f); assertEquals(0f, a.w.last(), 0f)
        assertEquals(0, ProceduralMotion.autoBlink(10, 5).frames.size)
    }

    @Test fun breathingAndSwayAndEyes() {
        val br = ProceduralMotion.breathing(0, 120, amplitudeDeg = 2f, stepFrames = 10)
        assertEquals(13, br.frames.size)
        for (i in 0 until br.frames.size) {
            val q = br.v.copyOfRange(i * 7 + 3, i * 7 + 7)
            assertEquals(1f, q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3], 1e-4f)
        }
        val sw = ProceduralMotion.idleSway(0, 150)
        assertArrayEquals(sw.v.copyOfRange(3, 7), sw.v.copyOfRange(sw.v.size - 4, sw.v.size), 1e-5f)
        val eye = ProceduralMotion.eyeSaccades(0, 300)
        assertEquals(0, eye.frames.first()); assertEquals(300, eye.frames.last())
        for (i in 1 until eye.frames.size) assertTrue(eye.frames[i] > eye.frames[i - 1])
        val mn = ProceduralMotion.morphNoise(0, 100, 0.5f, 0.2f)
        assertTrue(mn.w.all { it in 0.3f..0.7f })
    }

    @Test fun stats() {
        fun t(f: IntArray) = VmdTrack(f, FloatArray(f.size * 7) { if (it % 7 == 0) it.toFloat() * 10 else if (it % 7 == 6) 1f else 0f }, ByteArray(f.size * 16))
        val m = VmdMotion("m", mapOf("a" to t(intArrayOf(0, 10, 20)), "b" to t(intArrayOf(0, 20))), mapOf("あ" to VmdMorphTrack(intArrayOf(5), floatArrayOf(1f))), 20)
        val s = MotionStats.summarize(m)
        assertEquals(2, s.boneTracks); assertEquals(1, s.morphTracks); assertEquals(5, s.boneKeys); assertEquals(20, s.lastFrame)
        assertEquals("a", s.busiest[0].name); assertEquals(21 - 4, s.emptyFrames)
        assertEquals("01:02:05", MotionStats.timecode(30 * 62 + 5, 30))
        assertEquals(30 * 62 + 5, MotionStats.parseTimecode("01:02:05", 30))
        assertEquals(35, MotionStats.parseTimecode("1:05", 30)); assertEquals(7, MotionStats.parseTimecode("7", 30))
        assertNull(MotionStats.parseTimecode("a:b", 30)); assertNull(MotionStats.parseTimecode("-1", 30))
        assertEquals("b", MotionStats.fastest(m, 1)[0].first.let { if (it == "a" || it == "b") "b" else it })
    }

    @Test fun physicsPlan() {
        assertEquals(PhysicsReplay.Action.CONTINUE, PhysicsReplay.plan(10, 11, true).action)
        assertEquals(PhysicsReplay.Action.CONTINUE, PhysicsReplay.plan(10, 10, false).action)
        val jump = PhysicsReplay.plan(10, 200, false)
        assertEquals(PhysicsReplay.Action.RESET_AND_WARM, jump.action); assertEquals(180, jump.warmStartFrame); assertEquals(20, jump.warmFrames)
        assertEquals(PhysicsReplay.Action.RESET_AND_WARM, PhysicsReplay.plan(50, 40, true).action)
        assertEquals(PhysicsReplay.Action.RESET_ONLY, PhysicsReplay.plan(null, 0, false).action)
        assertEquals(5, PhysicsReplay.plan(null, 5, false).warmFrames)
        assertEquals(80 until 100, PhysicsReplay.exportWarmup(100, 20))
        assertTrue(PhysicsReplay.isJump(0, 10))
    }

    @Test fun groundShadow() {
        val m = GroundShadow.planarMatrix(floatArrayOf(0f, -1f, 0f))!!
        val p = GroundShadow.project(m, 3f, 10f, 4f)
        assertEquals(3f, p[0], 1e-4f); assertEquals(0f, p[1], 1e-4f); assertEquals(4f, p[2], 1e-4f)
        val oblique = GroundShadow.planarMatrix(floatArrayOf(1f, -1f, 0f))!!
        val q = GroundShadow.project(oblique, 0f, 10f, 0f)
        assertEquals(10f, q[0], 1e-3f); assertEquals(0f, q[1], 1e-3f)
        assertNull(GroundShadow.planarMatrix(floatArrayOf(1f, 0f, 0f)))
        assertNull(GroundShadow.planarMatrix(floatArrayOf(Float.NaN, -1f, 0f)))
        val lifted = GroundShadow.planarMatrix(floatArrayOf(0f, -1f, 0f), GroundShadow.liftedPlane(1f, 0f))!!
        assertEquals(1f, GroundShadow.project(lifted, 0f, 5f, 0f)[1], 1e-4f)
        assertTrue(GroundShadow.opacityFor(floatArrayOf(0f, -1f, 0f)) > GroundShadow.opacityFor(floatArrayOf(1f, -0.1f, 0f)))
        assertEquals(0f, GroundShadow.opacityFor(floatArrayOf(0f, 0f, 0f)), 0f)
    }

    @Test fun edgeThickness() {
        val near = EdgeOutline.thicknessPx(1f, 10f, 1080, 45f)
        val far = EdgeOutline.thicknessPx(1f, 80f, 1080, 45f)
        assertTrue(near > far && far >= 0f)
        assertEquals(0f, EdgeOutline.thicknessPx(1f, -1f, 1080, 45f), 0f)
        assertTrue(EdgeOutline.thicknessPx(1f, 0.01f, 1080, 45f) <= 12f)
    }
}
