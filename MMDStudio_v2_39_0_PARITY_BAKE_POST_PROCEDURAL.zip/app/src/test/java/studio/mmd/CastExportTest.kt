package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.scene.CastExport
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class CastExportTest {
    private fun read(b: ByteArray): Map<String, ByteArray> {
        val m = LinkedHashMap<String, ByteArray>(); val z = ZipInputStream(ByteArrayInputStream(b))
        while (true) { val e = z.nextEntry ?: break; m[e.name] = z.readBytes() }
        return m
    }
    @Test fun repeatedNamesGetSuffix() { assertEquals(listOf("A", "A_2", "a_3"), CastExport.uniqueNames(listOf("A", "A", "a"))) }
    @Test fun badCharsReplaced() { assertEquals(listOf("a_b_c", "personagem"), CastExport.uniqueNames(listOf("a/b:c", "  "))) }
    @Test fun zipHoldsEachVmd() {
        val m = read(CastExport.zip(listOf("Miku" to byteArrayOf(1, 2), "Miku" to byteArrayOf(3))))
        assertEquals(listOf("Miku.vmd", "Miku_2.vmd"), m.keys.toList())
        assertArrayEquals(byteArrayOf(3), m["Miku_2.vmd"])
    }
}
