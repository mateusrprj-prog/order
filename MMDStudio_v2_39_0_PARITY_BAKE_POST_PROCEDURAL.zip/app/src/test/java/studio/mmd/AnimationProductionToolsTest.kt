package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import studio.mmd.edit.Editor
import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxModel

/** Cobertura das ferramentas de repetição de trecho e suavização por trilha. */
class AnimationProductionToolsTest {
    private fun bone(n: String) = PmxBone(n, n, 0f, 0f, 0f, -1, 0, 0x001A, -1, -1, 0f, null)
    private fun editor(): Editor {
        val model = PmxModel(
            "Ferramentas", 2f, FloatArray(3), FloatArray(3), FloatArray(2),
            IntArray(4) { if (it == 0) 0 else -1 }, FloatArray(4) { if (it == 0) 1f else 0f },
            IntArray(0), emptyList(), emptyList(), listOf(bone("a"), bone("b")), emptyList()
        )
        return Editor(model)
    }

    @Test fun repeatRangeCopiesBoneAndMorphTracksAndRipplesFollowingKeysAsOneUndo() {
        val e = editor()
        e.zeroBones(listOf("a"), 0)
        e.zeroBones(listOf("a"), 4)
        e.zeroBones(listOf("a"), 8)
        e.zeroBones(listOf("b"), 3)
        e.liveMorph("smile", 2, 0.25f)
        e.liveMorph("smile", 8, 0.75f)
        e.finish()

        assertEquals(6, e.repeatRange(listOf("a"), listOf("smile"), 0, 4, 2))
        assertEquals(listOf(0, 4, 5, 9, 10, 14, 18), e.keyFramesOf("a").toList())
        assertEquals(listOf(2, 7, 12, 18), e.morphKeyFramesOf("smile").toList())
        assertEquals(listOf(3), e.keyFramesOf("b").toList())

        assertTrue(e.undo())
        assertEquals(listOf(0, 4, 8), e.keyFramesOf("a").toList())
        assertEquals(listOf(2, 8), e.morphKeyFramesOf("smile").toList())
        assertEquals(listOf(3), e.keyFramesOf("b").toList())
    }

    @Test fun repeatRangeRejectsInvalidRangesAndEmptyTracksWithoutChangingData() {
        val e = editor()
        e.zeroBones(listOf("a"), 3)
        assertEquals(0, e.repeatRange(listOf("a"), emptyList(), -1, 10, 2))
        assertEquals(0, e.repeatRange(listOf("missing"), emptyList(), 0, 10, 1))
        assertEquals(0, e.repeatRange(listOf("a"), emptyList(), 0, 10, 0))
        assertEquals(listOf(3), e.keyFramesOf("a").toList())
    }

    @Test fun rippleDeleteRemovesRangeAndClosesGapOnlyOnAffectedTracksWithUndo() {
        val e = editor()
        e.zeroBones(listOf("a"), 0)
        e.zeroBones(listOf("a"), 4)
        e.zeroBones(listOf("a"), 8)
        e.zeroBones(listOf("b"), 3)
        e.zeroBones(listOf("b"), 7)
        e.liveMorph("smile", 2, 0.2f)
        e.liveMorph("smile", 5, 0.5f)
        e.liveMorph("smile", 10, 1f)
        e.finish()

        assertEquals(4, e.rippleDeleteRange(listOf("a"), listOf("smile"), 3, 6))
        assertEquals(listOf(0, 4), e.keyFramesOf("a").toList())
        assertEquals(listOf(2, 6), e.morphKeyFramesOf("smile").toList())
        assertEquals(listOf(3, 7), e.keyFramesOf("b").toList())

        assertTrue(e.undo())
        assertEquals(listOf(0, 4, 8), e.keyFramesOf("a").toList())
        assertEquals(listOf(2, 5, 10), e.morphKeyFramesOf("smile").toList())
        assertEquals(listOf(3, 7), e.keyFramesOf("b").toList())
    }

    @Test fun rippleDeleteDoesNothingWhenNoSelectedTrackHasKeysInRange() {
        val e = editor()
        e.zeroBones(listOf("a"), 0)
        e.zeroBones(listOf("a"), 10)
        assertEquals(0, e.rippleDeleteRange(listOf("a"), emptyList(), 3, 6))
        assertEquals(listOf(0, 10), e.keyFramesOf("a").toList())
    }

    @Test fun reverseRangeReversesValuesAndInternalBezierCurvesAndCanUndo() {
        val e = editor()
        e.liveBone("a", 0, null, floatArrayOf(0f, 0f, 0f))
        e.liveBone("a", 5, null, floatArrayOf(5f, 0f, 0f))
        e.liveBone("a", 10, null, floatArrayOf(10f, 0f, 0f))
        e.finish()
        val originalCurve = intArrayOf(18, 27, 94, 111)
        val nextCurve = intArrayOf(31, 42, 103, 119)
        e.setCurve("a", 5, -1, originalCurve)
        e.setCurve("a", 10, -1, nextCurve)

        assertEquals(3, e.reverseRange(listOf("a"), emptyList(), 0, 10))
        val pose = FloatArray(7)
        e.sampleBone("a", 0f, pose); assertEquals(10f, pose[0], 0.0001f)
        e.sampleBone("a", 5f, pose); assertEquals(5f, pose[0], 0.0001f)
        e.sampleBone("a", 10f, pose); assertEquals(0f, pose[0], 0.0001f)
        val reversed = e.curveOf("a", 5)!!
        assertEquals(127 - nextCurve[2], reversed[0].toInt() and 0xFF)
        assertEquals(127 - nextCurve[3], reversed[4].toInt() and 0xFF)
        assertEquals(127 - nextCurve[0], reversed[8].toInt() and 0xFF)
        assertEquals(127 - nextCurve[1], reversed[12].toInt() and 0xFF)

        assertTrue(e.undo())
        e.sampleBone("a", 0f, pose); assertEquals(0f, pose[0], 0.0001f)
        e.sampleBone("a", 10f, pose); assertEquals(10f, pose[0], 0.0001f)
    }

    @Test fun smoothRangeSoftensInteriorBoneAndMorphKeysKeepsEndpointsAndUndoes() {
        val e = editor()
        e.liveBone("a", 0, null, floatArrayOf(0f, 0f, 0f))
        e.liveBone("a", 10, null, floatArrayOf(10f, 0f, 0f))
        e.liveBone("a", 20, null, floatArrayOf(0f, 0f, 0f))
        e.liveBone("b", 10, null, floatArrayOf(7f, 0f, 0f))
        e.liveMorph("smile", 0, 0f)
        e.liveMorph("smile", 10, 1f)
        e.liveMorph("smile", 20, 0f)
        e.finish()

        assertEquals(2, e.smoothRange(listOf("a", "b"), listOf("smile"), 0, 20, 1f, 1))
        val pose = FloatArray(7)
        e.sampleBone("a", 10f, pose)
        assertEquals(0f, pose[0], 0.0001f)
        e.sampleBone("a", 0f, pose)
        assertEquals(0f, pose[0], 0.0001f)
        e.sampleBone("a", 20f, pose)
        assertEquals(0f, pose[0], 0.0001f)
        e.sampleBone("b", 10f, pose)
        assertEquals(7f, pose[0], 0.0001f)
        assertEquals(0f, e.sampleMorph("smile", 10f), 0.0001f)

        assertTrue(e.undo())
        e.sampleBone("a", 10f, pose)
        assertEquals(10f, pose[0], 0.0001f)
        assertEquals(1f, e.sampleMorph("smile", 10f), 0.0001f)
    }

    @Test fun curvePresetAppliesToAllBoneKeysInRangeAsOneUndoAndLeavesOtherFramesAlone() {
        val e = editor()
        e.zeroBones(listOf("a"), 0)
        e.zeroBones(listOf("a"), 5)
        e.zeroBones(listOf("a"), 10)
        e.zeroBones(listOf("b"), 5)
        e.finish()
        val before = e.curveOf("a", 0)!!.copyOf()
        val preset = intArrayOf(0, 0, 127, 127)

        assertEquals(2, e.setCurveRange(listOf("a", "b"), 4, 8, -1, preset))
        for (track in listOf("a", "b")) {
            val ip = e.curveOf(track, 5)!!
            for (channel in 0..3) {
                assertEquals(preset[0], ip[channel].toInt() and 0xFF)
                assertEquals(preset[1], ip[4 + channel].toInt() and 0xFF)
                assertEquals(preset[2], ip[8 + channel].toInt() and 0xFF)
                assertEquals(preset[3], ip[12 + channel].toInt() and 0xFF)
            }
        }
        assertEquals(before.toList(), e.curveOf("a", 0)!!.toList())
        assertTrue(e.undo())
        assertTrue(e.curveOf("a", 5)!!.contentEquals(e.curveOf("a", 0)!!))
        assertTrue(e.curveOf("b", 5)!!.contentEquals(e.curveOf("a", 0)!!))
    }

    @Test fun curvePresetValidatesInputAndClampsControlPoints() {
        val e = editor()
        e.zeroBones(listOf("a"), 2)
        assertEquals(0, e.setCurveRange(listOf("a"), -1, 2, -1, intArrayOf(1, 2, 3, 4)))
        assertEquals(0, e.setCurveRange(listOf("a"), 0, 3, 4, intArrayOf(1, 2, 3, 4)))
        assertEquals(0, e.setCurveRange(listOf("a"), 0, 3, -1, intArrayOf(1, 2, 3)))
        assertEquals(1, e.setCurveRange(listOf("a"), 0, 3, 0, intArrayOf(-5, 130, 64, 255)))
        val ip = e.curveOf("a", 2)!!
        assertEquals(0, ip[0].toInt() and 0xFF)
        assertEquals(127, ip[4].toInt() and 0xFF)
        assertEquals(64, ip[8].toInt() and 0xFF)
        assertEquals(127, ip[12].toInt() and 0xFF)
    }

    @Test fun smoothingNeedsThreeKeysAndDoesNotChangeKeyTimes() {
        val e = editor()
        e.zeroBones(listOf("a"), 0)
        e.zeroBones(listOf("a"), 5)
        assertEquals(0, e.smoothRange(listOf("a"), emptyList(), 0, 5, 0.8f, 3))
        assertEquals(listOf(0, 5), e.keyFramesOf("a").toList())
    }
}
