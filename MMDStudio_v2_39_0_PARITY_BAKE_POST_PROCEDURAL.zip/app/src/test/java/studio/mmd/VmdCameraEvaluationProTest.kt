package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.VmdCamera

class VmdCameraEvaluationProTest {
    @Test fun binarySearchSamplesLinearWhenInterpolationIsAbsent() {
        val camera = VmdCamera(intArrayOf(0,10), floatArrayOf(30f,10f), floatArrayOf(0f,0f,0f, 10f,20f,30f), floatArrayOf(0f,0f,0f, 1f,2f,3f), floatArrayOf(20f,60f), ByteArray(0))
        val out = FloatArray(8); camera.evaluate(5f, out)
        assertEquals(20f, out[0], 0.001f); assertEquals(5f, out[1], 0.001f)
        assertEquals(10f, out[2], 0.001f); assertEquals(15f, out[3], 0.001f)
        assertEquals(40f, out[7], 0.001f)
    }
    @Test fun clampsBeforeFirstAndAfterLastKey() {
        val camera = VmdCamera(intArrayOf(5,10), floatArrayOf(22f,11f), floatArrayOf(1f,2f,3f, 4f,5f,6f), FloatArray(6), floatArrayOf(35f,70f), ByteArray(48))
        val out = FloatArray(8); camera.evaluate(0f, out); assertEquals(22f, out[0], 0.001f)
        camera.evaluate(100f, out); assertEquals(11f, out[0], 0.001f); assertEquals(70f, out[7], 0.001f)
    }
    @Test fun nonFiniteFrameUsesFirstKeySafely() {
        val camera = VmdCamera(intArrayOf(4), floatArrayOf(17f), floatArrayOf(1f,2f,3f), FloatArray(3), floatArrayOf(55f), ByteArray(24))
        val out = FloatArray(8); camera.evaluate(Float.NaN, out)
        assertEquals(17f, out[0], 0.001f); assertEquals(55f, out[7], 0.001f)
    }
    @Test fun duplicateFramesAvoidZeroDivision() {
        val camera = VmdCamera(intArrayOf(0,0,10), floatArrayOf(30f,20f,10f), FloatArray(9), FloatArray(9), floatArrayOf(30f,40f,50f), ByteArray(72))
        val out = FloatArray(8); camera.evaluate(0f, out)
        assertEquals(20f, out[0], 0.001f)
    }
    @Test fun incompleteArraysReturnSafeDefault() {
        val camera = VmdCamera(intArrayOf(0,10), floatArrayOf(1f), floatArrayOf(0f,0f,0f, 1f,1f,1f), FloatArray(6), floatArrayOf(45f,50f), ByteArray(0))
        val out = FloatArray(8); camera.evaluate(2f, out)
        assertEquals(1f, out[0], 0.001f); assertTrue(out.all { it.isFinite() })
    }
}
