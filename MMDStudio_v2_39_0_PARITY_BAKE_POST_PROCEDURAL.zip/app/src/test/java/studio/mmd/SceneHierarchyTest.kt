package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.project.PropMeta
import studio.mmd.scene.*

class SceneHierarchyTest {
    private fun prop(id: String, bone: String = "") = PropMeta(id, "P$id", "pmx", 1f, 2f, 3f, 1f, bone)
    private val cast = listOf(CastMeta("e1", "Extra", "pmx"))

    @Test fun attachedPropIsChildOfMainWithBone() {
        val g = SceneHierarchy.build("Miku", true, listOf(prop("a", "右手首"), prop("b")), cast, OutlinerState())
        assertEquals("model", g.get("prop:a")!!.parentId); assertEquals("右手首", g.get("prop:a")!!.attachBone)
        assertNull(g.get("prop:b")!!.parentId)
        assertEquals(setOf("prop:a"), SceneHierarchy.attachedKeys(g))
        assertTrue(SceneHierarchy.problems(g).isEmpty())
    }
    @Test fun groupMembersBecomeChildrenOfGroup() {
        val o = OutlinerState(groups = listOf(OutGroup("grp:1", "Cena", listOf("prop:b", "char:e1"))))
        val g = SceneHierarchy.build("M", true, listOf(prop("b")), cast, o)
        assertEquals("grp:1", g.get("prop:b")!!.parentId); assertEquals("grp:1", g.get("char:e1")!!.parentId)
        assertEquals(NodeType.GROUP, g.get("grp:1")!!.type)
        assertTrue(SceneHierarchy.problems(g).isEmpty())
    }
    @Test fun boneAttachmentWinsOverGroup() {
        val o = OutlinerState(groups = listOf(OutGroup("grp:1", "G", listOf("prop:a"))))
        val g = SceneHierarchy.build("M", true, listOf(prop("a", "頭")), cast, o)
        assertEquals("model", g.get("prop:a")!!.parentId)
    }
    @Test fun noModelMeansPropsAreNotAttached() {
        val g = SceneHierarchy.build("", false, listOf(prop("a", "頭")), cast, OutlinerState())
        assertNull(g.get("prop:a")!!.parentId); assertEquals("", g.get("prop:a")!!.attachBone)
        assertEquals("char:e1", g.activeId)
    }
    @Test fun groupWithMissingMemberHasNoInvalidReference() {
        val o = OutlinerState(groups = listOf(OutGroup("grp:1", "G", listOf("prop:gone", "prop:b"))))
        val g = SceneHierarchy.build("M", true, listOf(prop("b")), cast, o)
        assertTrue(SceneHierarchy.problems(g).isEmpty())
    }
    @Test fun problemsDetectsBrokenGraph() {
        val bad = SceneGraph(listOf(SceneNode("a", "A", NodeType.PROP, parentId = "x"), SceneNode("b", "B", NodeType.GROUP, parentId = "c"), SceneNode("c", "C", NodeType.GROUP, parentId = "b")))
        val p = SceneHierarchy.problems(bad)
        assertTrue(p.any { it.contains("pai inexistente") }); assertTrue(p.any { it.contains("ciclo") })
    }
    @Test fun removeKeepingChildrenDetachesThem() {
        val g = SceneHierarchy.build("M", true, listOf(prop("a", "頭")), cast, OutlinerState())
        val r = SceneHierarchy.removeKeepingChildren(g, "model")
        assertNull(r.get("model")); assertNull(r.get("prop:a")!!.parentId); assertEquals("", r.get("prop:a")!!.attachBone)
        assertTrue(SceneHierarchy.problems(r).isEmpty())
        assertEquals("char:e1", r.activeId)
    }
}
