package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.ModelToolsSession
import studio.mmd.edit.WeightPaintMode
import studio.mmd.edit.WeightPaintSession
import studio.mmd.edit.MeshTopologyAnalyzer
import studio.mmd.edit.WeightTransfer
import studio.mmd.edit.WeightTransferOptions
import studio.mmd.fx.FxConfig
import studio.mmd.fx.FxStyle
import studio.mmd.fx.ParticleFx
import studio.mmd.rig.ClothXpbd
import studio.mmd.rig.ClothBakeCache
import studio.mmd.rig.ClothCacheCodec
import studio.mmd.rig.ClothSphere
import studio.mmd.rig.ClothBox
import studio.mmd.rig.ClothTriangleCollider
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

class AdvancedStudioToolsTest {
    private fun mesh(): PmxModel {
        val mats = listOf(
            PmxMaterial("A", "A", floatArrayOf(1f,1f,1f,1f), FloatArray(3), 0f, FloatArray(3), 0, FloatArray(4), 0f, -1,-1,0,true,0,3),
            PmxMaterial("B", "B", floatArrayOf(1f,1f,1f,1f), FloatArray(3), 0f, FloatArray(3), 0, FloatArray(4), 0f, -1,-1,0,true,0,3)
        )
        val bones = listOf(PmxBone("root", "root", 0f,0f,0f,-1,0,0x001F,-1,-1,0f,null), PmxBone("leftArm", "leftArm", 0f,1f,0f,0,0,0x001F,-1,-1,0f,null))
        return PmxModel("mesh", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f, 2f,0f,0f),
            FloatArray(12), FloatArray(8),
            intArrayOf(0,-1,-1,-1, 0,-1,-1,-1, 1,-1,-1,-1, 1,-1,-1,-1),
            floatArrayOf(1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f),
            intArrayOf(0,1,2, 1,3,2), emptyList(), mats, bones, emptyList())
    }

    @Test fun materialSelectionAndRingExpansionAreTopological() {
        val s = ModelToolsSession(mesh())
        assertEquals(3, s.selectByMaterial(0))
        assertEquals(3, s.selectedCount)
        assertEquals(4, s.growSelection())
        assertEquals(4, s.shrinkSelection())
        assertEquals(2, s.selectByBone(1))
    }

    @Test fun selectedSculptOnlyMovesSelectedVerticesAndUndoRestores() {
        val s = ModelToolsSession(mesh())
        s.selectRange(0, 1)
        val before = s.buildModel().positions.copyOf()
        assertEquals(2, s.transformSelected(1f, 0f, 0f).changed)
        val after = s.buildModel().positions
        assertEquals(before[0] + 1f, after[0], .0001f)
        assertEquals(before[3] + 1f, after[3], .0001f)
        assertEquals(before[6], after[6], .0001f)
        assertTrue(s.undo())
        assertArrayEquals(before, s.buildModel().positions, .0001f)
    }

    @Test fun localSmoothAndInflateOperateOnlyOnSelectedVertices() {
        val s = ModelToolsSession(mesh())
        s.recalculateNormals()
        s.selectRange(0, 0)
        val untouched = s.buildModel().positions.copyOfRange(3, 12)
        s.smoothSelected(2, .5f)
        assertArrayEquals(untouched, s.buildModel().positions.copyOfRange(3, 12), .0001f)
        s.inflateSelected(.1f)
        assertTrue(kotlin.math.abs(s.buildModel().positions[2]) > 0f)
    }

    @Test fun cylindricalAndSphericalUvAreFiniteAndUndoable() {
        val s = ModelToolsSession(mesh())
        assertEquals(4, s.cylindricalUv().changed)
        assertTrue(s.buildModel().uvs.all { it.isFinite() })
        assertEquals(4, s.sphericalUv().changed)
        assertTrue(s.buildModel().uvs.all { it.isFinite() })
        assertTrue(s.undo())
    }

    @Test fun selectedWeightPaintingPreservesNormalizationAndUndo() {
        val m = mesh(); val s = WeightPaintSession(m)
        val before = s.buildModel().boneWeights.copyOf()
        val result = s.paintVertices(intArrayOf(0, 1), 1, .8f, 1f, WeightPaintMode.REPLACE)
        assertEquals(2, result.changed)
        assertEquals(.8f, s.influenceAt(0, 1), .0001f)
        assertEquals(1f, s.buildModel().boneWeights[0] + s.buildModel().boneWeights[1] + s.buildModel().boneWeights[2] + s.buildModel().boneWeights[3], .0001f)
        assertTrue(s.undo())
        assertArrayEquals(before, s.buildModel().boneWeights, .0001f)
    }

    @Test fun materialTextureSlotsCanBeReassignedWithoutLosingMaterialProperties() {
        val m = mesh()
        val textured = PmxModel(m.name, m.version, m.positions, m.normals, m.uvs, m.boneIndices, m.boneWeights,
            m.indices, listOf("base.png", "sphere.png"), m.materials, m.bones, m.morphs)
        val s = ModelToolsSession(textured)
        assertEquals(1, s.setMaterialTextures(0, 0, 1, 2).changed)
        val mat = s.buildModel().materials[0]
        assertEquals(0, mat.textureIndex)
        assertEquals(1, mat.sphereIndex)
        assertEquals(2, mat.sphereMode)
        assertEquals("A", mat.name)
        assertEquals(3, mat.indexCount)
        assertTrue(s.undo())
        assertEquals(-1, s.buildModel().materials[0].textureIndex)
    }


    @Test fun spatialSelectionAndSelectedUvNormalizationRespectSelection() {
        val s = ModelToolsSession(mesh())
        assertEquals(2, s.selectInBounds(0f, 1f, 0f, 0f, 0f, 0f))
        assertEquals(2, s.selectedCount)
        s.transformUv(2f, 3f, .25f, -.5f)
        val before = s.buildModel().uvs.copyOf()
        assertEquals(2, s.normalizeSelectedUv().changed)
        val after = s.buildModel().uvs
        assertTrue(after.all { it.isFinite() })
        assertEquals(0f, after[0], .0001f)
        assertEquals(1f, after[2], .0001f)
        assertTrue(s.undo())
        assertArrayEquals(before, s.buildModel().uvs, .0001f)
    }

    @Test fun editedMeshAndMaterialsSurvivePmxWriteParseRoundTrip() {
        val source = mesh()
        val textured = PmxModel(source.name, source.version, source.positions, source.normals, source.uvs,
            source.boneIndices, source.boneWeights, source.indices, listOf("base.png"), source.materials,
            source.bones, source.morphs)
        val edit = ModelToolsSession(textured)
        edit.selectRange(0, 1)
        edit.transformSelected(.2f, 0f, 0f)
        edit.setMaterialTextures(0, 0, -1, 0)
        val written = PmxWriter.write(edit.buildModel())
        val parsed = PmxParser.parse(written.bytes)
        assertEquals(4, parsed.vertexCount)
        assertEquals(0, parsed.materials[0].textureIndex)
        assertEquals("base.png", parsed.textures[0])
        assertEquals(edit.buildModel().positions[0], parsed.positions[0], .0001f)
        assertEquals(edit.buildModel().positions[3], parsed.positions[3], .0001f)
    }

    @Test fun proceduralEffectsAreDeterministicAndFrameDependent() {
        val cfg = FxConfig(enabled = true, style = FxStyle.SPARKS, count = 30, seed = 42)
        val a = ParticleFx.buildLines(cfg, 12f)
        val b = ParticleFx.buildLines(cfg, 12f)
        val c = ParticleFx.buildLines(cfg, 20f)
        assertArrayEquals(a, b, 0f)
        assertFalse(a.contentEquals(c))
        assertEquals(30 * 6, a.size)
        assertTrue(a.all { it.isFinite() })
        FxStyle.entries.forEach { style ->
            val generated = ParticleFx.buildLines(cfg.copy(style = style), 4f, 24f)
            assertEquals(cfg.count * 6, generated.size)
            assertTrue("$style emitted non-finite coordinates", generated.all { it.isFinite() })
            val points = ParticleFx.buildPoints(cfg.copy(style = style), 4f, 24f)
            assertEquals(cfg.count * 3, points.size)
            assertTrue("$style emitted non-finite point sprites", points.all { it.isFinite() })
        }
        assertTrue(ParticleFx.buildLines(cfg.copy(enabled = false), 12f).isEmpty())
    }
    @Test fun xpbdSolverKeepsAnchorsAndProducesFiniteDeformation() {
        val m = mesh()
        val solver = ClothXpbd.fromMesh(m.positions, m.indices, particleMass = 1f)
        solver.pin(0)
        solver.setColliders(spheres = listOf(ClothSphere(10f, 10f, 10f, .5f)))
        val result = solver.step(1f / 30f, gravityY = -9.81f, groundY = null, substeps = 4, iterations = 8)
        assertEquals(m.positions[0], result[0], .0001f)
        assertEquals(m.positions[1], result[1], .0001f)
        assertEquals(m.positions[2], result[2], .0001f)
        assertTrue(result.all { it.isFinite() })
        assertTrue(result.indices.any { kotlin.math.abs(result[it] - m.positions[it]) > 1e-7f })
    }

    @Test fun clothCacheCodecRoundTripsAndRejectsCorruption() {
        val m = mesh()
        val solver = ClothXpbd.fromMesh(m.positions, m.indices)
        val frame = solver.step(1f / 30f, groundY = null)
        val signature = ClothCacheCodec.modelSignature(m.positions, m.indices)
        val cache = ClothBakeCache(m.vertexCount, 30, listOf(frame, frame.copyOf()), signature)
        val encoded = ClothCacheCodec.encode(cache)
        val decoded = ClothCacheCodec.decode(encoded)
        assertEquals(cache.vertexCount, decoded.vertexCount)
        assertEquals(cache.fps, decoded.fps)
        assertEquals(signature, decoded.modelHash)
        assertNotEquals(signature, ClothCacheCodec.modelSignature(m.positions.copyOf().also { it[0] += .01f }, m.indices))
        assertArrayEquals(frame, decoded.frames[0], .0001f)
        val corrupt = encoded.copyOf().also { it[it.lastIndex - 5] = (it[it.lastIndex - 5].toInt() xor 0x20).toByte() }
        assertTrue(runCatching { ClothCacheCodec.decode(corrupt) }.isFailure)
    }

    @Test fun clothCacheCodecStillReadsLegacyVersionOneFiles() {
        val m = mesh()
        val frame = m.positions.copyOf()
        val payload = frame.size.toLong() * 4L
        val bytes = ByteBuffer.allocate(8 + 4 * 4 + 8 + payload.toInt() + 4).order(ByteOrder.LITTLE_ENDIAN)
        bytes.put(byteArrayOf(77, 77, 68, 67, 76, 84, 72, 49))
        bytes.putInt(1); bytes.putInt(m.vertexCount); bytes.putInt(30); bytes.putInt(1); bytes.putLong(payload)
        frame.forEach { bytes.putFloat(it) }
        val crc = CRC32(); crc.update(bytes.array(), 0, bytes.position()); bytes.putInt(crc.value.toInt())
        val decoded = ClothCacheCodec.decode(bytes.array())
        assertEquals(m.vertexCount, decoded.vertexCount)
        assertEquals(0L, decoded.modelHash)
        assertArrayEquals(frame, decoded.frames.single(), .0001f)
    }

    @Test fun topologyAnalyzerReportsBoundariesComponentsAndUvDegeneracy() {
        val report = MeshTopologyAnalyzer.inspect(mesh())
        assertEquals(2, report.validTriangles)
        assertEquals(4, report.boundaryEdges)
        assertEquals(0, report.nonManifoldEdges)
        assertEquals(1, report.connectedComponents)
        assertEquals(0, report.isolatedVertices)
        assertEquals(2, report.zeroAreaUvTriangles)
    }

    @Test fun uvRelaxKeepsSelectionBoundaryAndMaterialAtlasRespectsSharedVertices() {
        val s = ModelToolsSession(mesh())
        s.selectRange(0, 2)
        val before = s.buildModel().uvs.copyOf()
        val relaxed = s.relaxSelectedUv(4, .5f)
        assertTrue(relaxed.message.contains("borda"))
        assertArrayEquals(before.copyOfRange(2, 6), s.buildModel().uvs.copyOfRange(2, 6), .0001f)
        val atlas = ModelToolsSession(mesh()).materialAtlas()
        assertTrue(atlas.changed >= 2)
        assertTrue(atlas.message.contains("compartilhados"))
        assertTrue(atlas.message.contains("costuras"))
    }

    @Test fun weightTransferMapsBoneInfluencesByNameAndNormalizes() {
        val source = mesh()
        val target = mesh()
        val report = WeightTransfer.transfer(source, target, WeightTransferOptions(neighbors = 3))
        assertEquals(target.vertexCount, report.transferredVertices)
        assertEquals(0, report.fallbackVertices)
        assertEquals(1, report.model.boneIndices[2 * 4])
        assertEquals(1f, report.model.boneWeights[2 * 4], .0001f)
        for (v in 0 until target.vertexCount) {
            val sum = (0..3).sumOf { report.model.boneWeights[v * 4 + it].toDouble() }.toFloat()
            assertEquals(1f, sum, .0001f)
        }
    }

    @Test fun weightTransferCanBeAppliedAndUndoneAsOneWeightPaintOperation() {
        val source = mesh()
        val session = WeightPaintSession(mesh())
        val before = session.buildModel().boneIndices.copyOf()
        val report = session.transferFrom(source, WeightTransferOptions(neighbors = 3))
        assertEquals(4, report.transferredVertices)
        assertTrue(session.canUndo)
        assertTrue(session.undo())
        assertArrayEquals(before, session.buildModel().boneIndices)
    }

    @Test fun unmatchedWeightTransferUsesConsistentBdefFallback() {
        val source = mesh()
        val original = mesh()
        val renamedBones = original.bones.mapIndexed { i, b -> PmxBone("unmatched_$i", b.nameEn, b.x, b.y, b.z, b.parent, b.layer, b.flags, b.tailBone, b.inheritParent, b.inheritWeight, b.ik) }
        val target = PmxModel(original.name, original.version, original.positions.copyOf(), original.normals.copyOf(), original.uvs.copyOf(),
            original.boneIndices.copyOf(), original.boneWeights.copyOf(), original.indices.copyOf(), original.textures, original.materials, renamedBones,
            original.morphs, original.rigidBodies, original.joints, weightTypes = ByteArray(original.vertexCount) { 3 })
        val report = WeightTransfer.transfer(source, target)
        assertEquals(target.vertexCount, report.fallbackVertices)
        assertTrue(report.model.weightTypes.all { it.toInt() == 0 })
        for (v in 0 until target.vertexCount) {
            assertEquals(0, report.model.boneIndices[v * 4])
            assertEquals(1f, report.model.boneWeights[v * 4], .0001f)
        }
    }

    @Test fun clothBoxColliderPushesParticleOutsideOrientedBounds() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f, 0f, 0f), intArrayOf())
        solver.setColliders(boxes = listOf(ClothBox(0f, 0f, 0f, 2f, .5f, .25f, 0f, (Math.PI / 2).toFloat(), 0f)), thickness = .02f)
        val p = solver.step(1f / 30f, gravityY = 0f, groundY = null)
        assertTrue(kotlin.math.abs(p[0]) >= .269f)
        assertTrue(p.all { it.isFinite() })
    }

    @Test fun clothTriangleSurfaceColliderPushesParticleOutOfBodySurface() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(.2f, .2f, .005f), intArrayOf())
        val surface = ClothTriangleCollider(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f)
        solver.setColliders(triangles = listOf(surface), thickness = .02f, cellSize = .1f)
        val p = solver.step(1f / 30f, gravityY = 0f, groundY = null)
        assertTrue("surface projection failed: ${p.toList()}", p[2] >= .019f)
        assertTrue(p.all { it.isFinite() })
    }

}
