package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.ModelDiagnostics
import studio.mmd.edit.ModelToolsSession
import studio.mmd.edit.copyPmxMaterial
import studio.mmd.mmd.*

class ModelToolsTest {
    private fun model(): PmxModel {
        val material = PmxMaterial("Body", "Body", floatArrayOf(.8f, .7f, .6f, 1f), floatArrayOf(.1f, .1f, .1f), 16f,
            floatArrayOf(.2f, .2f, .2f), 0x10, floatArrayOf(0f, 0f, 0f, 1f), 1f,
            -1, -1, 0, true, 0, 3)
        val bones = listOf(PmxBone("root", "root", .5f, .5f, 0f, -1, 0, 0x001F, -1, -1, 0f, null))
        val morph = PmxMorph("smile", "smile", 1, 1, intArrayOf(0), floatArrayOf(.5f, 0f, 0f))
        val rigid = PmxRigid("body", "body", 0, 0, 0, 1f, .1f, .1f, 1, 0, floatArrayOf(1f, 1f, 1f), floatArrayOf(.5f, .5f, 0f), FloatArray(3))
        val joint = PmxJoint("joint", 0, 0, floatArrayOf(.5f, .5f, 0f), FloatArray(3), FloatArray(3), FloatArray(3), FloatArray(3), FloatArray(3), FloatArray(3), FloatArray(3))
        return PmxModel("test", 2.1f,
            floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f),
            FloatArray(9), FloatArray(6),
            intArrayOf(0, -1, -1, -1, 0, -1, -1, -1, 0, -1, -1, -1),
            floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f),
            intArrayOf(0, 1, 2), emptyList(), listOf(material), bones, listOf(morph), listOf(rigid), listOf(joint))
    }

    @Test fun planarUvAndFlipAreUndoable() {
        val s = ModelToolsSession(model())
        val r = s.planarUv(1)
        assertEquals(3, r.changed)
        val uv = s.buildModel().uvs
        assertEquals(0f, uv[0], .0001f)
        assertEquals(1f, uv[2], .0001f)
        assertTrue(s.flipUv(true).changed > 0)
        assertTrue(s.undo())
        assertArrayEquals(uv, s.buildModel().uvs, .0001f)
    }

    @Test fun recalculatedNormalsAreUnitLength() {
        val s = ModelToolsSession(model())
        assertEquals(3, s.recalculateNormals().changed)
        val n = s.buildModel().normals
        for (i in 0 until 3) {
            val o = i * 3
            val len = kotlin.math.sqrt(n[o] * n[o] + n[o + 1] * n[o + 1] + n[o + 2] * n[o + 2])
            assertEquals(1f, len, .0001f)
            assertTrue(n[o + 2] > .99f)
        }
    }

    @Test fun geometryTransformKeepsRigAndVertexMorphAligned() {
        val s = ModelToolsSession(model())
        s.transformGeometry(2f, 1f, 1f, 0f, 0f, 0f)
        val m = s.buildModel()
        assertEquals(.5f, m.bones[0].x, .0001f)
        assertEquals(1f, m.morphs[0].vertexDelta!![0], .0001f)
        assertEquals(2f, m.rigidBodies[0].size[0], .0001f)
        assertTrue(s.undo())
        assertEquals(0f, s.buildModel().positions[0], .0001f)
        assertTrue(s.redo())
        assertEquals(-.5f, s.buildModel().positions[0], .0001f)
    }

    @Test fun materialUpdatePreservesTextureAndIndexMetadata() {
        val s = ModelToolsSession(model())
        val old = s.material(0)!!
        val edited = copyPmxMaterial(old, diffuse = floatArrayOf(1f, .2f, .3f, .8f), flags = old.flags or 1, specularPower = 64f)
        s.updateMaterial(0, edited)
        val result = s.buildModel().materials[0]
        assertEquals(.8f, result.diffuse[3], .0001f)
        assertTrue(result.doubleSided)
        assertEquals(64f, result.specularPower, .0001f)
        assertEquals(3, result.indexCount)
    }


    @Test fun rigidAndJointRotationsComposeDegreesAsRadians() {
        val s = ModelToolsSession(model())
        s.transformGeometry(1f, 1f, 1f, 90f, 0f, 0f)
        val edited = s.buildModel()
        assertEquals((Math.PI / 2.0).toFloat(), edited.rigidBodies[0].rot[0], .0001f)
        assertEquals((Math.PI / 2.0).toFloat(), edited.joints[0].rot[0], .0001f)
    }

    @Test fun diagnosticsAllowIntentionalUvTilingButRejectNonFinitePositions() {
        val session = ModelToolsSession(model())
        session.recalculateNormals()
        session.planarUv(1)
        session.transformUv(2f, 2f, 0f, 0f)
        val tiled = ModelDiagnostics.inspect(session.buildModel())
        assertTrue(tiled.uvOutsideUnit > 0)
        assertFalse(tiled.hasErrors)
        val good = model()
        val badPositions = good.positions.copyOf().also { it[0] = Float.NaN }
        val broken = PmxModel(good.name, good.version, badPositions, good.normals, good.uvs, good.boneIndices, good.boneWeights,
            good.indices, good.textures, good.materials, good.bones, good.morphs, good.rigidBodies, good.joints)
        val report = ModelDiagnostics.inspect(broken)
        assertTrue(report.nonFinitePositions > 0)
        assertTrue(report.hasErrors)
    }

    @Test fun diagnosticsFindBadNormalsAndDegenerateFaces() {
        val valid = model()
        val broken = PmxModel(valid.name, valid.version, valid.positions, valid.normals, valid.uvs, valid.boneIndices, valid.boneWeights,
            intArrayOf(0, 0, 1), valid.textures, valid.materials, valid.bones, valid.morphs, valid.rigidBodies, valid.joints)
        val report = ModelDiagnostics.inspect(broken)
        assertEquals(1, report.degenerateTriangles)
        assertEquals(3, report.invalidNormals)
        assertTrue(report.issues.isNotEmpty())
    }
}
