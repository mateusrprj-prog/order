package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.PmxJoint
import studio.mmd.rig.PmxJointProfiles

class PmxJointProfilesTest {
    private fun joint(type: Int) = PmxJoint("joint", 0, 1, FloatArray(3), FloatArray(3),
        floatArrayOf(-1f,-2f,-3f), floatArrayOf(1f,2f,3f),
        floatArrayOf(-.4f,-.5f,-.6f), floatArrayOf(.4f,.5f,.6f),
        floatArrayOf(8f,8f,8f), floatArrayOf(9f,9f,9f), type)

    @Test fun spring6DofRetainsSpringCoefficients() {
        val p = PmxJointProfiles.resolve(joint(0))
        assertEquals(8f, p.springPosition[0], 0f)
        assertEquals(9f, p.springRotation[1], 0f)
        assertEquals(-2f, p.positionMin[1], 0f)
    }

    @Test fun sixDofUsesLimitsWithoutSprings() {
        val p = PmxJointProfiles.resolve(joint(1))
        assertEquals(0f, p.springPosition.sum(), 0f)
        assertEquals(0f, p.springRotation.sum(), 0f)
        assertEquals(-.5f, p.rotationMin[1], 0f)
    }

    @Test fun pointToPointLocksTranslationAndFreesRotation() {
        val p = PmxJointProfiles.resolve(joint(2))
        assertTrue(p.positionMin.all { it == 0f } && p.positionMax.all { it == 0f })
        assertTrue(p.rotationMin.all { it < -1000f } && p.rotationMax.all { it > 1000f })
    }

    @Test fun coneTwistRetainsAngularLimitsAndLocksTranslation() {
        val p = PmxJointProfiles.resolve(joint(3))
        assertTrue(p.approximate)
        assertTrue(p.positionMin.all { it == 0f } && p.positionMax.all { it == 0f })
        assertEquals(-.6f, p.rotationMin[2], 0f)
    }

    @Test fun sliderAllowsOnlyLocalXTranslation() {
        val p = PmxJointProfiles.resolve(joint(4))
        assertEquals(-1f, p.positionMin[0], 0f)
        assertEquals(1f, p.positionMax[0], 0f)
        assertEquals(0f, p.positionMin[1], 0f)
        assertTrue(p.rotationMin.all { it == 0f } && p.rotationMax.all { it == 0f })
    }

    @Test fun hingeAllowsOnlyLocalXRotation() {
        val p = PmxJointProfiles.resolve(joint(5))
        assertTrue(p.positionMin.all { it == 0f } && p.positionMax.all { it == 0f })
        assertEquals(-.4f, p.rotationMin[0], 0f)
        assertEquals(0f, p.rotationMin[1], 0f)
        assertEquals(0f, p.rotationMax[2], 0f)
    }
}
