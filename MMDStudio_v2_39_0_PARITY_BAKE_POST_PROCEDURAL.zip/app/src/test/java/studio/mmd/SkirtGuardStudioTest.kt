package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import studio.mmd.rig.*

/** v2.6.0 — colisão de superfície corporal animada, preview estável e bake incremental. */
class SkirtGuardStudioTest {
    private fun testModel(): PmxModel {
        val positions = floatArrayOf(
            -0.18f, 1.0f, -0.18f, 0.18f, 1.0f, -0.18f,
            -0.18f, 1.0f, 0.18f, 0.18f, 1.0f, 0.18f,
            -0.25f, 0.15f, -0.25f, 0.25f, 0.15f, -0.25f,
            -0.25f, 0.15f, 0.25f, 0.25f, 0.15f, 0.25f
        )
        val indices = intArrayOf(0, 1, 4, 1, 5, 4, 1, 3, 5, 3, 7, 5, 3, 2, 7, 2, 6, 7, 2, 0, 6, 0, 4, 6)
        val bones = listOf(
            PmxBone("下半身", "LowerBody", 0f, 1f, 0f, -1, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("左足", "Left Leg", 0.1f, 0.8f, 0f, 0, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("左ひざ", "Left Knee", 0.1f, 0.4f, 0f, 1, 0, 0x001F, -1, -1, 0f, null)
        )
        val material = PmxMaterial("スカート", "Skirt", floatArrayOf(1f, 1f, 1f, 1f), FloatArray(3), 0f,
            FloatArray(3), 0, FloatArray(4), 0f, -1, -1, 0, true, 0, indices.size)
        val boneIndices = IntArray(positions.size / 3 * 4) { -1 }
        val boneWeights = FloatArray(positions.size / 3 * 4)
        for (v in 0 until positions.size / 3) {
            boneIndices[v * 4] = if (v < 4) 0 else 1
            boneWeights[v * 4] = 1f
        }
        return PmxModel("Skirt test", 2.1f, positions, FloatArray(positions.size), FloatArray(positions.size / 3 * 2),
            boneIndices, boneWeights, indices, emptyList(), listOf(material), bones, emptyList())
    }

    @Test fun playbackSessionBuildsBoundedSkirtMeshAndReturnsIndependentSnapshot() {
        val model = testModel()
        val original = model.positions.copyOf()
        val profile = SkirtGuardAuto.profile(model)
        assertTrue(profile.detected)
        assertTrue(profile.colliderHints.isNotEmpty())
        val session = SkirtGuardPlaybackSession(model, profile)
        assertTrue(session.ready)
        val current = Animator(model, 1f).also { it.prepareClothPose(1f) }
        val previous = Animator(model, 1f).also { it.prepareClothPose(0f) }
        val result = session.step(1f / 30f, current, previous, 0.018f)
        assertNotNull(result)
        assertEquals(model.positions.size, result!!.size)
        assertTrue(result.all { it.isFinite() })
        assertArrayEquals(original, model.positions, 0f)
        assertNotSame(model.positions, result)
    }

    @Test fun playbackSessionRefusesOversizedGarmentsInsteadOfFreezingViewport() {
        val model = testModel()
        val session = SkirtGuardPlaybackSession(model, SkirtGuardAuto.profile(model), maxVertices = 3)
        assertFalse(session.ready)
        assertTrue(session.status.contains("limitado"))
    }

    @Test fun autoFixNeverExceedsPerVertexDisplacementLimit() {
        val model = testModel()
        val vertices = SkirtGuardAuto.profile(model).skirtVertexIndices
        val before = model.positions.copyOf()
        val capsule = ClothCapsule(0f, 0f, 0f, 0f, 1f, 0f, 0.4f)
        val report = SkirtGuardStudio.autoFix(before, vertices, listOf(capsule), maxDisplacement = 0.01f, strength = 1f, passes = 4)
        assertTrue(report.maxDisplacement <= 0.01001f)
        assertEquals(model.positions.size, report.positions.size)
        assertArrayEquals(model.positions, before, 0f)
    }

    @Test fun bakeAutoFixCorrectionPreservesVelocityHistory() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f, 0f, 0f), intArrayOf())
        assertTrue(solver.applyPositionCorrection(0, 0.02f, 0.03f, 0.04f))
        assertArrayEquals(floatArrayOf(0.02f, 0.03f, 0.04f), solver.step(1f / 30f, gravityY = 0f, substeps = 1, iterations = 1, damping = 0f, groundY = null), 1e-6f)
        solver.pin(0)
        assertFalse(solver.applyPositionCorrection(0, 1f, 1f, 1f))
    }


    @Test fun playbackBuildsBoundedAnimatedBodySurfaceAndCanDisableIt() {
        val base = testModel()
        val positions = floatArrayOf(
            -0.25f, 0.76f, 0.16f, 0.25f, 0.76f, 0.16f, 0f, 0.58f, 0.18f,
            -0.12f, 0.70f, 0.02f, 0.12f, 0.70f, 0.02f, 0f, 0.55f, 0.02f
        )
        val materials = listOf(
            PmxMaterial("スカート", "Skirt", floatArrayOf(1f,1f,1f,1f), FloatArray(3), 0f, FloatArray(3), 0, FloatArray(4), 0f, -1, -1, 0, false, 0, 3),
            PmxMaterial("Body", "Body", floatArrayOf(1f,1f,1f,1f), FloatArray(3), 0f, FloatArray(3), 0, FloatArray(4), 0f, -1, -1, 0, false, 0, 3)
        )
        val bones = listOf(
            PmxBone("下半身", "LowerBody", 0f, 1f, 0f, -1, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("左足", "Left thigh", -0.12f, 0.8f, 0f, 0, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("左ひざ", "Left knee", -0.12f, 0.4f, 0f, 1, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("右足", "Right thigh", 0.12f, 0.8f, 0f, 0, 0, 0x001F, -1, -1, 0f, null)
        )
        val boneIndices = IntArray(24) { -1 }; val boneWeights = FloatArray(24)
        for (v in 0..2) { boneIndices[v * 4] = 0; boneWeights[v * 4] = 1f }
        for (v in 3..5) { boneIndices[v * 4] = 1; boneWeights[v * 4] = 1f }
        val model = PmxModel("body-surface", 2.1f, positions, FloatArray(positions.size), FloatArray(12),
            boneIndices, boneWeights, intArrayOf(0,1,2,3,4,5), emptyList(), materials, bones, emptyList())
        val profile = SkirtGuardAuto.profile(model)
        assertTrue(profile.detected)
        val session = SkirtGuardPlaybackSession(model, profile, bodySurfaceCollision = true)
        assertTrue(session.ready)
        assertEquals(1, session.bodyCollisionTriangleCount)
        val disabled = SkirtGuardPlaybackSession(model, profile, bodySurfaceCollision = false)
        assertEquals(0, disabled.bodyCollisionTriangleCount)
    }

    @Test fun partialBakeMergePreservesUntouchedFrames() {
        val hash = 1234L
        val old = ClothBakeCache(1, 30, listOf(floatArrayOf(0f,0f,0f), floatArrayOf(1f,1f,1f), floatArrayOf(2f,2f,2f)), hash)
        val merged = ClothCacheCodec.mergeFrameRange(old, 1, listOf(floatArrayOf(9f,9f,9f)), 1, 30, hash, floatArrayOf(-1f,-1f,-1f))
        assertArrayEquals(floatArrayOf(0f,0f,0f), merged.frames[0], 0f)
        assertArrayEquals(floatArrayOf(9f,9f,9f), merged.frames[1], 0f)
        assertArrayEquals(floatArrayOf(2f,2f,2f), merged.frames[2], 0f)
    }

    @Test fun partialBakeRequiresCompatiblePreviousCache() {
        try {
            ClothCacheCodec.mergeFrameRange(null, 5, listOf(floatArrayOf(1f,1f,1f)), 1, 30, 1L, floatArrayOf(0f,0f,0f))
            fail("A partial bake must require a compatible prior cache")
        } catch (expected: IllegalArgumentException) { assertTrue(expected.message!!.contains("cache anterior")) }
    }

    @Test fun analysisReportsNonFiniteSafeGeometryAndRecognizedMaterial() {
        val model = testModel()
        val report = SkirtGuardStudio.analyzePose(model, null, 0f)
        assertTrue(report.detected)
        assertTrue(report.confidence > 0.5f)
        assertTrue(report.testedVertices > 0)
        assertTrue(report.selfIntersectingTrianglePairs >= 0)
    }
}
