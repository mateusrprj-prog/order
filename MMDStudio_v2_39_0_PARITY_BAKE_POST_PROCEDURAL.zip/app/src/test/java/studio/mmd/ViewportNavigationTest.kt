package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.render.OrbitCamera
import studio.mmd.render.ViewPreset
import studio.mmd.ui.GizmoMath
import kotlin.math.abs
import kotlin.math.sqrt

/** v1.30.0 (P0 Navegação Livre): matemática da câmera de viewport e do gizmo. Roda em JVM, sem Android. */
class ViewportNavigationTest {
    private fun dist(a: FloatArray, b: FloatArray) = sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
    private fun dot(a: FloatArray, b: FloatArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    private fun fwd(c: OrbitCamera): FloatArray { val e = c.eye(); return floatArrayOf(e[0] - c.tx, e[1] - c.ty, e[2] - c.tz) }

    @Test fun orbitHorizontalChangesOnlyYaw() {
        val c = OrbitCamera(); val p0 = c.pitch
        c.orbit(100f, 0f)
        assertEquals(p0, c.pitch, 1e-4f); assertEquals(30f - 40f, c.yaw, 1e-3f)
    }

    @Test fun orbitAnyAngleReachesBackAndSides() {
        val c = OrbitCamera(); c.setAngles(0f, 0f)
        c.orbit(450f, 0f)                       // 180° de giro: de frente para as costas
        assertEquals(180f, abs(c.yaw), 1e-2f)
        val e = c.eye(); assertTrue("câmera atrás do modelo", e[2] < 0f)
    }

    @Test fun pitchIsClampedNeverFlips() {
        val c = OrbitCamera()
        c.orbit(0f, 100000f); assertEquals(89f, c.pitch, 1e-4f)
        c.orbit(0f, -100000f); assertEquals(-89f, c.pitch, 1e-4f)
    }

    @Test fun yawStaysInRangeAfterManyTurns() {
        val c = OrbitCamera()
        repeat(500) { c.orbit(37f, 0f) }
        assertTrue(c.yaw > -180f && c.yaw <= 180f)
    }

    @Test fun orbitKeepsDistanceToFocusConstant() {
        val c = OrbitCamera(); c.focusOn(2f, 1f, -3f); c.dist = 7f
        repeat(50) { c.orbit(13f, 5f); assertEquals(7f, dist(c.eye(), floatArrayOf(c.tx, c.ty, c.tz)), 1e-3f) }
    }

    @Test fun cameraBasisIsOrthonormalAndRightHanded() {
        for (y in listOf(-170f, -90f, 0f, 33f, 90f, 180f)) for (p in listOf(-80f, 0f, 45f, 88f)) {
            val c = OrbitCamera(); c.setAngles(y, p)
            val r = c.right(); val u = c.up(); val f = fwd(c).map { it / c.dist }.toFloatArray()
            assertEquals(0f, dot(r, u), 1e-4f); assertEquals(0f, dot(r, f), 1e-4f); assertEquals(0f, dot(u, f), 1e-4f)
            assertEquals(1f, dot(u, u), 1e-4f)
            // r × u = f (direita × cima = para trás da câmera)
            val cx = r[1] * u[2] - r[2] * u[1]; val cy = r[2] * u[0] - r[0] * u[2]; val cz = r[0] * u[1] - r[1] * u[0]
            assertEquals(f[0], cx, 1e-4f); assertEquals(f[1], cy, 1e-4f); assertEquals(f[2], cz, 1e-4f)
        }
    }

    @Test fun panMovesFocusInCameraPlaneAndKeepsAngles() {
        val c = OrbitCamera(); c.setAngles(40f, 60f); c.dist = 10f; c.focusOn(0f, 1f, 0f)
        val y0 = c.yaw; val p0 = c.pitch; val d0 = c.dist
        c.pan(80f, -50f, 1000f)
        assertEquals(y0, c.yaw, 1e-4f); assertEquals(p0, c.pitch, 1e-4f); assertEquals(d0, c.dist, 1e-4f)
        val moved = floatArrayOf(c.tx - 0f, c.ty - 1f, c.tz - 0f)
        assertEquals("pan não pode andar na direção de visada", 0f, dot(moved, fwd(c)), 1e-3f)
        assertTrue("moveu", dist(moved, floatArrayOf(0f, 0f, 0f)) > 0.01f)
    }

    @Test fun panWithHighPitchStillUsesCameraUp() {
        // antes (v1.29): com a câmera olhando de cima, arrastar p/ cima só mudava ty. Agora desloca em tz/tx (plano da tela).
        val c = OrbitCamera(); c.setAngles(0f, 80f); c.focusOn(0f, 0f, 0f)
        c.pan(0f, 100f, 1000f)
        assertTrue(abs(c.tz) > abs(c.ty))
    }

    @Test fun panDoesNotDependOnAnyObject() {
        // a câmera só tem estado de visualização: não há como alterar modelo/osso/keyframe por aqui
        val fields = OrbitCamera::class.java.declaredFields.map { it.name }.toSet()
        assertTrue(fields.containsAll(setOf("yaw", "pitch", "dist", "tx", "ty", "tz")))
    }

    @Test fun zoomIsLimitedAndFollowsPinchDirection() {
        val c = OrbitCamera(); c.dist = 10f
        c.zoom(2f); assertEquals(5f, c.dist, 1e-4f)         // abrir dedos aproxima
        c.zoom(0.5f); assertEquals(10f, c.dist, 1e-4f)      // fechar afasta
        repeat(200) { c.zoom(1.5f) }; assertEquals(c.minDist, c.dist, 1e-4f)
        repeat(400) { c.zoom(0.5f) }; assertEquals(c.maxDist, c.dist, 1e-3f)
        val d = c.dist; c.zoom(0f); c.zoom(Float.NaN); c.zoom(-1f); assertEquals(d, c.dist, 0f)
    }

    @Test fun focusKeepsAnglesAndDistanceButMovesOrbitCenter() {
        val c = OrbitCamera(); c.setAngles(120f, 15f); c.dist = 6f
        c.focusOn(5f, 2f, -4f)
        assertEquals(120f, c.yaw, 1e-4f); assertEquals(15f, c.pitch, 1e-4f); assertEquals(6f, c.dist, 1e-4f)
        c.orbit(200f, 30f)
        assertEquals(6f, dist(c.eye(), floatArrayOf(5f, 2f, -4f)), 1e-3f)   // gira em torno do foco novo
    }

    @Test fun frameSphereFitsObjectInView() {
        val c = OrbitCamera()
        for (r in listOf(0.3f, 1f, 8f, 40f)) for (aspect in listOf(0.5f, 1f, 2f)) {
            c.frameSphere(1f, 2f, 3f, r, 45f, aspect)
            val half = Math.toRadians(22.5); val halfMin = if (aspect < 1f) Math.atan(Math.tan(half) * aspect) else half
            assertTrue("r=$r cabe", c.dist * Math.sin(halfMin) >= r || c.dist >= c.maxDist - 1e-3f)
            assertEquals(1f, c.tx, 0f); assertEquals(2f, c.ty, 0f); assertEquals(3f, c.tz, 0f)
        }
    }

    @Test fun frameBoxHandlesModelWithFarPivot() {
        val c = OrbitCamera()
        c.frameBox(100f, 0f, 100f, 102f, 2f, 101f)           // modelo longe da origem
        assertEquals(101f, c.tx, 1e-4f); assertEquals(1f, c.ty, 1e-4f); assertEquals(100.5f, c.tz, 1e-4f)
        assertTrue(c.dist > 1f && c.dist < 20f)
    }

    @Test fun presetsMatchEyeSide() {
        fun eyeFor(p: ViewPreset): FloatArray { val c = OrbitCamera(); c.focusOn(0f, 0f, 0f); c.dist = 1f; c.setAngles(p.yaw, p.pitch); return c.eye() }
        assertEquals(1f, eyeFor(ViewPreset.FRONT)[2], 1e-4f)
        assertEquals(-1f, eyeFor(ViewPreset.BACK)[2], 1e-4f)
        assertEquals(1f, eyeFor(ViewPreset.RIGHT)[0], 1e-4f)
        assertEquals(-1f, eyeFor(ViewPreset.LEFT)[0], 1e-4f)
        assertTrue(eyeFor(ViewPreset.TOP)[1] > 0.99f); assertTrue(eyeFor(ViewPreset.BOTTOM)[1] < -0.99f)
    }

    @Test fun presetLabelAndFreeOrbitAfterPreset() {
        val c = OrbitCamera(); c.setAngles(ViewPreset.BACK.yaw, ViewPreset.BACK.pitch)
        assertEquals("Trás", c.presetLabel())
        c.orbit(10f, 0f); assertNull("depois de orbitar não é mais preset", c.presetLabel())
        c.setAngles(ViewPreset.TOP.yaw, ViewPreset.TOP.pitch); assertEquals("Topo", c.presetLabel())
        c.orbit(0f, -50f); assertTrue("sai do topo livremente", c.pitch < 89f)
    }

    @Test fun smallGestureStepsGiveSmallCameraSteps() {
        // sem saltos bruscos: 1 px = 0,4°; 1 px de pan = fração pequena da distância
        val c = OrbitCamera(); c.setAngles(10f, 10f); val y0 = c.yaw
        c.orbit(1f, 0f); assertEquals(0.4f, abs(c.yaw - y0), 1e-4f)
        c.dist = 10f; c.focusOn(0f, 0f, 0f); c.pan(1f, 0f, 1000f)
        assertTrue(sqrt(c.tx * c.tx + c.ty * c.ty + c.tz * c.tz) < 0.02f)
    }

    // ---------- Gizmo ----------
    @Test fun gizmoPresetAxisFacesCameraForEveryPreset() {
        for (p in ViewPreset.values()) {
            val ax = GizmoMath.axes(p.yaw, p.pitch)
            val front = ax.maxByOrNull { it.depth }!!
            assertEquals(p.name, p, front.preset)
            assertTrue(front.depth > 0.999f)
        }
    }

    @Test fun gizmoAtDefaultFrontShowsXRightYUp() {
        val ax = GizmoMath.axes(0f, 0f)
        val x = ax.first { it.label == "X" }; val y = ax.first { it.label == "Y" }
        assertEquals(1f, x.sx, 1e-4f); assertEquals(0f, x.sy, 1e-4f)
        assertEquals(1f, y.sy, 1e-4f); assertEquals(0f, y.sx, 1e-4f)
    }

    @Test fun gizmoTapSelectsTouchedAxisAndPrefersNearest() {
        val ax = GizmoMath.axes(0f, 0f)
        val r = 100f
        assertEquals(ViewPreset.RIGHT, GizmoMath.hit(ax, 100f, 0f, r, 20f)?.preset)    // +X à direita
        assertEquals(ViewPreset.TOP, GizmoMath.hit(ax, 0f, -100f, r, 20f)?.preset)     // +Y em cima (tela: y negativo)
        assertEquals(ViewPreset.LEFT, GizmoMath.hit(ax, -100f, 0f, r, 20f)?.preset)
        assertEquals(ViewPreset.FRONT, GizmoMath.hit(ax, 0f, 0f, r, 20f)?.preset)      // +Z (frente) e -Z se sobrepõem: vence o virado p/ a câmera
        assertNull(GizmoMath.hit(ax, 70f, 70f, r, 20f))
    }

    @Test fun gizmoThenFreeOrbitFlow() {
        val c = OrbitCamera()
        val tapped = GizmoMath.hit(GizmoMath.axes(c.yaw, c.pitch), 0f, 0f, 100f, 1000f)!!.preset   // qualquer toque válido
        c.setAngles(tapped.yaw, tapped.pitch); c.orbit(-30f, 12f)
        assertTrue(c.yaw != tapped.yaw || c.pitch != tapped.pitch)
    }
}
