package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.ai.LipSync
import kotlin.math.*

/** v1.36.0 — lipsync por áudio: vogais sintéticas (trem de pulsos + ressonadores F1/F2/F3), silêncio, offset, mapeamento de morphs. */
class LipSyncTest {
    private val sr = 16000
    private val formants = mapOf(
        "a" to floatArrayOf(800f, 1300f, 2800f), "i" to floatArrayOf(300f, 2300f, 3000f), "u" to floatArrayOf(330f, 1200f, 2600f),
        "e" to floatArrayOf(520f, 1900f, 2700f), "o" to floatArrayOf(500f, 900f, 2600f)
    )

    private fun vowel(v: String, sec: Float, amp: Float = 0.3f): FloatArray {
        val n = (sec * sr).toInt(); val f = formants.getValue(v)
        val y = FloatArray(n); var src = FloatArray(n) { if (it % 133 == 0) 1f else 0f }
        for (fr in f) {
            val r = exp(-PI * 90.0 / sr).toFloat(); val c = 2f * r * cos(2.0 * PI * fr / sr).toFloat()
            var y1 = 0f; var y2 = 0f
            val o = FloatArray(n)
            for (i in 0 until n) { val s = src[i] + c * y1 - r * r * y2; o[i] = s; y2 = y1; y1 = s }
            src = o
        }
        val mx = src.maxOf { abs(it) }.coerceAtLeast(1e-6f)
        for (i in 0 until n) y[i] = src[i] / mx * amp
        return y
    }
    private fun silence(sec: Float) = FloatArray((sec * sr).toInt()) { ((it * 7919) % 13 - 6) / 6f * 0.0003f }
    private fun cat(vararg p: FloatArray): FloatArray { val o = FloatArray(p.sumOf { it.size }); var k = 0; for (a in p) { a.copyInto(o, k); k += a.size }; return o }
    private fun valueAt(ks: List<Pair<Int, Float>>?, f: Int): Float {
        if (ks == null || ks.isEmpty()) return 0f
        if (f <= ks.first().first) return if (f == ks.first().first) ks.first().second else 0f
        if (f >= ks.last().first) return if (f == ks.last().first) ks.last().second else 0f
        val i = ks.indexOfLast { it.first <= f }; val a = ks[i]; val b = ks[i + 1]
        return a.second + (b.second - a.second) * (f - a.first) / (b.first - a.first).toFloat()
    }
    private fun dominant(r: LipSync.Result, f: Int) = LipSync.VOWELS.maxByOrNull { valueAt(r.keys[it], f) }!!.takeIf { valueAt(r.keys[it], f) > 0.15f }

    @Test fun recognizesFiveVowelsInSequence() {
        val seq = listOf("a", "i", "u", "e", "o")
        val x = cat(*seq.flatMap { listOf(vowel(it, 0.5f), silence(0.2f)) }.toTypedArray())
        val r = LipSync.analyze(x, sr, LipSync.Options(fps = 30))
        for ((k, v) in seq.withIndex()) {
            val mid = ((k * 0.7f + 0.25f) * 30).toInt()
            assertEquals("vogal $v no quadro $mid", v, dominant(r, mid))
        }
    }

    @Test fun silenceStaysClosed() {
        val x = cat(silence(0.3f), vowel("a", 0.5f), silence(0.5f))
        val r = LipSync.analyze(x, sr, LipSync.Options())
        assertNull(dominant(r, 2))
        assertEquals("a", dominant(r, 0.55f.times(30).toInt()))
        assertNull(dominant(r, (0.3f + 0.5f + 0.35f).times(30).toInt()))
    }

    @Test fun pureSilenceProducesNoKeys() {
        val r = LipSync.analyze(silence(1f), sr, LipSync.Options())
        assertTrue(r.isEmpty)
    }

    @Test fun quieterVowelOpensLess() {
        val x = cat(vowel("a", 0.4f, 0.4f), silence(0.1f), vowel("a", 0.4f, 0.06f))
        val r = LipSync.analyze(x, sr, LipSync.Options(sensitivity = 0.9f))
        assertTrue(valueAt(r.keys["a"], 6) > valueAt(r.keys["a"], 21) + 0.1f)
    }

    @Test fun intensityScalesButNeverPassesOne() {
        val x = vowel("a", 0.5f)
        val lo = LipSync.analyze(x, sr, LipSync.Options(intensity = 0.5f)); val hi = LipSync.analyze(x, sr, LipSync.Options(intensity = 1.5f))
        assertTrue(valueAt(lo.keys["a"], 7) < valueAt(hi.keys["a"], 7))
        assertTrue(hi.keys.values.flatten().all { it.second in 0f..1f })
    }

    @Test fun offsetShiftsKeysLikeAudioPanel() {
        val x = cat(silence(0.2f), vowel("a", 0.5f))
        val a = LipSync.analyze(x, sr, LipSync.Options(offsetMs = 0)); val b = LipSync.analyze(x, sr, LipSync.Options(offsetMs = 1000))
        assertEquals(dominant(a, 12), dominant(b, 42))              // +1 s = 30 quadros depois
        assertEquals(30, b.from)
    }

    @Test fun keysAreSparseAndOrdered() {
        val x = vowel("a", 2f)
        val r = LipSync.analyze(x, sr, LipSync.Options())
        val ks = r.keys.getValue("a")
        assertTrue("esparso (${ks.size} de ${r.total})", ks.size < r.total / 2)
        assertEquals(ks.map { it.first }, ks.map { it.first }.sorted())
    }

    @Test fun toMonoDownmixesAndDecimates() {
        val n = 48000
        val pcm = ByteArray(n * 4)
        for (i in 0 until n) { val s = (sin(2 * PI * 440 * i / 48000) * 12000).toInt().toShort(); for (c in 0..1) { pcm[i * 4 + c * 2] = (s.toInt() and 0xFF).toByte(); pcm[i * 4 + c * 2 + 1] = (s.toInt() shr 8).toByte() } }
        val (m, r) = LipSync.toMono(pcm, 48000, 2)
        assertEquals(16000, r); assertTrue(abs(m.size - 16000) <= 2); assertTrue(m.maxOf { abs(it) } in 0.2f..0.5f)
    }

    @Test fun morphNameMatching() {
        val m = listOf("あ" to "a", "い" to "i", "う" to "u", "えええ" to "E", "Blink" to "blink", "おー" to "")
        val f = LipSync.findMorphs(m)
        assertEquals("あ", f["a"]); assertEquals("い", f["i"]); assertEquals("う", f["u"]); assertEquals("えええ", f["e"]); assertEquals("おー", f["o"])
        assertTrue(LipSync.findMorphs(listOf("Smile" to "smile", "chair" to "")).isEmpty())
        assertEquals(mapOf("あ" to listOf(3 to 1f)), LipSync.toMorphKeys(LipSync.Result(mapOf("a" to listOf(3 to 1f), "i" to listOf(1 to 1f)), 0, 3, 1, 1), mapOf("a" to "あ")))
    }
}
