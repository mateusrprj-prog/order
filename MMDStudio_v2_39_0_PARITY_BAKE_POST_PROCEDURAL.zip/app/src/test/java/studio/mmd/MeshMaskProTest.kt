package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.MeshMaskFalloff
import studio.mmd.edit.MeshMaskPaintSession
import studio.mmd.edit.MeshMaskPresetCodec
import studio.mmd.mmd.PmxModel

class MeshMaskProTest {
    private fun model(): PmxModel = PmxModel(
        "mask-pro", 2.1f,
        floatArrayOf(0f,0f,0f, .2f,0f,0f, 0f,.2f,0f,
            0f,0f,.02f, .2f,0f,.02f, 0f,.2f,.02f),
        FloatArray(18), FloatArray(12), IntArray(24) { -1 }, FloatArray(24),
        intArrayOf(0,1,2, 3,4,5), emptyList(), emptyList(), emptyList(), emptyList()
    )

    @Test fun geodesicBrushStaysOnConnectedSurfaceAcrossNearbyLayers() {
        val source = model()
        val session = MeshMaskPaintSession(source)
        session.paintStroke(
            listOf(floatArrayOf(0f,0f,0f)), radius = .12f,
            surfaceConstrained = true, falloff = MeshMaskFalloff.LINEAR
        )
        val mask = session.valuesCopy()
        assertTrue(mask[0] > .9f)
        assertEquals(0f, mask[3], 0f)
        assertEquals(0f, mask[4], 0f)
        assertEquals(0f, mask[5], 0f)
    }

    @Test fun spatialBrushSupportsConstantFalloffAndBoundedHistory() {
        val source = model()
        val session = MeshMaskPaintSession(source, historyLimit = 2)
        session.paintStroke(listOf(floatArrayOf(0f,0f,0f)), radius = .3f,
            falloff = MeshMaskFalloff.CONSTANT)
        assertTrue(session.valuesCopy()[0] > .99f)
        session.fill(.2f); session.fill(.4f); session.fill(.6f)
        assertTrue(session.undo()); assertTrue(session.undo()); assertFalse(session.undo())
        assertTrue(session.redo()); assertTrue(session.redo()); assertFalse(session.redo())
    }

    @Test fun presetRoundTripValidatesTopologyAndChecksum() {
        val source = model()
        val values = floatArrayOf(1f, .8f, .5f, 0f, .2f, .3f)
        val bytes = MeshMaskPresetCodec.encode(source, values, "saia frente")
        val decoded = MeshMaskPresetCodec.decode(bytes, source)
        assertEquals("saia frente", decoded.name)
        assertArrayEquals(values, decoded.values, 0f)

        val longUnicodeName = "Saia_frente_表情✨".repeat(40)
        val unicodeDecoded = MeshMaskPresetCodec.decode(MeshMaskPresetCodec.encode(source, values, longUnicodeName), source)
        assertFalse(unicodeDecoded.name.contains('\uFFFD'))
        assertTrue(unicodeDecoded.name.toByteArray(Charsets.UTF_8).size <= 240)

        val corrupted = bytes.copyOf(); corrupted[corrupted.lastIndex - 5] = (corrupted[corrupted.lastIndex - 5].toInt() xor 0x40).toByte()
        assertThrows(IllegalArgumentException::class.java) { MeshMaskPresetCodec.decode(corrupted, source) }

        val changedMesh = PmxModel(source.name, source.version, source.positions.copyOf().also { it[0] += .01f },
            source.normals, source.uvs, source.boneIndices, source.boneWeights, source.indices,
            source.textures, source.materials, source.bones, source.morphs)
        assertThrows(IllegalArgumentException::class.java) { MeshMaskPresetCodec.decode(bytes, changedMesh) }
    }
    @Test fun geodesicStrokeIncludesTheEndOfVeryLongMultiSegmentPath() {
        val source = PmxModel(
            "long-stroke", 2.1f,
            floatArrayOf(0f,0f,0f, 200f,0f,0f),
            FloatArray(6), FloatArray(4), IntArray(8) { -1 }, FloatArray(8),
            intArrayOf(0,1,1), emptyList(), emptyList(), emptyList(), emptyList()
        )
        val session = MeshMaskPaintSession(source)
        val path = (0..20).map { i -> floatArrayOf(i * 10f, 0f, 0f) }
        session.paintStroke(path, radius = .01f, surfaceConstrained = true, falloff = MeshMaskFalloff.LINEAR)
        val result = session.valuesCopy()
        assertTrue(result[0] > .9f)
        assertTrue(result[1] > .9f)
    }

    @Test fun historyUsesCombinedSnapshotBudgetAndUndoRedoRemainUsable() {
        val session = MeshMaskPaintSession(model(), historyLimit = 64, historyBudgetBytes = 48L)
        assertEquals(2, session.historyCapacity)
        repeat(6) { session.fill((it + 1) / 7f) }
        assertTrue(session.historyEntries <= session.historyCapacity)
        assertTrue(session.undo())
        assertTrue(session.undo())
        assertFalse(session.undo())
        assertTrue(session.redo())
        assertTrue(session.redo())
        assertFalse(session.redo())
        assertTrue(session.historyEntries <= session.historyCapacity)
    }

    @Test fun spatialBrushSubdividesHugeDiagonalQueriesWithoutLosingSurfaceCandidates() {
        val source = PmxModel(
            "diagonal-grid", 2.1f,
            floatArrayOf(0f,0f,0f, 50f,50f,50f, 100f,100f,100f),
            FloatArray(9), FloatArray(6), IntArray(12) { -1 }, FloatArray(12),
            intArrayOf(0,1,2), emptyList(), emptyList(), emptyList(), emptyList()
        )
        val session = MeshMaskPaintSession(source)
        session.paintStroke(listOf(floatArrayOf(0f,0f,0f), floatArrayOf(100f,100f,100f)), radius = .1f)
        assertTrue(session.valuesCopy().all { it > .9f })
    }

}
