package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class OfficialParityV37Test {
    private fun track(frames: IntArray, x: FloatArray): VmdTrack {
        val n = frames.size
        return VmdTrack(frames, FloatArray(n * 7) { if (it % 7 == 0) x[it / 7] else if (it % 7 == 6) 1f else 0f }, ByteArray(n * 16) { if (it % 16 < 8) 20 else 107 })
    }

    @Test fun accessorySamplingStepAndLinear() {
        val t = AccessoryTrack("stage", listOf(
            AccessoryKey(10, pos = floatArrayOf(0f, 0f, 0f), opacity = 0f, parentModel = -1),
            AccessoryKey(20, pos = floatArrayOf(10f, 0f, 0f), scale = 2f, opacity = 1f, parentModel = 0, parentBone = 5, visible = false)
        ))
        assertEquals(0f, t.sample(0f)!!.pos[0], 0f)
        val mid = t.sample(15f)!!
        assertEquals(5f, mid.pos[0], 1e-4f); assertEquals(1.5f, mid.scale, 1e-4f); assertEquals(0.5f, mid.opacity, 1e-4f)
        assertTrue(mid.visible); assertEquals(-1, mid.parentModel)          // degrau: vale a key anterior
        val end = t.sample(25f)!!
        assertFalse(end.visible); assertEquals(5, end.parentBone)
        assertNull(AccessoryTrack("x", emptyList()).sample(3f))
        assertNull(t.sample(Float.NaN))
    }

    @Test fun accessoryEditAndCodec() {
        var t = AccessoryTrack("a b", listOf(AccessoryKey(0), AccessoryKey(10, pos = floatArrayOf(1f, 2f, 3f), rotDeg = floatArrayOf(10f, 20f, 30f), curve = intArrayOf(64, 0, 64, 127))))
        t = t.insertFrames(5, 10)
        assertEquals(20, t.keys.last().frame)
        t = t.deleteFrames(5, 10)
        assertEquals(10, t.keys.last().frame)
        val d = AccessoryTrack.decode(AccessoryTrack.encode(t))!!
        assertEquals(2, d.keys.size); assertEquals("a b", d.id)
        assertEquals(30f, d.keys[1].rotDeg[2], 0f); assertEquals(64, d.keys[1].curve[0])
        assertNull(AccessoryTrack.decode(""))
        assertEquals(1, AccessoryTrack.decode("x\n0\tNaN\t0\t0\t0\t0\t0\t1\t1\t1\t1\t-1\t-1\t20\t20\t107\t107\n5\t0\t0\t0\t0\t0\t0\t1\t1\t1\t1\t-1\t-1\t20\t20\t107\t107")!!.keys.size)
        assertEquals(2, AccessoryTrack("x", listOf(AccessoryKey(1), AccessoryKey(1), AccessoryKey(2))).keys.size)
    }

    @Test fun accessoryMatrixAndAttach() {
        val s = AccessoryTrack("a", listOf(AccessoryKey(0, pos = floatArrayOf(1f, 2f, 3f), scale = 2f, rotDeg = floatArrayOf(0f, 90f, 0f)))).sample(0f)!!
        val m = AccessoryTrack.matrix(s)
        assertEquals(1f, m[12], 1e-5f); assertEquals(3f, m[14], 1e-5f)
        // eixo X local (coluna 0) com Ry 90 e escala 2 → (0,0,-2)
        assertEquals(0f, m[0], 1e-5f); assertEquals(-2f, m[2], 1e-5f)
        val tr = AccessoryTrack("a", listOf(AccessoryKey(0), AccessoryKey(5, parentModel = 0, parentBone = 3), AccessoryKey(9, parentModel = 0, parentBone = 3), AccessoryKey(12, parentModel = 1, parentBone = 0))).toAttachTrack(2)
        assertEquals(3, tr.keys.size)
    }

    @Test fun fade() {
        val t = AccessoryTrack("a", listOf(AccessoryKey(0), AccessoryKey(100))).withFade(10, 10)
        assertEquals(0f, t.sample(0f)!!.opacity, 1e-5f)
        assertEquals(1f, t.sample(50f)!!.opacity, 1e-5f)
        assertEquals(0f, t.sample(100f)!!.opacity, 1e-5f)
        assertEquals(0.5f, t.sample(5f)!!.opacity, 1e-3f)
    }

    @Test fun mergeWithOffsetFilterAndConflict() {
        val base = VmdMotion("m", mapOf("a" to track(intArrayOf(0, 10), floatArrayOf(0f, 1f))), mapOf("あ" to VmdMorphTrack(intArrayOf(0), floatArrayOf(0.5f))), 10)
        val over = VmdMotion("o", mapOf("a" to track(intArrayOf(0, 5), floatArrayOf(9f, 8f)), "zz" to track(intArrayOf(0), floatArrayOf(1f))), mapOf("あ" to VmdMorphTrack(intArrayOf(0), floatArrayOf(1f))), 5)
        val r = MotionMerge.merge(base, over, MotionMerge.Options(offsetFrames = 10, knownBones = setOf("a"), knownMorphs = setOf("あ")))
        assertEquals(1, r.skipped)
        val a = r.motion.bones.getValue("a")
        assertArrayEquals(intArrayOf(0, 10, 15), a.frames)
        assertEquals(9f, a.v[7], 0f)                         // overlay vence no frame 10
        val b = MotionMerge.merge(base, over, MotionMerge.Options(offsetFrames = 10, conflict = MotionMerge.Conflict.BASE_WINS)).motion.bones.getValue("a")
        assertEquals(1f, b.v[7], 0f)
        val rep = MotionMerge.merge(base, over, MotionMerge.Options(conflict = MotionMerge.Conflict.REPLACE_TRACK, boneFilter = setOf("a"))).motion
        assertArrayEquals(intArrayOf(0, 5), rep.bones.getValue("a").frames)
        assertFalse(rep.bones.containsKey("zz"))
        val cut = MotionMerge.merge(base, over, MotionMerge.Options(from = 3, to = 9, boneFilter = setOf("a"))).motion.bones.getValue("a")
        assertArrayEquals(intArrayOf(0, 5, 10), cut.frames)
        val neg = MotionMerge.merge(base, over, MotionMerge.Options(offsetFrames = -3, boneFilter = setOf("a"))).motion.bones.getValue("a")
        assertTrue(neg.frames.all { it >= 0 })
        val ren = MotionMerge.merge(base, over, MotionMerge.Options(renames = mapOf("zz" to "new"))).motion
        assertTrue(ren.bones.containsKey("new"))
    }

    @Test fun cameraCutIsStep() {
        val c0 = CameraMotionTools.put(null, 0, CameraPose(30f, 0f, 10f, 0f))
        val c1 = CameraMotionTools.put(c0, 60, CameraPose(10f, 0f, 10f, 0f))
        val cut = CameraShots.cut(c1, 30, CameraShots.pose(CameraShots.Shot.CLOSE_UP, 20f))
        assertTrue(cut.frames.contains(29) && cut.frames.contains(30))
        val out = FloatArray(8)
        cut.evaluate(29f, out); val before = out[0]
        cut.evaluate(30f, out); val after = out[0]
        assertEquals(CameraShots.pose(CameraShots.Shot.CLOSE_UP, 20f).distance, after, 1e-3f)
        assertTrue("salto seco entre 29 e 30", Math.abs(before - after) > 10f)
        assertEquals(1, CameraShots.cut(null, 0, CameraPose()).frames.size)
    }

    @Test fun shotsAndFraming() {
        val close = CameraShots.pose(CameraShots.Shot.CLOSE_UP, 20f)
        val wide = CameraShots.pose(CameraShots.Shot.WIDE, 20f)
        assertTrue(close.distance < wide.distance && close.y > wide.y)
        assertTrue(CameraShots.pose(CameraShots.Shot.MEDIUM, Float.NaN).distance > 0f)
        assertEquals(20f / 0.8f / 2f / Math.tan(Math.toRadians(22.5)).toFloat(), CameraShots.distanceToFrame(20f, 45f), 1e-3f)
        val seq = CameraShots.cutSequence(null, listOf(CameraShots.Shot.WIDE, CameraShots.Shot.CLOSE_UP), 0, 90, 30, 20f)!!
        assertTrue(seq.frames.contains(60) && seq.frames.contains(90))
        val pan = CameraShots.pan(seq, 0, 10, 5f, 0f)!!
        assertNotNull(pan)
    }
}
