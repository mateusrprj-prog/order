package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class PmxImpulseMorphsTest {
    private fun raw(indexSize: Int = 1, body: Int = 0, local: Int = 1, v: FloatArray = floatArrayOf(1f,2f,3f), r: FloatArray = floatArrayOf(4f,5f,6f)): ByteArray {
        val b = ByteBuffer.allocate(indexSize + 25).order(ByteOrder.LITTLE_ENDIAN)
        when (indexSize) { 1 -> b.put(body.toByte()); 2 -> b.putShort(body.toShort()); else -> b.putInt(body) }
        b.put(local.toByte()); v.forEach { b.putFloat(it) }; r.forEach { b.putFloat(it) }
        return b.array()
    }
    private fun morph(bytes: ByteArray, count: Int = 1) = PmxMorph("impulse", "", 0, 10, raw = bytes, count = count)

    @Test fun decodesAllVectorComponentsAndLocalFlag() {
        val d = PmxImpulseMorphs.decode(morph(raw()), 1)
        assertEquals(1, d.entries.size); assertEquals(26, d.elementSize)
        val e = d.entries.single(); assertEquals(0, e.rigidBody); assertTrue(e.local)
        assertArrayEquals(floatArrayOf(1f,2f,3f), e.velocity, 0.0001f)
        assertArrayEquals(floatArrayOf(4f,5f,6f), e.torque, 0.0001f)
    }
    @Test fun supportsOneTwoAndFourByteSignedIndices() {
        for (size in intArrayOf(1,2,4)) {
            val d = PmxImpulseMorphs.decode(morph(raw(size)), 1)
            assertEquals(1, d.entries.size)
        }
    }
    @Test fun rejectsInvalidBodyIndex() {
        val d = PmxImpulseMorphs.decode(morph(raw(body = -1)), 1)
        assertTrue(d.entries.isEmpty()); assertEquals(1, d.warnings.size)
    }
    @Test fun rejectsInvalidLocalFlag() {
        val d = PmxImpulseMorphs.decode(morph(raw(local = 2)), 1)
        assertTrue(d.entries.isEmpty()); assertEquals(1, d.warnings.size)
    }
    @Test fun rejectsNonFiniteVectors() {
        val d = PmxImpulseMorphs.decode(morph(raw(v = floatArrayOf(Float.NaN,0f,0f))), 1)
        assertTrue(d.entries.isEmpty()); assertEquals(1, d.warnings.size)
    }
    @Test fun malformedByteCountIsNotPartiallyRead() {
        val d = PmxImpulseMorphs.decode(morph(byteArrayOf(1,2,3)), 1)
        assertTrue(d.entries.isEmpty()); assertEquals(1, d.warnings.size)
    }
    @Test fun dispatcherUsesResolvedWeightAndDoesNotFireZeroWeight() {
        val model = PmxModel("test", 2.1f, FloatArray(0), FloatArray(0), FloatArray(0), IntArray(0), FloatArray(0), IntArray(0), emptyList(), emptyList(), emptyList(), listOf(morph(raw())))
            .let { PmxModel(it.name,it.version,it.positions,it.normals,it.uvs,it.boneIndices,it.boneWeights,it.indices,it.textures,it.materials,it.bones,it.morphs, rigidBodies = listOf(PmxRigid("body","",-1,0,0,1f,0f,0f,1))) }
        val dispatcher = PmxImpulseMorphDispatcher(model)
        var received = 0f
        val sink = PmxImpulseSink { entry, weight -> received = entry.velocity[0] * weight; true }
        assertEquals(0, dispatcher.dispatchLeaf(0, 0f, sink)); assertEquals(0f, received, 0.0001f)
        assertEquals(1, dispatcher.dispatchLeaf(0, 0.5f, sink)); assertEquals(0.5f, received, 0.0001f)
    }
}
