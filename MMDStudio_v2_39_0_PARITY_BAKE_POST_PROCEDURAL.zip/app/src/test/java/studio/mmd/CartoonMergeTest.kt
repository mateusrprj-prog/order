package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.cartoon.*
import studio.mmd.edit.BKey
import studio.mmd.edit.MKey
import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdParser
import studio.mmd.mmd.VmdTrack

/** v1.29.2 — Cartoon em personagem extra: mesclar no movimento atual e gravar como VMD (lógica pura). */
class CartoonMergeTest {
    private val ID = byteArrayOf(20, 20, 107, 107, 20, 20, 107, 107, 20, 20, 107, 107, 20, 20, 107, 107)
    private fun bk(f: Int, y: Float) = BKey(f, floatArrayOf(0f, y, 0f, 0f, 0f, 0f, 1f), ID.copyOf())
    private fun built(from: Int, to: Int, vararg fy: Pair<Int, Float>) =
        Built(mapOf("センター" to fy.map { bk(it.first, it.second) }), emptyMap(), from, to)
    private fun oldMotion(): VmdMotion {
        val fr = intArrayOf(0, 10, 20, 30)
        val v = FloatArray(fr.size * 7); for (i in fr.indices) { v[i * 7 + 1] = 100f + i; v[i * 7 + 6] = 1f }
        val ip = ByteArray(fr.size * 16); for (i in fr.indices) ID.copyInto(ip, i * 16)
        return VmdMotion("m", mapOf("センター" to VmdTrack(fr, v, ip), "首" to VmdTrack(intArrayOf(5), floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f), ID.copyOf())),
            mapOf("まばたき" to VmdMorphTrack(intArrayOf(0, 12), floatArrayOf(0f, 1f))), 30)
    }

    @Test fun nullOldMakesMotionFromBuilt() {
        val r = CartoonMerge.merge(null, built(5, 15, 5 to 0f, 15 to 1f), null, null)
        assertEquals(2, r.boneKeys)
        assertEquals(15, r.motion.maxFrame)
        assertEquals(listOf(5, 15), r.motion.bones.getValue("センター").frames.toList())
    }
    @Test fun replacesOnlyTheRangeAndKeepsTheRest() {
        val r = CartoonMerge.merge(oldMotion(), built(8, 22, 8 to 0.5f, 22 to 0.7f), null, null)
        val t = r.motion.bones.getValue("センター")
        assertEquals(listOf(0, 8, 22, 30), t.frames.toList())       // keys 10 e 20 (dentro de 8..22) foram substituídas
        assertEquals(100f, t.v[1], 0f)                                // key 0 intacta
        assertEquals(0.5f, t.v[1 * 7 + 1], 0f)
        assertEquals(103f, t.v[3 * 7 + 1], 0f)                        // key 30 intacta
        assertTrue(r.motion.bones.containsKey("首"))                  // outra trilha intacta
        assertEquals(30, r.motion.maxFrame)
    }
    @Test fun extendsMaxFrame() {
        val r = CartoonMerge.merge(oldMotion(), built(40, 60, 40 to 0f, 60 to 1f), null, null)
        assertEquals(60, r.motion.maxFrame)
        assertEquals(listOf(0, 10, 20, 30, 40, 60), r.motion.bones.getValue("センター").frames.toList())
    }
    @Test fun ignoresBonesMissingFromModel() {
        val r = CartoonMerge.merge(oldMotion(), built(0, 10, 0 to 0f, 10 to 1f), setOf("首"), null)
        assertEquals(0, r.written)
        assertEquals(30, r.motion.maxFrame)
        assertEquals(listOf(0, 10, 20, 30), r.motion.bones.getValue("センター").frames.toList())
    }
    @Test fun morphsMergeAndFilter() {
        val b = Built(emptyMap(), mapOf("まばたき" to listOf(MKey(10, 0.5f), MKey(14, 0f)), "なし" to listOf(MKey(1, 1f))), 10, 14)
        val r = CartoonMerge.merge(oldMotion(), b, null, setOf("まばたき"))
        assertEquals(2, r.morphKeys)
        assertEquals(listOf(0, 10, 14), r.motion.morphs.getValue("まばたき").frames.toList())   // key 12 estava em 10..14: substituída
        assertFalse(r.motion.morphs.containsKey("なし"))
    }
    @Test fun doesNotMutateOld() {
        val o = oldMotion()
        CartoonMerge.merge(o, built(0, 30, 0 to 9f, 30 to 9f), null, null)
        assertEquals(listOf(0, 10, 20, 30), o.bones.getValue("センター").frames.toList())
    }
    @Test fun vmdRoundTrip() {
        val r = CartoonMerge.merge(oldMotion(), built(8, 22, 8 to 0.5f, 22 to 0.7f), null, null)
        val bytes = CartoonMerge.toVmdBytes(r.motion, "personagem")
        val back = VmdParser.parse(bytes)
        assertEquals(r.motion.maxFrame, back.maxFrame)
        val t = back.bones.getValue("センター")
        assertEquals(listOf(0, 8, 22, 30), t.frames.toList())
        assertEquals(0.5f, t.v[1 * 7 + 1], 1e-6f)
        assertArrayEquals(ID, t.ip.copyOfRange(16, 32))
        assertEquals(listOf(0, 12), back.morphs.getValue("まばたき").frames.toList())
        assertTrue(back.bones.containsKey("首"))
    }
}
