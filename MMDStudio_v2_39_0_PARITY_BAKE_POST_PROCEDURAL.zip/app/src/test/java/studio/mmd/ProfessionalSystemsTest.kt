package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.WeightPaintSession
import studio.mmd.edit.WeightPaintMode
import studio.mmd.mmd.*
import studio.mmd.mocap.MotionCleanup
import studio.mmd.rig.ClothSphere
import studio.mmd.rig.ClothXpbd
import studio.mmd.rig.ClothBakeCache
import studio.mmd.rig.ClothCacheCodec
import java.io.File

class ProfessionalSystemsTest {
    private fun camera(frames: IntArray = intArrayOf(0, 20)): VmdCamera {
        val dist = floatArrayOf(30f, 15f)
        val pos = floatArrayOf(0f, 5f, 0f, 10f, 15f, 2f)
        val rot = FloatArray(6)
        val fov = floatArrayOf(45f, 60f)
        val ip = ByteArray(frames.size * 24) { 20 }
        for (i in frames.indices) for (c in 0 until 6) {
            val o = i * 24 + c * 4
            ip[o] = 20; ip[o + 1] = 107; ip[o + 2] = 20; ip[o + 3] = 107
        }
        return VmdCamera(frames, dist, pos, rot, fov, ip)
    }

    @Test fun cameraKeysCanBeAddedRemovedAndRoundTrippedAsVmd() {
        val c = CameraMotionTools.put(camera(), 10, CameraPose(distance = 22f, y = 12f, fov = 50f))
        assertArrayEquals(intArrayOf(0, 10, 20), c.frames)
        assertEquals(22f, CameraMotionTools.sample(c, 10f).distance, 0.001f)
        val bytes = CameraMotionTools.toVmd(c)
        val parsed = VmdParser.parseCamera(bytes)!!
        assertArrayEquals(c.frames, parsed.frames)
        assertEquals(12f, CameraMotionTools.sample(parsed, 10f).y, 0.001f)
        assertEquals(0, VmdParser.parse(bytes).maxFrame)
        assertNull(CameraMotionTools.remove(CameraMotionTools.remove(CameraMotionTools.remove(c, 0), 10), 20))
    }

    @Test fun cameraReverseAndLinearizeKeepSortedFrames() {
        val c = CameraMotionTools.reverse(camera(), 0, 20)!!
        assertArrayEquals(intArrayOf(0, 20), c.frames)
        assertEquals(15f, CameraMotionTools.sample(c, 0f).distance, 0.001f)
        val lin = CameraMotionTools.setLinear(c, 0, 20)!!
        assertEquals(20, lin.ip[0].toInt())
        assertEquals(20, lin.ip[1].toInt())
        assertEquals(107, lin.ip[3].toInt())
    }

    private fun model(): PmxModel {
        val bones = listOf(
            PmxBone("左腕", "Left Arm", 0f, 0f, 0f, -1, 0, 0, -1, -1, 0f, null),
            PmxBone("右腕", "Right Arm", 0f, 0f, 0f, -1, 0, 0, -1, -1, 0f, null)
        )
        return PmxModel("weights", 2.1f,
            floatArrayOf(1f, 1f, 0f, -1f, 1f, 0f, 1f, 0f, 0f, -1f, 0f, 0f),
            FloatArray(12), FloatArray(8),
            intArrayOf(0, -1, -1, -1, 0, -1, -1, -1, 0, -1, -1, -1, 0, -1, -1, -1),
            floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f),
            intArrayOf(0, 1, 2, 0, 2, 3), emptyList(), emptyList(), bones, emptyList())
    }

    @Test fun weightPaintingNormalizesAndSupportsUndoRedo() {
        val session = WeightPaintSession(model())
        val report = session.paintVertices(intArrayOf(0), 1, 0.75f, 1f, WeightPaintMode.REPLACE)
        assertEquals(1, report.changed)
        val result = session.buildModel()
        assertEquals(1, result.boneIndices[0])
        assertEquals(0.75f, result.boneWeights[0], 0.0001f)
        assertEquals(1, result.weightTypes[0].toInt())
        assertTrue(session.undo())
        assertEquals(0, session.buildModel().boneIndices[0])
        assertTrue(session.redo())
        assertEquals(1, session.buildModel().boneIndices[0])
    }

    @Test fun mirrorWeightsUsesPairedLeftAndRightBones() {
        val s = WeightPaintSession(model())
        val report = s.mirrorX(tolerance = 0.01f, sourcePositiveX = true)
        assertEquals(2, report.changed)
        val result = s.buildModel()
        assertEquals(1, result.boneIndices[4])
        assertEquals(1f, result.boneWeights[4], 0.001f)
    }

    @Test fun weightSphereBrushRespectsRadiusAndPruning() {
        val s = WeightPaintSession(model())
        val report = s.paintSphere(1f, 1f, 0f, 0.25f, 1, 1f)
        assertEquals(1, report.changed)
        assertEquals(1, s.buildModel().boneIndices[0])
        val pruned = s.prune(0.05f, 2)
        assertTrue(pruned.changed >= 0)
    }

    @Test fun clothXpbdBuildsStretchAndBendConstraintsAndKeepsPins() {
        val p = floatArrayOf(0f, 1f, 0f, 1f, 1f, 0f, 1f, 0.2f, 0f, 0f, 0.2f, 0f)
        val cloth = ClothXpbd.fromMesh(p, intArrayOf(0, 1, 2, 0, 2, 3), stretchCompliance = 0f, bendCompliance = 0.0001f)
        assertEquals(4, cloth.stats.particles)
        assertTrue(cloth.stats.stretchConstraints >= 5)
        assertTrue(cloth.stats.bendConstraints >= 1)
        cloth.pin(0)
        repeat(20) { cloth.step(1f / 30f, iterations = 12, groundY = 0f) }
        val pin = cloth.position(0)
        assertArrayEquals(floatArrayOf(0f, 1f, 0f), pin, 0.0001f)
        for (v in 0 until cloth.vertexCount) {
            val pos = cloth.position(v)
            assertTrue(pos.all { it.isFinite() })
            assertTrue(pos[1] >= -0.0001f)
        }
    }

    @Test fun clothSphereCollisionProjectsParticlesOutsideCollider() {
        val cloth = ClothXpbd.fromMesh(floatArrayOf(0f, 1f, 0f, 0.1f, 1f, 0f, 0f, 1.1f, 0f), intArrayOf(0, 1, 2))
        cloth.setColliders(spheres = listOf(ClothSphere(0f, 1f, 0f, 0.5f)))
        repeat(3) { cloth.step(1f / 60f, gravityY = 0f, iterations = 8, groundY = null) }
        val p = cloth.position(0)
        val distance = kotlin.math.sqrt(p[0] * p[0] + (p[1] - 1f) * (p[1] - 1f) + p[2] * p[2])
        assertTrue(distance >= 0.49f)
    }

    @Test fun clothCacheRoundTripsAndDetectsCorruption() {
        val original = ClothBakeCache(2, 30, listOf(
            floatArrayOf(0f, 1f, 2f, 3f, 4f, 5f),
            floatArrayOf(0.1f, 1.1f, 2.1f, 3.1f, 4.1f, 5.1f)
        ))
        val bytes = ClothCacheCodec.encode(original)
        val decoded = ClothCacheCodec.decode(bytes)
        assertEquals(2, decoded.vertexCount)
        assertEquals(30, decoded.fps)
        assertArrayEquals(original.frames[1], decoded.frames[1], 0f)
        val corrupt = bytes.copyOf(); corrupt[corrupt.lastIndex - 5] = (corrupt[corrupt.lastIndex - 5].toInt() xor 0x40).toByte()
        var rejected = false
        try { ClothCacheCodec.decode(corrupt) } catch (_: IllegalArgumentException) { rejected = true }
        assertTrue(rejected)
    }

    @Test fun clothCacheAtomicWriteRecoversFromBackup() {
        val dir = File(System.getProperty("java.io.tmpdir"), "mmd-cloth-cache-test-${System.nanoTime()}").apply { mkdirs() }
        val file = File(dir, "cloth.clothcache")
        try {
            val first = ClothBakeCache(1, 24, listOf(floatArrayOf(1f, 2f, 3f)))
            val second = ClothBakeCache(1, 24, listOf(floatArrayOf(4f, 5f, 6f)))
            ClothCacheCodec.writeAtomic(file, first)
            ClothCacheCodec.writeAtomic(file, second)
            assertArrayEquals(floatArrayOf(4f, 5f, 6f), ClothCacheCodec.readWithBackup(file).frames[0], 0f)
            file.writeBytes(byteArrayOf(1, 2, 3))
            assertArrayEquals(floatArrayOf(1f, 2f, 3f), ClothCacheCodec.readWithBackup(file).frames[0], 0f)
        } finally { dir.deleteRecursively() }
    }

    @Test fun clothSphereCenterFallbackRemainsFinite() {
        val cloth = ClothXpbd.fromMesh(floatArrayOf(0f, 0f, 0f, 0.1f, 0f, 0f, 0f, 0.1f, 0f), intArrayOf(0, 1, 2))
        cloth.setColliders(spheres = listOf(ClothSphere(0f, 0f, 0f, 0.5f)))
        val result = cloth.step(1f / 60f, gravityY = 0f, iterations = 1, groundY = null)
        assertTrue(result.all { it.isFinite() })
        assertTrue(kotlin.math.sqrt(result[0] * result[0] + result[1] * result[1] + result[2] * result[2]) >= 0.49f)
    }

    @Test fun cameraSmoothingRespectsUnevenFrameSpacingAndAngleWrap() {
        val frames = intArrayOf(0, 2, 10)
        val camera = VmdCamera(
            frames, floatArrayOf(10f, 100f, 30f), FloatArray(9),
            floatArrayOf(Math.toRadians(179.0).toFloat(), 0f, 0f, 0f, 0f, 0f, Math.toRadians(-179.0).toFloat(), 0f, 0f),
            floatArrayOf(45f, 90f, 45f), ByteArray(72) { 20 }
        )
        val smooth = CameraMotionTools.smooth(camera, 0, 10, strength = 1f, passes = 1)!!
        assertEquals(14f, smooth.dist[1], 0.001f) // 20% entre os quadros 0 e 10
        assertTrue(kotlin.math.abs(kotlin.math.abs(smooth.rot[3]) - Math.PI.toFloat()) < 0.03f)
    }

    @Test fun weightPaintCapsuleStrokeAndInfluenceQueriesWork() {
        val s = WeightPaintSession(model())
        val result = s.paintCapsule(0f, 1f, 0f, 1f, 1f, 0f, 0.2f, 1, 1f)
        assertTrue(result.changed >= 1)
        assertTrue(s.influenceAt(0, 1) > 0f)
        assertTrue(s.verticesInfluencedBy(1).isNotEmpty())
    }

    @Test fun clothSelfCollisionSeparatesOverlappingDisconnectedPanels() {
        val p = floatArrayOf(
            0f, 1f, 0f, 1f, 1f, 0f, 0f, 1f, 1f,
            0f, 1f, 0f, 1f, 1f, 0f, 0f, 1f, 1f
        )
        val cloth = ClothXpbd.fromMesh(p, intArrayOf(0, 1, 2, 3, 4, 5))
        repeat(3) { cloth.step(1f / 60f, gravityY = 0f, substeps = 1, iterations = 4, groundY = null, selfCollision = true) }
        val a = cloth.position(0); val b = cloth.position(3)
        val d = kotlin.math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
        assertTrue(d >= 0.002f)
        assertTrue((0 until cloth.vertexCount).all { cloth.position(it).all(Float::isFinite) })
    }

    @Test fun clothMassAndStreamingBakeAreAvailable() {
        val cloth = ClothXpbd.fromMesh(floatArrayOf(0f, 1f, 0f, 1f, 1f, 0f, 0f, 1f, 1f), intArrayOf(0, 1, 2))
        cloth.setMass(1, 2f)
        cloth.pin(0)
        var frames = 0
        val last = cloth.bakeStreaming(5, 30) { frame, positions ->
            assertEquals(frames, frame)
            assertEquals(9, positions.size)
            frames++
        }
        assertEquals(5, frames)
        assertEquals(9, last.size)
        assertTrue(cloth.unpin(0))
    }

    @Test fun motionCleanupUsesActualFrameSpacing() {
        val input = mapOf("root" to listOf(
            0 to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f),
            2 to floatArrayOf(10f, 0f, 0f, 0f, 0f, 0f, 1f),
            10 to floatArrayOf(10f, 0f, 0f, 0f, 0f, 0f, 1f)
        ))
        val clean = MotionCleanup.clean(input, strength = 1f, passes = 1)["root"]!!
        assertEquals(2f, clean[1].second[0], 0.001f)
    }

    @Test fun motionCleanupRemovesSpikesAndNormalizesQuaternions() {
        val input = mapOf("センター" to listOf(
            0 to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 2f),
            1 to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f),
            2 to floatArrayOf(10f, 0f, 0f, 0f, 0f, 0f, -1f),
            3 to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f),
            4 to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f)
        ))
        val clean = MotionCleanup.clean(input, strength = 1f, passes = 1, spikeThreshold = 0.1f)["センター"]!!
        assertEquals(5, clean.size)
        assertEquals(0f, clean[2].second[0], 0.001f)
        for (key in clean) {
            val q = key.second
            val len = kotlin.math.sqrt((3..6).sumOf { (q[it] * q[it]).toDouble() }).toFloat()
            assertEquals(1f, len, 0.001f)
        }
    }
}
