package studio.mmd

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import studio.mmd.mmd.GlbParser
import studio.mmd.mmd.ObjParser
import studio.mmd.mmd.PmxFormatException
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import studio.mmd.rig.PhysBake
import studio.mmd.rig.PhysConfig
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** v1.14.0: importação de .glb/.gltf/.obj e assinatura do cache de física. Nunca executados (sem Kotlin/Gradle no ambiente de escrita). */
class GlbImportTest {
    private fun glb(json: String, bin: ByteArray): ByteArray {
        var j = json.toByteArray(Charsets.UTF_8)
        val jp = (4 - j.size % 4) % 4; j = j + ByteArray(jp) { ' '.code.toByte() }
        val bp = bin + ByteArray((4 - bin.size % 4) % 4)
        val total = 12 + 8 + j.size + 8 + bp.size
        val bb = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(0x46546C67).putInt(2).putInt(total)
        bb.putInt(j.size).putInt(0x4E4F534A).put(j)
        bb.putInt(bp.size).putInt(0x004E4942).put(bp)
        return bb.array()
    }

    private fun tri(): ByteArray {
        val bb = ByteBuffer.allocate(42).order(ByteOrder.LITTLE_ENDIAN)
        for (f in floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f)) bb.putFloat(f)
        bb.putShort(0).putShort(1).putShort(2)
        return bb.array()
    }

    private val plain = """{"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0,"name":"t"}],
      "meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1,"material":0}]}],
      "materials":[{"name":"vermelho","pbrMetallicRoughness":{"baseColorFactor":[1,0,0,1]},"doubleSided":true}],
      "buffers":[{"byteLength":42}],
      "bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":36},{"buffer":0,"byteOffset":36,"byteLength":6}],
      "accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3"},{"bufferView":1,"componentType":5123,"count":3,"type":"SCALAR"}]}"""

    @Test fun triangleBecomesMmdModelWithRootBone() {
        val m = GlbParser.parse(glb(plain, tri())).model
        assertEquals(3, m.vertexCount)
        assertEquals(1, m.bones.size); assertEquals("raiz", m.bones[0].name)
        // 1 m = 12,5 unidades MMD; Z invertido
        assertArrayEquals(floatArrayOf(12.5f, 0f, 0f), floatArrayOf(m.positions[3], m.positions[4], Math.abs(m.positions[5])), 1e-4f)
        assertEquals(12.5f, m.positions[7], 1e-4f)
        assertArrayEquals(intArrayOf(0, 2, 1), m.indices)           // ordem invertida
        assertEquals(1, m.materials.size); assertEquals(3, m.materials[0].indexCount); assertTrue(m.materials[0].doubleSided)
        assertEquals(1f, m.materials[0].diffuse[0], 1e-6f); assertEquals(0f, m.materials[0].diffuse[1], 1e-6f)
        assertEquals(0, m.boneIndices[0]); assertEquals(1f, m.boneWeights[0], 1e-6f)
        assertEquals(-1, m.boneIndices[1])
        // normal calculada (não havia NORMAL): aponta para +Z do glTF = -Z no MMD
        assertEquals(-1f, m.normals[2], 1e-4f)
    }

    @Test fun skinnedMeshMapsJointsAndHierarchy() {
        val bb = ByteBuffer.allocate(3 * 12 + 6 + 2 + 3 * 4 + 3 * 16).order(ByteOrder.LITTLE_ENDIAN)
        for (f in floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f)) bb.putFloat(f)
        bb.putShort(0).putShort(1).putShort(2); bb.putShort(0)
        for (v in 0..2) { bb.put(0.toByte()).put(1.toByte()).put(0.toByte()).put(0.toByte()) }                      // JOINTS_0 ubyte vec4
        for (v in 0..2) { bb.putFloat(0.75f).putFloat(0.25f).putFloat(0f).putFloat(0f) } // WEIGHTS_0 float vec4
        val json = """{"asset":{"version":"2.0"},"nodes":[{"mesh":0,"skin":0},{"name":"quadril","translation":[0,1,0],"children":[2]},{"name":"cabeca","translation":[0,0.5,0]}],
          "skins":[{"joints":[1,2]}],
          "meshes":[{"primitives":[{"attributes":{"POSITION":0,"JOINTS_0":2,"WEIGHTS_0":3},"indices":1}]}],
          "buffers":[{"byteLength":${bb.capacity()}}],
          "bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":36},{"buffer":0,"byteOffset":36,"byteLength":6},{"buffer":0,"byteOffset":44,"byteLength":12},{"buffer":0,"byteOffset":56,"byteLength":48}],
          "accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3"},{"bufferView":1,"componentType":5123,"count":3,"type":"SCALAR"},
                       {"bufferView":2,"componentType":5121,"count":3,"type":"VEC4"},{"bufferView":3,"componentType":5126,"count":3,"type":"VEC4"}]}"""
        val m = GlbParser.parse(glb(json, bb.array())).model
        assertEquals(3, m.bones.size)                 // raiz + 2 juntas
        val q = m.bones.indexOfFirst { it.name == "quadril" }; val c = m.bones.indexOfFirst { it.name == "cabeca" }
        assertEquals(-1, m.bones[q].parent); assertEquals(q, m.bones[c].parent)
        assertEquals(1f * 12.5f, m.bones[q].y, 1e-3f); assertEquals(1.5f * 12.5f, m.bones[c].y, 1e-3f)
        assertEquals(q, m.boneIndices[0]); assertEquals(c, m.boneIndices[1])
        assertEquals(0.75f, m.boneWeights[0], 1e-6f); assertEquals(0.25f, m.boneWeights[1], 1e-6f)
    }

    @Test fun animationsAreReportedNotSilentlyDropped() {
        val j = plain.replaceFirst("\"scene\":0", "\"animations\":[{}],\"scene\":0")
        val w = GlbParser.parse(glb(j, tri())).model.warnings
        assertTrue(w.any { it.contains("animações") })
    }

    @Test fun invalidFilesGiveClearErrors() {
        try { GlbParser.parse("não é glTF".toByteArray()); fail() } catch (e: PmxFormatException) { assertTrue(e.message!!.isNotEmpty()) }
        val noMesh = """{"asset":{"version":"2.0"},"nodes":[{}]}"""
        try { GlbParser.parse(glb(noMesh, ByteArray(0))); fail() } catch (e: PmxFormatException) { assertTrue(e.message!!.contains("malha")) }
        val bad = plain.replace("\"count\":3,\"type\":\"SCALAR\"", "\"count\":300,\"type\":\"SCALAR\"")
        try { GlbParser.parse(glb(bad, tri())); fail() } catch (e: PmxFormatException) { /* índices fora do buffer: primitiva ignorada => sem malha */ }
    }
}

class ObjImportTest {
    @Test fun quadWithMaterialIsTriangulatedAndFlipped() {
        val obj = "mtllib a.mtl\nv 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\nvt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nusemtl cor\nf 1/1 2/2 3/3 4/4\n"
        val mtl = "newmtl cor\nKd 0.1 0.2 0.3\nd 0.5\nmap_Kd tex/foto.png\n"
        val m = ObjParser.parse(obj.toByteArray()) { if (it == "a.mtl") mtl.toByteArray() else null }
        assertEquals(4, m.vertexCount); assertEquals(6, m.indices.size)
        assertEquals(1, m.bones.size)
        assertEquals(1, m.materials.size); assertEquals(6, m.materials[0].indexCount)
        assertEquals(0.2f, m.materials[0].diffuse[1], 1e-6f); assertEquals(0.5f, m.materials[0].diffuse[3], 1e-6f)
        assertEquals(listOf("foto.png"), m.textures); assertEquals(0, m.materials[0].textureIndex)
        assertEquals(1f, m.uvs[1 * 2 + 1] , 1e-6f)  // vt (1,0) -> V invertido = 1
        assertEquals(12.5f, m.positions[3], 1e-4f)
        // primeiro triângulo (0,1,2) vira (0,2,1) por causa do Z invertido
        assertArrayEquals(intArrayOf(0, 2, 1), m.indices.copyOfRange(0, 3))
    }

    @Test fun negativeIndicesAndMissingNormalsWork() {
        val m = ObjParser.parse("v 0 0 0\nv 1 0 0\nv 0 1 0\nf -3 -2 -1\n".toByteArray())
        assertEquals(3, m.vertexCount)
        assertTrue(m.warnings.any { it.contains("normais") })
        assertEquals(1f, Math.abs(m.normals[2]), 1e-4f)
    }

    @Test fun hugeModelIsRescaled() {
        val m = ObjParser.parse("v 0 0 0\nv 1000 0 0\nv 0 1000 0\nf 1 2 3\n".toByteArray())
        assertTrue(m.warnings.any { it.contains("reescalado") })
        var mx = 0f; for (i in 0 until m.positions.size) mx = maxOf(mx, Math.abs(m.positions[i]))
        assertEquals(20f, mx, 0.1f)
    }

    @Test fun emptyObjFails() {
        try { ObjParser.parse("# nada\n".toByteArray()); fail() } catch (e: PmxFormatException) { assertTrue(e.message!!.contains("vértice")) }
    }
}

class PhysCacheKeyTest {
    private fun mo(v: Float) = VmdMotion("m", mapOf("a" to VmdTrack(intArrayOf(0, 10), FloatArray(14) { it + v }, ByteArray(32))), emptyMap(), 10)

    @Test fun sameContentSameSignatureDifferentContentDiffers() {
        assertEquals(PhysBake.signature(mo(0f)), PhysBake.signature(mo(0f)))   // instâncias diferentes, mesmo conteúdo
        assertNotEquals(PhysBake.signature(mo(0f)), PhysBake.signature(mo(0.5f)))
    }

    @Test fun keyChangesWithPhysicsConfig() {
        val s = PhysBake.signature(mo(0f))
        val a = PhysBake.combine(s, PhysConfig(enabled = true), emptyList(), emptyList())
        assertEquals(a, PhysBake.combine(s, PhysConfig(enabled = true), emptyList(), emptyList()))
        assertNotEquals(a, PhysBake.combine(s, PhysConfig(enabled = true, gravity = 1.5f), emptyList(), emptyList()))
    }
}
