package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import studio.mmd.rig.PhysConfig
import studio.mmd.rig.RigConfig
import studio.mmd.rig.RigState

/** v1.26.0 (8.3b): cada personagem tem a sua RigConfig; RigState é só atalho para a principal. Nunca executado (sem kotlinc no ambiente de escrita). */
class RigConfigTest {
    @Test fun rigStateIsAShortcutToMain() {
        RigState.main.clear()
        RigState.phys = PhysConfig(enabled = true)
        assertTrue(RigState.main.phys.enabled)
        assertSame(RigState.main.phys, RigState.phys)
        RigState.main.clear()
        assertFalse(RigState.phys.enabled)
    }

    @Test fun separateConfigsDoNotShareState() {
        val a = RigConfig(); val b = RigConfig()
        a.phys = PhysConfig(enabled = true)
        assertTrue(a.phys.enabled)
        assertFalse(b.phys.enabled)
        assertNotSame(a, RigState.main)
        assertTrue(b.list.isEmpty() && b.secondary.isEmpty())
        assertNull(b.physCache)
    }

    @Test fun clearResetsEverything() {
        val c = RigConfig()
        c.phys = PhysConfig(enabled = true)
        c.clear()
        assertFalse(c.phys.enabled)
        assertEquals(0, c.list.size)
    }
}
