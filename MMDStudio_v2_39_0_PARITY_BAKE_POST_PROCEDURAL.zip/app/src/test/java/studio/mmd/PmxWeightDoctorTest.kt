package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.PmxWeightDoctor
import studio.mmd.mmd.*

class PmxWeightDoctorTest {
    private fun sample(): PmxModel {
        val bones = listOf(
            PmxBone("root","root",0f,0f,0f,-1,0,0,-1,-1,0f,null),
            PmxBone("child","child",0f,1f,0f,0,0,0,-1,-1,0f,null)
        )
        return PmxModel("weights",2.1f,floatArrayOf(0f,0f,0f,1f,0f,0f),FloatArray(6),FloatArray(4),
            intArrayOf(0,0,1,-1, 99,-1,-1,-1), floatArrayOf(.2f,.3f,.5f,0f, 1f,0f,0f,0f),
            intArrayOf(),emptyList(),emptyList(),bones,emptyList(),weightTypes=byteArrayOf(2,4))
    }

    @Test fun mergesDuplicateBonesAndNormalizesRemainingWeights() {
        val result = PmxWeightDoctor.repair(sample())
        assertEquals(2, result.repairedVertices)
        assertEquals(0, result.model.boneIndices[0]) // duplicate bone 0 is merged, then sorted with bone 1; tie order deterministic
        assertEquals(.5f, result.model.boneWeights[0], 1e-5f)
        assertEquals(.5f, result.model.boneWeights[1], 1e-5f)
        assertEquals(1, result.leftUnweighted)
        assertEquals(0, result.reportAfter.invalidBoneReferences)
        assertEquals(0, result.reportAfter.sumMismatch)
    }

    @Test fun optionalFallbackBoneCanRepairFullyUnweightedVertex() {
        val result = PmxWeightDoctor.repair(sample(), fallbackBone = 0)
        val base = 4
        assertEquals(0, result.model.boneIndices[base])
        assertEquals(1f, result.model.boneWeights[base], 0f)
        assertEquals(0, result.leftUnweighted)
    }

    @Test fun validSdefKeepsBoneOrderAndSdefParameters() {
        val root = PmxBone("root","root",0f,0f,0f,-1,0,0,-1,-1,0f,null)
        val child = PmxBone("child","child",0f,1f,0f,0,0,0,-1,-1,0f,null)
        val model = PmxModel("sdef",2.1f,floatArrayOf(0f,0f,0f),FloatArray(3),FloatArray(2),
            intArrayOf(1,0,-1,-1),floatArrayOf(.3f,.7f,0f,0f),intArrayOf(),emptyList(),emptyList(),listOf(root,child),emptyList(),
            weightTypes=byteArrayOf(3),sdef=FloatArray(9) { it.toFloat() })
        val fixed = PmxWeightDoctor.repair(model).model
        assertEquals(1, fixed.boneIndices[0]); assertEquals(0, fixed.boneIndices[1])
        assertEquals(.3f, fixed.boneWeights[0], 1e-6f); assertEquals(.7f, fixed.boneWeights[1], 1e-6f)
        assertEquals(3, fixed.weightTypes[0].toInt())
        assertArrayEquals(model.sdef, fixed.sdef!!, 0f)
    }

    @Test fun sourceModelIsNotMutated() {
        val source = sample(); val old = source.boneWeights.copyOf()
        PmxWeightDoctor.repair(source)
        assertArrayEquals(old, source.boneWeights, 0f)
    }
}
