package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.material.*
import studio.mmd.mmd.*
import studio.mmd.rig.*
import kotlin.math.abs
import kotlin.math.sqrt

class ProfessionalUpgradeTest {
    private fun material() = PmxMaterial(
        "Studio", "Studio", floatArrayOf(.72f, .31f, .18f, 1f),
        floatArrayOf(.3f, .3f, .3f), 30f, floatArrayOf(.1f, .1f, .1f),
        0, floatArrayOf(0f, 0f, 0f, 1f), 0f,
        -1, -1, 0, false, 0, 3
    )

    @Test fun shaderGraphBasicCompilesFinitePmxMaterialAndPreservesTextureBindings() {
        val base = material()
        val result = ShaderGraphCompiler.compile(ShaderGraphCompiler.basic(base), base)
        assertEquals(5, result.evaluatedNodes)
        assertEquals(base.name, result.material.name)
        assertEquals(base.textureIndex, result.material.textureIndex)
        assertEquals(base.sphereIndex, result.material.sphereIndex)
        assertEquals(base.diffuse[0], result.material.diffuse[0], .0001f)
        assertTrue(result.material.specular.all { it.isFinite() })
        assertTrue(result.material.ambient.all { it.isFinite() })
        assertTrue(result.material.specularPower.isFinite())
        assertTrue(result.warnings.any { it.contains("metallic") })
    }

    @Test fun shaderGraphMaterialSurvivesPmxWriterParserRoundTrip() {
        val base = material()
        val compiled = ShaderGraphCompiler.compile(ShaderGraphCompiler.basic(base), base).material
        val model = PmxModel(
            "Shader round-trip", 2.1f,
            floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f),
            floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f),
            floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f),
            intArrayOf(0, -1, -1, -1, 0, -1, -1, -1, 0, -1, -1, -1),
            floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f),
            intArrayOf(0, 1, 2), emptyList(), listOf(compiled), emptyList(), emptyList()
        )
        val written = PmxWriter.write(model)
        val parsed = PmxParser.parse(written.bytes)
        assertEquals(compiled.diffuse[0], parsed.materials[0].diffuse[0], .0001f)
        assertEquals(compiled.specularPower, parsed.materials[0].specularPower, .01f)
        assertEquals(compiled.textureIndex, parsed.materials[0].textureIndex)
    }

    @Test fun shaderGraphMixNodeControlsBaseColor() {
        val base = material()
        val graph = MaterialGraph(
            nodes = listOf(
                MaterialGraphNode("black", MaterialNodeKind.COLOR, floatArrayOf(0f, 0f, 0f, 1f)),
                MaterialGraphNode("gold", MaterialNodeKind.COLOR, floatArrayOf(1f, .5f, .05f, 1f)),
                MaterialGraphNode("factor", MaterialNodeKind.VALUE, value = .25f),
                MaterialGraphNode("mix", MaterialNodeKind.MIX),
                MaterialGraphNode("surface", MaterialNodeKind.PRINCIPLED),
                MaterialGraphNode("output", MaterialNodeKind.OUTPUT)
            ),
            links = listOf(
                MaterialGraphLink("black", "mix", "a"),
                MaterialGraphLink("gold", "mix", "b"),
                MaterialGraphLink("factor", "mix", "factor"),
                MaterialGraphLink("mix", "surface", "baseColor"),
                MaterialGraphLink("surface", "output", "surface")
            )
        )
        val result = ShaderGraphCompiler.compile(graph, base)
        assertEquals(.25f, result.material.diffuse[0], .0001f)
        assertEquals(.125f, result.material.diffuse[1], .0001f)
        assertEquals(.0125f, result.material.diffuse[2], .0001f)
    }

    @Test fun shaderGraphRejectsCyclesAndDuplicateNodeIds() {
        val cyclic = MaterialGraph(
            listOf(MaterialGraphNode("a", MaterialNodeKind.MIX), MaterialGraphNode("b", MaterialNodeKind.MIX), MaterialGraphNode("out", MaterialNodeKind.OUTPUT)),
            listOf(MaterialGraphLink("a", "b", "a"), MaterialGraphLink("b", "a", "a"), MaterialGraphLink("b", "out", "surface"))
        )
        try {
            ShaderGraphCompiler.compile(cyclic, material())
            fail("O ciclo deveria ser rejeitado")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message.orEmpty().contains("Ciclo"))
        }
        val duplicate = MaterialGraph(listOf(MaterialGraphNode("x", MaterialNodeKind.VALUE), MaterialGraphNode("x", MaterialNodeKind.OUTPUT)), emptyList())
        try {
            ShaderGraphCompiler.compile(duplicate, material())
            fail("IDs duplicados deveriam ser rejeitados")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message.orEmpty().contains("duplicados"))
        }
    }

    @Test fun twoBoneIkSolverKeepsSegmentLengthsAndHitsReachableTarget() {
        val root = Vec3(0f, 0f, 0f)
        val middleRest = Vec3(2f, 0f, 0f)
        val endRest = Vec3(4f, 0f, 0f)
        val target = Vec3(3f, 0f, 0f)
        val solved = TwoBoneIkSolver.solve(root, middleRest, endRest, target, Vec3(0f, 0f, 1f))
        assertTrue(solved.reachable)
        assertEquals(2f, (solved.middle - root).length(), .001f)
        assertEquals(2f, (solved.end - solved.middle).length(), .001f)
        assertEquals(target.x, solved.end.x, .001f)
        assertEquals(target.y, solved.end.y, .001f)
        assertEquals(target.z, solved.end.z, .001f)
        assertTrue(listOf(solved.middle.x, solved.middle.y, solved.middle.z).all { it.isFinite() })
    }

    @Test fun twoBoneIkSolverReportsUnreachableTargetWithoutStretchingBones() {
        val solved = TwoBoneIkSolver.solve(
            Vec3(0f, 0f, 0f), Vec3(1f, 0f, 0f), Vec3(2f, 0f, 0f),
            Vec3(10f, 0f, 0f), Vec3(0f, 0f, 1f)
        )
        assertFalse(solved.reachable)
        assertTrue(solved.reachError > 7.9f)
        assertEquals(1f, (solved.middle - Vec3(0f, 0f, 0f)).length(), .001f)
        assertEquals(1f, (solved.end - solved.middle).length(), .001f)
    }


    @Test fun shaderGraphMultiplyCombinesBaseAndTintChannels() {
        val base = material()
        val graph = MaterialGraph(
            nodes = listOf(
                MaterialGraphNode("base", MaterialNodeKind.COLOR, floatArrayOf(.8f, .4f, .2f, 1f)),
                MaterialGraphNode("tint", MaterialNodeKind.COLOR, floatArrayOf(.5f, .25f, 1f, 1f)),
                MaterialGraphNode("multiply", MaterialNodeKind.MULTIPLY),
                MaterialGraphNode("surface", MaterialNodeKind.PRINCIPLED),
                MaterialGraphNode("output", MaterialNodeKind.OUTPUT)
            ),
            links = listOf(
                MaterialGraphLink("base", "multiply", "a"),
                MaterialGraphLink("tint", "multiply", "b"),
                MaterialGraphLink("multiply", "surface", "baseColor"),
                MaterialGraphLink("surface", "output", "surface")
            )
        )
        val diffuse = ShaderGraphCompiler.compile(graph, base).material.diffuse
        assertEquals(.4f, diffuse[0], .0001f)
        assertEquals(.1f, diffuse[1], .0001f)
        assertEquals(.2f, diffuse[2], .0001f)
    }

    @Test fun twoBoneIkSolverHonorsMinimumBendWithoutStretching() {
        val minimum = Math.toRadians(100.0).toFloat()
        val maximum = Math.toRadians(120.0).toFloat()
        val solved = TwoBoneIkSolver.solve(
            Vec3(0f, 0f, 0f), Vec3(2f, 0f, 0f), Vec3(4f, 0f, 0f),
            Vec3(3f, 0f, 0f), Vec3(0f, 0f, 1f), TwoBoneIkLimits(minimum, maximum)
        )
        assertFalse(solved.reachable)
        assertEquals(minimum, solved.bendRadians, .0001f)
        assertEquals(2f, (solved.middle - Vec3(0f, 0f, 0f)).length(), .001f)
        assertEquals(2f, (solved.end - solved.middle).length(), .001f)
    }

    @Test fun skinnedClothConvertsFromPreviousPoseAndKeepsAnchorsInCurrentPose() {
        val vertices = floatArrayOf(0f, 1f, 0f, 1f, 1f, 0f, 0f, 0f, 0f)
        val indices = intArrayOf(0, 1, 2)
        val cloth = ClothXpbd.fromMesh(vertices, indices)
        cloth.pin(0)
        val translation = object : ClothSkinTransform {
            override fun toWorldPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                out[0] = x + 2f; out[1] = y; out[2] = z
            }
            override fun toWorldPreviousPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                out[0] = x + 1f; out[1] = y; out[2] = z
            }
            override fun toLocalPosition(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                out[0] = x - 2f; out[1] = y; out[2] = z
            }
            override fun toWorldVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                out[0] = x; out[1] = y; out[2] = z
            }
            override fun toLocalVector(vertex: Int, x: Float, y: Float, z: Float, out: FloatArray) {
                out[0] = x; out[1] = y; out[2] = z
            }
        }
        val before = cloth.position(1)
        val after = cloth.stepSkinned(1f / 30f, translation, gravityY = 0f, substeps = 1, iterations = 1, damping = 0f, groundY = null)
        assertEquals(before[0] - 1f, after[3], .02f)
        assertEquals(before[1], after[4], .02f)
        assertEquals(before[2], after[5], .02f)
        assertEquals(0f, cloth.position(0)[0], .001f)
        assertTrue(after.all { it.isFinite() })
    }
}
