package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class PmxPrimitiveDrawTest {
    @Test fun defaultIsTriangle() = assertEquals(PmxPrimitiveMode.TRIANGLES,PmxPrimitiveDraw.modeFromFlags(0))
    @Test fun pointFlagWinsWhenBothPointAndLineAreSet() = assertEquals(PmxPrimitiveMode.POINTS,PmxPrimitiveDraw.modeFromFlags(0xC0))
    @Test fun lineFlagSelectsLines() = assertEquals(PmxPrimitiveMode.LINES,PmxPrimitiveDraw.modeFromFlags(0x80))
    @Test fun triangleEdgesExpandAsAbBcCa() {
        assertArrayEquals(intArrayOf(4,7,7,9,9,4),PmxPrimitiveDraw.expandTriangleEdges(intArrayOf(4,7,9)))
    }
    @Test fun multipleTrianglesPreserveMaterialOrder() {
        assertArrayEquals(intArrayOf(0,1,1,2,2,0, 3,4,4,5,5,3),PmxPrimitiveDraw.expandTriangleEdges(intArrayOf(0,1,2,3,4,5)))
    }
}
