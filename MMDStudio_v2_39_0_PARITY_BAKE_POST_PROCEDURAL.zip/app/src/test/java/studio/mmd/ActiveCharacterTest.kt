package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.scene.ActiveCharacter
import studio.mmd.scene.EditSessions

class ActiveCharacterTest {
    private class Fake(val id: String) { var keys = 0 }

    @Test fun resolveFallsBackToMainWhenGone() {
        assertEquals("model", ActiveCharacter.resolve(null, listOf("a")))
        assertEquals("model", ActiveCharacter.resolve("zzz", listOf("a")))
        assertEquals("a", ActiveCharacter.resolve("a", listOf("a", "b")))
        assertEquals("model", ActiveCharacter.resolve("model", listOf("a")))
    }
    @Test fun labelsAndLock() {
        assertEquals("Miku", ActiveCharacter.label("a", mapOf("a" to "Miku"), "x"))
        assertEquals("Principal", ActiveCharacter.label("model", emptyMap(), " "))
        assertFalse(ActiveCharacter.canEdit("a", setOf("a")))
        assertTrue(ActiveCharacter.canEdit("b", setOf("a")))
    }
    @Test fun sessionsAreIndependentAndLazy() {
        var created = 0
        val s = EditSessions { id -> created++; Fake(id) }
        val a = s.get("a")!!; val b = s.get("b")!!
        assertSame(a, s.get("a")); assertEquals(2, created)
        a.keys = 5; s.markDirty("a")
        assertEquals(0, b.keys); assertTrue(s.isDirty("a")); assertFalse(s.isDirty("b"))
    }
    @Test fun flushSavesOnlyDirtyAndKeepsFailed() {
        val s = EditSessions { Fake(it) }
        s.get("a"); s.get("b"); s.get("c"); s.markDirty("a"); s.markDirty("c")
        val saved = ArrayList<String>()
        assertEquals(1, s.flush { id, _ -> saved.add(id); id == "a" })
        assertEquals(listOf("a", "c"), saved)
        assertEquals(listOf("c"), s.dirtyIds())
    }
    @Test fun failedCreateAndDrop() {
        val s = EditSessions<Fake> { null }
        assertNull(s.get("a")); assertFalse(s.has("a"))
        val t = EditSessions { Fake(it) }; t.get("a"); t.markDirty("a"); t.drop("a")
        assertFalse(t.has("a")); assertTrue(t.dirtyIds().isEmpty())
        t.markDirty("nao-aberto"); assertFalse(t.isDirty("nao-aberto"))
    }
}
