package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*

class PmxPhysicsDoctorTest {
    private fun model(rigid: PmxRigid, joint: PmxJoint): PmxModel = PmxModel(
        "physics", 2.1f, floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f),
        floatArrayOf(0f,0f,1f, 0f,0f,1f, 0f,0f,1f), FloatArray(6),
        intArrayOf(0,-1,-1,-1, 0,-1,-1,-1, 0,-1,-1,-1),
        floatArrayOf(1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f), intArrayOf(0,1,2), emptyList(),
        listOf(PmxMaterial("m","m",floatArrayOf(1f,1f,1f,1f),floatArrayOf(0f,0f,0f),0f,floatArrayOf(0f,0f,0f),0,floatArrayOf(0f,0f,0f,1f),0f,-1,-1,0,true,0,3)),
        listOf(PmxBone("root","root",0f,0f,0f,-1,0,0,-1,-1,0f,null)), emptyList(), listOf(rigid, rigid.copyForTest("b")), listOf(joint)
    )
    private fun PmxRigid.copyForTest(name2: String) = PmxRigid(name2,nameEn,bone,group,shape,mass,linearDamping,angularDamping,mode,mask,size.copyOf(),pos.copyOf(),rot.copyOf(),restitution,friction)

    @Test fun validRigidAndJointAreHealthy() {
        val rb = PmxRigid("a","a",0,0,0,1f,0.1f,0.1f,1,size=floatArrayOf(.1f,.1f,.1f),pos=FloatArray(3),rot=FloatArray(3))
        val j = PmxJoint("j",0,1,FloatArray(3),FloatArray(3),floatArrayOf(-1f,-1f,-1f),floatArrayOf(1f,1f,1f),floatArrayOf(-1f,-1f,-1f),floatArrayOf(1f,1f,1f),FloatArray(3),FloatArray(3))
        assertTrue(PmxPhysicsDoctor.inspect(model(rb,j)).healthy)
    }

    @Test fun detectsBadRigidAndJointParameters() {
        val rb = PmxRigid("bad","bad",99,22,8,Float.NaN,-1f,2f,9,size=floatArrayOf(0f,-1f,Float.NaN),pos=floatArrayOf(Float.NaN,0f,0f),rot=FloatArray(3),restitution=2f,friction=Float.NaN)
        val j = PmxJoint("bad-j",0,0,FloatArray(3),FloatArray(3),floatArrayOf(2f,0f,0f),floatArrayOf(1f,1f,1f),FloatArray(3),FloatArray(3),floatArrayOf(-1f,0f,0f),FloatArray(3),type=8)
        val report = PmxPhysicsDoctor.inspect(model(rb,j))
        assertFalse(report.healthy)
        assertTrue(report.issues.any { it.code == "rigid.bone" })
        assertTrue(report.issues.any { it.code == "joint.references" })
    }

    @Test fun repairClampsSafeFieldsAndDropsOrphanJoints() {
        val rb = PmxRigid("bad","bad",99,22,8,Float.NaN,-1f,2f,9,size=floatArrayOf(0f,-1f,Float.NaN),pos=floatArrayOf(Float.NaN,0f,0f),rot=FloatArray(3),restitution=2f,friction=Float.NaN)
        val j = PmxJoint("orphan",9,10,FloatArray(3),FloatArray(3),FloatArray(3),FloatArray(3),FloatArray(3),FloatArray(3),FloatArray(3),FloatArray(3))
        val result = PmxPhysicsDoctor.repair(model(rb,j))
        assertEquals(2, result.model.rigidBodies.size)
        assertEquals(0, result.model.joints.size)
        assertEquals(1, result.removedJoints)
        assertEquals(-1, result.model.rigidBodies[0].bone)
        assertEquals(0f, result.model.rigidBodies[0].mass, 0f)
        assertTrue(result.model.rigidBodies[0].size.all { it > 0f && it.isFinite() })
    }
}
