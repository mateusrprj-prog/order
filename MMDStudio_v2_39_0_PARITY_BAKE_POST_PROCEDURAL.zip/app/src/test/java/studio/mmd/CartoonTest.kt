package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.cartoon.*
import studio.mmd.edit.BKey
import studio.mmd.edit.Euler
import studio.mmd.edit.MKey

/** v1.28.0 — Cartoon Motion Library: lógica pura (não toca em Android). */
class CartoonTest {
    private fun key(f: Int, y: Float, rz: Float = 0f): BKey {
        val q = Euler.quat(0f, 0f, rz)
        return BKey(f, floatArrayOf(0f, y, 0f, q[0], q[1], q[2], q[3]), CartoonMath.linearIp())
    }
    private fun closedClip() = Clip(mapOf("センター" to listOf(key(0, 0f), key(10, 1f), key(20, 0f))), emptyMap())
    private fun openClip() = Clip(mapOf("センター" to listOf(key(0, 0f), key(10, 1f), key(20, 2f))), emptyMap())

    @Test fun defaultParamsKeepKeysAndCurves() {
        val b = CartoonMath.build(closedClip(), CartoonParams(), null)
        val l = b.bones.getValue("センター")
        assertEquals(listOf(0, 10, 20), l.map { it.frame })
        assertEquals(1f, l[1].v[1], 1e-5f)
        assertArrayEquals(CartoonMath.linearIp(), l[1].ip)
    }
    @Test fun speedDoublesHalvesDuration() {
        val b = CartoonMath.build(closedClip(), CartoonParams(speed = 2f), null)
        assertEquals(10, b.last)
        assertEquals(listOf(0, 5, 10), b.bones.getValue("センター").map { it.frame })
    }
    @Test fun intensityScalesPositionAndAngle() {
        val c = Clip(mapOf("頭" to listOf(key(0, 0f), key(10, 2f, 40f))), emptyMap())
        val b = CartoonMath.build(c, CartoonParams(intensity = 0.5f), null).bones.getValue("頭")
        assertEquals(1f, b[1].v[1], 1e-4f)
        val z = Euler.euler(b[1].v.copyOfRange(3, 7))[2]
        assertEquals(20f, z, 0.5f)
        val d = CartoonMath.build(c, CartoonParams(intensity = 0f), null).bones.getValue("頭")
        assertEquals(1f, d[1].v[6], 1e-4f)
    }
    @Test fun closedLoopHasNoDuplicateSeamKey() {
        val b = CartoonMath.build(closedClip(), CartoonParams(loops = 3), null)
        val fr = b.bones.getValue("センター").map { it.frame }
        assertEquals(fr.distinct(), fr)
        assertEquals(60, b.last)
        assertEquals(listOf(0, 10, 20, 30, 40, 50, 60), fr)
    }
    @Test fun openLoopGetsSeamWhenSmoothed() {
        val b = CartoonMath.build(openClip(), CartoonParams(loops = 2, smooth = 0.5f), null)
        val fr = b.bones.getValue("センター").map { it.frame }
        assertEquals(fr.sorted(), fr); assertEquals(fr.distinct(), fr)
        assertTrue(b.last > 40)           // 20 + emenda 6 + 20
    }
    @Test fun rangeCropsWithSampledBorders() {
        val b = CartoonMath.build(closedClip(), CartoonParams(srcStart = 5, srcEnd = 15), null)
        val l = b.bones.getValue("センター")
        assertEquals(0, l[0].frame); assertEquals(10, l.last().frame)
        assertEquals(0.5f, l[0].v[1], 1e-4f)      // amostrado no meio da subida
    }
    @Test fun atFrameShiftsEverything() {
        val b = CartoonMath.build(closedClip(), CartoonParams(atFrame = 100), null)
        assertEquals(100, b.first); assertEquals(120, b.last)
    }
    @Test fun combineGivesEachBoneToOneSource() {
        val base = Clip(mapOf("センター" to listOf(key(0, 0f), key(10, 1f)), "頭" to listOf(key(0, 0f), key(10, 5f)), "左腕" to listOf(key(0, 0f), key(10, 7f))), mapOf("笑い" to listOf(MKey(0, 0f), MKey(10, 1f))))
        val over = Clip(mapOf("頭" to listOf(key(0, 0f), key(5, 9f)), "左腕" to listOf(key(0, 0f), key(5, 3f)), "センター" to listOf(key(0, 0f), key(5, 99f))), emptyMap())
        val r = CartoonMath.combine(base, CartoonParams(), over, CartoonParams(), setOf(BoneGroup.HEAD, BoneGroup.ARMS))
        assertEquals(1f, r.bones.getValue("センター").maxOf { it.v[1] }, 1e-5f)        // corpo: do base
        assertEquals(9f, r.bones.getValue("頭").maxOf { it.v[1] }, 1e-5f)            // cabeça: do over
        assertEquals(3f, r.bones.getValue("左腕").maxOf { it.v[1] }, 1e-5f)
        assertTrue(r.morphs.containsKey("笑い"))                                     // rosto não foi pedido: continua do base
        assertTrue(r.last >= 10)                                                     // over repete até cobrir o base
    }
    @Test fun combineWithoutOverEqualsBuild() {
        val a = CartoonMath.combine(closedClip(), CartoonParams(), null, CartoonParams(), setOf(BoneGroup.HEAD))
        assertEquals(20, a.last)
    }
    @Test fun groupsClassifyStandardBones() {
        assertEquals(BoneGroup.HEAD, BoneGroups.of("頭")); assertEquals(BoneGroup.ARMS, BoneGroups.of("左手首")); assertEquals(BoneGroup.LEGS, BoneGroups.of("右足首"))
        assertEquals(BoneGroup.BODY, BoneGroups.of("センター")); assertEquals(BoneGroup.BODY, BoneGroups.of("上半身2"))
    }
    @Test fun compatCountsBones() {
        val c = Clip(mapOf("頭" to listOf(key(0, 0f)), "尻尾" to listOf(key(0, 0f))), emptyMap())
        assertEquals(0.5f, c.compat(setOf("頭"), emptySet()), 1e-5f)
    }
    @Test fun builtinClipsAreWellFormed() {
        assertTrue(CartoonBuiltin.all.size >= 28)
        assertEquals(CartoonBuiltin.all.size, CartoonBuiltin.all.map { it.id }.distinct().size)
        for (cat in CartoonCat.values()) assertTrue("categoria vazia: $cat", CartoonBuiltin.all.any { it.cat == cat })
        for (d in CartoonBuiltin.all) {
            val c = d.make()
            assertTrue(d.id, c.length > 0 && (c.bones.isNotEmpty() || c.morphs.isNotEmpty()))
            for ((n, l) in c.bones) {
                assertEquals("$n em ${d.id}", l.map { it.frame }.sorted(), l.map { it.frame })
                for (k in l) { assertEquals(16, k.ip.size); assertEquals(7, k.v.size); assertFalse(k.v.any { it.isNaN() }) }
            }
        }
    }
    @Test fun cyclesAreClosedLoops() {
        for (id in listOf("walk_cartoon", "run_cartoon", "idle_breath", "react_joy", "hand_wave")) {
            val c = CartoonBuiltin.byId(id)!!.make()
            assertTrue("$id deveria fechar", CartoonMath.isClosed(c, 0, c.length))
        }
    }
    @Test fun builtToMotionKeepsTracks() {
        val m = CartoonMath.build(closedClip(), CartoonParams(), null).toMotion()
        assertEquals(setOf("センター"), m.bones.keys); assertEquals(20, m.maxFrame)
    }
}
