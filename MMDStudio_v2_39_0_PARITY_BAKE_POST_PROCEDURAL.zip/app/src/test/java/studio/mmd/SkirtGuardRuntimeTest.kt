package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import studio.mmd.rig.*

class SkirtGuardRuntimeTest {
    private fun bone(name: String, en: String, x: Float, y: Float, parent: Int) =
        PmxBone(name, en, x, y, 0f, parent, 0, 0, -1, -1, 0f, null)

    private fun model(): PmxModel {
        val bones = listOf(
            bone("センター", "center", 0f, 1f, -1),
            bone("左足", "thigh_L", -0.2f, 0.8f, 0), bone("左ひざ", "knee_L", -0.2f, 0.4f, 1), bone("左足首", "ankle_L", -0.2f, 0.1f, 2),
            bone("右足", "thigh_R", 0.2f, 0.8f, 0), bone("右ひざ", "knee_R", 0.2f, 0.4f, 4), bone("右足首", "ankle_R", 0.2f, 0.1f, 5),
            bone("スカート前", "front_skirt", 0f, 0.75f, 0)
        )
        val material = PmxMaterial("Saia plissada", "Pleated skirt", floatArrayOf(1f,1f,1f,1f), floatArrayOf(0f,0f,0f), 0f,
            floatArrayOf(0f,0f,0f), 0, floatArrayOf(0f,0f,0f,1f), 0f, -1, -1, 0, false, 0, 3)
        return PmxModel("SkirtGuardRuntimeTest", 2.1f, floatArrayOf(-0.25f,0.65f,0.1f, 0.25f,0.65f,0.1f, 0f,0.6f,0.2f),
            FloatArray(9), FloatArray(6), intArrayOf(7,1,-1,-1, 7,4,-1,-1, 7,0,-1,-1),
            floatArrayOf(0.9f,0.1f,0f,0f, 0.9f,0.1f,0f,0f, 0.9f,0.1f,0f,0f), intArrayOf(0,1,2), emptyList(), listOf(material), bones, emptyList())
    }

    @Test fun dynamicCollidersFollowBonePoseAndUseAnatomicalPlan() {
        val model = model(); val profile = SkirtGuardAuto.detect(model)
        val pose = SkirtGuardRuntime.pose(model, profile, 0.02f) { _, x, y, z, out ->
            out[0] = x + 1f; out[1] = y - 0.25f; out[2] = z + 0.5f
        }
        assertTrue(profile.detected)
        assertTrue(pose.source.startsWith("BodyColliders"))
        assertTrue(pose.capsules.size >= 4)
        assertTrue(pose.capsules.all { it.radius >= 0.02f })
        assertTrue(pose.capsules.first().ax > 0.5f)
    }

    @Test fun diagnosticsFindResidualClipping() {
        val capsule = ClothCapsule(0f, 0f, 0f, 0f, 1f, 0f, 0.25f)
        val d = SkirtGuardDiagnostics.measure(floatArrayOf(0f, 0.5f, 0f), intArrayOf(0), listOf(capsule))
        assertEquals(1, d.testedVertices)
        assertEquals(1, d.penetratingVertices)
        assertEquals(0, d.worstVertex)
        assertEquals(0.25f, d.maxPenetration, 1e-4f)
    }

    @Test fun xpbdProjectsClothOutOfGeneratedCapsuleVolume() {
        val solver = ClothXpbd.fromMesh(floatArrayOf(0f,0.5f,0f, 0.01f,0.5f,0f, -0.01f,0.5f,0f), intArrayOf(), particleMass = 1f)
        solver.setColliders(capsules = listOf(ClothCapsule(0f,0f,0f, 0f,1f,0f, 0.2f)), thickness = 0.01f)
        val result = solver.step(1f / 30f, gravityY = 0f, substeps = 1, iterations = 2, damping = 0f, groundY = null)
        val distance = kotlin.math.sqrt(result[0]*result[0] + (result[1]-0.5f)*(result[1]-0.5f) + result[2]*result[2])
        assertTrue("XPBD deve projetar a partícula para fora do colisor", distance >= 0.199f)
    }

    @Test fun safeProfileWithoutSkirtProducesNoRuntimeColliders() {
        val m = model(); val noSkirt = SkirtGuardAuto.detect(m).copy(detected = false, regions = emptyList())
        assertTrue(SkirtGuardRuntime.restPose(m, noSkirt).capsules.isEmpty())
    }

    @Test fun japaneseAnkleBoneIsNotClassifiedAsThighHint() {
        val profile = SkirtGuardAuto.detect(model())
        assertTrue(profile.colliderHints.none { it.boneName.contains("足首") })
    }

    @Test fun existingKinematicPmxRigidDoesNotReceiveDuplicateGuardHint() {
        val m = model()
        val rigidModel = PmxModel(m.name, m.version, m.positions, m.normals, m.uvs, m.boneIndices, m.boneWeights,
            m.indices, m.textures, m.materials, m.bones, m.morphs,
            rigidBodies = listOf(PmxRigid("left thigh", "left thigh", 1, 0, 2, 0f, 0f, 0f, 0,
                size = floatArrayOf(0.08f, 0.3f, 0f), pos = floatArrayOf(-0.2f, 0.6f, 0f))))
        val expected = BodyColliders.plan(rigidModel).colliders.size
        val actual = SkirtGuardRuntime.restPose(rigidModel).capsules.size
        assertEquals(expected, actual)
    }
}
