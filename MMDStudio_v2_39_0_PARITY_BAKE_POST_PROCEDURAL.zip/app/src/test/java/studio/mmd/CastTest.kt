package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.scene.CastCodec
import studio.mmd.scene.CastMeta

class CastTest {
    @Test fun roundTrip() {
        val l = listOf(CastMeta("a", "Miku", "zip", 1.5f, 0f, -2f, 90f, 1.2f, "dança.vmd"), CastMeta("b", "Rin", "pmx"))
        val r = CastCodec.fromJson(CastCodec.toJson(l))
        assertEquals(2, r.cast.size); assertTrue(r.warnings.isEmpty())
        assertEquals(l[0], r.cast[0]); assertEquals(l[1], r.cast[1])
    }
    @Test fun corruptedJsonGivesWarningNotCrash() {
        val r = CastCodec.fromJson("{não é json")
        assertTrue(r.cast.isEmpty()); assertEquals(1, r.warnings.size)
    }
    @Test fun newerVersionIgnored() {
        val r = CastCodec.fromJson("""{"formatVersion":99,"cast":[{"id":"a"}]}""")
        assertTrue(r.cast.isEmpty()); assertEquals(1, r.warnings.size)
    }
    @Test fun duplicateAndMissingIdsSkippedWithWarnings() {
        val r = CastCodec.fromJson("""{"formatVersion":1,"cast":[{"id":"a"},{"id":"a"},{"name":"x"},5,{"id":"c","s":999}]}""")
        assertEquals(listOf("a", "c"), r.cast.map { it.id })
        assertEquals(3, r.warnings.size)
        assertEquals(20f, r.cast[1].s, 0f)   // escala limitada
    }
    @Test fun globalClockUsesLongestMotion() {
        assertEquals(300, CastCodec.totalFrames(300, listOf(10, 99)))
        assertEquals(501, CastCodec.totalFrames(300, listOf(10, 500)))
        assertEquals(300, CastCodec.totalFrames(300, emptyList()))
    }
}
