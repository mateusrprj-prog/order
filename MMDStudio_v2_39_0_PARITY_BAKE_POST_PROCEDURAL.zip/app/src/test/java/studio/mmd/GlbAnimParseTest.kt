package studio.mmd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import studio.mmd.mmd.GlbParser
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Base64

class GlbAnimParseTest {
    /** glTF .gltf com data URI: 1 triângulo, 2 nós (raiz + filho "braco"), skin com os 2, e uma animação de rotação+translação. */
    private fun gltf(extraChannel: String = "", interp: String = "LINEAR"): ByteArray {
        val bb = ByteBuffer.allocate(4096).order(ByteOrder.LITTLE_ENDIAN)
        fun f(vararg v: Float) { v.forEach { bb.putFloat(it) } }
        fun s(vararg v: Int) { v.forEach { bb.putShort(it.toShort()) } }
        val pos = bb.position(); f(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f)            // 0..36
        val idx = bb.position(); s(0, 1, 2, 0); // 8 bytes
        val tim = bb.position(); f(0f, 1f)                                           // 8
        val rot = bb.position(); f(0f, 0f, 0f, 1f, 0f, 0f, 0.7071068f, 0.7071068f) // 32
        val trn = bb.position(); f(0f, 0f, 0f, 0f, 2f, 0f)                          // 24
        val joints = bb.position(); bb.put(byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)) // 3 verts x 4 ubyte
        val wgt = bb.position(); repeat(3) { f(1f, 0f, 0f, 0f) }
        val ibm = bb.position(); repeat(2) { f(1f,0f,0f,0f, 0f,1f,0f,0f, 0f,0f,1f,0f, 0f,0f,0f,1f) }
        val len = bb.position()
        val b64 = Base64.getEncoder().encodeToString(bb.array().copyOf(len))
        val json = """{"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],
        "nodes":[{"name":"raiz","children":[1]},{"name":"braco","translation":[0,1,0]}],
        "skins":[{"joints":[0,1],"inverseBindMatrices":8}],
        "meshes":[{"primitives":[{"attributes":{"POSITION":0,"JOINTS_0":6,"WEIGHTS_0":7},"indices":1}]}],
        "meshes_":0,
        "buffers":[{"byteLength":$len,"uri":"data:application/octet-stream;base64,$b64"}],
        "bufferViews":[{"buffer":0,"byteOffset":$pos,"byteLength":36},{"buffer":0,"byteOffset":$idx,"byteLength":6},{"buffer":0,"byteOffset":$tim,"byteLength":8},
          {"buffer":0,"byteOffset":$rot,"byteLength":32},{"buffer":0,"byteOffset":$trn,"byteLength":24},{"buffer":0,"byteOffset":$joints,"byteLength":12},{"buffer":0,"byteOffset":$wgt,"byteLength":48},{"buffer":0,"byteOffset":$ibm,"byteLength":128}],
        "accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3","min":[0,0,0],"max":[1,1,0]},
          {"bufferView":1,"componentType":5123,"count":3,"type":"SCALAR"},
          {"bufferView":2,"componentType":5126,"count":2,"type":"SCALAR"},
          {"bufferView":3,"componentType":5126,"count":2,"type":"VEC4"},
          {"bufferView":4,"componentType":5126,"count":2,"type":"VEC3"},
          {"bufferView":5,"componentType":5121,"count":3,"type":"VEC4"},
          {"bufferView":5,"componentType":5121,"count":3,"type":"VEC4"},
          {"bufferView":6,"componentType":5126,"count":3,"type":"VEC4"},
          {"bufferView":7,"componentType":5126,"count":2,"type":"MAT4"}],
        "animations":[{"name":"mexe","samplers":[{"input":2,"output":3,"interpolation":"$interp"},{"input":2,"output":4}],
          "channels":[{"sampler":0,"target":{"node":1,"path":"rotation"}},{"sampler":1,"target":{"node":0,"path":"translation"}}$extraChannel]}]}"""
        return json.toByteArray()
    }

    @Test fun leClipComCanaisEOssos() {
        val p = GlbParser.parse(gltf())
        assertEquals(1, p.clips.size)
        val c = p.clips[0]
        assertEquals("mexe", c.name); assertEquals(2, c.channels.size); assertEquals(1f, c.duration, 0f)
        val rot = c.channels.first { it.path == "rotation" }
        assertEquals("braco", rot.nodeName); assertTrue(rot.bone >= 0)
        val q = FloatArray(4); rot.sampler.eval(0.5f, q)
        assertEquals(0.3826834f, q[2], 1e-4f)   // meio entre 0° e 90° em Z = 45°
        val tr = c.channels.first { it.path == "translation" }; val v = FloatArray(3); tr.sampler.eval(0.5f, v)
        assertEquals(1f, v[1], 1e-5f)
        assertTrue(p.model.warnings.any { it.contains("animação(ões) do glTF lidas") })
        val rg = p.rig!!; assertEquals(2, rg.restT.size); assertEquals(1f, rg.restT[1][1], 0f)
        val mo = studio.mmd.mmd.GltfToMotion.convert(c, rg, p.model).motion
        assertTrue(mo.bones.isNotEmpty()); assertEquals(30, mo.maxFrame)
    }

    @Test fun canalInvalidoViraAvisoSemDerrubarOResto() {
        val extra = "," + """{"sampler":0,"target":{"node":1,"path":"weights"}},{"sampler":9,"target":{"node":1,"path":"scale"}}"""
        val p = GlbParser.parse(gltf(extra))
        assertEquals(2, p.clips[0].channels.size)
        assertTrue(p.model.warnings.any { it.contains("'weights' não suportada") })
        assertTrue(p.model.warnings.any { it.contains("sampler inválido") })
    }

    @Test fun cubicSplineComTamanhoErradoEhRecusadoComAviso() {
        val p = GlbParser.parse(gltf(interp = "CUBICSPLINE"))
        assertTrue(p.model.warnings.any { it.contains("tamanho dos valores") })
    }
}
