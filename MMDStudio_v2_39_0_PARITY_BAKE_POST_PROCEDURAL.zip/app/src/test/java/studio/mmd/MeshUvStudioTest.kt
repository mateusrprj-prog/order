package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.edit.MeshEditing
import studio.mmd.edit.SeamAwareUvUnwrapper
import studio.mmd.mmd.*

class MeshUvStudioTest {
    private fun fixture(indices: IntArray = intArrayOf(0, 1, 2, 2, 1, 3)): PmxModel {
        val material = PmxMaterial("body", "body", floatArrayOf(1f, 1f, 1f, 1f), floatArrayOf(0f, 0f, 0f), 1f,
            floatArrayOf(0f, 0f, 0f), 0, floatArrayOf(0f, 0f, 0f, 1f), 0f, -1, -1, 0, false, 0, indices.size)
        val morph = PmxMorph("smile", "smile", 0, 1, intArrayOf(1, 2), floatArrayOf(.1f, 0f, 0f, 0f, .2f, 0f), count = 2)
        val positions = floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 1f, 1f, .2f)
        return PmxModel("fixture", 2.1f, positions, FloatArray(12) { if (it % 3 == 1) 1f else 0f }, FloatArray(8),
            IntArray(16) { if (it % 4 == 0) 0 else -1 }, FloatArray(16) { if (it % 4 == 0) 1f else 0f }, indices,
            emptyList(), listOf(material), emptyList(), listOf(morph), weightTypes = ByteArray(4) { 1 }, sdef = FloatArray(36),
            addUvCount = 1, addUvs = FloatArray(16), edgeScale = FloatArray(4) { 1f }, indexSizes = intArrayOf(1, 1, 1, 1, 1, 1))
    }

    @Test fun seamAwareUnwrapSplitsVerticesAndRemapsAllPerVertexData() {
        val m = fixture()
        val seam = SeamAwareUvUnwrapper.edgeKey(1, 2)
        val result = SeamAwareUvUnwrapper.unwrap(m, setOf(seam), .02f)
        assertEquals(2, result.islandCount)
        assertEquals(2, result.splitVertices)
        assertEquals(6, result.model.vertexCount)
        assertEquals(18, result.model.positions.size)
        assertEquals(24, result.model.boneWeights.size)
        assertEquals(24, result.model.boneIndices.size)
        assertEquals(54, result.model.sdef!!.size)
        assertEquals(24, result.model.addUvs.size)
        assertEquals(6, result.model.weightTypes.size)
        assertEquals(6, result.model.edgeScale.size)
        assertEquals(4, result.model.morphs[0].vertexIdx!!.size)
        assertEquals(12, result.model.morphs[0].vertexDelta!!.size)
        assertEquals(6, result.model.materials[0].indexCount)
        assertEquals(1, result.model.indexSizes[0])
        assertTrue(result.model.uvs.all { it.isFinite() && it in 0f..1f })
        assertFalse(result.model.uvs.contentEquals(m.uvs))
    }

    @Test fun unwrapWithoutSeamKeepsOneChartAndOriginalVertexCount() {
        val m = fixture()
        val result = SeamAwareUvUnwrapper.unwrap(m)
        assertEquals(1, result.islandCount)
        assertEquals(0, result.splitVertices)
        assertEquals(m.vertexCount, result.model.vertexCount)
        assertEquals(m.indices.size, result.model.indices.size)
    }

    @Test fun sharpAngleAndMaterialBordersGenerateSeams() {
        val m = fixture()
        assertTrue(SeamAwareUvUnwrapper.seamsByAngle(m, 10f).contains(SeamAwareUvUnwrapper.edgeKey(1, 2)))
        val secondMaterial = PmxMaterial("face2", "face2", floatArrayOf(1f, 1f, 1f, 1f), floatArrayOf(0f, 0f, 0f), 1f,
            floatArrayOf(0f, 0f, 0f), 0, floatArrayOf(0f, 0f, 0f, 1f), 0f, -1, -1, 0, false, 0, 3)
        val twoMats = PmxModel(m.name, m.version, m.positions, m.normals, m.uvs, m.boneIndices, m.boneWeights, m.indices,
            m.textures, listOf(m.materials[0].let { PmxMaterial(it.name, it.nameEn, it.diffuse, it.specular, it.specularPower, it.ambient,
                it.flags, it.edgeColor, it.edgeSize, it.textureIndex, it.sphereIndex, it.sphereMode, it.toonShared, it.toonIndex, 3) }, secondMaterial),
            m.bones, m.morphs)
        assertTrue(SeamAwareUvUnwrapper.seamsAtMaterialBorders(twoMats).contains(SeamAwareUvUnwrapper.edgeKey(1, 2)))
    }

    @Test fun unwrapUpgradesVertexIndexWidthWhenNoRawBlocksExist() {
        val base = fixture()
        val positions = FloatArray(255 * 3).also { base.positions.copyInto(it) }
        val model = PmxModel(base.name, base.version, positions, FloatArray(255 * 3), FloatArray(255 * 2),
            IntArray(255 * 4) { -1 }, FloatArray(255 * 4), base.indices, base.textures, base.materials, base.bones,
            emptyList(), indexSizes = intArrayOf(1, 1, 1, 1, 1, 1))
        val result = SeamAwareUvUnwrapper.unwrap(model, setOf(SeamAwareUvUnwrapper.edgeKey(1, 2)))
        assertFalse(result.aborted)
        assertEquals(257, result.model.vertexCount)
        assertEquals(2, result.model.indexSizes[0])
    }

    @Test fun unwrapRefusesUnsafeIndexWidthUpgradeWhenRawPmXBlocksExist() {
        val base = fixture()
        val positions = FloatArray(255 * 3).also { base.positions.copyInto(it) }
        val rawMorph = PmxMorph("uv", "uv", 0, 3, raw = byteArrayOf(1, 2, 3), count = 1)
        val model = PmxModel(base.name, base.version, positions, FloatArray(255 * 3), FloatArray(255 * 2),
            IntArray(255 * 4) { -1 }, FloatArray(255 * 4), base.indices, base.textures, base.materials, base.bones,
            listOf(rawMorph), indexSizes = intArrayOf(1, 1, 1, 1, 1, 1))
        val result = SeamAwareUvUnwrapper.unwrap(model, setOf(SeamAwareUvUnwrapper.edgeKey(1, 2)))
        assertTrue(result.aborted)
        assertEquals(model.vertexCount, result.model.vertexCount)
        assertTrue(result.model === model)
        assertTrue(result.warnings.any { it.contains("Unwrap cancelado") })
    }

    @Test fun extrudeBuildsTopAndBoundaryWallsAndRemapsVertexData() {
        val m = fixture()
        val result = MeshEditing.extrudeFacesInsideSelection(m, intArrayOf(0, 1, 2, 3), .3f, 0f)
        assertFalse(result.aborted)
        assertEquals(10, result.changedFaces)
        assertEquals(8, result.model.vertexCount)
        assertEquals(36, result.model.indices.size)
        assertEquals(36, result.model.materials[0].indexCount)
        assertEquals(32, result.model.boneWeights.size)
        assertEquals(72, result.model.sdef!!.size)
        assertEquals(32, result.model.addUvs.size)
        assertEquals(8, result.model.weightTypes.size)
        assertEquals(8, result.model.edgeScale.size)
        assertEquals(4, result.model.morphs[0].vertexIdx!!.size)
        assertTrue(result.model.normals.all { it.isFinite() })
        assertTrue(result.model.positions[14] > m.positions[2])
    }

    @Test fun insetShrinksTheExtrudedPatchTowardItsCenter() {
        val m = fixture()
        val result = MeshEditing.extrudeFacesInsideSelection(m, intArrayOf(0, 1, 2, 3), 0f, .5f)
        assertEquals(8, result.model.vertexCount)
        val old = m.positions
        val new = result.model.positions
        assertTrue(new[12] > old[0])
        assertTrue(new[13] > old[1])
        assertTrue(new[14] > old[2])
    }

    @Test fun deleteSelectedFacesUpdatesMaterialRangesAndPreservesVertices() {
        val m = fixture()
        val result = MeshEditing.deleteFacesInsideSelection(m, intArrayOf(0, 1, 2))
        assertEquals(1, result.changedFaces)
        assertArrayEquals(intArrayOf(2, 1, 3), result.model.indices)
        assertEquals(3, result.model.materials[0].indexCount)
        assertEquals(m.vertexCount, result.model.vertexCount)
        assertEquals(m.morphs[0].vertexIdx!!.size, result.model.morphs[0].vertexIdx!!.size)
    }

    @Test fun faceWindingFlipRecalculatesNormals() {
        val m = fixture()
        val result = MeshEditing.flipFacesInsideSelection(m, intArrayOf(0, 1, 2))
        assertEquals(1, result.changedFaces)
        assertArrayEquals(intArrayOf(0, 2, 1, 2, 1, 3), result.model.indices)
        assertTrue(result.model.normals.all { it.isFinite() })
    }

    @Test fun degenerateTrianglesAreRemovedWithoutCorruptingMaterialCounts() {
        val m = fixture(intArrayOf(0, 1, 2, 1, 1, 3))
        val result = MeshEditing.removeDegenerateFaces(m)
        assertEquals(1, result.changedFaces)
        assertArrayEquals(intArrayOf(0, 1, 2), result.model.indices)
        assertEquals(3, result.model.materials[0].indexCount)
    }
}
