package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.scene.OutlinerState

class OutlinerStateTest {
    private val nat = listOf("model", "prop:a", "prop:b", "char:c", "light", "camera", "audio")

    @Test fun renameAndRoundTrip() {
        var s = OutlinerState().rename("model", "  Heroína ").toggleLock("prop:a").toggleRenderOff("char:c")
        s = s.makeGroup(listOf("prop:a", "prop:b"), "g1", "Cenário").toggleCollapse("grp:g1")
        s = s.move("char:c", -1, nat)
        val r = OutlinerState.Codec.fromJson(s.toJson())
        assertTrue(r.warnings.isEmpty()); assertEquals(s, r.state)
        assertEquals("Heroína", r.state.nameOf("model", "x"))
    }
    @Test fun blankNameIgnoredAndLightNotLockable() {
        val s = OutlinerState().rename("model", "  ").toggleLock("light").toggleLock("model")
        assertTrue(s.names.isEmpty()); assertTrue(s.locked.isEmpty())
    }
    @Test fun groupArrangeAndCollapse() {
        val s = OutlinerState().makeGroup(listOf("prop:a", "prop:b"), "g1", "Cenário")
        val rows = s.arrange(nat)
        assertEquals(listOf("model", "char:c", "light", "camera", "audio", "grp:g1", "prop:a", "prop:b"), rows.map { it.key })
        assertEquals(1, rows.first { it.key == "prop:a" }.indent)
        val c = s.toggleCollapse("grp:g1").arrange(nat).map { it.key }
        assertFalse("prop:a" in c); assertTrue("grp:g1" in c)
    }
    @Test fun ungroupKeepsObjects() {
        val s = OutlinerState().makeGroup(listOf("prop:a"), "g1", "G").ungroup("grp:g1")
        assertTrue(s.groups.isEmpty()); assertTrue("prop:a" in s.arrange(nat).map { it.key })
    }
    @Test fun moveInsideGroupAndRoot() {
        var s = OutlinerState().makeGroup(listOf("prop:a", "prop:b"), "g1", "G")
        s = s.move("prop:b", -1, nat)
        assertEquals(listOf("prop:b", "prop:a"), s.group("grp:g1")!!.members)
        val r = OutlinerState().move("prop:b", -1, nat).arrange(nat).map { it.key }
        assertEquals(listOf("model", "prop:b", "prop:a"), r.take(3))
    }
    @Test fun forgetAndPruneLeaveNoInvalidReference() {
        var s = OutlinerState().rename("prop:a", "x").toggleLock("prop:a").toggleRenderOff("prop:a")
            .makeGroup(listOf("prop:a", "prop:b"), "g1", "G")
        s = s.forget("prop:a")
        assertTrue(s.names.isEmpty() && s.locked.isEmpty() && s.renderOff.isEmpty())
        assertEquals(listOf("prop:b"), s.group("grp:g1")!!.members)
        s = s.forget("prop:b"); assertTrue(s.groups.isEmpty())
        val p = OutlinerState().makeGroup(listOf("char:z"), "g2", "G").prune(setOf("model"))
        assertTrue(p.groups.isEmpty())
    }
    @Test fun addToGroupMovesBetweenGroups() {
        val s = OutlinerState().makeGroup(listOf("prop:a"), "g1", "A").makeGroup(listOf("prop:b"), "g2", "B").addToGroup("prop:a", "grp:g2")
        assertNull(s.group("grp:g1")); assertEquals(listOf("prop:b", "prop:a"), s.group("grp:g2")!!.members)
    }
    @Test fun corruptedAndNewerVersionAreSafe() {
        assertEquals(1, OutlinerState.Codec.fromJson("{ruim").warnings.size)
        assertEquals(OutlinerState(), OutlinerState.Codec.fromJson("""{"formatVersion":9}""").state)
        val d = OutlinerState.Codec.fromJson("""{"formatVersion":1,"groups":[{"id":"g","members":["a"]},{"id":"g","members":["b"]},{"id":"h","members":["a"]}]}""")
        assertEquals(1, d.state.groups.size); assertTrue(d.warnings.isNotEmpty())
    }

    @Test fun historyUndoRedo() {
        val h = studio.mmd.scene.History<Int>(3)
        assertFalse(h.canUndo); assertNull(h.undo(0))
        h.push(1); h.push(2)                    // estados anteriores 1, 2; atual 3
        assertEquals(2, h.undo(3)); assertEquals(1, h.undo(2))
        assertTrue(h.canRedo); assertEquals(2, h.redo(1)); assertEquals(3, h.redo(2)); assertNull(h.redo(3))
        h.push(9); assertFalse(h.canRedo)       // nova mudança zera o refazer
        h.push(10); h.push(11); h.push(12)      // limite 3: o mais antigo cai
        assertEquals(12, h.undo(0)); assertEquals(11, h.undo(0)); assertEquals(10, h.undo(0)); assertNull(h.undo(0))
    }

    @Test fun makeGroupWithManyKeys() {
        val st = OutlinerState().makeGroup(listOf("model", "prop:a", "char:b", "prop:a", "camera"), "g1", "Grupo 1")
        assertEquals(1, st.groups.size)
        assertEquals(listOf("model", "prop:a", "char:b"), st.groups[0].members)   // repetido e não agrupável ignorados
    }
}
