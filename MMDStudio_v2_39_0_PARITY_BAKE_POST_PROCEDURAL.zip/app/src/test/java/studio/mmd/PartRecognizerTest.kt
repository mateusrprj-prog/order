package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import studio.mmd.rig.*

/** v1.32.0 — Editor de Partes: reconhecimento combinado, correções manuais, divisão e ligação com o movimento secundário. */
class PartRecognizerTest {
    private fun bone(n: String, x: Float, y: Float, z: Float, p: Int, en: String = n) = PmxBone(n, en, x, y, z, p, 0, 0x001F, -1, -1, 0f, null)
    private fun mat(n: String, count: Int) = PmxMaterial(n, "", floatArrayOf(1f, 1f, 1f, 1f), FloatArray(3), 5f, FloatArray(3), 1, floatArrayOf(0f, 0f, 0f, 1f), 1f, -1, -1, 0, true, 0, count)
    private fun rigid(n: String, b: Int, mode: Int) = PmxRigid(n, "", b, 0, 1, 1f, 0.5f, 0.5f, mode)

    /** 12 ossos, 3 corpos rígidos, 3 materiais (9 vértices). Índices dos ossos nos comentários. */
    private fun model(): PmxModel {
        val bones = listOf(
            bone("センター", 0f, 8f, 0f, -1),          // 0 corpo
            bone("下半身", 0f, 8f, 0f, 0),            // 1 corpo
            bone("スカート前", 0f, 7f, -1f, 1),        // 2 saia
            bone("先端", 0f, 6f, -1.5f, 2),           // 3 sem nome útil, filho da saia
            bone("スカート後", 0f, 7f, 1f, 1),         // 4 saia
            bone("頭", 0f, 14f, 0f, 0),               // 5 corpo
            bone("左髪1", 1f, 15f, 0f, 5),             // 6 cabelo
            bone("謎ボーン", 0f, 9f, 0f, 0),           // 7 tem física, sem nome reconhecível
            bone("左腕", 2f, 12f, 0f, 0),              // 8 corpo
            bone("左袖", 3f, 12f, 0f, 8),              // 9 manga esquerda
            bone("右袖", -3f, 12f, 0f, 8),             // 10 manga direita
            bone("Neck", 0f, 13f, 0f, 0, "neck")       // 11 corpo (nome em inglês)
        )
        val rbs = listOf(rigid("スカート前", 2, 1), rigid("謎剛体", 7, 1), rigid("左髪1", 6, 2))
        val mats = listOf(mat("肌", 3), mat("材質2", 3), mat("スカート", 3))
        val pos = FloatArray(27); val zs = floatArrayOf(0f, 0f, 0f, -1f, -1f, -1f, 0f, 0f, 0f)
        for (v in 0 until 9) pos[v * 3 + 2] = zs[v]
        val bi = IntArray(36) { -1 }; val bw = FloatArray(36)
        val vertBone = intArrayOf(0, 0, 0, 2, 2, 2, 0, 0, 0)     // m1 pesa 100% no osso da saia
        for (v in 0 until 9) { bi[v * 4] = vertBone[v]; bw[v * 4] = 1f }
        return PmxModel("t", 2f, pos, FloatArray(27), FloatArray(18), bi, bw, IntArray(9) { it }, emptyList(), mats, bones, emptyList(), rigidBodies = rbs)
    }

    private fun PartReport.el(key: String) = parts.flatMap { it.elements }.firstOrNull { it.key == key }
    private fun PartReport.part(id: String) = parts.firstOrNull { it.id == id }

    @Test fun skirtBonesRigidAndWeightedMaterialGroupTogether() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        val skirt = r.part("skirt|")!!
        assertTrue(skirt.bones.map { it.name }.containsAll(listOf("スカート前", "先端", "スカート後")))
        assertEquals(PartCat.SKIRT, r.el("rigid:0:スカート前")!!.category)
        assertEquals(PartCat.SKIRT, r.el("mat:1:材質2")!!.category)           // só os pesos dos vértices indicam a saia
        assertNotEquals(PartLevel.REVIEW, r.el("mat:1:材質2")!!.level)
        // bone com nome + corpo rígido + física concordam: confiança alta
        assertEquals(PartLevel.HIGH, r.el("bone:スカート前")!!.level)
    }

    @Test fun boneWithoutUsefulNameInheritsFromParentChainWithLowerConfidence() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        val e = r.el("bone:先端")!!
        assertEquals(PartCat.SKIRT, e.category)
        assertTrue(e.evidence.any { it.contains("herda") })
        assertTrue(e.confidence < r.el("bone:スカート前")!!.confidence)
    }

    @Test fun materialNameAloneNeverReachesHighConfidence() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        val e = r.el("mat:2:スカート")!!
        assertEquals(PartCat.SKIRT, e.category)
        assertTrue(e.confidence < 0.5f)
        assertNotEquals(PartLevel.HIGH, e.level)
    }

    @Test fun dynamicBoneWithoutNameIsListedAsUnknownForReview() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        val u = r.part("unknown|")!!
        assertTrue(u.elements.any { it.key == "bone:謎ボーン" })
        assertTrue(u.needsReview)
        assertTrue(r.reviewCount >= 1)
    }

    @Test fun standardBodyBonesNeverBecomeParts() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        for (n in listOf("センター", "下半身", "頭", "左腕", "Neck")) assertNull("$n não deve ser parte", r.el("bone:$n"))
    }

    @Test fun sidedCategoriesSplitByNameAndOthersDoNot() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides())
        assertNotNull(r.part("sleeve|Esquerda")); assertNotNull(r.part("sleeve|Direita"))
        assertNotNull(r.part("hair|"))          // cabelo não é dividido por lado automaticamente
        assertEquals("左髪1", r.part("hair|")!!.bones.single().name)
    }

    @Test fun englishNamesUseWordMatchingNotSubstrings() {
        val bones = listOf(bone("Center", 0f, 8f, 0f, -1, "center"), bone("Hair_L", 1f, 15f, 0f, 0), bone("chair", 0f, 1f, 0f, 0), bone("ponytail", 0f, 15f, 1f, 0), bone("Head", 0f, 14f, 0f, 0, "head"))
        val m = PmxModel("e", 2f, FloatArray(0), FloatArray(0), FloatArray(0), IntArray(0), FloatArray(0), IntArray(0), emptyList(), emptyList(), bones, emptyList())
        val r = PartRecognizer.build(PartRecognizer.analyze(m), PartOverrides())
        assertEquals(PartCat.HAIR, r.el("bone:Hair_L")!!.category)
        assertNull(r.el("bone:chair"))
        assertEquals(PartCat.TAIL_HAIR, r.el("bone:ponytail")!!.category)   // "ponytail" não vira "tail" (cauda)
        assertNull(r.el("bone:Head"))
    }

    @Test fun sideDetection() {
        assertEquals("Esquerda", PartRecognizer.sideOf("左袖"))
        assertEquals("Direita", PartRecognizer.sideOf("Sleeve_R"))
        assertEquals("Esquerda", PartRecognizer.sideOf("arm.L"))
        assertEquals("", PartRecognizer.sideOf("Lace"))
        assertEquals("", PartRecognizer.sideOf("Hair"))
    }

    @Test fun manualOverridePrevailsAndIsConfirmed() {
        val a = PartRecognizer.analyze(model())
        val o = PartOverrides().withAssign(listOf("bone:謎ボーン"), PartAssign(PartCat.HAIR))
        val r = PartRecognizer.build(a, o)
        val e = r.el("bone:謎ボーン")!!
        assertEquals(PartCat.HAIR, e.category); assertTrue(e.manual); assertEquals(PartLevel.CONFIRMED, e.level)
        assertTrue(r.part("hair|")!!.bones.any { it.name == "謎ボーン" })
        assertNull(r.part("unknown|")?.elements?.firstOrNull { it.key == "bone:謎ボーン" })
    }

    @Test fun userCanAddAnElementTheAutomaticRecognitionIgnored() {
        val a = PartRecognizer.analyze(model())
        val r = PartRecognizer.build(a, PartOverrides().withAssign(listOf("bone:左腕"), PartAssign(PartCat.COAT)))
        assertEquals(PartCat.COAT, r.el("bone:左腕")!!.category)
    }

    @Test fun removingFromPartsMovesElementToNone() {
        val a = PartRecognizer.analyze(model())
        val r = PartRecognizer.build(a, PartOverrides().withAssign(listOf("bone:スカート後"), PartAssign(PartCat.NONE)))
        assertTrue(r.part("none|")!!.elements.any { it.name == "スカート後" })
        assertFalse(r.part("skirt|")!!.bones.any { it.name == "スカート後" })
        assertTrue(r.summary.isNotEmpty())
    }

    @Test fun codecRoundTripAndSafeFallbacks() {
        val o = PartOverrides().withAssign(listOf("bone:a", "mat:1:x"), PartAssign(PartCat.SKIRT, "Frente")).withPhysics("skirt|", false)
        assertEquals(o, PartOverridesIo.fromJson(PartOverridesIo.toJson(o)))
        assertTrue(PartOverridesIo.fromJson("isto nao e json").isEmpty)
        assertTrue(PartOverridesIo.fromJson("{\"v\":99,\"assign\":[{\"k\":\"bone:a\",\"c\":\"hair\"}]}").isEmpty)   // versão futura
    }

    @Test fun profileCodecCarriesPartsAndOldFilesStillLoad() {
        val cfg = RigConfig().apply { parts = PartOverrides().withAssign(listOf("bone:x"), PartAssign(PartCat.HAIR)) }
        assertEquals(cfg.parts, CharacterRigProfileCodec.decode(CharacterRigProfileCodec.encode(cfg)).parts)
        // arquivo da v1.31.0 (sem o campo "parts")
        assertTrue(CharacterRigProfileCodec.decode("{\"formatVersion\":1,\"constraints\":\"[]\",\"secondary\":\"[]\",\"physics\":\"{}\"}").parts.isEmpty)
    }

    @Test fun overrideForAnotherModelIsIgnoredAndCounted() {
        val r = PartRecognizer.build(PartRecognizer.analyze(model()), PartOverrides().withAssign(listOf("mat:99:inexistente", "bone:nao-existe"), PartAssign(PartCat.HAIR)))
        assertEquals(2, r.orphanOverrides)
        assertNull(r.el("mat:99:inexistente"))
    }

    @Test fun splitFrontBackUsesPositionsOfBonesAndMaterials() {
        val m = model()
        val a = PartRecognizer.analyze(m)
        val base = PartRecognizer.build(a, PartOverrides())
        val o = PartRecognizer.splitPart(m, base.part("skirt|")!!, 2, PartOverrides())
        val r = PartRecognizer.build(a, o)
        val front = r.part("skirt|Frente")!!; val back = r.part("skirt|Trás")!!
        assertTrue(front.bones.map { it.name }.containsAll(listOf("スカート前", "先端")))
        assertEquals(listOf("スカート後"), back.bones.map { it.name })
        assertTrue(front.materials.any { it.name == "材質2" })        // centróide dos vértices em z = −1
    }

    @Test fun applyToSecondaryCreatesStableGroupsAndKeepsOthers() {
        val m = model()
        val r = PartRecognizer.build(PartRecognizer.analyze(m), PartOverrides())
        val mine = Secondary("m1", "Meu grupo", listOf("左腕"))
        val (list, msg) = PartRecognizer.applyToSecondary(m, r, listOf(mine))
        assertTrue(msg.isNotEmpty())
        assertTrue(list.any { it.id == "m1" })
        val g = list.first { it.id == "part:skirt|" }
        assertTrue(g.bones.containsAll(listOf("スカート前", "先端", "スカート後")))
        assertEquals(1, g.preset)                                       // preset "Saia/roupa"
        assertTrue(list.none { it.id.startsWith("part:unknown") || it.id.startsWith("part:body") })
        // reaplicar não duplica e preserva o ajuste fino feito no grupo
        val tweaked = list.map { if (it.id == "part:skirt|") it.copy(intensity = 0.2f) else it }
        val (again, _) = PartRecognizer.applyToSecondary(m, r, tweaked)
        assertEquals(list.size, again.size)
        assertEquals(0.2f, again.first { it.id == "part:skirt|" }.intensity, 0.0001f)
        // desligar a física da parte remove o grupo dela
        val off = PartRecognizer.build(PartRecognizer.analyze(m), PartOverrides().withPhysics("skirt|", false))
        assertTrue(PartRecognizer.applyToSecondary(m, off, again).first.none { it.id == "part:skirt|" })
    }

    @Test fun freeNamedGroupSplitsPartAndFeedsSecondary() {
        val m = model()
        val a = PartRecognizer.analyze(m)
        val o = PartOverrides().withAssign(listOf("bone:スカート前", "bone:先端"), PartAssign(PartCat.SKIRT, PartRecognizer.sanitizeGroup("  Barra | da:saia ")))
        val r = PartRecognizer.build(a, o)
        val g = r.part("skirt|Barra da saia")!!
        assertEquals(setOf("スカート前", "先端"), g.bones.map { it.name }.toSet())
        assertEquals(listOf("スカート後"), r.part("skirt|")!!.bones.map { it.name })
        assertTrue(PartRecognizer.applyToSecondary(m, r, emptyList()).first.any { it.id == "part:skirt|Barra da saia" })
        assertEquals("", PartRecognizer.sanitizeGroup(" | : "))
        assertEquals(24, PartRecognizer.sanitizeGroup("x".repeat(60)).length)
    }
}
