package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import studio.mmd.rig.*

class PmxSoftBodyRuntimeTest {
    private fun model(): PmxModel {
        val p = floatArrayOf(0f,0f,0f, 1f,0f,0f, 1f,1f,0f, 0f,1f,0f, 8f,8f,8f)
        val m = PmxMaterial("cloth","cloth", floatArrayOf(1f,1f,1f,1f), floatArrayOf(0f,0f,0f), 1f,
            floatArrayOf(0f,0f,0f), 0, floatArrayOf(0f,0f,0f,1f), 1f, -1,-1,0,true,0,6)
        val rb = PmxRigid("anchor","anchor",-1,0,0,1f,0f,0f,0,0,floatArrayOf(1f,1f,1f),floatArrayOf(0f,0f,0f),floatArrayOf(0f,0f,0f))
        val sb = PmxSoftBody("cloth","cloth",0,0,0,0,0,0,0,1f,0.02f,1,
            FloatArray(12).also { it[1]=0.03f }, FloatArray(6), intArrayOf(4,8,1,1), intArrayOf(80,35,10),
            listOf(PmxSoftBodyAnchor(0,0,false)), intArrayOf(3))
        return PmxModel("test",2.1f,p,FloatArray(p.size),FloatArray(10),IntArray(20){-1},FloatArray(20),
            intArrayOf(0,1,2,0,2,3), emptyList(),listOf(m),emptyList(),emptyList(), listOf(rb), emptyList(), softBodies=listOf(sb))
    }

    @Test fun materialFacesRemapToLocalParticles() {
        val runtime = PmxSoftBodyRuntime.create(model(),0)
        assertArrayEquals(intArrayOf(0,1,2,0,2,3),runtime.localTriangles)
        assertArrayEquals(intArrayOf(0,1,2,3),runtime.sourceVertices)
        assertEquals(4,runtime.stats.particles)
        assertEquals(2,runtime.stats.triangles)
    }

    @Test fun pinsAndAnchorsAreCountedAndCanMove() {
        val runtime = PmxSoftBodyRuntime.create(model(),0)
        assertEquals(2,runtime.stats.pins)
        assertEquals(1,runtime.stats.anchors)
        runtime.updateAnchorTargets(mapOf(0 to floatArrayOf(2f,0f,0f)))
        val p = runtime.step(1f/60f, gravityY=0f, iterations=4)
        assertEquals(2f,p[0],0.01f)
    }

    @Test fun scatterOnlyTouchesSourceVertices() {
        val runtime = PmxSoftBodyRuntime.create(model(),0)
        val positions = model().positions.copyOf()
        val simulated = runtime.step(1f/60f,gravityY=0f)
        runtime.scatterInto(positions,simulated)
        assertEquals(8f,positions[12],0f)
    }

    @Test fun invalidMaterialIsRejected() {
        val m = model(); val sb = PmxSoftBody("bad","bad",0,5,0,0,0,0,0,1f,0f,0,FloatArray(12),FloatArray(6),IntArray(4),IntArray(3), emptyList(),IntArray(0))
        val bad = PmxModel(m.name,m.version,m.positions,m.normals,m.uvs,m.boneIndices,m.boneWeights,m.indices,m.textures,m.materials,m.bones,m.morphs,m.rigidBodies,m.joints,
            m.nameEn,m.comment,m.commentEn,m.displayFrames,m.addUvCount,m.addUvs,m.weightTypes,m.sdef,m.edgeScale,m.textEncoding,m.indexSizes,m.softBodyCount,m.softBodyRaw,m.warnings,listOf(sb))
        try { PmxSoftBodyRuntime.create(bad,0); throw AssertionError("material inválido deveria ser recusado") } catch (_: IllegalArgumentException) { }
    }

    @Test fun particleLimitPreventsHugeAllocation() {
        try { PmxSoftBodyRuntime.create(model(),0,PmxSoftBodyRuntimeConfig(maxVertices=3)); throw AssertionError("limite deveria bloquear") } catch (_: IllegalArgumentException) { }
    }
}
