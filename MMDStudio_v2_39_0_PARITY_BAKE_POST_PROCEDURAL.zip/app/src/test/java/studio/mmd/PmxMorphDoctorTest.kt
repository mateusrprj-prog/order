package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

class PmxMorphDoctorTest {
    private fun model(morphs: List<PmxMorph>, vertices: Int = 1, addUvCount: Int = 0, rigidCount: Int = 0) = PmxModel(
        "test", 2.1f, FloatArray(vertices * 3), FloatArray(vertices * 3), FloatArray(vertices * 2),
        IntArray(vertices * 4) { -1 }, FloatArray(vertices * 4), IntArray(0), emptyList(), emptyList(), emptyList(), morphs,
        rigidBodies = List(rigidCount) { PmxRigid("rb$it", "", -1, 0, 0, 1f, 0f, 0f, 1) },
        addUvCount = addUvCount, addUvs = FloatArray(vertices * addUvCount * 4)
    )
    private fun impulse(body: Int = 0): PmxMorph {
        val b = ByteBuffer.allocate(26).order(ByteOrder.LITTLE_ENDIAN).put(body.toByte()).put(1)
        repeat(6) { b.putFloat((it + 1).toFloat()) }
        return PmxMorph("impulse", "", 0, 10, raw = b.array(), count = 1)
    }
    private fun addUv(type: Int = 4, vertex: Int = 0): PmxMorph {
        val b = ByteBuffer.allocate(17).order(ByteOrder.LITTLE_ENDIAN).put(vertex.toByte())
        repeat(4) { b.putFloat(0.1f) }
        return PmxMorph("extra", "", 0, type, raw = b.array(), count = 1)
    }

    @Test fun detectsGroupCycles() {
        val a = PmxMorph("A", "", 0, 0, groupIdx = intArrayOf(1), groupRate = floatArrayOf(1f))
        val b = PmxMorph("B", "", 0, 0, groupIdx = intArrayOf(0), groupRate = floatArrayOf(1f))
        val report = PmxMorphDoctor.inspect(model(listOf(a,b)))
        assertTrue(report.issues.any { it.code == "graph.cycle" })
    }
    @Test fun detectsInvalidVertexMorphPayload() {
        val m = PmxMorph("bad", "", 0, 1, vertexIdx = intArrayOf(7), vertexDelta = floatArrayOf(0f, Float.NaN, 0f))
        val report = PmxMorphDoctor.inspect(model(listOf(m)))
        assertTrue(report.issues.any { it.code == "vertex.index" })
        assertTrue(report.issues.any { it.code == "vertex.non_finite" })
    }
    @Test fun validatesAdditionalUvChannelAvailability() {
        val report = PmxMorphDoctor.inspect(model(listOf(addUv()), addUvCount = 0))
        assertTrue(report.issues.any { it.code == "add_uv.channel_missing" })
    }
    @Test fun validatesImpulseBodyReferences() {
        val report = PmxMorphDoctor.inspect(model(listOf(impulse(body = 3)), rigidCount = 1))
        assertEquals(0, report.impulseRecords)
        assertTrue(report.issues.any { it.code == "impulse.record" })
    }
    @Test fun countsValidImpulseRecords() {
        val report = PmxMorphDoctor.inspect(model(listOf(impulse()), rigidCount = 1))
        assertEquals(1, report.impulseRecords)
        assertFalse(report.issues.any { it.code == "impulse.record" })
    }
    @Test fun reportsMalformedMaterialMorphPayload() {
        val malformed = PmxMorph("mat", "", 0, 8, raw = byteArrayOf(1), count = 1)
        val report = PmxMorphDoctor.inspect(model(listOf(malformed)))
        assertTrue(report.issues.any { it.code == "material.raw" })
    }
}
