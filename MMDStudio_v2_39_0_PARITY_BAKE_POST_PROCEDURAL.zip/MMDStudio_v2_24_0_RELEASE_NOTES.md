# MMD Studio 2.24.0 — Additional UV & Vertex Color

- Suporte aos morphs PMX 4–7 (Additional UV 1–4), incluindo vec4 completo.
- Upload dinâmico dos quatro canais adicionais para GPU quando presentes.
- Leitura do flag de vertex color PMX 2.1 (0x20) por material.
- Shader aplica a cor por vértice na difusa e alfa apenas quando ativado pelo material.
- Buffers e attributes extras são liberados/recriados com o modelo.
