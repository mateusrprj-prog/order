# MMD Studio 2.9.0 — Mesh Mask Studio

**Data:** 23/11/2026  
**versionCode:** 109  
**versionName:** 2.9.0

## Resumo

A versão 2.9.0 transforma a máscara de vértices em uma ferramenta prática de edição, acessível pela bancada Model Tools e ligada à viewport OpenGL. O novo fluxo combina pintura 3D, simetria, seleção topológica e correções de geometria limitadas pela influência da máscara.

## Novidades

### Mesh Mask Studio
- Nova classe `MeshMaskPaintSession`, com máscara FloatArray por vértice, valores entre 0 e 1 e armazenamento temporário independente do PMX.
- Pincel em coordenadas locais PMX. As amostras de um traço são ligadas por segmentos para reduzir lacunas em movimentos rápidos do dedo.
- Falloff smoothstep, modos REPLACE/ADD/SUBTRACT, raio, força, valor alvo e simetria refletida pelo centro da caixa delimitadora no eixo X.
- Ações de preencher seleção/toda malha, inverter, limpar, suavizar pela adjacência e Undo/Redo próprio.
- Máscaras automáticas Toda/Frente/Trás/Esquerda/Direita reaproveitando `SkirtGuardRegionWeights`.
- Preview ciano por vértices com influência acima de 0,05, limitado a 4.096 pontos no renderer.

### Seleção topológica e geodésica
- Seleção de componente conectado por BFS.
- Seleção geodésica por Dijkstra, usando comprimentos das arestas para não atravessar superfícies desconectadas apenas por estarem espacialmente próximas.
- Conversão de uma máscara para seleção através de limiar configurável.

### Correção localizada de geometria
- Relaxamento Taubin positivo/negativo guiado por máscara, com 1–16 iterações, intensidade e teto de deslocamento por vértice.
- Vértices fora da máscara não são movidos; máscara parcial atenua a correção.
- Preservação opcional de bordas abertas detectadas por arestas usadas uma única vez.
- Removedor heurístico de picos/espigões por escala local da vizinhança e correção máxima limitada.
- Recálculo de normais e integração com Undo/Redo geométrico já existente.

## Como usar

1. Abra um PMX e entre em **Model Tools**.
2. Em **Seleção**, use **Ilha conectada** ou **Raio geodésico** para selecionar uma peça coerente.
3. Abra **Máscaras** e gere uma região automática ou ative **Pintar máscara diretamente na viewport**.
4. Ajuste raio, força, alvo e modo. Ative o espelhamento X quando fizer sentido para a malha.
5. Use **Selecionar vértices pela máscara**, **Relaxar pela máscara**, **Micro relax** ou **Remover picos / espigões**.
6. Confira o resultado e use **Salvar no projeto** para gravar a geometria editada.

## Limitações conhecidas

- A máscara é temporária à sessão Model Tools; não é serializada no PMX nem no arquivo de projeto. Salvar o projeto grava as alterações geométricas, não a máscara para reedição posterior.
- O centro do pincel é o vértice visível mais próximo do ponto selecionado. A pintura não usa raycast barycêntrico nem interpolação por coordenadas de triângulo.
- O overlay é pontual/ciano e binário por limiar, não heatmap contínuo. É limitado a 4.096 pontos.
- Simetria X reflete através do centro da caixa delimitadora; não usa pares topológicos nem resolve correspondência de malhas assimétricas.
- O relaxamento usa média uniforme de vizinhos, não Laplaciano cotangente anisotrópico. A densidade/topologia da malha influencia o resultado.
- Remoção de picos é heurística e pode reduzir detalhes intencionais em geometrias irregulares. Use máscara localizada, limiar conservador e Undo.
- O núcleo e a sintaxe dos fontes foram validados localmente, mas o build Android/Compose runtime/GPU/aparelho não foi executado neste ambiente. Ver `MMDStudio_v2_9_0_TEST_RESULTS.txt`.

## Arquivos principais

- `app/src/main/java/studio/mmd/edit/MeshMaskPaintSession.kt`
- `app/src/main/java/studio/mmd/edit/ModelTools.kt`
- `app/src/main/java/studio/mmd/ui/ModelToolsPanel.kt`
- `app/src/main/java/studio/mmd/ui/SceneScreen.kt`
- `app/src/main/java/studio/mmd/render/SceneGLView.kt`
- `app/src/test/java/studio/mmd/MeshMaskStudioTest.kt`
