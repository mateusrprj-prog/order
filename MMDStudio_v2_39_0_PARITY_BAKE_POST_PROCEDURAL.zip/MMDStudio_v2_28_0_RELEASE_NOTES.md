# MMD Studio 2.28.0 — VMD Camera Evaluation Pro

**VersionCode:** 128  
**VersionName:** 2.28.0  
**Base:** MMD Studio 2.27.0  
**Entrega:** 7 marcos cumulativos de 2.22.0 a 2.28.0

## Implementação
- Troca a busca linear de keyframes de câmera por upper-bound/busca binária O(log n).
- Trata arrays de keyframes/interpolação incompletos sem exceção.
- Evita divisão por zero em frames duplicados, sanitiza frame não finito e limita o resultado aos keyframes extremos.
- Usa fallback linear quando os dados Bézier são ausentes, inválidos ou não monotônicos no eixo X.
- Mantém o buffer de saída reutilizável, sem criar objetos temporários por amostra.
- O caminho já usado pelo SceneGLView passa a consumir a avaliação otimizada automaticamente.

## Limites
A melhoria é na avaliação de câmera, não uma reescrita completa da interpolação de ossos/morphs. A equivalência exata de Bézier com MMD deve ser comparada com VMDs de referência; a velocidade e os valores na GPU/aparelho não foram medidos nesta sessão.

## Verificação de build
- Testes puros do núcleo Kotlin/JVM listados em `MMDStudio_v2_28_0_TEST_RESULTS.txt`.
- O build Android/Gradle, APK, Compose em runtime e OpenGL ES em dispositivo não foram executados nesta sessão.
