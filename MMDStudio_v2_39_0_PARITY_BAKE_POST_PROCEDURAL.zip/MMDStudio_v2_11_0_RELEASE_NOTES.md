# MMD Studio 2.11.0 — Mesh Mask Sculpt Pro

**VersionCode:** 111  
**VersionName:** 2.11.0  
**Base:** MMD Studio 2.10.0  
**Data:** 23/11/2026

A 2.11.0 transforma as máscaras pintadas em controles de deformação de superfície: inflar, encolher, pinçar, mover, achatar, escalar e girar. Inclui força contínua, limite de deslocamento por vértice, proteção opcional de bordas abertas e Undo/Redo geométrico.

Consulte `docs/REL_2_11_0.md` e `docs/MASK_SCULPT_PRO_WORKFLOW.md`.
