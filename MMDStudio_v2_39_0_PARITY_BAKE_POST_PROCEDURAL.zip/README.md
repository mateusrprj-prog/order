# MMD Studio 2.11.0 — Mesh Mask Sculpt Pro

A 2.11.0 continua a linha Mesh Mask Pro: a máscara pintada agora também dirige deformações locais com pesos contínuos — inflar, encolher, pinçar, mover, achatar, escalar e girar — com limite de deslocamento, proteção de bordas abertas e Undo/Redo geométrico. Consulte `docs/REL_2_11_0.md` e `docs/MASK_SCULPT_PRO_WORKFLOW.md`.

# MMD Studio (Android) — v2.11.0
Release **v2.11.0** (23/11/2026): **Mesh Mask Sculpt Pro**. A 2.10.0 permanece como base com pintura geodésica e presets `.mmdmask`; a 2.11.0 estende a máscara a sete deformações de malha controladas pelo valor 0..1 da máscara. Consulte `MMDStudio_v2_11_0_RELEASE_NOTES.md` e `MMDStudio_v2_11_0_TEST_RESULTS.txt`.

Release anterior **v2.7.0**: **Dynamics Pro + Swept Collision + Cache V4**. O Skirt Guard agora divide a trajetória das cápsulas animadas por subpasso físico e executa CCD temporal aproximada para reduzir tunneling em movimentos rápidos. A correção Auto-Fix pode ser aplicada por região angular (toda/frente/trás/esquerda/direita) com transição suave e limite de deslocamento. Após o bake, o painel informa qualidade das constraints e possíveis cruzamentos de triângulos; também há desfazer/refazer do último Auto-Fix do quadro final.

O cache XPBD formato 4 usa assinaturas FNV-1a 64-bit de dados PMX relevantes, curvas VMD de bones/morphs/IK e parâmetros/constantes do solver. Formatos antigos v1–v3 continuam legíveis, mas são preservados e não são reutilizados no novo bake; faça um bake completo para migrá-los. O bake parcial só mescla intervalos quando modelo, FPS, movimento e solver são exatamente compatíveis.

Limites: a CCD aproximada aplica-se a cápsulas; colisão corpo/triângulo continua discreta por quadro. O detector de cruzamentos triangulares é uma análise broadphase limitada, não um solver completo de auto-interseção e pode não detectar contatos coplanares. O histórico desfaz/refaz apenas a última correção do quadro final do bake, não toda a sequência. Preview CPU continua opcional e limitado conforme documentação.

Ver `docs/REL_2_7_0.md`, `docs/REL_2_7_0_TEST_RESULTS.txt` e `docs/DYNAMICS_PRO_WORKFLOW.md`.

Release anterior **v2.6.0**: Skirt Guard Pro + superfície corporal animada + bake incremental. Ver `docs/REL_2_6_0.md`.

App nativo Kotlin + Jetpack Compose + OpenGL ES 3.0 (renderização pela API GLES20 e shaders GLSL ES). Sem WebView/PWA.

## Status
v2.11.0: **MESH MASK SCULPT PRO** — inflar, encolher, pinçar, mover, achatar, escalar e girar por máscara, com limite por vértice, proteção opcional de bordas abertas e Undo/Redo geométrico. Ver `docs/REL_2_11_0.md`.

v2.10.0: **MESH MASK STUDIO PRO** — pintura 3D na viewport, pincel geodésico por arestas, simetria/falloff/modos, presets `.mmdmask` com assinatura e CRC, overlay amostrado, histórico Undo/Redo por orçamento conjunto e reamostragem robusta de traços longos. Núcleo Kotlin/JVM compilado; 15/15 testes focados; Kotlin PSI 133/133; ZIP íntegro. Build Android/APK/Compose runtime/GPU/dispositivo não validados. Ver `docs/REL_2_10_0.md` e `docs/REL_2_10_0_TEST_RESULTS.txt`.

v2.9.0: **MESH MASK STUDIO** — seleção geodésica, relaxamento Taubin e correção de picos guiada por máscara. Ver `docs/REL_2_9_0.md`.

v2.7.0: **DYNAMICS PRO + SWEPT COLLISION + CACHE V4** — CCD temporal aproximada de cápsulas segmentada por subpassos; correção regional com falloff; métricas de qualidade; diagnóstico limitado de cruzamentos triangulares; undo/redo da última correção do quadro final; cache vinculado a PMX/VMD/solver por hash 64-bit e leitura segura de versões anteriores sem reutilizá-las. Ver `docs/REL_2_7_0.md`.

v2.6.0: **SKIRT GUARD PRO + ANIMATED BODY SURFACE + INCREMENTAL CLOTH BAKE** — preview XPBD pode colidir com uma amostra limitada de triângulos corporais deformados; passo fixo com catch-up limitado; faixa de âncora ajustável; bake por intervalo. Ver `docs/REL_2_6_0.md`.

v2.5.0: **SKIRT GUARD STUDIO + LIVE PLAYBACK CLOTH** — diagnóstico manual de clipping, Auto-Fix limitado e preview da saia durante playback.

## Compilar e testar
- Android Studio: abrir a pasta e rodar `app`.
- Testes de parser: `gradle testDebugUnitTest` (JUnit, sem aparelho).
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).

## Cartoon Motion Library (v1.28.0)
Chip **Cartoon** na tela da cena: 30 movimentos originais em 8 categorias, prévia, aplicar com desfazer, importação de .vmd, velocidade/intensidade/loop/trecho/suavização e combinação por grupos de ossos. Squash & Stretch (P4) ainda não. Detalhes e roteiro de teste: `docs/MMD_Studio_Roadmap_Master_Production_Claude.md` (seção no fim).

## Assinatura do APK (v1.28.2)
O workflow gera `assembleDebug` (chave debug). Para build release: defina as variáveis `MMD_KEYSTORE_FILE` (caminho do .jks), `MMD_KEYSTORE_PASSWORD`, `MMD_KEY_ALIAS`, `MMD_KEY_PASSWORD` (no GitHub: Secrets; o .jks em base64 decodificado no workflow) ou crie `keystore.properties` na raiz com `storeFile`, `storePassword`, `keyAlias`, `keyPassword`. Nunca envie `.jks`/senhas ao repositório.



## 2.3.0 — Skirt Guard Auto
- Reconhecimento automático de regiões de saia por materiais PMX e evidência de pesos.
- Perfil/cache criado durante o parse de PMX, incluindo importações diretas.
- Sugestões de cápsulas para coxas e joelhos, com raio estimado pela distribuição de pesos.
- Detecção de ossos dedicados à saia e lista de vértices/materiais identificados.
- Perfil conservador: não altera pesos originais automaticamente.

## v2.8.0 — Mesh Quality & Soft Regions
- Mesh quality analysis: degenerate/invalid triangles, areas, edge statistics, stretch/collapse checks.
- Soft regional vertex masks with optional base mask and adjacency diffusion. See `docs/MESH_QUALITY_SOFT_REGIONS_WORKFLOW.md`.
