# MMD Studio 2.28.1 — Kotlin scope fix for GitHub Actions build

## Fixed
- Fixed `Unresolved reference: skirtProfile` in `SceneScreen.kt` (reported at line 2322 in the previous ZIP).
- The skirt profile was created inside the `withContext(Dispatchers.Default)` block but referenced in the bake summary outside that block.
- Captured the `detected` flag in a bake-scope Boolean and used that flag when building the final intersection summary. The profile itself remains scoped to the simulation worker.

## Package layout
- Gradle root files (`settings.gradle.kts`, `build.gradle.kts`) remain at the ZIP root, matching the workflow that extracts to `proj/` and runs `gradle assembleDebug` from `proj`.

## Validation performed
- Confirmed the source patch is present.
- Confirmed ZIP integrity and the Gradle root layout after extraction.
- Full Android Gradle build was not run in this environment (Gradle/Android SDK unavailable).
