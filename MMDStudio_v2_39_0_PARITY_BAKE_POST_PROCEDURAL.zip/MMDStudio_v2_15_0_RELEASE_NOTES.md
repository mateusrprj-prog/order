# MMD Studio 2.15.0 — Cloth Solver Safety Pro

**Android versionCode:** `115`  
**Base:** MMD Studio 2.11.0 + marcos cumulativos anteriores  
**Data:** 23/11/2026

## O que entrou nesta etapa
- Passo XPBD transacional: snapshot completo antes de simular e rollback integral quando uma etapa viola os limites de segurança.
- Detecção de coordenadas não finitas/absurdas, deslocamento extremo por passo e velocidade excessiva.
- Restauração de posições, histórico, velocidades, multiplicadores de constraints e cápsulas varridas no rollback.
- Guard opcional no solver normal e integrado ao caminho de playback com skinning da saia.
- Relatório do último passo e contador de rollbacks disponíveis na sessão de playback; reset limpa relatório, lambdas XPBD e cápsulas varridas.
- O passo clássico segue disponível para bake/offline sem guard, preservando compatibilidade de chamadas anteriores.

## Limites conhecidos
- O projeto mantém o parser/exportador e renderer existentes; esta atualização não declara compatibilidade total com todos os recursos do MMD oficial.
- Build Android/APK, Compose em runtime, OpenGL em aparelho e validação em dispositivo não foram executados neste ambiente.
- Reparo de dados nunca substitui revisão visual do modelo, rig ou animação; mantenha cópia do PMX/VMD original.
