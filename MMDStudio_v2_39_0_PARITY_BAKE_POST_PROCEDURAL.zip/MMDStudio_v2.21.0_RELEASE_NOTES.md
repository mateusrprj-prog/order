# MMD Studio 2.21.0 — PMX 2.1 Joint DOF Profiles

**Android versionCode:** `121`  
**Android versionName:** `2.21.0`  
**Base cumulativa:** `2.15.0` + 2.16.0, 2.17.0, 2.18.0, 2.19.0, 2.20.0

## Resumo
Perfis de graus de liberdade para os seis tipos de junta PMX 2.1 integrados ao PhysEngine, com aproximações explícitas para ConeTwist, Slider e Hinge.

### O que mudou
- Perfis PMX para os seis tipos de junta: Spring 6DOF, 6DOF, Point-to-Point, ConeTwist, Slider e Hinge.
- PhysEngine usa o perfil resolvido para limitar translação/rotação e aplicar molas quando cabível.
- Tipos não suportados por versões antigas são tratados como dados inválidos pelo Physics Doctor.
- Testes verificam os graus de liberdade e limites por tipo.

### Limite
O solver do app é um solver posicional próprio, não Bullet. ConeTwist, Slider e Hinge usam aproximações axiais no referencial local; comportamento numérico não é idêntico ao MMD/Bullet.

## Validação deste marco
- Código Kotlin/JVM dos núcleos alterados compilado isoladamente quando possível.
- Testes focados executados em runner JVM local com stubs de JUnit/Android apenas para as dependências externas necessárias; isso não substitui Gradle/JUnit oficial.
- Análise de sintaxe Kotlin aplicada aos arquivos de interface/renderer alterados; não resolve referências Android/Compose nem valida runtime GL.
- `unzip -t` aplicado ao pacote final.
- **Não gerado nesta sessão:** APK Android; não há Gradle/Wrapper nem Android SDK instalado no ambiente.
- **Não validado:** runtime Compose/OpenGL, desempenho GPU e teste em aparelho físico.
