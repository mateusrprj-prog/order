# MMD Studio 2.28.2 — SceneRenderer cloth-cache JVM setter clash fix

## Fixed
- Fixed the Kotlin compiler `Platform declaration clash` in `SceneRenderer` for `setClothCache(ClothBakeCache?)`.
- Renamed the renderer's backing property from `clothCache` to `cachedClothBake`.
- Kept the explicit `SceneRenderer.setClothCache(cache)` method, which resets skirt-guard playback after cache replacement.
- Kept the public `SceneGLView.setClothCache(cache)` facade unchanged; it still dispatches the update onto the GL thread and requests a render.
- Updated Android `versionCode` to 129 and `versionName` to 2.28.2.

## Why this fixes the reported compiler error
A Kotlin `var clothCache` generates a JVM setter named `setClothCache(ClothBakeCache)`. The class also declared an explicit function with that exact JVM signature. The backing property now has a different name, so only the explicit setter method remains.

## Validation
- Static check: no `clothCache` backing property remains in `SceneRenderer`.
- Static check: exactly one `setClothCache(ClothBakeCache?)` declaration remains inside `SceneRenderer`.
- Checked all renderer references use `cachedClothBake`; the outer `SceneGLView.setClothCache` API remains intact.
- ZIP integrity and extraction layout will be checked after packaging.
- Full Android Gradle build was not run in this environment; the GitHub Actions build is still required to verify downstream compilation errors.
