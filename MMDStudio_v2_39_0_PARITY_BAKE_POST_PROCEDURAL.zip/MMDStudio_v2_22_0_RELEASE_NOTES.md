# MMD Studio 2.22.0 — PMX 2.1 Soft Body Runtime

- Ponte PMX soft body → solver XPBD.
- Remapeamento material/triângulos/vertices.
- Pins e anchors por rigid body com offsets de repouso.
- Massa por vértice derivada da massa total.
- Damping/vento e iterações derivados dos parâmetros PMX (aproximação documentada).
- Colisores e rollback transacional.
- API `scatterInto` para atualizar posições do modelo.

Limite: não é Bullet e não implementa pressão, volume, clusters nem pose matching. O runtime ainda não é ativado automaticamente no viewport.
