# MMD Studio 2.23.0 — Material Morph Texture/Environment/Toon

- PMX material morph tipo 8 passa a ler os 3 vetores de tint RGBA: texture, sphere/environment e toon.
- Suporte a multiply/additive com acumuladores separados.
- Animator finaliza 12 canais por material.
- Renderer aplica textura base, sphere map e toon ramp tint nos shaders.
- Reset e neutral white validados.

Esta é a interpretação dos canais do registro PMX; compatibilidade visual exata com MMD/MME ainda requer comparação com fixtures oficiais.
