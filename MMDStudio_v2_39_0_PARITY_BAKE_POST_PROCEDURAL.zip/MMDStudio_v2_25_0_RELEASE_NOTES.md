# MMD Studio 2.25.0 — Point & Line Material Modes

- PMX material point flag e line flag passam a controlar o primitive mode do renderer.
- Point flag tem precedência sobre line flag.
- Novo índice expandido AB/BC/CA por face para GL_LINES.
- GL_POINTS com tamanho derivado de edgeSize.
- Outline passa a respeitar o primitive mode.
