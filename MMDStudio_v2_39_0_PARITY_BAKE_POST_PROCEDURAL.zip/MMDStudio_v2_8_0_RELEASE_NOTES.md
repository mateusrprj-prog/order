# MMD Studio 2.8.0 — Mesh Quality & Soft Regions

This release adds a mesh-quality diagnostic API and reusable soft regional correction masks.

## Features
- Analyze mesh triangle validity, degenerate triangles, area range/mean, unique edge length range/mean, and non-finite vertex count.
- When reference positions are provided, count stretched/collapsed unique edges by ratio thresholds.
- Generate per-vertex soft influence weights for `ALL`, `FRONT`, `BACK`, `LEFT`, `RIGHT`.
- Supports a base mask for material/selection gating and optional adjacency diffusion (0–32 iterations, amount 0–1).
- Base mask is reapplied after diffusion so zeroed vertices stay excluded.
- Four JUnit tests added.

## Verification
The new core module compiled with `kotlinc`; all four test methods were run through a lightweight JVM test harness with JUnit-compatible assertion stubs. This is targeted verification only. Full Gradle/JUnit, Android build/APK, Compose runtime and hardware tests were not run (Android SDK and Gradle wrapper/system Gradle unavailable).

## Integration status
Core utility API is available in the rig package. The viewport does not yet include paintable vertex-mask UI. Existing regional Auto-Fix remains separate and functional.
