# MMD Studio 2.33.0 e 2.34.0
Ver CHANGELOG.md. Limites: nada compilado/testado; fechar loop copia a pose com curva linear; inserir/apagar frames da câmera não mexe em áudio nem em ossos (use o Editor para eles).
