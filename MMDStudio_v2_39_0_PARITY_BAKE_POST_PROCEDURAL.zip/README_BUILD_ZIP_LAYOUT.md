# ZIP layout compatibility fix

Android Gradle project files are at the ZIP root. With `unzip -o *.zip -d proj`, these files land directly in `proj/`: `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, and `app/build.gradle.kts`. This matches `gradle assembleDebug` with `working-directory: proj`. ZIP structure was verified by extraction and file checks; an Android build was not executed here.
