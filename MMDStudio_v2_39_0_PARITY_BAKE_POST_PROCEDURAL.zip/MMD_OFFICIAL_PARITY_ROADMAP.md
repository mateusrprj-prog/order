# MMD Studio — Parity Roadmap (após 2.28.0)

Objetivo: aumentar compatibilidade prática com MikuMikuDance/PMX/VMD sem declarar equivalência antes de comparar resultados contra arquivos e aplicações de referência.

## Estado concluído nesta sequência
- PMX 2.1: adaptador experimental de soft body para XPBD (não Bullet; ainda não anexado automaticamente ao playback).
- Morph PMX: tint de textura/sphere/toon, Additional UV 1–4 e morph de impulso com API de evento manual.
- PMX 2.1 rendering: modos de pontos e linhas por material.
- Diagnóstico PMX: auditoria Morph Doctor integrada à bancada Check.
- VMD camera: avaliação O(log n) resiliente a dados inválidos/incompletos.

## Próximas frentes prioritárias
1. Integrar o runtime soft body à pose/skinning por frame, ao ciclo fixo de simulação e à sincronização de rigid bodies; preservar os dados PMX e permitir desligar/bakear o solver.
2. Implementar pressão/volume, clusters, pose matching, colisões contínuas e auto-colisão com limites de memória; validar com soft bodies de referência do MMD.
3. Comparar os seis tipos de joint e rigid bodies contra o comportamento real do MMD/Bullet, incluindo ordem de simulação, damping, limites, forças e estados de reset.
4. Ligar impulse morphs à timeline/VMD como evento de frame, garantindo disparo único no playback normal, scrub reversível e bake determinístico.
5. Expandir a comparação de morphs material/UV e primitive modes com PMX fixtures reais, incluindo todos os flags e casos de borda.
6. Verificar toon maps compartilhados/individuais, sphere modes, alpha, shadow/self-shadow e ordenação transparente contra renders capturados no MMD.
7. Otimizar buffers, draw calls, índices e cache de avaliação VMD para aparelhos Android de capacidade menor.
8. Criar uma suíte de conformidade com arquivos de referência PMX/PMD/VMD, fixtures de câmera/curvas, resultados binários e imagens de render golden.

## Critérios de aceitação para declarar paridade
- Round-trip PMX/VMD sem perda dos campos suportados e preservação explícita dos blocos desconhecidos.
- Comparação quadro a quadro com arquivos de referência, dentro de tolerâncias definidas para posição, rotação, câmera, física e cor.
- Build Gradle debug/release e testes Android instrumentados aprovados.
- Teste em aparelhos reais, incluindo estabilidade, uso de memória e desempenho de cenas grandes.
- Nenhum recurso descrito como “compatível com MMD” apenas por existir uma aproximação de API.

## Limitações da 2.28.0
- O soft body é uma ponte XPBD experimental e não Bullet SoftBody.
- Morph de impulso é disparado por API/evento explícito; ainda não há faixa VMD automática.
- Additional UV, shader toon e point/line foram integrados no código do renderer, mas não foram validados em GPU/aparelho nesta sessão.
- A câmera foi otimizada; a interpolação de todos os canais VMD ainda requer verificação comparativa integral.
- APK Android não foi gerado nesta sessão.

## Lacunas conhecidas vs. MMD oficial (auditoria 2.32.0)
Já existiam: VMD import/export, IK on/off, luz, self-shadow, visibilidade, câmera VMD, morph, física, PMX 2.1, retiming, repetir, suavizar, presets Bézier, VPD.
Entregues em motor nesta versão (ver `docs/REL_2_32_0.md`): inserir frames, reduzir keys, pai externo, rig de câmera, waveform/batidas, onion skin.
Ainda faltam (não implementados): UI do pai externo e integração no renderer/Animator; seguir osso da câmera na UI; waveform na timeline; onion skin no viewport; acessórios .x com keys de pai/escala/opacidade; DoF, bloom e motion blur; fundo de vídeo/imagem; multi-seleção por caixa de ossos; bake de interpolação para ossos com curva automática; comparação quadro a quadro com MMD real.
