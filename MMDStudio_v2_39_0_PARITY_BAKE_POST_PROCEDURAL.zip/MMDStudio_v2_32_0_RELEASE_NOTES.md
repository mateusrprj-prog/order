# MMD Studio 2.32.0 — Official Parity Tools

**versionCode 133 · versionName 2.32.0 · base 2.28.2**

## O que entrou
| Marco | Módulo | Estado |
|---|---|---|
| 2.29.0 | `mmd/MotionFrameOps.kt` — inserir/apagar/inverter frames, reduzir keys (ossos, morphs, câmera, extras) | Ligado na UI (Editor → trecho) |
| 2.30.0 | `mmd/OuterParent.kt` — pai externo com offset que mantém a pose de mundo | Só motor + testes |
| 2.31.0 | `mmd/CameraRig.kt`, `mmd/CameraRigActions.kt` — seguir osso, tremor, dolly zoom, órbita | Órbita/tremor/dolly ligados no painel Câmera; seguir osso só motor |
| 2.32.0 | `mmd/AnimationAids.kt` (waveform, batidas, onion skin) + `CurvePreset` | Só motor + testes |

Editor ganhou `insertFramesAll` e `reduceKeysAll` (via `replaceUndoable`, um passo de Desfazer).

## Limites (leia antes de testar)
- **Nada disto foi compilado nem executado**: o ambiente não tinha Kotlin, Gradle nem Android SDK. Rode `assembleDebug` e `testDebugUnitTest` no GitHub Actions; se houver erro de compilação, ele deve estar nos arquivos novos ou nos 3 pontos de integração (Editor.kt, EditPanels.kt, Outliner.kt/SceneScreen.kt).
- Reduzir keys assume interpolação linear entre vizinhos e preserva keys com curva não linear; é limpeza aproximada.
- Inserir frames não mexe no áudio nem no cache de tecido/física; refaça o bake depois.
- Órbita/tremor/dolly usam a convenção de ângulos de `VmdCamera.evaluate`, sem comparação com o MMD oficial.
- Pai externo, waveform/batidas e onion skin ainda não têm UI nem ligação no renderer.
- Não há equivalência declarada com o MMD oficial; ver `MMD_OFFICIAL_PARITY_ROADMAP.md`.
