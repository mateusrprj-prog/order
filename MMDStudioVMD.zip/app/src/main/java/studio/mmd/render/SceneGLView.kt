package studio.mmd.render

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLUtils
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.Animator
import studio.mmd.mmd.VmdMotion
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

enum class TouchMode { ORBIT, PAN }
enum class ViewPreset(val yaw: Float, val pitch: Float) {
    FRONT(0f, 0f), BACK(180f, 0f), LEFT(-90f, 0f), RIGHT(90f, 0f), TOP(0f, 89f), BOTTOM(0f, -89f)
}

/** Estado da câmera orbital, compartilhado entre a thread de toque e a thread GL. */
class OrbitCamera {
    @Volatile var yaw = 30f
    @Volatile var pitch = 20f
    @Volatile var dist = 12f
    @Volatile var tx = 0f
    @Volatile var ty = 1f
    @Volatile var tz = 0f

    fun reset() { yaw = 30f; pitch = 20f; dist = 12f; tx = 0f; ty = 1f; tz = 0f }
    fun eye(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf(
            tx + dist * (cos(p) * sin(y)).toFloat(),
            ty + dist * sin(p).toFloat(),
            tz + dist * (cos(p) * cos(y)).toFloat()
        )
    }
}

class SceneGLView(context: Context) : GLSurfaceView(context) {
    val camera = OrbitCamera()
    @Volatile var touchMode = TouchMode.ORBIT
    private val renderer = SceneRenderer(camera)
    private var lastX = 0f; private var lastY = 0f; private var lastCount = 0
    private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            camera.dist = (camera.dist / d.scaleFactor).coerceIn(1.5f, 80f); return true
        }
    })

    init {
        setEGLContextClientVersion(3)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun applyPreset(p: ViewPreset) { camera.yaw = p.yaw; camera.pitch = p.pitch; requestRender() }
    /** Envia o modelo para a thread GL (cria buffers e texturas lá). */
    fun loadModel(model: PmxModel, textures: List<ByteArray?>) {
        queueEvent { renderer.loadModel(model, textures); requestRender() }
    }

    fun setFrame(f: Int) { renderer.frame = f.toFloat(); requestRender() }
    fun setMotion(mo: VmdMotion?) { queueEvent { renderer.setMotion(mo); requestRender() } }

    fun frameAll() { camera.reset(); requestRender() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        val n = e.pointerCount
        val x = (0 until n).map { e.getX(it) }.average().toFloat()
        val y = (0 until n).map { e.getY(it) }.average().toFloat()
        if (e.actionMasked == MotionEvent.ACTION_MOVE && n == lastCount && !scale.isInProgress) {
            val dx = x - lastX; val dy = y - lastY
            if (n >= 2 || touchMode == TouchMode.PAN) {
                val k = camera.dist * 0.0015f
                val yr = Math.toRadians(camera.yaw.toDouble())
                camera.tx -= (cos(yr) * dx).toFloat() * k
                camera.tz += (sin(yr) * dx).toFloat() * k
                camera.ty += dy * k
            } else {
                camera.yaw -= dx * 0.4f
                camera.pitch = (camera.pitch + dy * 0.4f).coerceIn(-89f, 89f)
            }
        }
        lastX = x; lastY = y; lastCount = n
        if (e.actionMasked == MotionEvent.ACTION_UP) lastCount = 0
        requestRender()
        return true
    }
}

private class SceneRenderer(private val cam: OrbitCamera) : GLSurfaceView.Renderer {
    private var program = 0; private var aPos = 0; private var uMvp = 0; private var uColor = 0
    private val proj = FloatArray(16); private val view = FloatArray(16); private val mvp = FloatArray(16)
    private lateinit var gridBuf: java.nio.FloatBuffer; private var gridCount = 0
    private var model: GlModel? = null
    private var animator: Animator? = null
    @Volatile var frame = 0f
    private var lastFrame = -1f

    fun setMotion(mo: VmdMotion?) { animator?.motion = mo; lastFrame = -1f }

    private fun updateSkin() {
        val a = animator ?: return; val gm = model ?: return
        if (a.motion == null || frame == lastFrame) return
        lastFrame = frame
        a.evaluate(frame, gm.vd)
        gm.vbuf.position(0); gm.vbuf.put(gm.vd); gm.vbuf.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, gm.vd.size * 4, gm.vbuf)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }
    private var mProg = 0
    private val tmp = FloatArray(16)
    private lateinit var xAxis: java.nio.FloatBuffer; private lateinit var zAxis: java.nio.FloatBuffer

    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    private fun compile(type: Int, src: String) = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.02f, 0.025f, 1f)
        val vs = compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}")
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        val g = ArrayList<Float>()
        for (i in -10..10) { g += listOf(i.toFloat(), 0f, -10f, i.toFloat(), 0f, 10f, -10f, 0f, i.toFloat(), 10f, 0f, i.toFloat()) }
        gridCount = g.size / 3; gridBuf = fb(g.toFloatArray())
        mProg = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, MODEL_VS))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, MODEL_FS)); GLES20.glLinkProgram(it)
        }
        xAxis = fb(floatArrayOf(-10f, 0f, 0f, 10f, 0f, 0f))
        zAxis = fb(floatArrayOf(0f, 0f, -10f, 0f, 0f, 10f))
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h, 0.1f, 200f)
    }

    private fun draw(buf: java.nio.FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val e = cam.eye()
        val top = cam.pitch > 85f || cam.pitch < -85f
        val upY = if (top) 0f else 1f
        val upZ = if (top) (if (cam.pitch > 0) -1f else 1f) else 0f
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], cam.tx, cam.ty, cam.tz, 0f, upY, upZ)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        draw(gridBuf, gridCount, 0.22f, 0.22f, 0.25f)
        draw(xAxis, 2, 0.9f, 0.2f, 0.2f)   // eixo X (vermelho)
        draw(zAxis, 2, 0.2f, 0.4f, 1f)     // eixo Z (azul)
        GLES20.glDisableVertexAttribArray(aPos)
        updateSkin()
        drawModel()
    }

    private class MatDraw(val diffuse: FloatArray, val ambient: FloatArray, val tex: Int, val twoSided: Boolean, val offset: Int, val count: Int)
    private class GlModel(val vbo: Int, val ibo: Int, val texIds: IntArray, val mats: List<MatDraw>, val vd: FloatArray, val vbuf: java.nio.FloatBuffer)

    private fun makeTexture(bytes: ByteArray?): Int {
        if (bytes == null) return 0
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return 0
        val id = IntArray(1); GLES20.glGenTextures(1, id, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return id[0]
    }

    private fun freeModel() {
        model?.let {
            GLES20.glDeleteBuffers(2, intArrayOf(it.vbo, it.ibo), 0)
            val t = it.texIds.filter { id -> id != 0 }.toIntArray()
            if (t.isNotEmpty()) GLES20.glDeleteTextures(t.size, t, 0)
        }
        model = null; animator = null
    }

    /** Roda na thread GL. Converte MMD (mão esquerda, -Z frente) para GL (Z invertido, winding invertido), escala 0.1. */
    fun loadModel(m: PmxModel, texBytes: List<ByteArray?>) {
        freeModel()
        val sc = 0.1f
        val vc = m.vertexCount
        val vd = FloatArray(vc * 8)
        var minX = 1e9f; var minY = 1e9f; var minZ = 1e9f; var maxX = -1e9f; var maxY = -1e9f; var maxZ = -1e9f
        for (i in 0 until vc) {
            val x = m.positions[i * 3] * sc; val y = m.positions[i * 3 + 1] * sc; val z = -m.positions[i * 3 + 2] * sc
            vd[i * 8] = x; vd[i * 8 + 1] = y; vd[i * 8 + 2] = z
            vd[i * 8 + 3] = m.normals[i * 3]; vd[i * 8 + 4] = m.normals[i * 3 + 1]; vd[i * 8 + 5] = -m.normals[i * 3 + 2]
            vd[i * 8 + 6] = m.uvs[i * 2]; vd[i * 8 + 7] = m.uvs[i * 2 + 1]
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val idx = m.indices.copyOf()
        for (t in 0 until idx.size / 3) { val a = idx[t * 3 + 1]; idx[t * 3 + 1] = idx[t * 3 + 2]; idx[t * 3 + 2] = a }
        val ids = IntArray(2); GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        val vbuf = fb(vd)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vd.size * 4, vbuf, GLES20.GL_DYNAMIC_DRAW)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(idx); position(0) }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val texIds = IntArray(m.textures.size) { makeTexture(texBytes.getOrNull(it)) }
        var off = 0
        val mats = m.materials.map { mt ->
            val tex = if (mt.textureIndex in texIds.indices) texIds[mt.textureIndex] else 0
            MatDraw(mt.diffuse, mt.ambient, tex, mt.doubleSided, off * 4, mt.indexCount).also { off += mt.indexCount }
        }
        model = GlModel(ids[0], ids[1], texIds, mats, vd, vbuf)
        animator = Animator(m, sc); lastFrame = -1f
        cam.tx = (minX + maxX) / 2; cam.ty = (minY + maxY) / 2; cam.tz = (minZ + maxZ) / 2
        cam.dist = maxOf(maxX - minX, maxY - minY, maxZ - minZ) * 2.2f
    }

    private fun drawModel() {
        val gm = model ?: return
        GLES20.glUseProgram(mProg)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProg, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProg, "uLight"), 0.3f, 0.6f, 0.8f)
        val aP = GLES20.glGetAttribLocation(mProg, "aPos"); val aN = GLES20.glGetAttribLocation(mProg, "aNrm"); val aU = GLES20.glGetAttribLocation(mProg, "aUv")
        val uD = GLES20.glGetUniformLocation(mProg, "uDiffuse"); val uA = GLES20.glGetUniformLocation(mProg, "uAmbient")
        val uH = GLES20.glGetUniformLocation(mProg, "uHasTex"); val uT = GLES20.glGetUniformLocation(mProg, "uTex")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo)
        GLES20.glEnableVertexAttribArray(aP); GLES20.glEnableVertexAttribArray(aN); GLES20.glEnableVertexAttribArray(aU)
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 32, 0)
        GLES20.glVertexAttribPointer(aN, 3, GLES20.GL_FLOAT, false, 32, 12)
        GLES20.glVertexAttribPointer(aU, 2, GLES20.GL_FLOAT, false, 32, 24)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glUniform1i(uT, 0)
        for (md in gm.mats) {
            if (md.count == 0) continue
            if (md.twoSided) GLES20.glDisable(GLES20.GL_CULL_FACE) else GLES20.glEnable(GLES20.GL_CULL_FACE)
            GLES20.glUniform4fv(uD, 1, md.diffuse, 0); GLES20.glUniform3fv(uA, 1, md.ambient, 0)
            GLES20.glUniform1f(uH, if (md.tex != 0) 1f else 0f)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, md.tex)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, md.count, GLES20.GL_UNSIGNED_INT, md.offset)
        }
        GLES20.glDisableVertexAttribArray(aP); GLES20.glDisableVertexAttribArray(aN); GLES20.glDisableVertexAttribArray(aU)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_CULL_FACE); GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }

    private companion object {
        const val MODEL_VS = "uniform mat4 uMvp; attribute vec3 aPos; attribute vec3 aNrm; attribute vec2 aUv; varying vec3 vN; varying vec2 vUv; void main(){vN=aNrm; vUv=aUv; gl_Position=uMvp*vec4(aPos,1.0);}"
        const val MODEL_FS = "precision mediump float; uniform sampler2D uTex; uniform float uHasTex; uniform vec4 uDiffuse; uniform vec3 uAmbient; uniform vec3 uLight; varying vec3 vN; varying vec2 vUv; " +
            "void main(){ vec3 n=normalize(vN); if(!gl_FrontFacing) n=-n; float l=0.5+0.5*max(dot(n,normalize(uLight)),0.0); " +
            "vec4 t = uHasTex>0.5 ? texture2D(uTex,vUv) : vec4(1.0); float a=uDiffuse.a*t.a; if(a<0.02) discard; " +
            "vec3 c = t.rgb*clamp(uDiffuse.rgb+uAmbient*0.3,0.0,1.0)*l; gl_FragColor=vec4(c,a);}"
    }
}
