package studio.mmd.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.importer.ModelImporter
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdParser
import studio.mmd.render.SceneGLView
import studio.mmd.render.TouchMode
import studio.mmd.render.ViewPreset

val Bg = Color(0xFF0A0A0B); val Panel = Color(0xFF17181B); val Accent = Color(0xFF2F7BFF)
val Muted = Color(0xFF8A8D94)
const val FPS = 30; const val DEFAULT_FRAMES = 300

@Composable
fun SceneScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val gl = remember { SceneGLView(ctx) }
    var mode by remember { mutableStateOf(TouchMode.ORBIT) }
    var menu by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(DEFAULT_FRAMES) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var currentModel by remember { mutableStateOf<PmxModel?>(null) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                if (name.lowercase().endsWith(".vmd")) {
                    val m = currentModel ?: throw IllegalStateException("Importe um modelo (.pmx/.zip) antes do movimento")
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(ModelImporter.readBytes(ctx, uri)) }
                    val boneNames = m.bones.map { it.name }.toHashSet(); val morphNames = m.morphs.map { it.name }.toHashSet()
                    val bm = mo.bones.keys.count { it in boneNames }; val mm = mo.morphs.keys.count { it in morphNames }
                    playing = false; frame = 0; total = mo.maxFrame + 1
                    gl.setMotion(mo); gl.setFrame(0)
                    status = "$name\n${total} frames (%.1fs a $FPS fps)\nossos casados: $bm/${mo.bones.size}\nmorphs casados: $mm/${mo.morphs.size}".format(total / FPS.toFloat()) +
                        if (bm == 0) "\nATENÇÃO: nenhum osso casou; o modelo não vai se mover" else ""
                    if (bm == 0) isError = true
                } else {
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, uri) }
                    val m = r.model
                    currentModel = m; playing = false; frame = 0; total = DEFAULT_FRAMES
                    gl.loadModel(m, r.textures)
                    status = "${m.name.ifBlank { r.sourceName }}\n${m.vertexCount} vértices · ${m.indices.size / 3} triângulos\n" +
                        "${m.materials.size} materiais · ${m.bones.size} ossos · ${m.morphs.size} morphs\n" +
                        "texturas: ${r.textures.count { it != null }}/${m.textures.size}"
                }
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    LaunchedEffect(playing, total) {
        while (playing) { delay(1000L / FPS); frame = (frame + 1) % total }
    }
    LaunchedEffect(frame) { gl.setFrame(frame) }
    DisposableEffect(Unit) { gl.onResume(); onDispose { gl.onPause() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowBackIosNew, null, Modifier.clickable { onClose() }.padding(8.dp).size(18.dp), tint = Color.White)
                Icon(Icons.Default.ViewInAr, null, Modifier.padding(start = 4.dp).size(18.dp), tint = Color.White)
                Text("Scene 3D", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Icon(Icons.Default.FolderOpen, null, Modifier.clickable { picker.launch(arrayOf("*/*")) }.padding(8.dp).size(22.dp), tint = Color.White)
                Icon(Icons.Default.Close, null, Modifier.clickable { onClose() }.padding(8.dp).size(20.dp), tint = Color.White)
            }
            Box(Modifier.padding(horizontal = 8.dp)) {
                Row(Modifier.clickable { menu = true }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Viewport de Edição", color = Color.White, fontSize = 12.sp)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Enquadrar tudo") }, onClick = { gl.frameAll(); menu = false })
                    listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esquerda" to ViewPreset.LEFT,
                        "Direita" to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { gl.applyPreset(p); menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(4.dp))) {
                AndroidView(factory = { gl }, modifier = Modifier.fillMaxSize())
                status?.let { Text(it, color = if (isError) Color(0xFFFF6B6B) else Color.White, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).background(Panel.copy(alpha = .8f), RoundedCornerShape(6.dp)).padding(8.dp)) }
                Column(Modifier.align(Alignment.CenterStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha = .85f))) {
                    ToolButton(Icons.Default.OpenWith, mode == TouchMode.ORBIT) { mode = TouchMode.ORBIT; gl.touchMode = mode }
                    ToolButton(Icons.Default.PanTool, mode == TouchMode.PAN) { mode = TouchMode.PAN; gl.touchMode = mode }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Animação", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("%d / %d".format(frame, total - 1), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.clickable { playing = !playing }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame - 1).coerceAtLeast(0) }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipNext, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame + 1).coerceAtMost(total - 1) }.padding(8.dp).size(22.dp))
            }
            Timeline(frame, total, Modifier.fillMaxWidth().height(110.dp).padding(horizontal = 8.dp, vertical = 6.dp)) { frame = it }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(3.dp).size(34.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Accent else Color.Transparent).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(18.dp))
    }
}

/** Régua de frames com playhead arrastável (um traço por segundo). */
@Composable
private fun Timeline(frame: Int, total: Int, modifier: Modifier, onSeek: (Int) -> Unit) {
    val last = (total - 1).coerceAtLeast(1)
    Canvas(modifier.background(Color(0xFF101114)).pointerInput(total) {
        detectTapGestures { onSeek((it.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }.pointerInput(total) {
        detectDragGestures { c, _ -> onSeek((c.position.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }) {
        val secs = (last / FPS).coerceAtLeast(1)
        val step = size.width * FPS / last
        for (s in 0..secs) drawLine(Color(0xFF3A3C42), Offset(s * step, 0f), Offset(s * step, 28f), 2f)
        val x = frame.toFloat() / last * size.width
        drawLine(Accent, Offset(x, 0f), Offset(x, size.height), 3f)
    }
}
