package studio.mmd.fbx

import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMotion
import java.io.OutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2

/**
 * Exporta o modelo (malha, esqueleto, pesos, materiais e texturas) e a animação assada quadro a quadro
 * para FBX binário 7.4. Convenções: Y para cima, mão direita (Z do MMD invertido), 1 unidade MMD = 8 cm,
 * rotações em graus (ordem XYZ do FBX). Morphs de rosto ainda não são exportados.
 */
object FbxExporter {
    private const val KTIME = 46186158000L
    private const val SCALE = 8.0           // cm por unidade do MMD
    private const val FPS = 30

    class Report(val bones: Int, val frames: Int, val animatedBones: Int)

    /** Nomes dos arquivos de textura dentro do pacote (null = textura ausente). */
    fun textureFileNames(model: PmxModel, tex: List<ByteArray?>): List<String?> = model.textures.mapIndexed { i, n ->
        if (tex.getOrNull(i) == null) null else {
            val ext = n.substringAfterLast('.', "png").lowercase().filter { it.isLetterOrDigit() }.ifEmpty { "png" }
            "tex/tex_%03d.%s".format(i, ext)
        }
    }

    fun write(out: OutputStream, model: PmxModel, motion: VmdMotion?, texNames: List<String?>, frames: Int): Report {
        val nb = model.bones.size
        var nextId = 100000L
        fun id() = nextId++
        fun cls(name: String, c: String) = name + "\u0000\u0001" + c

        // nomes únicos dos ossos
        val used = HashSet<String>()
        val boneNames = Array(nb) { i ->
            var n = model.bones[i].name.ifBlank { "bone_$i" }.replace("\u0000", "")
            if (!used.add(n)) { n = "${n}_$i"; used.add(n) }
            n
        }
        val meshName = model.name.ifBlank { "Modelo" }.replace("\u0000", "")

        // ---------- animação assada (antes dos Models, para fixar a pose do quadro 0 e os canais constantes)
        val n = maxOf(frames, 1)
        val hasAnim = motion != null && n > 1
        val rest = DoubleArray(nb * 3)   // translação local de repouso (já convertida)
        for (i in 0 until nb) {
            val b = model.bones[i]
            val p = b.parent
            if (p in 0 until nb && p != i) {
                val pb = model.bones[p]
                rest[i * 3] = (b.x - pb.x) * SCALE; rest[i * 3 + 1] = (b.y - pb.y) * SCALE; rest[i * 3 + 2] = -(b.z - pb.z) * SCALE
            } else {
                rest[i * 3] = b.x * SCALE; rest[i * 3 + 1] = b.y * SCALE; rest[i * 3 + 2] = -b.z * SCALE
            }
        }
        val staticT = DoubleArray(nb * 3) { rest[it] }
        val staticR = DoubleArray(nb * 3)
        val animT = BooleanArray(nb); val animR = BooleanArray(nb)
        var curves: Array<FloatArray?> = arrayOfNulls(nb)   // 6 canais por osso, canal-major (c * n + f)
        var animCount = 0
        if (hasAnim) {
            val an = Animator(model, 1f)
            an.motion = motion
            val all = Array(nb) { FloatArray(6 * n) }
            val tmp = FloatArray(7); val eul = DoubleArray(3); val prev = DoubleArray(nb * 3)
            for (f in 0 until n) {
                an.evaluatePose(f.toFloat())
                for (b in 0 until nb) {
                    an.local(b, tmp)
                    val a = all[b]
                    a[f] = (tmp[0] * SCALE).toFloat(); a[n + f] = (tmp[1] * SCALE).toFloat(); a[2 * n + f] = (-tmp[2] * SCALE).toFloat()
                    eulerXyz(-tmp[3].toDouble(), -tmp[4].toDouble(), tmp[5].toDouble(), tmp[6].toDouble(), eul)
                    if (f > 0) for (k in 0..2) eul[k] = unwrap(eul[k], prev[b * 3 + k])
                    for (k in 0..2) { prev[b * 3 + k] = eul[k]; a[(3 + k) * n + f] = eul[k].toFloat() }
                }
            }
            curves = arrayOfNulls(nb)
            for (b in 0 until nb) {
                val a = all[b]
                val moveT = BooleanArray(3) { !constant(a, it, n) }
                val moveR = BooleanArray(3) { !constant(a, 3 + it, n) }
                for (k in 0..2) { staticT[b * 3 + k] = a[k * n].toDouble(); staticR[b * 3 + k] = a[(3 + k) * n].toDouble() }
                animT[b] = moveT.any { it }; animR[b] = moveR.any { it }
                if (animT[b] || animR[b]) { curves[b] = a; animCount++ }
            }
        }

        // ---------- objetos
        val objects = FbxNode("Objects")
        val conns = ArrayList<Array<Any>>()
        fun connect(child: Long, parent: Long) { conns.add(arrayOf("OO", child, parent)) }
        fun connectP(child: Long, parent: Long, prop: String) { conns.add(arrayOf("OP", child, parent, prop)) }
        val counts = LinkedHashMap<String, Int>()
        fun count(t: String) { counts[t] = (counts[t] ?: 0) + 1 }

        // esqueleto
        val boneId = LongArray(nb) { id() }
        for (i in 0 until nb) {
            val attrId = id()
            objects.child("NodeAttribute").addLong(attrId).addString(cls(boneNames[i], "NodeAttribute")).addString("LimbNode").apply {
                child("Properties70")
                child("TypeFlags").addString("Skeleton")
            }
            count("NodeAttribute")
            val m = objects.child("Model").addLong(boneId[i]).addString(cls(boneNames[i], "Model")).addString("LimbNode")
            m.child("Version").addInt(232)
            val pr = m.child("Properties70")
            pr.vec("Lcl Translation", staticT[i * 3], staticT[i * 3 + 1], staticT[i * 3 + 2])
            pr.vec("Lcl Rotation", staticR[i * 3], staticR[i * 3 + 1], staticR[i * 3 + 2])
            m.child("Shading").addBool(true)
            m.child("Culling").addString("CullingOff")
            count("Model")
            connect(attrId, boneId[i])
            val p = model.bones[i].parent
            connect(boneId[i], if (p in 0 until nb && p != i) boneId[p] else 0L)
        }

        // malha
        val meshId = id(); val geoId = id()
        run {
            val m = objects.child("Model").addLong(meshId).addString(cls(meshName, "Model")).addString("Mesh")
            m.child("Version").addInt(232)
            m.child("Properties70")
            m.child("Shading").addBool(true)
            m.child("Culling").addString("CullingOff")
            count("Model")
            connect(meshId, 0L)
        }
        val tris = model.indices.size / 3
        run {
            val vc = model.vertexCount
            val verts = DoubleArray(vc * 3)
            for (i in 0 until vc) {
                verts[i * 3] = model.positions[i * 3] * SCALE; verts[i * 3 + 1] = model.positions[i * 3 + 1] * SCALE
                verts[i * 3 + 2] = -model.positions[i * 3 + 2] * SCALE
            }
            val pvi = IntArray(tris * 3); val uvi = IntArray(tris * 3)
            val nrm = DoubleArray(tris * 9)
            for (t in 0 until tris) {
                val a = model.indices[t * 3]; val b = model.indices[t * 3 + 1]; val c = model.indices[t * 3 + 2]
                // ordem invertida (Z espelhado): a, c, b
                pvi[t * 3] = a; pvi[t * 3 + 1] = c; pvi[t * 3 + 2] = -b - 1
                uvi[t * 3] = a; uvi[t * 3 + 1] = c; uvi[t * 3 + 2] = b
                val vs = intArrayOf(a, c, b)
                for (k in 0..2) {
                    val v = vs[k]
                    nrm[t * 9 + k * 3] = model.normals[v * 3].toDouble(); nrm[t * 9 + k * 3 + 1] = model.normals[v * 3 + 1].toDouble()
                    nrm[t * 9 + k * 3 + 2] = -model.normals[v * 3 + 2].toDouble()
                }
            }
            val uv = DoubleArray(vc * 2)
            for (i in 0 until vc) { uv[i * 2] = model.uvs[i * 2].toDouble(); uv[i * 2 + 1] = 1.0 - model.uvs[i * 2 + 1] }
            val matIdx = IntArray(tris)
            run {
                var t = 0
                for ((mi, mt) in model.materials.withIndex()) {
                    val cnt = mt.indexCount / 3
                    var k = 0
                    while (k < cnt && t < tris) { matIdx[t++] = mi; k++ }
                }
                val last = (model.materials.size - 1).coerceAtLeast(0)
                while (t < tris) matIdx[t++] = last
            }
            val g = objects.child("Geometry").addLong(geoId).addString(cls(meshName, "Geometry")).addString("Mesh")
            g.child("Vertices").addDoubles(verts)
            g.child("PolygonVertexIndex").addInts(pvi)
            g.child("GeometryVersion").addInt(124)
            g.child("LayerElementNormal").addInt(0).apply {
                child("Version").addInt(101); child("Name").addString("")
                child("MappingInformationType").addString("ByPolygonVertex"); child("ReferenceInformationType").addString("Direct")
                child("Normals").addDoubles(nrm)
            }
            g.child("LayerElementUV").addInt(0).apply {
                child("Version").addInt(101); child("Name").addString("UVMap")
                child("MappingInformationType").addString("ByPolygonVertex"); child("ReferenceInformationType").addString("IndexToDirect")
                child("UV").addDoubles(uv); child("UVIndex").addInts(uvi)
            }
            g.child("LayerElementMaterial").addInt(0).apply {
                child("Version").addInt(101); child("Name").addString("")
                child("MappingInformationType").addString("ByPolygon"); child("ReferenceInformationType").addString("IndexToDirect")
                child("Materials").addInts(matIdx)
            }
            g.child("Layer").addInt(0).apply {
                child("Version").addInt(100)
                for (t in listOf("LayerElementNormal", "LayerElementUV", "LayerElementMaterial"))
                    child("LayerElement").apply { child("Type").addString(t); child("TypedIndex").addInt(0) }
            }
            count("Geometry")
            connect(geoId, meshId)
        }

        // materiais e texturas
        val texNodeId = HashMap<Int, Long>()
        val matNames = HashSet<String>()
        for ((mi, mt) in model.materials.withIndex()) {
            val matId = id()
            var nm = mt.name.ifBlank { "material_$mi" }.replace("\u0000", "")
            if (!matNames.add(nm)) { nm = "${nm}_$mi"; matNames.add(nm) }
            val m = objects.child("Material").addLong(matId).addString(cls(nm, "Material")).addString("")
            m.child("Version").addInt(102); m.child("ShadingModel").addString("phong"); m.child("MultipleLayer").addInt(0)
            val pr = m.child("Properties70")
            pr.vec("DiffuseColor", mt.diffuse[0].toDouble(), mt.diffuse[1].toDouble(), mt.diffuse[2].toDouble(), "Color")
            pr.num("Opacity", mt.diffuse[3].toDouble())
            count("Material")
            connect(matId, meshId)
            val ti = mt.textureIndex
            val file = texNames.getOrNull(ti)
            if (ti >= 0 && file != null) {
                val tid = texNodeId.getOrPut(ti) {
                    val texId = id(); val vidId = id()
                    val tn = file.substringAfterLast('/')
                    val v = objects.child("Video").addLong(vidId).addString(cls(tn, "Video")).addString("Clip")
                    v.child("Type").addString("Clip")
                    v.child("Properties70").child("P").addString("Path").addString("KString").addString("XRefUrl").addString("").addString(file)
                    v.child("UseMipMap").addInt(0); v.child("Filename").addString(file); v.child("RelativeFilename").addString(file)
                    count("Video")
                    val t = objects.child("Texture").addLong(texId).addString(cls(tn, "Texture")).addString("")
                    t.child("Type").addString("TextureVideoClip"); t.child("Version").addInt(202)
                    t.child("TextureName").addString(cls(tn, "Texture")); t.child("Properties70")
                    t.child("Media").addString(cls(tn, "Video"))
                    t.child("FileName").addString(file); t.child("RelativeFilename").addString(file)
                    count("Texture")
                    connect(vidId, texId)
                    texId
                }
                connectP(tid, matId, "DiffuseColor")
            }
        }

        // pele (skin) + clusters
        val skinId = id()
        run {
            val per = Array(nb) { ArrayList<Int>() }
            val perW = Array(nb) { ArrayList<Double>() }
            for (v in 0 until model.vertexCount) {
                var tw = 0f
                for (k in 0..3) { val b = model.boneIndices[v * 4 + k]; if (b in 0 until nb) tw += model.boneWeights[v * 4 + k] }
                if (tw <= 0f) continue
                for (k in 0..3) {
                    val b = model.boneIndices[v * 4 + k]; val w = model.boneWeights[v * 4 + k]
                    if (b !in 0 until nb || w <= 0f) continue
                    per[b].add(v); perW[b].add((w / tw).toDouble())
                }
            }
            val s = objects.child("Deformer").addLong(skinId).addString(cls(meshName, "Deformer")).addString("Skin")
            s.child("Version").addInt(101); s.child("Link_DeformAcuracy").addDouble(50.0); s.child("SkinningType").addString("Linear")
            count("Deformer"); connect(skinId, geoId)
            for (b in 0 until nb) {
                if (per[b].isEmpty()) continue
                val cid = id()
                val c = objects.child("Deformer").addLong(cid).addString(cls(boneNames[b], "SubDeformer")).addString("Cluster")
                c.child("Version").addInt(100); c.child("UserData").addString("").addString("")
                c.child("Indexes").addInts(per[b].toIntArray())
                c.child("Weights").addDoubles(perW[b].toDoubleArray())
                c.child("Transform").addDoubles(matrix(0.0, 0.0, 0.0))
                c.child("TransformLink").addDoubles(restMatrix(model, b))
                count("Deformer")
                connect(cid, skinId); connect(boneId[b], cid)
            }
        }

        // pose de repouso
        run {
            val p = objects.child("Pose").addLong(id()).addString(cls("BindPose", "Pose")).addString("BindPose")
            p.child("Type").addString("BindPose"); p.child("Version").addInt(100); p.child("NbPoseNodes").addInt(nb + 1)
            p.child("PoseNode").apply { child("Node").addLong(meshId); child("Matrix").addDoubles(matrix(0.0, 0.0, 0.0)) }
            for (b in 0 until nb) p.child("PoseNode").apply { child("Node").addLong(boneId[b]); child("Matrix").addDoubles(restMatrix(model, b)) }
            count("Pose")
        }

        // animação
        if (hasAnim && animCount > 0) {
            val stackId = id(); val layerId = id()
            val stop = KTIME * (n - 1) / FPS
            val st = objects.child("AnimationStack").addLong(stackId).addString(cls("Take 001", "AnimStack")).addString("")
            st.child("Properties70").apply {
                ktime("LocalStart", 0L); ktime("LocalStop", stop); ktime("ReferenceStart", 0L); ktime("ReferenceStop", stop)
            }
            count("AnimationStack")
            objects.child("AnimationLayer").addLong(layerId).addString(cls("BaseLayer", "AnimLayer")).addString("")
            count("AnimationLayer")
            connect(layerId, stackId)
            val allTimes = LongArray(n) { KTIME * it / FPS }
            val twoTimes = longArrayOf(0L, allTimes[n - 1])
            for (b in 0 until nb) {
                val a = curves[b] ?: continue
                for (kind in 0..1) {
                    if (if (kind == 0) !animT[b] else !animR[b]) continue
                    val prop = if (kind == 0) "Lcl Translation" else "Lcl Rotation"
                    val short = if (kind == 0) "T" else "R"
                    val nodeId = id()
                    val cn = objects.child("AnimationCurveNode").addLong(nodeId).addString(cls(short, "AnimCurveNode")).addString("")
                    cn.child("Properties70").apply {
                        for (k in 0..2) num("d|" + "XYZ"[k], a[(kind * 3 + k) * n].toDouble())
                    }
                    count("AnimationCurveNode")
                    connect(nodeId, layerId); connectP(nodeId, boneId[b], prop)
                    for (k in 0..2) {
                        val ch = kind * 3 + k
                        val curveId = id()
                        val isConst = constant(a, ch, n)
                        val vals = if (isConst) floatArrayOf(a[ch * n], a[ch * n + n - 1]) else a.copyOfRange(ch * n, ch * n + n)
                        val times = if (isConst) twoTimes else allTimes
                        val cv = objects.child("AnimationCurve").addLong(curveId).addString(cls("", "AnimCurve")).addString("")
                        cv.child("Default").addDouble(vals[0].toDouble())
                        cv.child("KeyVer").addInt(4008)
                        cv.child("KeyTime").addLongs(times)
                        cv.child("KeyValueFloat").addFloats(vals)
                        cv.child("KeyAttrFlags").addInts(intArrayOf(4132))
                        cv.child("KeyAttrDataFloat").addFloats(floatArrayOf(0f, 0f, 218434821f, 0f))
                        cv.child("KeyAttrRefCount").addInts(intArrayOf(vals.size))
                        count("AnimationCurve")
                        connectP(curveId, nodeId, "d|" + "XYZ"[k])
                    }
                }
            }
        }

        // ---------- cabeçalho, definições, conexões
        val roots = ArrayList<FbxNode>()
        FbxNode("FBXHeaderExtension").apply {
            child("FBXHeaderVersion").addInt(1003); child("FBXVersion").addInt(7400)
            child("Creator").addString("MMD Studio")
        }.also { roots.add(it) }
        roots.add(FbxNode("FileId").addRaw(ByteArray(16) { (it * 17 + 3).toByte() }))
        roots.add(FbxNode("CreationTime").addString("1970-01-01 10:00:00:000"))
        roots.add(FbxNode("Creator").addString("MMD Studio"))
        FbxNode("GlobalSettings").apply {
            child("Version").addInt(1000)
            child("Properties70").apply {
                int("UpAxis", 1); int("UpAxisSign", 1); int("FrontAxis", 2); int("FrontAxisSign", 1)
                int("CoordAxis", 0); int("CoordAxisSign", 1); int("OriginalUpAxis", 1); int("OriginalUpAxisSign", 1)
                num("UnitScaleFactor", 1.0); num("OriginalUnitScaleFactor", 1.0)
                child("P").addString("TimeMode").addString("enum").addString("").addString("").addInt(6)
            }
        }.also { roots.add(it) }
        FbxNode("Documents").apply {
            child("Count").addInt(1)
            child("Document").addLong(id()).addString("Scene").addString("Scene").apply {
                child("Properties70").child("P").addString("SourceObject").addString("object").addString("").addString("")
                child("RootNode").addLong(0L)
            }
        }.also { roots.add(it) }
        roots.add(FbxNode("References"))
        FbxNode("Definitions").apply {
            child("Version").addInt(100)
            child("Count").addInt(counts.values.sum() + 1)
            child("ObjectType").addString("GlobalSettings").child("Count").addInt(1)
            for ((t, c) in counts) child("ObjectType").addString(t).child("Count").addInt(c)
        }.also { roots.add(it) }
        roots.add(objects)
        FbxNode("Connections").apply {
            for (c in conns) {
                val node = child("C").addString(c[0] as String).addLong(c[1] as Long).addLong(c[2] as Long)
                if (c.size > 3) node.addString(c[3] as String)
            }
        }.also { roots.add(it) }
        FbxNode("Takes").apply { child("Current").addString("") }.also { roots.add(it) }

        FbxFile.write(out, roots, 7400)
        return Report(nb, if (hasAnim) n else 0, animCount)
    }

    // ---------- helpers de propriedades (Properties70)
    private fun FbxNode.vec(name: String, x: Double, y: Double, z: Double, type: String = name): FbxNode {
        child("P").addString(name).addString(type).addString("").addString("A").addDouble(x).addDouble(y).addDouble(z); return this
    }
    private fun FbxNode.num(name: String, v: Double): FbxNode {
        child("P").addString(name).addString("Number").addString("").addString("A").addDouble(v); return this
    }
    private fun FbxNode.int(name: String, v: Int): FbxNode {
        child("P").addString(name).addString("int").addString("Integer").addString("").addInt(v); return this
    }
    private fun FbxNode.ktime(name: String, v: Long): FbxNode {
        child("P").addString(name).addString("KTime").addString("Time").addString("").addLong(v); return this
    }

    // ---------- matemática
    /** Matriz 4x4 (16 doubles, translação nos elementos 12..14) só de translação. */
    private fun matrix(x: Double, y: Double, z: Double) =
        doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, x, y, z, 1.0)

    private fun restMatrix(m: PmxModel, b: Int): DoubleArray {
        val bn = m.bones[b]
        return matrix(bn.x * SCALE, bn.y * SCALE, -bn.z * SCALE)
    }

    private fun constant(a: FloatArray, ch: Int, n: Int): Boolean {
        var mn = a[ch * n]; var mx = mn
        for (f in 1 until n) { val v = a[ch * n + f]; if (v < mn) mn = v; if (v > mx) mx = v }
        return mx - mn < 1e-4f
    }

    private fun unwrap(a: Double, prev: Double): Double {
        var v = a
        while (v - prev > 180.0) v -= 360.0
        while (v - prev < -180.0) v += 360.0
        return v
    }

    /** Quaternion (já em mão direita) -> Euler XYZ do FBX (R = Rz·Ry·Rx), em graus. */
    private fun eulerXyz(x: Double, y: Double, z: Double, w: Double, o: DoubleArray) {
        val r00 = 1 - 2 * (y * y + z * z); val r10 = 2 * (x * y + z * w); val r20 = 2 * (x * z - y * w)
        val r21 = 2 * (y * z + x * w); val r22 = 1 - 2 * (x * x + y * y)
        val r11 = 1 - 2 * (x * x + z * z); val r12 = 2 * (y * z - x * w)
        val ey = asin((-r20).coerceIn(-1.0, 1.0))
        val ex: Double; val ez: Double
        if (abs(r20) < 0.99999) { ex = atan2(r21, r22); ez = atan2(r10, r00) }
        else { ex = atan2(-r12, r11); ez = 0.0 }
        val k = 180.0 / PI
        o[0] = ex * k; o[1] = ey * k; o[2] = ez * k
    }
}
