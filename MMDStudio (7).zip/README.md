# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 2.0. Sem WebView/PWA.

## Status
Etapa 4 (edição): modo Esqueleto com ossos desenhados sobre o modelo, seleção de osso por toque, abas Ossos/Osso/Pose/Morphs, keyframes (auto-key), copiar/colar/espelhar/zerar/resetar pose, desfazer/refazer.
Etapa 3: parser VMD, esqueleto com FK + IK (CCD) + append, skinning na CPU, morphs de vértice/osso/grupo, reprodução ligada à timeline.
Etapa 2: parser PMX 2.0/2.1 (vértices, faces, texturas, materiais, ossos, IK, morphs), importação de .pmx ou .zip (ícone de pasta), render OpenGL ES 3 com texturas e materiais (sem animação ainda).
Etapa 1 (anterior):
câmera orbital (1 dedo orbita/pan conforme ferramenta, 2 dedos pan, pinça zoom), vistas Frente/Trás/Esquerda/Direita/Topo/Base,
play/pause, frame anterior/próximo e timeline com playhead arrastável.
Etapa 9 (0.9.0): exportar FBX animado (menu do disquete) e Cena (cenário/acessórios PMX estáticos). Veja o arquivo de contexto.

## Compilar
- Android Studio: abrir a pasta e rodar `app`.
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
