plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "studio.mmd"
    compileSdk = 34
    defaultConfig { applicationId = "studio.mmd"; minSdk = 26; targetSdk = 34; versionCode = 27; versionName = "1.8.0" }
    signingConfigs {
        // Chave fixa do projeto: mantém a mesma assinatura em todas as versões (permite atualizar sem desinstalar).
        create("release") {
            storeFile = file("mmdstudio.jks"); storePassword = "mmdstudio2026"
            keyAlias = "mmdstudio"; keyPassword = "mmdstudio2026"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isDebuggable = false
        }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    // Captura de movimento por vídeo (modelo empacotado, roda no aparelho)
    implementation("com.google.mlkit:pose-detection:18.0.0-beta5")
    implementation("com.google.mlkit:pose-detection-accurate:18.0.0-beta5")
}
