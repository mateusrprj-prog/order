# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 2.0. Sem WebView/PWA.

## Status
Etapa 2: parser PMX 2.0/2.1 (vértices, faces, texturas, materiais, ossos, IK, morphs), importação de .pmx ou .zip (ícone de pasta), render OpenGL ES 3 com texturas e materiais (sem animação ainda).
Etapa 1 (anterior):
câmera orbital (1 dedo orbita/pan conforme ferramenta, 2 dedos pan, pinça zoom), vistas Frente/Trás/Esquerda/Direita/Topo/Base,
play/pause, frame anterior/próximo e timeline com playhead arrastável.
Ainda NÃO implementado: PMD, VMD, skinning/bones animados, morphs aplicados, física, áudio, exportação, sombras, toon/sphere.

## Compilar
- Android Studio: abrir a pasta e rodar `app`.
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
