package studio.mmd.project

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/** Dados de um projeto. Arquivos do projeto ficam em filesDir/projects/<id>/ (project.json, model.*, audio.*, animacao.vmd). */
data class ProjectMeta(
    val id: String, val name: String, val aspect: String, val resolution: Int, val fps: Int,
    val bg: String, val created: Long, val updated: Long, val frames: Int
)

object Aspects {
    /** Nome -> largura/altura (0 = livre, sem moldura). */
    val all: List<Pair<String, Float>> = listOf(
        "16:9" to 16f / 9f, "9:16" to 9f / 16f, "4:5" to 4f / 5f, "1:1" to 1f, "4:3" to 4f / 3f, "Livre" to 0f
    )

    fun ratio(key: String): Float = all.firstOrNull { it.first == key }?.second ?: 0f

    /** Resolução = lado menor (4:3 em 2160p = 2880×2160). Livre = null. */
    fun size(key: String, res: Int): Pair<Int, Int>? {
        val r = ratio(key)
        if (r <= 0f) return null
        return if (r >= 1f) Pair((res * r).toInt() / 2 * 2, res) else Pair(res, (res / r).toInt() / 2 * 2)
    }
}

object Backgrounds {
    val all: List<Pair<String, Int>> = listOf(
        "Preto" to 0xFF000000.toInt(), "Cinza" to 0xFF303236.toInt(), "Branco" to 0xFFFFFFFF.toInt(),
        "Azul" to 0xFF1B3A6B.toInt(), "Verde" to 0xFF00B140.toInt()
    )

    fun color(name: String): Int = all.firstOrNull { it.first == name }?.second ?: all[0].second
}

object ProjectStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    private fun write(ctx: Context, m: ProjectMeta) {
        val j = JSONObject().put("id", m.id).put("name", m.name).put("aspect", m.aspect).put("resolution", m.resolution)
            .put("fps", m.fps).put("bg", m.bg).put("created", m.created).put("updated", m.updated).put("frames", m.frames)
        File(dir(ctx, m.id), "project.json").writeText(j.toString())
    }

    private fun read(f: File): ProjectMeta? = try {
        val j = JSONObject(f.readText())
        ProjectMeta(
            j.getString("id"), j.getString("name"), j.optString("aspect", "16:9"), j.optInt("resolution", 1080),
            j.optInt("fps", 30), j.optString("bg", "Preto"), j.optLong("created"), j.optLong("updated"), j.optInt("frames", 300)
        )
    } catch (e: Exception) { null }

    fun list(ctx: Context): List<ProjectMeta> =
        (root(ctx).listFiles() ?: emptyArray()).mapNotNull { d -> File(d, "project.json").takeIf { it.exists() }?.let { read(it) } }

    fun get(ctx: Context, id: String): ProjectMeta? = File(File(root(ctx), id), "project.json").takeIf { it.exists() }?.let { read(it) }

    fun create(ctx: Context, name: String, aspect: String, res: Int, fps: Int, bg: String): ProjectMeta {
        val now = System.currentTimeMillis()
        val m = ProjectMeta(UUID.randomUUID().toString(), name, aspect, res, fps, bg, now, now, 300)
        write(ctx, m); return m
    }

    fun rename(ctx: Context, id: String, name: String) { get(ctx, id)?.let { write(ctx, it.copy(name = name)) } }

    /** Atualiza data de modificação e duração. */
    fun touch(ctx: Context, id: String, frames: Int) { get(ctx, id)?.let { write(ctx, it.copy(updated = System.currentTimeMillis(), frames = frames)) } }

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }

    fun sizeBytes(ctx: Context, id: String): Long = File(root(ctx), id).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Copia o arquivo escolhido para o projeto como <prefix>.<ext>, substituindo o anterior. */
    fun copyIn(ctx: Context, id: String, uri: Uri, prefix: String, ext: String): File {
        val d = dir(ctx, id)
        val tmp = File(d, "$prefix.tmp")
        (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")).use { i ->
            tmp.outputStream().use { o -> i.copyTo(o) }
        }
        d.listFiles()?.filter { it.name.startsWith("$prefix.") && it.name != tmp.name }?.forEach { it.delete() }
        val dst = File(d, "$prefix.$ext")
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
        return dst
    }

    fun fileWith(ctx: Context, id: String, prefix: String): File? =
        dir(ctx, id).listFiles()?.firstOrNull { it.name.startsWith("$prefix.") && !it.name.endsWith(".tmp") }

    fun animFile(ctx: Context, id: String) = File(dir(ctx, id), "animacao.vmd")

    /** Grava a animação do projeto; null apaga. */
    fun saveAnim(ctx: Context, id: String, bytes: ByteArray?) {
        val f = animFile(ctx, id)
        if (bytes == null) f.delete() else f.writeBytes(bytes)
    }
}
