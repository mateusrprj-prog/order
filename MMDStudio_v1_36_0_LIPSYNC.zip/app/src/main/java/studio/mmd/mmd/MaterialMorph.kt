package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Elemento de morph de material (PMX tipo 8). [mat] = -1 vale para todos os materiais. [v] = 16 valores, ver [MaterialMorphs.CH]. */
class MatMorphElem(val mat: Int, val add: Boolean, val v: FloatArray)

/**
 * Morphs de material (v1.12.1). Canais por material (16 floats): difusa RGBA (0-3), especular RGB (4-6), brilho (7),
 * ambiente RGB (8-10), cor da borda RGBA (11-14), espessura da borda (15).
 * Regra (leitura comum da especificação PMX, NÃO comparada com o MMD oficial): modo multiplicar mistura o fator de 1 até o valor
 * com o peso (1 + (v-1)*w) e os fatores se multiplicam; modo somar acumula v*w; final = base * fator + soma.
 * Os coeficientes de textura/esfera/toon dos elementos são lidos e IGNORADOS (sem efeito no render).
 */
object MaterialMorphs {
    const val CH = 16

    /** Decodifica os bytes brutos preservados pelo parser. O tamanho do índice de material sai de raw.size / count - 113. */
    fun decode(mo: PmxMorph): List<MatMorphElem> {
        val raw = mo.raw ?: return emptyList()
        if (mo.count <= 0 || raw.size % mo.count != 0) return emptyList()
        val size = raw.size / mo.count
        val mS = size - 113
        if (mS != 1 && mS != 2 && mS != 4) return emptyList()
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val out = ArrayList<MatMorphElem>(mo.count)
        for (k in 0 until mo.count) {
            var o = k * size
            val idx = when (mS) { 1 -> bb.get(o).toInt(); 2 -> bb.getShort(o).toInt(); else -> bb.getInt(o) }
            o += mS
            val add = bb.get(o).toInt() == 1
            o += 1
            val v = FloatArray(CH)
            for (c in 0 until CH) v[c] = bb.getFloat(o + c * 4)
            out.add(MatMorphElem(idx, add, v))
        }
        return out
    }
}

/** Acúmulo por quadro dos morphs de material (sem alocação por quadro). */
class MaterialMorphState(val count: Int) {
    private val mul = FloatArray(count * MaterialMorphs.CH)
    private val add = FloatArray(count * MaterialMorphs.CH)
    var active = false; private set

    init { reset() }

    fun reset() { java.util.Arrays.fill(mul, 1f); java.util.Arrays.fill(add, 0f); active = false }

    fun apply(e: MatMorphElem, w: Float) {
        if (w.isNaN() || w.isInfinite()) return
        val first = if (e.mat < 0) 0 else e.mat
        val last = if (e.mat < 0) count - 1 else e.mat
        if (first >= count) return
        active = true
        for (mi in first..last) {
            val o = mi * MaterialMorphs.CH
            for (c in 0 until MaterialMorphs.CH) {
                if (e.add) add[o + c] += e.v[c] * w else mul[o + c] *= 1f + (e.v[c] - 1f) * w
            }
        }
    }

    /** Valores finais (base * fator + soma, com limites) de todos os materiais em [out] (count * CH floats). */
    fun finalize(mats: List<PmxMaterial>, out: FloatArray) {
        val ch = MaterialMorphs.CH
        for (mi in 0 until minOf(count, mats.size)) {
            val mt = mats[mi]; val o = mi * ch
            for (c in 0..3) out[o + c] = (mt.diffuse.getOrElse(c) { if (c == 3) 1f else 0f } * mul[o + c] + add[o + c]).coerceIn(0f, 1f)
            for (c in 0..2) out[o + 4 + c] = (mt.specular.getOrElse(c) { 0f } * mul[o + 4 + c] + add[o + 4 + c]).coerceAtLeast(0f)
            out[o + 7] = (mt.specularPower * mul[o + 7] + add[o + 7]).coerceAtLeast(0f)
            for (c in 0..2) out[o + 8 + c] = (mt.ambient.getOrElse(c) { 0f } * mul[o + 8 + c] + add[o + 8 + c]).coerceIn(0f, 1f)
            for (c in 0..3) out[o + 11 + c] = (mt.edgeColor.getOrElse(c) { 0f } * mul[o + 11 + c] + add[o + 11 + c]).coerceIn(0f, 1f)
            out[o + 15] = (mt.edgeSize * mul[o + 15] + add[o + 15]).coerceAtLeast(0f)
        }
    }
}
