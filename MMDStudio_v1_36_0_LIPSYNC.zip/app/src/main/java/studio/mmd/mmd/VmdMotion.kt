package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/** Keyframes de um osso: 7 floats por key (pos xyz + quat xyzw) e 16 bytes de interpolação Bézier por key. */
class VmdTrack(val frames: IntArray, val v: FloatArray, val ip: ByteArray)
class VmdMorphTrack(val frames: IntArray, val w: FloatArray)

/** Keys de IK ligado/desligado de um osso de IK. Valor em degrau: vale o último key com frame <= quadro; antes do primeiro key vale o do primeiro. */
class VmdIkTrack(val frames: IntArray, val on: BooleanArray) {
    fun at(f: Float): Boolean {
        if (frames.isEmpty()) return true
        var k = 0
        while (k + 1 < frames.size && frames[k + 1] <= f) k++
        return on[k]
    }
}

/** Keys de luz do VMD: por key, cor RGB (3 floats) e direção XYZ (3 floats). Lidas e preservadas; ainda sem efeito no render. */
class VmdLightKeys(val frames: IntArray, val color: FloatArray, val dir: FloatArray)

/** Keys de self-shadow do VMD: modo (0 = desligado, 1/2 = modos do MMD) e distância. Lidas e preservadas; ainda sem efeito no render. */
class VmdShadowKeys(val frames: IntArray, val mode: ByteArray, val dist: FloatArray)

/** Seções do VMD além de ossos/morphs/câmera: IK ligado/desligado (aplicado na animação), luz e self-shadow (só preservados). */
class VmdExtras(val ik: Map<String, VmdIkTrack> = emptyMap(), val lights: VmdLightKeys? = null, val shadows: VmdShadowKeys? = null) {
    val isEmpty get() = ik.isEmpty() && lights == null && shadows == null

    /** Chaves de IK agrupadas por quadro (o formato do VMD guarda, por quadro, a lista de IKs com key naquele quadro). */
    private fun ikByFrame(): java.util.TreeMap<Int, MutableList<Pair<String, Boolean>>> {
        val m = java.util.TreeMap<Int, MutableList<Pair<String, Boolean>>>()
        for ((name, t) in ik.toSortedMap()) for (i in t.frames.indices) m.getOrPut(t.frames[i]) { ArrayList() }.add(name to t.on[i])
        return m
    }

    /** Tamanho em bytes das 3 seções (luz, sombra, IK), contando os 3 contadores. */
    fun byteSize(): Int {
        var n = 12 + (lights?.frames?.size ?: 0) * 28 + (shadows?.frames?.size ?: 0) * 9
        for ((_, l) in ikByFrame()) n += 9 + l.size * 21
        return n
    }

    /** Grava luz, sombra e IK (nessa ordem, como no VMD). Nomes de IK em Shift_JIS, 20 bytes. */
    fun write(b: ByteBuffer) {
        val sj = Charset.forName("Shift_JIS")
        val lk = lights; val nl = lk?.frames?.size ?: 0
        b.putInt(nl)
        if (lk != null) for (i in 0 until nl) {
            b.putInt(lk.frames[i]); for (c in 0..2) b.putFloat(lk.color[i * 3 + c]); for (c in 0..2) b.putFloat(lk.dir[i * 3 + c])
        }
        val sk = shadows; val ns = sk?.frames?.size ?: 0
        b.putInt(ns)
        if (sk != null) for (i in 0 until ns) { b.putInt(sk.frames[i]); b.put(sk.mode[i]); b.putFloat(sk.dist[i]) }
        val g = ikByFrame()
        b.putInt(g.size)
        for ((frame, l) in g) {
            b.putInt(frame); b.put(1.toByte()); b.putInt(l.size)
            for ((name, on) in l) {
                val e = name.toByteArray(sj); val a = ByteArray(20); System.arraycopy(e, 0, a, 0, minOf(e.size, 20)); b.put(a)
                b.put(if (on) 1.toByte() else 0.toByte())
            }
        }
    }

    companion object { val EMPTY = VmdExtras() }
}

class VmdMotion(
    val modelName: String,
    val bones: Map<String, VmdTrack>,
    val morphs: Map<String, VmdMorphTrack>,
    val maxFrame: Int,
    /** Avisos do importador (seções ignoradas, keys duplicadas...). */
    val warnings: List<String> = emptyList(),
    /** v1.13.0: IK ligado/desligado, luz e self-shadow do VMD. */
    val extras: VmdExtras = VmdExtras.EMPTY
)

/** Câmera do VMD: por key, distância, centro (xyz), rotação (xyz, rad), fov (graus) e 24 bytes de interpolação (X,Y,Z,rot,dist,fov). */
class VmdCamera(val frames: IntArray, val dist: FloatArray, val pos: FloatArray, val rot: FloatArray, val fov: FloatArray, val ip: ByteArray) {
    val maxFrame get() = if (frames.isEmpty()) 0 else frames[frames.size - 1]

    private fun bez(k: Int, o: Int, s: Float): Float {
        val x1 = (ip[k * 24 + o].toInt() and 0xFF) / 127f; val x2 = (ip[k * 24 + o + 1].toInt() and 0xFF) / 127f
        val y1 = (ip[k * 24 + o + 2].toInt() and 0xFF) / 127f; val y2 = (ip[k * 24 + o + 3].toInt() and 0xFF) / 127f
        var lo = 0f; var hi = 1f; var t = s
        for (i in 0 until 14) {
            t = (lo + hi) * 0.5f
            val u = 1 - t
            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
            if (x < s) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
    }

    /** out = [dist, cx, cy, cz, rx, ry, rz, fov] no quadro [f]. */
    fun evaluate(f: Float, out: FloatArray) {
        val n = frames.size
        if (n == 0) return
        var k = 0
        while (k + 1 < n && frames[k + 1] <= f) k++
        if (k + 1 >= n || f <= frames[k]) {
            out[0] = dist[k]; for (c in 0..2) { out[1 + c] = pos[k * 3 + c]; out[4 + c] = rot[k * 3 + c] }; out[7] = fov[k]; return
        }
        val k2 = k + 1
        val t = ((f - frames[k]) / (frames[k2] - frames[k]).toFloat()).coerceIn(0f, 1f)
        fun mix(a: Float, b: Float, w: Float) = a + (b - a) * w
        val wx = bez(k2, 0, t); val wy = bez(k2, 4, t); val wz = bez(k2, 8, t)
        val wr = bez(k2, 12, t); val wd = bez(k2, 16, t); val wf = bez(k2, 20, t)
        out[0] = mix(dist[k], dist[k2], wd)
        out[1] = mix(pos[k * 3], pos[k2 * 3], wx); out[2] = mix(pos[k * 3 + 1], pos[k2 * 3 + 1], wy); out[3] = mix(pos[k * 3 + 2], pos[k2 * 3 + 2], wz)
        for (c in 0..2) out[4 + c] = mix(rot[k * 3 + c], rot[k2 * 3 + c], wr)
        out[7] = mix(fov[k], fov[k2], wf)
    }
}

/** Leitor de VMD (versões 1 e 2). Lê keyframes de ossos e morphs; câmera é lida à parte; IK ligado/desligado é aplicado (v1.13.0); luz e self-shadow são lidos e preservados em [VmdExtras], sem efeito no render. */
object VmdParser {
    private val SJIS: Charset = Charset.forName("Shift_JIS")

    private class BKey(val frame: Int, val v: FloatArray, val ip: ByteArray)

    fun parse(data: ByteArray): VmdMotion {
        if (data.size < 50) throw IllegalArgumentException("Arquivo VMD muito pequeno")
        if (!String(data, 0, 30, Charsets.US_ASCII).startsWith("Vocaloid Motion Data"))
            throw IllegalArgumentException("Não é um arquivo VMD (assinatura inválida)")
        val v2 = String(data, 0, 30, Charsets.US_ASCII).contains("0002")
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        b.position(30)
        val modelName = str(b, if (v2) 20 else 10)
        var maxFrame = 0
        val warn = ArrayList<String>()
        var dupes = 0

        val nb = b.int
        if (nb < 0 || nb.toLong() * 111 > b.remaining()) throw IllegalArgumentException("VMD truncado (ossos)")
        val boneKeys = HashMap<String, MutableList<BKey>>()
        repeat(nb) {
            val name = str(b, 15); val frame = b.int
            val v = FloatArray(7) { b.float }
            var len = Math.sqrt((v[3] * v[3] + v[4] * v[4] + v[5] * v[5] + v[6] * v[6]).toDouble()).toFloat()
            if (len < 1e-6f) { v[3] = 0f; v[4] = 0f; v[5] = 0f; v[6] = 1f; len = 1f }
            for (k in 3..6) v[k] /= len
            val ip = ByteArray(64); b.get(ip)
            if (frame > maxFrame) maxFrame = frame
            boneKeys.getOrPut(name) { ArrayList() }.add(BKey(frame, v, ip.copyOfRange(0, 16)))
        }
        val bones = boneKeys.mapValues { (_, list0) ->
            list0.sortBy { it.frame }
            // frames repetidos: vale o último do arquivo
            val list = ArrayList<BKey>(list0.size)
            for (k in list0) { if (list.isNotEmpty() && list[list.size - 1].frame == k.frame) { list[list.size - 1] = k; dupes++ } else list.add(k) }
            val v = FloatArray(list.size * 7); val ip = ByteArray(list.size * 16)
            list.forEachIndexed { i, k -> k.v.copyInto(v, i * 7); k.ip.copyInto(ip, i * 16) }
            VmdTrack(IntArray(list.size) { list[it].frame }, v, ip)
        }

        val morphs = HashMap<String, VmdMorphTrack>()
        if (b.remaining() >= 4) {
            val nm = b.int
            if (nm < 0 || nm.toLong() * 23 > b.remaining()) throw IllegalArgumentException("VMD truncado (morphs)")
            val tmp = HashMap<String, MutableList<Pair<Int, Float>>>()
            repeat(nm) {
                val name = str(b, 15); val frame = b.int; val w = b.float
                if (frame > maxFrame) maxFrame = frame
                tmp.getOrPut(name) { ArrayList() }.add(frame to w)
            }
            for ((k, l0) in tmp) {
                l0.sortBy { it.first }
                val l = ArrayList<Pair<Int, Float>>(l0.size)
                for (e in l0) { if (l.isNotEmpty() && l[l.size - 1].first == e.first) { l[l.size - 1] = e; dupes++ } else l.add(e) }
                morphs[k] = VmdMorphTrack(IntArray(l.size) { l[it].first }, FloatArray(l.size) { l[it].second })
            }
        }
        if (dupes > 0) warn.add("$dupes keys repetidas no mesmo quadro (ficou a última).")
        // seções seguintes: câmera (lida à parte), luz, sombra, IK
        var lights: VmdLightKeys? = null; var shadows: VmdShadowKeys? = null; var ik: Map<String, VmdIkTrack> = emptyMap()
        if (b.remaining() >= 4) {
            val nc = b.int
            if (nc < 0 || nc.toLong() * 61 > b.remaining()) warn.add("Seção de câmera truncada ou inválida (contagem $nc).")
            else {
                b.position(b.position() + nc * 61)
                if (b.remaining() >= 4) {
                    val nl = b.int
                    if (nl < 0 || nl.toLong() * 28 > b.remaining()) warn.add("Seção de iluminação truncada ou inválida.")
                    else {
                        if (nl > 0) {
                            val fr = IntArray(nl); val col = FloatArray(nl * 3); val dir = FloatArray(nl * 3)
                            for (k in 0 until nl) { fr[k] = b.int; for (c in 0..2) col[k * 3 + c] = b.float; for (c in 0..2) dir[k * 3 + c] = b.float }
                            lights = sortLights(fr, col, dir)
                            warn.add("$nl keys de iluminação lidas e preservadas (ainda sem efeito no render).")
                        }
                        if (b.remaining() >= 4) {
                            val ns = b.int
                            if (ns < 0 || ns.toLong() * 9 > b.remaining()) warn.add("Seção de self-shadow truncada ou inválida.")
                            else {
                                if (ns > 0) {
                                    val fr = IntArray(ns); val md = ByteArray(ns); val ds = FloatArray(ns)
                                    for (k in 0 until ns) { fr[k] = b.int; md[k] = b.get(); ds[k] = b.float }
                                    shadows = sortShadows(fr, md, ds)
                                    warn.add("$ns keys de self-shadow lidas e preservadas (ainda sem efeito no render).")
                                }
                                if (b.remaining() >= 4) ik = readIk(b, b.int, warn)
                            }
                        }
                    }
                }
            }
        }
        return VmdMotion(modelName, bones, morphs, maxFrame, warn, VmdExtras(ik, lights, shadows))
    }

    private fun sortLights(fr: IntArray, col: FloatArray, dir: FloatArray): VmdLightKeys {
        val ord = fr.indices.sortedBy { fr[it] }
        return VmdLightKeys(IntArray(fr.size) { fr[ord[it]] },
            FloatArray(fr.size * 3) { col[ord[it / 3] * 3 + it % 3] }, FloatArray(fr.size * 3) { dir[ord[it / 3] * 3 + it % 3] })
    }

    private fun sortShadows(fr: IntArray, md: ByteArray, ds: FloatArray): VmdShadowKeys {
        val ord = fr.indices.sortedBy { fr[it] }
        return VmdShadowKeys(IntArray(fr.size) { fr[ord[it]] }, ByteArray(fr.size) { md[ord[it]] }, FloatArray(fr.size) { ds[ord[it]] })
    }

    /** Seção de IK: [count] keys; cada uma = quadro (4), mostrar (1), N (4) e N x (nome 20 + ligado 1). Tolera truncamento (avisa e para). */
    private fun readIk(b: ByteBuffer, count: Int, warn: MutableList<String>): Map<String, VmdIkTrack> {
        if (count < 0) { warn.add("Seção de IK inválida (contagem $count)."); return emptyMap() }
        val tmp = HashMap<String, MutableList<Pair<Int, Boolean>>>()
        var read = 0
        for (i in 0 until count) {
            if (b.remaining() < 9) { warn.add("Seção de IK truncada: leu $read de $count keys."); break }
            val frame = b.int; b.get(); val c = b.int
            if (c < 0 || c.toLong() * 21 > b.remaining()) { warn.add("Seção de IK truncada ou inválida: leu $read de $count keys."); break }
            repeat(c) { val name = str(b, 20); val on = b.get().toInt() != 0; tmp.getOrPut(name) { ArrayList() }.add(frame to on) }
            read++
        }
        val out = HashMap<String, VmdIkTrack>()
        for ((name, l0) in tmp) {
            l0.sortBy { it.first }
            val l = ArrayList<Pair<Int, Boolean>>(l0.size)
            for (e in l0) { if (l.isNotEmpty() && l[l.size - 1].first == e.first) l[l.size - 1] = e else l.add(e) }
            out[name] = VmdIkTrack(IntArray(l.size) { l[it].first }, BooleanArray(l.size) { l[it].second })
        }
        if (read > 0) warn.add("$read keys de IK ligado/desligado aplicadas (${out.size} ossos de IK).")
        return out
    }

    /** Lê só a câmera (seção depois de ossos e morphs). Devolve null se o arquivo não tem keys de câmera. */
    fun parseCamera(data: ByteArray): VmdCamera? = try {
        if (data.size < 50 || !String(data, 0, 30, Charsets.US_ASCII).startsWith("Vocaloid Motion Data")) null else {
            val v2 = String(data, 0, 30, Charsets.US_ASCII).contains("0002")
            val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            b.position(30 + if (v2) 20 else 10)
            val nb = b.int; b.position(b.position() + nb * 111)
            val nm = b.int; b.position(b.position() + nm * 23)
            val nc = if (b.remaining() >= 4) b.int else 0
            if (nc <= 0 || nc.toLong() * 61 > b.remaining()) null else {
                class K(val f: Int, val d: Float, val p: FloatArray, val r: FloatArray, val fov: Float, val ip: ByteArray)
                val ks = ArrayList<K>(nc)
                repeat(nc) {
                    val f = b.int; val d = b.float
                    val p = FloatArray(3) { b.float }; val r = FloatArray(3) { b.float }
                    val ip = ByteArray(24); b.get(ip)
                    val fov = b.int.toFloat(); b.get()
                    ks.add(K(f, d, p, r, fov, ip))
                }
                ks.sortBy { it.f }
                val dist = FloatArray(nc) { ks[it].d }; val pos = FloatArray(nc * 3); val rot = FloatArray(nc * 3)
                val ip = ByteArray(nc * 24)
                for (i in 0 until nc) { for (c in 0..2) { pos[i * 3 + c] = ks[i].p[c]; rot[i * 3 + c] = ks[i].r[c] }; ks[i].ip.copyInto(ip, i * 24) }
                VmdCamera(IntArray(nc) { ks[it].f }, dist, pos, rot, FloatArray(nc) { ks[it].fov }, ip)
            }
        }
    } catch (e: Exception) { null }

    private fun str(b: ByteBuffer, n: Int): String {
        val a = ByteArray(n); b.get(a)
        var e = a.indexOf(0); if (e < 0) e = n
        return String(a, 0, e, SJIS)
    }
}
