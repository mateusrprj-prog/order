# Roteiro para aproximar o MMD Studio do MMD oficial

Este roteiro é uma direção de engenharia, não uma declaração de recursos já concluídos. O alvo é compatibilidade prática, qualidade visual e estabilidade de produção.

## Concluído na cadeia 2.12–2.15
- Auditoria estrutural PMX de malha, materiais, referências, rig, morphs e física preservada.
- Reparo conservador de influências de skinning, com preservação de SDEF válido.
- Higienização de tracks VMD de osso/morph e das curvas de câmera.
- Rollback transacional do solver XPBD no playback de saia.

## Próximos marcos de maior impacto
1. **Compatibilidade PMX 2.1 real:** interpretar e editar soft bodies, anchors, pins e parâmetros; hoje blocos soft body são preservados como dados brutos quando suportado pelo caminho de leitura/escrita, não equivalem a uma simulação PMX 2.1 completa.
2. **Física MMD:** implementar parâmetros e modos de rigid bodies/joints com correspondência ao comportamento Bullet/MMD, incluindo ordem de simulação e sincronização com IK/morph.
3. **Animação VMD:** validar Bezier byte a byte com arquivos de referência, aplicar IK/physics toggles em runtime e finalizar luz/self-shadow VMD no renderer.
4. **Rigging e skinning:** ferramentas de bone weight auto-normalização com heat diffusion/geodesic, transfer entre modelos, SDEF/QDEF round-trip e visualização de deformação.
5. **Roupas:** colisão contínua corpo/tecido, self-collision escalável, fricção, costura/constraints de painel, bake determinístico e caches por pose.
6. **Renderer:** materiais MMD completos (toon, sphere, edge, alpha/culling), shadow maps, transparência ordenada, outline consistente e pós-processamento com perfil de compatibilidade.
7. **Import/export:** corpus de conformidade com MMD/MME, PMX Editor e VMDs reais; round-trip de PMX preservando todos os blocos desconhecidos e índices.
8. **Produção Android:** Gradle reproducível, testes instrumentados, profiling em dispositivos modestos, limites de memória e exportação longa recuperável.

## Critério de qualidade
Cada recurso novo deve ter: fixture de arquivo real, teste de round-trip, comparação com resultado de referência do MMD oficial quando aplicável, teste de regressão, limite de desempenho/memória e nota explícita de compatibilidade. Não declarar paridade até passar pelo corpus e pelos testes visuais em aparelho.
