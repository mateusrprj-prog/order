package studio.mmd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import studio.mmd.project.ProjectStore
import studio.mmd.ui.HomeScreen
import studio.mmd.ui.SceneScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            var openId by rememberSaveable { mutableStateOf<String?>(null) }
            val meta = remember(openId) { openId?.let { ProjectStore.get(ctx, it) } }
            if (meta == null) HomeScreen { openId = it } else SceneScreen(meta) { openId = null }
        }
    }
}
