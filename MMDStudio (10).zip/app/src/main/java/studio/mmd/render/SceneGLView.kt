package studio.mmd.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import android.opengl.GLUtils
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.Animator
import studio.mmd.mmd.VmdMotion
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class TouchMode { ORBIT, PAN, ROTATE, MOVE }
enum class ViewPreset(val yaw: Float, val pitch: Float) {
    FRONT(0f, 0f), BACK(180f, 0f), LEFT(-90f, 0f), RIGHT(90f, 0f), TOP(0f, 89f), BOTTOM(0f, -89f)
}

/** Estado da câmera orbital, compartilhado entre a thread de toque e a thread GL. */
class OrbitCamera {
    @Volatile var yaw = 30f
    @Volatile var pitch = 20f
    @Volatile var dist = 12f
    @Volatile var tx = 0f
    @Volatile var ty = 1f
    @Volatile var tz = 0f

    fun reset() { yaw = 30f; pitch = 20f; dist = 12f; tx = 0f; ty = 1f; tz = 0f }
    fun eye(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf(
            tx + dist * (cos(p) * sin(y)).toFloat(),
            ty + dist * sin(p).toFloat(),
            tz + dist * (cos(p) * cos(y)).toFloat()
        )
    }
}

class SceneGLView(context: Context) : GLSurfaceView(context) {
    val camera = OrbitCamera()
    @Volatile var touchMode = TouchMode.ORBIT
    private val renderer = SceneRenderer(camera)
    private var lastX = 0f; private var lastY = 0f; private var lastCount = 0
    private var downX = 0f; private var downY = 0f; private var downT = 0L; private var multi = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    /** Toque curto (sem arrastar) no viewport, em pixels da view. */
    var onTap: ((Float, Float) -> Unit)? = null
    /** Osso editado pelas ferramentas Girar/Mover (-1 = nenhum; aí o 1 dedo orbita). */
    @Volatile var dragBone = -1
    /** (girar?, valores): quaternion xyzw (girar) ou deslocamento xyz (mover), já no espaço local do pai. Thread principal. */
    var onBoneDrag: ((Boolean, FloatArray) -> Unit)? = null
    var onBoneDragEnd: (() -> Unit)? = null
    private var dragging = false
    private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            camera.dist = (camera.dist / d.scaleFactor).coerceIn(1.5f, 80f); return true
        }
    })

    /** Chamado na thread principal quando o contexto GL está pronto (só então dá para carregar um modelo). */
    var onReady: (() -> Unit)? = null

    /** Cor de fundo do viewport (ARGB). */
    fun setClearColor(argb: Int) {
        renderer.clr = floatArrayOf(android.graphics.Color.red(argb) / 255f, android.graphics.Color.green(argb) / 255f, android.graphics.Color.blue(argb) / 255f)
        requestRender()
    }

    init {
        renderer.onCreated = { post { onReady?.invoke() } }
        setEGLContextClientVersion(3)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun applyPreset(p: ViewPreset) { camera.yaw = p.yaw; camera.pitch = p.pitch; requestRender() }
    /** Envia o modelo para a thread GL (cria buffers e texturas lá). */
    fun loadModel(model: PmxModel, textures: List<ByteArray?>) {
        queueEvent { renderer.loadModel(model, textures); requestRender() }
    }

    fun addProp(id: String, model: PmxModel, textures: List<ByteArray?>, x: Float, y: Float, z: Float, s: Float) {
        queueEvent { renderer.addProp(id, model, textures, x, y, z, s); requestRender() }
    }
    fun removeProp(id: String) { queueEvent { renderer.removeProp(id); requestRender() } }
    fun setProp(id: String, x: Float, y: Float, z: Float, s: Float) { queueEvent { renderer.setProp(id, x, y, z, s); requestRender() } }

    /** Renderiza o quadro [f] limpo (sem grade/esqueleto) e devolve o bitmap da tela; null se falhar. */
    suspend fun captureAwait(f: Int): Bitmap? = suspendCancellableCoroutine { cont ->
        renderer.frame = f.toFloat()
        renderer.captureCb = { b -> if (cont.isActive) cont.resume(b) }
        requestRender()
    }

    fun setFrame(f: Int) { renderer.frame = f.toFloat(); requestRender() }
    fun setMotion(mo: VmdMotion?) { queueEvent { renderer.setMotion(mo); requestRender() } }

    fun frameAll() { camera.reset(); requestRender() }

    /** Liga/desliga o esqueleto desenhado por cima do modelo e define o osso destacado (-1 = nenhum). */
    fun setOverlay(show: Boolean, selected: Int) { renderer.showBones = show; renderer.selectedBone = selected; requestRender() }

    /** Osso mais próximo do ponto (px) ou -1. O resultado volta na thread principal. */
    fun pickBone(x: Float, y: Float, cb: (Int) -> Unit) {
        queueEvent { val r = renderer.pick(x, y); post { cb(r) } }
    }

    private fun sendDrag(dx: Float, dy: Float) {
        val b = dragBone; val rot = touchMode == TouchMode.ROTATE
        queueEvent { val r = renderer.dragBone(b, dx, dy, rot); if (r != null) post { onBoneDrag?.invoke(rot, r) } }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = e.eventTime; multi = false }
            MotionEvent.ACTION_POINTER_DOWN -> multi = true
            MotionEvent.ACTION_UP -> if (!multi && e.eventTime - downT < 350 && hypot(e.x - downX, e.y - downY) < slop) onTap?.invoke(e.x, e.y)
        }
        val n = e.pointerCount
        val x = (0 until n).map { e.getX(it) }.average().toFloat()
        val y = (0 until n).map { e.getY(it) }.average().toFloat()
        if (e.actionMasked == MotionEvent.ACTION_MOVE && n == lastCount && !scale.isInProgress) {
            val dx = x - lastX; val dy = y - lastY
            val tool = touchMode == TouchMode.ROTATE || touchMode == TouchMode.MOVE
            if (n == 1 && tool && dragBone >= 0) {
                if (dragging || hypot(e.x - downX, e.y - downY) > slop) { dragging = true; sendDrag(dx, dy) }
            } else if (n >= 2 || touchMode == TouchMode.PAN) {
                val k = camera.dist * 0.0015f
                val yr = Math.toRadians(camera.yaw.toDouble())
                camera.tx -= (cos(yr) * dx).toFloat() * k
                camera.tz += (sin(yr) * dx).toFloat() * k
                camera.ty += dy * k
            } else {
                camera.yaw -= dx * 0.4f
                camera.pitch = (camera.pitch + dy * 0.4f).coerceIn(-89f, 89f)
            }
        }
        lastX = x; lastY = y; lastCount = n
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            lastCount = 0
            if (dragging) { dragging = false; queueEvent { post { onBoneDragEnd?.invoke() } } }
        }
        requestRender()
        return true
    }
}

private class SceneRenderer(private val cam: OrbitCamera) : GLSurfaceView.Renderer {
    private var program = 0; private var aPos = 0; private var uMvp = 0; private var uColor = 0
    private val proj = FloatArray(16); private val view = FloatArray(16); private val mvp = FloatArray(16)
    private lateinit var gridBuf: java.nio.FloatBuffer; private var gridCount = 0
    private var model: GlModel? = null
    private var animator: Animator? = null
    @Volatile var frame = 0f
    private var lastFrame = -1f
    @Volatile var showBones = false
    @Volatile var selectedBone = -1
    private var vw = 1; private var vh = 1
    /** Pedido de captura: no próximo quadro desenha sem grade/eixos/esqueleto e devolve o bitmap (thread GL). */
    @Volatile var captureCb: ((Bitmap?) -> Unit)? = null
    private var pProg = 0
    private var bonePos = FloatArray(0); private var boneParent = IntArray(0); private var boneVis = BooleanArray(0)
    private var lineArr = FloatArray(0); private var ptArr = FloatArray(0)
    private var lineBuf: java.nio.FloatBuffer? = null; private var ptBuf: java.nio.FloatBuffer? = null

    @Volatile var clr = floatArrayOf(0.02f, 0.02f, 0.025f)
    var onCreated: (() -> Unit)? = null
    private var lastModel: PmxModel? = null
    private var lastTex: List<ByteArray?>? = null
    private var curMotion: VmdMotion? = null

    // ---- cenário / acessórios (modelos estáticos extras)
    private class Prop(val id: String, val model: PmxModel, val tex: List<ByteArray?>, var gm: GlModel?, var x: Float, var y: Float, var z: Float, var s: Float)
    private val props = ArrayList<Prop>()
    private val pmvp = FloatArray(16)

    fun addProp(id: String, m: PmxModel, tex: List<ByteArray?>, x: Float, y: Float, z: Float, s: Float) {
        removeProp(id)
        props.add(Prop(id, m, tex, buildGl(m, tex), x, y, z, s))
    }
    fun removeProp(id: String) {
        props.filter { it.id == id }.forEach { freeGl(it.gm) }
        props.removeAll { it.id == id }
    }
    fun setProp(id: String, x: Float, y: Float, z: Float, s: Float) {
        props.firstOrNull { it.id == id }?.let { it.x = x; it.y = y; it.z = z; it.s = s }
    }
    private fun freeGl(g: GlModel?) {
        if (g == null) return
        GLES20.glDeleteBuffers(2, intArrayOf(g.vbo, g.ibo), 0)
        val t = g.texIds.filter { id -> id != 0 }.toIntArray()
        if (t.isNotEmpty()) GLES20.glDeleteTextures(t.size, t, 0)
    }

    /** Malha estática na pose de repouso (mesma conversão MMD -> GL do modelo principal). */
    private fun buildGl(m: PmxModel, texBytes: List<ByteArray?>): GlModel {
        val sc = 0.1f
        val vc = m.vertexCount
        val vd = FloatArray(vc * 8)
        for (i in 0 until vc) {
            vd[i * 8] = m.positions[i * 3] * sc; vd[i * 8 + 1] = m.positions[i * 3 + 1] * sc; vd[i * 8 + 2] = -m.positions[i * 3 + 2] * sc
            vd[i * 8 + 3] = m.normals[i * 3]; vd[i * 8 + 4] = m.normals[i * 3 + 1]; vd[i * 8 + 5] = -m.normals[i * 3 + 2]
            vd[i * 8 + 6] = m.uvs[i * 2]; vd[i * 8 + 7] = m.uvs[i * 2 + 1]
        }
        val idx = m.indices.copyOf()
        for (t in 0 until idx.size / 3) { val a = idx[t * 3 + 1]; idx[t * 3 + 1] = idx[t * 3 + 2]; idx[t * 3 + 2] = a }
        val ids = IntArray(2); GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        val vbuf = fb(vd)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vd.size * 4, vbuf, GLES20.GL_STATIC_DRAW)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(idx); position(0) }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val texIds = IntArray(m.textures.size) { makeTexture(texBytes.getOrNull(it)) }
        var off = 0
        val mats = m.materials.map { mt ->
            val tex = if (mt.textureIndex in texIds.indices) texIds[mt.textureIndex] else 0
            MatDraw(mt.diffuse, mt.ambient, tex, mt.doubleSided, off * 4, mt.indexCount).also { off += mt.indexCount }
        }
        return GlModel(ids[0], ids[1], texIds, mats, vd, vbuf)
    }

    fun setMotion(mo: VmdMotion?) { curMotion = mo; animator?.motion = mo; lastFrame = -1f }

    private fun updateSkin() {
        val a = animator ?: return; val gm = model ?: return
        if (a.motion == null || frame == lastFrame) return
        lastFrame = frame
        a.evaluate(frame, gm.vd)
        gm.vbuf.position(0); gm.vbuf.put(gm.vd); gm.vbuf.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo)
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, gm.vd.size * 4, gm.vbuf)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }
    private var mProg = 0
    private val tmp = FloatArray(16)
    private lateinit var xAxis: java.nio.FloatBuffer; private lateinit var zAxis: java.nio.FloatBuffer

    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    private fun compile(type: Int, src: String) = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.02f, 0.025f, 1f)
        val vs = compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}")
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        val g = ArrayList<Float>()
        for (i in -10..10) { g += listOf(i.toFloat(), 0f, -10f, i.toFloat(), 0f, 10f, -10f, 0f, i.toFloat(), 10f, 0f, i.toFloat()) }
        gridCount = g.size / 3; gridBuf = fb(g.toFloatArray())
        mProg = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, MODEL_VS))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, MODEL_FS)); GLES20.glLinkProgram(it)
        }
        pProg = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; uniform float uSize; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0); gl_PointSize=uSize;}"))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")); GLES20.glLinkProgram(it)
        }
        xAxis = fb(floatArrayOf(-10f, 0f, 0f, 10f, 0f, 0f))
        zAxis = fb(floatArrayOf(0f, 0f, -10f, 0f, 0f, 10f))
        // contexto GL recriado (app voltou do segundo plano): refaz os buffers e texturas do modelo
        lastModel?.let { loadModel(it, lastTex ?: emptyList(), true) }
        props.forEach { it.gm = buildGl(it.model, it.tex) }
        onCreated?.invoke()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); vw = w; vh = h
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h, 0.1f, 200f)
    }

    private fun draw(buf: java.nio.FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(clr[0], clr[1], clr[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val e = cam.eye()
        val top = cam.pitch > 85f || cam.pitch < -85f
        val upY = if (top) 0f else 1f
        val upZ = if (top) (if (cam.pitch > 0) -1f else 1f) else 0f
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], cam.tx, cam.ty, cam.tz, 0f, upY, upZ)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        val cap = captureCb
        if (cap == null) {
            draw(gridBuf, gridCount, 0.22f, 0.22f, 0.25f)
            draw(xAxis, 2, 0.9f, 0.2f, 0.2f)   // eixo X (vermelho)
            draw(zAxis, 2, 0.2f, 0.4f, 1f)     // eixo Z (azul)
        }
        GLES20.glDisableVertexAttribArray(aPos)
        for (p in props) {
            val g = p.gm ?: continue
            System.arraycopy(mvp, 0, pmvp, 0, 16)
            Matrix.translateM(pmvp, 0, p.x, p.y, p.z); Matrix.scaleM(pmvp, 0, p.s, p.s, p.s)
            drawModel(g, pmvp)
        }
        updateSkin()
        drawModel()
        if (cap == null) drawBones()
        else { captureCb = null; cap(readFrame()) }
    }

    /** Lê o framebuffer atual (origem embaixo-esquerda) e devolve um Bitmap ARGB já na orientação certa. */
    private fun readFrame(): Bitmap? = try {
        val w = vw; val h = vh
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        buf.rewind()
        val raw = IntArray(w * h); buf.asIntBuffer().get(raw)
        val px = IntArray(w * h)
        for (y in 0 until h) {
            val src = (h - 1 - y) * w; val dst = y * w
            for (x in 0 until w) {
                val v = raw[src + x]
                px[dst + x] = (0xFF shl 24) or ((v and 0xFF) shl 16) or (v and 0xFF00) or ((v shr 16) and 0xFF)
            }
        }
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    } catch (e: Throwable) { null }

    /** Esqueleto por cima do modelo (sem teste de profundidade): linhas pai→filho, pontos brancos e o osso selecionado em laranja. */
    private fun drawBones() {
        val a = animator ?: return
        val nb = boneParent.size
        if (!showBones || nb == 0 || a.motion == null) return
        val lb = lineBuf ?: return; val pb = ptBuf ?: return
        a.boneGl(bonePos)
        var lk = 0; var pk = 0
        for (i in 0 until nb) {
            if (!boneVis[i]) continue
            ptArr[pk++] = bonePos[i * 3]; ptArr[pk++] = bonePos[i * 3 + 1]; ptArr[pk++] = bonePos[i * 3 + 2]
            val p = boneParent[i]
            if (p in 0 until nb && p != i && boneVis[p]) {
                lineArr[lk++] = bonePos[p * 3]; lineArr[lk++] = bonePos[p * 3 + 1]; lineArr[lk++] = bonePos[p * 3 + 2]
                lineArr[lk++] = bonePos[i * 3]; lineArr[lk++] = bonePos[i * 3 + 1]; lineArr[lk++] = bonePos[i * 3 + 2]
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        lb.position(0); lb.put(lineArr, 0, lk); lb.position(0)
        GLES20.glLineWidth(2f)
        draw(lb, lk / 3, 0.30f, 0.75f, 1f)
        GLES20.glLineWidth(1f)
        GLES20.glDisableVertexAttribArray(aPos)

        GLES20.glUseProgram(pProg)
        val uM = GLES20.glGetUniformLocation(pProg, "uMvp"); val uS = GLES20.glGetUniformLocation(pProg, "uSize")
        val uC = GLES20.glGetUniformLocation(pProg, "uColor"); val aP = GLES20.glGetAttribLocation(pProg, "aPos")
        GLES20.glUniformMatrix4fv(uM, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aP)
        pb.position(0); pb.put(ptArr, 0, pk); pb.position(0)
        GLES20.glUniform1f(uS, 9f); GLES20.glUniform4f(uC, 1f, 1f, 1f, 1f)
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 12, pb)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, pk / 3)
        val s = selectedBone
        if (s in 0 until nb) {
            val sb = fb(floatArrayOf(bonePos[s * 3], bonePos[s * 3 + 1], bonePos[s * 3 + 2]))
            GLES20.glUniform1f(uS, 20f); GLES20.glUniform4f(uC, 1f, 0.55f, 0.1f, 1f)
            GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 12, sb)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 1)
        }
        GLES20.glDisableVertexAttribArray(aP)
    }

    /**
     * Roda na thread GL. Converte um arrasto de dedo (px) em edição do osso [b], no espaço local do pai.
     * Girar: quaternion (4 floats). Mover: deslocamento (3 floats). GL = MMD com Z invertido: eixo (x,y,-z) e ângulo com sinal trocado.
     */
    fun dragBone(b: Int, dx: Float, dy: Float, rotate: Boolean): FloatArray? {
        val a = animator ?: return null
        if (b !in boneParent.indices || a.motion == null) return null
        val rx = view[0]; val ry = view[4]; val rz = view[8]   // direita da câmera (GL)
        val ux = view[1]; val uy = view[5]; val uz = view[9]   // cima da câmera (GL)
        val o = FloatArray(3)
        if (rotate) {
            val ax = ux * dx + rx * dy; val ay = uy * dx + ry * dy; val az = uz * dx + rz * dy
            val len = Math.sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
            if (len < 1e-6f) return null
            val ang = Math.toRadians((len * 0.4f).toDouble()).toFloat()
            val sn = -sin(ang / 2) / len                       // ângulo invertido (Z espelhado)
            a.toParentSpace(b, ax * sn, ay * sn, -az * sn, o)
            return floatArrayOf(o[0], o[1], o[2], cos(ang / 2))
        }
        val e = cam.eye()
        val px = bonePos[b * 3]; val py = bonePos[b * 3 + 1]; val pz = bonePos[b * 3 + 2]
        val d = Math.sqrt(((px - e[0]) * (px - e[0]) + (py - e[1]) * (py - e[1]) + (pz - e[2]) * (pz - e[2])).toDouble()).toFloat()
        val k = 2f * d * 0.4142f / vh                          // tan(22,5°): metade do FOV de 45°
        val gx = (rx * dx - ux * dy) * k; val gy = (ry * dx - uy * dy) * k; val gz = (rz * dx - uz * dy) * k
        a.toParentSpace(b, gx / 0.1f, gy / 0.1f, -gz / 0.1f, o)
        return o
    }

    /** Roda na thread GL. Projeta cada osso visível com a MVP do último quadro e devolve o mais perto do toque (raio 64 px) ou -1. */
    fun pick(px: Float, py: Float): Int {
        val a = animator ?: return -1
        val nb = boneParent.size
        if (nb == 0 || a.motion == null) return -1
        a.boneGl(bonePos)
        var best = -1; var bd = 64f * 64f
        for (i in 0 until nb) {
            if (!boneVis[i]) continue
            val x = bonePos[i * 3]; val y = bonePos[i * 3 + 1]; val z = bonePos[i * 3 + 2]
            val cx = mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]
            val cy = mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]
            val cw = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
            if (cw <= 0.0001f) continue
            val sx = (cx / cw * 0.5f + 0.5f) * vw; val sy = (1f - (cy / cw * 0.5f + 0.5f)) * vh
            val d = (sx - px) * (sx - px) + (sy - py) * (sy - py)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private class MatDraw(val diffuse: FloatArray, val ambient: FloatArray, val tex: Int, val twoSided: Boolean, val offset: Int, val count: Int)
    private class GlModel(val vbo: Int, val ibo: Int, val texIds: IntArray, val mats: List<MatDraw>, val vd: FloatArray, val vbuf: java.nio.FloatBuffer)

    private fun makeTexture(bytes: ByteArray?): Int {
        if (bytes == null) return 0
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return 0
        val id = IntArray(1); GLES20.glGenTextures(1, id, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return id[0]
    }

    private fun freeModel() {
        model?.let {
            GLES20.glDeleteBuffers(2, intArrayOf(it.vbo, it.ibo), 0)
            val t = it.texIds.filter { id -> id != 0 }.toIntArray()
            if (t.isNotEmpty()) GLES20.glDeleteTextures(t.size, t, 0)
        }
        model = null; animator = null
        bonePos = FloatArray(0); boneParent = IntArray(0); boneVis = BooleanArray(0); lineBuf = null; ptBuf = null
    }

    /** Roda na thread GL. Converte MMD (mão esquerda, -Z frente) para GL (Z invertido, winding invertido), escala 0.1. */
    fun loadModel(m: PmxModel, texBytes: List<ByteArray?>, keepMotion: Boolean = false) {
        freeModel()
        lastModel = m; lastTex = texBytes
        if (!keepMotion) curMotion = null
        val sc = 0.1f
        val vc = m.vertexCount
        val vd = FloatArray(vc * 8)
        var minX = 1e9f; var minY = 1e9f; var minZ = 1e9f; var maxX = -1e9f; var maxY = -1e9f; var maxZ = -1e9f
        for (i in 0 until vc) {
            val x = m.positions[i * 3] * sc; val y = m.positions[i * 3 + 1] * sc; val z = -m.positions[i * 3 + 2] * sc
            vd[i * 8] = x; vd[i * 8 + 1] = y; vd[i * 8 + 2] = z
            vd[i * 8 + 3] = m.normals[i * 3]; vd[i * 8 + 4] = m.normals[i * 3 + 1]; vd[i * 8 + 5] = -m.normals[i * 3 + 2]
            vd[i * 8 + 6] = m.uvs[i * 2]; vd[i * 8 + 7] = m.uvs[i * 2 + 1]
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val idx = m.indices.copyOf()
        for (t in 0 until idx.size / 3) { val a = idx[t * 3 + 1]; idx[t * 3 + 1] = idx[t * 3 + 2]; idx[t * 3 + 2] = a }
        val ids = IntArray(2); GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        val vbuf = fb(vd)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vd.size * 4, vbuf, GLES20.GL_DYNAMIC_DRAW)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(idx); position(0) }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val texIds = IntArray(m.textures.size) { makeTexture(texBytes.getOrNull(it)) }
        var off = 0
        val mats = m.materials.map { mt ->
            val tex = if (mt.textureIndex in texIds.indices) texIds[mt.textureIndex] else 0
            MatDraw(mt.diffuse, mt.ambient, tex, mt.doubleSided, off * 4, mt.indexCount).also { off += mt.indexCount }
        }
        model = GlModel(ids[0], ids[1], texIds, mats, vd, vbuf)
        animator = Animator(m, sc).also { it.motion = curMotion }; lastFrame = -1f
        val nb = m.bones.size
        bonePos = FloatArray(nb * 3); boneParent = IntArray(nb) { m.bones[it].parent }
        val vis = BooleanArray(nb) { m.bones[it].flags and 0x0008 != 0 }
        boneVis = if (vis.any { it }) vis else BooleanArray(nb) { true }
        lineArr = FloatArray(nb * 6); lineBuf = fb(lineArr)
        ptArr = FloatArray(nb * 3); ptBuf = fb(ptArr)
        cam.tx = (minX + maxX) / 2; cam.ty = (minY + maxY) / 2; cam.tz = (minZ + maxZ) / 2
        cam.dist = maxOf(maxX - minX, maxY - minY, maxZ - minZ) * 2.2f
    }

    private fun drawModel(gm0: GlModel? = model, mat: FloatArray = mvp) {
        val gm = gm0 ?: return
        GLES20.glUseProgram(mProg)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(mProg, "uMvp"), 1, false, mat, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(mProg, "uLight"), 0.3f, 0.6f, 0.8f)
        val aP = GLES20.glGetAttribLocation(mProg, "aPos"); val aN = GLES20.glGetAttribLocation(mProg, "aNrm"); val aU = GLES20.glGetAttribLocation(mProg, "aUv")
        val uD = GLES20.glGetUniformLocation(mProg, "uDiffuse"); val uA = GLES20.glGetUniformLocation(mProg, "uAmbient")
        val uH = GLES20.glGetUniformLocation(mProg, "uHasTex"); val uT = GLES20.glGetUniformLocation(mProg, "uTex")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo)
        GLES20.glEnableVertexAttribArray(aP); GLES20.glEnableVertexAttribArray(aN); GLES20.glEnableVertexAttribArray(aU)
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 32, 0)
        GLES20.glVertexAttribPointer(aN, 3, GLES20.GL_FLOAT, false, 32, 12)
        GLES20.glVertexAttribPointer(aU, 2, GLES20.GL_FLOAT, false, 32, 24)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glUniform1i(uT, 0)
        for (md in gm.mats) {
            if (md.count == 0) continue
            if (md.twoSided) GLES20.glDisable(GLES20.GL_CULL_FACE) else GLES20.glEnable(GLES20.GL_CULL_FACE)
            GLES20.glUniform4fv(uD, 1, md.diffuse, 0); GLES20.glUniform3fv(uA, 1, md.ambient, 0)
            GLES20.glUniform1f(uH, if (md.tex != 0) 1f else 0f)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, md.tex)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, md.count, GLES20.GL_UNSIGNED_INT, md.offset)
        }
        GLES20.glDisableVertexAttribArray(aP); GLES20.glDisableVertexAttribArray(aN); GLES20.glDisableVertexAttribArray(aU)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_CULL_FACE); GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }

    private companion object {
        const val MODEL_VS = "uniform mat4 uMvp; attribute vec3 aPos; attribute vec3 aNrm; attribute vec2 aUv; varying vec3 vN; varying vec2 vUv; void main(){vN=aNrm; vUv=aUv; gl_Position=uMvp*vec4(aPos,1.0);}"
        const val MODEL_FS = "precision mediump float; uniform sampler2D uTex; uniform float uHasTex; uniform vec4 uDiffuse; uniform vec3 uAmbient; uniform vec3 uLight; varying vec3 vN; varying vec2 vUv; " +
            "void main(){ vec3 n=normalize(vN); if(!gl_FrontFacing) n=-n; float l=0.5+0.5*max(dot(n,normalize(uLight)),0.0); " +
            "vec4 t = uHasTex>0.5 ? texture2D(uTex,vUv) : vec4(1.0); float a=uDiffuse.a*t.a; if(a<0.02) discard; " +
            "vec3 c = t.rgb*clamp(uDiffuse.rgb+uAmbient*0.3,0.0,1.0)*l; gl_FragColor=vec4(c,a);}"
    }
}
