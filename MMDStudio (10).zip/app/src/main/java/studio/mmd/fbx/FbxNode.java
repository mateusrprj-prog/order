package studio.mmd.fbx;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.zip.Deflater;

/** Nó do FBX binário 7.4. Propriedades são codificadas ao serem adicionadas (arrays já saem comprimidos). */
public final class FbxNode {
    private static final class Prop {
        final byte type; final byte[] data;
        Prop(char t, byte[] d) { type = (byte) t; data = d; }
    }

    public final String name;
    private final byte[] nameBytes;
    private final ArrayList<Prop> props = new ArrayList<>();
    private final ArrayList<FbxNode> children = new ArrayList<>();
    private long cachedSize = -1;
    private long propsLen = -1;

    public FbxNode(String name) {
        this.name = name;
        this.nameBytes = name.getBytes(StandardCharsets.UTF_8);
    }

    public FbxNode child(String childName) {
        FbxNode c = new FbxNode(childName);
        children.add(c);
        return c;
    }

    private static ByteBuffer buf(int n) { return ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN); }

    public FbxNode addInt(int v) { props.add(new Prop('I', buf(4).putInt(v).array())); return this; }
    public FbxNode addLong(long v) { props.add(new Prop('L', buf(8).putLong(v).array())); return this; }
    public FbxNode addDouble(double v) { props.add(new Prop('D', buf(8).putDouble(v).array())); return this; }
    public FbxNode addBool(boolean v) { props.add(new Prop('C', new byte[]{(byte) (v ? 1 : 0)})); return this; }

    public FbxNode addString(String s) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        ByteBuffer bb = buf(4 + b.length); bb.putInt(b.length); bb.put(b);
        props.add(new Prop('S', bb.array())); return this;
    }

    public FbxNode addRaw(byte[] b) {
        ByteBuffer bb = buf(4 + b.length); bb.putInt(b.length); bb.put(b);
        props.add(new Prop('R', bb.array())); return this;
    }

    private static byte[] arr(int count, byte[] raw) {
        byte[] body = raw; int enc = 0;
        if (raw.length >= 256) {
            Deflater d = new Deflater(Deflater.BEST_SPEED);
            d.setInput(raw); d.finish();
            byte[] tmp = new byte[raw.length + 64];
            int n = 0;
            while (!d.finished() && n < tmp.length) n += d.deflate(tmp, n, tmp.length - n);
            if (d.finished() && n < raw.length) { body = java.util.Arrays.copyOf(tmp, n); enc = 1; }
            d.end();
        }
        ByteBuffer bb = buf(12 + body.length);
        bb.putInt(count).putInt(enc).putInt(body.length).put(body);
        return bb.array();
    }

    public FbxNode addDoubles(double[] v) {
        ByteBuffer bb = buf(v.length * 8); for (double x : v) bb.putDouble(x);
        props.add(new Prop('d', arr(v.length, bb.array()))); return this;
    }
    public FbxNode addFloats(float[] v) {
        ByteBuffer bb = buf(v.length * 4); for (float x : v) bb.putFloat(x);
        props.add(new Prop('f', arr(v.length, bb.array()))); return this;
    }
    public FbxNode addInts(int[] v) {
        ByteBuffer bb = buf(v.length * 4); for (int x : v) bb.putInt(x);
        props.add(new Prop('i', arr(v.length, bb.array()))); return this;
    }
    public FbxNode addLongs(long[] v) {
        ByteBuffer bb = buf(v.length * 8); for (long x : v) bb.putLong(x);
        props.add(new Prop('l', arr(v.length, bb.array()))); return this;
    }

    long size() {
        if (cachedSize >= 0) return cachedSize;
        long pl = 0; for (Prop p : props) pl += 1 + p.data.length;
        propsLen = pl;
        long s = 13 + nameBytes.length + pl;
        if (!children.isEmpty()) { for (FbxNode c : children) s += c.size(); s += 13; }
        cachedSize = s; return s;
    }

    private static void u32(OutputStream o, long v) throws IOException {
        o.write((int) (v & 0xFF)); o.write((int) ((v >> 8) & 0xFF)); o.write((int) ((v >> 16) & 0xFF)); o.write((int) ((v >> 24) & 0xFF));
    }

    void write(OutputStream o, long start) throws IOException {
        long total = size();
        u32(o, start + total); u32(o, props.size()); u32(o, propsLen);
        o.write(nameBytes.length); o.write(nameBytes);
        for (Prop p : props) { o.write(p.type); o.write(p.data); }
        if (!children.isEmpty()) {
            long pos = start + 13 + nameBytes.length + propsLen;
            for (FbxNode c : children) { c.write(o, pos); pos += c.size(); }
            o.write(new byte[13]);
        }
    }
}
