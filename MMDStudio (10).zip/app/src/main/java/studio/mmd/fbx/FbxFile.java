package studio.mmd.fbx;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Grava um arquivo FBX binário (versão 7400) a partir dos nós de topo. */
public final class FbxFile {
    private static final byte[] FOOT_ID = {(byte) 0xfa, (byte) 0xbc, (byte) 0xab, 0x09, (byte) 0xd0, (byte) 0xc8, (byte) 0xd4, 0x66,
            (byte) 0xb1, 0x76, (byte) 0xfb, (byte) 0x83, 0x1c, (byte) 0xf7, 0x26, 0x7e};
    private static final byte[] FOOT_MAGIC = {(byte) 0xf8, 0x5a, (byte) 0x8c, 0x6a, (byte) 0xde, (byte) 0xf5, (byte) 0xd9, 0x7e,
            (byte) 0xec, (byte) 0xe9, 0x0c, (byte) 0xe3, 0x75, (byte) 0x8f, 0x29, 0x0b};

    private FbxFile() {}

    public static void write(OutputStream out, List<FbxNode> roots, int version) throws IOException {
        out.write("Kaydara FBX Binary  ".getBytes(StandardCharsets.US_ASCII));
        out.write(0); out.write(0x1A); out.write(0);
        out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(version).array());
        long pos = 27;
        for (FbxNode n : roots) { n.write(out, pos); pos += n.size(); }
        out.write(new byte[13]); pos += 13;
        out.write(FOOT_ID); pos += 16;
        out.write(new byte[4]); pos += 4;
        long pad = ((pos + 15) & ~15L) - pos;
        if (pad == 0) pad = 16;
        out.write(new byte[(int) pad]);
        out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(version).array());
        out.write(new byte[120]);
        out.write(FOOT_MAGIC);
        out.flush();
    }
}
