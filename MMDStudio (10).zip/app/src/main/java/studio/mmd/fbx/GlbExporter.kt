package studio.mmd.fbx

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import studio.mmd.mmd.Animator
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.VmdMotion
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Exporta para glTF 2.0 binário (.glb): malha, materiais, texturas embutidas, esqueleto, pele e animação assada a 30 fps.
 * Formato sem ambiguidade de Euler (rotações em quaternion) e com matrizes de bind explícitas, por isso costuma
 * abrir certo em mais apps do que o FBX. Y para cima, Z invertido (mão direita), 1 unidade MMD = 0,08 m.
 */
object GlbExporter {
    private const val S = 0.08f
    private const val FPS = 30

    private fun fl(a: FloatArray): ByteArray {
        val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); b.asFloatBuffer().put(a); return b.array()
    }
    private fun it32(a: IntArray): ByteArray {
        val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); b.asIntBuffer().put(a); return b.array()
    }
    private fun sh(a: ShortArray): ByteArray {
        val b = ByteBuffer.allocate(a.size * 2).order(ByteOrder.LITTLE_ENDIAN); b.asShortBuffer().put(a); return b.array()
    }
    private fun jarr(vararg v: Number): JSONArray { val a = JSONArray(); for (x in v) a.put(x.toDouble()); return a }
    private fun jlist(l: List<Int>): JSONArray { val a = JSONArray(); for (x in l) a.put(x); return a }

    fun write(out: OutputStream, model: PmxModel, motion: VmdMotion?, tex: List<ByteArray?>, frames: Int): FbxExporter.Report {
        val nb = model.bones.size
        val vc = model.vertexCount
        val bin = ByteArrayOutputStream()
        val views = JSONArray(); val accessors = JSONArray()
        fun align() { while (bin.size() % 4 != 0) bin.write(0) }
        fun view(bytes: ByteArray, target: Int = 0): Int {
            align()
            val o = JSONObject().put("buffer", 0).put("byteOffset", bin.size()).put("byteLength", bytes.size)
            if (target != 0) o.put("target", target)
            bin.write(bytes); views.put(o); return views.length() - 1
        }
        fun accessor(bv: Int, comp: Int, count: Int, type: String, mn: JSONArray? = null, mx: JSONArray? = null): Int {
            val o = JSONObject().put("bufferView", bv).put("componentType", comp).put("count", count).put("type", type)
            if (mn != null) o.put("min", mn)
            if (mx != null) o.put("max", mx)
            accessors.put(o); return accessors.length() - 1
        }

        // ---------- atributos dos vértices
        val pos = FloatArray(vc * 3); val nrm = FloatArray(vc * 3); val uv = FloatArray(vc * 2)
        val mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE); val mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (i in 0 until vc) {
            pos[i * 3] = model.positions[i * 3] * S; pos[i * 3 + 1] = model.positions[i * 3 + 1] * S; pos[i * 3 + 2] = -model.positions[i * 3 + 2] * S
            nrm[i * 3] = model.normals[i * 3]; nrm[i * 3 + 1] = model.normals[i * 3 + 1]; nrm[i * 3 + 2] = -model.normals[i * 3 + 2]
            uv[i * 2] = model.uvs[i * 2]; uv[i * 2 + 1] = model.uvs[i * 2 + 1]
            for (k in 0..2) { val v = pos[i * 3 + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v }
        }
        val joints = ShortArray(vc * 4); val weights = FloatArray(vc * 4)
        for (v in 0 until vc) {
            var tw = 0f
            for (k in 0..3) { val b = model.boneIndices[v * 4 + k]; val w = model.boneWeights[v * 4 + k]; if (b in 0 until nb && w > 0f) tw += w }
            if (tw <= 0f) { weights[v * 4] = 1f; continue }
            var c = 0
            for (k in 0..3) {
                val b = model.boneIndices[v * 4 + k]; val w = model.boneWeights[v * 4 + k]
                if (b !in 0 until nb || w <= 0f) continue
                joints[v * 4 + c] = b.toShort(); weights[v * 4 + c] = w / tw; c++
            }
        }
        val accPos = accessor(view(fl(pos), 34962), 5126, vc, "VEC3", jarr(mn[0], mn[1], mn[2]), jarr(mx[0], mx[1], mx[2]))
        val accNrm = accessor(view(fl(nrm), 34962), 5126, vc, "VEC3")
        val accUv = accessor(view(fl(uv), 34962), 5126, vc, "VEC2")
        val accJ = accessor(view(sh(joints), 34962), 5123, vc, "VEC4")
        val accW = accessor(view(fl(weights), 34962), 5126, vc, "VEC4")

        // ---------- texturas
        val images = JSONArray(); val textures = JSONArray()
        val texMap = HashMap<Int, Int>()
        for (i in model.textures.indices) {
            val b = tex.getOrNull(i) ?: continue
            var data: ByteArray? = null; var mime = ""
            if (b.size > 4 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte()) { data = b; mime = "image/png" }
            else if (b.size > 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte()) { data = b; mime = "image/jpeg" }
            else {
                try {
                    val bm = BitmapFactory.decodeByteArray(b, 0, b.size)
                    if (bm != null) { val bo = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, bo); data = bo.toByteArray(); mime = "image/png" }
                } catch (e: Throwable) { data = null }
            }
            if (data == null) continue
            images.put(JSONObject().put("bufferView", view(data)).put("mimeType", mime))
            textures.put(JSONObject().put("source", images.length() - 1).put("sampler", 0))
            texMap[i] = textures.length() - 1
        }

        // ---------- materiais e primitivas
        val materials = JSONArray(); val prims = JSONArray()
        var off = 0
        for ((mi, mt) in model.materials.withIndex()) {
            val pbr = JSONObject().put("baseColorFactor", jarr(mt.diffuse[0], mt.diffuse[1], mt.diffuse[2], mt.diffuse[3]))
                .put("metallicFactor", 0.0).put("roughnessFactor", 0.8)
            texMap[mt.textureIndex]?.let { pbr.put("baseColorTexture", JSONObject().put("index", it)) }
            val m = JSONObject().put("name", mt.name.ifBlank { "material_$mi" }).put("pbrMetallicRoughness", pbr).put("doubleSided", mt.doubleSided)
            m.put("alphaMode", if (mt.diffuse[3] < 0.999f) "BLEND" else "OPAQUE")
            materials.put(m)
            val tris = minOf(mt.indexCount, model.indices.size - off).coerceAtLeast(0) / 3
            if (tris > 0) {
                val idx = IntArray(tris * 3)
                for (t in 0 until tris) {
                    val a = model.indices[off + t * 3]; val b = model.indices[off + t * 3 + 1]; val c = model.indices[off + t * 3 + 2]
                    idx[t * 3] = a; idx[t * 3 + 1] = c; idx[t * 3 + 2] = b   // Z espelhado: ordem invertida
                }
                val accI = accessor(view(it32(idx), 34963), 5125, idx.size, "SCALAR")
                prims.put(JSONObject().put("attributes", JSONObject().put("POSITION", accPos).put("NORMAL", accNrm).put("TEXCOORD_0", accUv)
                    .put("JOINTS_0", accJ).put("WEIGHTS_0", accW)).put("indices", accI).put("material", mi))
            }
            off += mt.indexCount
        }

        // ---------- nós (ossos) + malha
        val nodes = JSONArray()
        val children = Array(nb) { ArrayList<Int>() }
        val rootBones = ArrayList<Int>()
        val restLocal = FloatArray(nb * 3)
        for (i in 0 until nb) {
            val b = model.bones[i]; val p = b.parent
            if (p in 0 until nb && p != i) {
                val pb = model.bones[p]
                restLocal[i * 3] = (b.x - pb.x) * S; restLocal[i * 3 + 1] = (b.y - pb.y) * S; restLocal[i * 3 + 2] = -(b.z - pb.z) * S
                children[p].add(i)
            } else {
                restLocal[i * 3] = b.x * S; restLocal[i * 3 + 1] = b.y * S; restLocal[i * 3 + 2] = -b.z * S
                rootBones.add(i)
            }
        }
        val used = HashSet<String>()
        for (i in 0 until nb) {
            var nm = model.bones[i].name.ifBlank { "bone_$i" }
            if (!used.add(nm)) { nm = "${nm}_$i"; used.add(nm) }
            val o = JSONObject().put("name", nm).put("translation", jarr(restLocal[i * 3], restLocal[i * 3 + 1], restLocal[i * 3 + 2]))
            if (children[i].isNotEmpty()) o.put("children", jlist(children[i]))
            nodes.put(o)
        }
        val meshNode = nb
        nodes.put(JSONObject().put("name", model.name.ifBlank { "Modelo" }).put("mesh", 0).put("skin", 0))

        // matrizes de bind inversas (só translação)
        val ibm = FloatArray(nb * 16)
        for (i in 0 until nb) {
            val b = model.bones[i]
            ibm[i * 16] = 1f; ibm[i * 16 + 5] = 1f; ibm[i * 16 + 10] = 1f; ibm[i * 16 + 15] = 1f
            ibm[i * 16 + 12] = -b.x * S; ibm[i * 16 + 13] = -b.y * S; ibm[i * 16 + 14] = b.z * S
        }
        val accIbm = accessor(view(fl(ibm)), 5126, nb, "MAT4")
        val skin = JSONObject().put("joints", jlist((0 until nb).toList())).put("inverseBindMatrices", accIbm)
        if (rootBones.isNotEmpty()) skin.put("skeleton", rootBones[0])

        // ---------- animação assada
        val n = maxOf(frames, 1)
        var animCount = 0
        val animations = JSONArray()
        if (motion != null && n > 1 && nb > 0) {
            val an = Animator(model, 1f); an.motion = motion
            val tr = Array(nb) { FloatArray(3 * n) }; val rt = Array(nb) { FloatArray(4 * n) }
            val tmp = FloatArray(7)
            for (f in 0 until n) {
                an.evaluatePose(f.toFloat())
                for (b in 0 until nb) {
                    an.local(b, tmp)
                    tr[b][f * 3] = tmp[0] * S; tr[b][f * 3 + 1] = tmp[1] * S; tr[b][f * 3 + 2] = -tmp[2] * S
                    var qx = -tmp[3]; var qy = -tmp[4]; var qz = tmp[5]; var qw = tmp[6]
                    val l = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
                    if (l > 1e-8f) { qx /= l; qy /= l; qz /= l; qw /= l }
                    if (f > 0) {   // continuidade de sinal para a interpolação linear
                        val r = rt[b]; val o = (f - 1) * 4
                        if (r[o] * qx + r[o + 1] * qy + r[o + 2] * qz + r[o + 3] * qw < 0f) { qx = -qx; qy = -qy; qz = -qz; qw = -qw }
                    }
                    rt[b][f * 4] = qx; rt[b][f * 4 + 1] = qy; rt[b][f * 4 + 2] = qz; rt[b][f * 4 + 3] = qw
                }
            }
            val times = FloatArray(n) { it / FPS.toFloat() }
            val accT = accessor(view(fl(times)), 5126, n, "SCALAR", jarr(0f), jarr(times[n - 1]))
            val samplers = JSONArray(); val channels = JSONArray()
            for (b in 0 until nb) {
                var mvT = false; var mvR = false
                for (f in 0 until n) {
                    for (k in 0..2) {
                        if (abs(tr[b][f * 3 + k] - restLocal[b * 3 + k]) > 1e-5f) mvT = true
                        if (abs(rt[b][f * 4 + k]) > 1e-4f) mvR = true
                    }
                }
                if (mvT) {
                    val acc = accessor(view(fl(tr[b])), 5126, n, "VEC3")
                    samplers.put(JSONObject().put("input", accT).put("output", acc).put("interpolation", "LINEAR"))
                    channels.put(JSONObject().put("sampler", samplers.length() - 1).put("target", JSONObject().put("node", b).put("path", "translation")))
                }
                if (mvR) {
                    val acc = accessor(view(fl(rt[b])), 5126, n, "VEC4")
                    samplers.put(JSONObject().put("input", accT).put("output", acc).put("interpolation", "LINEAR"))
                    channels.put(JSONObject().put("sampler", samplers.length() - 1).put("target", JSONObject().put("node", b).put("path", "rotation")))
                }
                if (mvT || mvR) animCount++
                tr[b] = FloatArray(0); rt[b] = FloatArray(0)
            }
            if (channels.length() > 0) animations.put(JSONObject().put("name", "Take 001").put("samplers", samplers).put("channels", channels))
        }

        // ---------- JSON + contêiner GLB
        val sceneNodes = ArrayList<Int>(rootBones); sceneNodes.add(meshNode)
        val root = JSONObject()
            .put("asset", JSONObject().put("version", "2.0").put("generator", "MMD Studio"))
            .put("scene", 0).put("scenes", JSONArray().put(JSONObject().put("nodes", jlist(sceneNodes))))
            .put("nodes", nodes)
            .put("meshes", JSONArray().put(JSONObject().put("primitives", prims)))
            .put("skins", JSONArray().put(skin))
            .put("materials", materials)
            .put("accessors", accessors).put("bufferViews", views)
            .put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size())))
        if (textures.length() > 0) {
            root.put("textures", textures).put("images", images)
            root.put("samplers", JSONArray().put(JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 10497)))
        }
        if (animations.length() > 0) root.put("animations", animations)

        var json = root.toString().toByteArray(Charsets.UTF_8)
        val jPad = (4 - json.size % 4) % 4
        val binBytes = bin.toByteArray()
        val bPad = (4 - binBytes.size % 4) % 4
        val total = 12 + 8 + json.size + jPad + 8 + binBytes.size + bPad
        fun u32(v: Int) = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
        out.write(u32(0x46546C67)); out.write(u32(2)); out.write(u32(total))
        out.write(u32(json.size + jPad)); out.write(u32(0x4E4F534A)); out.write(json)
        for (i in 0 until jPad) out.write(0x20)
        out.write(u32(binBytes.size + bPad)); out.write(u32(0x004E4942)); out.write(binBytes)
        for (i in 0 until bPad) out.write(0)
        out.flush()
        return FbxExporter.Report(nb, if (animations.length() > 0) n else 0, animCount)
    }
}
