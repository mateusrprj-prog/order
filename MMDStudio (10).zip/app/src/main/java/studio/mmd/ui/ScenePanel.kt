package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.project.PropMeta

/** Painel "Cena": cenário e acessórios extras (modelos PMX estáticos) com posição e escala. */
@Composable
fun ScenePanel(
    props: List<PropMeta>, sel: Int, onSel: (Int) -> Unit,
    onAdd: () -> Unit, onRemove: (Int) -> Unit,
    onChange: (Int, PropMeta) -> Unit, onDone: () -> Unit,
    modifier: Modifier
) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Cenário e acessórios", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("+ Adicionar", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Accent, RoundedCornerShape(6.dp)).clickable { onAdd() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (props.isEmpty()) {
            Text("Importe um .pmx ou .zip (cenário, palco, objeto). O formato .x ainda não é suportado.", color = Muted, fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp))
        }
        props.forEachIndexed { i, p ->
            Row(Modifier.fillMaxWidth().padding(top = 6.dp).background(if (i == sel) Color(0xFF26324A) else Color(0xFF1E2024), RoundedCornerShape(6.dp))
                .clickable { onSel(if (i == sel) -1 else i) }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("Remover", color = Color(0xFFFF6B6B), fontSize = 11.sp, modifier = Modifier.clickable { onRemove(i) }.padding(start = 10.dp))
            }
        }
        val p = props.getOrNull(sel)
        if (p != null) {
            PropSlider("X", p.x, -30f, 30f, { onChange(sel, p.copy(x = it)) }, onDone)
            PropSlider("Y", p.y, -30f, 30f, { onChange(sel, p.copy(y = it)) }, onDone)
            PropSlider("Z", p.z, -30f, 30f, { onChange(sel, p.copy(z = it)) }, onDone)
            PropSlider("Esc", p.s, 0.1f, 5f, { onChange(sel, p.copy(s = it)) }, onDone)
        } else if (props.isNotEmpty()) {
            Text("Toque num objeto para ajustar posição e escala.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
private fun PropSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(26.dp))
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, onValueChangeFinished = onDone, valueRange = min..max, modifier = Modifier.weight(1f))
        Text("%.1f".format(value), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(40.dp))
    }
}
