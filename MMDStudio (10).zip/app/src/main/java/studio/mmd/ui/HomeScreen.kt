package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.project.Aspects
import studio.mmd.project.Backgrounds
import studio.mmd.project.ProjectMeta
import studio.mmd.project.ProjectStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class Item(val meta: ProjectMeta, val size: Long)

private fun loadItems(ctx: android.content.Context) = ProjectStore.list(ctx).map { Item(it, ProjectStore.sizeBytes(ctx, it.id)) }

private fun fmtSize(b: Long) = if (b >= 1024 * 1024) "%.1f MB".format(b / 1048576f) else "%d KB".format(maxOf(1L, b / 1024))

private fun fmtDur(frames: Int): String { val s = frames / FPS; return "%d:%02d".format(s / 60, s % 60) }

/** Tela inicial: lista de projetos + criação de projeto. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf(loadItems(ctx)) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var order by remember { mutableIntStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<ProjectMeta?>(null) }
    var deleting by remember { mutableStateOf<ProjectMeta?>(null) }
    val orders = listOf("Mais recentes", "Mais antigos", "Nome")
    val dayFmt = remember { SimpleDateFormat("d 'de' MMMM 'de' yyyy", Locale("pt", "BR")) }

    val shown = all.filter { query.isBlank() || it.meta.name.contains(query, ignoreCase = true) }.let { l ->
        when (order) {
            0 -> l.sortedByDescending { it.meta.updated }
            1 -> l.sortedBy { it.meta.updated }
            else -> l.sortedBy { it.meta.name.lowercase() }
        }
    }
    val rows = ArrayList<Any>()
    var lastDay = ""
    for (it in shown) {
        if (order < 2) { val d = dayFmt.format(Date(it.meta.updated)); if (d != lastDay) { rows.add(d); lastDay = d } }
        rows.add(it)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                Text("MMD Studio", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Meus projetos", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Search, null, tint = Color.White, modifier = Modifier.clickable { searching = !searching; if (!searching) query = "" }.padding(8.dp).size(22.dp))
                    Row(Modifier.clickable { order = (order + 1) % orders.size }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Ordem: ${orders[order]}", color = Color.White, fontSize = 12.sp)
                        Icon(Icons.Default.SwapVert, null, tint = Color.White, modifier = Modifier.padding(start = 4.dp).size(16.dp))
                    }
                }
                if (searching) {
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = SolidColor(Accent),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(8.dp)).padding(12.dp),
                        decorationBox = { inner -> Box { if (query.isEmpty()) Text("Buscar projeto", color = Muted, fontSize = 14.sp); inner() } }
                    )
                }
                if (all.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Nenhum projeto ainda.\nToque no + para criar.", color = Muted, fontSize = 14.sp)
                    }
                } else if (shown.isEmpty()) {
                    Text("Nenhum projeto encontrado.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp))
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(rows) { r ->
                            if (r is String) Text(r, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                            else if (r is Item) ProjectCard(r, { onOpen(r.meta.id) }, { renaming = r.meta }, { deleting = r.meta })
                        }
                    }
                }
            }
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp).size(64.dp).clip(CircleShape).background(Accent).clickable { creating = true },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, "Novo projeto", tint = Color.White, modifier = Modifier.size(32.dp)) }
        }

        if (creating) {
            val next = (all.mapNotNull { Regex("Projeto (\\d+)").matchEntire(it.meta.name)?.groupValues?.get(1)?.toIntOrNull() }.maxOrNull() ?: all.size) + 1
            NewProjectSheet("Projeto $next", { creating = false }) { name, aspect, res, fps, bg ->
                val m = ProjectStore.create(ctx, name, aspect, res, fps, bg)
                creating = false; onOpen(m.id)
            }
        }
        renaming?.let { m ->
            var t by remember(m.id) { mutableStateOf(m.name) }
            AlertDialog(
                onDismissRequest = { renaming = null }, title = { Text("Renomear projeto") },
                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                confirmButton = { TextButton({ if (t.isNotBlank()) { ProjectStore.rename(ctx, m.id, t.trim()); all = loadItems(ctx) }; renaming = null }) { Text("Salvar") } },
                dismissButton = { TextButton({ renaming = null }) { Text("Cancelar") } }
            )
        }
        deleting?.let { m ->
            AlertDialog(
                onDismissRequest = { deleting = null }, title = { Text("Excluir \"${m.name}\"?") },
                text = { Text("O projeto e os arquivos dele (modelo, animação, áudio) serão apagados do aparelho.") },
                confirmButton = { TextButton({ ProjectStore.delete(ctx, m.id); all = loadItems(ctx); deleting = null }) { Text("Excluir", color = Color(0xFFFF6B6B)) } },
                dismissButton = { TextButton({ deleting = null }) { Text("Cancelar") } }
            )
        }
    }
}

@Composable
private fun ProjectCard(it: Item, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val m = it.meta
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onOpen() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 84.dp, height = 72.dp).background(Color(0xFF0C0D0F), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ViewInAr, null, tint = Muted, modifier = Modifier.size(28.dp))
            Text(fmtDur(m.frames), color = Color.White, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp))
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(m.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${m.aspect}  ·  ${m.resolution}p", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text("${fmtSize(it.size)}  ·  ${m.fps} fps", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Box {
            Icon(Icons.Default.MoreHoriz, null, tint = Color.White, modifier = Modifier.clickable { menu = true }.padding(8.dp).size(24.dp))
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Excluir", color = Color(0xFFFF6B6B)) }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

// ------------------------------------------------------------------ folha "Novo projeto"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewProjectSheet(defaultName: String, onDismiss: () -> Unit, onCreate: (String, String, Int, Int, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var aspect by remember { mutableStateOf("16:9") }
    var res by remember { mutableIntStateOf(1080) }
    var fps by remember { mutableIntStateOf(30) }
    var bg by remember { mutableStateOf("Preto") }
    val frameSize = Aspects.size(aspect, res)

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF121316), sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 16.dp)) {
            Text("Novo projeto", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            BasicTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold), cursorBrush = SolidColor(Accent),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp).background(Panel, RoundedCornerShape(10.dp)).padding(16.dp),
                decorationBox = { inner -> Box { if (name.isEmpty()) Text(defaultName, color = Muted, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); inner() } }
            )
            Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Aspects.all.forEach { (key, r) ->
                    val sel = key == aspect
                    Column(Modifier.weight(1f).clickable { aspect = key }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Canvas(Modifier.size(46.dp)) {
                            val s = size.minDimension
                            if (r <= 0f) {
                                drawRect(if (sel) Accent else Muted, Offset(4f, 4f), Size(s - 8f, s - 8f), style = Stroke(3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))))
                            } else {
                                val w = if (r >= 1f) s * 0.9f else s * 0.9f * r; val h = if (r >= 1f) s * 0.9f / r else s * 0.9f
                                val tl = Offset((s - w) / 2, (s - h) / 2)
                                if (sel) drawRect(Accent, tl, Size(w, h)) else drawRect(Muted, tl, Size(w, h), style = Stroke(3f))
                            }
                        }
                        Text(key, color = if (sel) Color.White else Muted, fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            SettingRow("Resolução", if (frameSize != null) "Tamanho do quadro\n${frameSize.first} × ${frameSize.second}" else "Tamanho do quadro\nlivre") {
                Picker("${res}p", listOf(480, 720, 1080, 1440, 2160).map { "${it}p" }) { res = it.removeSuffix("p").toInt() }
            }
            SettingRow("Quadros por segundo", "Usado na exportação de vídeo") {
                Picker("$fps fps", listOf(24, 30, 60, 120).map { "$it fps" }) { fps = it.removeSuffix(" fps").toInt() }
            }
            SettingRow("Plano de fundo", "Cor do viewport") {
                Picker(bg, Backgrounds.all.map { it.first }, swatch = Color(Backgrounds.color(bg))) { bg = it }
            }
            Text("Criar projeto", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.End).padding(top = 20.dp).clickable { onCreate(name.trim().ifEmpty { defaultName }, aspect, res, fps, bg) }.padding(8.dp))
            Icon(Icons.Default.Close, "Fechar", tint = Color.White, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { onDismiss() }.padding(12.dp).size(28.dp))
        }
    }
}

@Composable
private fun SettingRow(title: String, hint: String, control: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(hint, color = Muted, fontSize = 11.sp)
        }
        Box(Modifier.weight(1f)) { control() }
    }
}

@Composable
private fun Picker(text: String, options: List<String>, swatch: Color? = null, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).clickable { open = true }.padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (swatch != null) Box(Modifier.size(22.dp).background(swatch, RoundedCornerShape(5.dp)))
            Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = if (swatch != null) 10.dp else 0.dp))
            Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted)
        }
        DropdownMenu(open, { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onPick(o) }) }
        }
    }
}
