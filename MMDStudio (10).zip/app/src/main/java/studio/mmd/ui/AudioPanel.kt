package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Painel "Áudio": importar, volume, deslocamento (offset) em relação à animação e remover. */
@Composable
fun AudioPanel(
    name: String?, durationMs: Int, volume: Float, offsetMs: Int,
    onImport: () -> Unit, onVolume: (Float) -> Unit, onOffset: (Int) -> Unit, onRemove: () -> Unit, onDone: () -> Unit,
    modifier: Modifier
) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Áudio", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (name == null) "+ Importar" else "Trocar", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Accent, RoundedCornerShape(6.dp)).clickable { onImport() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (name == null) {
            Text("Importe um .mp3, .wav, .ogg, .m4a, .aac ou .flac. Ele toca junto com o play.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            return@Column
        }
        Text("$name · %.1fs".format(durationMs / 1000f), color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp))
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vol", color = Muted, fontSize = 12.sp, modifier = Modifier.width(30.dp))
            Slider(value = volume.coerceIn(0f, 1f), onValueChange = onVolume, onValueChangeFinished = onDone, valueRange = 0f..1f, modifier = Modifier.weight(1f))
            Text("${(volume * 100).toInt()}%", color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(44.dp))
        }
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Atraso", color = Muted, fontSize = 12.sp, modifier = Modifier.width(44.dp))
            Slider(value = offsetMs.toFloat().coerceIn(-5000f, 5000f), onValueChange = { onOffset(it.toInt() / 10 * 10) }, onValueChangeFinished = onDone,
                valueRange = -5000f..5000f, modifier = Modifier.weight(1f))
            Text("%+.2fs".format(offsetMs / 1000f), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(56.dp))
        }
        Text("Positivo: o áudio entra depois da animação. Negativo: entra antes (pula o começo do áudio).", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("−1 quadro") { onOffset(offsetMs - 33); onDone() }
            Chip("+1 quadro") { onOffset(offsetMs + 33); onDone() }
            Chip("Zerar atraso") { onOffset(0); onDone() }
            Chip("Remover", Color(0xFFFF6B6B)) { onRemove() }
        }
    }
}

@Composable
private fun Chip(text: String, color: Color = Color.White, onClick: () -> Unit) {
    Text(text, color = color, fontSize = 11.sp, maxLines = 1,
        modifier = Modifier.background(Color(0xFF26282D), RoundedCornerShape(6.dp)).clickable { onClick() }.padding(horizontal = 9.dp, vertical = 7.dp))
}
