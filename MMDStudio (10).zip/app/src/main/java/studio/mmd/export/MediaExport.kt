package studio.mmd.export

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import studio.mmd.edit.Editor
import studio.mmd.mmd.PmxModel
import java.io.File
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object MediaExport {
    /** Recorta o centro do bitmap na proporção [ratio] (largura/altura; <=0 = sem recorte). */
    fun cropAspect(src: Bitmap, ratio: Float): Bitmap {
        if (ratio <= 0f) return src
        val w = src.width; val h = src.height
        var fw = w; var fh = (w / ratio).toInt()
        if (fh > h) { fh = h; fw = (h * ratio).toInt() }
        fw = fw.coerceIn(2, w); fh = fh.coerceIn(2, h)
        if (fw == w && fh == h) return src
        return Bitmap.createBitmap(src, (w - fw) / 2, (h - fh) / 2, fw, fh)
    }

    /** Pose VPD (Shift_JIS) do quadro [frame]: todos os ossos que têm keyframes. Morphs não incluídos. */
    fun vpd(model: PmxModel, ed: Editor, frame: Int, baseName: String): ByteArray {
        val sb = StringBuilder()
        sb.append("Vocaloid Pose Data file\r\n\r\n")
        val bones = model.bones.filter { ed.hasTrack(it.name) }
        sb.append(baseName).append(".osm;\t\t// 親ファイル名\r\n")
        sb.append(bones.size).append(";\t\t\t\t// 総ポーズ数\r\n\r\n")
        val o = FloatArray(7)
        for ((i, b) in bones.withIndex()) {
            ed.sampleBone(b.name, frame.toFloat(), o)
            sb.append("Bone").append(i).append('{').append(b.name).append("\r\n")
            sb.append(String.format(Locale.US, "  %.6f,%.6f,%.6f;\t\t// trans x,y,z\r\n", o[0], o[1], o[2]))
            sb.append(String.format(Locale.US, "  %.6f,%.6f,%.6f,%.6f;\t\t// Quaternion x,y,z,w\r\n", o[3], o[4], o[5], o[6]))
            sb.append("}\r\n\r\n")
        }
        return sb.toString().toByteArray(charset("Shift_JIS"))
    }

    /** Compacta a pasta do projeto (modelo, animação, áudio, cenário, config) num zip. */
    fun zipDir(dir: File, out: OutputStream): Int {
        var n = 0
        ZipOutputStream(out).use { z ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(dir).path.replace('\\', '/')))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry(); n++
            }
        }
        return n
    }
}

/** Codificador H.264 → MP4 alimentado com bitmaps (sem áudio). Largura/altura devem ser pares. */
class VideoEncoder(file: File, private val w: Int, private val h: Int, private val fps: Int) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType("video/avc")
    private val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var count = 0

    init {
        val f = MediaFormat.createVideoFormat("video/avc", w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        f.setInteger(MediaFormat.KEY_BIT_RATE, (w.toLong() * h * 6).coerceIn(2_000_000L, 40_000_000L).toInt())
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    fun add(bmp: Bitmap) {
        var idx = codec.dequeueInputBuffer(10_000)
        var tries = 0
        while (idx < 0) {
            drain(false)
            idx = codec.dequeueInputBuffer(10_000)
            if (++tries > 500) throw IllegalStateException("Codificador travou")
        }
        val img = codec.getInputImage(idx) ?: throw IllegalStateException("Codificador sem entrada de imagem")
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val yp = img.planes[0]; val up = img.planes[1]; val vp = img.planes[2]
        val yb = yp.buffer; val ub = up.buffer; val vb = vp.buffer
        for (y in 0 until h) {
            val even = y % 2 == 0
            for (x in 0 until w) {
                val c = px[y * w + x]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                yb.put(y * yp.rowStride + x * yp.pixelStride, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
                if (even && x % 2 == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    ub.put((y / 2) * up.rowStride + (x / 2) * up.pixelStride, u.toByte())
                    vb.put((y / 2) * vp.rowStride + (x / 2) * vp.pixelStride, v.toByte())
                }
            }
        }
        codec.queueInputBuffer(idx, 0, w * h * 3 / 2, count * 1_000_000L / fps, 0)
        count++
        drain(false)
    }

    fun finish() {
        var idx = codec.dequeueInputBuffer(10_000)
        var tries = 0
        while (idx < 0 && tries++ < 500) { drain(false); idx = codec.dequeueInputBuffer(10_000) }
        if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, count * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
        try { codec.stop() } catch (ignored: Throwable) {}
        codec.release()
        try { if (started) muxer.stop() } catch (ignored: Throwable) {}
        muxer.release()
    }

    fun abort() {
        try { codec.stop() } catch (ignored: Throwable) {}
        try { codec.release() } catch (ignored: Throwable) {}
        try { muxer.release() } catch (ignored: Throwable) {}
    }

    private fun drain(end: Boolean) {
        var waits = 0
        while (true) {
            val i = codec.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end || ++waits > 500) return
                continue
            }
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                continue
            }
            if (i < 0) continue
            val buf = codec.getOutputBuffer(i)
            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
            if (buf != null && info.size > 0 && started) {
                buf.position(info.offset); buf.limit(info.offset + info.size)
                muxer.writeSampleData(track, buf, info)
            }
            codec.releaseOutputBuffer(i, false)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
        }
    }
}
