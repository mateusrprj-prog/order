plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "studio.mmd"
    compileSdk = 34
    defaultConfig { applicationId = "studio.mmd"; minSdk = 26; targetSdk = 34; versionCode = 11; versionName = "0.11.0" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
}
