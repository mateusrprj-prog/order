package studio.mmd.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import android.opengl.GLUtils
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.Animator
import studio.mmd.mmd.VmdMotion
import android.opengl.GLES20
import android.opengl.GLES30
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLDisplay
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class TouchMode { ORBIT, PAN, ROTATE, MOVE }
enum class ViewPreset(val yaw: Float, val pitch: Float) {
    FRONT(0f, 0f), BACK(180f, 0f), LEFT(-90f, 0f), RIGHT(90f, 0f), TOP(0f, 89f), BOTTOM(0f, -89f)
}

/** Estado da câmera orbital, compartilhado entre a thread de toque e a thread GL. */
/** Luz direcional: yaw/pitch em graus (de onde a luz vem), intensidade e cor. Padrão = a luz fixa antiga. */
data class LightCfg(val yaw: Float = 21f, val pitch: Float = 35f, val intensity: Float = 1f, val r: Float = 1f, val g: Float = 1f, val b: Float = 1f)

class OrbitCamera {
    @Volatile var yaw = 30f
    @Volatile var pitch = 20f
    @Volatile var dist = 12f
    @Volatile var tx = 0f
    @Volatile var ty = 1f
    @Volatile var tz = 0f

    fun reset() { yaw = 30f; pitch = 20f; dist = 12f; tx = 0f; ty = 1f; tz = 0f }
    fun eye(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf(
            tx + dist * (cos(p) * sin(y)).toFloat(),
            ty + dist * sin(p).toFloat(),
            tz + dist * (cos(p) * cos(y)).toFloat()
        )
    }
}

/** Escolhe um EGLConfig ES3 com MSAA 4x (cai para 2x, depois sem MSAA) e profundidade 24 (cai para 16). */
private class MsaaChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16)) for (samples in intArrayOf(4, 2, 0)) {
            val attrs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth, EGL10.EGL_RENDERABLE_TYPE, 0x40,   // EGL_OPENGL_ES3_BIT
                EGL10.EGL_SURFACE_TYPE, EGL10.EGL_WINDOW_BIT,
                EGL10.EGL_SAMPLE_BUFFERS, if (samples > 0) 1 else 0, EGL10.EGL_SAMPLES, samples, EGL10.EGL_NONE)
            val num = IntArray(1)
            if (!egl.eglChooseConfig(display, attrs, null, 0, num) || num[0] <= 0) continue
            val cfgs = arrayOfNulls<EGLConfig>(1)
            if (egl.eglChooseConfig(display, attrs, cfgs, 1, num)) cfgs[0]?.let { return it }
        }
        throw IllegalArgumentException("Nenhum EGLConfig ES3 disponível")
    }
}

class SceneGLView(context: Context) : GLSurfaceView(context) {
    val camera = OrbitCamera()
    @Volatile var touchMode = TouchMode.ORBIT
    private val renderer = SceneRenderer(camera)
    private var lastX = 0f; private var lastY = 0f; private var lastCount = 0
    private var downX = 0f; private var downY = 0f; private var downT = 0L; private var multi = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    /** Toque curto (sem arrastar) no viewport, em pixels da view. */
    var onTap: ((Float, Float) -> Unit)? = null
    /** Osso editado pelas ferramentas Girar/Mover (-1 = nenhum; aí o 1 dedo orbita). */
    @Volatile var dragBone = -1
    /** (girar?, valores): quaternion xyzw (girar) ou deslocamento xyz (mover), já no espaço local do pai. Thread principal. */
    var onBoneDrag: ((Boolean, FloatArray) -> Unit)? = null
    var onBoneDragEnd: (() -> Unit)? = null
    private var dragging = false
    private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            camera.dist = (camera.dist / d.scaleFactor).coerceIn(1.5f, 80f); return true
        }
    })

    /** Chamado na thread principal quando o contexto GL está pronto (só então dá para carregar um modelo). */
    var onReady: (() -> Unit)? = null

    /** Cor de fundo do viewport (ARGB). */
    fun setClearColor(argb: Int) {
        renderer.clr = floatArrayOf(android.graphics.Color.red(argb) / 255f, android.graphics.Color.green(argb) / 255f, android.graphics.Color.blue(argb) / 255f)
        requestRender()
    }

    init {
        renderer.onCreated = { post { onReady?.invoke() } }
        setEGLContextClientVersion(3)
        setEGLConfigChooser(MsaaChooser())
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun applyPreset(p: ViewPreset) { camera.yaw = p.yaw; camera.pitch = p.pitch; requestRender() }
    /** Envia o modelo para a thread GL (cria buffers e texturas lá). */
    fun loadModel(model: PmxModel, textures: List<ByteArray?>) {
        queueEvent { renderer.loadModel(model, textures); requestRender() }
    }

    fun addProp(id: String, model: PmxModel, textures: List<ByteArray?>, x: Float, y: Float, z: Float, s: Float,
                bone: String = "", rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) {
        queueEvent { renderer.addProp(id, model, textures, x, y, z, s, bone, rx, ry, rz); requestRender() }
    }
    fun removeProp(id: String) { queueEvent { renderer.removeProp(id); requestRender() } }
    fun setProp(id: String, x: Float, y: Float, z: Float, s: Float, bone: String = "", rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) {
        queueEvent { renderer.setProp(id, x, y, z, s, bone, rx, ry, rz); requestRender() }
    }

    /** Renderiza o quadro [f] limpo (sem grade/esqueleto) e devolve o bitmap da tela; null se falhar. */
    suspend fun captureAwait(f: Int): Bitmap? = suspendCancellableCoroutine { cont ->
        renderer.frame = f.toFloat()
        renderer.captureCb = { b -> if (cont.isActive) cont.resume(b) }
        requestRender()
    }

    fun setFrame(f: Int) { renderer.frame = f.toFloat(); requestRender() }
    /** Posição fracionária (em quadros de 30 fps) para a prévia a 60 fps. */
    fun setFramePos(f: Float) { renderer.frame = f; requestRender() }
    fun setMotion(mo: VmdMotion?) { queueEvent { renderer.setMotion(mo); requestRender() } }
    /** Força recalcular a pose (ex.: restrições do Rig mudaram). */
    fun refreshPose() { queueEvent { renderer.invalidatePose(); requestRender() } }

    fun frameAll() { camera.reset(); requestRender() }
    /** Chaves ocultas: "model" e "prop:<id>". */
    fun setHidden(h: Set<String>) { renderer.hidden = h; requestRender() }
    fun setLight(c: LightCfg) { renderer.light = c; requestRender() }
    /** Modo de sombreamento: 0 Solid, 1 Material Preview, 2 Rendered, 3 MMD (toon + contorno + esfera). */
    fun setShading(mode: Int) { renderer.shading = mode.coerceIn(0, 3); requestRender() }
    fun setShadows(on: Boolean) { renderer.shadowsOn = on; requestRender() }
    fun setOutline(on: Boolean) { renderer.outlineOn = on; requestRender() }
    /** Quadros desenhados por segundo (média de ~0,5 s). */
    val fps: Float get() = renderer.fps
    /** Erro de compilação de shader, se houve (null = tudo certo). */
    val shaderError: String? get() = renderer.shaderLog
    /** Imagem de fundo (null remove). Fica atrás do modelo e vai para vídeo/PNG exportados. */
    fun setBackgroundImage(b: android.graphics.Bitmap?) { renderer.bgBmp = b; renderer.bgDirty = true; requestRender() }
    /** Câmera do VMD (null = câmera livre). flipX inverte a inclinação, caso o arquivo use o sinal oposto. */
    fun setVmdCamera(c: studio.mmd.mmd.VmdCamera?, flipX: Boolean) { renderer.vmdCam = c; renderer.camFlipX = flipX; requestRender() }

    /** Liga/desliga o esqueleto desenhado por cima do modelo e define o osso destacado (-1 = nenhum). */
    fun setOverlay(show: Boolean, selected: Int) { renderer.showBones = show; renderer.selectedBone = selected; requestRender() }

    /** Osso mais próximo do ponto (px) ou -1. O resultado volta na thread principal. */
    fun pickBone(x: Float, y: Float, cb: (Int) -> Unit) {
        queueEvent { val r = renderer.pick(x, y); post { cb(r) } }
    }

    private fun sendDrag(dx: Float, dy: Float) {
        val b = dragBone; val rot = touchMode == TouchMode.ROTATE
        queueEvent { val r = renderer.dragBone(b, dx, dy, rot); if (r != null) post { onBoneDrag?.invoke(rot, r) } }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = e.eventTime; multi = false }
            MotionEvent.ACTION_POINTER_DOWN -> multi = true
            MotionEvent.ACTION_UP -> if (!multi && e.eventTime - downT < 350 && hypot(e.x - downX, e.y - downY) < slop) onTap?.invoke(e.x, e.y)
        }
        val n = e.pointerCount
        val x = (0 until n).map { e.getX(it) }.average().toFloat()
        val y = (0 until n).map { e.getY(it) }.average().toFloat()
        if (e.actionMasked == MotionEvent.ACTION_MOVE && n == lastCount && !scale.isInProgress) {
            val dx = x - lastX; val dy = y - lastY
            val tool = touchMode == TouchMode.ROTATE || touchMode == TouchMode.MOVE
            if (n == 1 && tool && dragBone >= 0) {
                if (dragging || hypot(e.x - downX, e.y - downY) > slop) { dragging = true; sendDrag(dx, dy) }
            } else if (n >= 2 || touchMode == TouchMode.PAN) {
                val k = camera.dist * 0.0015f
                val yr = Math.toRadians(camera.yaw.toDouble())
                camera.tx -= (cos(yr) * dx).toFloat() * k
                camera.tz += (sin(yr) * dx).toFloat() * k
                camera.ty += dy * k
            } else {
                camera.yaw -= dx * 0.4f
                camera.pitch = (camera.pitch + dy * 0.4f).coerceIn(-89f, 89f)
            }
        }
        lastX = x; lastY = y; lastCount = n
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            lastCount = 0
            if (dragging) { dragging = false; queueEvent { post { onBoneDragEnd?.invoke() } } }
        }
        requestRender()
        return true
    }
}

private class SceneRenderer(private val cam: OrbitCamera) : GLSurfaceView.Renderer {
    private var program = 0; private var aPos = 0; private var uMvp = 0; private var uColor = 0
    private val proj = FloatArray(16); private val view = FloatArray(16); private val mvp = FloatArray(16)
    private lateinit var gridBuf: java.nio.FloatBuffer; private var gridCount = 0
    private var model: GlModel? = null
    private var animator: Animator? = null
    @Volatile var frame = 0f
    @Volatile var light = LightCfg()
    @Volatile var shading = 1
    @Volatile var hidden: Set<String> = emptySet()
    @Volatile var fps = 0f
    @Volatile var shaderLog: String? = null
    private var fpsCount = 0; private var fpsT = 0L
    private val eyeW = FloatArray(3)
    private var aniso = 0f
    // skinning na GPU: matrizes de osso numa textura RGBA32F (3 texels por osso, 1 linha por osso)
    private var boneTex = 0; private var boneCount = 1
    private var boneRows = FloatArray(12); private var boneBuf: java.nio.FloatBuffer? = null
    private var posMorphedPrev = false
    private var shProg = 0
    private var shX = 0f; private var shZ = 0f; private var shR = 1f; private var shBone = -1
    private val IDENT = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val pmat = FloatArray(16); private val dmvp = FloatArray(16)
    private class MU(p: Int) {
        val mvp = GLES20.glGetUniformLocation(p, "uMvp"); val model = GLES20.glGetUniformLocation(p, "uModel")
        val skinned = GLES20.glGetUniformLocation(p, "uSkinned"); val scl = GLES20.glGetUniformLocation(p, "uScl")
        val bones = GLES20.glGetUniformLocation(p, "uBones"); val tex = GLES20.glGetUniformLocation(p, "uTex")
        val hasTex = GLES20.glGetUniformLocation(p, "uHasTex"); val diffuse = GLES20.glGetUniformLocation(p, "uDiffuse")
        val ambient = GLES20.glGetUniformLocation(p, "uAmbient"); val spec = GLES20.glGetUniformLocation(p, "uSpec")
        val specPow = GLES20.glGetUniformLocation(p, "uSpecPow"); val light = GLES20.glGetUniformLocation(p, "uLight")
        val lightCol = GLES20.glGetUniformLocation(p, "uLightCol"); val eye = GLES20.glGetUniformLocation(p, "uEye")
        val mode = GLES20.glGetUniformLocation(p, "uMode")
        val outline = GLES20.glGetUniformLocation(p, "uOutline"); val shadow = GLES20.glGetUniformLocation(p, "uShadow")
        val sphere = GLES20.glGetUniformLocation(p, "uSphere"); val lightVP = GLES20.glGetUniformLocation(p, "uLightVP")
        val shadowOn = GLES20.glGetUniformLocation(p, "uShadowOn"); val shadowSize = GLES20.glGetUniformLocation(p, "uShadowSize")
        val sphereMode = GLES20.glGetUniformLocation(p, "uSphereMode"); val camR = GLES20.glGetUniformLocation(p, "uCamR")
        val camU = GLES20.glGetUniformLocation(p, "uCamU"); val edge = GLES20.glGetUniformLocation(p, "uEdge")
        val edgePass = GLES20.glGetUniformLocation(p, "uEdgePass")
    }
    // sombra projetada (shadow map), contorno e estado do modo MMD
    @Volatile var shadowsOn = true
    @Volatile var outlineOn = true
    private var sProg = 0; private var su: MU? = null
    private var shTex = 0; private var shFbo = 0; private var shFail = false; private var shadowActive = false
    private val lightVP = FloatArray(16); private val lvM = FloatArray(16); private val lpM = FloatArray(16)
    private var bCx = 0f; private var bCy = 1f; private var bCz = 0f; private var bR = 1.2f
    private var mu: MU? = null
    @Volatile var bgBmp: android.graphics.Bitmap? = null
    @Volatile var bgDirty = false
    private var bgTex = 0; private var bgProg = 0
    private val bgQuad: java.nio.FloatBuffer = java.nio.ByteBuffer.allocateDirect(8 * 4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }
    @Volatile var vmdCam: studio.mmd.mmd.VmdCamera? = null
    @Volatile var camFlipX = false
    private val camOut = FloatArray(8)
    private var lastFrame = -1f
    @Volatile var showBones = false
    @Volatile var selectedBone = -1
    private var vw = 1; private var vh = 1
    /** Pedido de captura: no próximo quadro desenha sem grade/eixos/esqueleto e devolve o bitmap (thread GL). */
    @Volatile var captureCb: ((Bitmap?) -> Unit)? = null
    private var pProg = 0
    private var bonePos = FloatArray(0); private var boneParent = IntArray(0); private var boneVis = BooleanArray(0)
    private var lineArr = FloatArray(0); private var ptArr = FloatArray(0)
    private var lineBuf: java.nio.FloatBuffer? = null; private var ptBuf: java.nio.FloatBuffer? = null

    @Volatile var clr = floatArrayOf(0.02f, 0.02f, 0.025f)
    var onCreated: (() -> Unit)? = null
    private var lastModel: PmxModel? = null
    private var lastTex: List<ByteArray?>? = null
    private var curMotion: VmdMotion? = null

    // ---- cenário / acessórios (modelos estáticos extras)
    private class Prop(val id: String, val model: PmxModel, val tex: List<ByteArray?>, var gm: GlModel?, var x: Float, var y: Float, var z: Float, var s: Float,
                       var bone: String = "", var rx: Float = 0f, var ry: Float = 0f, var rz: Float = 0f)
    private val boneIdx = HashMap<String, Int>()
    private val bmat = FloatArray(16)
    private val props = ArrayList<Prop>()

    fun addProp(id: String, m: PmxModel, tex: List<ByteArray?>, x: Float, y: Float, z: Float, s: Float,
                bone: String = "", rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) {
        removeProp(id)
        props.add(Prop(id, m, tex, buildGl(m, tex), x, y, z, s, bone, rx, ry, rz))
    }
    fun removeProp(id: String) {
        props.filter { it.id == id }.forEach { freeGl(it.gm) }
        props.removeAll { it.id == id }
    }
    fun setProp(id: String, x: Float, y: Float, z: Float, s: Float, bone: String = "", rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) {
        props.firstOrNull { it.id == id }?.let { it.x = x; it.y = y; it.z = z; it.s = s; it.bone = bone; it.rx = rx; it.ry = ry; it.rz = rz }
    }
    private fun freeGl(g: GlModel?) {
        if (g == null) return
        GLES20.glDeleteBuffers(2, intArrayOf(g.vbo, g.ibo), 0)
        if (g.posVbo != 0) GLES20.glDeleteBuffers(1, intArrayOf(g.posVbo), 0)
        val t = g.texIds.filter { id -> id != 0 }.toIntArray()
        if (t.isNotEmpty()) GLES20.glDeleteTextures(t.size, t, 0)
    }

    private fun matDraws(m: PmxModel, texIds: IntArray): List<MatDraw> {
        var off = 0
        return m.materials.map { mt ->
            val tex = if (mt.textureIndex in texIds.indices) texIds[mt.textureIndex] else 0
            val sp = floatArrayOf(mt.specular.getOrElse(0) { 0f }, mt.specular.getOrElse(1) { 0f }, mt.specular.getOrElse(2) { 0f })
            val sph = if (mt.sphereIndex in texIds.indices && (mt.sphereMode == 1 || mt.sphereMode == 2)) texIds[mt.sphereIndex] else 0
            val edge = if ((mt.flags and 0x10) != 0 && mt.edgeColor.size >= 4) mt.edgeColor else null
            MatDraw(mt.diffuse, mt.ambient, sp, mt.specularPower, tex, mt.doubleSided, off * 4, mt.indexCount, sph, mt.sphereMode, edge, mt.edgeSize).also { off += mt.indexCount }
        }
    }

    /** Malha estática na pose de repouso (mesma conversão MMD -> GL do modelo principal). */
    private fun buildGl(m: PmxModel, texBytes: List<ByteArray?>): GlModel {
        val sc = 0.1f
        val vc = m.vertexCount
        val vd = FloatArray(vc * 8)
        for (i in 0 until vc) {
            vd[i * 8] = m.positions[i * 3] * sc; vd[i * 8 + 1] = m.positions[i * 3 + 1] * sc; vd[i * 8 + 2] = -m.positions[i * 3 + 2] * sc
            vd[i * 8 + 3] = m.normals[i * 3]; vd[i * 8 + 4] = m.normals[i * 3 + 1]; vd[i * 8 + 5] = -m.normals[i * 3 + 2]
            vd[i * 8 + 6] = m.uvs[i * 2]; vd[i * 8 + 7] = m.uvs[i * 2 + 1]
        }
        val idx = m.indices.copyOf()
        for (t in 0 until idx.size / 3) { val a = idx[t * 3 + 1]; idx[t * 3 + 1] = idx[t * 3 + 2]; idx[t * 3 + 2] = a }
        val ids = IntArray(2); GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        val vbuf = fb(vd)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vd.size * 4, vbuf, GLES20.GL_STATIC_DRAW)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(idx); position(0) }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val texIds = IntArray(m.textures.size) { makeTexture(texBytes.getOrNull(it)) }
        return GlModel(ids[0], ids[1], texIds, matDraws(m, texIds))
    }

    fun setMotion(mo: VmdMotion?) { curMotion = mo; animator?.motion = mo; lastFrame = -1f }
    fun invalidatePose() { lastFrame = -1f }

    /** Skinning na GPU: só sobe as matrizes de osso (poucos KB) e, se houver morph de vértice, as posições. */
    private fun updateSkin() {
        val a = animator ?: return; val gm = model ?: return
        if (a.motion == null || frame == lastFrame) return
        lastFrame = frame
        a.evaluateRows(frame, boneRows)
        val bb = boneBuf ?: return
        bb.position(0); bb.put(boneRows); bb.position(0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, boneTex)
        GLES30.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, 3, boneCount, GLES20.GL_RGBA, GLES20.GL_FLOAT, bb)
        val morphed = a.vertexMorphed
        val pb = gm.posBuf
        if (pb != null && (morphed || posMorphedPrev)) {
            posMorphedPrev = morphed
            val w = a.morphedPositions
            pb.position(0); pb.put(w); pb.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.posVbo)
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, w.size * 4, pb)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        }
    }
    private var mProg = 0
    private val tmp = FloatArray(16)
    private lateinit var xAxis: java.nio.FloatBuffer; private lateinit var zAxis: java.nio.FloatBuffer

    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src); GLES20.glCompileShader(sh)
        val ok = IntArray(1); GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { shaderLog = GLES20.glGetShaderInfoLog(sh); android.util.Log.e("MMDStudio", "shader: $shaderLog") }
        return sh
    }
    private fun link(vs: String, fs: String): Int = GLES20.glCreateProgram().also {
        GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(it)
        val ok = IntArray(1); GLES20.glGetProgramiv(it, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) { shaderLog = GLES20.glGetProgramInfoLog(it); android.util.Log.e("MMDStudio", "link: $shaderLog") }
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        bgTex = 0; bgProg = 0; bgDirty = bgBmp != null
        GLES20.glClearColor(0.02f, 0.02f, 0.025f, 1f)
        val vs = compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}")
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        val g = ArrayList<Float>()
        for (i in -10..10) { g += listOf(i.toFloat(), 0f, -10f, i.toFloat(), 0f, 10f, -10f, 0f, i.toFloat(), 10f, 0f, i.toFloat()) }
        gridCount = g.size / 3; gridBuf = fb(g.toFloatArray())
        shProg = 0
        mProg = link(MODEL_VS, MODEL_FS)
        mu = MU(mProg)
        sProg = link(MODEL_VS, SHADOW_FS); su = MU(sProg)
        shTex = 0; shFbo = 0; shFail = false; shadowActive = false   // contexto novo: recria o shadow map
        aniso = if ((GLES20.glGetString(GLES20.GL_EXTENSIONS) ?: "").contains("GL_EXT_texture_filter_anisotropic")) 4f else 0f
        pProg = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; uniform float uSize; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0); gl_PointSize=uSize;}"))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")); GLES20.glLinkProgram(it)
        }
        xAxis = fb(floatArrayOf(-10f, 0f, 0f, 10f, 0f, 0f))
        zAxis = fb(floatArrayOf(0f, 0f, -10f, 0f, 0f, 10f))
        // contexto GL recriado (app voltou do segundo plano): refaz os buffers e texturas do modelo
        lastModel?.let { loadModel(it, lastTex ?: emptyList(), true) }
        props.forEach { it.gm = buildGl(it.model, it.tex) }
        onCreated?.invoke()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); vw = w; vh = h
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h, 0.1f, 200f)
    }

    private fun drawBackground() {
        if (bgDirty) {
            bgDirty = false
            if (bgTex != 0) { GLES20.glDeleteTextures(1, intArrayOf(bgTex), 0); bgTex = 0 }
            val b = bgBmp
            if (b != null && !b.isRecycled) {
                val t = IntArray(1); GLES20.glGenTextures(1, t, 0); bgTex = t[0]
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
            }
        }
        val b = bgBmp
        if (bgTex == 0 || b == null || vw <= 0 || vh <= 0) return
        if (bgProg == 0) {
            val vs = compile(GLES20.GL_VERTEX_SHADER, "attribute vec2 aP; uniform vec2 uK; varying vec2 vUv; void main(){ vec2 u=aP*0.5+0.5; vUv=vec2((u.x-0.5)*uK.x+0.5, 1.0-((u.y-0.5)*uK.y+0.5)); gl_Position=vec4(aP,0.0,1.0);}")
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform sampler2D uT; varying vec2 vUv; void main(){ gl_FragColor=vec4(texture2D(uT,vUv).rgb,1.0);}")
            bgProg = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        }
        val va = vw.toFloat() / vh; val ia = b.width.toFloat() / b.height   // "cover": preenche a tela sem distorcer
        val kx = if (va > ia) 1f else va / ia; val ky = if (va > ia) ia / va else 1f
        GLES20.glUseProgram(bgProg)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST); GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(bgProg, "uT"), 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(bgProg, "uK"), kx, ky)
        val a = GLES20.glGetAttribLocation(bgProg, "aP")
        bgQuad.position(0)
        GLES20.glEnableVertexAttribArray(a); GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 8, bgQuad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    private fun draw(buf: java.nio.FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(clr[0], clr[1], clr[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        drawBackground()
        val e = cam.eye()
        val top = cam.pitch > 85f || cam.pitch < -85f
        val upY = if (top) 0f else 1f
        val upZ = if (top) (if (cam.pitch > 0) -1f else 1f) else 0f
        val vc = vmdCam
        var eyeX = e[0]; var eyeY = e[1]; var eyeZ = e[2]
        if (vc != null && vc.frames.isNotEmpty() && vw > 0 && vh > 0) {
            vc.evaluate(frame, camOut)
            val d = camOut[0].toDouble(); val rx = (if (camFlipX) -camOut[4] else camOut[4]).toDouble(); val ry = camOut[5].toDouble(); val rz = camOut[6].toDouble()
            // R = Ry * Rx * Rz aplicado a um vetor (Z primeiro, depois X, depois Y), em coordenadas MMD
            fun rotv(x0: Double, y0: Double, z0: Double): DoubleArray {
                var x = x0; var y = y0; var z = z0
                var t = x * Math.cos(rz) - y * Math.sin(rz); y = x * Math.sin(rz) + y * Math.cos(rz); x = t
                t = y * Math.cos(rx) - z * Math.sin(rx); z = y * Math.sin(rx) + z * Math.cos(rx); y = t
                t = x * Math.cos(ry) + z * Math.sin(ry); z = -x * Math.sin(ry) + z * Math.cos(ry); x = t
                return doubleArrayOf(x, y, z)
            }
            val off = rotv(0.0, 0.0, d); val up = rotv(0.0, 1.0, 0.0)
            val s = 0.1f
            val cx = camOut[1] * s; val cy = camOut[2] * s; val cz = -camOut[3] * s
            eyeX = cx + off[0].toFloat() * s; eyeY = cy + off[1].toFloat() * s; eyeZ = cz - off[2].toFloat() * s
            Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ, cx, cy, cz,
                up[0].toFloat(), up[1].toFloat(), -up[2].toFloat())
            Matrix.perspectiveM(proj, 0, camOut[7].coerceIn(1f, 170f), vw.toFloat() / vh, 0.1f, 500f)
        } else {
            Matrix.perspectiveM(proj, 0, 45f, if (vh > 0) vw.toFloat() / vh else 1f, 0.1f, 200f)
            eyeX = e[0]; eyeY = e[1]; eyeZ = e[2]
            Matrix.setLookAtM(view, 0, e[0], e[1], e[2], cam.tx, cam.ty, cam.tz, 0f, upY, upZ)
        }
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        eyeW[0] = eyeX; eyeW[1] = eyeY; eyeW[2] = eyeZ
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        val cap = captureCb
        if (cap == null) {
            draw(gridBuf, gridCount, 0.22f, 0.22f, 0.25f)
            draw(xAxis, 2, 0.9f, 0.2f, 0.2f)   // eixo X (vermelho)
            draw(zAxis, 2, 0.2f, 0.4f, 1f)     // eixo Z (azul)
        }
        GLES20.glDisableVertexAttribArray(aPos)
        updateSkin()   // antes dos objetos: os presos a ossos usam a pose do quadro atual
        val useSh = shadowsOn && shading >= 2 && model != null && !shFail
        if (useSh) renderShadowMap()
        shadowActive = useSh && shTex != 0 && !shFail
        if (shading == 2 && !shadowActive && "model" !in hidden) drawContactShadow()
        for (p in props) {
            val g = p.gm ?: continue
            if ("prop:" + p.id in hidden) continue
            val bi = if (p.bone.isNotEmpty()) boneIdx[p.bone] else null
            val a = animator
            if (bi != null && a != null && a.motion != null) {
                a.boneMatrixGl(bi, pmat)
                Matrix.rotateM(pmat, 0, p.ry, 0f, 1f, 0f); Matrix.rotateM(pmat, 0, p.rx, 1f, 0f, 0f); Matrix.rotateM(pmat, 0, p.rz, 0f, 0f, 1f)
            } else Matrix.setIdentityM(pmat, 0)
            Matrix.translateM(pmat, 0, p.x, p.y, p.z); Matrix.scaleM(pmat, 0, p.s, p.s, p.s)
            drawModel(g, pmat)
        }
        if ("model" !in hidden) drawModel(edges = true)
        if (cap == null) drawBones()
        else { captureCb = null; cap(readFrame()) }
        fpsCount++
        val now = android.os.SystemClock.elapsedRealtime()
        if (fpsT == 0L) fpsT = now
        if (now - fpsT >= 500) { fps = fpsCount * 1000f / (now - fpsT); fpsCount = 0; fpsT = now }
    }

    /** Sombra de contato suave no chão, sob o osso Centro (só no modo Rendered). */
    private fun drawContactShadow() {
        if (model == null) return
        if (shProg == 0) shProg = link(
            "uniform mat4 uMvp; uniform vec3 uC; uniform float uR; attribute vec2 aP; varying vec2 vP; void main(){ vP=aP; gl_Position=uMvp*vec4(uC.x+aP.x*uR, 0.003, uC.z+aP.y*uR, 1.0); }",
            "precision mediump float; varying vec2 vP; void main(){ float d=clamp(length(vP),0.0,1.0); float a=1.0-smoothstep(0.0,1.0,d); gl_FragColor=vec4(0.0,0.0,0.0,a*a*0.55); }")
        var sx = shX; var sz = shZ
        val a = animator
        if (a != null && a.motion != null && shBone >= 0) { a.boneMatrixGl(shBone, bmat); sx = bmat[12]; sz = bmat[14] }
        GLES20.glUseProgram(shProg)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(shProg, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(shProg, "uC"), sx, 0f, sz)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(shProg, "uR"), shR)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glDepthMask(false)
        GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val ap = GLES20.glGetAttribLocation(shProg, "aP")
        bgQuad.position(0)
        GLES20.glEnableVertexAttribArray(ap); GLES20.glVertexAttribPointer(ap, 2, GLES20.GL_FLOAT, false, 8, bgQuad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(ap)
        GLES20.glDepthMask(true)
    }

    /** Lê o framebuffer atual (origem embaixo-esquerda) e devolve um Bitmap ARGB já na orientação certa. */
    private fun readFrame(): Bitmap? = try {
        val w = vw; val h = vh
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        buf.rewind()
        val raw = IntArray(w * h); buf.asIntBuffer().get(raw)
        val px = IntArray(w * h)
        for (y in 0 until h) {
            val src = (h - 1 - y) * w; val dst = y * w
            for (x in 0 until w) {
                val v = raw[src + x]
                px[dst + x] = (0xFF shl 24) or ((v and 0xFF) shl 16) or (v and 0xFF00) or ((v shr 16) and 0xFF)
            }
        }
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    } catch (e: Throwable) { null }

    /** Esqueleto por cima do modelo (sem teste de profundidade): linhas pai→filho, pontos brancos e o osso selecionado em laranja. */
    private fun drawBones() {
        val a = animator ?: return
        val nb = boneParent.size
        if (!showBones || nb == 0 || a.motion == null) return
        val lb = lineBuf ?: return; val pb = ptBuf ?: return
        a.boneGl(bonePos)
        var lk = 0; var pk = 0
        for (i in 0 until nb) {
            if (!boneVis[i]) continue
            ptArr[pk++] = bonePos[i * 3]; ptArr[pk++] = bonePos[i * 3 + 1]; ptArr[pk++] = bonePos[i * 3 + 2]
            val p = boneParent[i]
            if (p in 0 until nb && p != i && boneVis[p]) {
                lineArr[lk++] = bonePos[p * 3]; lineArr[lk++] = bonePos[p * 3 + 1]; lineArr[lk++] = bonePos[p * 3 + 2]
                lineArr[lk++] = bonePos[i * 3]; lineArr[lk++] = bonePos[i * 3 + 1]; lineArr[lk++] = bonePos[i * 3 + 2]
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        lb.position(0); lb.put(lineArr, 0, lk); lb.position(0)
        GLES20.glLineWidth(2f)
        draw(lb, lk / 3, 1f, 0.35f, 0.35f)
        GLES20.glLineWidth(1f)
        GLES20.glDisableVertexAttribArray(aPos)

        GLES20.glUseProgram(pProg)
        val uM = GLES20.glGetUniformLocation(pProg, "uMvp"); val uS = GLES20.glGetUniformLocation(pProg, "uSize")
        val uC = GLES20.glGetUniformLocation(pProg, "uColor"); val aP = GLES20.glGetAttribLocation(pProg, "aPos")
        GLES20.glUniformMatrix4fv(uM, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aP)
        pb.position(0); pb.put(ptArr, 0, pk); pb.position(0)
        GLES20.glUniform1f(uS, 9f); GLES20.glUniform4f(uC, 1f, 1f, 1f, 1f)
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 12, pb)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, pk / 3)
        val s = selectedBone
        if (s in 0 until nb) {
            val sb = fb(floatArrayOf(bonePos[s * 3], bonePos[s * 3 + 1], bonePos[s * 3 + 2]))
            GLES20.glUniform1f(uS, 20f); GLES20.glUniform4f(uC, 1f, 0.55f, 0.1f, 1f)
            GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 12, sb)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 1)
        }
        GLES20.glDisableVertexAttribArray(aP)
    }

    /**
     * Roda na thread GL. Converte um arrasto de dedo (px) em edição do osso [b], no espaço local do pai.
     * Girar: quaternion (4 floats). Mover: deslocamento (3 floats). GL = MMD com Z invertido: eixo (x,y,-z) e ângulo com sinal trocado.
     */
    fun dragBone(b: Int, dx: Float, dy: Float, rotate: Boolean): FloatArray? {
        val a = animator ?: return null
        if (b !in boneParent.indices || a.motion == null) return null
        val rx = view[0]; val ry = view[4]; val rz = view[8]   // direita da câmera (GL)
        val ux = view[1]; val uy = view[5]; val uz = view[9]   // cima da câmera (GL)
        val o = FloatArray(3)
        if (rotate) {
            val ax = ux * dx + rx * dy; val ay = uy * dx + ry * dy; val az = uz * dx + rz * dy
            val len = Math.sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
            if (len < 1e-6f) return null
            val ang = Math.toRadians((len * 0.4f).toDouble()).toFloat()
            val sn = -sin(ang / 2) / len                       // ângulo invertido (Z espelhado)
            a.toParentSpace(b, ax * sn, ay * sn, -az * sn, o)
            return floatArrayOf(o[0], o[1], o[2], cos(ang / 2))
        }
        val e = cam.eye()
        val px = bonePos[b * 3]; val py = bonePos[b * 3 + 1]; val pz = bonePos[b * 3 + 2]
        val d = Math.sqrt(((px - e[0]) * (px - e[0]) + (py - e[1]) * (py - e[1]) + (pz - e[2]) * (pz - e[2])).toDouble()).toFloat()
        val k = 2f * d * 0.4142f / vh                          // tan(22,5°): metade do FOV de 45°
        val gx = (rx * dx - ux * dy) * k; val gy = (ry * dx - uy * dy) * k; val gz = (rz * dx - uz * dy) * k
        a.toParentSpace(b, gx / 0.1f, gy / 0.1f, -gz / 0.1f, o)
        return o
    }

    /** Roda na thread GL. Projeta cada osso visível com a MVP do último quadro e devolve o mais perto do toque (raio 64 px) ou -1. */
    fun pick(px: Float, py: Float): Int {
        val a = animator ?: return -1
        val nb = boneParent.size
        if (nb == 0 || a.motion == null) return -1
        a.boneGl(bonePos)
        var best = -1; var bd = 64f * 64f
        for (i in 0 until nb) {
            if (!boneVis[i]) continue
            val x = bonePos[i * 3]; val y = bonePos[i * 3 + 1]; val z = bonePos[i * 3 + 2]
            val cx = mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]
            val cy = mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]
            val cw = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
            if (cw <= 0.0001f) continue
            val sx = (cx / cw * 0.5f + 0.5f) * vw; val sy = (1f - (cy / cw * 0.5f + 0.5f)) * vh
            val d = (sx - px) * (sx - px) + (sy - py) * (sy - py)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private class MatDraw(val diffuse: FloatArray, val ambient: FloatArray, val spec: FloatArray, val specPow: Float,
                          val tex: Int, val twoSided: Boolean, val offset: Int, val count: Int,
                          val sphereTex: Int = 0, val sphereMode: Int = 0, val edge: FloatArray? = null, val edgeSize: Float = 0f)
    /** vbo: interleaved (props: pos/nrm/uv 32 B) ou estático do modelo (nrm/uv/bones/pesos 52 B). posVbo: posições dinâmicas (só modelo com skinning na GPU). */
    private class GlModel(val vbo: Int, val ibo: Int, val texIds: IntArray, val mats: List<MatDraw>,
                          val posVbo: Int = 0, val posBuf: java.nio.FloatBuffer? = null) { val skinned get() = posVbo != 0 }

    private fun makeTexture(bytes: ByteArray?): Int {
        if (bytes == null) return 0
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return 0
        val id = IntArray(1); GLES20.glGenTextures(1, id, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        if (aniso > 0f) GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, 0x84FE, aniso)   // GL_TEXTURE_MAX_ANISOTROPY_EXT
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return id[0]
    }

    private fun freeModel() {
        freeGl(model)
        if (boneTex != 0) { GLES20.glDeleteTextures(1, intArrayOf(boneTex), 0); boneTex = 0 }
        posMorphedPrev = false
        model = null; animator = null
        bonePos = FloatArray(0); boneParent = IntArray(0); boneVis = BooleanArray(0); lineBuf = null; ptBuf = null; boneIdx.clear()
    }

    /**
     * Roda na thread GL. Converte MMD (mão esquerda, -Z frente) para GL (Z invertido, winding invertido), escala 0.1.
     * Skinning na GPU: posições brutas (MMD) num VBO dinâmico, normais/UV/ossos/pesos num VBO estático,
     * matrizes de osso numa textura RGBA32F atualizada a cada quadro.
     */
    fun loadModel(m: PmxModel, texBytes: List<ByteArray?>, keepMotion: Boolean = false) {
        freeModel()
        lastModel = m; lastTex = texBytes
        if (!keepMotion) curMotion = null
        val sc = 0.1f
        val vc = m.vertexCount
        val nb = m.bones.size
        val st = FloatArray(vc * 13)
        var minX = 1e9f; var minY = 1e9f; var minZ = 1e9f; var maxX = -1e9f; var maxY = -1e9f; var maxZ = -1e9f
        for (i in 0 until vc) {
            val x = m.positions[i * 3] * sc; val y = m.positions[i * 3 + 1] * sc; val z = -m.positions[i * 3 + 2] * sc
            val o = i * 13
            st[o] = m.normals[i * 3]; st[o + 1] = m.normals[i * 3 + 1]; st[o + 2] = m.normals[i * 3 + 2]
            st[o + 3] = m.uvs[i * 2]; st[o + 4] = m.uvs[i * 2 + 1]
            for (k in 0..3) {
                val bi = m.boneIndices[i * 4 + k]
                st[o + 5 + k] = if (bi in 0 until nb) bi.toFloat() else -1f   // índice inválido = sem influência
                st[o + 9 + k] = m.boneWeights[i * 4 + k]
            }
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val idx = m.indices.copyOf()
        for (t in 0 until idx.size / 3) { val a = idx[t * 3 + 1]; idx[t * 3 + 1] = idx[t * 3 + 2]; idx[t * 3 + 2] = a }
        val ids = IntArray(3); GLES20.glGenBuffers(3, ids, 0)   // 0 estático, 1 índices, 2 posições
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, st.size * 4, fb(st), GLES20.GL_STATIC_DRAW)
        val posBuf = fb(m.positions)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[2])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, m.positions.size * 4, posBuf, GLES20.GL_DYNAMIC_DRAW)
        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(idx); position(0) }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        val texIds = IntArray(m.textures.size) { makeTexture(texBytes.getOrNull(it)) }
        model = GlModel(ids[0], ids[1], texIds, matDraws(m, texIds), ids[2], posBuf)
        val an = Animator(m, sc).also { it.motion = curMotion }; animator = an; lastFrame = -1f

        // textura de matrizes de osso (3 texels por osso), começa no repouso
        boneCount = maxOf(1, nb)
        boneRows = FloatArray(boneCount * 12); an.restRows(boneRows)
        boneBuf = fb(boneRows)
        val tx = IntArray(1); GLES20.glGenTextures(1, tx, 0); boneTex = tx[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, boneTex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES30.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES30.GL_RGBA32F, 3, boneCount, 0, GLES20.GL_RGBA, GLES20.GL_FLOAT, boneBuf)

        bonePos = FloatArray(nb * 3); boneParent = IntArray(nb) { m.bones[it].parent }
        boneIdx.clear(); for (i in 0 until nb) boneIdx.putIfAbsent(m.bones[i].name, i)
        val vis = BooleanArray(nb) { m.bones[it].flags and 0x0008 != 0 }
        boneVis = if (vis.any { it }) vis else BooleanArray(nb) { true }
        lineArr = FloatArray(nb * 6); lineBuf = fb(lineArr)
        ptArr = FloatArray(nb * 3); ptBuf = fb(ptArr)
        shBone = boneIdx["センター"] ?: boneIdx["Center"] ?: boneIdx["center"] ?: -1
        shX = (minX + maxX) / 2; shZ = (minZ + maxZ) / 2
        shR = (maxOf(maxX - minX, maxZ - minZ) * 0.4f).coerceIn(0.45f, 6f)
        cam.tx = (minX + maxX) / 2; cam.ty = (minY + maxY) / 2; cam.tz = (minZ + maxZ) / 2
        bCx = cam.tx; bCy = cam.ty; bCz = cam.tz
        bR = (0.5f * Math.sqrt(((maxX - minX) * (maxX - minX) + (maxY - minY) * (maxY - minY) + (maxZ - minZ) * (maxZ - minZ)).toDouble()).toFloat()).coerceIn(0.3f, 30f)
        cam.dist = maxOf(maxX - minX, maxY - minY, maxZ - minZ) * 2.2f
    }

    private fun drawModel(gm0: GlModel? = model, mm: FloatArray = IDENT, prog: Int = mProg, uu: MU? = mu, vp: FloatArray = mvp, pass: Int = 0, edges: Boolean = false) {
        val gm = gm0 ?: return; val u = uu ?: return
        GLES20.glUseProgram(prog)
        Matrix.multiplyMM(dmvp, 0, vp, 0, mm, 0)
        GLES20.glUniformMatrix4fv(u.mvp, 1, false, dmvp, 0); GLES20.glUniformMatrix4fv(u.model, 1, false, mm, 0)
        GLES20.glUniform1f(u.skinned, if (gm.skinned) 1f else 0f); GLES20.glUniform1f(u.scl, 0.1f)
        val lc = light; val ly = Math.toRadians(lc.yaw.toDouble()); val lp = Math.toRadians(lc.pitch.toDouble())
        GLES20.glUniform3f(u.light, (Math.cos(lp) * Math.sin(ly)).toFloat(), Math.sin(lp).toFloat(), (Math.cos(lp) * Math.cos(ly)).toFloat())
        GLES20.glUniform3f(u.lightCol, lc.r * lc.intensity, lc.g * lc.intensity, lc.b * lc.intensity)
        GLES20.glUniform3f(u.eye, eyeW[0], eyeW[1], eyeW[2]); GLES20.glUniform1i(u.mode, shading)
        GLES20.glUniform1i(u.shadow, 2); GLES20.glUniform1i(u.sphere, 3)
        GLES20.glUniform1f(u.shadowOn, if (shadowActive && pass == 0) 1f else 0f)
        if (shadowActive && pass == 0) {
            GLES20.glUniformMatrix4fv(u.lightVP, 1, false, lightVP, 0); GLES20.glUniform1f(u.shadowSize, SH_SIZE.toFloat())
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, shTex)
        }
        GLES20.glUniform3f(u.camR, view[0], view[4], view[8]); GLES20.glUniform3f(u.camU, view[1], view[5], view[9])
        GLES20.glUniform1f(u.outline, 0f); GLES20.glUniform1f(u.edgePass, 0f); GLES20.glUniform1f(u.sphereMode, 0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        if (gm.skinned) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.posVbo)
            GLES20.glEnableVertexAttribArray(0); GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 12, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo)
            GLES20.glVertexAttribPointer(1, 3, GLES20.GL_FLOAT, false, 52, 0)
            GLES20.glVertexAttribPointer(2, 2, GLES20.GL_FLOAT, false, 52, 12)
            GLES20.glVertexAttribPointer(3, 4, GLES20.GL_FLOAT, false, 52, 20)
            GLES20.glVertexAttribPointer(4, 4, GLES20.GL_FLOAT, false, 52, 36)
            for (k in 1..4) GLES20.glEnableVertexAttribArray(k)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, boneTex)
            GLES20.glUniform1i(u.bones, 1)
        } else {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo)
            GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 32, 0)
            GLES20.glVertexAttribPointer(1, 3, GLES20.GL_FLOAT, false, 32, 12)
            GLES20.glVertexAttribPointer(2, 2, GLES20.GL_FLOAT, false, 32, 24)
            for (k in 0..2) GLES20.glEnableVertexAttribArray(k)
            GLES20.glVertexAttrib4f(3, -1f, -1f, -1f, -1f); GLES20.glVertexAttrib4f(4, 0f, 0f, 0f, 0f)
        }
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glUniform1i(u.tex, 0)
        for (md in gm.mats) {
            if (md.count == 0) continue
            if (pass == 1 || md.twoSided) GLES20.glDisable(GLES20.GL_CULL_FACE) else GLES20.glEnable(GLES20.GL_CULL_FACE)
            GLES20.glUniform4fv(u.diffuse, 1, md.diffuse, 0); GLES20.glUniform3fv(u.ambient, 1, md.ambient, 0)
            GLES20.glUniform3fv(u.spec, 1, md.spec, 0); GLES20.glUniform1f(u.specPow, md.specPow)
            GLES20.glUniform1f(u.hasTex, if (md.tex != 0) 1f else 0f)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, md.tex)
            if (pass == 0) {
                GLES20.glUniform1f(u.sphereMode, if (md.sphereTex != 0) md.sphereMode.toFloat() else 0f)
                if (md.sphereTex != 0) { GLES20.glActiveTexture(GLES20.GL_TEXTURE3); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, md.sphereTex); GLES20.glActiveTexture(GLES20.GL_TEXTURE0) }
            }
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, md.count, GLES20.GL_UNSIGNED_INT, md.offset)
        }
        // contorno (casco invertido): só no modo MMD, só no modelo principal
        if (pass == 0 && edges && shading == 3 && outlineOn) {
            GLES20.glUniform1f(u.edgePass, 1f); GLES20.glUniform1f(u.sphereMode, 0f)
            GLES20.glEnable(GLES20.GL_CULL_FACE); GLES20.glCullFace(GLES20.GL_FRONT)
            for (md in gm.mats) {
                val ec = md.edge ?: continue
                if (md.count == 0 || md.diffuse[3] < 0.5f) continue
                GLES20.glUniform1f(u.outline, md.edgeSize.coerceIn(0.3f, 3f) * 0.005f)
                GLES20.glUniform4fv(u.edge, 1, ec, 0)
                GLES20.glUniform4fv(u.diffuse, 1, md.diffuse, 0); GLES20.glUniform1f(u.hasTex, if (md.tex != 0) 1f else 0f)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, md.tex)
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, md.count, GLES20.GL_UNSIGNED_INT, md.offset)
            }
            GLES20.glUniform1f(u.outline, 0f); GLES20.glUniform1f(u.edgePass, 0f); GLES20.glCullFace(GLES20.GL_BACK)
        }
        for (k in 0..4) GLES20.glDisableVertexAttribArray(k)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0); GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_CULL_FACE); GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }


    /** Shadow map: desenha o modelo (com skinning) da posição da luz, só profundidade. */
    private fun renderShadowMap() {
        val gm = model ?: return; val u = su ?: return
        val prevFbo = IntArray(1); GLES20.glGetIntegerv(GLES20.GL_FRAMEBUFFER_BINDING, prevFbo, 0)
        val vpOld = IntArray(4); GLES20.glGetIntegerv(GLES20.GL_VIEWPORT, vpOld, 0)
        if (shFbo == 0) {
            val t = IntArray(1); GLES20.glGenTextures(1, t, 0); shTex = t[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, shTex)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES30.GL_DEPTH_COMPONENT24, SH_SIZE, SH_SIZE, 0, GLES20.GL_DEPTH_COMPONENT, GLES20.GL_UNSIGNED_INT, null as java.nio.Buffer?)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_MODE, GLES30.GL_COMPARE_REF_TO_TEXTURE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_FUNC, GLES20.GL_LEQUAL)
            val f = IntArray(1); GLES20.glGenFramebuffers(1, f, 0); shFbo = f[0]
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, shFbo)
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT, GLES20.GL_TEXTURE_2D, shTex, 0)
            GLES30.glDrawBuffers(1, intArrayOf(GLES30.GL_NONE), 0); GLES30.glReadBuffer(GLES30.GL_NONE)
            if (GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) != GLES20.GL_FRAMEBUFFER_COMPLETE) {
                shFail = true; shaderLog = "Sombra indisponível neste aparelho (framebuffer incompleto)"
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, prevFbo[0]); return
            }
        }
        // matriz da luz (ortográfica, centrada no osso Centro quando há animação)
        val ly = Math.toRadians(light.yaw.toDouble()); val lp = Math.toRadians(light.pitch.toDouble())
        val lx = (Math.cos(lp) * Math.sin(ly)).toFloat(); val lyy = Math.sin(lp).toFloat(); val lz = (Math.cos(lp) * Math.cos(ly)).toFloat()
        var cx = bCx; val cy = bCy; var cz = bCz
        val a = animator
        if (a != null && a.motion != null && shBone >= 0) { a.boneMatrixGl(shBone, pmat); cx = pmat[12]; cz = pmat[14] }
        val r = bR * 1.35f + 0.6f
        val flat = Math.abs(lyy) > 0.97f
        Matrix.setLookAtM(lvM, 0, cx + lx * r * 2f, cy + lyy * r * 2f, cz + lz * r * 2f, cx, cy, cz, 0f, if (flat) 0f else 1f, if (flat) 1f else 0f)
        Matrix.orthoM(lpM, 0, -r, r, -r, r, 0.1f, r * 4f)
        Matrix.multiplyMM(lightVP, 0, lpM, 0, lvM, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, shFbo)
        GLES20.glViewport(0, 0, SH_SIZE, SH_SIZE)
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL); GLES20.glPolygonOffset(2f, 4f)
        drawModel(gm, IDENT, sProg, u, lightVP, 1)
        GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, prevFbo[0])
        GLES20.glViewport(vpOld[0], vpOld[1], vpOld[2], vpOld[3])
    }

    private companion object {
        // GLSL ES 3.00. Skinning linear (BDEF1/2/4; SDEF como BDEF2) idêntico ao da CPU: cada osso = 3 linhas vec4 já em GL.
        const val MODEL_VS = "#version 300 es\n" +
            "precision highp float; precision highp int; precision highp sampler2D;\n" +
            "uniform float uOutline; uniform mat4 uMvp; uniform mat4 uModel; uniform float uSkinned; uniform float uScl; uniform sampler2D uBones;\n" +
            "layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNrm; layout(location=2) in vec2 aUv;\n" +
            "layout(location=3) in vec4 aBi; layout(location=4) in vec4 aBw;\n" +
            "out vec3 vN; out vec3 vW; out vec2 vUv;\n" +
            "void main(){\n" +
            "  vec3 p = aPos; vec3 n = aNrm;\n" +
            "  if (uSkinned > 0.5) {\n" +
            "    vec3 sp = vec3(0.0); vec3 sn = vec3(0.0); float tw = 0.0; vec4 hp = vec4(aPos, 1.0);\n" +
            "    for (int k = 0; k < 4; k++) {\n" +
            "      float bf = aBi[k]; float w = aBw[k];\n" +
            "      if (bf < -0.5 || w == 0.0) continue;\n" +
            "      int b = int(bf + 0.5);\n" +
            "      vec4 r0 = texelFetch(uBones, ivec2(0, b), 0); vec4 r1 = texelFetch(uBones, ivec2(1, b), 0); vec4 r2 = texelFetch(uBones, ivec2(2, b), 0);\n" +
            "      sp += w * vec3(dot(r0, hp), dot(r1, hp), dot(r2, hp));\n" +
            "      sn += w * vec3(dot(r0.xyz, aNrm), dot(r1.xyz, aNrm), dot(r2.xyz, aNrm));\n" +
            "      tw += w;\n" +
            "    }\n" +
            "    if (tw == 0.0) { sp = vec3(aPos.x, aPos.y, -aPos.z) * uScl; sn = vec3(aNrm.x, aNrm.y, -aNrm.z); }\n" +
            "    p = sp; n = sn;\n" +
            "  }\n" +
            "  if (uOutline > 0.0) p += normalize(n) * uOutline;\n" +
            "  vW = (uModel * vec4(p, 1.0)).xyz; vN = mat3(uModel) * n; vUv = aUv;\n" +
            "  gl_Position = uMvp * vec4(p, 1.0);\n" +
            "}\n"
        // uMode: 0 Solid (cinza neutro, luz de estúdio), 1 Material Preview (textura + luz suave), 2 Rendered (linear + ACES + brilho + borda de luz)
        const val MODEL_FS = "#version 300 es\n" +
            "precision highp float; precision highp sampler2D; precision highp sampler2DShadow;\n" +
            "uniform sampler2D uTex; uniform float uHasTex; uniform vec4 uDiffuse; uniform vec3 uAmbient;\n" +
            "uniform vec3 uSpec; uniform float uSpecPow; uniform vec3 uLight; uniform vec3 uLightCol; uniform vec3 uEye; uniform int uMode;\n" +
            "uniform sampler2DShadow uShadow; uniform sampler2D uSphere; uniform mat4 uLightVP; uniform float uShadowOn; uniform float uShadowSize;\n" +
            "uniform float uSphereMode; uniform vec3 uCamR; uniform vec3 uCamU; uniform vec4 uEdge; uniform float uEdgePass;\n" +
            "in vec3 vN; in vec3 vW; in vec2 vUv; out vec4 oC;\n" +
            "vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0); }\n" +
            "float shadowF(vec3 n){\n" +
            "  if (uShadowOn < 0.5) return 1.0;\n" +
            "  vec4 lp = uLightVP * vec4(vW + n * 0.012, 1.0);\n" +
            "  vec3 pc = lp.xyz / lp.w * 0.5 + 0.5;\n" +
            "  if (pc.x < 0.0 || pc.x > 1.0 || pc.y < 0.0 || pc.y > 1.0 || pc.z > 1.0) return 1.0;\n" +
            "  float s = 0.0; float ts = 1.0 / uShadowSize;\n" +
            "  for (int i = -1; i <= 1; i++) { for (int j = -1; j <= 1; j++) { s += texture(uShadow, vec3(pc.xy + vec2(float(i), float(j)) * ts, pc.z - 0.0012)); } }\n" +
            "  return s / 9.0;\n" +
            "}\n" +
            "void main(){\n" +
            "  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;\n" +
            "  vec3 v = normalize(uEye - vW); vec3 L = normalize(uLight); vec3 h = normalize(L + v);\n" +
            "  vec4 t = uHasTex > 0.5 ? texture(uTex, vUv) : vec4(1.0);\n" +
            "  float a = uDiffuse.a * t.a;\n" +
            "  if (uMode == 0) { if (a < 0.5) discard; a = 1.0; } else if (a < 0.02) discard;\n" +
            "  if (uEdgePass > 0.5) { oC = vec4(uEdge.rgb, uEdge.a * smoothstep(0.1, 0.6, a)); return; }\n" +
            "  float ndv = clamp(dot(n, v), 0.0, 1.0); float key = max(dot(n, L), 0.0); float up = n.y * 0.5 + 0.5;\n" +
            "  vec3 col;\n" +
            "  if (uMode == 0) {\n" +
            "    vec3 base = mix(vec3(0.74), uDiffuse.rgb, 0.25);\n" +
            "    vec3 hemi = mix(vec3(0.28, 0.28, 0.31), vec3(0.62, 0.63, 0.67), up);\n" +
            "    float sp = pow(max(dot(n, h), 0.0), 40.0) * 0.18;\n" +
            "    col = base * (hemi * 0.85 + vec3(0.30) * ndv + 0.30 * key * uLightCol) + vec3(sp);\n" +
            "  } else {\n" +
            "    vec3 alb = clamp(uDiffuse.rgb + uAmbient * 0.3, 0.0, 1.0) * t.rgb;\n" +
            "    vec3 Lf = normalize(vec3(-L.x, 0.25, -L.z)); float fill = max(dot(n, Lf), 0.0);\n" +
            "    if (uMode == 1) {\n" +
            "      vec3 amb = mix(vec3(0.32, 0.31, 0.31), vec3(0.58, 0.60, 0.66), up);\n" +
            "      float sp = pow(max(dot(n, h), 0.0), clamp(uSpecPow, 4.0, 128.0)) * step(0.0, dot(n, L));\n" +
            "      float rim = pow(1.0 - ndv, 3.0);\n" +
            "      col = alb * (amb * 0.75 + key * 0.55 * uLightCol + fill * 0.16 * vec3(0.80, 0.86, 1.0)) + uSpec * sp * 0.35 + rim * 0.10 * vec3(0.75, 0.82, 1.0);\n" +
            "    } else if (uMode == 3) {\n" +
            "      vec2 su = vec2(dot(n, uCamR), -dot(n, uCamU)) * 0.5 + 0.5;\n" +
            "      if (uSphereMode > 0.5 && uSphereMode < 1.5) alb *= texture(uSphere, su).rgb;\n" +
            "      float sh = shadowF(n);\n" +
            "      float lit = smoothstep(0.42, 0.55, dot(n, L) * 0.5 + 0.5) * sh;\n" +
            "      vec3 shade = alb * vec3(0.60, 0.56, 0.70);\n" +
            "      vec3 litc = alb * clamp(0.42 + 0.62 * uLightCol, 0.0, 1.15);\n" +
            "      col = mix(shade, litc, lit);\n" +
            "      float sp = pow(max(dot(n, h), 0.0), clamp(uSpecPow, 4.0, 128.0)) * step(0.0, dot(n, L)) * sh;\n" +
            "      col += uSpec * smoothstep(0.35, 0.6, sp) * 0.35;\n" +
            "      if (uSphereMode > 1.5 && uSphereMode < 2.5) col += texture(uSphere, su).rgb * 0.7;\n" +
            "    } else {\n" +
            "      vec3 albL = pow(alb, vec3(2.2));\n" +
            "      float wrap = clamp((dot(n, L) + 0.25) / 1.25, 0.0, 1.0) * mix(0.2, 1.0, shadowF(n));\n" +
            "      vec3 amb = mix(vec3(0.10, 0.095, 0.09), vec3(0.34, 0.37, 0.45), up) * mix(0.65, 1.0, clamp(n.y * 0.5 + 0.6, 0.0, 1.0));\n" +
            "      float pw = clamp(uSpecPow, 8.0, 200.0);\n" +
            "      float sp = pow(max(dot(n, h), 0.0), pw) * (pw + 8.0) / 25.13 * 0.08 * step(0.0, dot(n, L));\n" +
            "      float rim = pow(1.0 - ndv, 3.5) * (0.25 + 0.75 * max(dot(n, -L), 0.0));\n" +
            "      vec3 lin = albL * (amb + wrap * 1.55 * uLightCol + fill * 0.30 * vec3(0.75, 0.85, 1.0)) + uSpec * sp * uLightCol + rim * 0.35 * vec3(0.80, 0.88, 1.0);\n" +
            "      col = pow(aces(lin * 0.95), vec3(1.0 / 2.2));\n" +
            "    }\n" +
            "  }\n" +
            "  oC = vec4(clamp(col, 0.0, 1.0), a);\n" +
            "}\n"
        const val SHADOW_FS = "#version 300 es\n" +
            "precision highp float; precision highp sampler2D;\n" +
            "uniform sampler2D uTex; uniform float uHasTex; uniform vec4 uDiffuse;\n" +
            "in vec2 vUv; out vec4 oC;\n" +
            "void main(){ float a = uDiffuse.a * (uHasTex > 0.5 ? texture(uTex, vUv).a : 1.0); if (a < 0.5) discard; oC = vec4(1.0); }\n"
        const val SH_SIZE = 2048
    }
}
