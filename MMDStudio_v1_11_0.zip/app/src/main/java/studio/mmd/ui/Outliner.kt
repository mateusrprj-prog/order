package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.render.ViewPreset

/** Uma linha da hierarquia. [visible] = null: sem olho (não dá para ocultar). */
class Layer(val key: String, val name: String, val icon: ImageVector, val sub: String, val indent: Int, val visible: Boolean?)

/** Hierarquia da cena (modelo, objetos presos/soltos, luz, câmera, áudio). Tocar numa linha abre o painel de propriedades dela. */
@Composable
fun LayersPanel(layers: List<Layer>, selected: String, onSelect: (String) -> Unit, onToggle: (String) -> Unit, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Panel.copy(alpha = .94f)).padding(6.dp)) {
        Text("Layers", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 6.dp, bottom = 4.dp))
        Column(Modifier.verticalScroll(rememberScrollState())) {
            for (l in layers) {
                val sel = l.key == selected
                Row(Modifier.fillMaxWidth().padding(vertical = 1.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (sel) Accent.copy(alpha = .28f) else Color.Transparent)
                    .clickable { onSelect(l.key) }.padding(start = (6 + 12 * l.indent).dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(l.icon, null, tint = if (sel) Color.White else Muted, modifier = Modifier.size(16.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 7.dp)) {
                        Text(l.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(l.sub, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    val v = l.visible
                    if (v != null) Icon(if (v) Icons.Default.Visibility else Icons.Default.VisibilityOff, null,
                        tint = if (v) Color.White else Muted,
                        modifier = Modifier.clickable { onToggle(l.key) }.padding(4.dp).size(18.dp))
                }
            }
        }
    }
}

/** Propriedades da câmera: câmera do VMD (ligar/inverter/remover) e vistas rápidas. */
@Composable
fun CameraPanel(hasVmd: Boolean, on: Boolean, flip: Boolean, onOn: () -> Unit, onFlip: () -> Unit, onRemove: () -> Unit,
                onPreset: (ViewPreset) -> Unit, onFrameAll: () -> Unit, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Text("Câmera", color = Color.White, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("Vistas", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esq." to ViewPreset.LEFT).forEach { (n, p) ->
                OutlinedButton(onClick = { onPreset(p) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(n, fontSize = 11.sp, maxLines = 1) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Dir." to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                OutlinedButton(onClick = { onPreset(p) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(n, fontSize = 11.sp, maxLines = 1) }
            }
        }
        OutlinedButton(onClick = onFrameAll, modifier = Modifier.fillMaxWidth()) { Text("Enquadrar tudo", fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))
        Text("Câmera do VMD", color = Muted, fontSize = 10.sp)
        if (!hasVmd) Text("Nenhuma. Importe um .vmd de câmera (ícone de pasta).", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        else Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(onClick = onOn, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(if (on) "Ligada" else "Desligada", fontSize = 11.sp, maxLines = 1) }
            OutlinedButton(onClick = onFlip, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(if (flip) "Inclin. invertida" else "Inverter inclin.", fontSize = 11.sp, maxLines = 1) }
            OutlinedButton(onClick = onRemove, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text("Remover", fontSize = 11.sp, maxLines = 1) }
        }
    }
}
