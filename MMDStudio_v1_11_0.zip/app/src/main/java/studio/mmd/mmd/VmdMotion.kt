package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/** Keyframes de um osso: 7 floats por key (pos xyz + quat xyzw) e 16 bytes de interpolação Bézier por key. */
class VmdTrack(val frames: IntArray, val v: FloatArray, val ip: ByteArray)
class VmdMorphTrack(val frames: IntArray, val w: FloatArray)

class VmdMotion(
    val modelName: String,
    val bones: Map<String, VmdTrack>,
    val morphs: Map<String, VmdMorphTrack>,
    val maxFrame: Int,
    /** Avisos do importador (seções ignoradas, keys duplicadas...). */
    val warnings: List<String> = emptyList()
)

/** Câmera do VMD: por key, distância, centro (xyz), rotação (xyz, rad), fov (graus) e 24 bytes de interpolação (X,Y,Z,rot,dist,fov). */
class VmdCamera(val frames: IntArray, val dist: FloatArray, val pos: FloatArray, val rot: FloatArray, val fov: FloatArray, val ip: ByteArray) {
    val maxFrame get() = if (frames.isEmpty()) 0 else frames[frames.size - 1]

    private fun bez(k: Int, o: Int, s: Float): Float {
        val x1 = (ip[k * 24 + o].toInt() and 0xFF) / 127f; val x2 = (ip[k * 24 + o + 1].toInt() and 0xFF) / 127f
        val y1 = (ip[k * 24 + o + 2].toInt() and 0xFF) / 127f; val y2 = (ip[k * 24 + o + 3].toInt() and 0xFF) / 127f
        var lo = 0f; var hi = 1f; var t = s
        for (i in 0 until 14) {
            t = (lo + hi) * 0.5f
            val u = 1 - t
            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
            if (x < s) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
    }

    /** out = [dist, cx, cy, cz, rx, ry, rz, fov] no quadro [f]. */
    fun evaluate(f: Float, out: FloatArray) {
        val n = frames.size
        if (n == 0) return
        var k = 0
        while (k + 1 < n && frames[k + 1] <= f) k++
        if (k + 1 >= n || f <= frames[k]) {
            out[0] = dist[k]; for (c in 0..2) { out[1 + c] = pos[k * 3 + c]; out[4 + c] = rot[k * 3 + c] }; out[7] = fov[k]; return
        }
        val k2 = k + 1
        val t = ((f - frames[k]) / (frames[k2] - frames[k]).toFloat()).coerceIn(0f, 1f)
        fun mix(a: Float, b: Float, w: Float) = a + (b - a) * w
        val wx = bez(k2, 0, t); val wy = bez(k2, 4, t); val wz = bez(k2, 8, t)
        val wr = bez(k2, 12, t); val wd = bez(k2, 16, t); val wf = bez(k2, 20, t)
        out[0] = mix(dist[k], dist[k2], wd)
        out[1] = mix(pos[k * 3], pos[k2 * 3], wx); out[2] = mix(pos[k * 3 + 1], pos[k2 * 3 + 1], wy); out[3] = mix(pos[k * 3 + 2], pos[k2 * 3 + 2], wz)
        for (c in 0..2) out[4 + c] = mix(rot[k * 3 + c], rot[k2 * 3 + c], wr)
        out[7] = mix(fov[k], fov[k2], wf)
    }
}

/** Leitor de VMD (versões 1 e 2). Lê keyframes de ossos e morphs; câmera é lida à parte; luz/sombra/IK-switch são ignorados, mas AVISADOS em VmdMotion.warnings. */
object VmdParser {
    private val SJIS: Charset = Charset.forName("Shift_JIS")

    private class BKey(val frame: Int, val v: FloatArray, val ip: ByteArray)

    fun parse(data: ByteArray): VmdMotion {
        if (data.size < 50) throw IllegalArgumentException("Arquivo VMD muito pequeno")
        if (!String(data, 0, 30, Charsets.US_ASCII).startsWith("Vocaloid Motion Data"))
            throw IllegalArgumentException("Não é um arquivo VMD (assinatura inválida)")
        val v2 = String(data, 0, 30, Charsets.US_ASCII).contains("0002")
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        b.position(30)
        val modelName = str(b, if (v2) 20 else 10)
        var maxFrame = 0
        val warn = ArrayList<String>()
        var dupes = 0

        val nb = b.int
        if (nb < 0 || nb.toLong() * 111 > b.remaining()) throw IllegalArgumentException("VMD truncado (ossos)")
        val boneKeys = HashMap<String, MutableList<BKey>>()
        repeat(nb) {
            val name = str(b, 15); val frame = b.int
            val v = FloatArray(7) { b.float }
            var len = Math.sqrt((v[3] * v[3] + v[4] * v[4] + v[5] * v[5] + v[6] * v[6]).toDouble()).toFloat()
            if (len < 1e-6f) { v[3] = 0f; v[4] = 0f; v[5] = 0f; v[6] = 1f; len = 1f }
            for (k in 3..6) v[k] /= len
            val ip = ByteArray(64); b.get(ip)
            if (frame > maxFrame) maxFrame = frame
            boneKeys.getOrPut(name) { ArrayList() }.add(BKey(frame, v, ip.copyOfRange(0, 16)))
        }
        val bones = boneKeys.mapValues { (_, list0) ->
            list0.sortBy { it.frame }
            // frames repetidos: vale o último do arquivo
            val list = ArrayList<BKey>(list0.size)
            for (k in list0) { if (list.isNotEmpty() && list[list.size - 1].frame == k.frame) { list[list.size - 1] = k; dupes++ } else list.add(k) }
            val v = FloatArray(list.size * 7); val ip = ByteArray(list.size * 16)
            list.forEachIndexed { i, k -> k.v.copyInto(v, i * 7); k.ip.copyInto(ip, i * 16) }
            VmdTrack(IntArray(list.size) { list[it].frame }, v, ip)
        }

        val morphs = HashMap<String, VmdMorphTrack>()
        if (b.remaining() >= 4) {
            val nm = b.int
            if (nm < 0 || nm.toLong() * 23 > b.remaining()) throw IllegalArgumentException("VMD truncado (morphs)")
            val tmp = HashMap<String, MutableList<Pair<Int, Float>>>()
            repeat(nm) {
                val name = str(b, 15); val frame = b.int; val w = b.float
                if (frame > maxFrame) maxFrame = frame
                tmp.getOrPut(name) { ArrayList() }.add(frame to w)
            }
            for ((k, l0) in tmp) {
                l0.sortBy { it.first }
                val l = ArrayList<Pair<Int, Float>>(l0.size)
                for (e in l0) { if (l.isNotEmpty() && l[l.size - 1].first == e.first) { l[l.size - 1] = e; dupes++ } else l.add(e) }
                morphs[k] = VmdMorphTrack(IntArray(l.size) { l[it].first }, FloatArray(l.size) { l[it].second })
            }
        }
        if (dupes > 0) warn.add("$dupes keys repetidas no mesmo quadro (ficou a última).")
        // seções seguintes: câmera (lida à parte), luz, sombra, IK
        if (b.remaining() >= 4) {
            val nc = b.int
            if (nc < 0 || nc.toLong() * 61 > b.remaining()) warn.add("Seção de câmera truncada ou inválida (contagem $nc).")
            else {
                b.position(b.position() + nc * 61)
                if (b.remaining() >= 4) {
                    val nl = b.int
                    if (nl < 0 || nl.toLong() * 28 > b.remaining()) warn.add("Seção de iluminação truncada ou inválida.")
                    else {
                        if (nl > 0) warn.add("$nl keys de iluminação ignoradas (ainda não suportadas).")
                        b.position(b.position() + nl * 28)
                        if (b.remaining() >= 4) {
                            val ns = b.int
                            if (ns < 0 || ns.toLong() * 9 > b.remaining()) warn.add("Seção de self-shadow truncada ou inválida.")
                            else {
                                if (ns > 0) warn.add("$ns keys de self-shadow ignoradas (ainda não suportadas).")
                                b.position(b.position() + ns * 9)
                                if (b.remaining() >= 4) {
                                    val ni = b.int
                                    if (ni > 0) warn.add("$ni keys de IK ligado/desligado ignoradas (ainda não suportadas).")
                                }
                            }
                        }
                    }
                }
            }
        }
        return VmdMotion(modelName, bones, morphs, maxFrame, warn)
    }

    /** Lê só a câmera (seção depois de ossos e morphs). Devolve null se o arquivo não tem keys de câmera. */
    fun parseCamera(data: ByteArray): VmdCamera? = try {
        if (data.size < 50 || !String(data, 0, 30, Charsets.US_ASCII).startsWith("Vocaloid Motion Data")) null else {
            val v2 = String(data, 0, 30, Charsets.US_ASCII).contains("0002")
            val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            b.position(30 + if (v2) 20 else 10)
            val nb = b.int; b.position(b.position() + nb * 111)
            val nm = b.int; b.position(b.position() + nm * 23)
            val nc = if (b.remaining() >= 4) b.int else 0
            if (nc <= 0 || nc.toLong() * 61 > b.remaining()) null else {
                class K(val f: Int, val d: Float, val p: FloatArray, val r: FloatArray, val fov: Float, val ip: ByteArray)
                val ks = ArrayList<K>(nc)
                repeat(nc) {
                    val f = b.int; val d = b.float
                    val p = FloatArray(3) { b.float }; val r = FloatArray(3) { b.float }
                    val ip = ByteArray(24); b.get(ip)
                    val fov = b.int.toFloat(); b.get()
                    ks.add(K(f, d, p, r, fov, ip))
                }
                ks.sortBy { it.f }
                val dist = FloatArray(nc) { ks[it].d }; val pos = FloatArray(nc * 3); val rot = FloatArray(nc * 3)
                val ip = ByteArray(nc * 24)
                for (i in 0 until nc) { for (c in 0..2) { pos[i * 3 + c] = ks[i].p[c]; rot[i * 3 + c] = ks[i].r[c] }; ks[i].ip.copyInto(ip, i * 24) }
                VmdCamera(IntArray(nc) { ks[it].f }, dist, pos, rot, FloatArray(nc) { ks[it].fov }, ip)
            }
        }
    } catch (e: Exception) { null }

    private fun str(b: ByteBuffer, n: Int): String {
        val a = ByteArray(n); b.get(a)
        var e = a.indexOf(0); if (e < 0) e = n
        return String(a, 0, e, SJIS)
    }
}
