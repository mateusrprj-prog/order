# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 3 (shaders GLSL ES 3.00). Sem WebView/PWA.

## Status
v1.10.0: Release 2 — escritor PMX (`PmxWriter`): exporta o modelo em PMX 2.0/2.1 com os dados preservados do importador (SDEF, UVs extras, morphs de UV/material/impulso, frames de exibição, física, soft bodies em bytes brutos), com testes de ida e volta byte a byte. Menu de exportação → "Exportar modelo (.pmx)" (converte PMD/.x em PMX).
v1.9.1: fundação do roadmap (Release 1) — importador PMX/VMD com avisos em vez de descarte silencioso, dados do PMX preservados (comentários, UVs extras, SDEF, eixos, frames de exibição, morphs UV/material/impulso), versão no formato do projeto, limites em zips, logger e testes JVM de parser.
v1.9.0: ocultar ossos e animação por texto (IA). v1.8.0: importar projeto .zip, modo MMD (toon, esfera, contorno, sombra), câmera no VMD.
Recursos: PMX/PMD/X/VMD, esqueleto FK + IK + append, skinning na GPU, morphs, timeline com keyframes e curvas Bézier, física própria, Action Constraints, mocap por vídeo, cena com acessórios, áudio, exportação VMD/VPD/FBX/GLB/MP4/PNG.
Veja `MMD-Studio-Contexto.md` (histórico, estado real, auditoria e roadmap em `docs/`).

## Compilar e testar
- Android Studio: abrir a pasta e rodar `app`.
- Testes de parser: `gradle testDebugUnitTest` (JUnit, sem aparelho).
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
