# MMD Studio — Roadmap Master de Evolução para o nível do MMD oficial de PC

**Documento para entregar ao Claude junto com o projeto-fonte `MMDStudio_v1_8_0.zip`.**

## Objetivo principal

Evoluir o **MMD Studio para Android** até se tornar um estúdio de animação 3D mobile com compatibilidade prática e confiável com o ecossistema MMD de PC, preservando e expandindo as ferramentas próprias do aplicativo.

A meta não é apenas criar telas com nomes parecidos com os do MMD. Cada recurso precisa funcionar de verdade, estar conectado ao motor, salvar corretamente no projeto e ser validado com arquivos reais.

O aplicativo deve continuar sendo:
- Nativo para Android, em Kotlin e Jetpack Compose.
- Com viewport 3D acelerado por OpenGL ES.
- Projetado primeiro para toque e telas de celular.
- Independente de WebView/PWA.
- Compatível com o ambiente de build já existente no repositório.
- Um editor completo, não um tutorial, visualizador ou protótipo visual.

**Regra fundamental:** não reescreva o aplicativo do zero e não remova recursos existentes para simplificar a implementação. Primeiro entenda a arquitetura atual, depois evolua os módulos de forma incremental.

---

# PARTE 1 — Diagnóstico real da versão fornecida

A versão de referência é `MMDStudio_v1_8_0.zip`. O README e os fontes dessa versão indicam a seguinte base. Isso é um inventário inicial, não uma garantia de que tudo esteja livre de bugs.

## 1.1 Tecnologias e arquitetura identificadas

- Kotlin e Jetpack Compose.
- Renderização em OpenGL ES; o README descreve a etapa de renderização como OpenGL ES 3.
- Parser e estruturas próprias para PMX, PMD, X e VMD.
- Motor próprio de animação, FK, IK CCD, append/inheritance e skinning por CPU.
- Editor de ossos, poses, morphs e keyframes.
- Sistema próprio de física, constraints e movimento secundário.
- Importação de modelos e projetos ZIP.
- Exportadores GLB e FBX.
- Exportação de mídia e sincronização/mixagem de áudio.
- Captura de movimento por câmera e retargeting.
- Cenas com objetos/acessórios e possibilidade de prendê-los a ossos.
- Câmera orbital, vistas ortográficas e modo MMD com toon, esfera, contorno e sombra.

## 1.2 Recursos já presentes na base — preservar e testar

- Importação PMX, PMD e X.
- Importação de projeto ZIP e busca de texturas.
- Leitura de VMD para animação de ossos e morphs.
- Leitor separado de câmera VMD.
- Esqueleto com FK e IK CCD.
- Skinning de personagens.
- Morphs de vértice, osso e grupo.
- Reprodução ligada à timeline.
- Modo de edição de esqueleto, seleção de ossos por toque.
- Abas de ossos, osso, pose e morphs.
- Auto-key e operações de pose: copiar, colar, espelhar, zerar/resetar.
- Undo/redo, conforme implementação existente.
- Curvas Bézier para animação.
- Câmera orbital e vistas Frente/Trás/Esquerda/Direita/Topo/Base.
- Toon, esfera, contorno e sombras no modo MMD.
- Câmera VMD.
- Física própria com corpos rígidos/juntas e movimento secundário.
- Action Constraints, como limites, olhar para, copiar rotação/posição.
- Reconhecimento automático de configurações de física.
- Objetos/acessórios presos a ossos.
- Captura de movimento, biblioteca e retargeting.
- Áudio, exportação de vídeo, GLB e FBX.
- Projetos salvos em formato próprio.

Não substituir esses sistemas por telas falsas. Melhorar a implementação existente e manter compatibilidade com projetos antigos.

## 1.3 Limitações explicitamente identificadas no código-fonte

### PMX
O comentário do `PmxParser` informa que a leitura vai até os morphs e que frames de exibição, corpos rígidos e juntas seriam tratados depois; o código atual tenta ler corpos rígidos e juntas, mas captura exceções e pode descartar os dados físicos silenciosamente.

Limitações observadas:
- SDEF é lido, mas convertido provisoriamente como BDEF2.
- UVs adicionais são pulados, não armazenados.
- Morphs dos tipos UV/adicionais (3–7), material (8) e impulso (10) são pulados e não preservados como dados editáveis.
- Morphs de grupo e flip são lidos, mas precisam ser validados quanto à avaliação e encadeamento.
- O parser não deve ignorar falhas em corpos rígidos/juntas silenciosamente.
- O modelo atual não representa todos os dados PMX necessários para edição round-trip.
- É necessário validar flags, índices, tamanhos, versões e arquivos truncados/malformados.

### VMD
O comentário do `VmdParser` informa que o leitor principal trata ossos e morphs; câmera é tratada por parser separado. Luz, sombra e IK switch são ignorados.

Limitações observadas:
- A seção de câmera é lida separadamente, não integrada a um modelo de motion completo.
- Keyframes de iluminação não são implementados.
- Keyframes de self-shadow não são implementados.
- IK enable/disable por keyframe não é implementado.
- Importação, edição e exportação precisam preservar seções desconhecidas ou ainda não suportadas, evitando perda silenciosa.
- Validar versões, ordenação de keyframes, nomes Shift-JIS, interpolação e arquivos truncados.

### Exportação e projeto
- O comentário de `MediaExport` diz que a exportação VPD inclui ossos com keyframes e não inclui morphs.
- O exportador FBX contém TODO indicando que movimentos/poses constantes precisam ser tratados nas curvas.
- É necessário verificar o round-trip real de PMX/VMD/VPD/GLB/FBX; não assumir fidelidade só porque o arquivo é gerado.
- Compatibilidade retroativa dos projetos `.zip` precisa ser preservada.

### Interface e fluxo
- O editor já possui timeline, keyframes e curvas, mas precisa de ferramentas de edição em lote e fluxos comparáveis aos do MMD de PC.
- O Scene Studio, o gerenciamento de vários modelos e a edição de câmera/iluminação precisam ser avaliados no código antes de serem considerados completos.
- A física existente é um motor próprio e não deve ser anunciada como equivalente à física MMD até passar por testes de compatibilidade.

---

# PARTE 2 — Requisitos de implementação

## 2.1 Compatibilidade PMX completa

Implementar um modelo de dados que preserve os dados PMX, mesmo quando uma parte ainda não tenha interface de edição.

### Parser e validação
- Suporte validado a PMX 2.0 e 2.1.
- Leitura de todos os campos do cabeçalho e configurações globais.
- Leitura completa de vértices, normais, UVs principais e UVs adicionais.
- BDEF1, BDEF2, BDEF4, SDEF e QDEF.
- Índices de vértices, texturas, materiais, ossos e morphs com validação de limites.
- Materiais e flags completas.
- Todos os tipos de ossos, flags, tail, parent, append/inherit, eixo fixo, eixo local, external parent e IK.
- Frames de exibição/bone display frames.
- Morphs de grupo, vértice, osso, UV, UV1–UV4, material, flip e impulso.
- Corpos rígidos e juntas PMX 2.0/2.1.
- Soft bodies PMX 2.1 e seus parâmetros, âncoras e pins.
- Preservação de nomes japonês/inglês, comentários e strings.
- Tratamento de Shift-JIS quando aplicável e UTF-16LE/UTF-8 conforme cabeçalho.
- Mensagens de erro úteis: seção, offset e causa.
- Nunca descartar silenciosamente uma seção inválida; apresentar aviso e oferecer importação parcial consciente, quando segura.

### Deformação e skinning
- Implementar SDEF real, usando os parâmetros C, R0 e R1.
- Implementar QDEF se suportado pelo formato, com fallback explícito e documentado caso o caminho de renderização não o suporte.
- Normalizar pesos com segurança.
- Corrigir transformações, hierarquia, escala, coordenadas e precisão.
- Evitar deformações em ombros, cotovelos, joelhos, quadris, mãos e rosto.
- Suporte a múltiplos UVs nos materiais/shaders.
- Otimizar skinning para GPU quando viável, mantendo fallback confiável.
- Validar normais após deformação e morphs.

### Morphs
- Avaliar corretamente morphs encadeados e dependências.
- Morphs de grupo e flip com regras corretas e prevenção de ciclos.
- Morphs de vértice.
- Morphs de osso com translação e rotação quaternion.
- Morphs UV e UV adicionais.
- Morphs de material, incluindo multiplicação/aditividade de cores, difuso, especular, ambiente, borda, textura, sphere texture e toon texture.
- Morphs de impulso aplicados à física.
- Slider com valor numérico, nome, painel e agrupamento do PMX.
- Keyframes de morph na timeline.
- Mistura de múltiplos morphs no mesmo frame.
- Presets de expressões sem substituir os morphs originais do modelo.

### Editor PMX
Criar um modo de edição do modelo com:
- Lista hierárquica de ossos e busca por nome.
- Editar posição/parent/flags e propriedades suportadas.
- Editar pesos de vértices e visualizar influência.
- Editar materiais, texturas, sphere/toon e flags.
- Editar morphs e seus elementos.
- Editar corpos rígidos, juntas, grupos e máscaras de colisão.
- Editar frames de exibição.
- Ferramentas de validação do modelo.
- Salvar/exportar PMX sem perder campos não modificados.
- Histórico undo/redo específico para edição de modelo.
- Duplicar e renomear itens com segurança.

**Importante:** não criar um editor PMX superficial. Primeiro completar o modelo de dados e o round-trip; depois construir as ferramentas de interface.

## 2.2 Compatibilidade VMD completa

Criar uma estrutura unificada de motion, com seções separadas e preservação de dados.

Implementar:
- Keyframes de ossos.
- Keyframes de morphs.
- Keyframes de câmera.
- Keyframes de iluminação.
- Keyframes de self-shadow.
- Keyframes de IK enable/disable.
- Interpolação Bézier conforme especificação do VMD.
- Interpolação individual de canais de posição/rotação/câmera.
- Ordenação estável de keyframes e tratamento de duplicados.
- Nomes e codificação compatíveis.
- Importação de VMD de modelo e VMD de câmera.
- Exportação VMD sem descartar seções suportadas.
- Preservar dados não editados e informar o que não pôde ser preservado.
- Biblioteca local de motions e metadados.
- Pré-visualização antes de aplicar motion.
- Retargeting de motions para modelos com nomes/hierarquias diferentes.
- Mapeamento editável de ossos japonês/inglês e nomes alternativos.
- Ajuste de escala, orientação, posição raiz e pose de referência.
- Aplicação de motion em múltiplos personagens.
- Mistura/blending de motions, transições e camadas de animação.
- Retiming: acelerar, desacelerar, inverter e deslocar trechos.
- Loop de motion e repetição com transição.
- Copiar/colar motion entre personagens e projetos.

## 2.3 Motor de animação e rig

### Esqueleto e IK
- FK e IK combinados por osso.
- IK PMX com número de iterações, limite angular e limites por link.
- IK ON/OFF animável por VMD.
- Alvos de IK selecionáveis no viewport.
- Controles de mão, pé, joelho, cotovelo e raiz.
- Pole targets para controlar a direção de cotovelos/joelhos.
- Limites de rotação e prevenção de inversões.
- Prioridade/camada de ossos e append/inherit.
- Eixos locais, eixo fixo e transformações externas.
- Visualização de hierarquia e influência.
- Modo pose e modo animação claramente separados.
- Ferramentas de mirror pose/motion com mapeamento de lados.
- Pose library com thumbnails, categorias e favoritos.
- Retargeting com calibração de proporções e pose base.

### Timeline e keyframes
- Timeline profissional com zoom horizontal/vertical.
- Trilhas independentes por personagem, osso, morph, câmera, luz, sombra, IK e física.
- Dope Sheet com seleção de keyframes.
- Seleção múltipla por toque/retângulo.
- Mover, duplicar, copiar, colar, excluir e deslocar intervalos.
- Snap configurável a frames, marcadores e playhead.
- Seleção por faixa e por canal.
- Auto-key configurável e indicação clara quando ativo.
- Keyframe manual e inserir/remover key.
- Interpolação por canal e por trecho.
- Editor Bézier visual com handles editáveis por toque.
- Presets de easing.
- Curvas de posição, rotação, morph, câmera e luz.
- Ripple edit e deslocamento de faixa.
- Marcadores, regiões, loop de reprodução e range de exportação.
- FPS configurável e indicação de frame/tempo.
- Undo/redo robusto para todas as operações.
- Navegação frame a frame e reprodução sem drift.
- Otimização para cenas longas e muitos keyframes.

### Editor de câmera
- Câmera independente de cada personagem.
- Câmera VMD com distância, centro, rotação, FOV e interpolação.
- Keyframes e curvas dedicadas.
- Dolly, pan, orbit, zoom, roll e foco.
- Alvo de câmera (look-at).
- Profundidade de campo com foco e abertura.
- Presets de enquadramento e composição.
- Múltiplas câmeras nomeadas e troca de câmera.
- Preview de câmera e viewport livre.
- Exportar/importar câmera VMD.
- Controles mobile de câmera sem conflitar com seleção/manipulação do personagem.

### Editor de iluminação e sombras
- Luz direcional, pontual e spot, conforme capacidade do renderizador.
- Cor, intensidade, direção, alcance e parâmetros.
- Keyframes de luz e interpolação.
- Luzes múltiplas.
- Ambiente e iluminação de preenchimento.
- Keyframes de iluminação VMD.
- Self-shadow VMD.
- Configuração de qualidade/resolução de sombra.
- Preview de sombras e diagnóstico de limites do dispositivo.

## 2.4 Física MMD

A física deve ser um subsistema real, não apenas um efeito de movimento secundário.

Implementar progressivamente:
- Corpos rígidos PMX: esfera, caixa e cápsula.
- Modos follow-bone, physics e physics-with-bone.
- Massa, amortecimento linear/angular, restituição e atrito.
- Grupos de colisão e máscaras.
- Juntas PMX com limites lineares/angulares e molas.
- Escala e conversão de unidades consistentes.
- Gravidade e parâmetros equivalentes ao MMD.
- Reset/restart da simulação.
- Simulação em passo fixo, independente do FPS de renderização.
- Reprodução determinística por frame, inclusive ao arrastar o playhead.
- Cache/bake de física para timeline e exportação.
- Recalcular a partir de um frame anterior quando necessário.
- Visualização de colliders, juntas, eixos e contatos.
- Painel para editar cada corpo rígido e junta.
- Ativar/desativar física por personagem e por corpo.
- Física de cabelo, saia, gravata, mangas e acessórios.
- Soft bodies PMX 2.1, quando viável.
- Diagnóstico de instabilidade e colisões.
- Perfis de qualidade para aparelhos diferentes.

Não afirmar compatibilidade equivalente ao MMD sem testes comparativos de cenas e modelos reais. Se houver diferença física inevitável, documentar o comportamento.

## 2.5 Renderizador e materiais MMD

Aprimorar o renderizador para fidelidade visual:
- Materiais PMX completos.
- Texturas diffuse, sphere e toon.
- Sphere multiply/add/subtexture conforme modo.
- Toon texture compartilhada e individual.
- Borda/outline por material com cor e espessura.
- Double-sided e flags de desenho.
- Transparência com ordenação correta.
- Self-shadow e sombras de cenário.
- Controle de culling e z-fighting.
- Normais, especular, ambient e diffuse.
- SDEF/QDEF e morphs no pipeline de renderização.
- Anti-aliasing e controle de resolução.
- Renderização em tempo real e modo de qualidade.
- Gestão de memória GPU e texturas grandes.
- Evitar travamentos por perda de contexto OpenGL.
- Shader diagnostics com mensagens úteis.
- Presets de renderização para dispositivos Android diferentes.

### MME e efeitos
Criar um sistema de efeitos extensível, inspirado no ecossistema MME, sem depender de plugins Windows:
- Bloom.
- Depth of field.
- Motion blur.
- Color grading.
- Tonemapping.
- SSAO, se o desempenho permitir.
- Fog/névoa.
- Rim light.
- Outline customizado.
- Partículas.
- Lens flare com controle.
- Vignette.
- Glitch e efeitos estilizados.
- Shaders customizados com formato seguro e documentado.
- Cadeia de pós-processamento com ordem configurável.
- Ativar/desativar por cena e por personagem.
- Presets e salvar configurações no projeto.
- Medidor de custo/performance por efeito.

Não prometer compatibilidade binária com plugins MME `.fx` do Windows sem desenvolver uma camada real de compatibilidade. O objetivo inicial é um sistema de efeitos nativo equivalente em recursos.

## 2.6 Scene/Stage Studio

Criar gerenciamento completo de cenas:
- Vários personagens simultâneos.
- Múltiplos objetos, acessórios e props.
- Stage/ambientes e cenários.
- Hierarquia/outliner com grupos e pastas.
- Renomear, duplicar, ocultar, bloquear e excluir.
- Transformações locais e globais.
- Parent/child e attachment a ossos.
- Instanciar objetos sem duplicar recursos desnecessariamente.
- Gerenciar materiais e texturas.
- Organizar personagens por nome e camadas.
- Câmeras múltiplas.
- Luzes múltiplas.
- Plano de chão, grade, eixos e guias.
- Gizmos de mover, girar e escalar.
- Snap e alinhamento.
- Seleção por toque e seleção por lista.
- Isolar objeto/personagem.
- Salvar e restaurar estado da cena.
- Importar modelos e acessórios sem perder referências.
- Pré-visualização de cena e enquadramento.
- Gerenciamento de assets internos.

## 2.7 Áudio e performance

- Trilhas de áudio na timeline.
- Waveform.
- Múltiplos clipes e trilhas.
- Deslocamento, corte, fade in/out e volume.
- Sincronização precisa com frames.
- Scrubbing com áudio opcional.
- Lip-sync básico por amplitude.
- Lip-sync por fonemas/visemas como recurso avançado.
- Animação de morphs faciais sincronizada.
- Múltiplos personagens com movimentos e expressões independentes.
- Biblioteca de performances e motions.
- Marcação de beats e marcadores de música.

## 2.8 Captura de movimento e retargeting

Preservar o sistema de mocap já existente e evoluí-lo:
- Calibração guiada.
- Mapeamento de ossos editável.
- Retargeting para diferentes proporções.
- Suavização e redução de jitter.
- Filtros de rotação e posição.
- Ajuste de root motion.
- Captura em tempo real e a partir de vídeo, conforme suporte real.
- Gravação direta para keyframes.
- Escolha dos ossos que serão gravados.
- Pré-visualização antes de aplicar.
- Mistura entre mocap e animação manual.
- Correção de pés e mãos.
- Limpeza de curvas e remoção de ruído.
- Biblioteca de capturas.

## 2.9 Exportação e intercâmbio

### Formatos MMD
- Exportação VMD de ossos, morphs, câmera, luz, sombra e IK switch, conforme suporte.
- Exportação VPD com ossos e morphs quando o formato/implementação permitir; informar limitações.
- Importação/exportação PMX com round-trip.
- Preservar seções PMX não editadas.
- Relatório de compatibilidade antes de exportar.
- Avisar se dados serão perdidos.

### Formatos gerais
- GLB/glTF com malha, materiais, texturas, esqueleto, animações e morph targets suportados.
- FBX com malha, rig, skinning, materiais e animações.
- Validar exportação em visualizadores externos.
- Corrigir poses constantes, animações e conversão de eixos.
- Exportar imagens e sequências.
- Vídeo com resolução, FPS, codec e qualidade configuráveis.
- Exportar áudio mixado.
- Render em lote e fila de exportação.
- Retomar/cancelar exportação com segurança.
- Indicador de progresso e estimativa quando possível.
- Exportar apenas intervalo selecionado.
- Render offline quando o modo em tempo real não oferecer qualidade suficiente.

## 2.10 Projeto, assets e produtividade
- Formato de projeto versionado.
- Migração automática de projetos antigos.
- Autosave e recuperação após encerramento inesperado.
- Backup e versões.
- Undo/redo global consistente.
- Biblioteca de modelos, motions, poses, materiais, efeitos e stages.
- Favoritos, categorias, busca e thumbnails.
- Gerenciador de dependências/arquivos usados.
- Recolher assets para um pacote portátil.
- Importação de ZIP segura contra path traversal e arquivos excessivos.
- Verificação de texturas ausentes.
- Relatório de arquivos incompatíveis.
- Templates de projeto.
- Duplicar cena/projeto.
- Compartilhar projeto com assets incluídos.

---

# PARTE 3 — Interface mobile profissional

A interface deve ter densidade funcional semelhante à de um software desktop, mas reorganizada para toque. Não simplesmente comprimir a interface de PC.

## Layout principal sugerido
- Viewport 3D central e redimensionável.
- Barra superior: projeto, salvar, undo/redo, playback e exportar.
- Ferramentas contextuais: selecionar, mover, girar, escalar, IK, câmera e iluminação.
- Painel inferior expansível: timeline/dope sheet/curvas.
- Painel lateral ou gaveta: Outliner, propriedades, bones, morphs e materiais.
- Abas ou modos de trabalho: Scene, Animate, Camera, Physics, Model/PMX, Render e Assets.
- Controles adaptáveis a retrato e paisagem.
- Painéis recolhíveis e atalhos para tarefas frequentes.
- Alvos de toque confortáveis e gestos consistentes.
- Não esconder ferramentas importantes em menus profundos.
- Feedback visual claro para seleção, auto-key, IK, física e estado de gravação.
- Interface funcional em telas pequenas e grandes.

## Interações
- Um dedo: selecionar ou manipular conforme ferramenta ativa.
- Dois dedos: orbitar/pan/zoom conforme modo, sem conflito com timeline.
- Gizmos 3D com alças grandes o suficiente para toque.
- Long press para menus contextuais.
- Arrastar keyframes com snap.
- Gestos configuráveis.
- Botão de desfazer sempre acessível.
- Alternar viewport, câmera e painéis sem perder contexto.

---

# PARTE 4 — Qualidade, desempenho e confiabilidade

## Desempenho Android
- Não bloquear a UI durante importação, parsing, skinning, física ou exportação.
- Usar coroutines/dispatchers adequados e cancelamento.
- Cache de malhas, texturas, shaders e animações.
- Evitar alocações por frame.
- Otimizar skinning e avaliação de morphs.
- Instancing quando possível.
- LOD e limites de qualidade configuráveis.
- Carregamento progressivo de assets grandes.
- Tratar perda/restauração do contexto OpenGL.
- Respeitar limites de memória e GPU.
- Perfil de desempenho com FPS, tempo de CPU/GPU e memória.
- Testar cenas com vários personagens, materiais e texturas pesadas.
- Não sacrificar precisão de animação silenciosamente para ganhar FPS.

## Estabilidade
- Validar entradas e índices.
- Nunca engolir exceções importantes.
- Logs por subsistema e exportação de relatório de diagnóstico.
- Mensagens de erro acionáveis.
- Recuperação de projeto.
- Evitar corrupção de projeto durante autosave.
- Testes de importação com arquivos incompletos e inválidos.
- Testes de regressão para cada atualização.

## Testes obrigatórios
Criar testes automatizados para:
- PMX 2.0 e 2.1.
- PMD e X.
- VMD de ossos/morphs/câmera/luz/sombra/IK.
- Interpolação Bézier.
- FK, IK, append e limites.
- Todos os tipos de morph.
- SDEF/QDEF.
- Física e bake determinístico.
- Importação/exportação round-trip.
- GLB/FBX em ferramentas externas.
- Projetos antigos.
- Undo/redo.
- Arquivos corrompidos e grandes.
- Regressões visuais e de performance.

Criar uma pasta de fixtures de teste com arquivos redistribuíveis/licenciados corretamente. Não incluir modelos ou motions protegidos sem autorização.

---

# PARTE 5 — Plano de execução por atualizações

Não tente implementar tudo em uma única alteração gigantesca. Divida em releases pequenas, compiláveis e testáveis. A ordem abaixo é uma proposta; ajuste depois da auditoria do código.

## Release 1 — Auditoria e fundação
1. Mapear arquitetura, dependências e fluxos.
2. Criar inventário de funcionalidades por classe.
3. Identificar bugs e dados descartados.
4. Criar testes de parser e fixtures.
5. Corrigir tratamento de erros e logs.
6. Definir interfaces de dados versionadas.
7. Garantir build debug reproduzível.

**Critério de conclusão:** relatório de auditoria, testes iniciais e build funcionando.

## Release 2 — PMX completo: estrutura e preservação
1. Completar parser PMX 2.0/2.1.
2. Preservar UVs adicionais e todos os dados de morph.
3. Implementar frames de exibição.
4. Completar corpos rígidos/juntas/soft bodies.
5. Remover descarte silencioso.
6. Criar relatório de compatibilidade.

**Critério:** importar e reexportar modelos sem perda dos dados suportados; diferenças documentadas.

## Release 3 — Deformação e morphs
1. SDEF.
2. QDEF ou fallback explícito.
3. UV morphs.
4. Material morphs.
5. Flip e group morphs robustos.
6. Impulse morphs ligados à física.
7. Testes visuais de deformação.

## Release 4 — VMD completo
1. Estrutura unificada de motion.
2. Luz.
3. Self-shadow.
4. IK switch.
5. Câmera integrada.
6. Preservação de dados e exportação.
7. Testes de interpolação e round-trip.

## Release 5 — Motion Editor profissional
1. Dope Sheet.
2. Seleção múltipla.
3. Copiar/colar/mover intervalos.
4. Curvas Bézier avançadas.
5. Camadas e blending.
6. Retiming, loop e transições.
7. Biblioteca VMD e poses.

## Release 6 — Física MMD
1. Corrigir parsing e mapeamento dos parâmetros.
2. Corpos rígidos e colisões.
3. Juntas e limites.
4. Passo fixo e determinismo.
5. Bake/cache.
6. Debug visual.
7. Soft bodies, se viável.

## Release 7 — Render MMD avançado
1. Materiais completos.
2. Toon/sphere/toon texture.
3. Outline.
4. Transparência.
5. Self-shadow.
6. Luzes e sombras animadas.
7. Presets de qualidade.

## Release 8 — Scene/Stage Studio
1. Multi-personagem.
2. Outliner avançado.
3. Acessórios e parenting.
4. Stages e props.
5. Múltiplas câmeras/luzes.
6. Organização e templates.

## Release 9 — PMX Editor
1. Editor de materiais.
2. Editor de ossos.
3. Pesos.
4. Morphs.
5. Física.
6. Frames de exibição.
7. Exportação PMX preservando dados.

## Release 10 — Efeitos e renderização
1. Pipeline de pós-processamento.
2. Efeitos nativos inspirados no MME.
3. Presets e cadeia de efeitos.
4. Render offline e fila de exportação.

## Release 11 — Áudio e performance
1. Waveform e trilhas.
2. Sincronização.
3. Lip-sync.
4. Múltiplos personagens.
5. Biblioteca de performances.

## Release 12 — Mocap e retargeting avançados
1. Calibração.
2. Retargeting de proporções.
3. Limpeza de curvas.
4. Correção de pés/mãos.
5. Mistura com animação manual.

## Release 13 — Intercâmbio e acabamento
1. Round-trip VMD/VPD/PMX.
2. GLB/FBX robustos.
3. Migração de projetos.
4. Autosave/backup.
5. Performance e testes em aparelhos reais.
6. Polimento final da interface.

---

# PARTE 6 — Instruções obrigatórias para o Claude

Você deve trabalhar como engenheiro principal do projeto, não como gerador de protótipos.

## Antes de alterar
1. Leia o repositório inteiro e identifique a arquitetura real.
2. Confira se o código atual mudou em relação ao ZIP de referência.
3. Não confie apenas no README ou em nomes de classes; leia as implementações.
4. Faça uma tabela: recurso, arquivo/classe, comportamento real, lacunas, testes existentes.
5. Identifique dependências e restrições do Android.
6. Apresente um plano curto para a próxima release e comece a implementar a primeira etapa acordada.

## Durante a implementação
- Não reescrever tudo do zero.
- Não remover funcionalidades que já funcionam.
- Não criar botões sem ação real.
- Não marcar recurso como concluído só porque existe uma classe.
- Não simular física, IK, render ou exportação com valores falsos.
- Não deixar TODOs críticos escondidos.
- Não engolir exceções nem descartar dados silenciosamente.
- Não mudar o formato do projeto sem migração retrocompatível.
- Não introduzir dependências enormes sem justificar custo e compatibilidade.
- Não usar WebView/PWA.
- Não reduzir a qualidade do viewport para mascarar bugs.
- Manter o app utilizável em Android e otimizar para o hardware mobile.
- Manter a interface em português quando essa for a linguagem atual do app.
- Respeitar licenças de bibliotecas, modelos e assets.

## Ao concluir cada atualização
1. Compilar o projeto.
2. Executar testes unitários e de instrumentação disponíveis.
3. Corrigir todos os erros introduzidos.
4. Informar arquivos modificados.
5. Informar recursos concluídos e limitações restantes.
6. Mostrar logs de build/testes relevantes.
7. Gerar o APK debug por meio do workflow já configurado no GitHub, quando o ambiente permitir.
8. Não afirmar que o APK está pronto se o workflow falhou.
9. Entregar mudanças em etapas pequenas, sem sobrescrever trabalho não relacionado.
10. Atualizar este roadmap com o estado real: concluído, parcial, pendente ou bloqueado.

## Definição de pronto
Uma funcionalidade só pode ser marcada como concluída quando:
- Está implementada no motor e na interface necessária.
- Persiste no projeto.
- Funciona ao reabrir o projeto.
- Tem testes ou cenário de validação reproduzível.
- Não quebra recursos existentes.
- Trata erros e formatos incompatíveis claramente.
- Foi validada em um aparelho Android real ou em ambiente equivalente.

## Primeira tarefa solicitada ao Claude

Comece pela **auditoria técnica completa da versão atual do repositório** usando este documento como especificação.

Entregue:
1. Matriz de funcionalidades: implementado, parcial, ausente, não verificável.
2. Lista de bugs e perdas de dados confirmadas no código.
3. Arquivos e módulos que serão alterados.
4. Plano da próxima atualização com escopo fechado.
5. Testes que serão adicionados.
6. Riscos técnicos e decisões de arquitetura.

Depois da auditoria, implemente a primeira atualização de maior impacto sem tentar fazer todas as etapas de uma vez. Priorize compatibilidade PMX/VMD, preservação de dados e testes, antes de adicionar novas telas.

**Meta final:** um estúdio Android de animação 3D com compatibilidade robusta com o MMD de PC, fluxo de trabalho mobile profissional e recursos próprios que ultrapassem o MMD tradicional em áreas como mocap, retargeting, exportação moderna e usabilidade por toque.


## Nota v1.30.1 — P0 URGENTE: Rotação/transformação da personagem inteira

**Objetivo:** girar a personagem/modelo para a direção desejada sem orbitar a câmera e sem modificar a pose dos ossos. É uma transformação do objeto raiz, separada da navegação livre da viewport (v1.30.0) e da câmera cinematográfica/VMD.

**Implementado no código-fonte:**
- `scene/RootTransform.kt`: estado base e trilha de keyframes por personagem, amostragem/interpolação, codec JSON versionado e persistência em `root_transforms.json`.
- `ui/TransformPanel.kt`: painel Transformar; alvo principal ou extra; controle circular (horizontal = Y, vertical = X), campos X°/Y°/Z°, posição, escala, comando Zerar rotação e keyframe no quadro atual.
- `render/SceneGLView.kt`: matriz `T * Rz * Ry * Rx * S` aplicada ao principal e aos extras no desenho, seleção/picking, MVP dos ossos e props presos ao personagem principal; API `setRootTransform`.
- `ui/SceneScreen.kt`: sincronização com timeline, persistência por projeto e aplicação da transformação nas capturas/exportações.
- `RootTransformTest`: round-trip do codec, interpolação contínua (inclui rotações >360°) e edição de trilha.

**Critérios de aceite antes de declarar validado:**
1. Selecionar a personagem principal e girá-la nos três eixos; repetir com cada extra.
2. Confirmar que câmera orbital e câmera VMD não mudam quando a rotação do objeto é editada.
3. Confirmar que pose, FK/IK, morphs e keys dos ossos permanecem intactos.
4. Criar keyframes em quadros distintos, reproduzir timeline e confirmar interpolação/giros completos.
5. Salvar, fechar e reabrir o projeto; confirmar persistência do principal e extras.
6. Exportar PNG/sequência/MP4 em quadros diferentes e confirmar que a orientação da personagem acompanha o quadro.
7. Confirmar que props presos aos ossos continuam acompanhando a personagem transformada.
8. Validar em Android real: arrasto no controle circular, campos numéricos e layout em tela pequena.

**Limites conhecidos nesta implementação:** controle circular ajusta X/Y; Z é numérico. Ainda não há rotação relativa à câmera, gizmo de anel diretamente no viewport ou Undo/Redo específico para transformação. O código não foi compilado nem testado no aparelho nesta entrega; a versão Android só deve ser marcada como validada depois do GitHub Actions e dos roteiros acima.

**Prioridade atual:** P0, implementar/build/testar esta transformação antes de avançar novas frentes de animação/câmera. A navegação de viewport da v1.30.0 continua sendo um sistema independente e não substitui esta função.


**Adendo de compatibilidade — v1.30.1:** duplicar um personagem extra deve copiar também `RootTransformEntry` (base + keys) para o novo ID; remover o extra deve remover sua entrada. A transformação raiz é persistente no projeto e aplicada nas capturas MP4/PNG/sequência; ela ainda não é baked para arquivos VMD/GLB/FBX. O teste `RootTransformTest` inclui duplicação independente de tracks e ângulos contínuos.
