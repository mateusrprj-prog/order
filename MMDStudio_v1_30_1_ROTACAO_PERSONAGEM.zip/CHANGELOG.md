# CHANGELOG
Estados: implementado / parcial / planejado / validado (escala 0–5 no roadmap, seção 13.1). Só 'validado' com build + teste no aparelho.

## 1.30.1 — P0 URGENTE: Transformação/rotação da personagem inteira. IMPLEMENTADA NO CÓDIGO-FONTE; BUILD ANDROID NÃO EXECUTADO
- Novo `scene/RootTransform.kt`: transformação raiz por alvo (personagem principal `model` ou extra `char:<id>`), com posição X/Y/Z, rotação X/Y/Z e escala; dados persistidos em `root_transforms.json` por projeto.
- Novo painel **Transformar** no SceneScreen: seletor de personagem, controle circular de rotação, campos numéricos de graus X/Y/Z, posição, escala, zerar rotação e criação/remoção de keyframes no quadro atual.
- O renderer agora aplica matriz de raiz `T * Rz * Ry * Rx * S` antes da projeção, tanto no principal quanto nos extras. Skinning/animação dos ossos continua separado; a câmera de viewport e a câmera VMD não são alteradas.
- A transformação é amostrada pela timeline e aplicada antes das capturas/exportações PNG, sequência e MP4; transformações dos extras sincronizam os valores legados de posição/giro/escala no `cast.json` para compatibilidade.
- Ângulos permanecem contínuos (ex.: 350° → 710°), permitindo giros completos animados; não são truncados para ±180°.
- Teste JVM adicionado/ajustado: `RootTransformTest` (codec round-trip, interpolação contínua, edição de keyframe). **Não executado neste ambiente.**
- **Status honesto:** código-fonte e documentação atualizados; não há Gradle wrapper, Gradle instalado nem Android SDK neste ambiente. Portanto, não foi possível compilar, executar testes JUnit Android/JVM completos nem validar o toque/render no aparelho. Verificar no GitHub Actions antes de instalar.
- Limites conhecidos: o controle circular manipula X/Y; Z é ajustado numericamente. Duplicar extra copia base e keyframes da transformação; remover extra limpa sua trilha. Não existe ainda rotação relativa à câmera, gizmo de anel 3D no viewport, Undo/Redo próprio, nem bake da transformação raiz para exportação VMD/GLB/FBX.

## 1.30.0 — P0 URGENTE: Navegação Livre da Viewport (Free Orbit Camera). ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO
- **Câmera de viewport extraída** para `render/OrbitCamera.kt` (matemática pura, sem Android): orbit, pan em espaço de câmera, zoom com limites (0,3–400), foco, enquadrar esfera/caixa, `presetLabel`. Não toca em modelo, osso, keyframe, IK nem Undo.
- **Orbit livre**: 1 dedo gira em qualquer ângulo (yaw sem limite, pitch ±89° sem inversão). Nas ferramentas Girar/Mover o dedo só edita o osso se o toque COMEÇAR a ≤56 dp do osso selecionado; fora disso orbita (antes ficava preso editando o osso).
- **Pan corrigido**: 2 dedos movem o foco no plano da câmera (antes ignorava a elevação) e a velocidade acompanha a distância/FOV.
- **Zoom por pinça** via `OrbitCamera.zoom` (limites seguros, ignora NaN/≤0).
- **Foco**: menu do viewport ganhou "Focar personagem ativo" e "Focar item selecionado"; "Enquadrar tudo" agora enquadra a caixa real da cena (extras e acessórios) em vez de só resetar. Mantém yaw/pitch e passa a orbitar o novo ponto.
- **Gizmo de orientação** (`ui/OrientationGizmo.kt`, canto superior direito): eixos ±X/±Y/±Z projetados pela câmera; tocar num eixo vai para Direita/Esquerda/Topo/Base/Frente/Trás e continua orbitável. Presets do menu/Outliner mantidos (viram atalhos).
- Testes JVM novos: `ViewportNavigationTest` (20 testes: base ortonormal, pitch/yaw, distância constante na órbita, pan sem andar na visada, zoom limitado, foco, enquadrar caixa com pivô distante, presets, gizmo). **Não executados aqui (sem Gradle/kotlinc no ambiente).**
- Pendente (P2): sensibilidade configurável, inércia, persistência da vista no projeto, ponto de órbita escolhido por toque.
## 1.29.13 — 8.3d-B3: renderer no personagem ativo (esqueleto desenhado, seleção e arrasto de ossos no extra; escrita, NÃO compilada). Fecha a 8.3d-B
## 1.29.12 — 8.3d-B2: personagem ativo editável pela UI (botão "Editar este personagem" no Elenco; Esqueleto/Keys/Dope Sheet/Desfazer/Key apontam para o ativo; salva em cast/<id>.vmd; escrita, NÃO compilada)
## 1.29.11 — 8.3d-B1: base lógica do personagem ativo (ActiveCharacter + EditSessions; 5 testes JVM OK; sem mudança de UI)
## 1.29.10 — 8.3d-C: exportar todos os personagens em .zip (CastExport; 3 testes JVM OK; UI NÃO compilada)
## 1.29.9 — 8.3d-A: copiar/colar poses entre personagens (PoseTransfer; 6 testes JVM OK; UI NÃO compilada)
## 1.29.8 — 8.4b final: Outliner lê a hierarquia do Scene Graph (SceneHierarchy; 7 testes JVM OK; UI NÃO compilada)
## 1.29.7 — Seleção por toque na viewport (8.4b; escrita, NÃO compilada)
## 1.29.6 — Cartoon: sinais de eixo corrigidos + IK das pernas desligado no trecho (30 testes JVM OK; UI NÃO compilada)
## 1.29.5 — Cartoon: editor acima da lista, barra de prévia, nomes sem corte, painel 380 dp; GLB: lista de animações volta ao reabrir (escrita, NÃO compilada)
## 1.29.4 — correção de build: `import java.util.Properties` no build.gradle.kts (erro 'Unresolved reference: util/load' no CI, vindo da v1.28.2)
## 1.29.3 — Outliner: seleção múltipla + agrupar (8.4b; escrita, NÃO compilada)
## 1.29.2 — Cartoon em personagens extras (escrita; UI NÃO compilada; lógica pura testada em JVM)
- Alvo "Aplicar em" no painel Cartoon; prévia e aplicar no extra; `CartoonMerge` (mescla + grava VMD); "Desfazer no extra" (até 20 passos). 21/21 testes JVM (CartoonMerge 7 + Cartoon 14) executados.
## 1.29.1 — Undo/Redo do Outliner (8.4b-1; escrita, NÃO compilada)
- `History<T>` + botões desfazer/refazer no painel Layers; snapshot de organização + nomes de props/extras. Excluir/duplicar fora do histórico.
## 1.29.0 — Outliner funcional, fatia 8.4a (escrita, NÃO compilada, NÃO testada no aparelho)
- Renomear, mover, bloquear, visível no render, grupos, duplicar, excluir; persistência em `outliner.json`. Nível 3 (interface) no papel; 4 (persistência) só após teste. Sem Undo/Redo; Scene Graph ainda não ligado.
## 1.28.2 — segurança/documentação (escrita, NÃO compilada)
- Senhas de assinatura removidas do Gradle; `.jks` fora do zip; `.gitignore`; este changelog.
## 1.28.1 — correção de crash na Cartoon (texto com '100%' em format). Não validada.
## 1.28.0 — Cartoon Motion Library P1–P3 (nível 2–3; sem build confirmado).
## 1.27.0 — Elenco (8.3c) (nível 2; sem build confirmado).
## 1.26.0 / 1.25.0 — RigConfig por personagem / renderer por instância (sem build confirmado).
## 1.24.2 — correção visual do painel Luz (visto em print do aparelho).
## 1.24.1 — correção de build (`mainChar.shBone`); primeiro build que abriu no aparelho.
## 1.24.0 — troca de clip GLB desfazível.
## 1.14.0–1.23.0 — D/G (física/importação), Releases 5, 7, 8.1–8.2, 9.1–9.4. Compilaram e abriram (v1.24.1); funções sem teste explícito.
## Até 1.12.x — ver seção 6 do md de contexto (várias confirmadas no aparelho).
