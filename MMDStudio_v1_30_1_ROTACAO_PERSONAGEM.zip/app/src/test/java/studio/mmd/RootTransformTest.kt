package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.scene.*

class RootTransformTest {
    @Test fun rootTransformCodecRoundTripPreservesBaseAndKeys() {
        val state = RootTransformState().ensure("model", RootTransform(1f, 2f, 3f, 10f, 20f, 30f, 1.2f))
            .addKey("model", 12)
            .edit("model", 12, RootTransform(4f, 5f, 6f, 45f, 90f, -20f, 2f))
        val decoded = RootTransformCodec.decode(RootTransformCodec.encode(state))
        assertEquals(state, decoded)
    }

    @Test fun keyframesInterpolateContinuousRotationAndPosition() {
        var state = RootTransformState().ensure("model", RootTransform())
        state = state.addKey("model", 0).edit("model", 0, RootTransform(0f, 0f, 0f, 0f, 350f, 0f, 1f))
        state = state.addKey("model", 10).edit("model", 10, RootTransform(10f, 0f, 0f, 0f, 710f, 0f, 2f))
        val middle = state.sample("model", 5)
        assertEquals(5f, middle.x, 0.001f)
        assertEquals(530f, middle.ry, 0.01f)
        assertEquals(1.5f, middle.scale, 0.001f)
    }

    @Test fun duplicateTargetCopiesBaseAndAllKeysIndependently() {
        var state = RootTransformState().ensure("char:old", RootTransform(y = 2f, ry = 35f))
        state = state.addKey("char:old", 5).edit("char:old", 5, RootTransform(y = 4f, ry = 370f))
        val copy = state.duplicateTarget("char:old", "char:new")
        assertEquals(state.sample("char:old", 5), copy.sample("char:new", 5))
        assertTrue(copy.hasKey("char:new", 5))
        val changed = copy.edit("char:new", 5, RootTransform(y = 8f, ry = 720f))
        assertEquals(370f, changed.sample("char:old", 5).ry, 0.001f)
        assertEquals(720f, changed.sample("char:new", 5).ry, 0.001f)
    }

    @Test fun anglesKeepFullTurnsInsteadOfWrappingTo180Degrees() {
        val t = RootTransform(rx = -307.2f, ry = 1440f, rz = 720f).normalized()
        assertEquals(-307.2f, t.rx, 0.001f)
        assertEquals(1440f, t.ry, 0.001f)
        assertEquals(720f, t.rz, 0.001f)
    }

    @Test fun editingTrackAddsKeyAtCurrentFrameAndKeepsBase() {
        val base = RootTransform(1f, 0f, 0f, 0f, 15f, 0f, 1f)
        var state = RootTransformState().ensure("char:a", base)
        state = state.addKey("char:a", 0)
        state = state.edit("char:a", 20, RootTransform(8f, 0f, 0f, 0f, 80f, 0f, 1f))
        assertEquals(base, state.base("char:a"))
        assertTrue(state.hasKey("char:a", 20))
    }
}
