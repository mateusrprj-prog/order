package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.scene.RootTransform
import kotlin.math.min

@Composable
fun TransformPanel(
    targetId: String,
    targets: List<Pair<String, String>>,
    transform: RootTransform,
    frame: Int,
    hasKey: Boolean,
    keyFrames: IntArray,
    onTarget: (String) -> Unit,
    onChange: (RootTransform) -> Unit,
    onAddKey: () -> Unit,
    onDeleteKey: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(10.dp).verticalScroll(rememberScrollState())) {
        Text("Transformar personagem", color = Color.White, fontSize = 14.sp)
        Text("Rotação aplicada à personagem inteira — não move a câmera nem altera a pose dos ossos.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp, bottom = 8.dp))
        var menu by remember { mutableStateOf(false) }
        val selected = targets.firstOrNull { it.first == targetId }?.second ?: "Personagem principal"
        Box {
            Text("Alvo: $selected  ▾", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Color(0xFF26282D), RoundedCornerShape(6.dp)).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 7.dp))
            androidx.compose.material3.DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                targets.forEach { (id, name) ->
                    androidx.compose.material3.DropdownMenuItem(text = { Text(name) }, onClick = { onTarget(id); menu = false })
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Controle circular · arraste para girar", color = Muted, fontSize = 10.sp)
                RotationPad(transform.rx, transform.ry) { rx, ry -> onChange(transform.copy(rx = rx, ry = ry)) }
                Text("Horizontal = Y · Vertical = X", color = Muted, fontSize = 9.sp)
                Text("Z é ajustado no campo ao lado", color = Muted, fontSize = 9.sp)
                Text("Zerar rotação", color = Color(0xFFFFD166), fontSize = 10.sp,
                    modifier = Modifier.clickable { onChange(transform.copy(rx = 0f, ry = 0f, rz = 0f)) }.padding(top = 5.dp))
            }
            Column(Modifier.weight(1f)) {
                AxisField("X°", transform.rx) { onChange(transform.copy(rx = it)) }
                AxisField("Y°", transform.ry) { onChange(transform.copy(ry = it)) }
                AxisField("Z°", transform.rz) { onChange(transform.copy(rz = it)) }
            }
        }
        Text("Posição e escala", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 3.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            AxisField("Pos X", transform.x, Modifier.weight(1f)) { onChange(transform.copy(x = it)) }
            AxisField("Pos Y", transform.y, Modifier.weight(1f)) { onChange(transform.copy(y = it)) }
            AxisField("Pos Z", transform.z, Modifier.weight(1f)) { onChange(transform.copy(z = it)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Escala", color = Color.White, fontSize = 11.sp)
            Slider(value = transform.scale.coerceIn(0.05f, 5f), onValueChange = { onChange(transform.copy(scale = it)) }, valueRange = 0.05f..5f, modifier = Modifier.weight(1f))
            Text("%.2f×".format(transform.scale), color = Color.White, fontSize = 10.sp)
        }
        Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (hasKey) "◆ Keyframe no quadro $frame" else "+ Criar keyframe no quadro $frame", color = Color.White, fontSize = 11.sp,
                modifier = Modifier.weight(1f).background(Accent, RoundedCornerShape(6.dp)).clickable { if (hasKey) onDeleteKey() else onAddKey() }.padding(horizontal = 10.dp, vertical = 8.dp))
            Text("${keyFrames.size} keys", color = Muted, fontSize = 10.sp)
        }
        if (keyFrames.isNotEmpty()) Text("Quadros: " + keyFrames.take(30).joinToString(", ") + if (keyFrames.size > 30) "…" else "", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun AxisField(label: String, value: Float, modifier: Modifier = Modifier, onCommit: (Float) -> Unit) {
    var text by remember(label, value) { mutableStateOf(if (value % 1f == 0f) value.toInt().toString() else "%.2f".format(value)) }
    var wasFocused by remember(label) { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    fun commit() { text.replace(',', '.').toFloatOrNull()?.let(onCommit) }
    Column(modifier.widthIn(min = 54.dp).padding(bottom = 3.dp)) {
        Text(label, color = Muted, fontSize = 9.sp)
        OutlinedTextField(value = text, onValueChange = { next ->
            text = next.filterIndexed { i, c -> c.isDigit() || c == '-' && i == 0 || (c == '.' || c == ',') && next.take(i).none { it == '.' || it == ',' } }
        }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            keyboardActions = KeyboardActions(onDone = { commit(); focus.clearFocus() }),
            modifier = Modifier.fillMaxWidth().height(48.dp).onFocusChanged {
                if (it.isFocused) wasFocused = true else if (wasFocused) { wasFocused = false; commit() }
            },
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp))
    }
}

@Composable
private fun RotationPad(rx: Float, ry: Float, onChange: (Float, Float) -> Unit) {
    val latestChange by rememberUpdatedState(onChange)
    val latestRx by rememberUpdatedState(rx)
    val latestRy by rememberUpdatedState(ry)
    Canvas(Modifier.size(124.dp).padding(4.dp).pointerInput(Unit) {
        detectDragGestures { change, _ ->
            val r = min(size.width, size.height) * 0.46f
            val cx = size.width / 2f; val cy = size.height / 2f
            val dx = (change.position.x - cx) / r
            val dy = (change.position.y - cy) / r
            val angleY = dx.coerceIn(-1f, 1f) * 180f
            val angleX = (-dy).coerceIn(-1f, 1f) * 90f
            latestChange(angleX, angleY)
        }
    }) {
        val c = center; val r = size.minDimension * 0.43f
        drawCircle(Color(0xFF303238), r, c)
        drawCircle(Color(0xFF777B84), r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        drawLine(Color(0xFF777B84), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
        drawLine(Color(0xFF777B84), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
        drawCircle(Color(0xFF777B84), 3.dp.toPx(), c)
        val px = c.x + (latestRy / 180f).coerceIn(-1f, 1f) * r
        val py = c.y - (latestRx / 90f).coerceIn(-1f, 1f) * r
        drawLine(Color(0xFFFFD166), c, Offset(px, py), 2.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Accent, 7.dp.toPx(), Offset(px, py))
    }
}
