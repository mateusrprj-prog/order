# MMD Studio — Contexto técnico da entrega v1.30.1

## Identificação
- Projeto: MMD Studio para Android, Kotlin + Jetpack Compose + OpenGL ES.
- Versão no Gradle: 1.30.1 (versionCode 71).
- Base recebida nesta tarefa: `MMDStudio_v1_30_0.zip`.
- Objetivo desta alteração: permitir transformar/rotacionar a personagem inteira, e não a câmera de visualização.

## O que foi alterado
1. `app/src/main/java/studio/mmd/scene/RootTransform.kt`
   - Estado de transformação por personagem: posição X/Y/Z, rotação X/Y/Z e escala uniforme.
   - Trilhas de keyframes com interpolação linear contínua; os ângulos não são reduzidos para ±180°, permitindo voltas completas.
   - Serialização JSON para `root_transforms.json`.
2. `app/src/main/java/studio/mmd/project/Project.kt`
   - Leitura e gravação atômica do arquivo de transformação dentro da pasta do projeto.
3. `app/src/main/java/studio/mmd/render/SceneGLView.kt`
   - `setRootTransform` e matriz raiz `T * Rz * Ry * Rx * S` no personagem principal e nos extras.
   - Matriz usada na renderização, MVP do esqueleto, picking, foco e props ligados ao personagem principal.
   - Não altera dados internos do Animator nem as keys dos ossos.
4. `app/src/main/java/studio/mmd/ui/TransformPanel.kt`
   - Painel Transformar, seletor do alvo, controle circular X/Y, campos numéricos X/Y/Z, posição, escala, zerar rotação e controles de keyframe.
5. `app/src/main/java/studio/mmd/ui/SceneScreen.kt`
   - Integração do painel à interface, amostragem por quadro, persistência e preparação das transformações antes de exportar/capturar.
6. `app/src/test/java/studio/mmd/RootTransformTest.kt`
   - Testes de codec, interpolação e edição de keyframes.

## Como acessar no app
1. Abra um projeto com personagem importada.
2. Na tela Scene, toque no chip **Transformar**.
3. Escolha **Personagem principal** ou um personagem do Elenco no seletor.
4. Arraste o controle circular: horizontal altera Y e vertical altera X. Use os campos numéricos para X/Y/Z, posição e escala.
5. Use **Zerar rotação** para zerar apenas X/Y/Z.
6. No quadro desejado, use **Criar keyframe**; no mesmo quadro o controle permite remover a key.

## Separação de sistemas
- Transformação raiz: move/gira/escala a personagem inteira.
- Ossos: continuam controlados pelo Animator/VMD/Editor.
- Câmera da viewport: permanece no sistema orbital independente.
- Câmera cinematográfica/VMD: não é transformada por este painel.

## Estado de validação
- Implementação em código-fonte: SIM.
- Documentação (README, CHANGELOG, roadmaps): atualizada.
- Testes unitários escritos/atualizados: SIM.
- Testes unitários executados nesta entrega: NÃO.
- Build Android executado: NÃO.
- Teste em dispositivo Android: NÃO.

Motivo: este ambiente não contém Gradle, Gradle Wrapper ou Android SDK (`android.jar`). A compilação e validação real precisam ser realizadas pelo workflow `Build Android APK` no GitHub Actions e depois no aparelho. Não tratar esta versão como validada até esses passos concluírem.

## Limitações conhecidas
- O controle circular controla X/Y; Z é numérico.
- Ainda não há rotação relativa à câmera, gizmo de rotação 3D diretamente sobre o modelo nem Undo/Redo dedicado à transformação.
- As transformações raiz são gravadas no projeto e aparecem nas capturas MP4/PNG/sequência; não são convertidas/baked para exportação VMD, GLB ou FBX nesta versão.
- Requer validação visual de modelos importados com pivôs/origens fora do centro.

## Próxima ação prioritária
Executar o workflow Android, corrigir eventuais erros de compilação, instalar o APK e percorrer os critérios de aceitação na seção v1.30.1 dos roadmaps mestres.
