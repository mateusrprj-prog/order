package studio.mmd.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.ui.geometry.Size
import studio.mmd.project.Aspects
import studio.mmd.project.Backgrounds
import studio.mmd.project.ProjectMeta
import studio.mmd.project.PropMeta
import studio.mmd.scene.CastCodec
import studio.mmd.scene.CastMeta
import studio.mmd.scene.OutlinerState
import studio.mmd.scene.History
import studio.mmd.project.AudioCfg
import studio.mmd.project.ProjectStore
import java.io.File
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import android.media.MediaPlayer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlin.math.abs
import kotlin.math.floor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.edit.Editor
import studio.mmd.importer.ModelImporter
import studio.mmd.mmd.VmdParser
import studio.mmd.cartoon.Built
import studio.mmd.cartoon.CartoonCat
import studio.mmd.scene.SceneHierarchy
import studio.mmd.scene.PoseTransfer
import studio.mmd.cartoon.CartoonMerge
import studio.mmd.cartoon.CartoonItem
import studio.mmd.cartoon.CartoonLibrary
import studio.mmd.mmd.PmxWriter
import studio.mmd.project.PoseLib
import studio.mmd.fbx.FbxExporter
import studio.mmd.fbx.GlbExporter
import studio.mmd.export.MediaExport
import studio.mmd.export.VideoEncoder
import android.graphics.Bitmap
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import studio.mmd.render.SceneGLView
import studio.mmd.render.TouchMode
import studio.mmd.render.ViewPreset

val Bg = Color(0xFF0A0A0B); val Panel = Color(0xFF17181B); val Accent = Color(0xFFE53935)
val Muted = Color(0xFF8A8D94)
const val FPS = 30; const val DEFAULT_FRAMES = 300

@Composable
fun SceneScreen(project: ProjectMeta, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var glReady by remember { mutableStateOf(false) }
    var restored by remember { mutableStateOf(false) }
    var guide by remember { mutableStateOf(true) }
    val gl = remember { SceneGLView(ctx).also { it.onReady = { glReady = true } } }
    var mode by remember { mutableStateOf(TouchMode.ORBIT) }
    var menu by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(maxOf(project.frames, 2)) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var editor by remember { mutableStateOf<Editor?>(null) }
    var skeleton by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var selBone by remember { mutableIntStateOf(-1) }
    var selMorph by remember { mutableIntStateOf(-1) }
    var rig by remember { mutableStateOf<List<studio.mmd.rig.Constraint>>(emptyList()) }
    var sec by remember { mutableStateOf<List<studio.mmd.rig.Secondary>>(emptyList()) }
    var phys by remember { mutableStateOf(studio.mmd.rig.PhysConfig()) }
    var camMotion by remember { mutableStateOf<studio.mmd.mmd.VmdCamera?>(null) }
    var camOn by remember { mutableStateOf(true) }
    var camFlip by remember { mutableStateOf(false) }
    var baking by remember { mutableStateOf(false) }
    val ed = editor
    val ver = ed?.version ?: 0
    var audio by remember { mutableStateOf<MediaPlayer?>(null) }
    var texData by remember { mutableStateOf<List<ByteArray?>>(emptyList()) }
    var exportMenu by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val prefs = remember { ctx.getSharedPreferences("mmdstudio", android.content.Context.MODE_PRIVATE) }
    var lightCfg by remember { mutableStateOf(studio.mmd.render.LightCfg(prefs.getFloat("l_yaw", 21f), prefs.getFloat("l_pitch", 35f), prefs.getFloat("l_int", 1f), prefs.getFloat("l_r", 1f), prefs.getFloat("l_g", 1f), prefs.getFloat("l_b", 1f))) }
    var lightDlg by remember { mutableStateOf(false) }
    // v1.23.0: animações do GLB/glTF importado (escolha de clip)
    var glbClips by remember { mutableStateOf<List<studio.mmd.mmd.GltfClip>>(emptyList()) }
    var glbRig by remember { mutableStateOf<studio.mmd.mmd.GltfRig?>(null) }
    var clipDlg by remember { mutableStateOf(false) }
    var clipCur by remember { mutableIntStateOf(-1) }
    var mocapDlg by remember { mutableStateOf(false) }
    var aiDlg by remember { mutableStateOf(false) }
    var bonesShown by remember { mutableStateOf(true) }
    var vidMbps by remember { mutableStateOf(prefs.getInt("vid_mbps", 0)) }
    var preview60 by remember { mutableStateOf(prefs.getBoolean("preview60", true)) }
    var shading by remember { mutableIntStateOf(prefs.getInt("shading", 1)) }   // 0 Solid, 1 Material Preview, 2 Rendered, 3 MMD
    var shadowsOn by remember { mutableStateOf(prefs.getBoolean("shadows", true)) }
    var outlineOn by remember { mutableStateOf(prefs.getBoolean("outline", true)) }
    var layersOpen by remember { mutableStateOf(false) }
    var layerSel by remember { mutableStateOf("model") }
    var lookCfg by remember { mutableStateOf(studio.mmd.render.LookCfg(prefs.getFloat("k_exp", 1f), prefs.getFloat("k_con", 1f), prefs.getFloat("k_sat", 1f), prefs.getFloat("k_rim", 0f), prefs.getFloat("k_soft", 0.13f), prefs.getFloat("k_shade", 1f))) }
    var lightPanel by remember { mutableStateOf(false) }
    var camPanel by remember { mutableStateOf(false) }
    var hidden by remember { mutableStateOf(setOf<String>()) }
    // v1.29.0 (8.4a): Outliner — nomes, bloqueio, visibilidade no render, grupos e ordem (outliner.json)
    var outl by remember { mutableStateOf(OutlinerState()) }
    var fpsShow by remember { mutableFloatStateOf(0f) }
    var shaderWarned by remember { mutableStateOf(false) }
    var fbxZip by remember { mutableStateOf(false) }
    var pmxZip by remember { mutableStateOf(false) }
    var scenePanel by remember { mutableStateOf(false) }
    var audioPanel by remember { mutableStateOf(false) }
    var audioName by remember { mutableStateOf<String?>(null) }
    var audioVol by remember { mutableFloatStateOf(1f) }
    var audioOff by remember { mutableIntStateOf(0) }
    var props by remember { mutableStateOf<List<PropMeta>>(emptyList()) }
    var selProp by remember { mutableIntStateOf(-1) }
    // v1.27.0 (8.3c): elenco = personagens extras animados (cada um com Animator, movimento e transformação próprios; mesmo relógio da timeline)
    var cast by remember { mutableStateOf<List<CastMeta>>(emptyList()) }
    var selCast by remember { mutableIntStateOf(-1) }
    var castPanel by remember { mutableStateOf(false) }
    // v1.28.0: Cartoon Motion Library (biblioteca de movimentos cartunescos; usa o mesmo Editor/Animator)
    var cartoonPanel by remember { mutableStateOf(false) }
    var cartoonPreviewId by remember { mutableStateOf<String?>(null) }
    var cartoonPreview by remember { mutableStateOf<studio.mmd.mmd.VmdMotion?>(null) }
    var cartoonPreviewLoop by remember { mutableStateOf(true) }
    var cartoonImportCat by remember { mutableStateOf(CartoonCat.BODY) }
    // v1.29.2: Cartoon em personagem EXTRA do Elenco (alvo, prévia no extra e desfazer próprio; extras não têm Editor)
    var cartoonTarget by remember { mutableStateOf("") }          // "" = principal; senão id do extra
    var cartoonPreviewTarget by remember { mutableStateOf("") }
    class CastUndo(val id: String, val oldBytes: ByteArray?, val oldName: String, val itemName: String)
    val castUndo = remember { ArrayList<CastUndo>() }
    var castUndoTick by remember { mutableIntStateOf(0) }
    var castMotionFor by remember { mutableStateOf("") }
    val castModels = remember { HashMap<String, studio.mmd.mmd.PmxModel>() }   // v1.29.6: modelo de cada extra (IK das pernas no Cartoon)
    val castMorphs = remember { HashMap<String, Set<String>>() }      // id -> nomes de morphs (compatibilidade/aplicação do Cartoon)
    val castBones = remember { HashMap<String, Set<String>>() }       // id -> nomes de ossos (para contar quantos ossos do VMD casam)
    val castMissing = remember { ArrayList<CastMeta>() }              // itens do cast.json cujo arquivo não abriu: preservados ao salvar, nunca apagados em silêncio
    fun persistCast() { try { ProjectStore.saveCast(ctx, project.id, cast + castMissing) } catch (ignored: Throwable) {} }
    // v1.29.12 (8.3d-B2): personagem ATIVO de edição. O principal usa `editor`; cada extra ganha um Editor sob demanda (carregado de cast/<id>.vmd).
    var activeId by remember { mutableStateOf(studio.mmd.scene.ActiveCharacter.MAIN) }
    var sessTick by remember { mutableIntStateOf(0) }
    val extraBase = remember { HashMap<String, Int>() }   // versão do Editor ao abrir: só é "sujo" se mudou depois
    val sessions = remember { studio.mmd.scene.EditSessions<Editor> { id ->
        val m = castModels[id] ?: return@EditSessions null
        val e = Editor(m); val f = ProjectStore.castMotionFile(ctx, project.id, id)
        if (f.exists() && f.length() > 0) try { e.load(VmdParser.parse(f.readBytes())) } catch (ignored: Throwable) {}
        e
    } }
    val actId = studio.mmd.scene.ActiveCharacter.resolve(activeId, cast.map { it.id })
    val ae: Editor? = if (sessTick >= 0 && actId != studio.mmd.scene.ActiveCharacter.MAIN) sessions.get(actId) else editor
    val aver = ae?.version ?: 0
    /** Grava no cast/<id>.vmd os extras editados (sem keys = apaga o arquivo). */
    fun flushExtras() {
        val saved = ArrayList<String>()
        sessions.flush { id, e ->
            try {
                val f = ProjectStore.castMotionFile(ctx, project.id, id)
                if (e.keyCount() > 0) f.writeBytes(e.toVmd()) else f.delete()
                saved.add(id); true
            } catch (ex: Throwable) { false }
        }
        if (saved.isNotEmpty()) {
            cast = cast.map { c -> if (c.id in saved) c.copy(motion = if (sessions.get(c.id)?.keyCount() == 0) "" else if (c.motion.isEmpty()) "editado" else c.motion) else c }
            persistCast()
        }
    }
    /** O .vmd do extra foi trocado por fora (Cartoon, pose, importar, desfazer): descarta a sessão para recarregar do arquivo. */
    fun dropSession(id: String) { sessions.drop(id); extraBase.remove(id); sessTick++ }
    fun warnText(w: List<String>): String =
        if (w.isEmpty()) "" else "\nAVISOS (${w.size}):" + w.take(3).joinToString("") { "\n• $it" } + (if (w.size > 3) "\n… e mais ${w.size - 3} (veja o log)" else "")
    fun note(t: String) { toast = t }
    // v1.29.1 (8.4b): desfazer/refazer da organização (nomes, bloqueio, render, grupos, ordem). Excluir/duplicar mexem em arquivos e NÃO são desfeitos.
    class OutlSnap(val state: OutlinerState, val propNames: Map<String, String>, val castNames: Map<String, String>)
    val outlHist = remember { History<OutlSnap>(50) }
    var outlHistTick by remember { mutableIntStateOf(0) }   // força recomposição dos botões desfazer/refazer
    fun outlSnap() = OutlSnap(outl, props.associate { "prop:" + it.id to it.name }, cast.associate { "char:" + it.id to it.name })
    fun recordOutl() { outlHist.push(outlSnap()); outlHistTick++ }
    fun persistOutl() { try { ProjectStore.saveOutliner(ctx, project.id, outl) } catch (ignored: Throwable) {} }
    fun restoreOutl(sn: OutlSnap) {
        val valid = (listOf("model") + props.map { "prop:" + it.id } + cast.map { "char:" + it.id } + castMissing.map { "char:" + it.id }).toSet()
        outl = sn.state.prune(valid)
        props = props.map { p -> sn.propNames["prop:" + p.id]?.let { p.copy(name = it) } ?: p }
        cast = cast.map { c -> sn.castNames["char:" + c.id]?.let { c.copy(name = it) } ?: c }
        try { ProjectStore.saveProps(ctx, project.id, props) } catch (ignored: Throwable) {}
        persistCast(); persistOutl(); outlHistTick++
    }
    fun removePropAt(i: Int) {
        val pm = props.getOrNull(i) ?: return
        val key = "prop:" + pm.id
        if (outl.isLocked(key)) { note("'${pm.name}' está bloqueado no Outliner"); return }
        gl.removeProp(pm.id); ProjectStore.deletePropFile(ctx, project.id, pm)
        hidden = hidden - key
        props = props.filterIndexed { k, _ -> k != i }; selProp = -1
        ProjectStore.saveProps(ctx, project.id, props)
        outl = outl.forget(key); persistOutl()
    }
    fun removeCastAt(i: Int) {
        val cm = cast.getOrNull(i) ?: return
        val key = "char:" + cm.id
        if (outl.isLocked(key)) { note("'${cm.name}' está bloqueado no Outliner"); return }
        sessions.drop(cm.id); extraBase.remove(cm.id); if (activeId == cm.id) activeId = studio.mmd.scene.ActiveCharacter.MAIN
        gl.removeCharacter(cm.id); ProjectStore.deleteCastFiles(ctx, project.id, cm); castBones.remove(cm.id); castMorphs.remove(cm.id); castModels.remove(cm.id); castUndo.removeAll { it.id == cm.id }; castUndoTick++
        hidden = hidden - key
        cast = cast.filterIndexed { k, _ -> k != i }; selCast = -1
        persistCast()
        outl = outl.forget(key); persistOutl()
    }
    val scope = rememberCoroutineScope()
    /** Duplica um personagem extra ou acessório/cenário: copia os arquivos (id novo), recarrega e entra no mesmo grupo. Estado mutável nunca é compartilhado. */
    fun duplicateLayer(k: String) {
        scope.launch {
            isError = false
            try {
                if (k.startsWith("char:")) {
                    val src = cast.firstOrNull { "char:" + it.id == k } ?: return@launch
                    val n = withContext(Dispatchers.IO) { ProjectStore.duplicateCast(ctx, project.id, src) }
                    val r = try { withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.castFile(ctx, project.id, n))) } }
                        catch (ex: Throwable) { ProjectStore.deleteCastFiles(ctx, project.id, n); throw ex }
                    val mf = ProjectStore.castMotionFile(ctx, project.id, n.id)
                    val mo = if (mf.exists()) try { withContext(Dispatchers.IO) { VmdParser.parse(mf.readBytes()) } } catch (ignored: Throwable) { null } else null
                    castBones[n.id] = r.model.bones.map { it.name }.toHashSet(); castMorphs[n.id] = r.model.morphs.map { it.name }.toHashSet(); castModels[n.id] = r.model
                    gl.addCharacter(n.id, r.model, r.textures, mo, n.x, n.y, n.z, n.ry, n.s)
                    cast = cast + (if (mo == null && n.motion.isNotEmpty()) n.copy(motion = "") else n)
                    persistCast()
                    outl.groupOf(k)?.let { g -> outl = outl.addToGroup("char:" + n.id, g.id); persistOutl() }
                    status = "'${n.name}' criado (cópia independente)"
                } else if (k.startsWith("prop:")) {
                    val src = props.firstOrNull { "prop:" + it.id == k } ?: return@launch
                    val n = withContext(Dispatchers.IO) { ProjectStore.duplicateProp(ctx, project.id, src) }
                    val r = try { withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.propFile(ctx, project.id, n))) } }
                        catch (ex: Throwable) { ProjectStore.deletePropFile(ctx, project.id, n); throw ex }
                    gl.addProp(n.id, r.model, r.textures, n.x, n.y, n.z, n.s, n.bone, n.rx, n.ry, n.rz)
                    props = props + n
                    ProjectStore.saveProps(ctx, project.id, props)
                    outl.groupOf(k)?.let { g -> outl = outl.addToGroup("prop:" + n.id, g.id); persistOutl() }
                    status = "'${n.name}' criado (cópia independente)"
                }
            } catch (e: Throwable) { isError = true; status = "Erro ao duplicar: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val bytes = e.toVmd(camMotion); val n = e.keyCount()
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(bytes) }
                    }
                    isError = false; status = "VMD salvo\n$n keyframes${if (camMotion != null) " + câmera (${camMotion!!.frames.size})" else ""} · ${bytes.size / 1024} KB"
                } catch (ex: Throwable) { isError = true; status = "Erro ao salvar: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    // v1.29.10 (8.3d-C): exporta principal + extras num .zip (um .vmd por personagem)
    val castZipSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val items = ArrayList<Pair<String, ByteArray>>()
            editor?.let { e -> if (e.keyCount() > 0) items.add((project.name.ifBlank { "principal" }) to e.toVmd(camMotion)) }
            for (cm in cast) { val f = ProjectStore.castMotionFile(ctx, project.id, cm.id); if (f.exists() && f.length() > 0) items.add(cm.name to f.readBytes()) }
            scope.launch {
                try {
                    if (items.isEmpty()) throw IllegalStateException("Nenhum personagem com movimento")
                    val zipBytes = withContext(Dispatchers.IO) { studio.mmd.scene.CastExport.zip(items) }
                    withContext(Dispatchers.IO) { (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(zipBytes) } }
                    isError = false; status = "Elenco salvo\n${items.size} personagem(ns) · ${zipBytes.size / 1024} KB"
                } catch (ex: Throwable) { isError = true; status = "Erro ao salvar: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    fun saveAudio() { ProjectStore.saveAudioCfg(ctx, project.id, audioName?.let { AudioCfg(it, audioVol, audioOff) }) }

    val fbxSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val mo = e.motion(); val frames = maxOf(mo.maxFrame + 1, 2); val tex = texData; val zip = fbxZip
            val base = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }
            isError = false; status = "Exportando FBX...\n$frames quadros"
            scope.launch {
                try {
                    var size = 0L; var rep: FbxExporter.Report? = null
                    withContext(Dispatchers.Default) {
                        val raw = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        val cnt = CountOut(raw.buffered(1 shl 16))
                        cnt.use { c ->
                            val names = FbxExporter.textureFileNames(e.model, tex)
                            if (zip) {
                                val z = ZipOutputStream(c)
                                z.putNextEntry(ZipEntry("$base.fbx"))
                                rep = FbxExporter.write(z, e.model, mo, names, frames)
                                z.closeEntry()
                                names.forEachIndexed { i, nm ->
                                    val b = tex.getOrNull(i)
                                    if (nm != null && b != null) { z.putNextEntry(ZipEntry(nm)); z.write(b); z.closeEntry() }
                                }
                                z.finish()
                            } else { rep = FbxExporter.write(c, e.model, mo, names, frames) }
                            Unit
                        }
                        size = cnt.count
                    }
                    val r = rep
                    status = "FBX exportado\n${r?.bones} ossos · ${r?.frames} quadros a $FPS fps\n${r?.animatedBones} ossos animados · ${size / 1024} KB" +
                        if (zip) "\n(zip com texturas)" else "\n(sem texturas)"
                } catch (ex: Throwable) { isError = true; status = "Erro ao exportar FBX: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    val pmxSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val tex = texData; val zip = pmxZip; val base = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }
            isError = false; status = "Exportando PMX..."
            scope.launch {
                try {
                    var size = 0L; var wr: List<String> = emptyList()
                    withContext(Dispatchers.Default) {
                        val names = PmxWriter.textureFileNames(e.model.textures, tex)
                        val out = PmxWriter.write(e.model, names.map { it.replace('/', '\\') })
                        wr = out.warnings
                        val raw = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        val cnt = CountOut(raw.buffered(1 shl 16))
                        cnt.use { c ->
                            if (zip) {
                                val z = ZipOutputStream(c)
                                z.putNextEntry(ZipEntry("$base.pmx")); z.write(out.bytes); z.closeEntry()
                                names.forEachIndexed { i, nm ->
                                    val b = tex.getOrNull(i)
                                    if (nm.isNotEmpty() && b != null) { z.putNextEntry(ZipEntry(nm)); z.write(b); z.closeEntry() }
                                }
                                z.finish()
                            } else { c.write(out.bytes) }
                            Unit
                        }
                        size = cnt.count
                    }
                    val ww = wr
                    for (x in ww) studio.mmd.util.Log.w("PmxExport", x)
                    status = "PMX exportado\n${e.model.vertexCount} vértices · ${e.model.bones.size} ossos · ${e.model.morphs.size} morphs · ${size / 1024} KB\n" +
                        "modelo em pose de repouso, sem animação (use Salvar animação .vmd)" +
                        (if (zip) "\n(zip com texturas)" else "\n(sem texturas)") + warnText(ww)
                } catch (ex: Throwable) { isError = true; status = "Erro ao exportar PMX: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    fun outName() = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }

    val glbSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("model/gltf-binary")) { uri ->
        val e = editor
        if (uri != null && e != null) {
            val mo = e.motion(); val frames = maxOf(mo.maxFrame + 1, 2); val tex = texData
            isError = false; status = "Exportando GLB...\n$frames quadros"
            scope.launch {
                try {
                    var size = 0L; var rep: FbxExporter.Report? = null
                    withContext(Dispatchers.Default) {
                        val raw = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        val cnt = CountOut(raw.buffered(1 shl 16))
                        cnt.use { c -> rep = GlbExporter.write(c, e.model, mo, tex, frames); Unit }
                        size = cnt.count
                    }
                    val r = rep
                    status = "GLB exportado\n${r?.bones} ossos · ${r?.frames} quadros a $FPS fps\n${r?.animatedBones} ossos animados · ${size / 1024} KB\ntexturas embutidas no arquivo"
                } catch (ex: Throwable) { isError = true; status = "Erro ao exportar GLB: ${ex.message ?: ex.javaClass.simpleName}" }
            }
        }
    }

    val pngSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Salvando imagem..."
            try {
                gl.setHidden(hidden + outl.renderOff)
                val shot = gl.captureAwait(frame) ?: throw IllegalStateException("Falha ao capturar a tela")
                val img = MediaExport.cropAspect(shot, Aspects.ratio(project.aspect))
                withContext(Dispatchers.IO) {
                    (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                status = "Imagem salva\n${img.width}×${img.height} (quadro $frame)"
            } catch (ex: Throwable) { isError = true; status = "Erro ao salvar imagem: ${ex.message ?: ex.javaClass.simpleName}" }
            gl.setHidden(hidden); gl.setFrame(frame)
        }
    }

    val vpdSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val e = editor
        if (uri != null && e != null) scope.launch {
            try {
                val bytes = MediaExport.vpd(e.model, e, frame, outName())
                withContext(Dispatchers.IO) { (ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")).use { it.write(bytes) } }
                isError = false; status = "Pose salva (.vpd)\nquadro $frame · ${bytes.size / 1024 + 1} KB\n(só ossos; morphs não incluídos)"
            } catch (ex: Throwable) { isError = true; status = "Erro ao salvar pose: ${ex.message ?: ex.javaClass.simpleName}" }
        }
    }

    val zipSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            try {
                editor?.let { e -> ProjectStore.saveAnim(ctx, project.id, if (e.keyCount() > 0) e.toVmd() else null) }
                saveAudio(); ProjectStore.saveProps(ctx, project.id, props); persistCast(); ProjectStore.saveRig(ctx, project.id, rig); ProjectStore.saveSecondary(ctx, project.id, sec)
                val n = withContext(Dispatchers.IO) {
                    val o = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                    o.buffered(1 shl 16).use { MediaExport.zipDir(ProjectStore.dir(ctx, project.id), it) }
                }
                isError = false; status = "Projeto exportado (.zip)\n$n arquivos"
            } catch (ex: Throwable) { isError = true; status = "Erro ao exportar projeto: ${ex.message ?: ex.javaClass.simpleName}" }
        }
    }

    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val ext = ModelImporter.displayName(ctx, uri).substringAfterLast('.', "png").lowercase().ifEmpty { "png" }
                val bmp = withContext(Dispatchers.IO) { decodeBg(ProjectStore.copyIn(ctx, project.id, uri, "bg", ext)) } ?: throw IllegalStateException("Não consegui ler essa imagem")
                gl.setBackgroundImage(bmp); isError = false; status = "Imagem de fundo aplicada\n${bmp.width}×${bmp.height} (aparece no vídeo e nos PNGs)"
            } catch (ex: Throwable) { isError = true; status = "Erro no fundo: ${ex.message ?: ex.javaClass.simpleName}" }
        }
    }

    val seqSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val e = editor
        if (uri != null && !exporting) {
            val frames = if (e != null && e.keyCount() > 0) maxOf(e.motion().maxFrame + 1, 2) else total
            exporting = true; playing = false; isError = false; gl.setHidden(hidden + outl.renderOff)
            scope.launch {
                try {
                    val ratio = Aspects.ratio(project.aspect); val limit = Aspects.size(project.aspect, project.resolution)
                    val os = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                    java.util.zip.ZipOutputStream(os.buffered(1 shl 16)).use { zo ->
                        for (f in 0 until frames) {
                            val shot = gl.captureAwait(f) ?: throw IllegalStateException("Falha ao capturar o quadro $f")
                            withContext(Dispatchers.Default) {
                                val c = MediaExport.cropAspect(shot, ratio)
                                var tw = c.width; var th = c.height
                                if (limit != null && tw > limit.first) { th = th * limit.first / tw; tw = limit.first }
                                val b = if (tw == c.width && th == c.height) c else Bitmap.createScaledBitmap(c, tw, th, true)
                                zo.putNextEntry(java.util.zip.ZipEntry("${outName()}_%05d.png".format(f)))
                                b.compress(Bitmap.CompressFormat.PNG, 100, zo)
                                zo.closeEntry()
                            }
                            status = "Exportando PNGs...\n${f + 1}/$frames quadros"
                        }
                    }
                    status = "Sequência PNG exportada (.zip)\n$frames quadros numerados ${outName()}_00000.png…"
                } catch (ex: Throwable) { isError = true; status = "Erro na sequência PNG: ${ex.message ?: ex.javaClass.simpleName}" }
                finally { exporting = false; gl.setFrame(frame) }
            }
        }
    }

    val videoSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        val e = editor
        if (uri != null && !exporting) {
            val frames = if (e != null && e.keyCount() > 0) maxOf(e.motion().maxFrame + 1, 2) else total
            exporting = true; playing = false; isError = false; gl.setHidden(hidden + outl.renderOff)
            scope.launch {
                val tmp = File(ctx.cacheDir, "export_video.mp4")
                val tmp2 = File(ctx.cacheDir, "export_video_audio.mp4")
                var enc: VideoEncoder? = null
                var done = false
                try {
                    status = "Exportando vídeo...\npreparando"
                    val ratio = Aspects.ratio(project.aspect)
                    val limit = Aspects.size(project.aspect, project.resolution)
                    val first = gl.captureAwait(0) ?: throw IllegalStateException("Falha ao capturar a tela")
                    val c0 = MediaExport.cropAspect(first, ratio)
                    var tw = c0.width; var th = c0.height
                    if (limit != null && tw > limit.first) { th = th * limit.first / tw; tw = limit.first }   // nunca aumenta além da tela
                    tw = maxOf(16, tw / 16 * 16); th = maxOf(16, th / 16 * 16)
                    val encoder = withContext(Dispatchers.Default) { VideoEncoder(tmp, tw, th, FPS, vidMbps * 1_000_000) }
                    enc = encoder
                    for (f in 0 until frames) {
                        val shot = if (f == 0) first else (gl.captureAwait(f) ?: throw IllegalStateException("Falha ao capturar o quadro $f"))
                        withContext(Dispatchers.Default) {
                            val c = MediaExport.cropAspect(shot, ratio)
                            val b = if (c.width == tw && c.height == th) c else Bitmap.createScaledBitmap(c, tw, th, true)
                            encoder.add(b)
                        }
                        status = "Exportando vídeo...\n${f + 1}/$frames quadros · ${tw}×${th}"
                    }
                    withContext(Dispatchers.Default) { encoder.finish() }
                    done = true
                    var src = tmp; var audioNote = "(sem áudio)"
                    val af = ProjectStore.fileWith(ctx, project.id, "audio")
                    if (af != null) {
                        status = "Exportando vídeo...\njuntando o áudio"
                        try {
                            withContext(Dispatchers.Default) { studio.mmd.export.AudioMux.mux(tmp, af, tmp2, audioOff, audioVol, frames * 1_000_000L / FPS) }
                            src = tmp2; audioNote = "(com áudio)"
                        } catch (ax: Throwable) { audioNote = "(sem áudio: ${ax.message ?: ax.javaClass.simpleName})" }
                    }
                    withContext(Dispatchers.IO) {
                        val o = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Não foi possível gravar o arquivo")
                        o.use { out -> src.inputStream().use { it.copyTo(out) } }
                    }
                    status = "Vídeo exportado (.mp4)\n${tw}×${th} · $frames quadros a $FPS fps · ${tmp.length() / 1024} KB\n$audioNote"
                } catch (ex: Throwable) {
                    isError = true; status = "Erro ao exportar vídeo: ${ex.message ?: ex.javaClass.simpleName}"
                    if (!done) enc?.abort()
                } finally {
                    tmp.delete(); tmp2.delete(); exporting = false; gl.setFrame(frame)
                }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in setOf("mp3", "wav", "ogg", "m4a", "aac", "flac")) {
                    val copy = withContext(Dispatchers.IO) { ProjectStore.copyIn(ctx, project.id, uri, "audio", ext) }
                    val mp = withContext(Dispatchers.IO) { MediaPlayer().apply { setDataSource(copy.absolutePath); prepare() } }
                    audio?.release(); audio = mp; audioName = name; saveAudio()
                    status = "$name\náudio: %.1fs (toca junto com o play)".format(mp.duration / 1000f)
                } else if (ext == "vmd") {
                    val bytes = withContext(Dispatchers.IO) { ModelImporter.readBytes(ctx, uri) }
                    val cam = withContext(Dispatchers.IO) { VmdParser.parseCamera(bytes) }
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(bytes) }
                    val hasMotion = mo.bones.isNotEmpty() || mo.morphs.isNotEmpty()
                    var camInfo = ""
                    if (cam != null) {
                        withContext(Dispatchers.IO) { ProjectStore.copyIn(ctx, project.id, uri, "camera", "vmd") }
                        camMotion = cam; camOn = true
                        total = maxOf(total, cam.maxFrame + 1)
                        camInfo = "câmera: ${cam.frames.size} keys (%.1fs) — ligada".format((cam.maxFrame + 1) / FPS.toFloat())
                    }
                    if (hasMotion || cam == null) {
                        val e = editor ?: throw IllegalStateException("Importe um modelo (.pmx/.zip) antes do movimento")
                        val m = e.model
                        val boneNames = m.bones.map { it.name }.toHashSet(); val morphNames = m.morphs.map { it.name }.toHashSet()
                        val bm = mo.bones.keys.count { it in boneNames }; val mm = mo.morphs.keys.count { it in morphNames }
                        playing = false; frame = 0; total = maxOf(mo.maxFrame + 1, cam?.let { it.maxFrame + 1 } ?: 0)
                        e.load(mo); gl.setFrame(0)
                        status = "$name\n${total} frames (%.1fs a $FPS fps)\nossos casados: $bm/${mo.bones.size}\nmorphs casados: $mm/${mo.morphs.size}".format(total / FPS.toFloat()) +
                            (if (bm == 0) "\nATENÇÃO: nenhum osso casou; o modelo não vai se mover" else "") + (if (camInfo.isNotEmpty()) "\n$camInfo" else "") +
                            (if (e.lastSkippedBoneKeys + e.lastSkippedMorphKeys > 0) "\nAVISO: ${e.lastSkippedBoneKeys} keys de ossos e ${e.lastSkippedMorphKeys} de morphs não existem neste modelo e não serão salvas" else "") +
                            warnText(mo.warnings)
                        mo.warnings.forEach { studio.mmd.util.Log.w("VMD", it) }
                        if (bm == 0) isError = true
                    } else {
                        playing = false; frame = 0; gl.setFrame(0)
                        status = "$name\n$camInfo\nMenu do viewport: liga/desliga a câmera do VMD."
                    }
                } else {
                    val src = if (ext in setOf("zip", "pmx", "glb", "gltf", "obj")) withContext(Dispatchers.IO) { Uri.fromFile(ProjectStore.copyIn(ctx, project.id, uri, "model", ext)) } else uri
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, src) }
                    val m = r.model
                    editor = Editor(m); texData = r.textures; selBone = -1; selMorph = -1; playing = false; frame = 0; total = DEFAULT_FRAMES
                    gl.loadModel(m, r.textures)
                    status = "${m.name.ifBlank { r.sourceName }}\n${m.vertexCount} vértices · ${m.indices.size / 3} triângulos\n" +
                        "${m.materials.size} materiais · ${m.bones.size} ossos · ${m.morphs.size} morphs\n" +
                        "texturas: ${r.textures.count { it != null }}/${m.textures.size}" + warnText(m.warnings)
                    m.warnings.forEach { studio.mmd.util.Log.w("PMX", it) }
                    val rg = r.rig
                    glbClips = r.clips; glbRig = rg; clipCur = -1
                    if (r.clips.isNotEmpty() && rg != null) { // v1.22.0/v1.23.0: GLB/glTF com animação -> keyframes do editor (1ª por padrão; escolha em 'Animações do arquivo…')
                        val clip = r.clips[0]
                        val cv = withContext(Dispatchers.Default) { studio.mmd.mmd.GltfToMotion.convert(clip, rg, m) }
                        if (cv.motion.bones.isNotEmpty()) {
                            editor?.load(cv.motion); total = cv.motion.maxFrame + 1; frame = 0; gl.setFrame(0); clipCur = 0
                            status += "\nAnimação '${clip.name}' importada (${cv.motion.bones.size} ossos, $total frames" + (if (r.clips.size > 1) "; o arquivo tem ${r.clips.size}: menu do viewport > Animações do arquivo…" else "") + ")"
                        } else { isError = true; status += "\nAnimação '${clip.name}' NÃO aplicada: nenhum canal casou com ossos do modelo" }
                        cv.warnings.forEach { studio.mmd.util.Log.w("GLB", it) }
                        if (r.clips.size > 1) clipDlg = true
                    }
                }
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    val cartoonPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val name = ModelImporter.displayName(ctx, uri)
                if (!name.lowercase().endsWith(".vmd")) throw IllegalStateException("Escolha um arquivo .vmd")
                val it2 = withContext(Dispatchers.IO) { CartoonLibrary.importVmd(ctx, uri, name, cartoonImportCat) }
                isError = false; status = "Movimento \"${it2.name}\" adicionado à biblioteca (${it2.cat.label}, ${it2.frames} quadros). Fica salvo neste aparelho."
            } catch (e: Throwable) { isError = true; status = "VMD não importado: ${e.message ?: e.javaClass.simpleName}" }
        }
    }
    val castPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando personagem..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in setOf("pmx", "pmd", "zip", "glb", "gltf")) throw IllegalStateException("Escolha um .pmx, .pmd, .glb, .gltf ou .zip")
                val m0 = withContext(Dispatchers.IO) { ProjectStore.addCastFile(ctx, project.id, uri, name.substringBeforeLast('.'), ext) }
                val r = try { withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.castFile(ctx, project.id, m0))) } }
                    catch (ex: Throwable) { ProjectStore.deleteCastFiles(ctx, project.id, m0); throw ex }
                var mo: studio.mmd.mmd.VmdMotion? = null; var label = ""; var note2 = ""
                val rg = r.rig
                if (r.clips.isNotEmpty() && rg != null) {   // GLB animado: a 1ª animação vira o movimento do personagem (salvo como cast/<id>.vmd)
                    try {
                        val clip = r.clips[0]
                        val cv = withContext(Dispatchers.Default) { studio.mmd.mmd.GltfToMotion.convert(clip, rg, r.model) }
                        if (cv.motion.bones.isNotEmpty()) {
                            val bytes = Editor(r.model).also { it.load(cv.motion) }.toVmd()
                            withContext(Dispatchers.IO) { ProjectStore.castMotionFile(ctx, project.id, m0.id).writeBytes(bytes) }
                            mo = cv.motion; label = clip.name.ifBlank { "animação do GLB" }
                            note2 = "\nMovimento '$label' (${cv.motion.bones.size} ossos)"
                        } else note2 = "\nA animação do arquivo não casou com nenhum osso"
                    } catch (ex: Throwable) { note2 = "\nAnimação do arquivo não aplicada: ${ex.message ?: ex.javaClass.simpleName}" }
                }
                val meta = m0.copy(x = 3f * (cast.size + 1), motion = label)
                castBones[meta.id] = r.model.bones.map { it.name }.toHashSet(); castMorphs[meta.id] = r.model.morphs.map { it.name }.toHashSet(); castModels[meta.id] = r.model
                gl.addCharacter(meta.id, r.model, r.textures, mo, meta.x, meta.y, meta.z, meta.ry, meta.s)
                cast = cast + meta; selCast = cast.size - 1
                mo?.let { total = CastCodec.totalFrames(total, listOf(it.maxFrame)) }
                persistCast()
                status = "${meta.name} (personagem extra)\n${r.model.vertexCount} vértices · ${r.model.bones.size} ossos · ${r.model.materials.size} materiais" + note2 +
                    "\nElenco: ${cast.size + 1} personagens na cena" + warnText(r.model.warnings)
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    val castMotionPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val cid = castMotionFor
        if (uri != null && cid.isNotEmpty()) scope.launch {
            isError = false; status = "Carregando movimento..."
            try {
                val cm = cast.firstOrNull { it.id == cid } ?: throw IllegalStateException("Personagem não encontrado")
                val name = ModelImporter.displayName(ctx, uri)
                if (!name.lowercase().endsWith(".vmd")) throw IllegalStateException("Escolha um arquivo .vmd")
                val bytes = withContext(Dispatchers.IO) { ModelImporter.readBytes(ctx, uri) }
                val mo = withContext(Dispatchers.Default) { VmdParser.parse(bytes) }
                if (mo.bones.isEmpty() && mo.morphs.isEmpty()) throw IllegalStateException("Este .vmd não tem movimento de ossos nem de morphs")
                val names = castBones[cid] ?: emptySet()
                val bm = mo.bones.keys.count { it in names }
                withContext(Dispatchers.IO) { ProjectStore.castMotionFile(ctx, project.id, cid).writeBytes(bytes) }
                dropSession(cid); gl.setCharacterMotion(cid, mo)
                cast = cast.map { if (it.id == cid) it.copy(motion = name) else it }
                total = CastCodec.totalFrames(total, listOf(mo.maxFrame))
                persistCast()
                status = "${cm.name}: $name\n${mo.maxFrame + 1} frames · ossos casados: $bm/${mo.bones.size}" +
                    (if (bm == 0) "\nATENÇÃO: nenhum osso casou; o personagem não vai se mover" else "") + warnText(mo.warnings)
                if (bm == 0) isError = true
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    val propPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            isError = false; status = "Carregando objeto..."
            try {
                val name = ModelImporter.displayName(ctx, uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in setOf("pmx", "zip", "x", "pmd", "glb", "gltf", "obj")) throw IllegalStateException("Escolha um .pmx, .pmd, .x, .glb, .gltf, .obj ou .zip")
                val meta = withContext(Dispatchers.IO) { ProjectStore.addPropFile(ctx, project.id, uri, name.substringBeforeLast('.'), ext) }
                val r = try { withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.propFile(ctx, project.id, meta))) } }
                    catch (ex: Throwable) { ProjectStore.deletePropFile(ctx, project.id, meta); throw ex }
                gl.addProp(meta.id, r.model, r.textures, meta.x, meta.y, meta.z, meta.s)
                props = props + meta; selProp = props.size - 1
                ProjectStore.saveProps(ctx, project.id, props)
                status = "${meta.name}\n${r.model.vertexCount} vértices · ${r.model.materials.size} materiais\ntexturas: ${r.textures.count { it != null }}/${r.model.textures.size}"
            } catch (e: Throwable) { isError = true; status = "Erro: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    LaunchedEffect(audio, audioVol) { try { val v = audioVol.coerceIn(0f, 1f); audio?.setVolume(v, v) } catch (ignored: Throwable) {} }
    LaunchedEffect(playing, total, audio) {
        val a = audio
        // toca o áudio na posição que corresponde ao quadro f (considerando o atraso); antes do atraso fica em silêncio
        fun startAudioAt(f: Float) {
            if (a == null) return
            try {
                val t = (f * 1000f / FPS).toInt() - audioOff
                if (t >= 0 && t < a.duration) { a.seekTo(t); if (!a.isPlaying) a.start() }
            } catch (ignored: Throwable) {}
        }
        // reprodução por tempo real, sincronizada com o vsync: a posição é fracionária (interpola entre os quadros
        // de 30 fps do VMD), então a prévia pode renderizar a 60 fps; se o aparelho não alcança, pula quadros em vez de atrasar
        var pos = frame.toFloat()
        var wrote = frame
        var last = 0L; var lastRender = 0L; var lastTarget = -1f
        if (playing) { startAudioAt(pos); last = withFrameNanos { it } }
        while (playing) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f); last = now
            if (frame != wrote) {   // o usuário mexeu na timeline durante o play
                pos = frame.toFloat(); wrote = frame
                try { if (a != null && a.isPlaying) a.pause() } catch (ignored: Throwable) {}
                startAudioAt(pos)
            } else pos += dt * FPS
            if (a != null && a.isPlaying) {
                val ap = (a.currentPosition + audioOff) / 1000f * FPS
                if (abs(ap - pos) > 3f) pos = ap   // só corrige se o áudio desviou mais de 3 quadros
            }
            if (pos >= total) {
                pos = 0f
                try { if (a != null && a.isPlaying) a.pause() } catch (ignored: Throwable) {}
                startAudioAt(0f)
            } else if (a != null && !a.isPlaying) startAudioAt(pos)
            if (preview60) {
                if (now - lastRender >= 15_000_000L) { lastRender = now; gl.setFramePos(pos) }
            } else {
                val q = floor(pos)
                if (q != lastTarget) { lastTarget = q; gl.setFramePos(q) }
            }
            val fi = pos.toInt()
            if (fi != frame) { frame = fi; wrote = fi }
        }
        if (a != null) { try { if (a.isPlaying) a.pause() } catch (ignored: Throwable) {} }
        gl.setFrame(frame)
    }
    DisposableEffect(Unit) { onDispose { audio?.release(); audio = null } }

    // ---- salvamento automático do projeto
    fun saveNow() {
        if (!restored) return
        try {
            editor?.let { e -> ProjectStore.saveAnim(ctx, project.id, if (e.keyCount() > 0) e.toVmd() else null) }
            flushExtras()
            ProjectStore.touch(ctx, project.id, total)
        } catch (ignored: Throwable) {}
    }
    fun closeNow() { saveNow(); onClose() }
    BackHandler { closeNow() }
    LaunchedEffect(ed, ver, aver, actId, total, restored) { if (restored) { delay(1500); saveNow() } }
    LaunchedEffect(Unit) { gl.setClearColor(Backgrounds.color(project.bg)) }

    // ---- reabre o que o projeto já tem (modelo, animação, áudio) quando o GL estiver pronto
    LaunchedEffect(glReady) {
        if (!glReady) return@LaunchedEffect
        try {
            val mf = ProjectStore.fileWith(ctx, project.id, "model")
            if (mf != null) {
                isError = false; status = "Abrindo projeto..."
                val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(mf)) }
                glbClips = r.clips; glbRig = r.rig; clipCur = -1   // v1.29.5: a lista de animações do GLB volta ao reabrir (a animação salva continua valendo)
                val e = Editor(r.model)
                val vf = ProjectStore.animFile(ctx, project.id)
                if (vf.exists()) {
                    val mo = withContext(Dispatchers.IO) { VmdParser.parse(vf.readBytes()) }
                    e.load(mo); total = maxOf(project.frames, mo.maxFrame + 1)
                }
                editor = e; texData = r.textures; gl.loadModel(r.model, r.textures)
                status = null
            }
            PoseLib.open(File(ProjectStore.animFile(ctx, project.id).parentFile, "poses.json"))
            ProjectStore.fileWith(ctx, project.id, "bg")?.let { bf -> withContext(Dispatchers.IO) { decodeBg(bf) }?.let { gl.setBackgroundImage(it) } }
            ProjectStore.fileWith(ctx, project.id, "camera")?.let { cf ->
                try { VmdParser.parseCamera(withContext(Dispatchers.IO) { cf.readBytes() })?.let { camMotion = it; total = maxOf(total, it.maxFrame + 1) } } catch (ignored: Throwable) {}
            }
            rig = ProjectStore.loadRig(ctx, project.id); sec = ProjectStore.loadSecondary(ctx, project.id); phys = ProjectStore.loadPhys(ctx, project.id)
            val loaded = ArrayList<PropMeta>()
            for (pm in ProjectStore.loadProps(ctx, project.id)) {
                try {
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.propFile(ctx, project.id, pm))) }
                    gl.addProp(pm.id, r.model, r.textures, pm.x, pm.y, pm.z, pm.s, pm.bone, pm.rx, pm.ry, pm.rz); loaded.add(pm)
                } catch (ignored: Throwable) {}
            }
            props = loaded
            // elenco (8.3c): reabre cada personagem extra com o movimento salvo; os que falharem ficam em castMissing (preservados no cast.json)
            val castLoaded = ArrayList<CastMeta>(); var castMax = -1
            for (cm in ProjectStore.loadCast(ctx, project.id)) {
                try {
                    val r = withContext(Dispatchers.IO) { ModelImporter.load(ctx, Uri.fromFile(ProjectStore.castFile(ctx, project.id, cm))) }
                    val mf = ProjectStore.castMotionFile(ctx, project.id, cm.id)
                    val mo = if (mf.exists()) try { withContext(Dispatchers.IO) { VmdParser.parse(mf.readBytes()) } } catch (ignored: Throwable) { null } else null
                    gl.addCharacter(cm.id, r.model, r.textures, mo, cm.x, cm.y, cm.z, cm.ry, cm.s)
                    castBones[cm.id] = r.model.bones.map { it.name }.toHashSet(); castMorphs[cm.id] = r.model.morphs.map { it.name }.toHashSet(); castModels[cm.id] = r.model
                    if (mo != null) castMax = maxOf(castMax, mo.maxFrame)
                    castLoaded.add(if (mo == null && cm.motion.isNotEmpty()) cm.copy(motion = "") else cm)
                } catch (ex: Throwable) { castMissing.add(cm); studio.mmd.util.Log.w("CAST", "não abriu '${cm.name}': ${ex.message ?: ex.javaClass.simpleName}") }
            }
            cast = castLoaded; total = CastCodec.totalFrames(total, listOf(castMax))
            // Outliner (8.4a): organização salva; referências a objetos que não existem mais são descartadas (personagens que não abriram contam como existentes)
            outl = ProjectStore.loadOutliner(ctx, project.id).prune(
                (listOf("model") + props.map { "prop:" + it.id } + castLoaded.map { "char:" + it.id } + castMissing.map { "char:" + it.id }).toSet())
            if (castMissing.isNotEmpty()) { isError = true; status = "${castMissing.size} personagem(ns) extra(s) não abriu(ram): " + castMissing.joinToString { it.name } + "\n(mantidos no projeto; nada foi apagado)" }
            val af = ProjectStore.fileWith(ctx, project.id, "audio")
            if (af != null) {
                audio = withContext(Dispatchers.IO) { MediaPlayer().apply { setDataSource(af.absolutePath); prepare() } }
                ProjectStore.loadAudioCfg(ctx, project.id)?.let { audioName = it.name; audioVol = it.volume; audioOff = it.offsetMs }
                if (audioName == null) audioName = af.name
            }
        } catch (ex: Throwable) { isError = true; status = "Erro ao abrir o projeto: ${ex.message ?: ex.javaClass.simpleName}" }
        restored = true
    }
    LaunchedEffect(frame) { if (!playing) gl.setFrame(frame) }
    // restrições do Rig: valem na prévia e nas exportações (o Animator lê de RigState); salva com atraso
    LaunchedEffect(rig, restored) {
        studio.mmd.rig.RigState.list = rig; gl.refreshPose()
        if (restored) { delay(800); try { ProjectStore.saveRig(ctx, project.id, rig) } catch (ignored: Throwable) {} }
    }
    LaunchedEffect(sec, restored) {
        studio.mmd.rig.RigState.secondary = sec; gl.refreshPose()
        if (restored) { delay(800); try { ProjectStore.saveSecondary(ctx, project.id, sec) } catch (ignored: Throwable) {} }
    }
    LaunchedEffect(lightCfg) {
        gl.setLight(lightCfg)
        prefs.edit().putFloat("l_yaw", lightCfg.yaw).putFloat("l_pitch", lightCfg.pitch).putFloat("l_int", lightCfg.intensity)
            .putFloat("l_r", lightCfg.r).putFloat("l_g", lightCfg.g).putFloat("l_b", lightCfg.b).apply()
    }
    LaunchedEffect(lookCfg) {
        gl.setLook(lookCfg)
        prefs.edit().putFloat("k_exp", lookCfg.exposure).putFloat("k_con", lookCfg.contrast).putFloat("k_sat", lookCfg.saturation)
            .putFloat("k_rim", lookCfg.rim).putFloat("k_soft", lookCfg.softness).putFloat("k_shade", lookCfg.shade).apply()
    }
    // v1.29.0: itens com 'visível no render' desligado só somem durante a exportação (PNG/vídeo/sequência); na viewport continuam como estão
    LaunchedEffect(hidden, exporting) { gl.setHidden(if (exporting) hidden + outl.renderOff else hidden) }
    LaunchedEffect(shading) { gl.setShading(shading); prefs.edit().putInt("shading", shading).apply() }
    LaunchedEffect(shadowsOn) { gl.setShadows(shadowsOn); prefs.edit().putBoolean("shadows", shadowsOn).apply() }
    LaunchedEffect(outlineOn) { gl.setOutline(outlineOn); prefs.edit().putBoolean("outline", outlineOn).apply() }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500); fpsShow = gl.fps
            val se = gl.shaderError
            if (se != null && !shaderWarned) { shaderWarned = true; isError = true; status = "Erro de shader: " + se.take(300) }
        }
    }
    fun applyClip(i: Int) {
        val clip = glbClips.getOrNull(i) ?: return
        val rg = glbRig ?: return
        val ed = editor ?: return
        scope.launch {
            try {
                val cv = withContext(Dispatchers.Default) { studio.mmd.mmd.GltfToMotion.convert(clip, rg, ed.model) }
                if (cv.motion.bones.isEmpty()) { isError = true; status = "Animação '${clip.name}' NÃO aplicada: nenhum canal casou com ossos do modelo"; return@launch }
                playing = false
                ed.replaceUndoable(cv.motion); total = maxOf(total, cv.motion.maxFrame + 1); frame = 0; gl.setFrame(0); clipCur = i
                isError = false; status = "Animação '${clip.name}' aplicada (${cv.motion.bones.size} ossos, $total frames). Substituiu as keys atuais; use Desfazer para voltar às anteriores."
                cv.warnings.forEach { studio.mmd.util.Log.w("GLB", it) }
            } catch (e: Throwable) { isError = true; status = "Erro ao aplicar animação: ${e.message ?: e.javaClass.simpleName}" }
        }
    }
    if (clipDlg) ClipPickerDialog(glbClips, clipCur, { applyClip(it); clipDlg = false }, { clipDlg = false })
    if (lightDlg) LightDialog(lightCfg, { lightCfg = it }, { lightDlg = false })
    val mocapEd = editor
    if (mocapDlg && mocapEd != null) MocapDialog(mocapEd, frame, FPS, { mocapDlg = false }) { msg, last ->
        total = maxOf(total, last + 1); isError = false; status = msg
    }
    if (aiDlg && mocapEd != null) AiAnimDialog(mocapEd, frame, FPS, { aiDlg = false }) { msg, last ->
        total = maxOf(total, last + 1); isError = false; status = msg
    }
    LaunchedEffect(Unit) { CartoonLibrary.load(ctx) }
    LaunchedEffect(playing) { if (playing) { cartoonPreview = null; cartoonPreviewId = null } }
    /** Volta o movimento de um extra ao que está salvo em cast/<id>.vmd (ou parado), depois de uma prévia do Cartoon. */
    fun restoreExtraMotion(id: String) {
        val mf = ProjectStore.castMotionFile(ctx, project.id, id)
        val mo = if (mf.exists()) try { VmdParser.parse(mf.readBytes()) } catch (e: Throwable) { null } else null
        gl.setCharacterMotion(id, mo)
    }
    /** v1.29.2: aplica o movimento Cartoon num extra: mescla no .vmd dele (só entre b.first e b.last), grava e guarda 1 passo de desfazer. */
    fun applyCartoonToExtra(item: CartoonItem, b: Built) {
        val cm = cast.firstOrNull { it.id == cartoonTarget }
        flushExtras()
        if (cm == null) { note("Personagem extra não encontrado"); return }
        if (outl.isLocked("char:" + cm.id)) { note("'${cm.name}' está bloqueado no Outliner"); return }
        cartoonPreview = null; cartoonPreviewId = null; playing = false
        scope.launch {
            try {
                val mf = ProjectStore.castMotionFile(ctx, project.id, cm.id)
                val oldBytes = withContext(Dispatchers.IO) { if (mf.exists()) mf.readBytes() else null }
                val oldMo = if (oldBytes != null) withContext(Dispatchers.Default) { VmdParser.parse(oldBytes) } else null
                val r = withContext(Dispatchers.Default) { CartoonMerge.merge(oldMo, b, castBones[cm.id], castMorphs[cm.id], castModels[cm.id]?.let { studio.mmd.cartoon.ikBonesDriving(it, b.bones.keys) } ?: emptyList()) }
                if (r.written == 0) { isError = true; status = "Cartoon: nenhum osso/morph deste movimento existe no modelo de '${cm.name}'. Nada foi alterado."; return@launch }
                val bytes = withContext(Dispatchers.Default) { CartoonMerge.toVmdBytes(r.motion, cm.name) }
                withContext(Dispatchers.IO) { mf.writeBytes(bytes) }
                dropSession(cm.id)
                gl.setCharacterMotion(cm.id, r.motion)
                castUndo.add(CastUndo(cm.id, oldBytes, cm.motion, "Cartoon \"" + item.name + "\"")); if (castUndo.size > 20) castUndo.removeAt(0)
                castUndoTick++
                cast = cast.map { if (it.id == cm.id) it.copy(motion = if (it.motion.isEmpty()) "Cartoon: " + item.name else if (it.motion.contains("Cartoon")) it.motion else it.motion + " + Cartoon") else it }
                total = CastCodec.totalFrames(total, listOf(r.motion.maxFrame))
                persistCast()
                isError = false
                status = "Cartoon: \"${item.name}\" aplicada em ${cm.name}: ${r.written} keys, quadros ${b.first}–${b.last} (%.1fs). Use \"Desfazer no extra\" para voltar.".format((b.last - b.first + 1) / FPS.toFloat())
            } catch (e: Throwable) { isError = true; status = "Erro no Cartoon (nada foi alterado): ${e.message ?: e.javaClass.simpleName}" }
        }
    }
    fun undoExtra(id: String) {
        val u = castUndo.lastOrNull { it.id == id } ?: return
        val cm = cast.firstOrNull { it.id == u.id }
        if (cm == null) { castUndo.removeAll { it.id == u.id }; castUndoTick++; return }
        if (outl.isLocked("char:" + cm.id)) { note("'${cm.name}' está bloqueado no Outliner"); return }
        scope.launch {
            try {
                val mf = ProjectStore.castMotionFile(ctx, project.id, cm.id)
                val ob = u.oldBytes
                if (ob == null) { withContext(Dispatchers.IO) { mf.delete() }; gl.setCharacterMotion(cm.id, null) }
                else {
                    val mo = withContext(Dispatchers.Default) { VmdParser.parse(ob) }
                    withContext(Dispatchers.IO) { mf.writeBytes(ob) }
                    gl.setCharacterMotion(cm.id, mo)
                }
                castUndo.remove(u); castUndoTick++; dropSession(cm.id)
                cast = cast.map { if (it.id == cm.id) it.copy(motion = u.oldName) else it }
                persistCast()
                isError = false; status = "Desfeito: ${u.itemName} em ${cm.name}."
            } catch (e: Throwable) { isError = true; status = "Erro ao desfazer: ${e.message ?: e.javaClass.simpleName}" }
        }
    }
    fun undoCartoonExtra() = undoExtra(cartoonTarget)
    /** v1.29.9 (8.3d): fotografa a pose do extra no quadro atual para a biblioteca de poses do projeto (vale para qualquer personagem). */
    fun castSavePose(i: Int) {
        val cm = cast.getOrNull(i) ?: return
        flushExtras()
        val mf = ProjectStore.castMotionFile(ctx, project.id, cm.id)
        val mo = if (mf.exists()) try { VmdParser.parse(mf.readBytes()) } catch (e: Throwable) { null } else null
        val sn = PoseTransfer.capture(mo, frame, "Pose ${PoseLib.items.size + 1} (${cm.name})")
        if (sn.bones.isEmpty() && sn.morphs.isEmpty()) { note("${cm.name} não tem movimento para fotografar"); return }
        PoseLib.add(sn); note("${sn.name} salva (${sn.bones.size} ossos, ${sn.morphs.size} morphs)")
    }
    /** Aplica uma pose da biblioteca no extra, como key no quadro atual (só o movimento dele muda; 1 passo de desfazer). */
    fun castApplyPose(i: Int, pi: Int) {
        val cm = cast.getOrNull(i) ?: return
        val p = PoseLib.items.getOrNull(pi) ?: return
        if (outl.isLocked("char:" + cm.id)) { note("'${cm.name}' está bloqueado no Outliner"); return }
        val at = frame
        flushExtras()
        scope.launch {
            try {
                val mf = ProjectStore.castMotionFile(ctx, project.id, cm.id)
                val oldBytes = withContext(Dispatchers.IO) { if (mf.exists()) mf.readBytes() else null }
                val oldMo = if (oldBytes != null) withContext(Dispatchers.Default) { VmdParser.parse(oldBytes) } else null
                val r = PoseTransfer.apply(oldMo, p, at, castBones[cm.id], castMorphs[cm.id])
                if (r.written == 0) { isError = true; status = "Nenhum osso/morph da pose '${p.name}' existe no modelo de '${cm.name}'. Nada foi alterado."; return@launch }
                val bytes = withContext(Dispatchers.Default) { CartoonMerge.toVmdBytes(r.motion, cm.name) }
                withContext(Dispatchers.IO) { mf.writeBytes(bytes) }
                dropSession(cm.id)
                gl.setCharacterMotion(cm.id, r.motion)
                castUndo.add(CastUndo(cm.id, oldBytes, cm.motion, "pose \"" + p.name + "\"")); if (castUndo.size > 20) castUndo.removeAt(0)
                castUndoTick++
                cast = cast.map { if (it.id == cm.id && it.motion.isEmpty()) it.copy(motion = "Pose: " + p.name) else it }
                total = CastCodec.totalFrames(total, listOf(r.motion.maxFrame))
                persistCast()
                val cp = castBones[cm.id]?.let { PoseTransfer.compat(p, it) } ?: 1f
                isError = false
                status = "Pose '${p.name}' aplicada em ${cm.name} (quadro $at): ${r.written} keys" + (if (cp < 0.8f) ", compat. ${(cp * 100).toInt()}% dos ossos" else "") + "."
            } catch (e: Throwable) { isError = true; status = "Erro ao aplicar pose (nada foi alterado): ${e.message ?: e.javaClass.simpleName}" }
        }
    }
    // Prévia da Cartoon: troca só o movimento mostrado (as keys do projeto NÃO mudam) e devolve o movimento do projeto ao terminar/parar.
    // v1.29.2: a prévia pode ser num extra (cartoonPreviewTarget); o extra volta ao movimento salvo no .vmd dele.
    LaunchedEffect(cartoonPreview) {
        val mo = cartoonPreview ?: return@LaunchedEffect
        val tgt = cartoonPreviewTarget
        val saved = frame; playing = false
        if (tgt.isEmpty()) gl.setMotion(mo) else gl.setCharacterMotion(tgt, mo)
        try {
            val last = maxOf(1, mo.maxFrame); var f = 0
            while (true) {
                gl.setFrame(f); kotlinx.coroutines.delay(1000L / FPS); f++
                if (f > last) { if (cartoonPreviewLoop) f = 0 else break }
            }
        } finally {
            if (cartoonPreview === mo) { cartoonPreview = null; cartoonPreviewId = null }
            if (tgt.isEmpty()) { if (cartoonPreview == null) editor?.let { gl.setMotion(it.motion()) } }
            else if (cartoonPreview == null || cartoonPreviewTarget != tgt) restoreExtraMotion(tgt)
            if (cartoonPreview == null) gl.setFrame(saved)
        }
    }
    LaunchedEffect(camMotion, camOn, camFlip) { gl.setVmdCamera(if (camOn) camMotion else null, camFlip) }
    LaunchedEffect(phys, restored) {
        studio.mmd.rig.RigState.phys = phys; gl.refreshPose()
        if (restored) { delay(800); try { ProjectStore.savePhys(ctx, project.id, phys) } catch (ignored: Throwable) {} }
    }
    DisposableEffect(Unit) { onDispose { studio.mmd.rig.RigState.list = emptyList(); studio.mmd.rig.RigState.secondary = emptyList(); studio.mmd.rig.RigState.phys = studio.mmd.rig.PhysConfig(); studio.mmd.rig.RigState.physCache = null } }
    /** Grava o movimento secundário (e restrições) dos ossos dos grupos ativos como keyframes, quadro a quadro. */
    fun bakeSecondary() {
        val e = editor ?: return
        val groups = sec.filter { it.enabled }
        val names = groups.flatMap { it.bones }.distinct().filter { n -> e.model.bones.any { it.name == n } }
        if (names.isEmpty()) { note("Nenhum grupo ativo"); return }
        val to = maxOf(e.allKeyFrames().lastOrNull() ?: 0, if (e.keyCount() == 0) total - 1 else 1)
        baking = true
        scope.launch {
            try {
                val mo = e.motion()
                val r = withContext(Dispatchers.Default) { studio.mmd.rig.Baker.compute(e.model, mo, names, 0, to) }
                val n = e.bakeRotations(names, 0, to) { f -> r.getOrNull(f) }
                sec = sec.map { if (it.enabled) it.copy(enabled = false) else it }
                note("Assado: $n keyframes. Grupos desligados.")
            } catch (ex: Throwable) { note("Erro ao assar: ${ex.message ?: ex.javaClass.simpleName}") }
            baking = false
        }
    }
    // toda edição gera um VmdMotion novo para a thread GL
    LaunchedEffect(ed, ver) { ed?.let { gl.setMotion(it.motion()) } }
    LaunchedEffect(ae, aver, actId) {
        if (actId != studio.mmd.scene.ActiveCharacter.MAIN && ae != null) {
            val b = extraBase.getOrPut(actId) { aver }
            if (aver != b) { sessions.markDirty(actId); gl.setCharacterMotion(actId, ae.motion()) }
        }
    }
    LaunchedEffect(skeleton, selBone, bonesShown) { gl.setOverlay(skeleton && bonesShown, selBone); gl.dragBone = if (skeleton) selBone else -1 }
    // v1.29.13 (8.3d-B3): o renderer desenha/seleciona/arrasta ossos do personagem ATIVO; ao ativar um extra, entrega o movimento do Editor (mesmo sem keys, para o esqueleto aparecer)
    LaunchedEffect(actId) {
        gl.setActiveCharacter(actId)
        if (actId != studio.mmd.scene.ActiveCharacter.MAIN) ae?.let { gl.setCharacterMotion(actId, it.motion()) }
    }
    LaunchedEffect(skeleton) { if (!skeleton && (mode == TouchMode.ROTATE || mode == TouchMode.MOVE)) { mode = TouchMode.ORBIT; gl.touchMode = mode } }
    LaunchedEffect(toast) { if (toast != null) { delay(2200); toast = null } }
    // painel de status some sozinho (erros ficam até tocar neles)
    LaunchedEffect(status, isError) { if (status != null && !isError) { delay(6000); status = null } }
    fun openPanel(which: String) {
        skeleton = which == "skel"; scenePanel = which == "scene"; audioPanel = which == "audio"; castPanel = which == "cast"; cartoonPanel = which == "cartoon"
        lightPanel = which == "light"; camPanel = which == "cam"
    }
    SideEffect {
        gl.onTap = { x, y ->
            if (skeleton && ae != null) gl.pickBone(x, y) { idx -> selBone = idx; if (idx >= 0) tab = 1 }
            else if (!skeleton) gl.pickLayer(x, y) { k ->   // v1.29.7: toque na viewport seleciona modelo/extra/acessório
                if (k != null) {
                    layerSel = k
                    when {
                        k == "model" -> openPanel("anim")
                        k.startsWith("char:") -> { openPanel("cast"); selCast = cast.indexOfFirst { "char:" + it.id == k } }
                        k.startsWith("prop:") -> { openPanel("scene"); selProp = props.indexOfFirst { "prop:" + it.id == k } }
                    }
                    note("Selecionado: " + (if (k == "model") "modelo principal" else if (k.startsWith("char:")) cast.firstOrNull { "char:" + it.id == k }?.name else props.firstOrNull { "prop:" + it.id == k }?.name ?: k))
                }
            }
        }
        gl.onBoneDrag = { rotate, v ->
            val e = ae; val b = e?.model?.bones?.getOrNull(selBone)
            if (e != null && b != null) {
                if (actId != studio.mmd.scene.ActiveCharacter.MAIN && outl.isLocked("char:" + actId)) note("Personagem bloqueado no Outliner")
                else if (rotate) { if (b.flags and 0x0002 != 0) e.nudgeBone(b.name, frame, v, null) else note("Este osso não pode girar") }
                else { if (b.flags and 0x0004 != 0) e.nudgeBone(b.name, frame, null, v) else note("Este osso não pode mover") }
            }
        }
        gl.onBoneDragEnd = { ae?.finishDrag() }
    }
    val selName = ae?.model?.bones?.getOrNull(selBone)?.name
    val hasKey = ae != null && selName != null && ae.hasKey(selName, frame)
    val keys = remember(ae, aver, selName, skeleton) {
        if (ae == null) IntArray(0) else if (skeleton && selName != null) ae.keyFramesOf(selName) else ae.allKeyFrames()
    }
    DisposableEffect(Unit) { gl.onResume(); onDispose { gl.onPause() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowBackIosNew, null, Modifier.clickable { closeNow() }.padding(8.dp).size(18.dp), tint = Color.White)
                Icon(Icons.Default.ViewInAr, null, Modifier.padding(start = 4.dp).size(18.dp), tint = Color.White)
                Text(project.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Box {
                    Icon(Icons.Default.Save, null, Modifier.clickable { exportMenu = true }.padding(8.dp).size(22.dp), tint = Color.White)
                    DropdownMenu(exportMenu, { exportMenu = false }) {
                        DropdownMenuItem(text = { Text("Salvar animação (.vmd)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes") else if (e.keyCount() == 0) note("Nenhum keyframe para salvar")
                            else saver.launch("animacao.vmd")
                        })
                        DropdownMenuItem(text = { Text("Salvar todos os personagens (.zip de .vmd)") }, onClick = {
                            exportMenu = false
                            if (cast.isEmpty()) note("Sem personagens extras: use \"Salvar animação\"") else castZipSaver.launch("elenco.zip")
                        })
                        DropdownMenuItem(text = { Text("Exportar modelo animado (.glb) — recomendado") }, onClick = {
                            exportMenu = false
                            if (editor == null) note("Importe um modelo antes") else glbSaver.launch("${outName()}.glb")
                        })
                        DropdownMenuItem(text = { Text("Exportar vídeo (.mp4)") }, onClick = {
                            exportMenu = false
                            if (exporting) note("Já existe uma exportação em andamento") else videoSaver.launch("${outName()}.mp4")
                        })
                        DropdownMenuItem(text = { Text(if (vidMbps == 0) "Bitrate do vídeo: automático (toque p/ mudar)" else "Bitrate do vídeo: $vidMbps Mbps (toque p/ mudar)") }, onClick = {
                            vidMbps = when (vidMbps) { 0 -> 4; 4 -> 8; 8 -> 16; 16 -> 30; else -> 0 }; prefs.edit().putInt("vid_mbps", vidMbps).apply()
                        })
                        DropdownMenuItem(text = { Text("Exportar sequência PNG (.zip)") }, onClick = {
                            exportMenu = false
                            if (exporting) note("Já existe uma exportação em andamento") else seqSaver.launch("${outName()}_frames.zip")
                        })
                        DropdownMenuItem(text = { Text("Salvar imagem do quadro (.png)") }, onClick = {
                            exportMenu = false; pngSaver.launch("${outName()}_quadro$frame.png")
                        })
                        DropdownMenuItem(text = { Text("Exportar pose do quadro (.vpd)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes") else vpdSaver.launch("${outName()}_pose$frame.vpd")
                        })
                        DropdownMenuItem(text = { Text("Exportar projeto (.zip)") }, onClick = {
                            exportMenu = false; zipSaver.launch("${outName()}_projeto.zip")
                        })
                        DropdownMenuItem(text = { Text("Exportar modelo (.pmx)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes")
                            else {
                                val withTex = texData.any { it != null }
                                pmxZip = withTex
                                pmxSaver.launch(if (withTex) "${outName()}_pmx.zip" else "${outName()}.pmx")
                            }
                        })
                        DropdownMenuItem(text = { Text("Exportar modelo animado (.fbx)") }, onClick = {
                            exportMenu = false
                            val e = editor
                            if (e == null) note("Importe um modelo antes")
                            else {
                                val withTex = texData.any { it != null }
                                fbxZip = withTex
                                val base = project.name.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.ifEmpty { "modelo" }
                                fbxSaver.launch(if (withTex) "$base.zip" else "$base.fbx")
                            }
                        })
                    }
                }
                Icon(Icons.Default.Layers, null, Modifier.clickable { layersOpen = !layersOpen }.padding(8.dp).size(22.dp), tint = if (layersOpen) Accent else Color.White)
                Icon(Icons.Default.FolderOpen, null, Modifier.clickable { picker.launch(arrayOf("*/*")) }.padding(8.dp).size(22.dp), tint = Color.White)
                Icon(Icons.Default.Close, null, Modifier.clickable { closeNow() }.padding(8.dp).size(20.dp), tint = Color.White)
            }
            Box(Modifier.padding(horizontal = 8.dp)) {
                Row(Modifier.clickable { menu = true }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Viewport de Edição", color = Color.White, fontSize = 12.sp)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Enquadrar tudo") }, onClick = { gl.frameAll(); menu = false })
                    DropdownMenuItem(text = { Text("Animar a partir de vídeo…") }, onClick = {
                        menu = false
                        if (editor == null) note("Importe um modelo primeiro") else mocapDlg = true
                    })
                    DropdownMenuItem(text = { Text("Animar com IA (texto)…") }, onClick = {
                        menu = false
                        if (editor == null) note("Importe um modelo primeiro") else aiDlg = true
                    })
                    if (glbClips.isNotEmpty()) DropdownMenuItem(text = { Text("Animações do arquivo… (${glbClips.size})") }, onClick = { menu = false; clipDlg = true })
                    DropdownMenuItem(text = { Text("Iluminação…") }, onClick = { menu = false; lightDlg = true })
                    DropdownMenuItem(text = { Text("Imagem de fundo…") }, onClick = { menu = false; bgPicker.launch(arrayOf("image/*")) })
                    DropdownMenuItem(text = { Text("Remover imagem de fundo") }, onClick = {
                        menu = false; gl.setBackgroundImage(null); ProjectStore.fileWith(ctx, project.id, "bg")?.delete(); note("Fundo removido")
                    })
                    if (camMotion != null) {
                        DropdownMenuItem(text = { Text(if (camOn) "Câmera do VMD: ligada (toque p/ câmera livre)" else "Câmera do VMD: desligada (toque p/ ligar)") }, onClick = { camOn = !camOn; menu = false })
                        DropdownMenuItem(text = { Text(if (camFlip) "Inclinação invertida (toque p/ normal)" else "Inverter inclinação da câmera") }, onClick = {
                            camFlip = !camFlip; menu = false; note("Se a câmera olha de cima/baixo ao contrário, use esta opção")
                        })
                        DropdownMenuItem(text = { Text("Remover câmera do VMD") }, onClick = {
                            camMotion = null; menu = false
                            ProjectStore.fileWith(ctx, project.id, "camera")?.delete(); note("Câmera removida")
                        })
                    }
                    DropdownMenuItem(text = { Text(if (preview60) "Prévia: 60 fps (toque p/ 30)" else "Prévia: 30 fps (toque p/ 60)") }, onClick = {
                        preview60 = !preview60; prefs.edit().putBoolean("preview60", preview60).apply(); menu = false
                        note(if (preview60) "Prévia a 60 fps" else "Prévia a 30 fps (economiza bateria)")
                    })
                    if (Aspects.ratio(project.aspect) > 0f) {
                        DropdownMenuItem(text = { Text(if (guide) "Ocultar moldura ${project.aspect}" else "Mostrar moldura ${project.aspect}") }, onClick = { guide = !guide; menu = false })
                    }
                    DropdownMenuItem(text = { Text(if (shadowsOn) "Sombras: ligadas (modos Render/MMD)" else "Sombras: desligadas") }, onClick = { shadowsOn = !shadowsOn; menu = false })
                    DropdownMenuItem(text = { Text(if (outlineOn) "Contorno: ligado (modo MMD)" else "Contorno: desligado") }, onClick = { outlineOn = !outlineOn; menu = false })
                    listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esquerda" to ViewPreset.LEFT,
                        "Direita" to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { gl.applyPreset(p); menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(4.dp))) {
                AndroidView(factory = { gl }, modifier = Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.TopCenter).padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.clip(RoundedCornerShape(10.dp)).background(Panel.copy(alpha = .85f)).padding(2.dp)) {
                        listOf("Solid" to 0, "Material" to 1, "Render" to 2, "MMD" to 3).forEach { (n, m) ->
                            Text(n, color = if (shading == m) Color.White else Muted, fontSize = 11.sp,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (shading == m) Accent else Color.Transparent)
                                    .clickable { shading = m }.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                    }
                    if (playing && fpsShow > 0f) Text("%.0f fps".format(fpsShow), color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                }
                val ratio = Aspects.ratio(project.aspect)
                if (guide && ratio > 0f) Canvas(Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height
                    var fw = w; var fh = fw / ratio
                    if (fh > h) { fh = h; fw = fh * ratio }
                    val l = (w - fw) / 2f; val t = (h - fh) / 2f
                    val dim = Color(0x88000000)
                    drawRect(dim, Offset(0f, 0f), Size(w, t)); drawRect(dim, Offset(0f, t + fh), Size(w, h - t - fh))
                    drawRect(dim, Offset(0f, t), Size(l, fh)); drawRect(dim, Offset(l + fw, t), Size(w - l - fw, fh))
                    drawRect(Color.White.copy(alpha = .5f), Offset(l, t), Size(fw, fh), style = Stroke(2f))
                }
                status?.let { Text(it, color = if (isError) Color(0xFFFF6B6B) else Color.White, fontSize = 9.sp, lineHeight = 12.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).widthIn(max = 200.dp).clip(RoundedCornerShape(6.dp))
                        .clickable { status = null }.background(Panel.copy(alpha = .75f)).padding(horizontal = 6.dp, vertical = 4.dp)) }
                toast?.let { Text(it, color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp).background(Panel.copy(alpha = .9f), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) }
                Column(Modifier.align(Alignment.CenterStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha = .85f))) {
                    ToolButton(Icons.Default.OpenWith, mode == TouchMode.ORBIT) { mode = TouchMode.ORBIT; gl.touchMode = mode }
                    ToolButton(Icons.Default.PanTool, mode == TouchMode.PAN) { mode = TouchMode.PAN; gl.touchMode = mode }
                    if (skeleton && ed != null) {
                        ToolButton(Icons.Default.Sync, mode == TouchMode.ROTATE) { mode = TouchMode.ROTATE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para girar") }
                        ToolButton(Icons.Default.ControlCamera, mode == TouchMode.MOVE) { mode = TouchMode.MOVE; gl.touchMode = mode; if (selBone < 0) note("Toque num osso para mover") }
                    }
                }
                if (layersOpen) {
                    val base = LinkedHashMap<String, Layer>()
                    base["model"] = Layer("model", outl.nameOf("model", ed?.model?.name?.ifBlank { "Modelo" } ?: "Sem modelo"), Icons.Default.ViewInAr,
                        if (ed != null) "${ed.model.bones.size} ossos · ${ed.model.vertexCount} vértices" else "importe um modelo", 0,
                        if (ed != null) "model" !in hidden else null, renderOff = "model" in outl.renderOff)
                    props.forEach { base["prop:" + it.id] = Layer("prop:" + it.id, it.name, Icons.Default.Category, if (it.bone.isNotEmpty()) "preso: " + it.bone else "solto", 0,
                        "prop:" + it.id !in hidden, locked = outl.isLocked("prop:" + it.id), renderOff = "prop:" + it.id in outl.renderOff) }
                    cast.forEach { base["char:" + it.id] = Layer("char:" + it.id, it.name, Icons.Default.Person, if (it.motion.isEmpty()) "extra · parado" else "extra · " + it.motion, 0,
                        "char:" + it.id !in hidden, locked = outl.isLocked("char:" + it.id), renderOff = "char:" + it.id in outl.renderOff) }
                    base["light"] = Layer("light", "Luz", Icons.Default.LightMode, "%.0f%%".format(lightCfg.intensity * 100), 0, null)
                    base["camera"] = Layer("camera", "Câmera", Icons.Default.Videocam, if (camMotion != null) (if (camOn) "VMD ligada" else "VMD desligada") else "livre", 0, null)
                    base["audio"] = Layer("audio", "Áudio", Icons.Default.MusicNote, audioName ?: "vazio", 0, null)
                    val naturalKeys = base.keys.toList()
                    // v1.29.8 (8.4b): a hierarquia vem do Scene Graph; acessório preso a osso aparece recuado (filho do modelo)
                    val attachedKeys = SceneHierarchy.attachedKeys(SceneHierarchy.build(ed?.model?.name ?: "", ed != null, props, cast, outl))
                    val layers = buildList {
                        for (r in outl.arrange(naturalKeys)) {
                            if (r.group) {
                                val g = outl.group(r.key) ?: continue
                                val mem = g.members.filter { it in base }
                                val lk = mem.filter { OutlinerState.lockable(it) }
                                add(Layer(g.id, g.name, Icons.Default.Folder, "${mem.size} itens", 0, mem.any { it !in hidden }, group = true, collapsed = g.collapsed,
                                    locked = lk.isNotEmpty() && lk.all { outl.isLocked(it) }, renderOff = mem.isNotEmpty() && mem.all { it in outl.renderOff }))
                            } else {
                                val l = base[r.key] ?: continue
                                add(Layer(l.key, l.name, l.icon, l.sub, r.indent + (if (l.key in attachedKeys) 1 else 0), l.visible, locked = l.locked, renderOff = l.renderOff))
                            }
                        }
                    }
                    val actions = OutlinerActions(
                        onRename = { k, n ->
                            if (n.isNotBlank()) { recordOutl(); when {
                                k.startsWith("prop:") -> { props = props.map { if ("prop:" + it.id == k) it.copy(name = n.trim()) else it }; ProjectStore.saveProps(ctx, project.id, props) }
                                k.startsWith("char:") -> { cast = cast.map { if ("char:" + it.id == k) it.copy(name = n.trim()) else it }; persistCast() }
                                else -> { outl = outl.rename(k, n); persistOutl() }
                            } }
                        },
                        onMove = { k, d -> recordOutl(); outl = outl.move(k, d, naturalKeys); persistOutl() },
                        onLock = { k ->
                            recordOutl()
                            val g = outl.group(k)
                            if (g != null) {
                                val ms = g.members.filter { OutlinerState.lockable(it) }
                                val all = ms.isNotEmpty() && ms.all { outl.isLocked(it) }
                                for (m in ms) if (outl.isLocked(m) == all) outl = outl.toggleLock(m)
                            } else outl = outl.toggleLock(k)
                            persistOutl()
                        },
                        onRenderOff = { k ->
                            recordOutl()
                            val g = outl.group(k)
                            if (g != null) {
                                val all = g.members.isNotEmpty() && g.members.all { it in outl.renderOff }
                                for (m in g.members) if ((m in outl.renderOff) == all) outl = outl.toggleRenderOff(m)
                            } else outl = outl.toggleRenderOff(k)
                            persistOutl()
                        },
                        onNewGroup = { k ->
                            recordOutl()
                            outl = outl.makeGroup(listOf(k), java.util.UUID.randomUUID().toString().take(8), "Grupo ${outl.groups.size + 1}")
                            outl.groupOf(k)?.let { layerSel = it.id }
                            persistOutl()
                        },
                        onGroupMany = { ks ->
                            recordOutl()
                            val gid = java.util.UUID.randomUUID().toString().take(8)
                            outl = outl.makeGroup(ks, gid, "Grupo ${outl.groups.size + 1}")
                            outl.groupOf(ks.firstOrNull { OutlinerState.groupable(it) } ?: "")?.let { layerSel = it.id }
                            persistOutl()
                        },
                        onAddToGroup = { k, gid -> recordOutl(); outl = outl.addToGroup(k, gid); persistOutl() },
                        onRemoveFromGroup = { k -> recordOutl(); outl = outl.removeFromGroup(k); persistOutl() },
                        onUngroup = { gid -> recordOutl(); outl = outl.ungroup(gid); layerSel = "model"; persistOutl() },
                        onDuplicate = { k -> duplicateLayer(k) },
                        onDelete = { k ->
                            when {
                                k.startsWith("char:") -> removeCastAt(cast.indexOfFirst { "char:" + it.id == k })
                                k.startsWith("prop:") -> removePropAt(props.indexOfFirst { "prop:" + it.id == k })
                            }
                        },
                        onCollapse = { gid -> outl = outl.toggleCollapse(gid); persistOutl() },
                        canUndo = outlHistTick >= 0 && outlHist.canUndo, canRedo = outlHistTick >= 0 && outlHist.canRedo,
                        onUndo = { outlHist.undo(outlSnap())?.let { restoreOutl(it); note("Desfeito") } },
                        onRedo = { outlHist.redo(outlSnap())?.let { restoreOutl(it); note("Refeito") } })
                    LayersPanel(layers, layerSel, outl.groups.map { it.id to it.name }, actions, { k ->
                        layerSel = k
                        when {
                            OutlinerState.isGroup(k) -> {}
                            k == "model" -> openPanel("anim")
                            k == "light" -> openPanel("light")
                            k == "camera" -> openPanel("cam")
                            k == "audio" -> openPanel("audio")
                            k.startsWith("char:") -> { openPanel("cast"); selCast = cast.indexOfFirst { "char:" + it.id == k } }
                            k.startsWith("prop:") -> { openPanel("scene"); selProp = props.indexOfFirst { "prop:" + it.id == k } }
                        }
                    }, { k ->
                        if (OutlinerState.isGroup(k)) {
                            val ms = outl.group(k)?.members ?: emptyList()
                            hidden = if (ms.any { it !in hidden }) hidden + ms else hidden - ms.toSet()
                        } else hidden = if (k in hidden) hidden - k else hidden + k
                    }, Modifier.align(Alignment.CenterEnd).padding(6.dp).width(208.dp).heightIn(max = 300.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                ModeChip("Animação", !skeleton && !scenePanel && !castPanel && !cartoonPanel && !audioPanel && !lightPanel && !camPanel) { openPanel("anim"); layerSel = "model" }
                ModeChip("Esqueleto", skeleton) { if (ed == null) note("Importe um modelo antes") else { openPanel("skel"); layerSel = "model" } }
                ModeChip("Cena", scenePanel) { openPanel("scene") }
                ModeChip("Elenco", castPanel) { openPanel("cast") }
                ModeChip("Cartoon", cartoonPanel) { openPanel("cartoon") }
                ModeChip("Luz", lightPanel) { openPanel("light"); layerSel = "light" }
                ModeChip("Câmera", camPanel) { openPanel("cam"); layerSel = "camera" }
                ModeChip("Áudio", audioPanel) { openPanel("audio"); layerSel = "audio" }
                }
                Text("%d / %d".format(frame, total - 1), color = Muted, fontSize = 11.sp)
            }
            if (lightPanel) LightPanel(lightCfg, { lightCfg = it }, Modifier.fillMaxWidth().height(300.dp).padding(horizontal = 8.dp), lookCfg, { lookCfg = it })
            if (camPanel) CameraPanel(camMotion != null, camOn, camFlip, { camOn = !camOn }, { camFlip = !camFlip },
                { camMotion = null; ProjectStore.fileWith(ctx, project.id, "camera")?.delete(); note("Câmera removida") },
                { gl.applyPreset(it) }, { gl.frameAll() }, Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 8.dp))
            if (audioPanel) {
                AudioPanel(audioName, try { audio?.duration ?: 0 } catch (e: Throwable) { 0 }, audioVol, audioOff,
                    { picker.launch(arrayOf("audio/*")) },
                    { audioVol = it }, { audioOff = it },
                    {
                        playing = false; audio?.release(); audio = null; audioName = null
                        ProjectStore.deleteAudio(ctx, project.id); note("Áudio removido")
                    },
                    { saveAudio() },
                    Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 8.dp))
            }
            if (castPanel) {
                CastPanel(cast, selCast, { selCast = it },
                    { castPicker.launch(arrayOf("*/*")) },
                    { i -> removeCastAt(i) },
                    { i -> cast.getOrNull(i)?.let { if (outl.isLocked("char:" + it.id)) note("'${it.name}' está bloqueado") else { castMotionFor = it.id; castMotionPicker.launch(arrayOf("*/*")) } } },
                    { i ->
                        cast.getOrNull(i)?.takeIf { !outl.isLocked("char:" + it.id) }?.let { cm ->
                            ProjectStore.castMotionFile(ctx, project.id, cm.id).delete(); dropSession(cm.id); gl.setCharacterMotion(cm.id, null)
                            cast = cast.mapIndexed { k, o -> if (k == i) o.copy(motion = "") else o }
                            persistCast()
                        }
                    },
                    { i, cm -> if (outl.isLocked("char:" + cm.id)) note("'${cm.name}' está bloqueado no Outliner") else { cast = cast.mapIndexed { k, o -> if (k == i) cm else o }; gl.setCharacter(cm.id, cm.x, cm.y, cm.z, cm.ry, cm.s) } },
                    { persistCast() },
                    { i -> castSavePose(i) }, { i, pi -> castApplyPose(i, pi) },
                    { i -> if (castUndoTick >= 0) castUndo.lastOrNull { it.id == cast.getOrNull(i)?.id }?.itemName else null },
                    { i -> cast.getOrNull(i)?.let { undoExtra(it.id) } },
                    activeCastId = actId, onEdit = { i -> cast.getOrNull(i)?.let { cm -> if (outl.isLocked("char:" + cm.id)) note("'${cm.name}' está bloqueado no Outliner") else { activeId = cm.id; selBone = -1; selMorph = -1; openPanel("skel"); note("Editando: ${cm.name}") } } },
                    onEditMain = { activeId = studio.mmd.scene.ActiveCharacter.MAIN; selBone = -1; selMorph = -1; note("Editando: personagem principal") },
                    Modifier.fillMaxWidth().height(300.dp).padding(horizontal = 8.dp))
            }
            if (cartoonPanel) {
                val cm = ed?.model
                val tgtCast = cast.firstOrNull { it.id == cartoonTarget }          // null = personagem principal
                val tgtIdx = if (tgtCast == null) 0 else cast.indexOf(tgtCast) + 1
                val undoItem = if (castUndoTick >= 0 && tgtCast != null) castUndo.lastOrNull { it.id == tgtCast.id } else null
                CartoonPanel(if (tgtCast != null) true else cm != null,
                    if (tgtCast != null) (castBones[tgtCast.id] ?: emptySet()) else cm?.bones?.map { it.name }?.toHashSet() ?: emptySet(),
                    if (tgtCast != null) (castMorphs[tgtCast.id] ?: emptySet()) else cm?.morphs?.map { it.name }?.toHashSet() ?: emptySet(),
                    frame, cartoonPreviewId,
                    { id, b, lp -> cartoonPreviewLoop = lp; cartoonPreviewTarget = tgtCast?.id ?: ""; cartoonPreviewId = id; cartoonPreview = b.toMotion((if (tgtCast != null) castModels[tgtCast.id] else cm)?.let { studio.mmd.cartoon.ikBonesDriving(it, b.bones.keys) } ?: emptyList()) },
                    { cartoonPreview = null; cartoonPreviewId = null },
                    { item: CartoonItem, b: Built ->
                        if (tgtCast != null) applyCartoonToExtra(item, b)
                        else {
                            val e = editor
                            if (e == null) note("Importe um modelo antes")
                            else {
                                cartoonPreview = null; cartoonPreviewId = null; playing = false
                                val n = e.applyKeys(b.bones, b.morphs, b.first, b.last)
                                total = maxOf(total, b.last + 1)
                                isError = false
                                status = "Cartoon: \"${item.name}\" aplicada: $n keys, quadros ${b.first}–${b.last} (%.1fs). Desfazer descarta tudo de uma vez.".format((b.last - b.first + 1) / FPS.toFloat())
                            }
                        }
                    },
                    { c -> cartoonImportCat = c; cartoonPicker.launch(arrayOf("*/*")) },
                    listOf("Principal") + cast.map { it.name }, tgtIdx,
                    { i -> cartoonPreview = null; cartoonPreviewId = null; cartoonTarget = if (i <= 0) "" else cast.getOrNull(i - 1)?.id ?: "" },
                    undoItem?.itemName, { undoCartoonExtra() },
                    Modifier.fillMaxWidth().height(380.dp).padding(horizontal = 8.dp))
            }
            if (scenePanel) {
                ScenePanel(props, selProp, { selProp = it }, ed?.model?.bones?.map { it.name } ?: emptyList(),
                    { propPicker.launch(arrayOf("*/*")) },
                    { i -> removePropAt(i) },
                    { i, pm -> if (outl.isLocked("prop:" + pm.id)) note("'${pm.name}' está bloqueado no Outliner") else { props = props.mapIndexed { k, o -> if (k == i) pm else o }; gl.setProp(pm.id, pm.x, pm.y, pm.z, pm.s, pm.bone, pm.rx, pm.ry, pm.rz) } },
                    { ProjectStore.saveProps(ctx, project.id, props) },
                    Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 8.dp))
            }
            if (skeleton && ae != null) {
                SkeletonPanel(ae, frame, tab, { tab = it }, selBone, { selBone = it }, selMorph, { selMorph = it }, { note(it) }, { frame = it }, rig, { rig = it }, sec, { sec = it }, phys, { phys = it }, { bakeSecondary() }, baking, bonesShown, { bonesShown = it }, { last -> total = maxOf(total, last + 1) },
                    Modifier.fillMaxWidth().height(if (tab == 6) 340.dp else if (tab >= 3) 270.dp else 230.dp).padding(horizontal = 8.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.clickable { playing = !playing }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame - 1).coerceAtLeast(0) }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipNext, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame + 1).coerceAtMost(total - 1) }.padding(8.dp).size(22.dp))
                Spacer(Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.Undo, null, tint = if (ae?.canUndo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ae?.undo() != true) note("Nada para desfazer") }.padding(8.dp).size(22.dp))
                Icon(Icons.AutoMirrored.Filled.Redo, null, tint = if (ae?.canRedo == true) Color.White else Color(0xFF4A4C52),
                    modifier = Modifier.clickable { if (ae?.redo() != true) note("Nada para refazer") }.padding(8.dp).size(22.dp))
                KeyButton(hasKey, selName != null) {
                    if (ae == null) note("Importe um modelo antes")
                    else if (selName == null) note("Selecione um osso (modo Esqueleto)")
                    else if (actId != studio.mmd.scene.ActiveCharacter.MAIN && outl.isLocked("char:" + actId)) note("Personagem bloqueado no Outliner")
                    else if (hasKey) { ae.deleteKeys(listOf(selName), frame); note("Keyframe removido") }
                    else { ae.keyBones(listOf(selName), frame); note("Keyframe inserido") }
                }
                Text("+1s", color = Muted, fontSize = 12.sp, modifier = Modifier.clickable { total += FPS }.padding(8.dp))
            }
            Timeline(frame, total, keys, Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp, vertical = 4.dp)) { frame = it }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(3.dp).size(34.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Accent else Color.Transparent).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean, onClick: () -> Unit) {
    Text(text, color = if (active) Color.White else Muted, fontSize = 12.sp,
        modifier = Modifier.padding(end = 6.dp).clip(RoundedCornerShape(14.dp))
            .background(if (active) Accent else Panel).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 5.dp))
}

/** Losango de keyframe: cheio = o osso selecionado já tem key neste quadro. */
@Composable
private fun KeyButton(active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Canvas(Modifier.clickable { onClick() }.padding(8.dp).size(22.dp)) {
        val c = center; val r = size.minDimension / 2f * 0.85f
        val p = Path().apply { moveTo(c.x, c.y - r); lineTo(c.x + r, c.y); lineTo(c.x, c.y + r); lineTo(c.x - r, c.y); close() }
        val col = if (enabled) Accent else Muted
        if (active) drawPath(p, col) else drawPath(p, col, style = Stroke(width = 3f))
    }
}

/** Régua de frames com playhead arrastável (um traço por segundo) e losangos nos keyframes. */
@Composable
private fun Timeline(frame: Int, total: Int, keys: IntArray, modifier: Modifier, onSeek: (Int) -> Unit) {
    val last = (total - 1).coerceAtLeast(1)
    Canvas(modifier.background(Color(0xFF101114)).pointerInput(total) {
        detectTapGestures { onSeek((it.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }.pointerInput(total) {
        detectDragGestures { c, _ -> onSeek((c.position.x / size.width * last).toInt().coerceIn(0, total - 1)) }
    }) {
        val secs = (last / FPS).coerceAtLeast(1)
        val step = size.width * FPS / last
        for (s in 0..secs) drawLine(Color(0xFF3A3C42), Offset(s * step, 0f), Offset(s * step, 28f), 2f)
        val cy = size.height * 0.6f; val r = 7f
        val diamonds = keys.size <= 800
        for (k in keys) {
            if (k > last) continue
            val kx = k.toFloat() / last * size.width
            if (diamonds) {
                val p = Path().apply { moveTo(kx, cy - r); lineTo(kx + r, cy); lineTo(kx, cy + r); lineTo(kx - r, cy); close() }
                drawPath(p, Color(0xFFFFC857))
            } else drawLine(Color(0xFFFFC857), Offset(kx, cy - r), Offset(kx, cy + r), 2f)
        }
        val x = frame.toFloat() / last * size.width
        drawLine(Accent, Offset(x, 0f), Offset(x, size.height), 3f)
    }
}

/** OutputStream que conta os bytes gravados. */
private class CountOut(private val o: OutputStream) : OutputStream() {
    var count = 0L
    override fun write(b: Int) { o.write(b); count++ }
    override fun write(b: ByteArray, off: Int, len: Int) { o.write(b, off, len); count += len }
    override fun flush() { o.flush() }
    override fun close() { o.close() }
}
