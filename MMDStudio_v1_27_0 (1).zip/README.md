# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 3 (shaders GLSL ES 3.00). Sem WebView/PWA.

## Status
v1.27.0: Release 8, fatia 8.3c (P0) — ELENCO: personagens extras animados na cena. Novo chip "Elenco" (+ Personagem: .pmx/.pmd/.glb/.gltf/.zip), cada um com `CharacterInstance`+`Animator`+`RigConfig` próprios, movimento próprio (.vmd, ou a 1ª animação do GLB), posição/giro/escala e visibilidade (Layers), todos no mesmo relógio da timeline; salvo em `cast.json` + `cast/` e reaberto com o projeto. Renderer: `addCharacter/removeCharacter/setCharacter/setCharacterMotion`, `buildChar/freeChar`. Testes JVM `CastTest` (5/5). NÃO compilada no Android.
v1.26.0: Release 8, fatia 8.3b (P0) — `RigConfig` (restrições, ação secundária, física e cache) agora é por personagem; `Animator` lê de `animator.rig`; `RigState` virou atalho para a configuração principal (comportamento idêntico). NÃO compilada.
v1.25.0: Release 8, fatia 8.3a (P0) — desenho, skinning GPU e sombra agora recebem a `CharacterInstance` por parâmetro (`updateSkin(ch)`, `drawModel(..., ch)`, laço `chars`); `lastFrame` virou campo da instância. Comportamento IDÊNTICO (ainda 1 personagem). NÃO compilada.
v1.24.2: correção visual no painel Luz/Aparência (rótulos quebravam em 2 linhas: "Saturaçã/o", "Suavidad/e"; valor encostava no slider). Visto em print do aparelho (19:42).
v1.24.1: correção de build — `SceneGLView.kt:590` usava `shBone` sem o prefixo `mainChar.` (resquício da extração do CharacterInstance na v1.19.0).
v1.24.0: P0 (nota de prioridades) — trocar a animação do GLB agora é um passo de DESFAZER (`Editor.replaceUndoable`); roadmap principal ganhou marcadores P0–P3, seção 12 e auditoria P0 (nada novo foi compilado).
v1.23.0: Release 9 (fatia 4) — GLB/glTF com várias animações: menu do viewport > "Animações do arquivo…" lista os clips e escolher um converte e substitui as keys do editor (abre sozinho ao importar se houver mais de uma). NÃO compilada.
v1.22.0: Release 9 (fatia 3) — `GltfToMotion` converte o clip glTF em keyframes do Editor; importar GLB animado já usa a 1ª animação (conversor com testes JVM).
v1.21.0: Release 9 (fatia 2) — `GlbParser` lê as animações do glTF (testes JVM).
v1.20.0: Release 9 (fatia 1) — `GltfSampler` (STEP/LINEAR/CUBICSPLINE, testes JVM).
v1.19.0: Release 8 (fatia 2) — CharacterInstance extraído do SceneRenderer (ainda 1 personagem; refatoração sem mudança de comportamento). Estado GL + Animator de um personagem agora vive em uma classe interna; prepara a fatia 8.3 (vários personagens).
v1.18.0: Release 8 (fatia 1) — Scene Graph em Kotlin puro (`scene/SceneGraph.kt`, `SceneSerializer.kt`): nós hierárquicos, instâncias, duplicar/agrupar/reordenar, ciclo recusado, `scenegraph.json` com migração do projeto v1 (`ProjectStore.loadOrMigrateScene`); testes JVM. AINDA não ligado à UI nem ao renderer.
v1.17.0: Release 7 (fatia 1) — painel Luz ganha "Aparência": exposição, contraste, saturação, luz de borda e, no modo MMD, suavidade do toon e força da sombra (salvo no aparelho).
v1.16.0: Release 5 (fatia 2) — Dope Sheet visual na aba Keys (grade trilha × quadro, zoom por pinça, rolagem, seleção e arrasto de keys individuais, resumo, copiar/colar/apagar, com desfazer); testes.
v1.15.0: Release 5 (fatia 1) — aba Keys no modo Esqueleto: mover, copiar/colar, apagar e retiming de keyframes por trecho de quadros, com desfazer; testes.
v1.14.0: importa modelos .glb/.gltf/.obj (soltos ou em .zip) como modelo/cenário (esqueleto, pesos, texturas; animações do arquivo ainda não); física com passo fixo de 1/240 s e cache (bake) determinístico na aba Física. FBX, debug visual da física e cache no projeto seguem pendentes.
v1.13.0: Release 4 (fatia 1) — VMD: IK ligado/desligado aplicado na animação; luz e self-shadow lidos e preservados na importação/exportação; testes.
v1.12.3: morphs de UV (tipo 3) aplicados no render, com testes.
v1.12.2: QDEF (dual quaternion) no shader, com referência em CPU e testes.
v1.12.1: morphs de material (cor, brilho, ambiente, borda; esconder materiais) no render, com testes.
v1.12.0: Release 3 (fatia 2) — SDEF real no shader (`Sdef.kt` de referência + testes); a textura de ossos ganhou o quaternion global de cada osso. QDEF, GLB/FBX com SDEF e morphs UV/material seguem pendentes.
v1.10.0: Release 2 — escritor PMX (`PmxWriter`): exporta o modelo em PMX 2.0/2.1 com os dados preservados do importador (SDEF, UVs extras, morphs de UV/material/impulso, frames de exibição, física, soft bodies em bytes brutos), com testes de ida e volta byte a byte. Menu de exportação → "Exportar modelo (.pmx)" (converte PMD/.x em PMX).
v1.9.1: fundação do roadmap (Release 1) — importador PMX/VMD com avisos em vez de descarte silencioso, dados do PMX preservados (comentários, UVs extras, SDEF, eixos, frames de exibição, morphs UV/material/impulso), versão no formato do projeto, limites em zips, logger e testes JVM de parser.
v1.9.0: ocultar ossos e animação por texto (IA). v1.8.0: importar projeto .zip, modo MMD (toon, esfera, contorno, sombra), câmera no VMD.
Recursos: PMX/PMD/X/GLB/glTF/OBJ/VMD, esqueleto FK + IK + append, skinning na GPU, morphs, timeline com keyframes e curvas Bézier, física própria, Action Constraints, mocap por vídeo, cena com acessórios, áudio, exportação VMD/VPD/FBX/GLB/MP4/PNG.
Veja `MMD-Studio-Contexto.md` (histórico, estado real, auditoria e roadmap em `docs/`).

## Compilar e testar
- Android Studio: abrir a pasta e rodar `app`.
- Testes de parser: `gradle testDebugUnitTest` (JUnit, sem aparelho).
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
