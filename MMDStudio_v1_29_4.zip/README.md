# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 3 (shaders GLSL ES 3.00). Sem WebView/PWA.

## Status
v1.29.4: correção do build (build.gradle.kts: `java.util.Properties` dentro de `android {}` não resolvia; agora `import java.util.Properties`). Erro visto no Actions; veio da v1.28.2.
v1.29.3: OUTLINER — seleção múltipla: "☐ Vários" no cabeçalho de Layers, toque nos itens (modelo/objetos/personagens) e "Agrupar" cria um grupo só com todos (um passo de desfazer). Usa `OutlinerState.makeGroup` (já aceitava lista). NÃO compilada.
v1.29.2: CARTOON EM PERSONAGENS EXTRAS (Elenco) — no painel Cartoon, "Aplicar em: Principal / <extra>"; prévia e Aplicar funcionam no extra escolhido (o movimento do Cartoon é mesclado no .vmd do extra só entre o quadro inicial e o final; o resto fica) e "Desfazer no extra" volta ao movimento anterior. Lógica pura nova `cartoon/CartoonMerge.kt` + `CartoonMergeTest` (7 testes) — EXECUTADOS em JVM junto com `CartoonTest` (21/21 OK). UI (`SceneScreen`, `CartoonPanel`) NÃO compilada no Android.
v1.29.1: fatia 8.4b-1 — DESFAZER/REFAZER no Outliner (renomear, mover, bloquear, visível no render, grupos; até 50 passos; excluir/duplicar não são desfeitos por mexerem em arquivos). Classe `History` + teste. NÃO compilada.
v1.29.0: Release 8, fatia 8.4a (P0) — OUTLINER FUNCIONAL sobre o que já existe (modelo, acessórios, personagens extras): renomear, mover para cima/baixo, bloquear (impede mover/excluir/trocar movimento), "visível no render" (some só no PNG/vídeo/sequência), grupos (criar, adicionar, tirar, desagrupar, recolher, ocultar/bloquear em bloco), duplicar e excluir (com confirmação). Salvo em `outliner.json` e restaurado ao reabrir; excluir limpa nome/bloqueio/grupo/ordem do objeto. Novo `scene/OutlinerState.kt` + `OutlinerStateTest` (8 testes, NÃO executados). O `SceneGraph` da v1.18 AINDA não é usado pela UI. Sem Undo/Redo no Outliner. NÃO compilada.
v1.28.2: segurança e documentação (sem mudança de funcionalidade) — senhas da assinatura removidas do `build.gradle.kts` (agora `MMD_KEYSTORE_FILE/PASSWORD`, `MMD_KEY_ALIAS`, `MMD_KEY_PASSWORD` ou `keystore.properties` local); `mmdstudio.jks` retirado do zip; `.gitignore` e `CHANGELOG.md` criados. A chave NÃO foi trocada: guarde o `.jks` em local seguro. NÃO compilada.
v1.27.0: Release 8, fatia 8.3c (P0) — ELENCO: personagens extras animados na cena. Novo chip "Elenco" (+ Personagem: .pmx/.pmd/.glb/.gltf/.zip), cada um com `CharacterInstance`+`Animator`+`RigConfig` próprios, movimento próprio (.vmd, ou a 1ª animação do GLB), posição/giro/escala e visibilidade (Layers), todos no mesmo relógio da timeline; salvo em `cast.json` + `cast/` e reaberto com o projeto. Renderer: `addCharacter/removeCharacter/setCharacter/setCharacterMotion`, `buildChar/freeChar`. Testes JVM `CastTest` (5/5). NÃO compilada no Android.
v1.26.0: Release 8, fatia 8.3b (P0) — `RigConfig` (restrições, ação secundária, física e cache) agora é por personagem; `Animator` lê de `animator.rig`; `RigState` virou atalho para a configuração principal (comportamento idêntico). NÃO compilada.
v1.25.0: Release 8, fatia 8.3a (P0) — desenho, skinning GPU e sombra agora recebem a `CharacterInstance` por parâmetro (`updateSkin(ch)`, `drawModel(..., ch)`, laço `chars`); `lastFrame` virou campo da instância. Comportamento IDÊNTICO (ainda 1 personagem). NÃO compilada.
v1.24.2: correção visual no painel Luz/Aparência (rótulos quebravam em 2 linhas: "Saturaçã/o", "Suavidad/e"; valor encostava no slider). Visto em print do aparelho (19:42).
v1.24.1: correção de build — `SceneGLView.kt:590` usava `shBone` sem o prefixo `mainChar.` (resquício da extração do CharacterInstance na v1.19.0).
v1.24.0: P0 (nota de prioridades) — trocar a animação do GLB agora é um passo de DESFAZER (`Editor.replaceUndoable`); roadmap principal ganhou marcadores P0–P3, seção 12 e auditoria P0 (nada novo foi compilado).
v1.23.0: Release 9 (fatia 4) — GLB/glTF com várias animações: menu do viewport > "Animações do arquivo…" lista os clips e escolher um converte e substitui as keys do editor (abre sozinho ao importar se houver mais de uma). NÃO compilada.
v1.22.0: Release 9 (fatia 3) — `GltfToMotion` converte o clip glTF em keyframes do Editor; importar GLB animado já usa a 1ª animação (conversor com testes JVM).
v1.21.0: Release 9 (fatia 2) — `GlbParser` lê as animações do glTF (testes JVM).
v1.20.0: Release 9 (fatia 1) — `GltfSampler` (STEP/LINEAR/CUBICSPLINE, testes JVM).
v1.19.0: Release 8 (fatia 2) — CharacterInstance extraído do SceneRenderer (ainda 1 personagem; refatoração sem mudança de comportamento). Estado GL + Animator de um personagem agora vive em uma classe interna; prepara a fatia 8.3 (vários personagens).
v1.18.0: Release 8 (fatia 1) — Scene Graph em Kotlin puro (`scene/SceneGraph.kt`, `SceneSerializer.kt`): nós hierárquicos, instâncias, duplicar/agrupar/reordenar, ciclo recusado, `scenegraph.json` com migração do projeto v1 (`ProjectStore.loadOrMigrateScene`); testes JVM. AINDA não ligado à UI nem ao renderer.
v1.17.0: Release 7 (fatia 1) — painel Luz ganha "Aparência": exposição, contraste, saturação, luz de borda e, no modo MMD, suavidade do toon e força da sombra (salvo no aparelho).
v1.16.0: Release 5 (fatia 2) — Dope Sheet visual na aba Keys (grade trilha × quadro, zoom por pinça, rolagem, seleção e arrasto de keys individuais, resumo, copiar/colar/apagar, com desfazer); testes.
v1.15.0: Release 5 (fatia 1) — aba Keys no modo Esqueleto: mover, copiar/colar, apagar e retiming de keyframes por trecho de quadros, com desfazer; testes.
v1.14.0: importa modelos .glb/.gltf/.obj (soltos ou em .zip) como modelo/cenário (esqueleto, pesos, texturas; animações do arquivo ainda não); física com passo fixo de 1/240 s e cache (bake) determinístico na aba Física. FBX, debug visual da física e cache no projeto seguem pendentes.
v1.13.0: Release 4 (fatia 1) — VMD: IK ligado/desligado aplicado na animação; luz e self-shadow lidos e preservados na importação/exportação; testes.
v1.12.3: morphs de UV (tipo 3) aplicados no render, com testes.
v1.12.2: QDEF (dual quaternion) no shader, com referência em CPU e testes.
v1.12.1: morphs de material (cor, brilho, ambiente, borda; esconder materiais) no render, com testes.
v1.12.0: Release 3 (fatia 2) — SDEF real no shader (`Sdef.kt` de referência + testes); a textura de ossos ganhou o quaternion global de cada osso. QDEF, GLB/FBX com SDEF e morphs UV/material seguem pendentes.
v1.10.0: Release 2 — escritor PMX (`PmxWriter`): exporta o modelo em PMX 2.0/2.1 com os dados preservados do importador (SDEF, UVs extras, morphs de UV/material/impulso, frames de exibição, física, soft bodies em bytes brutos), com testes de ida e volta byte a byte. Menu de exportação → "Exportar modelo (.pmx)" (converte PMD/.x em PMX).
v1.9.1: fundação do roadmap (Release 1) — importador PMX/VMD com avisos em vez de descarte silencioso, dados do PMX preservados (comentários, UVs extras, SDEF, eixos, frames de exibição, morphs UV/material/impulso), versão no formato do projeto, limites em zips, logger e testes JVM de parser.
v1.9.0: ocultar ossos e animação por texto (IA). v1.8.0: importar projeto .zip, modo MMD (toon, esfera, contorno, sombra), câmera no VMD.
Recursos: PMX/PMD/X/GLB/glTF/OBJ/VMD, esqueleto FK + IK + append, skinning na GPU, morphs, timeline com keyframes e curvas Bézier, física própria, Action Constraints, mocap por vídeo, cena com acessórios, áudio, exportação VMD/VPD/FBX/GLB/MP4/PNG.
Veja `MMD-Studio-Contexto.md` (histórico, estado real, auditoria e roadmap em `docs/`).

## Compilar e testar
- Android Studio: abrir a pasta e rodar `app`.
- Testes de parser: `gradle testDebugUnitTest` (JUnit, sem aparelho).
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).

## Cartoon Motion Library (v1.28.0)
Chip **Cartoon** na tela da cena: 30 movimentos originais em 8 categorias, prévia, aplicar com desfazer, importação de .vmd, velocidade/intensidade/loop/trecho/suavização e combinação por grupos de ossos. Squash & Stretch (P4) ainda não. Detalhes e roteiro de teste: `docs/MMD_Studio_Roadmap_Master_Production_Claude.md` (seção no fim).

## Assinatura do APK (v1.28.2)
O workflow gera `assembleDebug` (chave debug). Para build release: defina as variáveis `MMD_KEYSTORE_FILE` (caminho do .jks), `MMD_KEYSTORE_PASSWORD`, `MMD_KEY_ALIAS`, `MMD_KEY_PASSWORD` (no GitHub: Secrets; o .jks em base64 decodificado no workflow) ou crie `keystore.properties` na raiz com `storeFile`, `storePassword`, `keyAlias`, `keyPassword`. Nunca envie `.jks`/senhas ao repositório.
