package studio.mmd.rig

import org.json.JSONArray
import org.json.JSONObject

/** Tipos de restrição (Action Constraints). */
object CType {
    const val LIMIT_ROT = 0   // limita a rotação do osso (graus por eixo, ordem Y·X·Z do MMD)
    const val LIMIT_POS = 1   // limita a posição (unidades MMD por eixo)
    const val LOOK_AT = 2     // o eixo escolhido do osso aponta para outro osso
    const val COPY_ROT = 3    // copia a rotação local de outro osso
    const val COPY_POS = 4    // copia a posição local de outro osso
    val names = listOf("Limitar rotação", "Limitar posição", "Olhar para", "Copiar rotação", "Copiar posição")
}

/** Eixos do "Olhar para": 0 +X, 1 −X, 2 +Y, 3 −Y, 4 +Z, 5 −Z (no MMD a frente do modelo é −Z). */
val AXIS_NAMES = listOf("+X", "−X", "+Y", "−Y", "+Z", "−Z")

/** Uma restrição ligada a um osso (por nome). Imutável: troca-se o objeto com copy(). */
data class Constraint(
    val id: String,
    val bone: String,
    val type: Int,
    val enabled: Boolean = true,
    val target: String = "",
    val axis: Int = 5,
    val weight: Float = 1f,
    val min: List<Float> = listOf(-180f, -180f, -180f),
    val max: List<Float> = listOf(180f, 180f, 180f)
)

/** Lista de restrições em uso pelo projeto aberto. O Animator (prévia e exportações) lê daqui. */
object RigState {
    @Volatile var list: List<Constraint> = emptyList()
    @Volatile var secondary: List<Secondary> = emptyList()
    @Volatile var phys: PhysConfig = PhysConfig()
}

object RigIo {
    fun toJson(l: List<Constraint>): String {
        val a = JSONArray()
        l.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("bone", c.bone).put("type", c.type).put("on", c.enabled)
                .put("target", c.target).put("axis", c.axis).put("w", c.weight.toDouble())
                .put("min", JSONArray(c.min.map { it.toDouble() })).put("max", JSONArray(c.max.map { it.toDouble() })))
        }
        return a.toString()
    }

    fun fromJson(s: String): List<Constraint> = try {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val j = a.getJSONObject(i)
            fun f3(k: String, d: Float): List<Float> {
                val x = j.optJSONArray(k) ?: return listOf(d, d, d)
                return (0..2).map { x.optDouble(it, d.toDouble()).toFloat() }
            }
            Constraint(j.getString("id"), j.getString("bone"), j.getInt("type"), j.optBoolean("on", true),
                j.optString("target", ""), j.optInt("axis", 5), j.optDouble("w", 1.0).toFloat(), f3("min", -180f), f3("max", 180f))
        }
    } catch (e: Exception) { emptyList() }
}

/** Grupo de movimento secundário automático (mola/amortecimento sobre rotações de ossos). */
data class Secondary(
    val id: String,
    val name: String,
    val bones: List<String>,
    val enabled: Boolean = true,
    val preset: Int = 0,
    val intensity: Float = 0.8f,   // 0 = sem efeito, 1 = só o osso "atrasado"
    val stiffness: Float = 150f,   // rigidez da mola (maior = volta mais rápido)
    val damping: Float = 0.35f,    // razão de amortecimento (0,3 balança muito; 1 = sem balanço)
    val delay: Float = 0.3f        // 0..1: ossos mais longe da raiz da cadeia ficam mais "moles" (efeito chicote)
)

object SecPreset {
    val names = listOf("Cabelo", "Saia/roupa", "Acessório", "Corpo", "Cabeça", "Peito", "Cauda/orelha")
    /** intensidade, rigidez, amortecimento, atraso */
    private val p = listOf(
        floatArrayOf(0.85f, 150f, 0.35f, 0.30f),
        floatArrayOf(0.80f, 100f, 0.50f, 0.20f),
        floatArrayOf(1.00f, 200f, 0.25f, 0.25f),
        floatArrayOf(0.50f, 250f, 0.60f, 0.10f),
        floatArrayOf(0.40f, 300f, 0.70f, 0.00f),
        floatArrayOf(0.90f, 220f, 0.25f, 0.10f),
        floatArrayOf(1.00f, 120f, 0.30f, 0.40f)
    )
    fun apply(g: Secondary, i: Int): Secondary { val v = p[i]; return g.copy(preset = i, intensity = v[0], stiffness = v[1], damping = v[2], delay = v[3]) }
}

object SecIo {
    fun toJson(l: List<Secondary>): String {
        val a = JSONArray()
        l.forEach { g ->
            a.put(JSONObject().put("id", g.id).put("name", g.name).put("bones", JSONArray(g.bones)).put("on", g.enabled).put("preset", g.preset)
                .put("int", g.intensity.toDouble()).put("k", g.stiffness.toDouble()).put("d", g.damping.toDouble()).put("delay", g.delay.toDouble()))
        }
        return a.toString()
    }

    fun fromJson(s: String): List<Secondary> = try {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val j = a.getJSONObject(i)
            val b = j.getJSONArray("bones")
            Secondary(j.getString("id"), j.optString("name", "Grupo"), (0 until b.length()).map { b.getString(it) },
                j.optBoolean("on", true), j.optInt("preset", 0), j.optDouble("int", 0.8).toFloat(), j.optDouble("k", 150.0).toFloat(),
                j.optDouble("d", 0.35).toFloat(), j.optDouble("delay", 0.3).toFloat())
        }
    } catch (e: Exception) { emptyList() }
}
