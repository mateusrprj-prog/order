package studio.mmd.rig

import org.json.JSONObject
import studio.mmd.mmd.PmxModel
import kotlin.math.*

/** Configuração da física real (corpos rígidos + juntas do PMX). */
data class PhysConfig(
    val enabled: Boolean = false,
    val gravity: Float = 1f,      // multiplica a gravidade padrão
    val stiffness: Float = 1f,    // multiplica as molas das juntas
    val damping: Float = 1f,      // multiplica os amortecimentos
    val wind: Float = 0f,         // vento lateral
    val ground: Boolean = true,   // chão em y=0
    val collisions: Boolean = true
)

object PhysIo {
    fun toJson(c: PhysConfig): String = JSONObject().put("on", c.enabled).put("g", c.gravity.toDouble()).put("k", c.stiffness.toDouble())
        .put("d", c.damping.toDouble()).put("w", c.wind.toDouble()).put("ground", c.ground).put("col", c.collisions).toString()
    fun fromJson(s: String): PhysConfig = try {
        val j = JSONObject(s)
        PhysConfig(j.optBoolean("on", false), j.optDouble("g", 1.0).toFloat(), j.optDouble("k", 1.0).toFloat(), j.optDouble("d", 1.0).toFloat(),
            j.optDouble("w", 0.0).toFloat(), j.optBoolean("ground", true), j.optBoolean("col", true))
    } catch (e: Exception) { PhysConfig() }
}

/**
 * Simulação de corpos rígidos com juntas mola 6-DOF (PBD: posição + rotação, 4 subpassos de ~1/240 s).
 * Corpos modo 0 seguem o osso (cinemáticos); modo 1 são livres e escrevem de volta no osso; modo 2 seguem a posição do osso e giram livres.
 * Colisão aproximada por cápsulas (esfera/caixa/cápsula), mais chão. Coordenadas MMD (unidades MMD).
 */
class PhysEngine private constructor(private val m: PmxModel) {
    private val rb = m.rigidBodies
    private val n = rb.size
    private val nb = m.bones.size
    private val pos = FloatArray(n * 3); private val q = FloatArray(n * 4)
    private val pp = FloatArray(n * 3); private val pq = FloatArray(n * 4)
    private val vel = FloatArray(n * 3); private val ang = FloatArray(n * 3)
    private val invM = FloatArray(n); private val invI = FloatArray(n)
    private val kin = BooleanArray(n); private val mode = IntArray(n)
    private val offP = FloatArray(n * 3); private val offQ = FloatArray(n * 4)
    private val tp0 = FloatArray(n * 3); private val tq0 = FloatArray(n * 4)
    private val tp1 = FloatArray(n * 3); private val tq1 = FloatArray(n * 4)
    private val hl = FloatArray(n); private val rad = FloatArray(n); private val axisL = IntArray(n)
    private val restQ = FloatArray(n * 4)

    private val jn = m.joints.size
    private val ja = IntArray(jn); private val jb = IntArray(jn)
    private val la = FloatArray(jn * 3); private val lb = FloatArray(jn * 3)
    private val fa = FloatArray(jn * 4); private val fb = FloatArray(jn * 4)
    private val skip = HashSet<Long>()

    /** Resultado por osso: driven = a física controla o osso; outQ/outT = pose global resultante (MMD). */
    val driven = BooleanArray(nb); val full = BooleanArray(nb)
    val outQ = FloatArray(nb * 4); val outT = FloatArray(nb * 3)
    private val boneOf = IntArray(n)
    private var needReset = true
    private var ownerOf = IntArray(0)
    private var time = 0f

    // ---- álgebra de quaternions (x, y, z, w)
    private val t = FloatArray(16)
    private fun qmul(a: FloatArray, ao: Int, b: FloatArray, bo: Int, o: FloatArray, oo: Int) {
        val ax = a[ao]; val ay = a[ao + 1]; val az = a[ao + 2]; val aw = a[ao + 3]
        val bx = b[bo]; val by = b[bo + 1]; val bz = b[bo + 2]; val bw = b[bo + 3]
        o[oo] = aw * bx + ax * bw + ay * bz - az * by
        o[oo + 1] = aw * by - ax * bz + ay * bw + az * bx
        o[oo + 2] = aw * bz + ax * by - ay * bx + az * bw
        o[oo + 3] = aw * bw - ax * bx - ay * by - az * bz
    }
    private fun qnorm(a: FloatArray, o: Int) {
        val l = sqrt(a[o] * a[o] + a[o + 1] * a[o + 1] + a[o + 2] * a[o + 2] + a[o + 3] * a[o + 3])
        if (l < 1e-8f) { a[o] = 0f; a[o + 1] = 0f; a[o + 2] = 0f; a[o + 3] = 1f } else { a[o] /= l; a[o + 1] /= l; a[o + 2] /= l; a[o + 3] /= l }
    }
    private fun rot(a: FloatArray, o: Int, x: Float, y: Float, z: Float, out: FloatArray, oo: Int, conj: Boolean = false) {
        val qx = if (conj) -a[o] else a[o]; val qy = if (conj) -a[o + 1] else a[o + 1]; val qz = if (conj) -a[o + 2] else a[o + 2]; val qw = a[o + 3]
        val cx = qy * z - qz * y; val cy = qz * x - qx * z; val cz = qx * y - qy * x
        val dx = qy * cz - qz * cy; val dy = qz * cx - qx * cz; val dz = qx * cy - qy * cx
        out[oo] = x + 2f * (qw * cx + dx); out[oo + 1] = y + 2f * (qw * cy + dy); out[oo + 2] = z + 2f * (qw * cz + dz)
    }
    private fun axisQ(ax: Int, ang: Float, o: FloatArray, oo: Int) {
        val s = sin(ang / 2); o[oo] = 0f; o[oo + 1] = 0f; o[oo + 2] = 0f; o[oo + 3] = cos(ang / 2); o[oo + ax] = s
    }
    private fun eulerQ(rx: Float, ry: Float, rz: Float, o: FloatArray, oo: Int) {
        axisQ(1, ry, t, 0); axisQ(0, rx, t, 4); axisQ(2, rz, t, 8)
        qmul(t, 0, t, 4, t, 12); qmul(t, 12, t, 8, o, oo)
    }
    private fun applyRot(b: Int, wx: Float, wy: Float, wz: Float) {
        val o = b * 4
        t[0] = wx * 0.5f; t[1] = wy * 0.5f; t[2] = wz * 0.5f; t[3] = 0f
        qmul(t, 0, q, o, t, 4)
        q[o] += t[4]; q[o + 1] += t[5]; q[o + 2] += t[6]; q[o + 3] += t[7]
        qnorm(q, o)
    }

    init {
        for (i in 0 until n) {
            val r = rb[i]
            mode[i] = r.mode
            boneOf[i] = if (r.bone in 0 until nb) r.bone else -1
            kin[i] = r.mode == 0 || boneOf[i] < 0
            for (k in 0..2) pos[i * 3 + k] = r.pos[k]
            eulerQ(r.rot[0], r.rot[1], r.rot[2], restQ, i * 4)
            for (k in 0..3) q[i * 4 + k] = restQ[i * 4 + k]
            val mass = if (r.mass <= 0f) 1f else r.mass
            val s = r.size
            when (r.shape) {
                0 -> { rad[i] = max(s[0], 0.01f); hl[i] = 0f; axisL[i] = 1 }
                2 -> { rad[i] = max(s[0], 0.01f); hl[i] = max(s[1], 0f) * 0.5f; axisL[i] = 1 }
                else -> {
                    val h = floatArrayOf(abs(s[0]), abs(s[1]), abs(s[2]))
                    var ax = 0; for (k in 1..2) if (h[k] > h[ax]) ax = k
                    var other = 0f; for (k in 0..2) if (k != ax) other = max(other, h[k])
                    rad[i] = max(other, 0.01f); hl[i] = max(h[ax] - other, 0f); axisL[i] = ax
                }
            }
            if (kin[i]) { invM[i] = 0f; invI[i] = 0f }
            else {
                invM[i] = if (r.mode == 2) 0f else 1f / mass
                val reff = rad[i] + hl[i] * 0.7f
                invI[i] = 1f / max(0.4f * mass * reff * reff, 1e-4f)
            }
            val b = boneOf[i]
            if (b >= 0) {
                val bn = m.bones[b]
                // offset do corpo em relação ao osso, no repouso (osso sem rotação)
                offP[i * 3] = r.pos[0] - bn.x; offP[i * 3 + 1] = r.pos[1] - bn.y; offP[i * 3 + 2] = r.pos[2] - bn.z
                for (k in 0..3) offQ[i * 4 + k] = restQ[i * 4 + k]
            } else { offQ[i * 4 + 3] = 1f }
        }
        for (j in 0 until jn) {
            val jt = m.joints[j]
            ja[j] = jt.a; jb[j] = jt.b
            if (jt.a !in 0 until n || jt.b !in 0 until n || jt.a == jt.b) { ja[j] = -1; continue }
            skip.add(jt.a.toLong() * n + jt.b); skip.add(jt.b.toLong() * n + jt.a)
            val qj = FloatArray(4); eulerQ(jt.rot[0], jt.rot[1], jt.rot[2], qj, 0)
            for ((bi, la0, fa0) in listOf(Triple(jt.a, la, fa), Triple(jt.b, lb, fb))) {
                rot(restQ, bi * 4, jt.pos[0] - rb[bi].pos[0], jt.pos[1] - rb[bi].pos[1], jt.pos[2] - rb[bi].pos[2], la0, j * 3, true)
                val inv = floatArrayOf(-restQ[bi * 4], -restQ[bi * 4 + 1], -restQ[bi * 4 + 2], restQ[bi * 4 + 3])
                qmul(inv, 0, qj, 0, fa0, j * 4)
            }
        }
        for (i in 0 until n) { val b = boneOf[i]; if (b >= 0 && !kin[i] && !driven[b]) { driven[b] = true; full[b] = mode[i] == 1 } }
        // só um corpo por osso comanda o osso: o primeiro; os demais seguem simulados mas não escrevem
        val owner = IntArray(nb) { -1 }
        for (i in 0 until n) { val b = boneOf[i]; if (b >= 0 && !kin[i] && owner[b] < 0) owner[b] = i }
        ownerOf = owner
    }
    fun reset() { needReset = true }

    private val rp = FloatArray(3); private val rq2 = FloatArray(4)
    /** Pose-alvo do corpo i a partir do osso (gq/gt = pose global dos ossos). */
    private fun target(i: Int, gq: FloatArray, gt: FloatArray, p: FloatArray, qq: FloatArray) {
        val b = boneOf[i]
        if (b < 0) { for (k in 0..2) p[i * 3 + k] = rb[i].pos[k]; for (k in 0..3) qq[i * 4 + k] = restQ[i * 4 + k]; return }
        rot(gq, b * 4, offP[i * 3], offP[i * 3 + 1], offP[i * 3 + 2], rp, 0)
        p[i * 3] = gt[b * 3] + rp[0]; p[i * 3 + 1] = gt[b * 3 + 1] + rp[1]; p[i * 3 + 2] = gt[b * 3 + 2] + rp[2]
        qmul(gq, b * 4, offQ, i * 4, qq, i * 4)
    }

    private val dir = FloatArray(3 * 2); private val c1 = FloatArray(3); private val c2 = FloatArray(3)

    private fun segAxis(i: Int, o: FloatArray) {
        val ax = axisL[i]
        rot(q, i * 4, if (ax == 0) 1f else 0f, if (ax == 1) 1f else 0f, if (ax == 2) 1f else 0f, o, 0)
    }

    fun step(dt: Float, gq: FloatArray, gt: FloatArray, cfg: PhysConfig) {
        for (i in 0 until n) { if (kin[i] || mode[i] == 2) { System.arraycopy(tp1, i * 3, tp0, i * 3, 3); System.arraycopy(tq1, i * 4, tq0, i * 4, 4) } }
        for (i in 0 until n) target(i, gq, gt, tp1, tq1)
        if (needReset) {
            for (i in 0 until n) {
                System.arraycopy(tp1, i * 3, pos, i * 3, 3); System.arraycopy(tq1, i * 4, q, i * 4, 4)
                System.arraycopy(tp1, i * 3, tp0, i * 3, 3); System.arraycopy(tq1, i * 4, tq0, i * 4, 4)
            }
            java.util.Arrays.fill(vel, 0f); java.util.Arrays.fill(ang, 0f); needReset = false; time = 0f
        }
        if (dt > 1e-6f) {
            val ns = ceil(dt * 240f).toInt().coerceIn(1, 8); val h = dt / ns
            for (s in 1..ns) { time += h; substep(h, s.toFloat() / ns, cfg) }
        }
        writeBack(gq, gt)
    }

    private fun lerpTargets(i: Int, f: Float) {
        for (k in 0..2) pos[i * 3 + k] = tp0[i * 3 + k] + (tp1[i * 3 + k] - tp0[i * 3 + k]) * f
        if (kin[i]) {
            var dot = 0f; for (k in 0..3) dot += tq0[i * 4 + k] * tq1[i * 4 + k]
            val sg = if (dot < 0) -1f else 1f
            for (k in 0..3) q[i * 4 + k] = tq0[i * 4 + k] * (1 - f) + tq1[i * 4 + k] * sg * f
            qnorm(q, i * 4)
        }
    }

    private fun substep(h: Float, f: Float, cfg: PhysConfig) {
        val g = -98f * cfg.gravity
        val windA = cfg.wind * 30f * (0.6f + 0.4f * sin(time * 1.7f))
        for (i in 0 until n) {
            System.arraycopy(pos, i * 3, pp, i * 3, 3); System.arraycopy(q, i * 4, pq, i * 4, 4)
            if (kin[i]) { lerpTargets(i, f); continue }
            if (mode[i] == 2) {
                for (k in 0..2) pos[i * 3 + k] = tp0[i * 3 + k] + (tp1[i * 3 + k] - tp0[i * 3 + k]) * f
                pp[i * 3] = pos[i * 3]; pp[i * 3 + 1] = pos[i * 3 + 1]; pp[i * 3 + 2] = pos[i * 3 + 2]
                vel[i * 3] = 0f; vel[i * 3 + 1] = 0f; vel[i * 3 + 2] = 0f
            } else {
                vel[i * 3 + 1] += g * h; vel[i * 3] += windA * h
                val ld = (1f - (rb[i].linearDamping * cfg.damping).coerceIn(0f, 0.99f)).pow(h)
                for (k in 0..2) vel[i * 3 + k] *= ld
                val sp = sqrt(vel[i * 3] * vel[i * 3] + vel[i * 3 + 1] * vel[i * 3 + 1] + vel[i * 3 + 2] * vel[i * 3 + 2])
                if (sp > 1500f) for (k in 0..2) vel[i * 3 + k] *= 1500f / sp
                for (k in 0..2) pos[i * 3 + k] += vel[i * 3 + k] * h
            }
            val ad = (1f - (rb[i].angularDamping * cfg.damping).coerceIn(0f, 0.99f)).pow(h)
            for (k in 0..2) ang[i * 3 + k] *= ad
            applyRot(i, ang[i * 3] * h, ang[i * 3 + 1] * h, ang[i * 3 + 2] * h)
        }
        for (it in 0 until 4) for (j in 0 until jn) if (ja[j] >= 0) solveJoint(j, h, cfg.stiffness)
        if (cfg.collisions) collide()
        if (cfg.ground) ground()
        for (i in 0 until n) {
            if (kin[i]) continue
            val inv = 1f / h
            for (k in 0..2) vel[i * 3 + k] = (pos[i * 3 + k] - pp[i * 3 + k]) * inv
            val ni = floatArrayOf(-pq[i * 4], -pq[i * 4 + 1], -pq[i * 4 + 2], pq[i * 4 + 3])
            qmul(q, i * 4, ni, 0, t, 8)
            val sg = if (t[11] < 0f) -1f else 1f
            ang[i * 3] = 2f * t[8] * sg * inv; ang[i * 3 + 1] = 2f * t[9] * sg * inv; ang[i * 3 + 2] = 2f * t[10] * sg * inv
            val bad = pos[i * 3].isNaN() || pos[i * 3 + 1].isNaN() || pos[i * 3 + 2].isNaN() || q[i * 4].isNaN() || abs(pos[i * 3 + 1]) > 1e5f
            if (bad) { needReset = true }
        }
    }

    private val w1 = FloatArray(3); private val w2 = FloatArray(3); private val ra = FloatArray(3); private val rbv = FloatArray(3)
    private val fq = FloatArray(4); private val fq2 = FloatArray(4); private val rel = FloatArray(4)

    private fun solveJoint(j: Int, h: Float, kMul: Float) {
        val a = ja[j]; val b = jb[j]; val jt = m.joints[j]
        val wA = invM[a]; val wB = invM[b]; val iA = invI[a]; val iB = invI[b]
        if (wA + wB + iA + iB <= 0f) return
        rot(q, a * 4, la[j * 3], la[j * 3 + 1], la[j * 3 + 2], ra, 0)
        rot(q, b * 4, lb[j * 3], lb[j * 3 + 1], lb[j * 3 + 2], rbv, 0)
        val dx = pos[b * 3] + rbv[0] - pos[a * 3] - ra[0]
        val dy = pos[b * 3 + 1] + rbv[1] - pos[a * 3 + 1] - ra[1]
        val dz = pos[b * 3 + 2] + rbv[2] - pos[a * 3 + 2] - ra[2]
        qmul(q, a * 4, fa, j * 4, fq, 0)          // quadro da junta pelo lado A
        qmul(q, b * 4, fb, j * 4, fq2, 0)         // idem pelo lado B
        // ---- linear (no quadro da junta)
        rot(fq, 0, dx, dy, dz, w1, 0, true)
        var cx = w1[0].coerceIn(jt.posMin[0], max(jt.posMin[0], jt.posMax[0]))
        var cy = w1[1].coerceIn(jt.posMin[1], max(jt.posMin[1], jt.posMax[1]))
        var cz = w1[2].coerceIn(jt.posMin[2], max(jt.posMin[2], jt.posMax[2]))
        val ex = w1[0] - cx; val ey = w1[1] - cy; val ez = w1[2] - cz
        val sw = (wA + wB) * h * h * kMul
        cx = ex + cx * min(0.9f, jt.springPos[0] * sw); cy = ey + cy * min(0.9f, jt.springPos[1] * sw); cz = ez + cz * min(0.9f, jt.springPos[2] * sw)
        rot(fq, 0, cx, cy, cz, w2, 0)
        val len = sqrt(w2[0] * w2[0] + w2[1] * w2[1] + w2[2] * w2[2])
        if (len > 1e-6f) {
            val nx = w2[0] / len; val ny = w2[1] / len; val nz = w2[2] / len
            val ca = (ra[1] * nz - ra[2] * ny).let { it * it } + (ra[2] * nx - ra[0] * nz).let { it * it } + (ra[0] * ny - ra[1] * nx).let { it * it }
            val cb = (rbv[1] * nz - rbv[2] * ny).let { it * it } + (rbv[2] * nx - rbv[0] * nz).let { it * it } + (rbv[0] * ny - rbv[1] * nx).let { it * it }
            val den = wA + iA * ca + wB + iB * cb
            if (den > 1e-9f) {
                val s = len / den
                val px = nx * s; val py = ny * s; val pz = nz * s
                if (wA > 0f || iA > 0f) {
                    pos[a * 3] += wA * px; pos[a * 3 + 1] += wA * py; pos[a * 3 + 2] += wA * pz
                    if (iA > 0f) applyRot(a, iA * (ra[1] * pz - ra[2] * py), iA * (ra[2] * px - ra[0] * pz), iA * (ra[0] * py - ra[1] * px))
                }
                if (wB > 0f || iB > 0f) {
                    pos[b * 3] -= wB * px; pos[b * 3 + 1] -= wB * py; pos[b * 3 + 2] -= wB * pz
                    if (iB > 0f) applyRot(b, -iB * (rbv[1] * pz - rbv[2] * py), -iB * (rbv[2] * px - rbv[0] * pz), -iB * (rbv[0] * py - rbv[1] * px))
                }
            }
        }
        // ---- angular
        if (iA + iB <= 0f) return
        qmul(q, a * 4, fa, j * 4, fq, 0); qmul(q, b * 4, fb, j * 4, fq2, 0)
        fq[0] = -fq[0]; fq[1] = -fq[1]; fq[2] = -fq[2]
        qmul(fq, 0, fq2, 0, rel, 0)
        if (rel[3] < 0f) { rel[0] = -rel[0]; rel[1] = -rel[1]; rel[2] = -rel[2]; rel[3] = -rel[3] }
        val sn = sqrt(rel[0] * rel[0] + rel[1] * rel[1] + rel[2] * rel[2])
        val an = 2f * atan2(sn, rel[3])
        val k = if (sn > 1e-6f) an / sn else 2f
        val rvx = rel[0] * k; val rvy = rel[1] * k; val rvz = rel[2] * k
        val kx = rvx.coerceIn(jt.rotMin[0], max(jt.rotMin[0], jt.rotMax[0]))
        val ky = rvy.coerceIn(jt.rotMin[1], max(jt.rotMin[1], jt.rotMax[1]))
        val kz = rvz.coerceIn(jt.rotMin[2], max(jt.rotMin[2], jt.rotMax[2]))
        val sa = (iA + iB) * h * h * kMul
        val ax = (rvx - kx) + kx * min(0.9f, jt.springRot[0] * sa)
        val ay = (rvy - ky) + ky * min(0.9f, jt.springRot[1] * sa)
        val az = (rvz - kz) + kz * min(0.9f, jt.springRot[2] * sa)
        if (abs(ax) + abs(ay) + abs(az) < 1e-7f) return
        // o quadro usado acima é o do lado A: refaz para levar o vetor ao mundo
        qmul(q, a * 4, fa, j * 4, fq, 0)
        rot(fq, 0, ax, ay, az, w1, 0)
        val tot = iA + iB
        if (iA > 0f) applyRot(a, w1[0] * iA / tot, w1[1] * iA / tot, w1[2] * iA / tot)
        if (iB > 0f) applyRot(b, -w1[0] * iB / tot, -w1[1] * iB / tot, -w1[2] * iB / tot)
    }

    private val sa = FloatArray(3); private val sb = FloatArray(3)

    private fun collide() {
        for (i in 0 until n) {
            if (kin[i]) continue
            segAxis(i, sa)
            for (j in 0 until n) {
                if (j == i || (!kin[j] && j < i)) continue
                if (skip.contains(i.toLong() * n + j)) continue
                if (rb[i].mode == 2 && kin[j]) continue
                val gi = rb[i].group; val gj = rb[j].group
                if ((rb[i].mask shr gj) and 1 != 0 || (rb[j].mask shr gi) and 1 != 0) continue
                val ddx = pos[j * 3] - pos[i * 3]; val ddy = pos[j * 3 + 1] - pos[i * 3 + 1]; val ddz = pos[j * 3 + 2] - pos[i * 3 + 2]
                val reach = rad[i] + hl[i] + rad[j] + hl[j]
                if (ddx * ddx + ddy * ddy + ddz * ddz > reach * reach) continue
                segAxis(j, sb)
                // extremidades
                val p1x = pos[i * 3] - sa[0] * hl[i]; val p1y = pos[i * 3 + 1] - sa[1] * hl[i]; val p1z = pos[i * 3 + 2] - sa[2] * hl[i]
                val d1x = sa[0] * 2 * hl[i]; val d1y = sa[1] * 2 * hl[i]; val d1z = sa[2] * 2 * hl[i]
                val p2x = pos[j * 3] - sb[0] * hl[j]; val p2y = pos[j * 3 + 1] - sb[1] * hl[j]; val p2z = pos[j * 3 + 2] - sb[2] * hl[j]
                val d2x = sb[0] * 2 * hl[j]; val d2y = sb[1] * 2 * hl[j]; val d2z = sb[2] * 2 * hl[j]
                closest(p1x, p1y, p1z, d1x, d1y, d1z, p2x, p2y, p2z, d2x, d2y, d2z)
                var nx = c2[0] - c1[0]; var ny = c2[1] - c1[1]; var nz = c2[2] - c1[2]
                val dist = sqrt(nx * nx + ny * ny + nz * nz)
                val pen = rad[i] + rad[j] - dist
                if (pen <= 0f) continue
                if (dist < 1e-6f) { nx = 0f; ny = 1f; nz = 0f } else { nx /= dist; ny /= dist; nz /= dist }
                val wi = invM[i]; val wj = invM[j]
                val tw = wi + wj
                if (tw <= 0f) continue
                val si = pen * wi / tw; val sj = pen * wj / tw
                pos[i * 3] -= nx * si; pos[i * 3 + 1] -= ny * si; pos[i * 3 + 2] -= nz * si
                if (!kin[j]) { pos[j * 3] += nx * sj; pos[j * 3 + 1] += ny * sj; pos[j * 3 + 2] += nz * sj }
            }
        }
    }

    private fun closest(p1x: Float, p1y: Float, p1z: Float, d1x: Float, d1y: Float, d1z: Float, p2x: Float, p2y: Float, p2z: Float, d2x: Float, d2y: Float, d2z: Float) {
        val rx = p1x - p2x; val ry = p1y - p2y; val rz = p1z - p2z
        val a = d1x * d1x + d1y * d1y + d1z * d1z; val e = d2x * d2x + d2y * d2y + d2z * d2z
        val f = d2x * rx + d2y * ry + d2z * rz
        var s: Float; var tt: Float
        if (a <= 1e-9f && e <= 1e-9f) { s = 0f; tt = 0f }
        else if (a <= 1e-9f) { s = 0f; tt = (f / e).coerceIn(0f, 1f) }
        else {
            val c = d1x * rx + d1y * ry + d1z * rz
            if (e <= 1e-9f) { tt = 0f; s = (-c / a).coerceIn(0f, 1f) }
            else {
                val bb = d1x * d2x + d1y * d2y + d1z * d2z
                val den = a * e - bb * bb
                s = if (den > 1e-9f) ((bb * f - c * e) / den).coerceIn(0f, 1f) else 0f
                tt = (bb * s + f) / e
                if (tt < 0f) { tt = 0f; s = (-c / a).coerceIn(0f, 1f) }
                else if (tt > 1f) { tt = 1f; s = ((bb - c) / a).coerceIn(0f, 1f) }
            }
        }
        c1[0] = p1x + d1x * s; c1[1] = p1y + d1y * s; c1[2] = p1z + d1z * s
        c2[0] = p2x + d2x * tt; c2[1] = p2y + d2y * tt; c2[2] = p2z + d2z * tt
    }

    private fun ground() {
        for (i in 0 until n) {
            if (kin[i] || mode[i] == 2) continue
            segAxis(i, sa)
            val low = pos[i * 3 + 1] - abs(sa[1]) * hl[i] - rad[i]
            if (low < 0f) {
                pos[i * 3 + 1] -= low
                pos[i * 3] += (pp[i * 3] - pos[i * 3]) * 0.3f; pos[i * 3 + 2] += (pp[i * 3 + 2] - pos[i * 3 + 2]) * 0.3f
            }
        }
    }

    private fun writeBack(gq: FloatArray, gt: FloatArray) {
        for (b in 0 until nb) {
            val i = ownerOf[b]
            if (i < 0) { continue }
            // osso = corpo * inverso(offset)
            val inv = floatArrayOf(-offQ[i * 4], -offQ[i * 4 + 1], -offQ[i * 4 + 2], offQ[i * 4 + 3])
            qmul(q, i * 4, inv, 0, outQ, b * 4)
            rot(outQ, b * 4, offP[i * 3], offP[i * 3 + 1], offP[i * 3 + 2], rp, 0)
            outT[b * 3] = pos[i * 3] - rp[0]; outT[b * 3 + 1] = pos[i * 3 + 1] - rp[1]; outT[b * 3 + 2] = pos[i * 3 + 2] - rp[2]
        }
    }

    val hasDriven: Boolean get() = driven.any { it }

    companion object {
        fun create(m: PmxModel): PhysEngine? {
            if (m.rigidBodies.isEmpty() || m.joints.isEmpty()) return null
            if (m.rigidBodies.none { it.mode != 0 }) return null
            return try { PhysEngine(m).takeIf { it.hasDriven } } catch (e: Exception) { null }
        }
    }
}
