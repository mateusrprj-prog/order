package studio.mmd.rig

import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxModel

/**
 * Reconhece as partes com física do modelo (cabelo, saia, roupa, peito, cauda/orelha, acessórios) e cria os grupos de
 * movimento secundário já ajustados. Usa os corpos rígidos do PMX (modo "física") para saber QUAIS ossos balançam;
 * a categoria vem do nome do osso/corpo rígido; massa e amortecimento do corpo rígido ajustam rigidez e balanço.
 * Se o modelo não tem corpos rígidos, cai para o reconhecimento só pelo nome.
 */
object AutoPhysics {
    class Result(val groups: List<Secondary>, val summary: String, val fromPhysics: Boolean)

    private class Cat(val label: String, val preset: Int, val keys: List<String>)

    private val cats = listOf(
        Cat("Peito", 5, listOf("乳", "おっぱい", "oppai", "breast", "bust", "boob", "ちち")),
        Cat("Cabelo", 0, listOf("髪", "hair", "ヘア", "ahoge", "アホ毛", "ポニテ", "ponytail", "twintail", "ツイン", "前髪", "横髪", "後髪", "bangs")),
        Cat("Saia", 1, listOf("スカート", "skirt", "スカ", "裾", "フレア", "flare")),
        Cat("Cauda/orelha", 6, listOf("尻尾", "しっぽ", "tail", "耳", "ケモ")),
        Cat("Roupa", 1, listOf("袖", "sleeve", "マント", "cape", "cloak", "coat", "コート", "服", "cloth", "ネクタイ", "necktie", "scarf", "マフラー",
            "ショール", "shawl", "フリル", "frill", "帯", "obi", "エプロン", "apron", "belt", "ファー", "襟", "collar", "jacket", "ジャケット")),
        Cat("Acessório", 2, listOf("リボン", "ribbon", "アクセ", "accessor", "飾", "ピアス", "イヤリング", "earring", "鈴", "chain", "チェーン", "紐", "himo",
            "string", "strap", "タッセル", "tassel", "羽", "wing", "feather", "ケーブル", "cable", "ヘッドホン"))
    )

    private fun isIk(b: PmxBone) = b.ik != null || b.name.contains("IK") || b.name.contains("ＩＫ")
    /** Sem corpos rígidos, palavras curtas em ASCII dão falso positivo; só aceitamos as longas ou japonesas. */
    private fun strictOk(k: String) = k.length >= 5 || k.any { it.code > 127 }

    fun detect(model: PmxModel): Result {
        val bones = model.bones
        val phys = HashMap<Int, ArrayList<studio.mmd.mmd.PmxRigid>>()
        for (rb in model.rigidBodies) {
            if ((rb.mode == 1 || rb.mode == 2) && rb.bone in bones.indices && !isIk(bones[rb.bone])) phys.getOrPut(rb.bone) { ArrayList() }.add(rb)
        }
        val fromPhysics = phys.isNotEmpty()
        val bySide = LinkedHashMap<String, ArrayList<Int>>()
        val catOf = HashMap<String, Cat?>()
        val cand = if (fromPhysics) phys.keys.sorted() else bones.indices.filter { !isIk(bones[it]) }
        for (b in cand) {
            val text = buildString {
                append(bones[b].name).append(' ').append(bones[b].nameEn)
                phys[b]?.forEach { append(' ').append(it.name).append(' ').append(it.nameEn) }
            }.lowercase()
            val cat = cats.firstOrNull { c -> c.keys.any { k -> (fromPhysics || strictOk(k)) && text.contains(k.lowercase()) } }
            if (cat == null && !fromPhysics) continue
            val label = cat?.label ?: "Outros"
            catOf[label] = cat
            bySide.getOrPut(label) { ArrayList() }.add(b)
        }
        val groups = ArrayList<Secondary>()
        for ((label, list) in bySide) {
            val cat = catOf[label]
            val preset = cat?.preset ?: 2
            var g = SecPreset.apply(Secondary(java.util.UUID.randomUUID().toString(), "$label (${if (fromPhysics) "física" else "auto"})", list.map { bones[it].name }), preset)
            if (fromPhysics) {
                val rbs = list.flatMap { phys[it] ?: emptyList() }
                if (rbs.isNotEmpty()) {
                    val mass = rbs.map { it.mass }.average().toFloat()
                    val ang = rbs.map { it.angularDamping }.average().toFloat()
                    // amortecimento alto no corpo rígido = movimento mais contido; massa alta = mais lento
                    g = g.copy(
                        damping = (g.damping + (ang - 0.7f) * 0.3f).coerceIn(0.15f, 1.2f),
                        stiffness = (g.stiffness * (1.4f / (0.8f + mass)).coerceIn(0.6f, 1.4f)).coerceIn(30f, 500f)
                    )
                }
            }
            groups.add(g)
        }
        val summary = if (groups.isEmpty()) "Nada reconhecido" else
            (if (fromPhysics) "Pela física do modelo: " else "Modelo sem física; reconhecido pelo nome: ") +
                groups.joinToString(" · ") { "${it.name.substringBefore(" (")} ${it.bones.size}" }
        return Result(groups, summary, fromPhysics)
    }
}
