package studio.mmd.mocap

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import kotlinx.coroutines.ensureActive
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min

/** Um quadro de pontos do corpo: 33 pontos do ML Kit (x, y, z normalizados pela altura da imagem) e confiança de cada um. */
class PoseFrame(val t: Float, val p: FloatArray, val conf: FloatArray)

/** Filtro One Euro (suaviza o tremor sem atrasar movimentos rápidos). */
class OneEuro(private val minCutoff: Float, private val beta: Float, private val dCutoff: Float = 1f) {
    private var init = false; private var xPrev = 0f; private var dxPrev = 0f
    private fun alpha(cutoff: Float, dt: Float): Float { val tau = 1f / (2f * PI.toFloat() * cutoff); return 1f / (1f + tau / dt) }
    fun filter(x: Float, dt: Float): Float {
        if (!init) { init = true; xPrev = x; dxPrev = 0f; return x }
        val dx = (x - xPrev) / dt
        val aD = alpha(dCutoff, dt); val dxHat = aD * dx + (1f - aD) * dxPrev
        val a = alpha(minCutoff + beta * abs(dxHat), dt)
        val xHat = a * x + (1f - a) * xPrev
        xPrev = xHat; dxPrev = dxHat
        return xHat
    }
}

object MocapEngine {
    /** Extrai os pontos do corpo de [startS] a [endS] a [fps] amostras por segundo, já suavizados (smooth 0..1). Roda em segundo plano. */
    suspend fun extract(file: File, startS: Float, endS: Float, fps: Int, smooth: Float, onProgress: (Int, Int) -> Unit): List<PoseFrame> {
        val mmr = MediaMetadataRetriever()
        val detector = PoseDetection.getClient(
            AccuratePoseDetectorOptions.Builder().setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE).build())
        val out = ArrayList<PoseFrame>()
        try {
            mmr.setDataSource(file.absolutePath)
            var w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 720
            var h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1280
            val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val sc = min(1f, 720f / maxOf(w, h))
            val tw = maxOf(32, (w * sc).toInt()); val th = maxOf(32, (h * sc).toInt())
            val n = maxOf(1, ((endS - startS) * fps).toInt() + 1)
            val minC = 3.0f * (1f - smooth) + 0.3f
            val filters = Array(99) { OneEuro(minC, 2.0f) }
            val dt = 1f / fps
            var last: FloatArray? = null; var lastConf = FloatArray(33)
            for (i in 0 until n) {
                coroutineContext.ensureActive()
                onProgress(i, n)
                val t = startS + i.toFloat() / fps
                val us = (t * 1_000_000L).toLong()
                var bmp: Bitmap? = try {
                    if (Build.VERSION.SDK_INT >= 27) mmr.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, tw, th)
                    else mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST)
                } catch (e: Exception) { null }
                if (bmp == null) { last?.let { out.add(PoseFrame(t, it.copyOf(), lastConf.copyOf())) }; continue }
                if (Build.VERSION.SDK_INT < 27 && maxOf(bmp.width, bmp.height) > 720) {
                    val k = 720f / maxOf(bmp.width, bmp.height)
                    bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
                }
                val hh = bmp.height.toFloat()
                val pose = try { Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0))) } catch (e: Exception) { null }
                val p = FloatArray(99); val conf = FloatArray(33)
                var ok = false
                if (pose != null) for (k in 0 until 33) {
                    val lm = pose.getPoseLandmark(k) ?: continue
                    val q = lm.position3D
                    conf[k] = lm.inFrameLikelihood
                    if (lm.inFrameLikelihood >= 0.3f) { p[k * 3] = q.x / hh; p[k * 3 + 1] = q.y / hh; p[k * 3 + 2] = q.z / hh; ok = true }
                    else if (last != null) { p[k * 3] = last[k * 3]; p[k * 3 + 1] = last[k * 3 + 1]; p[k * 3 + 2] = last[k * 3 + 2] }
                }
                bmp.recycle()
                if (!ok) { last?.let { out.add(PoseFrame(t, it.copyOf(), lastConf.copyOf())) }; continue }
                for (k in 0 until 99) p[k] = filters[k].filter(p[k], dt)
                last = p; lastConf = conf
                out.add(PoseFrame(t, p, conf))
            }
            onProgress(n, n)
        } finally {
            try { mmr.release() } catch (e: Exception) {}
            try { detector.close() } catch (e: Exception) {}
        }
        return out
    }
}
