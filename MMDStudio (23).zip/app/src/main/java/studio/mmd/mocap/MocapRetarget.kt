package studio.mmd.mocap

import studio.mmd.mmd.PmxModel
import kotlin.math.*

class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(k: Float) = V3(x * k, y * k, z * k)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun len() = sqrt(dot(this))
    fun norm(): V3 { val l = len(); return if (l < 1e-8f) V3(0f, 1f, 0f) else V3(x / l, y / l, z / l) }
}

/** Quaternion (x, y, z, w) com a mesma convenção do Animator. */
class Q(val x: Float, val y: Float, val z: Float, val w: Float) {
    operator fun times(o: Q) = Q(w * o.x + x * o.w + y * o.z - z * o.y, w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w, w * o.w - x * o.x - y * o.y - z * o.z)
    fun inv() = Q(-x, -y, -z, w)
    fun norm(): Q { val l = sqrt(x * x + y * y + z * z + w * w); return if (l < 1e-8f) Q(0f, 0f, 0f, 1f) else Q(x / l, y / l, z / l, w / l) }
    fun rot(v: V3): V3 {
        val c = V3(x, y, z).cross(v); val d = V3(x, y, z).cross(c)
        return v + c * (2f * w) + d * 2f
    }
    companion object {
        val ID = Q(0f, 0f, 0f, 1f)
        /** Menor rotação que leva a direção [a] até a direção [b]. */
        fun arc(a0: V3, b0: V3): Q {
            val a = a0.norm(); val b = b0.norm(); val d = a.dot(b)
            if (d > 0.99999f) return ID
            if (d < -0.99999f) {
                var ax = a.cross(V3(1f, 0f, 0f)); if (ax.len() < 0.1f) ax = a.cross(V3(0f, 0f, 1f))
                ax = ax.norm(); return Q(ax.x, ax.y, ax.z, 0f)
            }
            val c = a.cross(b)
            return Q(c.x, c.y, c.z, 1f + d).norm()
        }
        fun axis(a: V3, ang: Float): Q { val n = a.norm(); val s = sin(ang / 2f); return Q(n.x * s, n.y * s, n.z * s, cos(ang / 2f)) }
    }
}

class MocapOptions(
    val allBones: Boolean,          // false = só ossos principais
    val moveCenter: Boolean,        // gerar posição do センター
    val swapSides: Boolean?,        // null = detectar sozinho
    val insertFrame: Int,           // quadro da timeline onde o trecho começa
    val timelineFps: Int = 30,
    val tolAngleDeg: Float = 1.5f,  // simplificação de keys
    val tolPos: Float = 0.05f
)

object MocapRetarget {
    /** Converte os pontos do corpo em keyframes (osso -> lista de (quadro, [px,py,pz,qx,qy,qz,qw])). */
    fun retarget(model: PmxModel, frames: List<PoseFrame>, o: MocapOptions): Map<String, List<Pair<Int, FloatArray>>> {
        if (frames.size < 2) throw IllegalStateException("Nenhuma pessoa foi detectada no trecho do vídeo")
        val idx = HashMap<String, Int>(); model.bones.forEachIndexed { i, b -> if (!idx.containsKey(b.name)) idx[b.name] = i }
        fun pos(n: String): V3? = idx[n]?.let { val b = model.bones[it]; V3(b.x, b.y, b.z) }

        val swap = o.swapSides ?: run {
            val d = frames.map { it.p[11 * 3] - it.p[12 * 3] }.sorted()[frames.size / 2]
            d < 0f
        }
        fun li(base: Int, left: Boolean) = if (left xor swap) base else base + 1   // índice ML do lado esquerdo/direito do MMD

        val G0 = HashMap<String, Q>()  // reservado
        val tracks = HashMap<String, ArrayList<Pair<Int, FloatArray>>>()
        fun add(name: String, frame: Int, q: Q, p: V3?) {
            val l = tracks.getOrPut(name) { ArrayList() }
            var qq = q.norm()
            val prev = l.lastOrNull()?.second
            if (prev != null && prev[3] * qq.w + prev[4] * qq.x + prev[5] * qq.y + prev[6] * qq.z < 0f) qq = Q(-qq.x, -qq.y, -qq.z, -qq.w)
            l.add(frame to floatArrayOf(p?.x ?: 0f, p?.y ?: 0f, p?.z ?: 0f, qq.x, qq.y, qq.z, qq.w))
        }

        // ---- proporções: comprimento da perna do modelo x do vídeo
        val legM = ((pos("左足")?.y ?: 0f) - (pos("左足首")?.y ?: 0f)).let { if (it > 1f) it else 10f }
        fun lm(f: PoseFrame, i: Int) = V3(f.p[i * 3], -f.p[i * 3 + 1], f.p[i * 3 + 2])   // imagem (y p/ baixo) -> MMD (y p/ cima, z p/ longe da câmera)
        val f0 = frames[0]
        val legV = max(1e-3f, (((lm(f0, 23) - lm(f0, 27)).len() + (lm(f0, 24) - lm(f0, 28)).len()) / 2f))
        val sc = legM / legV
        val hip0 = (lm(f0, 23) + lm(f0, 24)) * 0.5f

        // ---- direções de repouso do modelo
        val restSpine = (pos("首") ?: pos("頭"))?.let { n -> pos("上半身")?.let { n - it } } ?: V3(0f, 1f, 0f)
        val restShoulders = ((pos("左肩") ?: pos("左腕")) ?: V3(1f, 0f, 0f)) - ((pos("右肩") ?: pos("右腕")) ?: V3(-1f, 0f, 0f))
        val restHips = (pos("左足") ?: V3(1f, 0f, 0f)) - (pos("右足") ?: V3(-1f, 0f, 0f))
        val restNeck = (pos("頭")?.let { h -> pos("首")?.let { h - it } })

        // pai resolvido mais próximo: usa a rotação global do primeiro ancestral já calculado
        fun parentG(name: String, g: Map<String, Q>): Q {
            var p = idx[name]?.let { model.bones[it].parent } ?: -1
            while (p >= 0) { g[model.bones[p].name]?.let { return it }; p = model.bones[p].parent }
            return Q.ID
        }

        for (f in frames) {
            val frame = o.insertFrame + ((f.t - frames[0].t) * o.timelineFps).roundToInt()
            val g = HashMap<String, Q>()
            fun solve(name: String, G: Q) { if (idx.containsKey(name)) { g[name] = G; add(name, frame, parentG(name, g).inv() * G, null) } }

            val shL = lm(f, li(11, true)); val shR = lm(f, li(11, false))
            val hpL = lm(f, li(23, true)); val hpR = lm(f, li(23, false))
            val shMid = (shL + shR) * 0.5f; val hipMid = (hpL + hpR) * 0.5f

            // tronco: inclinação (arco) + giro em torno da coluna
            val spine = shMid - hipMid
            val q1 = Q.arc(restSpine, spine)
            val d = spine.norm()
            val l1 = q1.rot(restShoulders.norm()); val lt = (shL - shR)
            val l1p = l1 - d * l1.dot(d); val ltp = lt - d * lt.dot(d)
            val twist = if (l1p.len() > 1e-4f && ltp.len() > 1e-4f) atan2(l1p.cross(ltp).dot(d), l1p.dot(ltp)) else 0f
            solve("上半身", Q.axis(d, twist) * q1)

            if (o.allBones) {
                solve("下半身", Q.arc(restHips, hpL - hpR))
                if (restNeck != null) solve("首", Q.arc(restNeck, ((lm(f, 7) + lm(f, 8)) * 0.5f) - shMid))
            }
            for (left in listOf(true, false)) {
                val s = if (left) "左" else "右"
                val sh = lm(f, li(11, left)); val el = lm(f, li(13, left)); val wr = lm(f, li(15, left))
                val hp = lm(f, li(23, left)); val kn = lm(f, li(25, left)); val an = lm(f, li(27, left))
                val rShoulder = pos("${s}腕"); val rElbow = pos("${s}ひじ"); val rWrist = pos("${s}手首")
                if (rShoulder != null && rElbow != null) solve("${s}腕", Q.arc(rElbow - rShoulder, el - sh))
                if (rElbow != null && rWrist != null) solve("${s}ひじ", Q.arc(rWrist - rElbow, wr - el))
                val rHip = pos("${s}足"); val rKnee = pos("${s}ひざ"); val rAnkle = pos("${s}足首")
                if (rHip != null && rKnee != null) solve("${s}足", Q.arc(rKnee - rHip, kn - hp))
                if (rKnee != null && rAnkle != null) solve("${s}ひざ", Q.arc(rAnkle - rKnee, an - kn))
                if (o.allBones) {
                    val toe = pos("${s}つま先") ?: pos("${s}足先EX")
                    if (rAnkle != null && toe != null) solve("${s}足首", Q.arc(toe - rAnkle, lm(f, li(31, left)) - an))
                }
            }
            if (o.moveCenter && idx.containsKey("センター")) {
                val dlt = hipMid - hip0
                add("センター", frame, Q.ID, V3(dlt.x * sc, dlt.y * sc, dlt.z * sc * 0.5f))
            }
        }
        // sobra: G0 não usado
        G0.clear()
        return tracks.mapValues { (name, l) -> simplify(l, if (name == "センター") o.tolPos else o.tolAngleDeg, name == "センター") }
    }

    /** Remove keys redundantes (Douglas-Peucker no tempo): mantém só o que a interpolação linear não reproduz. */
    private fun simplify(l: List<Pair<Int, FloatArray>>, tol: Float, isPos: Boolean): List<Pair<Int, FloatArray>> {
        if (l.size <= 2) return l
        val keep = BooleanArray(l.size); keep[0] = true; keep[l.size - 1] = true
        val stack = ArrayDeque<IntArray>(); stack.addLast(intArrayOf(0, l.size - 1))
        while (stack.isNotEmpty()) {
            val (a, b) = stack.removeLast()
            if (b - a < 2) continue
            var worst = -1; var wv = 0f
            val fa = l[a].first; val fb = l[b].first
            for (i in a + 1 until b) {
                val t = if (fb == fa) 0f else (l[i].first - fa).toFloat() / (fb - fa)
                val e = if (isPos) {
                    val p0 = l[a].second; val p1 = l[b].second; val p = l[i].second
                    sqrt((p[0] - (p0[0] + (p1[0] - p0[0]) * t)).pow(2) + (p[1] - (p0[1] + (p1[1] - p0[1]) * t)).pow(2) + (p[2] - (p0[2] + (p1[2] - p0[2]) * t)).pow(2))
                } else angleErr(l[a].second, l[b].second, l[i].second, t)
                if (e > wv) { wv = e; worst = i }
            }
            if (worst >= 0 && wv > tol) { keep[worst] = true; stack.addLast(intArrayOf(a, worst)); stack.addLast(intArrayOf(worst, b)) }
        }
        return l.filterIndexed { i, _ -> keep[i] }
    }

    /** Erro em graus entre a rotação real e a interpolada (lerp normalizado) de duas keys. */
    private fun angleErr(a: FloatArray, b: FloatArray, c: FloatArray, t: Float): Float {
        var qx = a[3] + (b[3] - a[3]) * t; var qy = a[4] + (b[4] - a[4]) * t; var qz = a[5] + (b[5] - a[5]) * t; var qw = a[6] + (b[6] - a[6]) * t
        val l = sqrt(qx * qx + qy * qy + qz * qz + qw * qw).coerceAtLeast(1e-8f); qx /= l; qy /= l; qz /= l; qw /= l
        val d = abs(qx * c[3] + qy * c[4] + qz * c[5] + qw * c[6]).coerceIn(0f, 1f)
        return Math.toDegrees(2.0 * acos(d.toDouble())).toFloat()
    }
}
