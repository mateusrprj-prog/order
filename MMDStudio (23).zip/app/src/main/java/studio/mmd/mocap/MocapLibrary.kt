package studio.mmd.mocap

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Vídeo de referência da biblioteca (nome, duração, tags). */
class MocapVideo(val id: String, val name: String, val durationMs: Long, val tags: String, val file: String, val builtin: Boolean)

/**
 * Biblioteca de vídeos de referência: pasta interna filesDir/mocap + library.json.
 * Vídeos "da casa" vêm de assets/mocap_library/index.json ([{"name","file","tags"}] + os mp4 na mesma pasta) e são copiados na primeira abertura.
 */
object MocapLibrary {
    val items = mutableStateListOf<MocapVideo>()
    private fun dir(ctx: Context) = File(ctx.filesDir, "mocap").also { it.mkdirs() }
    fun fileOf(ctx: Context, v: MocapVideo) = File(dir(ctx), v.file)

    fun load(ctx: Context) {
        items.clear()
        try { // embutidos
            val idxTxt = ctx.assets.open("mocap_library/index.json").bufferedReader().use { it.readText() }
            val a = JSONArray(idxTxt)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val fn = o.getString("file"); val dst = File(dir(ctx), "builtin_$fn")
                if (!dst.exists()) ctx.assets.open("mocap_library/$fn").use { ins -> dst.outputStream().use { ins.copyTo(it) } }
                items.add(MocapVideo("b_$fn", o.optString("name", fn), duration(dst), o.optString("tags", ""), dst.name, true))
            }
        } catch (e: Exception) { /* sem embutidos */ }
        try {
            val f = File(dir(ctx), "library.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (File(dir(ctx), o.getString("file")).exists())
                        items.add(MocapVideo(o.getString("id"), o.getString("name"), o.optLong("ms"), o.optString("tags", ""), o.getString("file"), false))
                }
            }
        } catch (e: Exception) { }
    }

    private fun duration(f: File): Long = try {
        val m = MediaMetadataRetriever(); m.setDataSource(f.absolutePath)
        val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L; m.release(); d
    } catch (e: Exception) { 0L }

    private fun save(ctx: Context) {
        val a = JSONArray()
        for (v in items) if (!v.builtin) a.put(JSONObject().put("id", v.id).put("name", v.name).put("ms", v.durationMs).put("tags", v.tags).put("file", v.file))
        File(dir(ctx), "library.json").writeText(a.toString())
    }

    /** Copia um vídeo escolhido pelo usuário para a biblioteca. */
    fun add(ctx: Context, uri: Uri, name: String, tags: String = ""): MocapVideo {
        val id = "u_" + System.currentTimeMillis()
        val dst = File(dir(ctx), "$id.mp4")
        ctx.contentResolver.openInputStream(uri)?.use { ins -> dst.outputStream().use { ins.copyTo(it) } } ?: throw java.io.IOException("Não consegui ler o vídeo")
        val v = MocapVideo(id, name.substringBeforeLast('.'), duration(dst), tags, dst.name, false)
        items.add(v); save(ctx); return v
    }

    fun remove(ctx: Context, v: MocapVideo) {
        if (v.builtin) return
        fileOf(ctx, v).delete(); items.remove(v); save(ctx)
    }

    fun setTags(ctx: Context, v: MocapVideo, tags: String) {
        val i = items.indexOf(v); if (i < 0 || v.builtin) return
        items[i] = MocapVideo(v.id, v.name, v.durationMs, tags, v.file, false); save(ctx)
    }
}
