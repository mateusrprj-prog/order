package studio.mmd.project

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import studio.mmd.edit.PoseSnap
import java.io.File

/** Biblioteca de poses do projeto aberto (poses.json ao lado do projeto). */
object PoseLib {
    val items = mutableStateListOf<PoseSnap>()
    private var file: File? = null

    fun open(f: File) {
        file = f; items.clear()
        try {
            if (!f.exists()) return
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val b = HashMap<String, FloatArray>(); val bo = o.getJSONObject("b")
                for (k in bo.keys()) { val arr = bo.getJSONArray(k); b[k] = FloatArray(7) { arr.getDouble(it).toFloat() } }
                val m = HashMap<String, Float>(); val mo = o.getJSONObject("m")
                for (k in mo.keys()) m[k] = mo.getDouble(k).toFloat()
                items.add(PoseSnap(o.getString("n"), b, m))
            }
        } catch (e: Exception) { items.clear() }
    }

    fun add(p: PoseSnap) { items.add(p); save() }
    fun remove(i: Int) { if (i in items.indices) { items.removeAt(i); save() } }

    private fun save() {
        val f = file ?: return
        try {
            val a = JSONArray()
            for (p in items) {
                val b = JSONObject(); for ((k, v) in p.bones) b.put(k, JSONArray().also { arr -> v.forEach { arr.put(it.toDouble()) } })
                val m = JSONObject(); for ((k, v) in p.morphs) m.put(k, v.toDouble())
                a.put(JSONObject().put("n", p.name).put("b", b).put("m", m))
            }
            f.writeText(a.toString())
        } catch (e: Exception) { }
    }
}
