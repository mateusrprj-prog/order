package studio.mmd.importer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import studio.mmd.mmd.PmdParser
import studio.mmd.mmd.XParser
import studio.mmd.mmd.PmxModel
import studio.mmd.mmd.PmxParser
import java.io.IOException
import java.nio.charset.Charset
import java.util.zip.ZipInputStream

/** Importa .pmx isolado ou .zip (modelo + texturas) a partir do armazenamento do Android. */
object ModelImporter {
    class Result(val model: PmxModel, val textures: List<ByteArray?>, val sourceName: String)

    private val KEEP = setOf("pmx", "pmd", "x", "png", "jpg", "jpeg", "bmp", "tga", "spa", "sph", "gif")

    fun load(ctx: Context, uri: Uri): Result {
        val name = displayName(ctx, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "zip" -> fromZip(ctx, uri, name)
            "pmx" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = PmxParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            "x" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = XParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            "pmd" -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir $name")
                val m = PmdParser.parse(bytes)
                Result(m, List(m.textures.size) { null }, name)
            }
            else -> throw IOException("Formato não suportado: $name")
        }
    }

    private fun fromZip(ctx: Context, uri: Uri, name: String): Result {
        val files = try { readZip(ctx, uri, Charsets.UTF_8) } catch (e: IllegalArgumentException) { readZip(ctx, uri, Charset.forName("Shift_JIS")) }
        val pmxPath = files.keys.firstOrNull { it.lowercase().endsWith(".pmx") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".pmd") }
            ?: files.keys.firstOrNull { it.lowercase().endsWith(".x") }
            ?: throw IOException("Nenhum .pmx, .pmd ou .x encontrado dentro do zip")
        val model = when {
            pmxPath.lowercase().endsWith(".pmd") -> PmdParser.parse(files.getValue(pmxPath))
            pmxPath.lowercase().endsWith(".x") -> XParser.parse(files.getValue(pmxPath))
            else -> PmxParser.parse(files.getValue(pmxPath))
        }
        val dir = pmxPath.lowercase().substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        val lower = files.keys.associateBy { it.lowercase() }
        val textures = model.textures.map { t ->
            val n = t.replace('\\', '/').lowercase().removePrefix("./")
            val key = lower[dir + n] ?: lower[n] ?: lower.entries.firstOrNull { it.key.substringAfterLast('/') == n.substringAfterLast('/') }?.value
            key?.let { k -> val d = files[k]; if (d != null && k.lowercase().endsWith(".tga")) TgaDecoder.toPng(d) else d }
        }
        return Result(model, textures, pmxPath.substringAfterLast('/'))
    }

    private fun readZip(ctx: Context, uri: Uri, cs: Charset): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o zip")
        ins.use { s ->
            ZipInputStream(s.buffered(), cs).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    val n = e.name.replace('\\', '/')
                    if (n.substringAfterLast('.', "").lowercase() in KEEP) out[n] = z.readBytes()
                }
            }
        }
        return out
    }

    fun readBytes(ctx: Context, uri: Uri): ByteArray =
        ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Não foi possível abrir o arquivo")

    fun displayName(ctx: Context, uri: Uri): String =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "arquivo"
}
