package studio.mmd.importer

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/** Converte TGA (tipos 1, 2, 3, 9, 10, 11; 8/15/16/24/32 bits) em PNG, para o resto do app tratar como textura normal. */
object TgaDecoder {
    fun toPng(d: ByteArray): ByteArray? = try {
        val idLen = d[0].toInt() and 0xFF; val cmType = d[1].toInt() and 0xFF; val type = d[2].toInt() and 0xFF
        val cmStart = u16(d, 3); val cmLen = u16(d, 5); val cmBits = d[7].toInt() and 0xFF
        val w = u16(d, 12); val h = u16(d, 14); val bpp = d[16].toInt() and 0xFF; val desc = d[17].toInt() and 0xFF
        if (w <= 0 || h <= 0 || w * h > 16_000_000) null else {
            var p = 18 + idLen
            val palette = IntArray(cmLen)
            if (cmType == 1) {
                val cb = (cmBits + 7) / 8
                for (i in 0 until cmLen) { palette[i] = px(d, p, cb, cmBits); p += cb }
            }
            val bytes = (bpp + 7) / 8
            val rle = type >= 9
            val base = if (rle) type - 8 else type
            if (base != 1 && base != 2 && base != 3) null else {
                val out = IntArray(w * h)
                var n = 0
                fun value(at: Int): Int {
                    if (base == 1) return palette.getOrElse((idxVal(d, at, bytes)) - cmStart) { 0 }
                    if (base == 3) { val g = d[at].toInt() and 0xFF; return (0xFF shl 24) or (g shl 16) or (g shl 8) or g }
                    return px(d, at, bytes, bpp)
                }
                if (!rle) {
                    while (n < w * h) { out[n++] = value(p); p += bytes }
                } else {
                    while (n < w * h) {
                        val hd = d[p++].toInt() and 0xFF; val c = (hd and 0x7F) + 1
                        if (hd and 0x80 != 0) { val v = value(p); p += bytes; for (k in 0 until c) if (n < w * h) out[n++] = v }
                        else for (k in 0 until c) { if (n < w * h) out[n++] = value(p); p += bytes }
                    }
                }
                val fixed = IntArray(w * h)
                val topFirst = desc and 0x20 != 0; val rightFirst = desc and 0x10 != 0
                for (y in 0 until h) for (x in 0 until w) {
                    val sy = if (topFirst) y else h - 1 - y
                    val sx = if (rightFirst) w - 1 - x else x
                    fixed[y * w + x] = out[sy * w + sx]
                }
                val bm = Bitmap.createBitmap(fixed, w, h, Bitmap.Config.ARGB_8888)
                val bo = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, bo); bm.recycle()
                bo.toByteArray()
            }
        }
    } catch (e: Exception) { null }

    private fun u16(d: ByteArray, o: Int) = (d[o].toInt() and 0xFF) or ((d[o + 1].toInt() and 0xFF) shl 8)
    private fun idxVal(d: ByteArray, o: Int, n: Int): Int = if (n == 1) d[o].toInt() and 0xFF else u16(d, o)
    private fun px(d: ByteArray, o: Int, n: Int, bits: Int): Int = when (n) {
        4 -> (bits.let { (d[o + 3].toInt() and 0xFF) shl 24 }) or ((d[o + 2].toInt() and 0xFF) shl 16) or ((d[o + 1].toInt() and 0xFF) shl 8) or (d[o].toInt() and 0xFF)
        3 -> (0xFF shl 24) or ((d[o + 2].toInt() and 0xFF) shl 16) or ((d[o + 1].toInt() and 0xFF) shl 8) or (d[o].toInt() and 0xFF)
        2 -> { val v = u16(d, o); val r = ((v shr 10) and 31) * 255 / 31; val g = ((v shr 5) and 31) * 255 / 31; val b = (v and 31) * 255 / 31
               (0xFF shl 24) or (r shl 16) or (g shl 8) or b }
        else -> 0
    }
}
