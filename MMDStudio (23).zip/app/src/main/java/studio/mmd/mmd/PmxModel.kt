package studio.mmd.mmd

/** Modelo PMX já interpretado (coordenadas originais do MMD, mão esquerda). */
class PmxModel(
    val name: String,
    val version: Float,
    val positions: FloatArray,      // 3 por vértice
    val normals: FloatArray,        // 3 por vértice
    val uvs: FloatArray,            // 2 por vértice
    val boneIndices: IntArray,      // 4 por vértice (-1 = vazio)
    val boneWeights: FloatArray,    // 4 por vértice
    val indices: IntArray,          // triângulos
    val textures: List<String>,
    val materials: List<PmxMaterial>,
    val bones: List<PmxBone>,
    val morphs: List<PmxMorph>,
    val rigidBodies: List<PmxRigid> = emptyList(),
    val joints: List<PmxJoint> = emptyList()
) {
    val vertexCount get() = positions.size / 3
}

class PmxMaterial(
    val name: String, val nameEn: String,
    val diffuse: FloatArray, val specular: FloatArray, val specularPower: Float, val ambient: FloatArray,
    val flags: Int, val edgeColor: FloatArray, val edgeSize: Float,
    val textureIndex: Int, val sphereIndex: Int, val sphereMode: Int,
    val toonShared: Boolean, val toonIndex: Int,
    val indexCount: Int
) { val doubleSided get() = flags and 1 != 0 }

class PmxIkLink(val bone: Int, val hasLimit: Boolean, val min: FloatArray?, val max: FloatArray?)
class PmxIk(val target: Int, val loopCount: Int, val limitAngle: Float, val links: List<PmxIkLink>)

class PmxBone(
    val name: String, val nameEn: String,
    val x: Float, val y: Float, val z: Float,
    val parent: Int, val layer: Int, val flags: Int,
    val tailBone: Int, val inheritParent: Int, val inheritWeight: Float,
    val ik: PmxIk?
)

/** type: 0 grupo, 1 vértice, 2 osso, 3-7 UV, 8 material, 9 flip, 10 impulso. Só 0/1/2/9 guardam dados por enquanto. */
class PmxMorph(
    val name: String, val nameEn: String, val panel: Int, val type: Int,
    val vertexIdx: IntArray? = null, val vertexDelta: FloatArray? = null,
    val boneIdx: IntArray? = null, val boneTrans: FloatArray? = null, val boneRot: FloatArray? = null,
    val groupIdx: IntArray? = null, val groupRate: FloatArray? = null
)

/** Corpo rígido do PMX. mode: 0 segue o osso, 1 física, 2 física + osso. shape: 0 esfera, 1 caixa, 2 cápsula. */
class PmxRigid(
    val name: String, val nameEn: String, val bone: Int, val group: Int, val shape: Int,
    val mass: Float, val linearDamping: Float, val angularDamping: Float, val mode: Int,
    val mask: Int = 0, val size: FloatArray = FloatArray(3), val pos: FloatArray = FloatArray(3), val rot: FloatArray = FloatArray(3),
    val restitution: Float = 0f, val friction: Float = 0.5f
)

/** Junta mola 6-DOF do PMX (a e b = índices de corpos rígidos). */
class PmxJoint(
    val name: String, val a: Int, val b: Int, val pos: FloatArray, val rot: FloatArray,
    val posMin: FloatArray, val posMax: FloatArray, val rotMin: FloatArray, val rotMax: FloatArray,
    val springPos: FloatArray, val springRot: FloatArray
)
