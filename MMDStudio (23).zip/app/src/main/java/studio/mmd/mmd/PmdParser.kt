package studio.mmd.mmd

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/** Leitor de PMD (formato antigo do MMD). Converte para PmxModel; sem corpos rígidos (física ainda não). */
object PmdParser {
    private val SJIS: Charset = Charset.forName("Shift_JIS")

    fun parse(data: ByteArray): PmxModel {
        try { return parseInternal(ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)) }
        catch (e: PmxFormatException) { throw e }
        catch (e: Exception) { throw PmxFormatException("Arquivo PMD truncado ou inválido (${e.javaClass.simpleName})") }
    }

    private fun str(b: ByteBuffer, n: Int): String {
        val a = ByteArray(n); b.get(a)
        var len = a.indexOf(0.toByte()); if (len < 0) len = n
        return String(a, 0, len, SJIS)
    }
    private fun u8(b: ByteBuffer) = b.get().toInt() and 0xFF
    private fun u16(b: ByteBuffer) = b.short.toInt() and 0xFFFF
    private fun cnt(n: Int, max: Int = 5_000_000): Int { if (n < 0 || n > max) throw PmxFormatException("Contagem inválida: $n"); return n }

    private fun parseInternal(b: ByteBuffer): PmxModel {
        val sig = ByteArray(3).also { b.get(it) }
        if (String(sig, Charsets.US_ASCII) != "Pmd") throw PmxFormatException("Não é um arquivo PMD (assinatura inválida)")
        val version = b.float
        val name = str(b, 20); str(b, 256)

        val vc = cnt(b.int)
        val pos = FloatArray(vc * 3); val nrm = FloatArray(vc * 3); val uv = FloatArray(vc * 2)
        val bi = IntArray(vc * 4) { -1 }; val bw = FloatArray(vc * 4)
        for (i in 0 until vc) {
            for (k in 0..2) pos[i * 3 + k] = b.float
            for (k in 0..2) nrm[i * 3 + k] = b.float
            uv[i * 2] = b.float; uv[i * 2 + 1] = b.float
            val b1 = u16(b); val b2 = u16(b); val w = u8(b) / 100f; u8(b)
            bi[i * 4] = b1; bw[i * 4] = w
            bi[i * 4 + 1] = b2; bw[i * 4 + 1] = 1f - w
        }

        val fc = cnt(b.int, 60_000_000)
        if (fc % 3 != 0) throw PmxFormatException("Número de índices não é múltiplo de 3")
        val indices = IntArray(fc) { u16(b) }
        for (ix in indices) if (ix >= vc) throw PmxFormatException("Índice de vértice fora do intervalo")

        // Materiais + texturas
        val texList = ArrayList<String>()
        fun texIdx(n: String): Int { if (n.isEmpty()) return -1; var i = texList.indexOf(n); if (i < 0) { texList.add(n); i = texList.size - 1 }; return i }
        val materials = List(cnt(b.int, 100_000)) { mi ->
            val d = FloatArray(4) { b.float }; val sp = b.float
            val spec = FloatArray(3) { b.float }; val amb = FloatArray(3) { b.float }
            val toon = u8(b); val edge = u8(b); val ic = b.int
            val file = str(b, 20)
            var tex = -1; var sph = -1; var sphMode = 0
            for (part in file.split('*')) {
                val p = part.trim(); if (p.isEmpty()) continue
                when (p.substringAfterLast('.', "").lowercase()) {
                    "sph" -> { sph = texIdx(p); sphMode = 1 }
                    "spa" -> { sph = texIdx(p); sphMode = 2 }
                    else -> tex = texIdx(p)
                }
            }
            val flags = (if (d[3] < 0.999f) 1 else 0) or (if (edge != 0) 0x10 else 0)
            PmxMaterial("mat$mi", "mat$mi", d, spec, sp, amb, flags, floatArrayOf(0f, 0f, 0f, 1f), 1f, tex, sph, sphMode, true, toon.coerceIn(0, 9), ic)
        }

        // Ossos
        class RawBone(val name: String, val parent: Int, val tail: Int, val type: Int, val ikp: Int, val x: Float, val y: Float, val z: Float)
        val bc = cnt(u16(b))
        val raw = List(bc) { RawBone(str(b, 20), u16(b), u16(b), u8(b), u16(b), b.float, b.float, b.float) }
        fun ok(i: Int) = i in 0 until bc

        val iks = HashMap<Int, PmxIk>()
        val ikc = u16(b)
        for (k in 0 until ikc) {
            val ib = u16(b); val target = u16(b); val chain = u8(b); val loop = u16(b); val lim = b.float
            val links = List(chain) {
                val lb = u16(b)
                val knee = ok(lb) && raw[lb].name.contains("ひざ")
                if (knee) PmxIkLink(lb, true, floatArrayOf(-3.1415927f, 0f, 0f), floatArrayOf(-0.0087f, 0f, 0f))
                else PmxIkLink(lb, false, null, null)
            }
            if (ok(ib)) iks[ib] = PmxIk(target, loop, lim * 4f, links)
        }
        val bones = raw.mapIndexed { i, r ->
            var flags = 0x0002 or 0x0010
            if (r.type != 7) flags = flags or 0x0008
            if (r.type == 1 || r.type == 2) flags = flags or 0x0004
            var tail = -1; var inh = -1; var iw = 0f
            if (r.type == 5 && ok(r.ikp)) { inh = r.ikp; iw = 1f; flags = flags or 0x0100 }
            if (r.type != 9 && r.type != 5 && ok(r.tail)) { tail = r.tail; flags = flags or 0x0001 }
            val ik = iks[i]
            if (ik != null) flags = flags or 0x0020
            PmxBone(r.name, r.name, r.x, r.y, r.z, if (ok(r.parent)) r.parent else -1, 0, flags, tail, inh, iw, ik)
        }

        // Morphs (o primeiro, "base", guarda os índices reais dos vértices)
        val morphs = ArrayList<PmxMorph>()
        val mc = u16(b)
        var base: IntArray? = null
        for (k in 0 until mc) {
            val n = str(b, 20); val c = cnt(b.int); val type = u8(b)
            val idx = IntArray(c); val d = FloatArray(c * 3)
            for (j in 0 until c) { idx[j] = b.int; for (q in 0..2) d[j * 3 + q] = b.float }
            if (type == 0) { base = idx; continue }
            val bs = base ?: continue
            val real = IntArray(c) { bs.getOrElse(idx[it]) { 0 }.coerceIn(0, maxOf(vc - 1, 0)) }
            morphs.add(PmxMorph(n, n, type, 1, vertexIdx = real, vertexDelta = d))
        }
        return PmxModel(name, version, pos, nrm, uv, bi, bw, indices, texList, materials, bones, morphs, emptyList())
    }
}
