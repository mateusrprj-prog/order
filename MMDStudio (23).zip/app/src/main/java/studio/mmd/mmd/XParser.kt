package studio.mmd.mmd

/** Leitor de DirectX .x em TEXTO (formato dos cenários/acessórios do MMD). Converte para PmxModel sem ossos. Binário/comprimido: erro claro. */
object XParser {
    private class Tok(val list: List<String>) { var i = 0
        fun has() = i < list.size
        fun peek() = list.getOrNull(i) ?: ""
        fun next() = list.getOrNull(i++) ?: throw PmxFormatException("Fim inesperado do arquivo .x")
        fun num() = next().toFloat()
        fun int() = next().toFloat().toInt()
        fun skipBlock() { var d = 1; while (has() && d > 0) { when (next()) { "{" -> d++; "}" -> d-- } } }
    }

    private class XMat(val d: FloatArray, val power: Float, val spec: FloatArray, val emis: FloatArray, val tex: String)
    private class Part(val pos: FloatArray, val nrm: FloatArray, val uv: FloatArray, val idx: IntArray, val mat: IntArray, val mats: List<XMat>)

    fun parse(data: ByteArray): PmxModel {
        if (data.size < 16) throw PmxFormatException("Arquivo .x vazio ou inválido")
        val head = String(data, 0, 16, Charsets.US_ASCII)
        if (!head.startsWith("xof ")) throw PmxFormatException("Não é um arquivo .x (assinatura inválida)")
        val fmt = head.substring(8, 12)
        if (fmt != "txt ") throw PmxFormatException(".x em formato \"$fmt\" ainda não é suportado; salve como .x de TEXTO (ou use .pmx).")
        val text = String(data, 16, data.size - 16, Charsets.ISO_8859_1)
        val tok = Tok(tokenize(text))
        val named = HashMap<String, XMat>()
        val parts = ArrayList<Part>()
        try { top(tok, named, parts, identity()) } catch (e: PmxFormatException) { throw e }
        catch (e: Exception) { if (parts.isEmpty()) throw PmxFormatException("Arquivo .x truncado ou inválido (${e.javaClass.simpleName})") }
        if (parts.isEmpty()) throw PmxFormatException("Nenhuma malha (Mesh) encontrada no .x")
        return build(parts)
    }

    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>(s.length / 4)
        var i = 0; val n = s.length
        while (i < n) {
            val c = s[i]
            when {
                c == '/' && i + 1 < n && s[i + 1] == '/' || c == '#' -> { while (i < n && s[i] != '\n') i++ }
                c <= ' ' || c == ';' || c == ',' -> i++
                c == '{' || c == '}' -> { out.add(c.toString()); i++ }
                c == '"' -> { val j = s.indexOf('"', i + 1).let { if (it < 0) n else it }; out.add("\"" + s.substring(i + 1, j)); i = j + 1 }
                else -> { var j = i; while (j < n && s[j] > ' ' && s[j] != ';' && s[j] != ',' && s[j] != '{' && s[j] != '}' && s[j] != '"') j++; out.add(s.substring(i, j)); i = j }
            }
        }
        return out
    }

    private fun identity() = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    /** Vetor-linha: v' = v * M (convenção do DirectX). */
    private fun mul(a: FloatArray, b: FloatArray): FloatArray { // a depois b: a * b
        val r = FloatArray(16)
        for (i in 0..3) for (j in 0..3) { var s = 0f; for (k in 0..3) s += a[i * 4 + k] * b[k * 4 + j]; r[i * 4 + j] = s }
        return r
    }

    /** Lê blocos de nível superior e Frames (aninhados), acumulando a matriz do Frame. */
    private fun top(t: Tok, named: HashMap<String, XMat>, parts: ArrayList<Part>, m: FloatArray) {
        while (t.has()) {
            val type = t.next()
            if (type == "}") return
            if (type == "{") { t.skipBlock(); continue }
            var name = ""
            if (t.peek() != "{") name = t.next()
            if (t.peek() != "{") continue
            t.next()
            when (type) {
                "Frame" -> frame(t, named, parts, m)
                "Mesh" -> parts.add(mesh(t, named, m))
                "Material" -> { named[name] = material(t) }
                else -> t.skipBlock()
            }
        }
    }

    private fun frame(t: Tok, named: HashMap<String, XMat>, parts: ArrayList<Part>, parent: FloatArray) {
        var m = parent
        while (t.has()) {
            val type = t.next()
            if (type == "}") return
            if (type == "{") { t.skipBlock(); continue }
            var name = ""
            if (t.peek() != "{") name = t.next()
            if (t.peek() != "{") continue
            t.next()
            when (type) {
                "FrameTransformMatrix" -> { val l = FloatArray(16) { t.num() }; m = mul(l, parent); t.skipBlock() }
                "Frame" -> frame(t, named, parts, m)
                "Mesh" -> parts.add(mesh(t, named, m))
                "Material" -> named[name] = material(t)
                else -> t.skipBlock()
            }
        }
    }

    private fun material(t: Tok): XMat {
        val d = FloatArray(4) { t.num() }; val p = t.num()
        val s = FloatArray(3) { t.num() }; val e = FloatArray(3) { t.num() }
        var tex = ""
        while (t.has()) {
            val ty = t.next()
            if (ty == "}") break
            if (ty == "{") { t.skipBlock(); continue }
            if (t.peek() != "{") t.next()
            t.next()
            if (ty == "TextureFilename") { tex = t.next().removePrefix("\""); t.skipBlock() } else t.skipBlock()
        }
        return XMat(d, p, s, e, tex)
    }

    private fun mesh(t: Tok, named: HashMap<String, XMat>, m: FloatArray): Part {
        val vc = t.int()
        if (vc < 0 || vc > 5_000_000) throw PmxFormatException("Malha .x inválida")
        val pos = FloatArray(vc * 3)
        for (i in 0 until vc) {
            val x = t.num(); val y = t.num(); val z = t.num()
            pos[i * 3] = x * m[0] + y * m[4] + z * m[8] + m[12]
            pos[i * 3 + 1] = x * m[1] + y * m[5] + z * m[9] + m[13]
            pos[i * 3 + 2] = x * m[2] + y * m[6] + z * m[10] + m[14]
        }
        val fc = t.int()
        val faces = ArrayList<IntArray>(fc)
        for (i in 0 until fc) { val k = t.int(); faces.add(IntArray(k) { t.int() }) }
        var nrm: FloatArray? = null; var nFaces: List<IntArray>? = null
        var uv: FloatArray? = null
        var matIdx: IntArray? = null; val mats = ArrayList<XMat>()
        while (t.has()) {
            val ty = t.next()
            if (ty == "}") break
            if (ty == "{") { t.skipBlock(); continue }
            if (t.peek() != "{") t.next()
            t.next()
            when (ty) {
                "MeshNormals" -> {
                    val nc = t.int(); val a = FloatArray(nc * 3)
                    for (i in 0 until nc) { val x = t.num(); val y = t.num(); val z = t.num()
                        a[i * 3] = x * m[0] + y * m[4] + z * m[8]; a[i * 3 + 1] = x * m[1] + y * m[5] + z * m[9]; a[i * 3 + 2] = x * m[2] + y * m[6] + z * m[10] }
                    val nf = t.int(); nFaces = List(nf) { val k = t.int(); IntArray(k) { t.int() } }
                    nrm = a; t.skipBlock()
                }
                "MeshTextureCoords" -> { val uc = t.int(); uv = FloatArray(uc * 2) { t.num() }; t.skipBlock() }
                "MeshMaterialList" -> {
                    val nm = t.int(); val ni = t.int()
                    matIdx = IntArray(ni) { t.int() }
                    var depth = 0
                    while (t.has()) {
                        val x = t.next()
                        if (x == "}") { if (depth == 0) break else depth-- ; continue }
                        if (x == "{") { // referência {Nome}
                            val nm2 = t.next(); named[nm2]?.let { mats.add(it) }; if (t.peek() == "}") t.next(); continue
                        }
                        if (x == "Material") { if (t.peek() != "{") t.next(); t.next(); mats.add(material(t)) }
                    }
                    if (mats.isEmpty() && nm > 0) mats.add(XMat(floatArrayOf(1f, 1f, 1f, 1f), 0f, FloatArray(3), FloatArray(3), ""))
                }
                else -> t.skipBlock()
            }
        }
        // expande cada canto de face (posição, normal, uv) e triangula em leque; agrupa por material depois
        val outP = ArrayList<Float>(); val outN = ArrayList<Float>(); val outU = ArrayList<Float>(); val outM = ArrayList<Int>()
        // acumula normais por vértice caso não haja MeshNormals
        val auto = FloatArray(vc * 3)
        if (nrm == null) for (f in faces) if (f.size >= 3) {
            val a = f[0]; val b = f[1]; val c = f[2]
            val ux = pos[b * 3] - pos[a * 3]; val uy = pos[b * 3 + 1] - pos[a * 3 + 1]; val uz = pos[b * 3 + 2] - pos[a * 3 + 2]
            val vx = pos[c * 3] - pos[a * 3]; val vy = pos[c * 3 + 1] - pos[a * 3 + 1]; val vz = pos[c * 3 + 2] - pos[a * 3 + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            // DirectX é horário em mão esquerda: inverte para apontar para fora
            for (v in f) { auto[v * 3] -= nx; auto[v * 3 + 1] -= ny; auto[v * 3 + 2] -= nz }
        }
        for ((fi, f) in faces.withIndex()) {
            if (f.size < 3) continue
            val mi = matIdx?.getOrNull(fi) ?: 0
            for (k in 1 until f.size - 1) {
                for (corner in intArrayOf(0, k, k + 1)) {
                    val vi = f[corner]
                    if (vi !in 0 until vc) throw PmxFormatException("Índice de vértice inválido no .x")
                    outP.add(pos[vi * 3]); outP.add(pos[vi * 3 + 1]); outP.add(pos[vi * 3 + 2])
                    val nf = nFaces?.getOrNull(fi); val na = nrm
                    if (na != null && nf != null && corner < nf.size && nf[corner] in 0 until na.size / 3) {
                        val ni = nf[corner]
                        outN.add(na[ni * 3]); outN.add(na[ni * 3 + 1]); outN.add(na[ni * 3 + 2])
                    } else {
                        var x = auto[vi * 3]; var y = auto[vi * 3 + 1]; var z = auto[vi * 3 + 2]
                        val l = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                        if (l > 1e-8f) { x /= l; y /= l; z /= l } else { x = 0f; y = 1f; z = 0f }
                        outN.add(x); outN.add(y); outN.add(z)
                    }
                    val u = uv
                    if (u != null && vi * 2 + 1 < u.size) { outU.add(u[vi * 2]); outU.add(u[vi * 2 + 1]) } else { outU.add(0f); outU.add(0f) }
                    outM.add(mi)
                }
            }
        }
        val cn = outP.size / 3
        return Part(outP.toFloatArray(), outN.toFloatArray(), outU.toFloatArray(), IntArray(cn) { it }, outM.toIntArray(), mats)
    }

    private fun build(parts: List<Part>): PmxModel {
        val pos = ArrayList<Float>(); val nrm = ArrayList<Float>(); val uvs = ArrayList<Float>()
        val tex = ArrayList<String>(); val materials = ArrayList<PmxMaterial>(); val indices = ArrayList<Int>()
        var base = 0
        fun ti(n: String): Int { if (n.isEmpty()) return -1; var i = tex.indexOf(n); if (i < 0) { tex.add(n); i = tex.size - 1 }; return i }
        for (p in parts) {
            val cn = p.mat.size  // um item por canto; cantos de 3 em 3 formam um triângulo
            val tris = cn / 3
            val nm = maxOf(p.mats.size, 1)
            for (mi in 0 until nm) {
                val xm = p.mats.getOrNull(mi) ?: XMat(floatArrayOf(1f, 1f, 1f, 1f), 0f, FloatArray(3), FloatArray(3), "")
                var count = 0
                for (tr in 0 until tris) {
                    val mt = p.mat[tr * 3].coerceIn(0, nm - 1)
                    if (mt != mi) continue
                    for (c in 0..2) indices.add(base + tr * 3 + c)
                    count += 3
                }
                if (count == 0) continue
                materials.add(PmxMaterial("mat${materials.size}", "mat${materials.size}", xm.d, xm.spec, xm.power,
                    floatArrayOf(xm.d[0], xm.d[1], xm.d[2]), 1, floatArrayOf(0f, 0f, 0f, 1f), 1f, ti(xm.tex.replace('\\', '/').substringAfterLast('/')), -1, 0, true, 0, count))
            }
            for (v in p.pos) pos.add(v); for (v in p.nrm) nrm.add(v); for (v in p.uv) uvs.add(v)
            base += cn
        }
        // reordena os índices por material já está garantido pela ordem de criação dos materiais acima
        return PmxModel("x", 1f, pos.toFloatArray(), nrm.toFloatArray(), uvs.toFloatArray(), IntArray(base * 0) , FloatArray(0),
            indices.toIntArray(), tex, materials, emptyList(), emptyList())
    }
}
