package studio.mmd.mmd

import kotlin.math.*
import studio.mmd.edit.Euler
import studio.mmd.rig.CType
import studio.mmd.rig.Constraint
import studio.mmd.rig.RigState
import studio.mmd.rig.Secondary

/**
 * Avalia a pose do modelo em um frame: amostra o VMD (Bézier/slerp), aplica morphs, FK, IK (CCD com limites),
 * "append" de rotação/translação (ossos D/twist) e skinning linear (BDEF1/2/4; SDEF tratado como BDEF2) na CPU.
 * Trabalha em coordenadas MMD; a saída já é convertida para GL (Z invertido, escala).
 */
/** Pool compartilhado para o skinning em CPU (usa até 4 threads; o resto do trabalho fica na thread GL). */
private object SkinPool {
    val threads = (Runtime.getRuntime().availableProcessors()).coerceIn(1, 4)
    val ex: java.util.concurrent.ExecutorService = java.util.concurrent.Executors.newFixedThreadPool(maxOf(1, threads - 1)) { r ->
        Thread(r, "skin").apply { isDaemon = true }
    }
}

class Animator(private val m: PmxModel, private val scale: Float) {
    @Volatile var motion: VmdMotion? = null
        set(v) { field = v; bind(v) }

    private val n = m.bones.size
    private val bpos = FloatArray(n * 3)
    private val rot = FloatArray(n * 4); private val tr = FloatArray(n * 3)
    private val rotF = FloatArray(n * 4); private val trF = FloatArray(n * 3)
    private val gq = FloatArray(n * 4); private val gt = FloatArray(n * 3)
    private val mat = FloatArray(n * 12)
    private val work = FloatArray(m.positions.size)
    private val tracks = arrayOfNulls<VmdTrack>(n)
    private val mTracks = arrayOfNulls<VmdMorphTrack>(m.morphs.size)
    private val sQ = FloatArray(4); private val sQ2 = FloatArray(4)
    private val v1 = FloatArray(3); private val v2 = FloatArray(3)

    init { for (i in 0 until n) { bpos[i * 3] = m.bones[i].x; bpos[i * 3 + 1] = m.bones[i].y; bpos[i * 3 + 2] = m.bones[i].z } }

    private val topo: IntArray = run {
        val order = (0 until n).sortedWith(compareBy<Int>({ m.bones[it].layer }, { it }))
        val seen = BooleanArray(n); val res = ArrayList<Int>(n)
        fun visit(b: Int) {
            if (b !in 0 until n || seen[b]) return
            seen[b] = true
            visit(m.bones[b].parent); visit(m.bones[b].inheritParent)
            res.add(b)
        }
        for (b in order) visit(b)
        res.toIntArray()
    }

    private fun bind(mo: VmdMotion?) {
        secLast = Float.NaN
        for (i in 0 until n) tracks[i] = mo?.bones?.get(m.bones[i].name)
        for (i in m.morphs.indices) mTracks[i] = mo?.morphs?.get(m.morphs[i].name)
    }

    // ---------- matemática de quaternions (x,y,z,w em arrays) ----------
    private fun qmul(a: FloatArray, ao: Int, b: FloatArray, bo: Int, o: FloatArray, oo: Int) {
        val ax = a[ao]; val ay = a[ao + 1]; val az = a[ao + 2]; val aw = a[ao + 3]
        val bx = b[bo]; val by = b[bo + 1]; val bz = b[bo + 2]; val bw = b[bo + 3]
        o[oo] = aw * bx + ax * bw + ay * bz - az * by
        o[oo + 1] = aw * by - ax * bz + ay * bw + az * bx
        o[oo + 2] = aw * bz + ax * by - ay * bx + az * bw
        o[oo + 3] = aw * bw - ax * bx - ay * by - az * bz
    }

    /** Rotaciona o vetor (vx,vy,vz) por q (ou pelo conjugado) e escreve o resultado em o a partir de oo. */
    private fun qrot(q: FloatArray, qo: Int, vx: Float, vy: Float, vz: Float, conj: Boolean, o: FloatArray, oo: Int) {
        val x = q[qo] * (if (conj) -1f else 1f); val y = q[qo + 1] * (if (conj) -1f else 1f); val z = q[qo + 2] * (if (conj) -1f else 1f); val w = q[qo + 3]
        val tx = 2 * (y * vz - z * vy); val ty = 2 * (z * vx - x * vz); val tz = 2 * (x * vy - y * vx)
        o[oo] = vx + w * tx + (y * tz - z * ty)
        o[oo + 1] = vy + w * ty + (z * tx - x * tz)
        o[oo + 2] = vz + w * tz + (x * ty - y * tx)
    }

    /** q^w (potência), caminho mais curto. */
    private fun qpow(q: FloatArray, qo: Int, w: Float, o: FloatArray) {
        var x = q[qo]; var y = q[qo + 1]; var z = q[qo + 2]; var qw = q[qo + 3]
        if (qw < 0) { x = -x; y = -y; z = -z; qw = -qw }
        val len = sqrt(x * x + y * y + z * z)
        if (len < 1e-8f) { o[0] = 0f; o[1] = 0f; o[2] = 0f; o[3] = 1f; return }
        val ang = 2 * atan2(len, qw) * w
        val s = sin(ang / 2) / len
        o[0] = x * s; o[1] = y * s; o[2] = z * s; o[3] = cos(ang / 2)
    }

    private fun bez(ip: ByteArray, i1: Int, i2: Int, i3: Int, i4: Int, s: Float): Float {
        val x1 = (ip[i1].toInt() and 0xFF) / 127f; val y1 = (ip[i2].toInt() and 0xFF) / 127f
        val x2 = (ip[i3].toInt() and 0xFF) / 127f; val y2 = (ip[i4].toInt() and 0xFF) / 127f
        if (x1 == y1 && x2 == y2) return s
        var lo = 0f; var hi = 1f; var t = s
        for (k in 0 until 18) {
            t = (lo + hi) / 2
            val u = 1 - t
            val x = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t
            if (x < s) lo = t else hi = t
        }
        val u = 1 - t
        return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t
    }

    private fun find(frames: IntArray, f: Float): Int {
        var lo = 0; var hi = frames.size - 1; var r = -1
        while (lo <= hi) { val mid = (lo + hi) ushr 1; if (frames[mid] <= f) { r = mid; lo = mid + 1 } else hi = mid - 1 }
        return r
    }

    private fun sampleBone(t: VmdTrack, f: Float, b: Int) {
        val i = find(t.frames, f)
        if (i < 0 || i == t.frames.size - 1) {
            val a = (if (i < 0) 0 else i) * 7
            for (c in 0..2) tr[b * 3 + c] = t.v[a + c]
            for (c in 0..3) rot[b * 4 + c] = t.v[a + 3 + c]
            return
        }
        val a = i * 7; val bb = (i + 1) * 7; val ip = (i + 1) * 16
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i])
        val sx = bez(t.ip, ip, ip + 4, ip + 8, ip + 12, s)
        val sy = bez(t.ip, ip + 1, ip + 5, ip + 9, ip + 13, s)
        val sz = bez(t.ip, ip + 2, ip + 6, ip + 10, ip + 14, s)
        val sr = bez(t.ip, ip + 3, ip + 7, ip + 11, ip + 15, s)
        tr[b * 3] = t.v[a] + (t.v[bb] - t.v[a]) * sx
        tr[b * 3 + 1] = t.v[a + 1] + (t.v[bb + 1] - t.v[a + 1]) * sy
        tr[b * 3 + 2] = t.v[a + 2] + (t.v[bb + 2] - t.v[a + 2]) * sz
        var dot = 0f
        for (c in 0..3) dot += t.v[a + 3 + c] * t.v[bb + 3 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) {
            val q = t.v[a + 3 + c] * (1 - sr) + t.v[bb + 3 + c] * sg * sr
            rot[b * 4 + c] = q; len += q * q
        }
        len = sqrt(len); if (len > 1e-8f) for (c in 0..3) rot[b * 4 + c] /= len
    }

    private fun sampleMorph(t: VmdMorphTrack, f: Float): Float {
        val i = find(t.frames, f)
        if (i < 0) return t.w[0]
        if (i == t.frames.size - 1) return t.w[i]
        val s = (f - t.frames[i]) / (t.frames[i + 1] - t.frames[i])
        return t.w[i] + (t.w[i + 1] - t.w[i]) * s
    }

    private fun applyMorph(mi: Int, w: Float, depth: Int) {
        val mo = m.morphs[mi]
        when (mo.type) {
            0 -> if (depth < 4) mo.groupIdx?.forEachIndexed { k, c -> if (c in m.morphs.indices) applyMorph(c, w * mo.groupRate!![k], depth + 1) }
            1 -> { val idx = mo.vertexIdx!!; val d = mo.vertexDelta!!
                for (k in idx.indices) { val v = idx[k]; if (v < 0 || v * 3 + 2 >= work.size) continue
                    work[v * 3] += d[k * 3] * w; work[v * 3 + 1] += d[k * 3 + 1] * w; work[v * 3 + 2] += d[k * 3 + 2] * w } }
            2 -> { val idx = mo.boneIdx!!
                for (k in idx.indices) { val b = idx[k]; if (b !in 0 until n) continue
                    for (c in 0..2) tr[b * 3 + c] += mo.boneTrans!![k * 3 + c] * w
                    System.arraycopy(mo.boneRot!!, k * 4, sQ2, 0, 4)
                    qpow(sQ2, 0, w, sQ); qmul(rot, b * 4, sQ, 0, sQ2, 0); System.arraycopy(sQ2, 0, rot, b * 4, 4) } }
        }
    }

    // ---------- esqueleto ----------
    private fun global(b: Int, append: Boolean) {
        val bone = m.bones[b]
        System.arraycopy(rot, b * 4, sQ, 0, 4)
        var tx = tr[b * 3]; var ty = tr[b * 3 + 1]; var tz = tr[b * 3 + 2]
        val s = bone.inheritParent
        if (append && s in 0 until n && s != b && bone.inheritWeight != 0f) {
            if (bone.flags and 0x0100 != 0) { qpow(rotF, s * 4, bone.inheritWeight, sQ2); qmul(sQ, 0, sQ2, 0, sQ, 0) }
            if (bone.flags and 0x0200 != 0) { tx += trF[s * 3] * bone.inheritWeight; ty += trF[s * 3 + 1] * bone.inheritWeight; tz += trF[s * 3 + 2] * bone.inheritWeight }
        }
        System.arraycopy(sQ, 0, rotF, b * 4, 4)
        trF[b * 3] = tx; trF[b * 3 + 1] = ty; trF[b * 3 + 2] = tz
        val p = bone.parent
        if (p !in 0 until n || p == b) {
            System.arraycopy(sQ, 0, gq, b * 4, 4)
            gt[b * 3] = bone.x + tx; gt[b * 3 + 1] = bone.y + ty; gt[b * 3 + 2] = bone.z + tz
        } else {
            val ox = bone.x - bpos[p * 3] + tx; val oy = bone.y - bpos[p * 3 + 1] + ty; val oz = bone.z - bpos[p * 3 + 2] + tz
            qrot(gq, p * 4, ox, oy, oz, false, gt, b * 3)
            gt[b * 3] += gt[p * 3]; gt[b * 3 + 1] += gt[p * 3 + 1]; gt[b * 3 + 2] += gt[p * 3 + 2]
            qmul(gq, p * 4, sQ, 0, gq, b * 4)
        }
    }

    private fun refreshChain(ik: PmxIk) {
        for (k in ik.links.indices.reversed()) { val lb = ik.links[k].bone; if (lb in 0 until n) global(lb, false) }
        val stack = ArrayList<Int>(); var b = ik.target
        while (b in 0 until n && ik.links.none { it.bone == b } && stack.size < 64) { stack.add(b); b = m.bones[b].parent }
        for (k in stack.indices.reversed()) global(stack[k], false)
    }

    private fun solveIk(ikBone: Int, ik: PmxIk) {
        val tb = ik.target
        if (tb !in 0 until n) return
        for (iter in 0 until min(ik.loopCount, 64)) {
            for (link in ik.links) {
                val lb = link.bone
                if (lb !in 0 until n) continue
                qrot(gq, lb * 4, gt[tb * 3] - gt[lb * 3], gt[tb * 3 + 1] - gt[lb * 3 + 1], gt[tb * 3 + 2] - gt[lb * 3 + 2], true, v1, 0)
                qrot(gq, lb * 4, gt[ikBone * 3] - gt[lb * 3], gt[ikBone * 3 + 1] - gt[lb * 3 + 1], gt[ikBone * 3 + 2] - gt[lb * 3 + 2], true, v2, 0)
                val l1 = sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2]); val l2 = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
                if (l1 < 1e-8f || l2 < 1e-8f) continue
                for (c in 0..2) { v1[c] /= l1; v2[c] /= l2 }
                val dot = (v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]).coerceIn(-1f, 1f)
                if (dot > 0.999999f) continue
                val ang = min(acos(dot), ik.limitAngle)
                var ax = v1[1] * v2[2] - v1[2] * v2[1]; var ay = v1[2] * v2[0] - v1[0] * v2[2]; var az = v1[0] * v2[1] - v1[1] * v2[0]
                val al = sqrt(ax * ax + ay * ay + az * az)
                if (al < 1e-8f) continue
                ax /= al; ay /= al; az /= al
                val mn = link.min; val mx = link.max
                if (link.hasLimit && mn != null && mx != null && mn[1] == 0f && mx[1] == 0f && mn[2] == 0f && mx[2] == 0f) {
                    ax = if (ax >= 0) 1f else -1f; ay = 0f; az = 0f
                }
                val sn = sin(ang / 2)
                sQ[0] = ax * sn; sQ[1] = ay * sn; sQ[2] = az * sn; sQ[3] = cos(ang / 2)
                qmul(rot, lb * 4, sQ, 0, sQ2, 0)
                System.arraycopy(sQ2, 0, rot, lb * 4, 4)
                if (link.hasLimit && mn != null && mx != null) clampRotVec(lb, mn, mx)
                refreshChain(ik)
            }
            val dx = gt[tb * 3] - gt[ikBone * 3]; val dy = gt[tb * 3 + 1] - gt[ikBone * 3 + 1]; val dz = gt[tb * 3 + 2] - gt[ikBone * 3 + 2]
            if (dx * dx + dy * dy + dz * dz < 1e-8f) break
        }
    }

    private fun clampRotVec(b: Int, mn: FloatArray, mx: FloatArray) {
        var x = rot[b * 4]; var y = rot[b * 4 + 1]; var z = rot[b * 4 + 2]; var w = rot[b * 4 + 3]
        if (w < 0) { x = -x; y = -y; z = -z; w = -w }
        val len = sqrt(x * x + y * y + z * z)
        if (len < 1e-8f) return
        val ang = 2 * atan2(len, w)
        val rx = (x / len * ang).coerceIn(min(mn[0], mx[0]), max(mn[0], mx[0]))
        val ry = (y / len * ang).coerceIn(min(mn[1], mx[1]), max(mn[1], mx[1]))
        val rz = (z / len * ang).coerceIn(min(mn[2], mx[2]), max(mn[2], mx[2]))
        val a2 = sqrt(rx * rx + ry * ry + rz * rz)
        if (a2 < 1e-8f) { rot[b * 4] = 0f; rot[b * 4 + 1] = 0f; rot[b * 4 + 2] = 0f; rot[b * 4 + 3] = 1f; return }
        val s = sin(a2 / 2) / a2
        rot[b * 4] = rx * s; rot[b * 4 + 1] = ry * s; rot[b * 4 + 2] = rz * s; rot[b * 4 + 3] = cos(a2 / 2)
    }

    /** Posição global (já em coordenadas GL) de cada osso após o último evaluate(). Chamar só na thread GL. */
    fun boneGl(out: FloatArray) {
        for (b in 0 until n) {
            out[b * 3] = gt[b * 3] * scale
            out[b * 3 + 1] = gt[b * 3 + 1] * scale
            out[b * 3 + 2] = -gt[b * 3 + 2] * scale
        }
    }

    /** Matriz 4x4 (coluna-maior, coordenadas GL) da transformação global do osso [b] após o último evaluate(). Thread GL. */
    fun boneMatrixGl(b: Int, o: FloatArray) {
        val x = -gq[b * 4]; val y = -gq[b * 4 + 1]; val z = gq[b * 4 + 2]; val w = gq[b * 4 + 3]
        o[0] = 1 - 2 * (y * y + z * z); o[1] = 2 * (x * y + z * w); o[2] = 2 * (x * z - y * w); o[3] = 0f
        o[4] = 2 * (x * y - z * w); o[5] = 1 - 2 * (x * x + z * z); o[6] = 2 * (y * z + x * w); o[7] = 0f
        o[8] = 2 * (x * z + y * w); o[9] = 2 * (y * z - x * w); o[10] = 1 - 2 * (x * x + y * y); o[11] = 0f
        o[12] = gt[b * 3] * scale; o[13] = gt[b * 3 + 1] * scale; o[14] = -gt[b * 3 + 2] * scale; o[15] = 1f
    }

    /** Rotaciona o vetor (coordenadas MMD, espaço global) para o espaço local do pai do osso [b]. Thread GL, após evaluate(). */
    fun toParentSpace(b: Int, vx: Float, vy: Float, vz: Float, out: FloatArray) {
        val p = m.bones[b].parent
        if (p !in 0 until n || p == b) { out[0] = vx; out[1] = vy; out[2] = vz }
        else qrot(gq, p * 4, vx, vy, vz, true, out, 0)
    }

    /** Calcula a pose em [frame] e escreve posição/normal (offsets 0..5 de cada vértice de 8 floats) em [out]. */
    fun evaluate(frame: Float, out: FloatArray) {
        pose(frame)
        buildMatrices()
        skin(out)
    }

    /** Só a pose (FK, IK, morphs de osso, append), sem skinning. Usado na exportação; depois leia com [local]. */
    fun evaluatePose(frame: Float) = pose(frame)

    /**
     * Transformação local do osso [b] em relação ao pai, em coordenadas MMD, após evaluatePose/evaluate.
     * o[0..2] = translação (já inclui o offset de repouso), o[3..6] = quaternion xyzw.
     */
    fun local(b: Int, o: FloatArray) {
        val p = m.bones[b].parent
        if (p !in 0 until n || p == b) {
            o[0] = gt[b * 3]; o[1] = gt[b * 3 + 1]; o[2] = gt[b * 3 + 2]
            for (c in 0..3) o[3 + c] = gq[b * 4 + c]
        } else {
            qrot(gq, p * 4, gt[b * 3] - gt[p * 3], gt[b * 3 + 1] - gt[p * 3 + 1], gt[b * 3 + 2] - gt[p * 3 + 2], true, o, 0)
            sQ[0] = -gq[p * 4]; sQ[1] = -gq[p * 4 + 1]; sQ[2] = -gq[p * 4 + 2]; sQ[3] = gq[p * 4 + 3]
            qmul(sQ, 0, gq, b * 4, o, 3)
        }
    }

    /** Pose em [frame]. Com movimento secundário ligado, avança a simulação (ou reaquece após um salto na timeline). */
    private fun pose(frame: Float) {
        syncSecondary()
        val sim = hasSec || physOn()
        if (!sim) { secLast = Float.NaN; secDt = 0f; phys?.reset(); poseCore(frame); return }
        if (secLast.isNaN() || frame < secLast - 1e-4f || frame - secLast > 4f) {
            java.util.Arrays.fill(secInit, false); phys?.reset()
            var f = max(0f, frame - 12f)
            secDt = 0f; poseCore(f)
            while (frame - f > 1e-3f) { val nf = min(f + 1f, frame); secDt = (nf - f) / 30f; poseCore(nf); f = nf }
            secLast = frame
            return
        }
        secDt = if (frame == secLast) 0f else (frame - secLast) / 30f
        poseCore(frame); secLast = frame
    }

    // ---------- movimento secundário (mola sobre a rotação global do osso) ----------
    private class SC(val k: Float, val c: Float, val inten: Float)
    private var secSrc: List<Secondary>? = null
    private var secBy: Array<SC?> = arrayOfNulls(n)
    private var hasSec = false
    private var secLast = Float.NaN
    private var secDt = 0f
    private val secS = FloatArray(n * 4); private val secW = FloatArray(n * 3); private val secInit = BooleanArray(n)
    private val tq = FloatArray(4); private val eq = FloatArray(4); private val rq = FloatArray(4)

    private fun syncSecondary() {
        val src = RigState.secondary
        if (src === secSrc) return
        secSrc = src; secBy = arrayOfNulls(n); hasSec = false; secLast = Float.NaN
        java.util.Arrays.fill(secInit, false)
        for (g in src) {
            if (!g.enabled) continue
            val set = HashSet<Int>()
            for (nm in g.bones) boneIdx[nm]?.let { set.add(it) }
            for (b in set) {
                var depth = 0; var p = m.bones[b].parent
                while (p in 0 until n && depth < 64) { if (p in set) depth++; p = m.bones[p].parent }
                val k = g.stiffness.coerceIn(5f, 1000f) / (1f + g.delay.coerceIn(0f, 1f) * depth)
                secBy[b] = SC(k, 2f * g.damping.coerceIn(0f, 2f) * sqrt(k), g.intensity.coerceIn(0f, 1f))
                hasSec = true
            }
        }
    }

    private fun applySec(b: Int, sc: SC) {
        val p = m.bones[b].parent
        val hasP = p in 0 until n && p != b
        if (hasP) qmul(gq, p * 4, rot, b * 4, tq, 0) else System.arraycopy(rot, b * 4, tq, 0, 4)
        if (!secInit[b]) {
            System.arraycopy(tq, 0, secS, b * 4, 4)
            secW[b * 3] = 0f; secW[b * 3 + 1] = 0f; secW[b * 3 + 2] = 0f; secInit[b] = true
        } else if (secDt > 0f) {
            val ns = max(1, ceil(secDt * 240f).toInt()); val h = secDt / ns
            for (step in 0 until ns) {
                eq[0] = -secS[b * 4]; eq[1] = -secS[b * 4 + 1]; eq[2] = -secS[b * 4 + 2]; eq[3] = secS[b * 4 + 3]
                qmul(tq, 0, eq, 0, rq, 0)
                if (rq[3] < 0) for (c in 0..3) rq[c] = -rq[c]
                val sl = sqrt(rq[0] * rq[0] + rq[1] * rq[1] + rq[2] * rq[2])
                if (sl > 1e-6f) {
                    val ax = rq[0] / sl; val ay = rq[1] / sl; val az = rq[2] / sl
                    var ang = 2f * atan2(sl, rq[3])
                    if (ang > 1.2f) {
                        val ex = ang - 1.2f; val sn = sin(ex / 2)
                        eq[0] = ax * sn; eq[1] = ay * sn; eq[2] = az * sn; eq[3] = cos(ex / 2)
                        qmul(eq, 0, secS, b * 4, secS, b * 4); ang = 1.2f
                    }
                    val acc = sc.k * ang
                    secW[b * 3] += (acc * ax - sc.c * secW[b * 3]) * h
                    secW[b * 3 + 1] += (acc * ay - sc.c * secW[b * 3 + 1]) * h
                    secW[b * 3 + 2] += (acc * az - sc.c * secW[b * 3 + 2]) * h
                } else {
                    val f = max(0f, 1f - sc.c * h)
                    secW[b * 3] *= f; secW[b * 3 + 1] *= f; secW[b * 3 + 2] *= f
                }
                var wx = secW[b * 3]; var wy = secW[b * 3 + 1]; var wz = secW[b * 3 + 2]
                var wl = sqrt(wx * wx + wy * wy + wz * wz)
                if (wl > 30f) { val f = 30f / wl; wx *= f; wy *= f; wz *= f; wl = 30f; secW[b * 3] = wx; secW[b * 3 + 1] = wy; secW[b * 3 + 2] = wz }
                if (wl > 1e-6f) {
                    val a2 = wl * h; val sn = sin(a2 / 2)
                    eq[0] = wx / wl * sn; eq[1] = wy / wl * sn; eq[2] = wz / wl * sn; eq[3] = cos(a2 / 2)
                    qmul(eq, 0, secS, b * 4, secS, b * 4)
                    val l = sqrt(secS[b * 4] * secS[b * 4] + secS[b * 4 + 1] * secS[b * 4 + 1] + secS[b * 4 + 2] * secS[b * 4 + 2] + secS[b * 4 + 3] * secS[b * 4 + 3])
                    if (l > 1e-8f) for (c in 0..3) secS[b * 4 + c] /= l
                }
            }
        }
        // saída: mistura do alvo (T) com o osso atrasado (S), pelo peso de intensidade
        var dot = 0f
        for (c in 0..3) dot += tq[c] * secS[b * 4 + c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val v = tq[c] * (1 - sc.inten) + secS[b * 4 + c] * sg * sc.inten; rq[c] = v; len += v * v }
        len = sqrt(len)
        if (len < 1e-8f) return
        for (c in 0..3) rq[c] /= len
        if (hasP) { eq[0] = -gq[p * 4]; eq[1] = -gq[p * 4 + 1]; eq[2] = -gq[p * 4 + 2]; eq[3] = gq[p * 4 + 3]; qmul(eq, 0, rq, 0, rot, b * 4) }
        else System.arraycopy(rq, 0, rot, b * 4, 4)
    }

    // ---------- física real (corpos rígidos + juntas do PMX) ----------
    private val phys: studio.mmd.rig.PhysEngine? = try { studio.mmd.rig.PhysEngine.create(m) } catch (e: Throwable) { null }
    private fun physOn() = phys != null && studio.mmd.rig.RigState.phys.enabled

    private fun physStep() {
        val e = phys ?: return
        e.step(secDt, gq, gt, studio.mmd.rig.RigState.phys)
        for (b in topo) {
            global(b, true)
            if (e.driven[b]) {
                System.arraycopy(e.outQ, b * 4, gq, b * 4, 4)
                if (e.full[b]) System.arraycopy(e.outT, b * 3, gt, b * 3, 3)
            }
        }
    }

    private fun poseCore(frame: Float) {
        for (b in 0 until n) {
            rot[b * 4] = 0f; rot[b * 4 + 1] = 0f; rot[b * 4 + 2] = 0f; rot[b * 4 + 3] = 1f
            tr[b * 3] = 0f; tr[b * 3 + 1] = 0f; tr[b * 3 + 2] = 0f
            tracks[b]?.let { sampleBone(it, frame, b) }
        }
        System.arraycopy(m.positions, 0, work, 0, work.size)
        for (i in m.morphs.indices) { val t = mTracks[i] ?: continue; val w = sampleMorph(t, frame); if (w != 0f) applyMorph(i, w, 0) }
        for (b in topo) global(b, false)
        for (b in 0 until n) m.bones[b].ik?.let { solveIk(b, it) }
        syncConstraints()
        if (hasCons || hasSec) { for (b in topo) { consBy[b]?.let { applyCons(b, it) }; secBy[b]?.let { applySec(b, it) }; global(b, true) } }
        else for (b in topo) global(b, true)
        if (physOn()) physStep()
    }

    // ---------- Action Constraints (rig) ----------
    private class CC(val b: Int, val type: Int, val ti: Int, val axis: Int, val w: Float, val mn: List<Float>, val mx: List<Float>)
    private var consSrc: List<Constraint>? = null
    private var consBy: Array<ArrayList<CC>?> = arrayOfNulls(n)
    private var hasCons = false
    private val boneIdx: Map<String, Int> by lazy { HashMap<String, Int>().also { mp -> for (i in 0 until n) mp.putIfAbsent(m.bones[i].name, i) } }
    private val cq = FloatArray(4)

    /** Recompila a lista de restrições (nomes → índices) quando ela muda. */
    private fun syncConstraints() {
        val src = RigState.list
        if (src === consSrc) return
        consSrc = src
        consBy = arrayOfNulls(n); hasCons = false
        for (c in src) {
            if (!c.enabled) continue
            val b = boneIdx[c.bone] ?: continue
            val needT = c.type == CType.LOOK_AT || c.type == CType.COPY_ROT || c.type == CType.COPY_POS
            val ti = if (needT) (boneIdx[c.target] ?: continue) else -1
            if (ti == b) continue
            (consBy[b] ?: ArrayList<CC>().also { consBy[b] = it }).add(CC(b, c.type, ti, c.axis, c.weight.coerceIn(0f, 1f), c.min, c.max))
            hasCons = true
        }
    }

    /** nlerp de rot[b] em direção a q (peso w), caminho mais curto. */
    private fun blendRot(b: Int, q: FloatArray, w: Float) {
        var dot = 0f
        for (c in 0..3) dot += rot[b * 4 + c] * q[c]
        val sg = if (dot < 0) -1f else 1f
        var len = 0f
        for (c in 0..3) { val v = rot[b * 4 + c] * (1 - w) + q[c] * sg * w; cq[c] = v; len += v * v }
        len = sqrt(len)
        if (len < 1e-8f) return
        for (c in 0..3) rot[b * 4 + c] = cq[c] / len
    }

    private fun applyCons(b: Int, list: List<CC>) {
        val bone = m.bones[b]
        for (c in list) when (c.type) {
            CType.LIMIT_ROT -> {
                val e = Euler.euler(floatArrayOf(rot[b * 4], rot[b * 4 + 1], rot[b * 4 + 2], rot[b * 4 + 3]))
                var ch = false
                for (k in 0..2) {
                    val lo = min(c.mn[k], c.mx[k]); val hi = max(c.mn[k], c.mx[k])
                    val v = e[k].coerceIn(lo, hi); if (v != e[k]) { e[k] = v; ch = true }
                }
                if (ch) { val q = Euler.quat(e[0], e[1], e[2]); for (k in 0..3) rot[b * 4 + k] = q[k] }
            }
            CType.LIMIT_POS -> for (k in 0..2) {
                val lo = min(c.mn[k], c.mx[k]); val hi = max(c.mn[k], c.mx[k])
                tr[b * 3 + k] = tr[b * 3 + k].coerceIn(lo, hi)
            }
            CType.COPY_ROT -> blendRot(b, floatArrayOf(rot[c.ti * 4], rot[c.ti * 4 + 1], rot[c.ti * 4 + 2], rot[c.ti * 4 + 3]), c.w)
            CType.COPY_POS -> for (k in 0..2) tr[b * 3 + k] += (tr[c.ti * 3 + k] - tr[b * 3 + k]) * c.w
            CType.LOOK_AT -> {
                val p = bone.parent
                // posição global atual do osso (o pai já foi calculado nesta passada)
                val px: Float; val py: Float; val pz: Float
                if (p !in 0 until n || p == b) { px = bone.x + tr[b * 3]; py = bone.y + tr[b * 3 + 1]; pz = bone.z + tr[b * 3 + 2] }
                else {
                    qrot(gq, p * 4, bone.x - bpos[p * 3] + tr[b * 3], bone.y - bpos[p * 3 + 1] + tr[b * 3 + 1], bone.z - bpos[p * 3 + 2] + tr[b * 3 + 2], false, v1, 0)
                    px = gt[p * 3] + v1[0]; py = gt[p * 3 + 1] + v1[1]; pz = gt[p * 3 + 2] + v1[2]
                }
                val dx = gt[c.ti * 3] - px; val dy = gt[c.ti * 3 + 1] - py; val dz = gt[c.ti * 3 + 2] - pz
                if (p !in 0 until n || p == b) { v2[0] = dx; v2[1] = dy; v2[2] = dz } else qrot(gq, p * 4, dx, dy, dz, true, v2, 0)
                val dl = sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
                if (dl < 1e-6f) continue
                val tx = v2[0] / dl; val ty = v2[1] / dl; val tz = v2[2] / dl
                val ax = when (c.axis) { 0 -> 1f; 1 -> -1f; else -> 0f }
                val ay = when (c.axis) { 2 -> 1f; 3 -> -1f; else -> 0f }
                val az = when (c.axis) { 4 -> 1f; 5 -> -1f; else -> 0f }
                // arco mais curto de (ax,ay,az) até (tx,ty,tz)
                val d = (ax * tx + ay * ty + az * tz).coerceIn(-1f, 1f)
                var qx = ay * tz - az * ty; var qy = az * tx - ax * tz; var qz = ax * ty - ay * tx
                var qw = 1f + d
                if (qw < 1e-6f) { // vetores opostos: gira 180° em torno de um eixo perpendicular
                    if (abs(ax) > 0.5f) { qx = 0f; qy = 1f; qz = 0f } else { qx = 1f; qy = 0f; qz = 0f }
                    qw = 0f
                }
                val ql = sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
                sQ[0] = qx / ql; sQ[1] = qy / ql; sQ[2] = qz / ql; sQ[3] = qw / ql
                blendRot(b, sQ, c.w)
            }
        }
    }

    private fun buildMatrices() {
        for (b in 0 until n) {
            val x = gq[b * 4]; val y = gq[b * 4 + 1]; val z = gq[b * 4 + 2]; val w = gq[b * 4 + 3]
            val o = b * 12
            mat[o] = 1 - 2 * (y * y + z * z); mat[o + 1] = 2 * (x * y - z * w); mat[o + 2] = 2 * (x * z + y * w)
            mat[o + 3] = 2 * (x * y + z * w); mat[o + 4] = 1 - 2 * (x * x + z * z); mat[o + 5] = 2 * (y * z - x * w)
            mat[o + 6] = 2 * (x * z - y * w); mat[o + 7] = 2 * (y * z + x * w); mat[o + 8] = 1 - 2 * (x * x + y * y)
            val px = bpos[b * 3]; val py = bpos[b * 3 + 1]; val pz = bpos[b * 3 + 2]
            mat[o + 9] = gt[b * 3] - (mat[o] * px + mat[o + 1] * py + mat[o + 2] * pz)
            mat[o + 10] = gt[b * 3 + 1] - (mat[o + 3] * px + mat[o + 4] * py + mat[o + 5] * pz)
            mat[o + 11] = gt[b * 3 + 2] - (mat[o + 6] * px + mat[o + 7] * py + mat[o + 8] * pz)
        }
    }

    private fun skin(out: FloatArray) {
        val vc = m.vertexCount
        val parts = SkinPool.threads
        if (parts <= 1 || vc < 20000) { skinRange(out, 0, vc); return }
        val step = (vc + parts - 1) / parts
        val futs = ArrayList<java.util.concurrent.Future<*>>()
        for (p in 1 until parts) {
            val s = p * step; val e = minOf(vc, s + step)
            if (s < e) futs.add(SkinPool.ex.submit(Runnable { skinRange(out, s, e) }))
        }
        skinRange(out, 0, minOf(vc, step))
        for (f in futs) f.get()
    }

    private fun skinRange(out: FloatArray, from: Int, to: Int) {
        val bi = m.boneIndices; val bw = m.boneWeights; val nr = m.normals
        for (i in from until to) {
            val x = work[i * 3]; val y = work[i * 3 + 1]; val z = work[i * 3 + 2]
            val nx = nr[i * 3]; val ny = nr[i * 3 + 1]; val nz = nr[i * 3 + 2]
            var ox = 0f; var oy = 0f; var oz = 0f; var onx = 0f; var ony = 0f; var onz = 0f; var tw = 0f
            for (k in 0..3) {
                val b = bi[i * 4 + k]; val w = bw[i * 4 + k]
                if (b !in 0 until n || w == 0f) continue
                val o = b * 12; tw += w
                ox += w * (mat[o] * x + mat[o + 1] * y + mat[o + 2] * z + mat[o + 9])
                oy += w * (mat[o + 3] * x + mat[o + 4] * y + mat[o + 5] * z + mat[o + 10])
                oz += w * (mat[o + 6] * x + mat[o + 7] * y + mat[o + 8] * z + mat[o + 11])
                onx += w * (mat[o] * nx + mat[o + 1] * ny + mat[o + 2] * nz)
                ony += w * (mat[o + 3] * nx + mat[o + 4] * ny + mat[o + 5] * nz)
                onz += w * (mat[o + 6] * nx + mat[o + 7] * ny + mat[o + 8] * nz)
            }
            if (tw == 0f) { ox = x; oy = y; oz = z; onx = nx; ony = ny; onz = nz }
            val p = i * 8
            out[p] = ox * scale; out[p + 1] = oy * scale; out[p + 2] = -oz * scale
            out[p + 3] = onx; out[p + 4] = ony; out[p + 5] = -onz
        }
    }
}
