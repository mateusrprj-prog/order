package studio.mmd.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.render.LightCfg
import java.io.File

/** Lê uma imagem de fundo reduzindo para no máximo ~2048 px no lado maior. */
fun decodeBg(f: File): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, o)
    var ss = 1; while (maxOf(o.outWidth, o.outHeight) / ss > 2048) ss *= 2
    BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = ss })
} catch (e: Throwable) { null }

@Composable
private fun LRow(label: String, v: Float, range: ClosedFloatingPointRange<Float>, fmt: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, modifier = Modifier.width(64.dp))
        Slider(v.coerceIn(range.start, range.endInclusive), onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text(fmt.format(v), fontSize = 11.sp, modifier = Modifier.width(44.dp))
    }
}

/** Diálogo de iluminação: presets + direção, intensidade e cor. */
@Composable
fun LightDialog(c: LightCfg, onChange: (LightCfg) -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } },
        title = { Text("Iluminação") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { onChange(LightCfg()) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Studio", fontSize = 11.sp) }
                    OutlinedButton(onClick = { onChange(LightCfg(160f, 25f, 1.4f, 0.8f, 0.9f, 1f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Rim", fontSize = 11.sp) }
                    OutlinedButton(onClick = { onChange(LightCfg(70f, 8f, 1.3f, 1f, 0.6f, 0.35f)) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Sunset", fontSize = 11.sp) }
                }
                LRow("Dir. H", c.yaw, 0f..360f, "%.0f°") { onChange(c.copy(yaw = it)) }
                LRow("Dir. V", c.pitch, -20f..90f, "%.0f°") { onChange(c.copy(pitch = it)) }
                LRow("Intens.", c.intensity, 0f..2f, "%.2f") { onChange(c.copy(intensity = it)) }
                LRow("Verm.", c.r, 0f..1f, "%.2f") { onChange(c.copy(r = it)) }
                LRow("Verde", c.g, 0f..1f, "%.2f") { onChange(c.copy(g = it)) }
                LRow("Azul", c.b, 0f..1f, "%.2f") { onChange(c.copy(b = it)) }
            }
        })
}
