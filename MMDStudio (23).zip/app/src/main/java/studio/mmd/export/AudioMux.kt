package studio.mmd.export

import android.media.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer

/**
 * Junta o áudio do projeto (qualquer formato que o Android decodifica) a um MP4 só de vídeo:
 * decodifica para PCM, aplica deslocamento (offsetMs: >0 atrasa o áudio) e volume, corta no tamanho do vídeo,
 * codifica em AAC e grava os dois trilhos com MediaMuxer.
 */
object AudioMux {
    private class Chunk(val data: ByteArray, val us: Long, val flags: Int)

    fun mux(video: File, audio: File, out: File, offsetMs: Int, volume: Float, videoUs: Long) {
        val (pcm0, rate, ch) = decode(audio, videoUs + 2_000_000L)
        // desloca
        val bytesPerMs = rate * ch * 2 / 1000
        val shift = (offsetMs * bytesPerMs).let { it - it % (ch * 2) }
        val maxBytes = ((videoUs / 1000L) * bytesPerMs).toInt().let { it - it % (ch * 2) }
        val bo = ByteArrayOutputStream()
        if (shift > 0) bo.write(ByteArray(shift)) else if (shift < 0) { /* pula o começo */ }
        val start = if (shift < 0) minOf(-shift, pcm0.size) else 0
        bo.write(pcm0, start, pcm0.size - start)
        var pcm = bo.toByteArray()
        if (pcm.size > maxBytes) pcm = pcm.copyOf(maxBytes)
        if (volume != 1f) {
            val bb = ByteBuffer.wrap(pcm).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            val g = volume.coerceIn(0f, 2f)
            var i = 0; while (i + 1 < pcm.size) { bb.putShort(i, (bb.getShort(i) * g).toInt().coerceIn(-32768, 32767).toShort()); i += 2 }
        }
        val (chunks, fmt) = encode(pcm, rate, ch)

        val ex = MediaExtractor(); ex.setDataSource(video.absolutePath)
        var vt = -1; for (i in 0 until ex.trackCount) if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)!!.startsWith("video/")) { vt = i; break }
        if (vt < 0) { ex.release(); throw IllegalStateException("Vídeo sem trilho de imagem") }
        ex.selectTrack(vt)
        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val vTrack = mux.addTrack(ex.getTrackFormat(vt)); val aTrack = mux.addTrack(fmt)
            mux.start()
            val buf = ByteBuffer.allocate(2 shl 20); val info = MediaCodec.BufferInfo()
            while (true) {
                info.size = ex.readSampleData(buf, 0)
                if (info.size < 0) break
                info.offset = 0; info.presentationTimeUs = ex.sampleTime
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                mux.writeSampleData(vTrack, buf, info); ex.advance()
            }
            for (c in chunks) {
                info.set(0, c.data.size, c.us, c.flags)
                mux.writeSampleData(aTrack, ByteBuffer.wrap(c.data), info)
            }
            mux.stop()
        } finally { try { mux.release() } catch (e: Exception) {}; ex.release() }
    }

    private fun decode(f: File, limitUs: Long): Triple<ByteArray, Int, Int> {
        val ex = MediaExtractor(); ex.setDataSource(f.absolutePath)
        var t = -1; for (i in 0 until ex.trackCount) if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { t = i; break }
        if (t < 0) { ex.release(); throw IllegalStateException("Arquivo de áudio sem trilho de som") }
        ex.selectTrack(t)
        val inFmt = ex.getTrackFormat(t)
        val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(inFmt, null, null, 0); dec.start()
        var rate = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val out = ByteArrayOutputStream()
        val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val i = dec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val b = dec.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0 || ex.sampleTime > limitUs) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    val b = dec.getOutputBuffer(o)!!
                    val a = ByteArray(info.size); b.position(info.offset); b.get(a, 0, info.size)
                    out.write(a)
                    dec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        } finally { try { dec.stop() } catch (e: Exception) {}; dec.release(); ex.release() }
        return Triple(out.toByteArray(), rate, ch)
    }

    private fun encode(pcm: ByteArray, rate: Int, ch: Int): Pair<List<Chunk>, MediaFormat> {
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch)
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        f.setInteger(MediaFormat.KEY_BIT_RATE, 160_000); f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
        val chunks = ArrayList<Chunk>(); var outFmt: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        var pos = 0; var inDone = false; var outDone = false
        val frameBytes = ch * 2
        try {
            while (!outDone) {
                if (!inDone) {
                    val i = enc.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val b = enc.getInputBuffer(i)!!; b.clear()
                        val n = minOf(b.capacity(), pcm.size - pos)
                        val us = pos / frameBytes * 1_000_000L / rate
                        if (n <= 0) { enc.queueInputBuffer(i, 0, 0, us, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { b.put(pcm, pos, n); enc.queueInputBuffer(i, 0, n, us, 0); pos += n }
                    }
                }
                val o = enc.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        val a = ByteArray(info.size); val b = enc.getOutputBuffer(o)!!; b.position(info.offset); b.get(a, 0, info.size)
                        chunks.add(Chunk(a, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME))
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) outFmt = enc.outputFormat
            }
        } finally { try { enc.stop() } catch (e: Exception) {}; enc.release() }
        return chunks to (outFmt ?: throw IllegalStateException("Codificador de áudio sem formato"))
    }
}
