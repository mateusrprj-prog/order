# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 2.0. Sem WebView/PWA.

## Status
Etapa 4 (edição): modo Esqueleto com ossos desenhados sobre o modelo, seleção de osso por toque, abas Ossos/Osso/Pose/Morphs, keyframes (auto-key), copiar/colar/espelhar/zerar/resetar pose, desfazer/refazer.
Etapa 3: parser VMD, esqueleto com FK + IK (CCD) + append, skinning na CPU, morphs de vértice/osso/grupo, reprodução ligada à timeline.
Etapa 2: parser PMX 2.0/2.1 (vértices, faces, texturas, materiais, ossos, IK, morphs), importação de .pmx ou .zip (ícone de pasta), render OpenGL ES 3 com texturas e materiais (sem animação ainda).
Etapa 1 (anterior):
câmera orbital (1 dedo orbita/pan conforme ferramenta, 2 dedos pan, pinça zoom), vistas Frente/Trás/Esquerda/Direita/Topo/Base,
play/pause, frame anterior/próximo e timeline com playhead arrastável.
v1.0.0: versão final (APK release assinado, ícone). v0.14.0: prender objetos a ossos (Cena) e reconhecimento automático de física. v0.13.1: movimento secundário automático (aba Rig). v0.13.0: aba Rig com Action Constraints (limitar rotação/posição, olhar para, copiar rotação/posição). v0.12.0: tema vermelho, prévia a 60 fps, skinning multithread, exportações (GLB recomendado), áudio, Cena. Veja o arquivo de contexto.

## Compilar
- Android Studio: abrir a pasta e rodar `app`.
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
