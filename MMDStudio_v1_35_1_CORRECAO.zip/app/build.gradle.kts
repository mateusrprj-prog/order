import java.util.Properties

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "studio.mmd"
    compileSdk = 34
    defaultConfig { applicationId = "studio.mmd"; minSdk = 26; targetSdk = 34; versionCode = 78; versionName = "1.35.1" }
    signingConfigs {
        // v1.28.2: credenciais fora do codigo. Fornecer por variaveis de ambiente (CI/GitHub Secrets)
        // ou por keystore.properties local (ignorado pelo Git). Sem credenciais, o build release sai SEM assinatura.
        // O build do workflow (assembleDebug) usa a chave debug e nao depende disto.
        val props = Properties()
        val propsFile = rootProject.file("keystore.properties")
        if (propsFile.exists()) propsFile.inputStream().use { props.load(it) }
        fun cred(env: String, key: String): String? = System.getenv(env) ?: props.getProperty(key)
        val ksPath = cred("MMD_KEYSTORE_FILE", "storeFile")
        if (ksPath != null && file(ksPath).exists()) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = cred("MMD_KEYSTORE_PASSWORD", "storePassword")
                keyAlias = cred("MMD_KEY_ALIAS", "keyAlias")
                keyPassword = cred("MMD_KEY_PASSWORD", "keyPassword")
            }
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.findByName("release")
            isMinifyEnabled = false
            isDebuggable = false
        }
    }
    testOptions { unitTests.isReturnDefaultValues = true }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    // Captura de movimento por vídeo (modelo empacotado, roda no aparelho)
    implementation("com.google.mlkit:pose-detection:18.0.0-beta5")
    implementation("com.google.mlkit:pose-detection-accurate:18.0.0-beta5")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013") // v1.14.0: o android.jar de testes só tem stubs de org.json
}
