# MMD Studio — Roadmap Master de Produção 3D, Animação, Motion Graphics e VFX
## Documento de direção técnica para Claude

**Base de trabalho:** `MMDStudio_v1_17_0.zip` (histórico; código atual analisado na seção 13: v1.28.1)  
**Referências visuais:** quatro vídeos enviados pelo usuário (`1000243160.mp4`, `1000243161.mp4`, `1000243162.mp4`, `1000243163.mp4`)  
**Plataforma-alvo:** Android, com prioridade para uso em aparelhos móveis  
**Regra principal:** evoluir o projeto existente. Não reescrever o app do zero e não substituir funcionalidades reais por telas demonstrativas.

---

# 1. Objetivo do projeto

Evoluir o MMD Studio de um editor de modelos/animação MMD para um **estúdio móvel de produção 3D, animação de personagens, motion graphics, VFX e composição cinematográfica**.

O aplicativo deve permitir criar projetos completos diretamente no Android, desde a montagem da cena e animação dos personagens até a composição dos efeitos e renderização final.

O objetivo não é copiar a interface ou o código de Blender, MMD, After Effects ou qualquer outro software. É construir sistemas próprios, adequados à arquitetura e às limitações do Android, mas com profundidade funcional de ferramenta de produção.

## Resultados que o app deverá conseguir produzir

1. Animações de personagens com corrida, saltos, perseguições, lutas coreografadas, poses e movimentos secundários.
2. Cenas com vários personagens independentes, cada um com rig, animação, materiais e transformações próprios.
3. Cenas estilizadas com cores fortes, formas geométricas, portais, corredores, painéis, objetos animados e câmeras dinâmicas.
4. Vídeos cinematográficos com cenários detalhados, iluminação dramática, close-ups, planos abertos, profundidade e efeitos.
5. Edições com textos, gráficos, máscaras, trilhas visuais, efeitos de impacto e sincronização com música.
6. Renderização final previsível, com qualidade e configurações controláveis, sem depender da aparência da prévia em tempo real.

---

# 2. Leitura das referências visuais

As referências devem ser tratadas como requisitos visuais, não como instruções para reproduzir personagens, marcas d'água, músicas ou obras protegidas.

## Referência 1 — `1000243160.mp4`

O vídeo apresenta uma cena estilizada de personagem 3D em movimento, com:
- personagem em escala pequena e depois em enquadramento próximo;
- corrida e poses de ação;
- cenário minimalista com planos e obstáculos geométricos;
- objetos grandes posicionados no caminho;
- efeito energético luminoso atravessando a cena;
- câmera que alterna entre leitura ampla da ação e acompanhamento mais próximo.

**Capacidades necessárias:** multiobjetos, animação corporal, root motion, obstáculos, VFX de energia, câmera animada, luz emissiva e composição de cena.

## Referência 2 — `1000243161.mp4`

O vídeo alterna entre uma apresentação de personagem/modelo em visual neutro e tomadas de ação cinematográfica em ambiente escuro.
Elementos observados:
- personagem humanoide com roupa e acessórios;
- visual de estudo/modelagem em tons neutros;
- mudança para cenas com iluminação baixa e fontes luminosas no ambiente;
- enquadramentos próximos e cortes de ação;
- sensação de movimento rápido, com desfoque e câmera dinâmica.

**Capacidades necessárias:** materiais, iluminação, ambiente, câmera, edição de planos, motion blur e pipeline de renderização.

## Referência 3 — `1000243162.mp4`

O vídeo mostra uma linguagem visual gráfica e estilizada:
- paleta muito saturada e contrastante;
- cenário geométrico e arquitetônico;
- grandes painéis e molduras coloridas;
- personagem estilizado em silhueta/alto contraste;
- elementos gráficos no espaço 3D;
- corredor com perspectiva forte;
- distorção/zoom radial e composição de impacto;
- textos de aviso integrados à composição.

**Capacidades necessárias:** materiais não realistas, paletas e color grading, objetos geométricos, texto no espaço 3D, deformações/distorções de imagem, câmera animada, composição e efeitos sincronizáveis.

## Referência 4 — `1000243163.mp4`

O vídeo contrasta o resultado final com a visão de trabalho de animadores:
- personagem robótico/estilizado em ambiente dramático;
- brilho intenso de uma fonte de energia;
- efeitos luminosos, rastros e linhas de movimento;
- planos próximos de partes do personagem e da ação;
- tomada ampla de cenário arquitetônico;
- visão de bastidores com vários rigs/personagens e controles visíveis;
- cena com escala ampla, na qual os personagens ocupam pequena parte do ambiente.

**Capacidades necessárias:** rigs e controles de animação, múltiplos personagens, organização de cena, cenários grandes, iluminação emissiva, VFX, câmeras com diferentes escalas de enquadramento e renderização cinematográfica.

## Conclusão das referências

Os vídeos não representam apenas “animação de osso”. Eles exigem quatro áreas integradas:

1. **Character Animation:** corpo, rosto, rig, IK, movimento e acting.
2. **Scene & Camera Direction:** personagens, objetos, cenários, luzes e câmeras.
3. **Motion Graphics & VFX:** formas, energia, partículas, rastros, textos e distorções.
4. **Compositing & Rendering:** planos, camadas, efeitos finais, áudio e exportação.

---

# 3. Auditoria de base: v1.17.0

A auditoria abaixo é estática, baseada no ZIP e no README/código-fonte. Não significa que o APK foi executado ou que o build foi validado nesta análise. Antes de alterar qualquer sistema, Claude deve confirmar o estado atual do repositório e executar os testes disponíveis.

## 3.1 Tecnologias e estrutura observadas

- Kotlin nativo e Jetpack Compose.
- OpenGL ES 3 com shaders GLSL ES 3.00.
- Parser e modelo PMX próprios.
- Importação PMX, PMD, X, GLB, glTF e OBJ.
- Importação de modelos soltos ou compactados em ZIP.
- Animator próprio, FK, IK e skinning na GPU.
- SDEF e QDEF no shader.
- Morphs de vértice, osso, UV e material.
- VMD para animação de ossos/morphs e leitura de câmera.
- Dope Sheet visual com seleção e arrasto de keyframes.
- Curvas Bézier e edição de keyframes.
- Física própria com passo fixo e cache/bake.
- Mocap por vídeo e retargeting.
- Constraints.
- Acessórios/objetos associados ao modelo.
- Áudio, exportação de mídia e exportadores GLB/FBX/VMD/VPD/PMX, conforme o estado de cada caminho.

## 3.2 Sistemas que já existem e devem ser preservados

| Área | Evidência na v1.17 | Diretriz |
|---|---|---|
| Importação PMX/PMD/X | Parsers próprios | Preservar e ampliar compatibilidade |
| Importação GLB/glTF/OBJ | `GlbParser` e `ObjParser` | Adicionar animações GLB sem quebrar malhas/texturas |
| Exportação PMX | `PmxWriter` | Preservar round-trip |
| Animator | `Animator.kt` | Evoluir sem duplicar motor |
| Skinning | GPU, SDEF e QDEF | Preservar caminhos já testados |
| Morphs | Vértice, osso, UV e material | Completar tipos e validar comportamento |
| Timeline | Dope Sheet e key editing | Evoluir para timeline multi-track |
| Câmera | Orbit camera e importação de câmera VMD | Criar câmera nativa animável |
| Luz | `LightCfg` com luz direcional e ajustes visuais | Expandir para sistema de luzes |
| Física | `Physics`, `AutoPhysics`, `Baker`, `PhysCache` | Expandir e manter determinismo |
| Mocap | `MocapEngine`, biblioteca e retargeting | Melhorar retarget e integração |
| Render | `SceneGLView.kt` | Evoluir de forma incremental |

## 3.3 Limitações explicitamente documentadas na v1.17

- Importação GLB/glTF ainda não importa animações embutidas.
- FBX e debug visual da física/cache no projeto foram listados como pendentes na documentação da versão.
- A câmera VMD pode ser importada/reproduzida, mas isso não é um editor nativo completo de câmera.
- A luz observada no código é uma configuração direcional (`LightCfg`), não um sistema completo de múltiplas luzes.
- A prévia OpenGL não equivale a um renderizador cinematográfico com composição e pós-processamento completo.
- O app possui áudio e exportação de mídia, mas não foi identificada uma suíte completa de composição multicamada de vídeo/VFX.
- A cena e o fluxo de edição ainda precisam ser avaliados para confirmar suporte real a múltiplas instâncias independentes de personagens, cada uma com Animator próprio.

**Não declarar recursos como concluídos apenas porque há uma aba, classe, botão, modelo de dados ou opção visual.** Validar o fluxo completo: criar/importar → editar → salvar → reabrir → reproduzir → exportar.

---

# 4. Arquitetura-alvo

O produto deve ter três ambientes de trabalho integrados, compartilhando o mesmo projeto, relógio, dados de cena e renderização.

## 4.1 Character Studio

Responsável por:
- importação e gerenciamento de personagens;
- rig e hierarquia de ossos;
- FK/IK e constraints;
- poses e biblioteca de poses;
- animação corporal;
- animação facial e morphs;
- camadas de animação;
- retargeting;
- física secundária;
- clips de animação.

## 4.2 Scene & Motion Studio

Responsável por:
- cena com várias instâncias de modelos;
- cenários, objetos e coleções;
- transformações de objetos;
- câmeras e cortes;
- luzes;
- materiais;
- caminhos e trajetórias;
- motion graphics 3D;
- organização e hierarquia da cena.

## 4.3 VFX & Compositor

Responsável por:
- camadas de vídeo/imagem/texto;
- máscaras;
- efeitos 2D e 3D;
- partículas;
- rastros e efeitos de energia;
- distorções;
- transições;
- color grading;
- composição de passes de render;
- áudio e sincronização.

## 4.4 Núcleo compartilhado obrigatório

Criar ou consolidar serviços compartilhados para:
- `Project/Scene Graph`: estado persistente da cena.
- `Animation Clock`: tempo e frame rate globais.
- `Animation Evaluation`: avaliação determinística de todos os canais.
- `Asset Registry`: modelos, texturas, vídeos, áudios, materiais e caches.
- `Render Graph`: dependências e ordem dos passes.
- `Undo/Redo`: comandos de edição de cena, timeline e compositor.
- `Serialization`: versão do projeto, migrações e validação.
- `Export Pipeline`: render por frame e codificação de mídia.

Os nomes acima são nomes conceituais. Reutilize nomes/estruturas existentes se já cumprirem a função. Não crie sistemas duplicados sem justificar.

---

# 5. Roadmap de desenvolvimento

## RELEASE 8 — Scene Graph & Multi-Character Foundation

> **PRIORIDADE P0 — fundação (nota de prioridades, 19/11/2026).** Scene Graph persistente, Outliner funcional e múltiplos personagens independentes bloqueiam câmeras, luzes, VFX e render. Tipo: implementação nova sobre base já escrita (8.1/8.2), precedida de auditoria.

**Prioridade: crítica**

### Objetivo
Transformar a cena de um único modelo editado em uma cena real com múltiplas instâncias independentes.

### Implementar
- Scene Graph hierárquico com nós.
- Tipos de nó: personagem, mesh/objeto, câmera, luz, grupo, áudio e efeito.
- Instâncias independentes de modelos.
- Animator independente por personagem.
- Transformação local e global.
- Parent/child para objetos presos a ossos ou a outros objetos.
- Outliner com seleção, ocultar, bloquear, renomear e agrupar.
- Duplicar, excluir, mover e reordenar nós.
- Salvar e restaurar todas as instâncias.
- Importação repetida do mesmo asset sem compartilhar estado mutável indevidamente.
- Seleção de personagem ativo sem interromper os demais.
- Reprodução simultânea com relógio global.

### Complementos da nota v1.28.1 (seção 13) — [NOVO — nota v1.28.1]
**Fatia 8.4 — Outliner/Scene Graph (fazer ANTES da 8.3d) — 8.4a escrita na v1.29.0 (ver fim do documento); 8.4b pendente:**
- Hierarquia: personagens, objetos 3D, acessórios, câmeras, luzes, grupos/coleções, cenário, partículas/futuros; o elenco (`cast.json`) passa a viver no grafo.
- Operações pela UI: selecionar/deselecionar, renomear, duplicar, excluir, agrupar/desagrupar, reordenar e reparentear, ocultar/mostrar, **bloquear edição**, **ativar/desativar visibilidade no render**, exibir tipo e estado, **sincronizar seleção Outliner ↔ viewport**.
- Persistência/histórico: salvar e restaurar a hierarquia completa, preservar referências entre objetos e personagens, Undo/Redo nas operações, **excluir pai/dependência sem deixar referência inválida**.
- Aceitação: criar cena com vários tipos de nó, reorganizar pela UI, salvar, fechar, reabrir: hierarquia e relações intactas.
**Fatia 8.3d — Edição independente de múltiplos personagens:**
- Selecionar qualquer personagem como ativo, com indicação clara; editar ossos e morphs do ativo; criar/mover/excluir keyframes por personagem; trilhas separadas na Dope Sheet; aplicar movimento a um sem alterar os demais.
- Rig, IK, constraints e física individuais; acessórios presos a ossos de qualquer personagem; **copiar/colar poses entre personagens compatíveis**; **duplicar personagem preservando/regenerando IDs corretamente**.
- Animação: estado independente por personagem, relógio de cena compartilhado, pausar/avançar/voltar quadro a quadro sem divergência, edição de um nunca sobrescreve os dados de outro.
- Exportação: cena com todos os personagens (hoje extras ficam fora de GLB/FBX/VMD/VPD), preservando transformações, hierarquia, materiais, texturas e animação quando o formato permitir; documentar limitações por formato.
- Aceitação: cena com ≥2 personagens: animar cada um independentemente, salvar, reabrir, reproduzir e exportar sem perder a separação dos dados.

### Critérios de aceitação
- Uma cena contém ao menos três personagens diferentes.
- Cada personagem pode ter animação e pose próprias.
- Reproduzir a timeline atualiza todos simultaneamente.
- Transformar um personagem não modifica os outros.
- Salvar, fechar e reabrir preserva cena, hierarquia e animações.
- Não há vazamento de recursos OpenGL ao remover ou substituir instâncias.

---

## RELEASE 9 — GLB Animation Import & Animation System Pro

> **PRIORIDADE P0 (importação GLB, clips, relógio) + P0/P1 (ferramentas manuais).** Ordem interna: seleção/edição de keys, graph editor, easing, layers com pesos, IK de mãos/pés, foot lock básico e Root Motion = P0/P1; retargeting avançado, pole vectors e limites articulares = P2. Nunca destruir keyframes ao aplicar um clip (v1.24.0: troca de clip desfazível).

**Prioridade: crítica**

### Objetivo
Permitir usar animações externas e criar movimentos mais convincentes dentro do app.

### Importação GLB/glTF
- Ler animation samplers e channels.
- Suportar translation, rotation, scale e morph weights quando presentes.
- Interpolar STEP, LINEAR e CUBICSPLINE corretamente.
- Resolver nós/alvos por índice e hierarquia.
- Validar skin joints e inverse bind matrices.
- Tratar arquivos com várias animações.
- Exibir lista de clips importados.
- Não perder texturas, materiais ou skinning já suportados.
- Reportar canais incompatíveis sem falha silenciosa.

### Ferramentas de animação
- Animation Clips independentes.
- Trim de início/fim.
- Loop, ping-pong e retiming.
- Blend entre clips.
- Camadas de animação com pesos.
- Override e additive layers quando matematicamente apropriado.
- Root motion separado do movimento in-place.
- Retargeting entre esqueletos com mapeamento editável.
- Biblioteca de ciclos: idle, walk, run e outras ações genéricas.
- Foot lock/planting para reduzir deslizamento dos pés.
- IK de mãos e pés com alvos no espaço da cena.
- Controles de pole vector e limites articulares.
- Pose mirroring e pose library.
- Editor de curvas com tangentes e interpolação por canal.

### Complementos da nota v1.28.1 — [NOVO — nota v1.28.1]
- **Graph Editor:** seleção de canais/propriedades, edição de keys e tangentes, modos de tangente, zoom/pan/enquadramento automático, edição numérica precisa, sincronização com timeline e Dope Sheet (o editor de curvas Bézier por key da Etapa 7 deve ser reaproveitado, não reescrito).
- **Camadas:** **máscaras por osso ou grupo de canais**, controle de peso, preservar keyframes existentes ao adicionar/combinar clips, ajuste de início/fim/velocidade/repetição.
- **Rig:** controles de mãos e pés, **ferramentas para corrigir poses e contatos**, **retargeting com ajuste de escala, orientação e pose-base**.
- **GLB:** morph weights, escala, **recarregar clips e lista ao reabrir o projeto**, validar rigs e hierarquias diferentes.
- Aceitação: importar GLB animado, ver todos os clips, aplicá-los sem destruir animações existentes, editar curvas, combinar, salvar e reabrir com o mesmo resultado.

### Critérios de aceitação
- Importar um GLB com pelo menos uma animação e reproduzi-la corretamente.
- Alternar clips sem saltos indevidos.
- Misturar dois clips com transição controlada.
- Root motion pode ser aplicado ou removido.
- Animação e pose permanecem corretas ao salvar/reabrir.
- Retargeting informa ossos sem correspondência e não os descarta silenciosamente.

---

## RELEASE 10 — Camera Director

> **PRIORIDADE P1** (estrutura básica de câmera como nó do Scene Graph antecipada em P0; follow/look-at, path, shake e cortes = P1). Depende de Scene Graph + Animation Clock.

**Prioridade: crítica**

### Objetivo
Transformar a câmera de visualização em um objeto de cena que possa ser dirigido e animado.

### Implementar
- Câmeras persistentes como nós do Scene Graph.
- Múltiplas câmeras por cena.
- Câmera ativa selecionável.
- Keyframes de posição, rotação, alvo e FOV.
- Perspectiva e ortográfica.
- Distância focal e parâmetros de lente.
- Look-at/target tracking.
- Follow camera com offset.
- Path camera com curva editável.
- Camera shake com intensidade, frequência, duração e seed.
- Dolly, pan, tilt, orbit, zoom e truck.
- Foco manual e foco em objeto.
- Depth of Field quando suportado pelo pipeline.
- Marcadores de corte e shot list na timeline.
- Transições entre câmeras.
- Preview da câmera ativa e safe frame.
- Importação VMD de câmera mantida como recurso adicional.

### Complementos da nota v1.28.1 — [NOVO — nota v1.28.1]
- Câmeras como nós persistentes do Scene Graph (renomear, duplicar, excluir, câmera ativa, alternar pela UI, keyframes de câmera visíveis na timeline); **exportar** dados de câmera nos formatos compatíveis (hoje só importa VMD); salvar/restaurar câmeras e animações no projeto.

### Critérios de aceitação
- Criar duas câmeras e alternar entre elas por marcadores de corte.
- Animar posição, rotação e FOV com curvas.
- Fazer câmera seguir um personagem sem alterar sua animação.
- Salvar/reabrir mantendo câmeras, keyframes e cortes.
- Render final respeita a câmera e os cortes definidos.

---

## RELEASE 11 — Motion Graphics 3D

> **PRIORIDADE P1.** Primitivas, texto 3D, pivot/parent, keyframes e materiais unlit/emissive primeiro; paths/arrays = P1/P2. Depende de Scene Graph.

**Prioridade: alta**

### Objetivo
Permitir criar composições abstratas e gráficas dentro do espaço 3D, como as referências com corredores, painéis, molduras, formas e portais.

### Primitivas
- Cubo, esfera, plano, cilindro, cone, torus e linhas.
- Plano com subdivisão e malha simples editável.
- Texto 3D e texto billboard.
- Curvas e paths.
- Objetos importados como elementos de composição.

### Transformação e animação
- Keyframes de posição, rotação, escala e visibilidade.
- Pivot editável.
- Parent/child.
- Follow path.
- Look-at.
- Instancing para repetição eficiente.
- Arrays e distribuição em linha/radial.
- Deformadores simples: bend, twist, taper e wave, conforme viabilidade.
- Animação procedural baseada em tempo.
- Controles de parâmetros expostos na timeline.

### Aparência
- Materiais unlit/emissive.
- Paletas e presets de cores.
- Transparência e blend modes suportados.
- Contorno e estilos toon.
- Gradientes por shader quando viável.
- Controle de face/culling e double-sided.

### Critérios de aceitação
- Criar corredor com painéis e formas geométricas sem sair do app.
- Animar cada objeto individualmente ou em grupo.
- Duplicar centenas de instâncias sem criar centenas de draw calls desnecessárias.
- Salvar e reabrir todos os objetos e animações.

---

## RELEASE 12 — Lighting & Material Studio

> **PRIORIDADE P1.** Luzes direcionais/pontuais/spot, rim/emissive e PBR/toon básicos primeiro, com orçamento de desempenho; luz de área e técnicas caras = P3.

**Prioridade: alta**

### Objetivo
Sair de uma configuração de luz direcional única para uma iluminação de cena mais expressiva.

### Luzes
- Directional.
- Point.
- Spot.
- Área/emulação de área se o renderer permitir.
- Cor, intensidade, alcance, cone e atenuação.
- Sombras por luz com orçamento configurável.
- Luz emissiva em materiais.
- Luz de borda/rim light.
- Presets de iluminação.
- Controle de ambiente e exposição.

### Materiais
- PBR metallic/roughness.
- Base color, metallic, roughness, normal, AO e emissive.
- Texturas e UV sets.
- Toon/cel shading.
- Unlit e materiais gráficos.
- Transparência com modos documentados.
- Two-sided.
- Parâmetros animáveis quando apropriado.
- Compatibilidade com materiais PMX existentes.

### Complementos da nota v1.28.1 — [NOVO — nota v1.28.1]
- **Pré-visualização de material** e persistência das alterações; **controles de qualidade e custo de renderização** das luzes/sombras expostos ao usuário; luzes como nós persistentes e animáveis no Scene Graph; melhorar compatibilidade com materiais/texturas importados (liga com a tabela P3 da seção 13.6).

### Critérios de aceitação
- Múltiplas luzes aparecem corretamente na prévia e no render.
- Materiais PBR e toon podem coexistir na mesma cena.
- Luzes e materiais são persistidos no projeto.
- O renderer mantém desempenho aceitável em cenas de teste no Android.
- Não quebrar aparência de modelos PMX que já funcionam.

---

## RELEASE 13 — VFX & Particle System

> **PRIORIDADE P1/P2 (VFX essenciais: trails, brilhos, anéis, afterimage, partículas determinísticas) e P2/P3 (distorções e pós-processamento).** Depende de relógio, cena e render estáveis; cada efeito com controle, custo previsível e opção de desligar.

**Prioridade: alta**

### Objetivo
Criar efeitos de energia, rastros, partículas, impactos e elementos atmosféricos usados nas referências.

### Partículas
- Emissor por ponto, área, cone e malha, conforme viabilidade.
- Spawn rate, lifetime, velocidade, direção, gravidade e tamanho.
- Cor ao longo da vida.
- Alpha e escala ao longo da vida.
- Random seed determinístico.
- Partículas em espaço local ou global.
- Orientação para câmera ou velocidade.
- Limites de partículas e orçamento de memória.
- Presets de poeira, faíscas, brilho, fumaça estilizada e energia abstrata.

### Efeitos de ação
- Trails/ribbons.
- Linhas de velocidade.
- Arcos de energia.
- Impact rings.
- Shockwave visual.
- Emissive pulse.
- Afterimage/ghost trail.
- Hit flash e flashes controlados.
- Efeitos ligados a osso, objeto ou trajetória.
- Spawn por evento de animação ou marcador da timeline.

### Distorções e pós-processamento
- Bloom.
- Vignette.
- Chromatic aberration com controle moderado.
- Radial blur/zoom blur.
- Distortion/heat haze.
- Color grading.
- Film grain opcional.
- Motion blur, preferencialmente como etapa separada e com fallback.
- Controle de intensidade e ordem dos efeitos.

### Segurança visual
- Evitar flashes intensos ou repetitivos por padrão.
- Fornecer controle para reduzir/desativar efeitos luminosos.
- Não usar flashes rápidos como preset padrão.
- Incluir avisos quando uma composição contiver efeitos piscantes.

### Critérios de aceitação
- Criar um efeito de energia que acompanha a mão de um personagem.
- Criar trail ligado a um objeto em movimento.
- Efeito é reproduzível em um frame específico e no render.
- Partículas usam seed e tempo determinísticos.
- Desativar VFX não altera a animação base.

---

## RELEASE 14 — VFX & Compositor 2D

> **PRIORIDADE P2.** Subsistema grande; só começar depois de existir saída de render 3D por frame confiável e pipeline de mídia validado.

**Prioridade: alta**

### Objetivo
Permitir finalizar edits com textos, gráficos, vídeos, imagens e efeitos sem depender de outro aplicativo.

### Timeline multicamada
- Trilhas de vídeo.
- Trilhas de imagem.
- Trilhas de texto.
- Trilhas de áudio.
- Trilhas de render 3D.
- Grupos e composição aninhada.
- In/out points.
- Trim, split, move, duplicate e ripple edit.
- Opacidade e transformações por keyframe.
- Sincronização por frame.
- Preview de composição.

### Máscaras e composição
- Máscara retangular, elíptica e path quando viável.
- Feather, expansão e inversão.
- Alpha compositing.
- Blend modes implementados e documentados.
- Chroma key como etapa posterior se houver desempenho.
- Camadas de adjustment/effect.
- Texto com fontes, tracking, alinhamento e animação.
- Revelação por palavra/letra.
- Contorno, sombra e preenchimento.
- Elementos gráficos vetoriais básicos.

### Integração com 3D
- Renderizar cena 3D como uma fonte de camada.
- Render passes: color, depth, normal, object ID e alpha, conforme suportado.
- Compor múltiplos passes.
- Sobrepor texto, gráficos e efeitos 2D ao render 3D.
- Preservar transparência quando o formato permitir.

### Critérios de aceitação
- Montar uma composição com render 3D, texto, imagem, duas trilhas de áudio e efeitos.
- Fazer trim e keyframes por camada.
- Salvar/reabrir sem perder sincronização.
- Exportar a composição final com duração e frame rate corretos.

---

## RELEASE 15 — Facial Animation & Character Acting

> **PRIORIDADE P1/P2 (morphs faciais existentes, expressões salvas, piscar/olhar) e P2 (lip sync, visemas, retargeting facial).** Não presumir o mesmo rig facial em todos os modelos.

**Prioridade: média-alta**

### Objetivo
Aumentar a expressividade dos personagens.

### Implementar
- Painel facial por morph/shape key.
- Grupos de expressões.
- Bibliotecas de expressões.
- Piscar automático configurável.
- Direção dos olhos e alvo de olhar.
- Controle de sobrancelha, boca e mandíbula quando o rig oferecer suporte.
- Lip sync por áudio em modo básico.
- Timeline de fonemas/visemas quando houver dados suficientes.
- Expressões como clips combináveis com animação corporal.
- Retarget de expressões apenas quando houver mapeamento explícito.

### Complementos da nota v1.28.1 — [NOVO — nota v1.28.1]
- Controles faciais **por personagem** (depende da 8.3d); integração com a Cartoon Motion Library (categoria Facial Expressions já existe: unificar com presets/keyframes de expressão); importação/edição de morphs faciais compatíveis.

### Critérios de aceitação
- Criar e salvar uma expressão composta.
- Animar olhos e expressões independentemente do corpo.
- Sincronizar abertura da boca com uma faixa de áudio em modo básico.
- Modelos sem morph facial continuam funcionando sem erros.

---

## RELEASE 16 — Cinematic Render & Export Pipeline

> **PRIORIDADE P0/P1 para o caminho BÁSICO (render por frame com estado real da cena + Animation Clock, vídeo/PNG, áudio por timestamp, progresso e cancelamento) — antecipado como infraestrutura, validar cedo; P2/P3 para qualidade cinematográfica (DoF, motion blur, grain, aberração cromática etc.).**

**Prioridade: crítica para entrega final**

### Objetivo
Garantir que a qualidade do vídeo exportado corresponda ao que foi montado na cena.

### Renderização
- Render por frame, não captura improvisada da prévia.
- Frame rate configurável.
- Resolução configurável.
- Render em lotes.
- Barra de progresso real.
- Cancelar e retomar render quando possível.
- Persistência de estado de render.
- Reprocessamento de frames com falha.
- Presets de qualidade.
- Gestão de memória e limpeza de recursos.
- Render offline determinístico para física e partículas.
- Motion blur e depth of field no render final quando habilitados.
- Render passes para compositor.
- Supersampling/anti-aliasing conforme capacidade do dispositivo.

### Exportação
- MP4 com encoder Android suportado.
- PNG sequence.
- WAV/AAC conforme pipeline.
- Áudio sincronizado por timestamp/frame.
- Metadados de frame rate e duração.
- Relatório de erros e frames faltantes.
- Exportação em segundo plano quando o Android permitir.
- Limite de memória e espaço livre verificados antes do render.

### Critérios de aceitação
- O mesmo frame exportado em execuções repetidas tem resultado consistente, salvo fontes explicitamente aleatórias.
- A duração final corresponde ao intervalo da timeline.
- O áudio não deriva progressivamente do vídeo.
- Render pode ser cancelado sem corromper o projeto.
- Falhas são reportadas e não apresentadas como exportação bem-sucedida.

---

# 6. Melhorias transversais obrigatórias

> **PRIORIDADE P0 — transversal a todas as fases** (autosave/recuperação/migração, memória CPU/GPU, recuperação de contexto GL, testes em aparelho real).

## 6.1 Projeto e persistência
- Versionar o formato do projeto.
- Migrações automáticas e testadas.
- Salvar Scene Graph, instâncias, câmeras, luzes, materiais, animações, efeitos e compositor.
- Referências a assets com caminhos internos estáveis.
- Verificar assets ausentes ao abrir projeto.
- Autosave e recuperação de sessão.
- Backup antes de migrações destrutivas.

## 6.2 UX mobile
- Interface adaptada para tela vertical e horizontal.
- Painéis recolhíveis.
- Controles touch para viewport.
- Gizmos de mover, girar e escalar.
- Seleção por toque e Outliner.
- Gestos de timeline sem conflito com scroll.
- Ferramentas acessíveis sem ocupar a viewport inteira.
- Modo de desempenho para aparelhos móveis.
- Não criar controles decorativos ou botões sem ação.

## 6.3 Desempenho Android
- Perfil de memória CPU/GPU.
- LOD para modelos e cenários grandes.
- Frustum culling.
- Instancing.
- Cache de shaders.
- Upload assíncrono de assets.
- Compressão de texturas apropriada ao hardware.
- Limite configurável de partículas.
- Redução adaptativa da qualidade da prévia.
- Render final separado da qualidade da viewport.
- Tratar perda/recuperação do contexto OpenGL.
- Liberar buffers, texturas, framebuffers e programas ao remover recursos.

## 6.4 Qualidade e testes
- Testes unitários para parsers e interpolação.
- Testes de serialização e migração de projeto.
- Testes determinísticos do Animation Clock.
- Testes de round-trip para formatos suportados.
- Testes de cenas com 1, 2, 3 e mais personagens.
- Testes de câmera e cortes.
- Testes de física e bake.
- Testes de render por frame.
- Testes de exportação com áudio.
- Testes em aparelho Android real, além de testes JVM.
- Testes de arquivos corrompidos, grandes e incompletos.

---

# 7. Sequência recomendada e dependências

A ordem deve respeitar as dependências técnicas. Não iniciar um compositor completo antes de existir uma fonte de render de cena confiável.

| Ordem | Release | Dependência principal |
|---:|---|---|
| 1 | 8 — Scene Graph & Multi-Character | Projeto/persistência |
| 2 | 9 — GLB Animation & Animation Pro | Scene Graph + Animator |
| 3 | 10 — Camera Director | Scene Graph + Animation Clock |
| 4 | 11 — Motion Graphics 3D | Scene Graph + transform animation |
| 5 | 12 — Lighting & Material Studio | Render Graph |
| 6 | 13 — VFX & Particles | Render Graph + Animation Clock |
| 7 | 14 — VFX & Compositor 2D | Render por frame + fontes 3D |
| 8 | 15 — Facial Animation | Animation System Pro |
| 9 | 16 — Cinematic Render & Export | Sistemas anteriores integrados |

As releases podem ser divididas em fatias menores. A numeração não exige que cada release seja entregue em um único commit.

---

# 8. Regras obrigatórias para Claude

## Antes de programar
1. Ler o projeto inteiro e identificar a arquitetura real da branch atual.
2. Comparar a branch atual com a base v1.17.0; não presumir que o ZIP ainda representa o HEAD.
3. Identificar os arquivos e classes existentes para cada sistema.
4. Criar um mapa de dependências e riscos.
5. Verificar testes existentes e executar a suíte antes de mudanças.
6. Não assumir que algo está ausente sem procurar no código; não assumir que algo funciona só porque existe uma classe.

## Durante a implementação
1. Implementar em fatias pequenas e compiláveis.
2. Reutilizar Animator, SceneGLView, ProjectStore e modelos existentes quando adequados.
3. Não duplicar motores de animação, relógios ou renderizadores.
4. Não reescrever parsers estáveis sem necessidade.
5. Não remover recursos MMD para priorizar recursos novos.
6. Não adicionar botões, abas ou sliders que não estejam conectados a operações reais.
7. Não usar dados falsos para simular múltiplos personagens, câmeras, luzes ou partículas.
8. Não afirmar suporte a um formato sem testar arquivos reais representativos.
9. Não deixar TODO como se fosse implementação concluída.
10. Considerar o desempenho e a memória do Android desde o primeiro commit.

## Para cada entrega
Informar:
- objetivo da fatia;
- arquivos criados/alterados;
- arquitetura escolhida;
- comportamento implementado;
- limitações ainda existentes;
- testes executados e resultados;
- comando de build usado e resultado;
- passos para testar no aparelho;
- riscos e próxima fatia.

## Critério de conclusão
Uma funcionalidade só pode ser marcada como concluída quando:
1. Pode ser criada ou importada pela UI.
2. Pode ser editada e visualizada.
3. É salva no projeto.
4. Continua correta após fechar e reabrir.
5. É avaliada corretamente na timeline.
6. Aparece corretamente no render/exportação quando aplicável.
7. Tem testes automatizados ou roteiro manual reproduzível.

---

# 9. Primeira tarefa para Claude

**Não implemente todas as releases de uma vez.**

Comece pela seguinte tarefa:

### Fase A — Auditoria atualizada
- Auditar a branch atual e confirmar a versão real.
- Mapear `Project.kt`, `SceneScreen.kt`, `SceneGLView.kt`, `Animator.kt`, `Editor.kt`, `DopeSheet.kt`, parsers, exportadores e testes.
- Determinar se a arquitetura atual suporta múltiplas instâncias independentes de personagens.
- Determinar como o estado de câmera é armazenado e se pode ser convertido em nó persistente.
- Determinar o estado real da importação de animações GLB.
- Determinar o caminho atual de renderização e exportação por frame.
- Identificar limitações de OpenGL ES e memória no Android.
- Executar testes e build disponíveis antes de alterar código.

### Fase B — Plano de implementação da Release 8
Apresentar:
- modelo de dados proposto para Scene Graph;
- estratégia de instâncias independentes;
- integração com ProjectStore;
- estratégia para não duplicar Animator;
- mudanças mínimas necessárias na UI/Outliner;
- plano de testes;
- arquivos que serão modificados.

### Fase C — Implementação incremental
Após a auditoria, implementar a primeira fatia funcional da Release 8. Não avançar para releases seguintes até que a cena multi-instância esteja persistente, reproduzível e testada.

---

# 10. Cenário de validação final

Usar um projeto de teste original com:
- três personagens 3D diferentes;
- ao menos dois personagens com rigs distintos;
- um cenário arquitetônico;
- obstáculos e painéis geométricos;
- uma câmera ampla e uma câmera de close;
- duas luzes de cores diferentes;
- uma animação de corrida/perseguição;
- um efeito de energia preso a um personagem;
- partículas e rastros;
- texto gráfico em uma camada do compositor;
- trilha de áudio original ou de teste.

O teste deve permitir:
1. montar a cena;
2. animar os personagens separadamente;
3. importar e retargetear um clip;
4. criar câmeras e cortes;
5. animar objetos geométricos;
6. criar e controlar VFX;
7. compor texto e camadas;
8. salvar e reabrir o projeto;
9. renderizar a sequência;
10. verificar sincronização, qualidade e estabilidade.

## Definição de sucesso do projeto

O MMD Studio será considerado um estúdio de produção funcional quando o usuário conseguir criar e exportar uma sequência completa como a das referências **sem precisar montar a cena em outro software** para suprir as funções centrais descritas neste roadmap.

Isso não significa que cada efeito avançado precisa existir desde a primeira release. Significa que a arquitetura deve permitir adicioná-los sem refazer o núcleo a cada ciclo.

---

# 11. Registro de progresso (atualizado a cada fatia)

> Regra: este registro é alterado a cada fatia entregue. Nada é marcado como concluído sem build + teste no aparelho confirmados pelo usuário.

## Fase A — Auditoria (feita sobre o ZIP v1.17.0; build NÃO executado)

**Ambiente:** sem Gradle/Kotlin/JDK e sem rede neste ambiente. Build e testes JVM não puderam ser rodados; tudo abaixo é leitura estática do código.

**Respostas às perguntas da Fase A:**

| Pergunta | Achado (arquivo) |
|---|---|
| Versão real | v1.17.0 (README). HEAD do repositório não foi comparado: só existe o ZIP. |
| Suporta várias instâncias independentes? | **Não.** `SceneRenderer` (em `SceneGLView.kt`) guarda UM `model: GlModel?`, UM `animator: Animator?` e UM `curMotion`. `loadModel()` chama `freeModel()` e substitui o modelo. |
| O que são os "props"? | `PmxModel` estáticos (classe `Prop`), sem Animator próprio, só x/y/z/escala, com opção de prender a um osso do modelo principal. Servem de base para o Scene Graph, mas não são personagens. |
| Editor | `Editor.kt` (863 linhas) edita um único modelo. A UI (`SceneScreen.kt`, ~959 linhas) mantém estado local com `remember` (um `editor`, `props`, `camMotion`, `lightCfg`). |
| Persistência | `ProjectMeta` (id, nome, aspecto, resolução, fps, fundo, frames) + arquivos soltos: `model.*`, `animacao.vmd`, props (`saveProps`), rig, secondary. `FORMAT_VERSION = 1`. Não há nós de cena nem hierarquia persistida. |
| Câmera | `OrbitCamera` (yaw/pitch/dist/alvo) é só de visualização e não é salva. Há uma única `vmdCam` (importada de VMD). Não é nó persistente. |
| Luz | Uma `LightCfg` direcional, guardada em SharedPreferences (não no projeto). |
| Outliner | `Outliner.kt`/`LayersPanel`: lista plana derivada do estado (modelo, props, luz, câmera, áudio). Só seleciona e oculta; sem renomear, agrupar, reordenar, duplicar. |
| GLB: animações | Não importadas (confirmado no README v1.14.0; `GlbParser.kt` 354 linhas). |
| Render/export por frame | Existe `captureAwait(frame)` no GL + `MediaExport.kt`/`AudioMux.kt`. Renderiza a cena atual, sem câmeras/cortes. |
| Testes | `ParserTest`, `ImportTest`, `KeyEditTest` (JVM). Nada para cena, câmera ou clock. |

**Riscos principais para a Release 8**
1. `SceneRenderer` está acoplado a um único modelo (GlModel, Animator, boneTex, matLive, estado de morph/sombra). Multi-instância exige extrair esse estado para uma classe por instância.
2. `Editor` e `SceneScreen` assumem um modelo ativo; é preciso um conceito de "instância ativa".
3. Memória/GL: cada instância tem VBO/IBO/texturas/textura de ossos; liberar na remoção (critério de aceite).
4. Projetos antigos (formatVersion 1) precisam migrar para o novo formato sem perda.

## Fase B — Plano da Release 8 (proposto, aguardando OK)

**Modelo de dados (novo `scene/SceneGraph.kt`, Kotlin puro, testável em JVM)**
- `SceneNode(id, name, type, parentId, visible, locked, local: Transform)`; tipos iniciais: `CHARACTER`, `PROP`, `GROUP` (CAMERA/LIGHT/AUDIO/EFFECT reservados para as releases seguintes).
- `Transform(pos, rotEuler, scale)` + cálculo de matriz global pela hierarquia.
- `CharacterData(assetFile, motionFile, ...)` por nó `CHARACTER`; `PropData` reaproveita `PropMeta`.
- Serialização em `scene.json` dentro da pasta do projeto, com `formatVersion` 2.

**Migração:** ao abrir projeto v1, criar `scene.json` com um nó `CHARACTER` (modelo principal) e nós `PROP` a partir de `props`. Backup de `project.json` antes de migrar.

**Instâncias independentes / sem duplicar Animator:** extrair do `SceneRenderer` uma classe `CharacterInstance` (GlModel, `Animator`, boneTex, morphs, matLive, motion). O renderer passa a manter `Map<nodeId, CharacterInstance>`. A classe `Animator` é reutilizada sem alteração, uma instância por personagem. Relógio único: `renderer.frame`.

**Integração com ProjectStore:** `ProjectStore.saveScene/loadScene` (escrita atômica, como `write()` já faz). `props`, `rig` e `secondary` continuam funcionando, migrando por nó em fatias posteriores.

**UI mínima:** Outliner passa a ler o Scene Graph (renomear, ocultar, bloquear, duplicar, excluir, personagem ativo). Sem controles novos além desses.

**Fatiamento (uma por vez, cada uma compilável):**
1. **8.1** `SceneGraph.kt` + serialização + migração v1→v2 + testes JVM (sem tocar na UI/GL).
2. **8.2** `CharacterInstance` extraída do renderer, ainda com 1 personagem (refatoração sem mudança de comportamento).
3. **8.3** Adicionar/remover 2º e 3º personagem, personagem ativo, reprodução simultânea.
4. **8.4** Outliner funcional (renomear, agrupar, duplicar, reordenar) + parent/child a ossos.

**Arquivos previstos em 8.1:** novos `scene/SceneGraph.kt`, `scene/SceneSerializer.kt`, `test/.../SceneGraphTest.kt`; alterado `project/Project.kt` (saveScene/loadScene, FORMAT_VERSION).

**Plano de testes 8.1:** hierarquia e matriz global; ciclo de pai inválido rejeitado; round-trip JSON; migração de projeto v1; arquivo corrompido.

**Estado:** Fase A concluída (estática). Fase B proposta. Fase C iniciada: 8.1 e 8.2 escritas (não compiladas/testadas).

## Correção ao plano (achada ao implementar 8.1)
O arquivo `scene.json` JÁ EXISTE na v1.17.0 e guarda só a lista de props (`ProjectStore.saveProps`). O plano dizia usar `scene.json` para o Scene Graph; isso sobrescreveria os props. **Decisão:** o grafo fica em `scenegraph.json` (versão própria dentro do arquivo). O `FORMAT_VERSION` do `project.json` NÃO foi aumentado nesta fatia, porque nada novo é gravado pela UI ainda; sobe na 8.3, quando o app passar a gravar o grafo.

## Fatia 8.1 — Scene Graph + serialização + migração (v1.18.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** base de dados da cena multi-instância, sem tocar UI nem OpenGL.

**Arquivos novos:** `scene/SceneGraph.kt`, `scene/SceneSerializer.kt`, `test/.../SceneGraphTest.kt`.
**Arquivos alterados:** `project/Project.kt` (`loadScene`, `saveScene`, `loadOrMigrateScene`), `build.gradle.kts` (versão 1.18.0, versionCode 41), `README.md`.

**Comportamento implementado**
- `SceneGraph` imutável (cada edição devolve um novo grafo, pronto para undo/redo). Tipos de nó: CHARACTER, PROP, GROUP, CAMERA, LIGHT, AUDIO, EFFECT (os quatro últimos só reservados).
- Operações: add, remove (com descendentes), rename, visível/trancado (herdados dos pais), setTransform (recusa nó trancado), personagem ativo, reparent (recusa ciclo, pai inexistente e osso em pai que não é personagem), move entre irmãos, agrupar, duplicar subárvore com ids novos.
- `Transform` (posição, rotação em graus, escala por eixo) e matriz global pela hierarquia (4x4 coluna-principal).
- `scenegraph.json`: leitura recusa JSON quebrado/sem versão/versão mais nova; danos parciais (id duplicado, tipo desconhecido, pai inexistente, ciclo, ativo inválido) viram **avisos**, não perda silenciosa.
- Migração v1: `SceneGraph.fromLegacy` + `ProjectStore.loadOrMigrateScene` (cria `project.v1.json.bak` uma vez, não altera o `scene.json` antigo). Props presos a osso viram filhos do personagem principal com `attachBone`.

**Limitações**
- Nada usa o grafo ainda: UI, Outliner e renderer seguem com um modelo só.
- A matriz do osso (`attachBone`) será resolvida pelo renderer na 8.2/8.4; `globalMatrix` ignora o osso.
- `reparent` mantém a matriz local (não compensa a global).
- Sem controle de assets órfãos ao remover nó (arquivos do projeto não são apagados).

**Testes:** 15 testes em `SceneGraphTest` escritos; **não executados** (sem Gradle/Kotlin aqui). Build não executado.
**Para testar:** `gradle testDebugUnitTest` (ou push no GitHub e ver o Actions). Reportar o log de erro de compilação, se houver. Nenhum teste de aparelho nesta fatia, pois não há mudança visível.
**Riscos:** erros de compilação Kotlin (escrito às cegas); o contrato de `GraphResult` e o uso de `ArrayDeque`/smart casts são os pontos a olhar primeiro.
**Próxima fatia:** 8.2 — extrair `CharacterInstance` do `SceneRenderer`, ainda com 1 personagem.

## Fatia 8.2 — CharacterInstance extraído (v1.19.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** extrair o estado GL + Animator de um personagem do `SceneRenderer` para uma classe interna, ainda com 1 personagem. Refatoração sem mudança de comportamento; prepara a fatia 8.3.

**Arquivos alterados:** `render/SceneGLView.kt` (classe interna `CharacterInstance` + uso de `mainChar`), `app/build.gradle.kts` (versão 1.19.0, versionCode 42), `README.md`.

**Comportamento implementado**
- `CharacterInstance` (inner class de `SceneRenderer`) guarda: `gl` (GlModel), `animator`, `boneTex`/`boneCount`/`boneRows`/`boneBuf`, flags de morph de posição/UV, `matLive`/`matLiveOn`, buffers do esqueleto (`bonePos`/`boneParent`/`boneVis`/`line*`/`pt*`), `lastModel`/`lastTex`/`curMotion`, `shBone`, `boneIdx`.
- O renderer mantém um único `mainChar`. `loadModel`, `setMotion`, `freeModel`, `updateSkin`, `drawBones`, `pick`, `dragBone`, restore de contexto e desenho de props presos a osso passam a usar `mainChar.*`.
- API pública de `SceneGLView` inalterada; UI não muda.

**Limitações**
- Ainda só um personagem. Não há mapa de instâncias nem personagem ativo.
- Nada de UI nova. O Scene Graph (8.1) continua sem ser lido pelo renderer.

**Testes:** nenhum novo (refatoração pura). Build não executado (sem Gradle/Kotlin aqui).
**Para testar:** push no GitHub e ver o Actions; instalar o APK e confirmar que o modelo carrega, anima, esqueleto, toque e arrasto continuam iguais. Reportar log de compilação se falhar.
**Riscos:** erro de compilação por campo não reescrito ou acesso a campo movido; ponto principal a olhar é `SceneGLView.kt` (CharacterInstance + mainChar).
**Próxima fatia:** 8.3 — adicionar/remover 2º e 3º personagem, personagem ativo, reprodução simultânea.

## Verificação da fatia 8.1 (19/11/2026, sem mudar código do app)
Compilei de verdade `scene/SceneGraph.kt` + `scene/SceneSerializer.kt` + `SceneGraphTest.kt` com o compilador Kotlin 2.0.21 (JVM) e rodei no JUnit 4.13.2: **0 erros de compilação, 15/15 testes passaram.** Ressalvas: `org.json` foi substituído por um stub mínimo (o real só existe no Android/Gradle) e `PropMeta` por uma cópia idêntica; o resto do app (Compose, OpenGL) NÃO foi compilado aqui. A fatia 8.2 (`SceneGLView.kt`) continua sem compilar. Status: 8.1 = lógica verificada em JVM; ainda falta build no Actions e teste no aparelho.

## Fatia 9.1 — Amostrador de animação glTF (v1.20.0) — LÓGICA VERIFICADA EM JVM; app NÃO compilado
**Objetivo:** base matemática da importação de animações GLB (Release 9): interpolação STEP, LINEAR (com slerp pelo caminho mais curto para quaternions) e CUBICSPLINE (Hermite com tangentes escaladas por dt; rotação normalizada).
**Arquivos novos:** `mmd/GltfSampler.kt`, `test/.../GltfSamplerTest.kt`. **Alterado:** `build.gradle.kts` (1.20.0 / versionCode 43).
**Verificação:** compilado com kotlinc 2.0.21 e executado no JUnit: 7/7 testes OK (linear/clamp, step, slerp, caminho curto, cubic, normalização, dados inválidos recusados).
**Limitações:** ainda NÃO ligado ao `GlbParser` (que continua avisando que animações não são importadas), sem clips, sem UI. Nada muda para o usuário.
**Para testar:** `gradle testDebugUnitTest` no Actions.
**Próxima fatia:** 9.2 — ler `animations` (samplers/channels) no `GlbParser` para `GltfSampler` e converter para keyframes do Editor.

## Fatia 9.2 — GlbParser lê animações glTF (v1.21.0) — LÓGICA VERIFICADA EM JVM; app NÃO compilado
**Objetivo:** ler `animations` (samplers/channels) do GLB/glTF em `GltfClip`/`GltfChannel`, sem aplicar ao modelo ainda.
**Alterados:** `mmd/GlbParser.kt` (`Parsed.clips`, parâmetro com default: `ModelImporter` não muda), `mmd/GltfSampler.kt` (+`GltfChannel`, `GltfClip`), `build.gradle.kts` (1.21.0 / 44). **Novo teste:** `GlbAnimParseTest.kt`.
**Comportamento:** canais translation/rotation/scale resolvem nó, nome e índice de osso (`-1` se o nó não é osso); STEP/LINEAR/CUBICSPLINE via `GltfSampler`. Canais com `weights`, alvo sem nó, sampler inválido ou tamanho errado viram **aviso** e são ignorados, sem derrubar o resto. O aviso antigo "animações não importadas" foi trocado por "N animação(ões) lidas; ainda não aplicadas".
**Verificação:** compilado com kotlinc 2.0.21 (com PmxModel real, org.json stub) e JUnit: 3/3 OK (clip com 2 canais e valores no meio do intervalo, canais inválidos, CUBICSPLINE com tamanho errado). `GlbParser` compilou inteiro fora do Android.
**Limitações:** morph weights não lidos; nada aplicado ao Animator/Editor/UI; testado só com um glTF sintético, não com arquivo real (Mixamo etc.).
**Próxima fatia:** 9.3 — converter clip → keyframes do Editor (conversão glTF→MMD de Z/quaternion, translação relativa ao repouso) e lista de clips na UI.

## Fatia 9.3 — Clip glTF → keyframes do Editor + ligação na importação (v1.22.0) — CONVERSOR VERIFICADO EM JVM; UI/Android NÃO compilados
**Objetivo:** fazer um GLB/glTF animado tocar no app ao importar (critério "importar um GLB com animação e reproduzi-la").
**Novos:** `mmd/GltfToMotion.kt` (`GltfRig`, `GltfToMotion.convert`), `test/.../GltfToMotionTest.kt`. **Alterados:** `GlbParser.kt` (`Parsed.rig`: repouso dos nós + escala), `importer/ModelImporter.kt` (`Result.clips/rig`, GLB solto e dentro de zip), `ui/SceneScreen.kt` (após importar modelo com clips: converte a 1ª animação, `editor.load`, ajusta duração e mostra no status), `GlbAnimParseTest.kt`, `build.gradle.kts` (1.22.0 / 45).
**Matemática:** por osso, delta = qAnim·conj(qRepouso); rotação MMD = Rp·delta·conj(Rp) (Rp = rotação de repouso global do pai glTF); depois (x,y,z,w)→(−x,−y,z,w). Deslocamento = Rp·(T−Trepouso)·escala, Z invertido. 1 key por quadro a 30 fps, curva linear, continuidade de sinal do quaternion.
**Comportamento:** usa só a 1ª animação (avisa se há mais). Canais de escala, de nós que não são ossos e `weights` são ignorados COM aviso. A animação entra no Editor, então é editável, salva no `animacao.vmd` do projeto e vai para as exportações. Nós com `matrix` no glTF: rotação de repouso tratada como identidade (aviso).
**Verificação:** 16/16 testes JVM (sampler 7 + parser 3 + conversor 6) compilando `GlbParser`/`PmxModel`/`VmdMotion` reais. `SceneScreen.kt` e `ModelImporter.kt` (Android) NÃO foram compilados.
**Não feito:** escolher outro clip (lista na UI), blend/camadas, root motion separado, retargeting entre esqueletos, animação de escala.
**Testar no aparelho:** importar um .glb/.zip com esqueleto e animação; deve aparecer "Animação 'x' importada" no status e o modelo se mover no play. Se a pose sair torta/espelhada, o ponto a ajustar é a conversão em `GltfToMotion.convert`; se nenhum osso casar, ver os avisos no log (tag GLB).
**Próxima fatia:** 9.4 — lista de clips com escolha na UI (feita na v1.23.0, ver abaixo) ou 8.3 — vários personagens.

## Fatia 9.4 — Lista de clips com escolha na UI (v1.23.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Objetivo:** um GLB/glTF com várias animações deixa de usar só a 1ª: o usuário escolhe qual aplicar.
**Alterados:** `ui/SceneScreen.kt` (estado `glbClips/glbRig/clipDlg/clipCur`, função `applyClip(i)`, item de menu "Animações do arquivo… (N)" no menu do viewport, diálogo abre sozinho ao importar se houver mais de 1 clip), `ui/StudioDialogs.kt` (+`ClipPickerDialog`), `build.gradle.kts` (1.23.0 / 46), `README.md`.
**Comportamento:** importar continua aplicando a 1ª por padrão; escolher outro clip roda `GltfToMotion.convert` em `Dispatchers.Default`, **substitui** as keys do editor (`editor.load`), ajusta a duração e volta ao quadro 0. A lista marca o clip em uso e mostra a duração.
**Limitações (v1.23.0; CORRIGIDO na v1.24.0 — a troca passou a usar `Editor.replaceUndoable`, desfazível):** trocar de clip não era desfazível (o `load` limpa o desfazer); ao reabrir o projeto a lista de clips NÃO é recarregada (o `animacao.vmd` salvo é o que volta); só um clip por vez (sem blend/camadas); sem pré-visualização do clip antes de aplicar.
**Verificação:** só revisão por leitura e balanceamento de chaves/parênteses; nenhum código novo de lógica pura (usa o conversor já testado 16/16 em JVM). Não compilado.
**Testar no aparelho:** importar um .glb com 2+ animações (ex.: Mixamo/Sketchfab) → o diálogo abre; escolher outra → o modelo muda de movimento no play; reabrir pelo menu "Animações do arquivo…".
**Próxima fatia:** 8.3 (vários personagens) ou o que o usuário escolher no menu.

# 12. Prioridades P0–P3 (nota complementar de 19/11/2026) — incorporadas
Fonte: `MMD_Studio_Nota_Atualizacoes_Prioridade.md` (nota complementar; NÃO substitui este documento). Nada foi removido; "menor prioridade" = fazer depois, não cancelar. Os marcadores P0–P3 estão no início de cada Release (seções 5 e 6).
**Legenda:** P0 essencial (bloqueia/sustenta outras áreas) · P1 alto valor · P2 complementar · P3 baixo retorno inicial.

| # | Item (ordem de utilidade) | Prioridade | Release | Tipo |
|---|---|---|---|---|
| 1 | Auditoria real, build e testes no Android | P0 | transversal | auditoria + correção |
| 2 | Scene Graph persistente + Outliner funcional | P0 | 8 | implementação nova |
| 3 | Múltiplos personagens independentes | P0 | 8 | implementação nova |
| 4 | Núcleo de animação + clips GLB, relógio único | P0 | 9 | implementação nova + correção |
| 5 | Ferramentas manuais (graph editor, layers, IK, root motion) | P0/P1 | 9 | implementação nova |
| 6 | Câmeras persistentes e Camera Director | P1 (base em P0) | 10 | implementação nova |
| 7 | Render por frame + exportação básica | P0/P1 | 16 (antecipado) | implementação nova |
| 8 | Estabilidade, desempenho, persistência | P0 contínuo | 6 | correção/refinamento |
| 9 | Luzes e materiais | P1 | 12 | implementação nova |
| 10 | Motion graphics 3D | P1 | 11 | implementação nova |
| 11 | Expressões faciais básicas | P1/P2 | 15 | implementação nova |
| 12 | VFX de ação essenciais | P1/P2 | 13 | implementação nova |
| 13 | Compositor 2D multicamada | P2 | 14 | implementação nova |
| 14 | Lip sync e facial avançada | P2 | 15 | refinamento futuro |
| 15 | Pós-processamento avançado | P2/P3 | 13/16 | refinamento futuro |
| 16 | Sistemas especializados (deformadores, luz de área, plugins, presets enormes) | P3 | — | refinamento futuro |

**Ordem técnica de execução (dependências):** auditoria → estabilidade/persistência → Scene Graph + Outliner → multi-personagem → Animation Clock → clips GLB → ferramentas manuais → câmeras → render/exportação básica com áudio → luzes/materiais → motion graphics → facial básico → VFX → compositor → render cinematográfico → especializados. Dividir em entregas pequenas; nunca uma release inteira sem testes.
**Ajuste de sequência (com a dependência):** a nota põe multi-personagem (3º) antes de mais trabalho de GLB; por isso, depois da v1.24.0, a próxima fatia de código deve ser a **8.3** (instâncias independentes), e não mais itens de glTF (morph weights/escala), que ficam para depois.

> **Atualização 19/11/2026:** a nota completa v1.28.1 foi incorporada na **seção 13** (escala 0–5, checklist de validação, segurança da assinatura, ordem 8.4 → 8.3d).

## 12.1 Regra dos cinco níveis (anti-progresso-falso)
Cada função é avaliada em: **Dados · Motor · Interface · Persistência · Saída**. Só vale "concluída" com os cinco + build + teste no aparelho. Classe, modelo de dados, botão ou tela isolados não contam.

## 12.2 Auditoria P0 (19/11/2026, v1.23.0→v1.24.0) — por leitura de código; build NÃO executado neste ambiente
| Sistema | Dados | Motor | Interface | Persistência | Saída | Observação real |
|---|---|---|---|---|---|---|
| Scene Graph | ✅ (testes JVM 15/15 em sessão anterior) | ❌ | ❌ | 🟨 `ProjectStore.loadOrMigrateScene/saveScene` existem, **nenhum chamador** | ❌ | Só o `ProjectStore` referencia o grafo; renderer, SceneScreen e Outliner não o usam |
| Outliner | — | — | 🟨 `LayersPanel` existe, alimentado por props/modelo (não pelo grafo); só selecionar/ocultar | ❌ | — | Faltam renomear, bloquear, duplicar, agrupar, reordenar sobre o grafo |
| Multi-personagem | 🟨 `CharacterInstance` | ❌ só `mainChar` | ❌ | ❌ | ❌ | Prepara 8.3; hoje só 1 personagem animado |
| Importação GLB animada | ✅ clips + `GltfSampler` (JVM) | ✅ `GltfToMotion` (JVM 16/16) | 🟨 v1.22–1.24, **não compilada** | 🟨 vira keys no `animacao.vmd`; lista de clips não recarrega ao reabrir | 🟨 via `Animator` (não testado) | Faltam escala, morph weights, loop/trim/blend |
| Aplicar clip sem destruir keys | — | ✅ v1.24.0 `Editor.replaceUndoable` | ✅ | — | — | **Correção**: antes (v1.23.0) a troca limpava o desfazer; agora é 1 passo de desfazer (teste novo em `KeyEditTest`, não executado) |
| Build/testes no Android | — | — | — | — | — | **Nenhuma versão da v1.13.0 à v1.24.0 teve build confirmado.** Bloqueio nº 1: rodar o Actions, enviar o log e testar no aparelho |

**Próximas ações P0 (ordem):** (1) usuário: build no Actions + roteiro no celular das v1.14–v1.24; (2) corrigir erros de compilação do log; (3) fatia 8.3 (instâncias independentes + personagem ativo + relógio global); (4) Outliner ligado ao Scene Graph (renomear, ocultar, bloquear, duplicar, agrupar, reordenar, undo); (5) recarregar a lista de clips ao reabrir.

## Fatia 9.5 — Troca de clip desfazível (v1.24.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Motivo:** a nota de prioridades exige que aplicar/importar um clip não destrua keyframes existentes. **Alterados:** `edit/Editor.kt` (+`replaceUndoable`: troca todas as keys como um passo de desfazer, sem limpar o histórico), `ui/SceneScreen.kt` (`applyClip` usa `replaceUndoable`; não encolhe a duração total), `ui/StudioDialogs.kt` (texto), `test/.../KeyEditTest.kt` (+teste de troca/desfazer/refazer), `build.gradle.kts` (1.24.0 / 47), `README.md`, este roadmap (marcadores P0–P3, seção 12).
**Limitação:** a importação inicial do GLB (1ª animação) ainda usa `editor.load` ao criar um modelo novo (editor novo, nada a preservar). `vmdExtras` não é restaurado pelo desfazer. Teste novo não executado (sem kotlinc neste ambiente).

## Correção de build (v1.24.1, 19/11/2026)
Primeiro log real do Actions (build de 19:25): `SceneGLView.kt:590:85 Unresolved reference: shBone`. Causa: a extração do `CharacterInstance` (v1.19.0, fatia 8.2) deixou uma referência sem `mainChar.`. Corrigido (1 linha). Era o único erro listado; outros podem aparecer na fase seguinte (testes/dex). Status: aguardando novo build.

## Registro 19/11/2026 (noite) — primeiro build que abriu no aparelho + v1.24.2
- Print do aparelho (19:42): app abre, tela Scene 3D com modelo, modos Solid/Material/Render/MMD, painel Luz com "Aparência" (v1.17.0+). Conclui-se que o build corrigido compilou e rodou; **versão exata não confirmada pelo usuário** — tratar v1.14–v1.24.1 como "compilou e abriu", cada função ainda sem teste explícito.
- Defeito achado no print e corrigido na v1.24.2: rótulos do painel de Luz quebravam em duas linhas (largura 64 dp). Agora 92 dp, 1 linha, valor com folga do slider.
- **Decisão sobre a 8.3 (vários personagens):** o renderer tem ~72 referências a `mainChar` (draw, sombra, contorno, skinning GPU, morphs de posição/UV/material, esqueleto) e `RigState` (restrições, ação secundária, física) é um objeto GLOBAL. Fazer a 8.3 de uma vez, sem compilador, arrisca quebrar o app que acabou de abrir. Plano em 3 passos pequenos: **8.3a** parametrizar draw/skin/sombra por `CharacterInstance` (comportamento idêntico, 1 personagem); **8.3b** tirar o estado de `RigState` para dentro da instância; **8.3c** adicionar o 2º personagem com Animator/Editor próprios e relógio global. Cada passo só avança depois de build + teste no aparelho.

## Fatia 8.3a — Renderer parametrizado por instância (v1.25.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Prioridade:** P0 (múltiplos personagens independentes). **Tipo:** refatoração sem mudança de comportamento, preparatória.
**Alterado (só `render/SceneGLView.kt`, `build.gradle.kts` 1.25.0 / 50, `README.md`):**
- `CharacterInstance` ganhou `lastFrame` (antes: campo global do renderer, que faria a 2ª instância pular a atualização da GPU).
- Nova lista `chars = arrayListOf(mainChar)`.
- `updateSkin()` → `updateSkin(ch)`; `onDrawFrame` chama para cada instância.
- `drawModel(..., ch = mainChar)`: textura de ossos e morphs de material vêm da instância; o desenho do modelo e o mapa de sombra percorrem `chars`.
**Ainda ligado só ao `mainChar` (de propósito, ficam para 8.3b/8.3c):** esqueleto desenhado (`drawBones`), seleção/arrasto de osso (`pick`, `dragBone`), objetos presos a osso, sombra de contato e centro da luz, `loadModel`/`freeModel`, `RigState` global (restrições, ação secundária, física).
**Critério:** o app deve se comportar exatamente como na v1.24.2 (modelo, sombra, morphs de material/UV/posição, troca de modo Solid/Material/Render/MMD). Qualquer diferença visual = regressão desta fatia.
**Verificação:** só leitura + balanceamento de chaves/parênteses; sem compilador.
**Próxima:** 8.3b — mover `RigState` (restrições/secundário/física) para dentro da instância; depois 8.3c (2º personagem + relógio global).

## Fatia 8.3b — Rig por personagem (v1.26.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Prioridade:** P0. **Tipo:** refatoração sem mudança de comportamento, preparatória para o 2º personagem.
**Problema:** `RigState` era um `object` global (restrições, ação secundária, física, cache da física) lido direto pelo `Animator`; dois personagens teriam compartilhado tudo.
**Alterado:** `rig/Constraints.kt` (+`RigConfig`; `RigState` virou atalho para `RigState.main`, com get/set que delegam), `mmd/Animator.kt` (construtor ganha `rigConfig` com padrão `RigState.main`; propriedade `rig`; 6 leituras de `RigState.*` trocadas por `rig.*`), `rig/PhysCache.kt` (`PhysBake.run(..., rig = RigState.main)` cria o `Animator` com essa config), `test/.../RigConfigTest.kt` (novo, não executado), `build.gradle.kts` (1.26.0 / 51), `README.md`.
**Não muda:** `SceneScreen`/`EditPanels` continuam gravando em `RigState.list/secondary/phys/physCache` (vão para a config principal); salvamento do projeto idem. O Animator do personagem principal usa `RigState.main`, então o app deve se comportar como na v1.25.0.
**Critério de teste:** restrições (aba Rig), ação secundária, física real ligada, "Calcular cache"/"Limpar cache" e exportação GLB/FBX com física funcionam como antes.
**Ainda falta para o 2º personagem (8.3c):** instanciar outro `Animator` com `RigConfig()` própria, UI para escolher o personagem ativo (e apontar `RigState`/painéis para a config dele), relógio global, salvar/reabrir as instâncias no Scene Graph.

## Fatia 8.3c — Elenco: 2º/3º personagem, movimento próprio, relógio global (v1.27.0) — LÓGICA PURA VERIFICADA EM JVM; renderer/UI ESCRITOS, NÃO COMPILADOS NO ANDROID
**Prioridade:** P0 (múltiplos personagens independentes). **Retoma o trabalho que a IA anterior não terminou:** o vídeo do usuário mostra o limite de uso estourando logo após "próxima", no início desta fatia (nenhum código da 8.3c existia na v1.26.0).
**Decisão de escopo:** o principal continua sendo editado pelas abas Animação/Esqueleto (Editor único). Os personagens EXTRAS têm movimento próprio vindo de arquivo (.vmd ou animação do GLB), transformação e visibilidade próprias. Editar ossos/keyframes de um extra pelo Editor (trocar o "personagem ativo" de edição) fica para a 8.3d, porque exige um Editor por personagem e repontar painéis/dope sheet.
**Novos:** `scene/Cast.kt` (`CastMeta`, `CastCodec`: JSON tolerante, versão, ids duplicados/ausentes viram aviso, escala limitada, `totalFrames` = relógio global), `ui/CastPanel.kt`, `test/.../CastTest.kt`.
**Alterados:** `render/SceneGLView.kt`, `ui/SceneScreen.kt`, `project/Project.kt`, `ui/ScenePanel.kt` (`PropSlider` agora `internal`), `app/build.gradle.kts` (1.27.0 / 52), `README.md`.
**Renderer:** `CharacterInstance` ganhou `id` e transformação (x,y,z,ry,s); `loadModel` foi dividido em `buildChar(ch, m, tex, rig)` (cria GL + Animator de UM personagem; devolve os limites) + o enquadramento da câmera, que continua só do principal; `freeModel` → `freeChar(ch)`. Extras: `addChar/removeChar/setChar/setCharMotion` (thread GL) e, na view, `addCharacter/removeCharacter/setCharacter/setCharacterMotion`. Cada extra cria o `Animator` com uma `RigConfig()` própria (restrições/física do principal não vazam). Matriz de mundo por personagem (`charMat`) vai no `uModel` (o skinning já sai em espaço GL, então só multiplica depois); o principal usa a identidade, como antes. Desenho e mapa de sombra percorrem `chars` respeitando a chave de ocultar `char:<id>`. Contexto GL recriado: ids antigos dos extras são zerados antes de reconstruir (para não apagar buffers novos), depois cada extra é refeito com o movimento atual.
**Relógio global:** continua sendo `renderer.frame` (um só); todos os personagens avaliam o mesmo quadro. `total` passa a ser `max(total, maior movimento + 1)`.
**UI:** chip **Elenco** (painel: + Personagem, lista, Remover, Importar/Limpar movimento, sliders X/Y/Z/Giro/Esc); Layers mostra cada extra (olho = ocultar). GLB animado entra com a 1ª animação como movimento (salvo como `cast/<id>.vmd` via `Editor.toVmd`). Importar o mesmo arquivo 2x cria 2 personagens independentes (id novo, arquivo novo).
**Persistência:** `cast.json` (escrita atômica) + `cast/<id>.<ext>` + `cast/<id>.vmd`. Entra no .zip do projeto (a pasta inteira é zipada). Se um personagem não abrir ao reabrir, fica em `castMissing` e é PRESERVADO no `cast.json` (nada é apagado em silêncio) e o status avisa.
**Testes:** `CastTest` 5/5 em JVM (round-trip, JSON corrompido, versão futura, ids duplicados/ausentes, relógio global) — compilado com kotlinc 2.0.21 + org.json stub. `SceneGLView.kt`/`SceneScreen.kt`/`CastPanel.kt`/`Project.kt` só passaram por checagem de sintaxe do parser Kotlin e balanceamento; NÃO compilados (sem Android SDK).
**Limitações:** (1) extras NÃO entram nas exportações GLB/FBX/VMD/VPD (só o principal); o VÍDEO/PNG capturam a cena toda, extras inclusos. (2) Sem esqueleto/seleção/arrasto de osso nos extras. (3) Sombra de contato (modo Rendered sem shadow map) e centro/raio do mapa de sombra seguem o principal: extras longe dele podem ficar sem sombra. (4) Sem física/restrições na UI para extras (a `RigConfig` existe, mas nenhuma tela a edita). (5) Scene Graph (8.1) ainda NÃO é gravado/lido pela UI: o elenco usa `cast.json` próprio; unificar é a 8.4. (6) Extras não são objetos pais de props (prender a osso só vale para o principal). (7) Sem rotação X/Z, só giro em Y.
**Para testar no aparelho:** (a) abrir projeto com modelo animado → chip Elenco → "+ Personagem" → escolher .pmx/.zip: o 2º personagem aparece ao lado, parado; (b) "Importar movimento (.vmd)": ele dança junto com o principal ao dar play, sem o principal mudar; (c) mexer nos sliders: só o selecionado se move; (d) olho no Layers oculta só ele; (e) adicionar um 3º; (f) fechar e reabrir o projeto: todos voltam com posição e movimento; (g) remover um: some e o app não trava; (h) exportar vídeo: os extras aparecem; (i) background/voltar ao app (contexto GL recriado): todos reaparecem.
**Riscos:** erros de compilação (escrito às cegas) — olhar primeiro `SceneGLView.kt` (`buildChar`, `addChar`) e o bloco `castPicker` em `SceneScreen.kt`; GL: textura de ossos por instância (já era por instância desde a 8.3a).
**Próxima:** 8.3d — personagem ativo de edição (Editor por personagem, esqueleto/dope sheet para extras) ou 8.4 (Outliner sobre o Scene Graph + elenco no grafo).

## Cartoon Motion Library — P1, P2 e P3 (v1.28.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO; lógica pura com testes JVM ESCRITOS mas NÃO EXECUTADOS (sem kotlinc neste ambiente)
**Origem:** pedido do usuário (documento "NOVA FUNCIONALIDADE — Cartoon Motion Library"). O zip v1.27.0 não tinha NENHUM código dela (a IA anterior bateu no limite antes de começar), então foi feita do zero.
**Análise da arquitetura (item 8 do pedido):** VMD é lido por `VmdParser` → `VmdMotion`; o `Editor` guarda as keys (`BKey`/`MKey`) e entrega `motion()` ao `Animator`, que associa pelo NOME do osso (ossos que o modelo não tem são ignorados). Por isso NÃO foi criado um segundo sistema de animação: a biblioteca gera/lê keys e grava no Editor (desfazer, dope sheet, exportação VMD e salvamento continuam funcionando).
**Novos:** `cartoon/CartoonCore.kt` (puro: `Clip`, `CartoonParams`, `CartoonMath.build/combine`, `BoneGroups`), `cartoon/CartoonBuiltin.kt` (30 movimentos originais gerados em código, 8 categorias), `cartoon/CartoonLibrary.kt` (itens da casa + VMD importados em `filesDir/cartoon` + `library.json`), `ui/CartoonPanel.kt`, `test/.../CartoonTest.kt` (14 testes).
**Alterados:** `edit/Editor.kt` (`applyKeys`: grava com as curvas Bézier preservadas, 1 passo de desfazer), `ui/SceneScreen.kt` (chip **Cartoon**, painel, seletor de .vmd, prévia, aplicar), `app/build.gradle.kts` (1.28.0 / 53), `README.md`.
**P1:** lista por categoria (Idle, Walking, Running, Reactions, Body Movement, Facial Expressions, Slapstick, Hand Gestures) com nome, categoria, duração, compatibilidade (% dos ossos que existem no modelo), miniatura (perfil de energia do movimento — NÃO é render 3D), **Prévia** (troca só o movimento mostrado; as keys do projeto não mudam; para ao dar play) e **Aplicar** (no quadro atual, substitui as keys daquelas trilhas no trecho, desfazer reverte tudo). **+ Importar VMD** copia o arquivo para o app (sem links externos) e entra na categoria selecionada no filtro (ou Body Movement).
**P2:** velocidade, duração do ciclo, intensidade (0–200%: rotação em eixo-ângulo e posição), repetições (loop 1–8; clip que fecha repete sem emenda; o que não fecha ganha emenda de ≥1 quadro, maior com Suavização), quadro inicial/final do original, suavização (mistura as curvas com ease), prévia em loop.
**P3:** combinar com outro movimento por GRUPOS (Corpo, Cabeça, Braços, Pernas, Rosto/morphs). Cada osso/morph vem de uma única fonte → sem conflito; o outro movimento repete para cobrir a duração.
**P4 (Squash & Stretch) — NÃO IMPLEMENTADO. Investigação:** VMD não tem escala de osso; o `Animator` só aplica uma escala uniforme global (`rows[o]=scale`). Caminho viável: trilha própria de escala (X/Y/Z, volume constante) guardada no projeto e multiplicada na matriz do osso raiz dentro do `Animator.evaluateRows` (só o transform final, sem tocar na malha → sem deformação permanente), com preset de salto/aterrissagem/impacto. Mexe no renderer e na exportação, por isso fica para a próxima fatia, depois do build desta.
**Fontes de movimentos (item 7):** só os movimentos originais do projeto (sem licença de terceiros) + importação local de .vmd pelo usuário. Nenhum link externo foi usado nem é necessário.
**SINAIS NÃO VERIFICADOS:** convenções de eixo dos movimentos da casa (tronco para a frente = X+ em 上半身; perna para a frente = X− em 足; braço esquerdo sobe com Z−; braço esquerdo vai para a frente com Y+) estão como constantes no topo de `CartoonBuiltin.kt`. Se algum movimento sair invertido no aparelho, é só trocar o sinal ali.
**Limitações:** prévia só do personagem principal (não dos extras do Elenco); aplicar também só no principal; a combinação usa a mesma velocidade/intensidade/suavização nos dois movimentos; categoria de VMD importado não pode ser trocada depois (excluir e reimportar); duração em quadros a 30 fps; morphs usam nomes comuns (まばたき, 笑い, 困る, 怒り, 驚き, あ) — se o modelo não tiver, são ignorados.
**Para testar no aparelho:** (a) chip Cartoon → lista com 30 movimentos; (b) ▶ Prévia em "Caminhada cartunesca": o modelo anda, ■ Parar volta à pose anterior e o projeto não muda; (c) Aplicar num quadro > 0: keys aparecem no dope sheet a partir do quadro atual; Desfazer remove tudo; (d) sliders de velocidade/intensidade/repetições mudam o resultado e o "Resultado: N quadros"; (e) combinar "Caminhada cartunesca" com "Acenar" nos grupos Cabeça+Braços; (f) importar um .vmd, reabrir o app, ver que continua na lista; (g) exportar o VMD do projeto depois de aplicar.
**Riscos de build:** escrito às cegas — olhar primeiro `CartoonPanel.kt` e o bloco `cartoonPanel` em `SceneScreen.kt`. `CartoonTest` não foi executado.
**Próxima:** build no Actions + roteiro acima; depois P4 (Squash & Stretch no `Animator`) e extras do Elenco como alvo da biblioteca.

---

# 13. Nota de melhorias, prioridades e próximas atualizações (v1.28.1) — INCORPORADA em 19/11/2026
Fonte: `MMD_Studio_Nota_Completa_Melhorias_Prioridades_v1_28_1.md` (nota complementar; NÃO substitui este documento e não apaga nada dele). Esta seção é a **tradução da nota para o roadmap**: o que já estava coberto (aponta para a Release), o que é novo (marcado **[NOVO]** e também acrescentado dentro da Release correspondente na seção 5) e o que foi ajustado. Nenhuma funcionalidade foi marcada como pronta por causa desta seção: é só planejamento.

## 13.1 Escala de comprovação (0–5) — complementa a regra dos cinco níveis da seção 12.1
| Nível | Significado |
|---|---|
| 0 — Ausente | Não existe implementação identificável |
| 1 — Estrutura | Existem modelos/classes/dados, sem fluxo funcional completo |
| 2 — Motor | O sistema executa a função em código |
| 3 — Interface | A função é editável e acessível pela UI |
| 4 — Persistência | Salva e reabre corretamente |
| 5 — Validado | Testado em Android real e, quando aplicável, exportado/reproduzido |

Correspondência: Dados≈1, Motor≈2, Interface≈3, Persistência≈4, Saída+teste no aparelho≈5. Não subir o nível sem evidência (build, log, teste no aparelho).

## 13.2 Estado de cada área da nota, por leitura do código v1.28.1 (nenhum build/teste novo foi feito neste ambiente)
| Área da nota | Prio. | Onde está neste roadmap | Nível hoje (evidência) |
|---|---|---|---|
| Validação v1.28.1 (build, APK, testes) | P0 | 13.3 (esta seção) + seção 6.4 | **0–1** para v1.25–v1.28.1: escritas, build do log real só confirmou até v1.24.1 (abriu no aparelho). Nada validado em 5 |
| Scene Graph + Outliner real | P0 | Release 8, fatia 8.4 | Graph: 1 (testes JVM 15/15; só `ProjectStore` o referencia). Outliner: 1–3 parcial (`LayersPanel`: selecionar/ocultar; não usa o grafo) |
| Edição completa de múltiplos personagens | P0 | Release 8, fatia 8.3d (**= "Release 8.5" da nota**) | Elenco 8.3c: 2 (renderer/UI escritos, não compilados); persistência `cast.json` 4 só no papel. Edição independente (ossos/morphs/keys/dope sheet por personagem): 0 |
| Graph Editor, camadas, blending, IK, root motion, retargeting, GLB | P0/P1 | Release 9 | Editor de curvas de interpolação Bézier por key (Etapa 7, confirmado) ≠ Graph Editor completo. GLB clips→keys: 2 (JVM 16/16), UI 3 não compilada, lista de clips não recarrega (nível 3, não 4). Resto: 0 |
| Camera Director | P1 | Release 10 | Câmera do viewport e câmera VMD (v1.3/v1.8): 2–3. Câmeras múltiplas/cortes/DoF: 0 |
| Lighting & Material Studio | P1 | Release 12 | Luz única + aparência/toon (v1.17.0): 2–3 sem teste. Múltiplas luzes e editor de materiais: 0 |
| Cartoon Motion Library avançada | P1/P2 | seção "Cartoon Motion Library" (fim) | P1–P3: 3 escrita, 14 testes JVM escritos não executados. Squash&Stretch/Anticipation avançada/extras do Elenco como alvo: 0 |
| Motion Graphics 3D | P2 | Release 11 | 0 |
| VFX & Particle System | P2 | Release 13 | 0 |
| VFX & Compositor 2D | P2 | Release 14 | 0 (exportação de vídeo/PNG básica existe, v0.11/v1.x, sem validação registrada pós-1.24) |
| Facial Animation | P2/P3 | Release 15 | Morphs editáveis e VMD de morph: confirmados (Etapas 4–5). Presets/lip sync/painel facial: 0 |
| Compatibilidade e ferramentas especializadas | P3 | 13.6 | ver tabela |
| Segurança da assinatura do APK | **transversal, fazer cedo** | 13.4 | **Problema confirmado no código** (ver 13.4) |
| Documentação e versionamento | transversal | 13.5 | README cita v1.28.x; changelog está espalhado em seções |
| Qualidade e desempenho no Android | P0 contínuo | seção 6.3/6.4 + 13.7 | parcial (cache de física, passo fixo, prévia 60 fps) sem medição em aparelho |

## 13.3 P0 — Checklist de validação da v1.28.1 (bloqueia as próximas releases)
Só marcar com evidência (log, print, descrição do teste). Enquanto isto não passar, nenhuma release nova é "concluída".
- [ ] Build limpo de debug no Actions; log salvo; erros e warnings relevantes corrigidos (primeiro olhar: `SceneGLView.kt` `buildChar/addChar`, `CartoonPanel.kt`, `CastPanel.kt`, bloco `castPicker`/`cartoonPanel` em `SceneScreen.kt`).
- [ ] Rodar a suíte JVM (`gradle testDebugUnitTest`) de verdade e **remover `continue-on-error`** do workflow quando passar (hoje falha de teste não bloqueia o APK).
- [ ] Instalar e abrir o APK no aparelho de referência (anotar modelo do aparelho e Android).
- [ ] Abrir projetos existentes (criados em versões antigas) sem corrupção; conferir migração `scene.json` → `scenegraph.json`.
- [ ] Importar PMX e tocar VMD (regressão das Etapas 2–3).
- [ ] Cartoon Motion Library: prévia, aplicar, combinar, importar VMD, desfazer (roteiro (a)–(g) na seção da Cartoon).
- [ ] Elenco: selecionar, mover independente, salvar, reabrir (roteiro (a)–(i) da seção 8.3c).
- [ ] Acessórios presos a ossos; física e restrições; desfazer/refazer em operações relevantes.
- [ ] Áudio; exportação MP4, PNG e sequência PNG (com extras inclusos).
- [ ] Projeto grande: anotar memória, temperatura, FPS.
- [ ] Registrar cada bug com passos para reproduzir + log.
**Critério:** release só vira "validada" (nível 5) com build + instalação + execução + teste funcional no Android. Teste JVM isolado não substitui.

## 13.4 Segurança da assinatura do APK — ACHADO REAL (auditoria de leitura do zip v1.28.1)
- `app/build.gradle.kts` (linhas 6–11) contém `storePassword`/`keyPassword` **em texto puro** (`"mmdstudio2026"`) e o arquivo **`app/mmdstudio.jks` está dentro do zip/repositório**. Se o repositório `mateusrprj-prog/order` for público, a chave de assinatura está exposta.
- Não há `.gitignore` no projeto (o repositório é montado por upload de `.zip`, então o zip inteiro, jks incluso, vai para o Git).
- **Tarefas (nenhuma feita ainda — código NÃO foi alterado nesta fatia de propósito):**
  - [ ] Verificar se o repositório é público e se o jks/senha estão no histórico Git.
  - [x] (v1.28.2, escrito, não compilado) Mover senhas para variáveis de ambiente/GitHub Secrets (`System.getenv`) e o jks para Secret (base64) decodificado no workflow; manter fallback só para build local do dono.
  - [x] (v1.28.2) Adicionar `.gitignore` (`*.jks`, `*.keystore`, `keystore.properties`, `local.properties`).
  - [ ] Decidir sobre rotação da chave: **NÃO descartar a chave atual sem avaliar o impacto**. Trocar a chave exige desinstalar o app (perde projetos locais) para quem já instalou. Alternativa: manter a chave, remover o jks do repositório, apagar o histórico se possível e aceitar o risco ou rotacionar quando fizer sentido (avisar o usuário antes e oferecer exportar projetos).
  - [x] (v1.28.2) Documentar o processo de assinatura (local e CI) no README.
- Observação: o build do workflow é `assembleDebug` (assinado com a chave debug do Gradle); a chave `release` só vale se um build release for feito. Mesmo assim o jks e as senhas expostos devem ser tratados como segredo vazado.
- **Atenção:** mexer em `build.gradle.kts`/workflow sem compilar pode quebrar o build. Fazer como fatia própria, com o usuário rodando o Actions em seguida.

## 13.5 Documentação e versionamento
- [x] (v1.28.2) README: refletir a versão real (hoje 1.28.1/versionCode 54) e o que está só escrito vs. validado.
- [x] (v1.28.2) Criar `CHANGELOG.md` por release (hoje o histórico está espalhado entre o md de contexto, esta seção 11 e o README).
- [ ] Manter quatro estados separados em toda entrada: **implementado / parcial / planejado / validado** (usar a escala 0–5 da 13.1).
- [ ] Registrar limitações conhecidas e formatos suportados com arquivos reais testados.
- [ ] Atualizar instruções de build (workflow, Gradle 8.7, remoção do `continue-on-error`).
- [ ] Manter este roadmap consistente com o código a cada fatia.

## 13.6 P3 — Compatibilidade e ferramentas especializadas
Priorizar pela demanda real e só depois da estabilidade dos sistemas centrais. Não declarar compatibilidade completa sem testar arquivos reais representativos.
| Área | Melhoria | Observação |
|---|---|---|
| FBX | Importação e validação da exportação de animação | FBX exporta (deformava no Aurea, corrigido sem teste); importação não existe |
| PMX | Editor mais completo de propriedades do modelo | escritor PMX existe (v1.10.0, não validado) |
| VPD | Avaliar exportação de morphs | |
| Física | Diagnóstico, visualização e cache | cache/bake existe (v1.14.0); visualização/debug não |
| GLB/glTF | Extensões e recursos | morph weights e escala = Release 9 |
| Materiais | Compatibilidade com materiais externos | liga com Release 12 |
| Assets | Biblioteca e gerenciamento de assets | **[NOVO]** |
| Projetos | Empacotamento de dependências e recursos | **[NOVO]** (hoje o projeto vira .zip da pasta) |
| Desempenho | LOD, qualidade de prévia, monitoramento | liga com 6.3 |

## 13.7 Qualidade e desempenho no Android (complemento da seção 6.3/6.4)
- [ ] Medir memória (CPU/GPU) em cenas com vários personagens, FPS da viewport, tempo de carregamento de modelos, temperatura e bateria em sessões longas.
- [ ] Níveis de qualidade de viewport; LOD quando necessário; evitar alocações por quadro; operações pesadas fora da thread de UI.
- [ ] Cancelamento e feedback em importações e renders demorados **[NOVO como requisito explícito]**.
- [ ] Autosave e recuperação de projetos (autosave existe; recuperação de sessão após falha não está validada).
- [ ] Testar projetos grandes e casos de falha.

## 13.8 Ordem de releases — conciliação com a nota
A nota propõe: validação → 8.4 Scene Graph+Outliner → 8.5 Multi-Character Editing → 9 → 10 → 11 → 12 → 13 → 14 → 15 → 16. Este roadmap **já tem** as Releases 9–16 com os mesmos objetivos, então **não foram duplicadas nem renumeradas**. A diferença é só dentro da Release 8:
| Ordem | Etapa | Equivale a |
|---:|---|---|
| 1 | Validação v1.28.1 (13.3) + segurança da assinatura (13.4) | P0 |
| 2 | Release 8, fatia **8.4** — Scene Graph + Outliner real (elenco entra no grafo) | nota 8.4 |
| 3 | Release 8, fatia **8.3d** — edição independente de múltiplos personagens | nota "8.5 Multi-Character Editing" |
| 4 | Release 9 — Animation System Pro | igual |
| 5 | Release 10 — Camera Director | igual |
| 6 | Release 11 — Motion Graphics 3D | igual |
| 7 | Release 12 — Lighting & Material Studio | igual |
| 8 | Release 13 — VFX & Particle System | igual |
| 9 | Release 14 — VFX & Compositor 2D | igual |
| 10 | Release 15 — Facial Animation | igual |
| 11 | Release 16 — Cinematic Render | igual |
**Ajuste de dependência registrado:** antes o menu recomendava 8.3d antes da 8.4. A nota inverte (8.4 antes). A razão técnica é válida: o grafo dá IDs estáveis e a hierarquia dos personagens, e a 8.3d precisa deles para guardar Editor/keys por personagem sem criar um terceiro formato (`cast.json` já é um segundo). Nova ordem: **validar → 8.4 → 8.3d**. Se o build mostrar que a 8.3c está quebrada, corrigir a 8.3c antes de ambos.

## 13.9 Regras de arquitetura e implementação (nota, partes IV) — o que é novo em relação à seção 8
A seção 8 já cobre a maioria. Acrescentado/reforçado:
- IDs estáveis para personagens, objetos, câmeras, luzes e componentes; **um Animation Clock compartilhado**, avaliação determinística por frame; estado de animação independente por personagem; exportadores consumindo a mesma representação de cena sempre que possível.
- Proibido: botão decorativo, tela que simula função, dado que o motor não consome, "pronto" porque existe classe.
- Toda edição importante considera Undo/Redo; toda propriedade persistente sobrevive a salvar/reabrir; a UI reflete o estado real do motor; prever carregamento, erro, cancelamento e ausência de dados.
- Em cada entrega registrar: arquivos alterados, decisões técnicas, limitações e testes executados (já exigido na seção 8, "Para cada entrega").

## 13.10 Checklist da IA para esta incorporação
- [x] Li o roadmap principal (`docs/MMD_Studio_Roadmap_Master_Production_Claude.md`) e o md de contexto.
- [x] Comparei todos os itens da nota com o roadmap (tabela 13.2).
- [x] Incorporei as prioridades neste arquivo; conteúdo anterior mantido integralmente.
- [x] Evitei duplicar releases; itens novos foram acrescentados nas Releases 8, 9, 10, 12, 15 e 16 (marcados **[NOVO — nota v1.28.1]**).
- [x] Diferenciei implementação de validação (escala 0–5; ninguém foi elevado).
- [x] Registrei pendência de build/teste Android (13.3) e o achado de segurança (13.4).
- [ ] Build e testes no aparelho — **dependem do usuário**.
- [ ] Correção de assinatura e `.gitignore` — **não feitas** (risco de quebrar build; ver 13.4).

**Registro v1.28.2 (19/11/2026):** feitas as tarefas de segurança/documentação acima. `app/mmdstudio.jks` saiu do zip (cópia em `backup_chave/`); chave NÃO rotacionada. Ainda pendente: checar se o repositório é público/histórico Git, Secrets no workflow, decisão sobre rotação. Tudo escrito, NÃO compilado.

## Fatia 8.4a — Outliner funcional (v1.29.0) — ESCRITA, NÃO COMPILADA, NÃO TESTADA; lógica pura com 8 testes JVM ESCRITOS, NÃO EXECUTADOS (sem kotlinc neste ambiente)
**Origem:** prompt de atualizações v1.28.1, prioridade 0, item 2. **Decisão de arquitetura:** em vez de religar tudo ao `SceneGraph` (v1.18, ainda sem chamadores) às cegas, o Outliner trabalha sobre as entidades reais (modelo, `PropMeta`, `CastMeta`) usando as MESMAS chaves do renderer (`model`, `prop:<id>`, `char:<id>`). Assim nada é duplicado e o que já funciona (cast.json, props) não muda de formato. Unificar com o `SceneGraph` continua pendente (8.4b).
**Novos:** `scene/OutlinerState.kt` (puro: nomes, bloqueio, renderOff, grupos, ordem; `arrange`, `move`, `makeGroup`, `addToGroup`, `ungroup`, `forget`, `prune`, codec tolerante), `test/.../OutlinerStateTest.kt`. **Alterados:** `ui/Outliner.kt` (`LayersPanel` com barra de ações; `Layer`/`OutlinerActions`), `ui/SceneScreen.kt` (estado `outl`, ações, bloqueio nos painéis, visível no render nas exportações, duplicar/excluir), `project/Project.kt` (`loadOutliner/saveOutliner`, `duplicateProp/duplicateCast`), `build.gradle.kts` (1.29.0 / 56), README, CHANGELOG.
**Feito (no código):** renomear (prop/personagem gravam no próprio meta; modelo e grupo no outliner.json); mover ↑↓ entre irmãos; bloquear (prop/personagem/grupo: recusa mover pelos sliders, excluir e trocar/limpar movimento); visível no render (modelo/prop/personagem/grupo: some só em PNG, vídeo e sequência PNG; a viewport não muda); grupos; ocultar/mostrar em bloco; duplicar prop e personagem (copia arquivos com id novo, entra no mesmo grupo, estado independente); excluir com confirmação; persistência e `prune` ao abrir.
**NÃO feito / limitações:** (1) `SceneGraph` não integrado (sem hierarquia pai/filho real, sem reparentear por arrasto); (2) **sem Undo/Redo** nas operações do Outliner; (3) sem múltipla seleção (agrupa um item por vez; "Para: grupo" move um a um); (4) luz, câmera e áudio seguem como linhas fixas (câmeras/luzes múltiplas = Releases 10/12); (5) seleção Outliner↔viewport: o Outliner seleciona e abre o painel, mas tocar no objeto na viewport não seleciona a linha (não existe picking de objeto); (6) bloqueio não cobre o modelo principal; (7) "visível no render" não vale para exportações GLB/FBX/VMD (elas só exportam o principal); (8) ocultar na viewport (olho) não é salvo no projeto (já era assim).
**Para testar no aparelho:** (a) abrir projeto com modelo + 1 acessório + 1 extra; (b) selecionar o acessório, ✎ renomear, fechar e reabrir: nome mantido; (c) ↑/↓ muda a ordem e persiste; (d) 🔒 num extra: sliders do Elenco não mexem e aparece aviso; excluir é recusado; (e) ícone de filme no extra, exportar PNG: ele some só na imagem; (f) pasta com "+": "Novo grupo", depois outro item "Para: Grupo 1"; seta recolhe; olho do grupo oculta todos; ✕ de pasta desagrupa sem apagar; (g) ⧉ duplicar um extra: aparece outro, movê-lo não mexe no original; reabrir: ambos voltam; (h) 🗑 excluir pede confirmação, some e não deixa grupo vazio.
**Riscos de build:** escrito às cegas — olhar primeiro `Outliner.kt` (`@Composable fun act` local, imports `filled.*`/`material3.*`), bloco `layersOpen` e `duplicateLayer` em `SceneScreen.kt`.
**Próxima:** build + roteiro acima; depois 8.4b (Scene Graph como fonte: hierarquia pai/filho, Undo/Redo do Outliner, seleção por toque na viewport) e 8.3d (edição independente de personagens).

## Fatia 8.4b-1 — Undo/Redo do Outliner (v1.29.1) — ESCRITA, NÃO COMPILADA, NÃO TESTADA; teste JVM do `History` escrito, NÃO executado
**Feito:** `History<T>` (scene/OutlinerState.kt, puro, limite 50); `SceneScreen` guarda instantâneo (`OutlinerState` + nomes de props e extras) antes de renomear, mover, bloquear, visível no render, criar/alterar/desfazer grupo; botões ↶ ↷ no cabeçalho de Layers; restaurar aplica, faz `prune` (sem referência a objeto excluído) e grava `outliner.json`/`scene.json`/`cast.json`. **Fora do histórico (de propósito):** excluir e duplicar (apagam/criam arquivos), recolher grupo (só visual). **Ainda pendente da 8.4b:** Scene Graph como fonte da hierarquia, seleção por toque na viewport, múltipla seleção. **Teste:** renomear um extra → ↶ volta o nome (também no painel Elenco); bloquear → ↶ destrava; criar grupo → ↶ desfaz; ↷ refaz; após excluir um item, ↶ não ressuscita o item.

## Fatia 8.3d-parcial — Cartoon em personagens extras (v1.29.2) — ESCRITA; lógica pura EXECUTADA em JVM (21/21); UI NÃO compilada, NÃO testada no aparelho
**Origem:** a IA anterior bateu no limite de uso enquanto adicionava "alvo por personagem" ao Cartoon (print do aparelho mostra o resumo parado em "Aplicar Cartoon em personagem extra com desfazer"); nada disso estava no zip v1.29.1. Refeito do zero. Fecha a limitação "prévia/aplicar só no principal" da v1.28.0.
**Feito:** painel Cartoon ganhou "Aplicar em: Principal / <cada extra>" (aparece com ≥1 extra); compatibilidade (% de ossos) usa o modelo do alvo; **Prévia** no extra troca só o movimento dele na viewport e devolve o salvo ao parar; **Aplicar** no extra mescla o movimento Cartoon no `cast/<id>.vmd` (substitui só as keys entre o quadro inicial e o final nas trilhas escritas; resto intacto; preserva IK/luz/sombra do VMD), grava, atualiza o renderer, estende a duração e mostra o nome em Layers; **"↶ Desfazer no extra"** (até 20 passos, por personagem) restaura os bytes anteriores (ou remove o .vmd se o extra estava parado). Extra bloqueado no Outliner recusa aplicar/desfazer. Se o .vmd atual do extra não abrir, nada é alterado.
**Novos:** `cartoon/CartoonMerge.kt` (puro: `merge`, `toVmdBytes`), `test/.../CartoonMergeTest.kt` (7 testes). **Alterados:** `ui/CartoonPanel.kt`, `ui/SceneScreen.kt` (`castMorphs`, `cartoonTarget`, `applyCartoonToExtra`, `undoCartoonExtra`, `restoreExtraMotion`, efeito da prévia), `build.gradle.kts` (1.29.2 / 58), README, CHANGELOG.
**Testes executados (JVM, kotlinc 2.0.21 do Gradle):** CartoonMergeTest 7/7 + CartoonTest 14/14 (os 14 nunca tinham rodado). Compilados só VmdMotion, CartoonCore, CartoonBuiltin, CartoonMerge (+stub de BKey/MKey/Euler); Compose/GL continuam sem build.
**Limitações:** o desfazer de extra é separado do Desfazer do rodapé; não persiste ao fechar o projeto; a prévia de extra roda do quadro 0 (não do quadro atual); extras seguem sem esqueleto/Editor (8.3d completa); GLB animado como extra: aplicar sobrescreve só o trecho, o resto do clip fica.
**Para testar no aparelho:** (a) projeto com modelo + 1 extra; Cartoon → chip "Aplicar em" mostra Principal e o extra; (b) escolher o extra, ▶ Prévia: só ele se move; parar: volta ao que tinha; (c) Aplicar: extra se move na timeline, Layers mostra "Cartoon: <nome>"; (d) "Desfazer no extra" volta ao parado/anterior; (e) aplicar, fechar e reabrir o projeto: movimento mantido; (f) bloquear o extra no Outliner: Aplicar é recusado; (g) alvo "Principal": comportamento idêntico à v1.29.1.
**Riscos de build:** `SceneScreen.kt` (classe local `CastUndo`, `return@launch` dentro de `try`, bloco `if (cartoonPanel)` e lambda `onTarget`) e a nova assinatura de `CartoonPanel`.
**Próxima:** build + roteiros; depois restante da 8.4b (Scene Graph como fonte, seleção por toque, múltipla seleção) e 8.3d completa (personagem ativo com Editor/esqueleto/Dope Sheet por personagem).

## Fatia 8.4b-2 — Seleção múltipla no Outliner (v1.29.3) — ESCRITA, NÃO COMPILADA, NÃO TESTADA; 1 teste JVM escrito (`makeGroupWithManyKeys`), NÃO executado (OutlinerState usa org.json, sem stub aqui)
**Feito:** "☐ Vários" no cabeçalho de Layers liga o modo; tocar em modelo/objeto/personagem marca/desmarca (grupos e luz/câmera/áudio ignorados); "Agrupar" cria um grupo com todos os marcados (1 passo de desfazer, usa `makeGroup` que já aceitava lista). `OutlinerActions.onGroupMany`. Alterados: `ui/Outliner.kt`, `ui/SceneScreen.kt`, `OutlinerStateTest.kt`, build 1.29.3/59, README, CHANGELOG.
**Teste no aparelho:** projeto com modelo + 2 acessórios + 1 extra; ☐ Vários → marcar 3 → Agrupar: aparece "Grupo N" com os 3; ↶ desfaz; fechar/reabrir mantém.
**Ainda pendente da 8.4b:** Scene Graph como fonte da hierarquia; seleção por toque na viewport. Depois: 8.3d completa.

**Registro v1.29.4:** build do Actions falhou só no `app/build.gradle.kts` (linhas 10 e 12, `Unresolved reference: util / load`, herdado da v1.28.2). Corrigido com `import java.util.Properties`. Primeiro build real desde a v1.24.1: os erros de Kotlin do app (v1.25–v1.29.3) só aparecem depois que o script passar.

## v1.29.5 — Ajustes da Cartoon (vídeos do aparelho) + A2 (lista de clips do GLB ao reabrir) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Visto nos 4 vídeos (22:34–22:36):** Cartoon abre e roda; prévias de Idle/Body/Slapstick/Hand Gestures funcionam. Incômodos identificados: (1) o editor ficava no fim da lista, fora da vista (só aparecia "Velocidade"); (2) nomes e linha "Body Movement · 60 fr (2…" cortados; (3) dois itens pareciam ativos ao mesmo tempo (destaque = selecionado OU em prévia); (4) sem controle visível para parar a prévia ao rolar; (5) painel baixo (3 itens visíveis).
**Corrigido:** editor ACIMA da lista (+ "Fechar editor"); barra "Prévia: nome ■ Parar"; nomes 2 linhas, detalhes curtos (categoria só quando "Todas"); destaque só do selecionado; painel 380 dp. Arquivos: `ui/CartoonPanel.kt`, `ui/SceneScreen.kt`.
**NÃO resolvido (sem causa confirmada):** em "Balanço de espera" (vídeo 1) o corpo e as asas balançam com amplitude muito maior que a do movimento (±5°). O clip em si é pequeno (CartoonBuiltin); suspeitas: Ação secundária/física ligada no projeto (asas), ou ossos do modelo sem orientação de repouso padrão. Teste: desligar Ação secundária e Física e repetir a prévia; se continuar, enviar o nome dos ossos das asas.
**A2:** ao reabrir o projeto, `glbClips/glbRig` voltam do próprio `model.glb`; a animação salva (animacao.vmd) continua valendo e nada é reaplicado sozinho.

## v1.29.6 — Cartoon: braços estranhos e pés parados (relato do usuário) — lógica EXECUTADA em JVM (30/30); UI NÃO compilada, NÃO testada no aparelho
**Causa dos braços:** os sinais da v1.28.0 eram suposições. Medido com o Animator real (modelo de teste em T): braço esquerdo SOBE com Z+ (código usava Z−); perna vai à frente com X+ (código X−); tronco/cabeça/下半身 inclinam à frente com X− (código X+); joelho dobra com X− (código X+). Corrigido: `ARM_UP=+1`, `LEG=+1` e `PB.rot` inverte o X de 上半身/上半身2/首/頭/下半身/ひざ (os números dos movimentos seguem "X+ = frente").
**Causa dos pés:** no PMX as pernas são dirigidas por IK (`左足ＩＫ`), que refaz a perna a cada quadro e anula as keys FK. Teste `legIkOnCancelsTheFkSwing` reproduz. Correção: `ikBonesDriving(model, ossos)` acha os IKs cujos links são ossos animados; `IkRange.off` os desliga entre o quadro inicial e o final e restaura no quadro seguinte (guardando o estado anterior). Usado em: prévia (`Built.toMotion(ikOff)`), Aplicar no principal (`Editor.applyKeys`; IK agora entra no Desfazer via `Snap.x`), Aplicar em extras (`CartoonMerge.merge(..., ikOff)`, `castModels`).
**Limites:** pés ficam livres (sem apoio no chão) no trecho; depois do trecho o IK volta e a perna retorna à pose do IK; modelos com rest-pose/eixos locais fora do padrão ainda podem diferir; sinais medidos num esqueleto de teste (T-pose, padrão MMD), não no seu modelo.
**Testes (JVM):** `CartoonAxisTest` (braço sobe, braço à frente, tronco à frente, perna à frente, joelho dobra, IK anula FK, ikBonesDriving, IkRange x2) + CartoonMergeTest 7 + CartoonTest 14 = 30 OK. Compilados com stubs de org.json/android.util.Log/BKey.
**Teste no aparelho:** Cartoon → Caminhada/Corrida: braços balançam naturalmente e as pernas se movem; Aplicar e ↶ Desfazer (IK volta); no extra também.

## Fatia 8.4b-3 — Seleção por toque na viewport (v1.29.7) — ESCRITA, NÃO COMPILADA, NÃO TESTADA
**Feito:** `SceneGLView.pickLayer` (thread GL) projeta com a MVP do último quadro os ossos de cada personagem visível (extras com a matriz de mundo) e a origem dos acessórios livres; devolve "model", "char:<id>" ou "prop:<id>" do mais próximo (raio 80 px). `SceneScreen`: no toque (fora do Esqueleto) seleciona a camada no Layers, abre o painel certo e mostra aviso "Selecionado: nome". `openPanel` foi movida para antes do `SideEffect` (função local precisa vir antes do uso).
**Limites:** acessório preso a osso não é selecionável por toque (use o Layers); acessório muito grande com origem longe do toque pode não ser pego; toque em área vazia não faz nada (não desseleciona).
**Teste no aparelho:** projeto com modelo + 1 extra + 1 acessório; tocar em cada um: Layers destaca e abre Animação/Elenco/Cena; ocultar o extra e tocar: não é selecionado; modo Esqueleto continua escolhendo ossos.
**Ainda pendente da 8.4b:** Scene Graph como fonte da hierarquia. Depois: 8.3d completa.

## Fatia 8.4b-4 — Hierarquia do Outliner vinda do Scene Graph (v1.29.8) — lógica EXECUTADA em JVM (7/7); UI NÃO compilada, NÃO testada no aparelho
**Feito:** `scene/SceneHierarchy.kt` (puro). `build(modelo, hasModel, props, cast, outliner)` monta um `SceneGraph` com ids = chaves de camada (`model`, `prop:`, `char:`, `grp:`); acessório preso a osso → filho do modelo com `attachBone`; membro de grupo → filho do nó GROUP; osso vence grupo; sem modelo, acessórios ficam soltos; pai inexistente vira raiz (nunca entra referência inválida). `attachedKeys` alimenta o recuo no Layers (`SceneScreen`: indent + 1 para presos). `problems()` valida pai inexistente, ciclo e osso sem pai personagem. `removeKeepingChildren()` remove um nó e solta os filhos (sem osso) em vez de apagá-los. Teste: `SceneHierarchyTest` (7).
**Honesto sobre o alcance:** o grafo é derivado do estado atual a cada desenho (não é gravado em disco nem substitui `cast.json`/`scene.json`/Outliner); o que muda na tela é o recuo dos acessórios presos. Persistir o grafo como fonte única e reparentear arrastando ficam para a 8.3d/Release 9, junto com personagem ativo e Editor por personagem. `removeKeepingChildren` e `problems` ainda não têm chamador na UI.
**Teste no aparelho:** projeto com modelo + acessório preso a osso (ex.: mão) + acessório solto: o preso aparece recuado sob o modelo; agrupar um solto continua funcionando; ↶ do Layers inalterado.
**Com isto a 8.4b está completa nos itens do roadmap** (multi-seleção v1.29.3, seleção por toque v1.29.7, hierarquia pelo grafo v1.29.8). Próxima: build + roteiros; depois 8.3d.

## Fatia 8.3d-A — Poses entre personagens (v1.29.9) — lógica EXECUTADA em JVM (6/6); UI NÃO compilada, NÃO testada no aparelho
**Escolha do usuário (20/11):** das 3 frentes da 8.3d, fazer só A (poses + duplicar). B (personagem ativo editável com Esqueleto/Dope Sheet por personagem — exige Editor por extra e roteamento de overlay/seleção/arrasto de ossos no renderer) e C (exportar todos os personagens) seguem pendentes.
**Feito:** `scene/PoseTransfer.kt` (puro): `capture(movimento, quadro, nome)` lê a pose de um `VmdMotion` (interpolação linear, curvas ignoradas); `apply(old, pose, quadro, ossosValidos, morphsValidos)` grava a pose como key (usa `CartoonMerge.merge`, só esse quadro muda); `compat(pose, ossos)`. UI: `CastPanel` ganhou "Fotografar pose deste personagem", lista da `PoseLib` com "Aplicar aqui" e "↶ Desfazer"; `SceneScreen`: `castSavePose`, `castApplyPose`, `undoExtra(id)` (generalização do desfazer da Cartoon: mesma pilha `castUndo`, rótulo mostra "Cartoon …" ou "pose …"). A PoseLib é do projeto: principal → extra e extra → principal funcionam pela mesma biblioteca (aplicar no principal continua pela aba Animação).
**Duplicar personagem:** já existia (`ProjectStore.duplicateCast`, id novo, copia modelo e .vmd) — não alterado.
**Limites:** pose capturada de extra ignora curvas Bézier (usa linear); pose aplicada em extra é 1 key (as keys vizinhas dele continuam); a pilha de desfazer dos extras não persiste ao fechar o projeto; compatibilidade só por nome de osso.
**Teste no aparelho:** projeto com principal + 1 extra com movimento: (a) Elenco → selecionar extra → Fotografar pose → aparece na lista; (b) Animação do principal → Aplicar essa pose; (c) salvar pose do principal na Animação, voltar ao Elenco → "Aplicar aqui" no extra: ele muda só naquele quadro, o principal não; (d) ↶ Desfazer volta; (e) extra bloqueado no Outliner recusa; (f) pose de rig muito diferente: aviso de compat. %.
**Próxima:** build + roteiros (inclui itens v1.29.3–v1.29.9); depois 8.3d-B e/ou C.

## Fatia 8.3d-C — Exportar todos os personagens (v1.29.10) — lógica EXECUTADA em JVM (3/3); UI NÃO compilada
`scene/CastExport.kt`: `zip(itens)` gera um .vmd por personagem, nomes seguros e únicos (`Nome`, `Nome_2`…). `SceneScreen`: launcher `castZipSaver` + item "Salvar todos os personagens (.zip de .vmd)" no menu Salvar (principal com keys + cada extra com `cast/<id>.vmd`). Limites: só VMD (sem GLB/FBX do elenco); modelos não vão no zip. **Teste:** projeto com extra → Salvar → item novo → abrir o zip e conferir os .vmd. **Resta:** 8.3d-B (personagem ativo editável).

## Fatia 8.3d-B — Personagem ativo editável — DIVIDIDA em B1/B2/B3 (para caber no limite de uso)
- **B1 (v1.29.11) FEITA — lógica EXECUTADA em JVM (5/5):** `scene/ActiveCharacter.kt`: `resolve` (volta ao principal se o extra sumiu), `label`, `canEdit` (respeita bloqueio do Outliner); `EditSessions<T>`: uma sessão (Editor) por extra, criada sob demanda, `markDirty`/`flush` (só grava o sujo; falha de gravação mantém sujo)/`drop`. Genérica em T porque `Editor` usa Compose e não compila em JVM puro. Sem mudança de UI.
- **B2 (pendente) — UI:** `SceneScreen`: estado `activeId`; botão "Editar este personagem" no CastPanel + selo/indicador do ativo na barra; `EditSessions<Editor>` com `create` = `Editor(castModels[id]).load(motion do cast/<id>.vmd)`; abas Animação/Keys/Dope Sheet apontam para `editorOf(activeId)`; salvar/fechar → `flush` grava `Editor.toVmd()` em `cast/<id>.vmd` + `persistCast`; Cartoon/pose/"Trocar movimento" num extra chamam `sessions.drop(id)`; recusar se bloqueado.
- **B3 (pendente) — renderer:** `SceneGLView`: movimento do extra ativo = `editor.motion()` ao vivo; overlay do esqueleto, seleção e arrasto de ossos no personagem ativo (hoje só `mainChar`); IK/morphs do ativo.
- **Teste B1:** `gradle testDebugUnitTest` → `ActiveCharacterTest` (5).

### 8.3d-B2 (v1.29.12) — ESCRITA, UI NÃO compilada, NÃO testada no aparelho
`SceneScreen`: `activeId`/`actId` (resolve p/ principal se o extra sumiu), `sessions = EditSessions<Editor>` (Editor do extra criado sob demanda de `castModels` + `cast/<id>.vmd`), `ae` = editor ativo. `ae` alimenta SkeletonPanel (Pose/Morph/Keys/Dope), Desfazer/Refazer, botão de Key, Timeline. Edição de extra: empurra `editor.motion()` ao renderer (`setCharacterMotion`) e marca sujo; `flushExtras()` grava `cast/<id>.vmd` no autosave/fechar (sem keys apaga o arquivo; rótulo "editado"). Cartoon/pose/importar/limpar/desfazer num extra gravam o arquivo e chamam `dropSession` (a sessão recarrega do arquivo; Cartoon e pose chamam `flushExtras` antes). Bloqueio do Outliner recusa editar e inserir key. `CastPanel`: botão "Editar este personagem", linha "Editando: …", "Voltar a editar o principal".
**Limites:** sem esqueleto desenhado/seleção/arrasto de osso no extra (B3); abas Rig/IK/Física/Mocap/IA ainda agem no PRINCIPAL; o desfazer do Editor do extra some ao fechar o projeto; "desfazer" do Cartoon/pose descarta edições manuais não salvas daquele extra.
**Teste:** Elenco → extra com movimento → "Editar este personagem" (abre Esqueleto) → escolher osso na lista, mexer slider/inserir key → o extra muda, o principal não → fechar e reabrir: edição mantida; Desfazer/Refazer; extra bloqueado recusa.
**Próxima:** B3 (renderer: esqueleto/arrasto no extra ativo).

### 8.3d-B3 (v1.29.13) — ESCRITA, UI/renderer NÃO compilados, NÃO testados no aparelho — FECHA a 8.3d-B
`SceneGLView`: `activeChar` + `setActiveCharacter(id)`; `editChar()` (volta ao principal se o extra sumiu); `charMvp(c)` = MVP × matriz de mundo do personagem. `drawBones`, `pick` e `dragBone` agem no personagem ativo (antes só `mainChar`). Extra: esqueleto desenhado na posição/giro/escala dele; seleção projeta com a MVP do extra; arrasto converte direita/cima da câmera para o espaço local desfazendo o giro Y (inversa conferida numericamente) e divide o deslocamento do Mover pela escala. Extra oculto no Outliner não mostra esqueleto nem é selecionável. `SceneScreen`: `LaunchedEffect(actId)` chama `setActiveCharacter` e entrega `ae.motion()` ao extra (esqueleto aparece mesmo sem keys); toque/arrasto/fim de arrasto usam `ae`; extra bloqueado recusa arrastar ("Personagem bloqueado no Outliner").
**Limites:** abas Rig/IK/Física/Mocap/IA ainda agem no PRINCIPAL; IK/restrições do extra usam `RigConfig()` vazia; só giro em Y no extra (limite da 8.3c); sombra de contato/mapa de sombra seguem o principal; Elenco continua fora de GLB/FBX/VPD.
**Teste no aparelho:** Elenco → extra com movimento (ou sem) → "Editar este personagem" → o esqueleto aparece SOBRE o extra (não na origem); tocar num osso do extra seleciona; Girar/Mover arrasta só o extra (principal intacto); mudar X/Giro/Esc do extra no Elenco e repetir (esqueleto acompanha); bloquear o extra no Outliner → arrastar recusa; ocultar → sem esqueleto; "Voltar a editar o principal" → esqueleto volta ao principal; Desfazer/Refazer; fechar/reabrir mantém a edição.
**Próxima:** build + roteiros acumulados (v1.29.3–v1.29.13); depois abas Rig/IK do extra ou Release 9 (item A2/9.5).


---

## Nota v1.30.0 — P0 URGENTE: Navegação Livre da Viewport

**Status:** escrita; NÃO compilada; NÃO testada no aparelho. Fonte: `MMD_Studio_Sugestao_Urgente_Navegacao_Livre_Viewport.md`.

| Item | P | Estado |
|---|---|---|
| Orbit livre (1 dedo) + separação navegar/editar osso | P0 | escrito |
| Pinça (zoom limitado) | P0 | escrito |
| Pan 2 dedos em espaço de câmera | P0 | escrito (corrigido) |
| Ponto de foco: personagem ativo / item selecionado / todos | P0/P1 | escrito |
| Gizmo de orientação com vistas ortogonais | P1 | escrito |
| Sensibilidade configurável, inércia, persistência da vista, foco por toque | P2 | NÃO feito |

**Critérios de aceitação 1–12:** nenhum pode ser marcado como cumprido antes de compilar e validar no aparelho com modelo de frente/costas/lateral/deitado, extras com rotações diferentes, pivô distante e osso selecionado (checar: orbitar longe do osso, arrastar o osso perto dele, pinça durante arrasto, gizmo, presets, nada vira keyframe/Undo).


## Nota v1.30.1 — P0 URGENTE: Rotação/transformação da personagem inteira

**Objetivo:** girar a personagem/modelo para a direção desejada sem orbitar a câmera e sem modificar a pose dos ossos. É uma transformação do objeto raiz, separada da navegação livre da viewport (v1.30.0) e da câmera cinematográfica/VMD.

**Implementado no código-fonte:**
- `scene/RootTransform.kt`: estado base e trilha de keyframes por personagem, amostragem/interpolação, codec JSON versionado e persistência em `root_transforms.json`.
- `ui/TransformPanel.kt`: painel Transformar; alvo principal ou extra; controle circular (horizontal = Y, vertical = X), campos X°/Y°/Z°, posição, escala, comando Zerar rotação e keyframe no quadro atual.
- `render/SceneGLView.kt`: matriz `T * Rz * Ry * Rx * S` aplicada ao principal e aos extras no desenho, seleção/picking, MVP dos ossos e props presos ao personagem principal; API `setRootTransform`.
- `ui/SceneScreen.kt`: sincronização com timeline, persistência por projeto e aplicação da transformação nas capturas/exportações.
- `RootTransformTest`: round-trip do codec, interpolação contínua (inclui rotações >360°) e edição de trilha.

**Critérios de aceite antes de declarar validado:**
1. Selecionar a personagem principal e girá-la nos três eixos; repetir com cada extra.
2. Confirmar que câmera orbital e câmera VMD não mudam quando a rotação do objeto é editada.
3. Confirmar que pose, FK/IK, morphs e keys dos ossos permanecem intactos.
4. Criar keyframes em quadros distintos, reproduzir timeline e confirmar interpolação/giros completos.
5. Salvar, fechar e reabrir o projeto; confirmar persistência do principal e extras.
6. Exportar PNG/sequência/MP4 em quadros diferentes e confirmar que a orientação da personagem acompanha o quadro.
7. Confirmar que props presos aos ossos continuam acompanhando a personagem transformada.
8. Validar em Android real: arrasto no controle circular, campos numéricos e layout em tela pequena.

**Limites conhecidos nesta implementação:** controle circular ajusta X/Y; Z é numérico. Ainda não há rotação relativa à câmera, gizmo de anel diretamente no viewport ou Undo/Redo específico para transformação. O código não foi compilado nem testado no aparelho nesta entrega; a versão Android só deve ser marcada como validada depois do GitHub Actions e dos roteiros acima.

**Prioridade atual:** P0, implementar/build/testar esta transformação antes de avançar novas frentes de animação/câmera. A navegação de viewport da v1.30.0 continua sendo um sistema independente e não substitui esta função.


**Adendo de compatibilidade — v1.30.1:** duplicar um personagem extra deve copiar também `RootTransformEntry` (base + keys) para o novo ID; remover o extra deve remover sua entrada. A transformação raiz é persistente no projeto e aplicada nas capturas MP4/PNG/sequência; ela ainda não é baked para arquivos VMD/GLB/FBX. O teste `RootTransformTest` inclui duplicação independente de tracks e ângulos contínuos.


## Nota v1.30.2 — P0 URGENTE: todo objeto de Cena precisa ser transformável

**Problema observado no aparelho:** um palco importado aparece em `Cena → Cenário e acessórios` e pode ser selecionado/ajustado ali, mas não aparece em `Transformar → Alvo`, que atualmente lista apenas personagem principal e extras do Elenco. Além disso, RX/RY/RZ de um objeto solto são armazenados, mas o caminho de renderização solto não aplicava esses ângulos.

**Escopo implementado no código-fonte v1.30.2:**
- A lista Alvo do painel Transformar deve refletir dinamicamente todos os objetos ativos da aba Cena (`prop:<id>`), além do personagem principal e dos personagens extras (`char:<id>`).
- Cada item de Cena deve poder ser selecionado pelo seletor Alvo, pela lista da própria aba Cena e pela seleção existente na viewport/Outliner; a seleção identifica o objeto exato, não a cena inteira.
- Posição X/Y/Z, rotação X/Y/Z e escala devem atuar no objeto selecionado sem alterar a câmera da viewport, personagens vizinhos ou outros objetos.
- Keyframes e interpolação do painel Transformar precisam funcionar por objeto, com tracks independentes em `root_transforms.json`.
- Os valores devem ser aplicados durante a prévia e os caminhos de captura/exportação que aplicam transformações por quadro. Projetos antigos devem inicializar a track a partir dos valores de `props.json`.
- Duplicar um objeto copia sua transformação e seus keyframes para um ID novo; excluir remove a track correspondente.
- O renderer deve respeitar RX/RY/RZ também para objetos soltos, não apenas objetos presos a ossos.

**Critérios de aceitação no Android:**
1. Importar um palco em Cena e encontrá-lo no seletor Transformar com identificação `Cena · <nome>`.
2. Escolher o palco e mudar separadamente X, Y e Z de rotação; a malha do palco gira de verdade, sem orbitar a viewport.
3. Mover e redimensionar o palco sem afetar personagens, outros props nem a câmera.
4. Criar dois keyframes no palco, reproduzir a timeline e confirmar interpolação; repetir com outro objeto para confirmar independência.
5. Salvar, fechar e reabrir: posição, rotação, escala e keyframes continuam corretos.
6. Duplicar e excluir objetos: a cópia recebe track independente e excluir remove apenas a track daquele ID.
7. Repetir com objeto preso a osso e com objeto solto no mundo.

**Limite importante:** esta nota trata da seleção e transformação individual de qualquer objeto adicionado em Cena. Não significa aplicar uma transformação global a todos os elementos da cena simultaneamente. Luz e câmera continuam nos painéis próprios enquanto não forem modeladas como itens transformáveis da lista Cena.

**Estado v1.30.2:** código-fonte atualizado; não considerar validado até o workflow Android compilar, o APK abrir no POCO X7 Pro e os critérios acima serem testados no aparelho.

## 13.11 P0 — Física de roupas e colisão corpo–tecido (planejada; ainda NÃO implementada)
**Origem:** vídeo `1000243628.mp4` enviado em 20/11/2026. A saia não reage adequadamente quando as pernas sobem/cruzam e ocorre interpenetração visual.

Auditoria do código v1.30.2: `Physics.kt` colide corpos rígidos PMX entre si; `Secondary` aplica molas às rotações dos ossos; `AutoPhysics` reconhece grupos, mas não gera simulação de malha; `PmxModel.softBodyRaw` preserva os bytes do PMX 2.1 sem interpretação; `PhysCache` armazena poses dos ossos, não vértices de tecido. Logo, sliders de gravidade/rigidez não resolvem o defeito por si só.

**Direção:** manter a física MMD existente; adicionar colisores cinemáticos do corpo (pelve, coxas, joelhos, panturrilhas) e um solver PBD/XPBD de roupa baseado em vértices/restrições/âncoras. A roupa deve ser corrigida para fora dos colisores; o esqueleto/keyframes da perna não podem ser movidos para resolver colisão. PMX 2.1 Soft Body deve ser interpretado em etapa própria, preservando round-trip dos dados ainda desconhecidos. Para PMX sem Soft Body e GLB/OBJ, oferecer configuração manual assistida.

**Prioridade:** P0-A debug + colisores corporais → P0-B saia/roupa com colisão e subpassos anti-tunneling → P0-C cache determinístico de estado da roupa, persistência e integração prévia/exportação. P1 interpretação PMX 2.1 e auto-detecção refinada. P2 auto-colisão, dobras e otimização avançada.

**Critério de aceite:** animação com caminhada, chute frontal/lateral, pernas cruzadas e agachamento; a roupa não deve atravessar visivelmente a perna; a perna e seus keyframes devem permanecer iguais; scrub/play/export devem concordar; desligar a simulação deve restaurar skinning base. Medir FPS/memória/temperatura no POCO X7 Pro.

**Documento técnico completo:** `docs/P0_Fisica_Roupas_Colisoes.md`. Estado atual: especificação somente; nenhuma física de tecido foi adicionada nesta revisão. Não elevar status para implementado/validado antes de código, build e teste no aparelho.


## Nota v1.31.0 — P0: Outliner de cena e perfis de rig/física independentes por personagem

**Origem:** referência do Outliner do Blender enviada pelo usuário em 20/11/2026. O objetivo é permitir escolher explicitamente o personagem/modelo em edição, especialmente os extras do Elenco, e configurar física sem afetar outros personagens.

**Implementado no código-fonte (ainda não validado por build/aparelho):**
- Outliner aberto por padrão no viewport; exibe modelo principal, props de Cena, personagens do Elenco, luz, câmera e áudio. Pode ser ocultado/reaberto pelo botão Layers.
- Selecionar principal ou extra define o personagem ativo e abre Esqueleto → Rig. O painel indica o nome do personagem proprietário do perfil.
- Cada extra possui `RigConfig` independente: restrições, movimento secundário e física real PMX. Persistência em `cast/<id>.rig.json`; principal mantém arquivos/compatibilidade legada.
- Duplicação copia perfil para ID novo; exclusão remove somente o perfil daquele extra.
- `SceneGLView.CharacterInstance`/`Animator` usam o perfil correspondente; atualizações reiniciam apenas a dinâmica daquela instância.
- `Baker.compute` e `PhysBake.run` recebem o perfil ativo, evitando usar `RigState.main` ao assar personagem extra.
- Teste `CharacterRigProfileTest` adicionado (3 casos: serialização, independência e fallback seguro), ainda não executado.

**Critérios de aceitação no Android:**
1. Abrir projeto e confirmar Outliner visível no canto direito; ocultar/reabrir pelo botão Layers.
2. Importar dois ou mais extras; selecionar um, confirmar o nome no cabeçalho Rig e mudar os controles de Física real.
3. Selecionar o segundo extra e usar valores bem diferentes; voltar ao primeiro e confirmar que valores e simulação não mudaram.
4. Selecionar o modelo principal e confirmar que suas configurações legadas não foram substituídas pelos extras.
5. Salvar/fechar/reabrir e conferir perfis em `cast/<id>.rig.json`.
6. Duplicar um extra: o duplicado começa com a configuração copiada, mas mudanças futuras ficam independentes. Excluir: remove só o perfil daquele ID.
7. Calcular cache/bake de movimento secundário em cada extra e verificar que o resultado corresponde à instância correta.
8. Testar toque no Outliner, toque direto no personagem e “Editar este personagem” no painel Elenco: os três caminhos devem selecionar o mesmo ativo.
9. Validar layout em paisagem/retrato e desempenho no POCO X7 Pro.

**Limites:** Outliner atual é uma lista hierárquica mobile baseada nas entidades existentes e nos grupos atuais; não equivale a todos os sistemas de Collection/parenting do Blender. Física independente cobre o sistema atual de corpos rígidos/juntas PMX e movimento secundário. Não implementa colisão de malha corpo–saia ou solver de tecido; a nota P0 13.11 permanece pendente. Cache da física continua transitório em memória, mas parâmetros e grupos são persistidos.

**Estado:** código-fonte alterado; testes escritos; build Android, testes JVM e teste no aparelho NÃO executados neste ambiente. Não marcar como validado antes do GitHub Actions e dos critérios acima.
