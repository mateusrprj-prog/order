# MMD Studio (Android)
App nativo Kotlin + Jetpack Compose + OpenGL ES 2.0. Sem WebView/PWA.

## Status
Etapa 1: UI da tela "Scene 3D" (baseada na referência) + viewport OpenGL com grade, eixos X/Z,
câmera orbital (1 dedo orbita/pan conforme ferramenta, 2 dedos pan, pinça zoom), vistas Frente/Trás/Esquerda/Direita/Topo/Base,
play/pause, frame anterior/próximo e timeline com playhead arrastável.
Ainda NÃO implementado: PMX/PMD, VMD, bones, morphs, áudio, exportação.

## Compilar
- Android Studio: abrir a pasta e rodar `app`.
- GitHub: push -> Actions -> artefato `mmd-studio-debug` (APK).
