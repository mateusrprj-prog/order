package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import studio.mmd.render.SceneGLView
import studio.mmd.render.TouchMode
import studio.mmd.render.ViewPreset

val Bg = Color(0xFF0A0A0B); val Panel = Color(0xFF17181B); val Accent = Color(0xFF2F7BFF)
val Muted = Color(0xFF8A8D94)
const val FPS = 30; const val TOTAL_FRAMES = 300

@Composable
fun SceneScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val gl = remember { SceneGLView(ctx) }
    var mode by remember { mutableStateOf(TouchMode.ORBIT) }
    var menu by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }

    LaunchedEffect(playing) {
        while (playing) { delay(1000L / FPS); frame = (frame + 1) % TOTAL_FRAMES }
    }
    DisposableEffect(Unit) { gl.onResume(); onDispose { gl.onPause() } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ArrowBackIosNew, null, Modifier.clickable { onClose() }.padding(8.dp).size(18.dp), tint = Color.White)
                Icon(Icons.Default.ViewInAr, null, Modifier.padding(start = 4.dp).size(18.dp), tint = Color.White)
                Text("Scene 3D", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Icon(Icons.Default.Close, null, Modifier.clickable { onClose() }.padding(8.dp).size(20.dp), tint = Color.White)
            }
            Box(Modifier.padding(horizontal = 8.dp)) {
                Row(Modifier.clickable { menu = true }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Viewport de Edição", color = Color.White, fontSize = 12.sp)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Enquadrar tudo") }, onClick = { gl.frameAll(); menu = false })
                    listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esquerda" to ViewPreset.LEFT,
                        "Direita" to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                        DropdownMenuItem(text = { Text(n) }, onClick = { gl.applyPreset(p); menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(4.dp))) {
                AndroidView(factory = { gl }, modifier = Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.CenterStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Panel.copy(alpha = .85f))) {
                    ToolButton(Icons.Default.OpenWith, mode == TouchMode.ORBIT) { mode = TouchMode.ORBIT; gl.touchMode = mode }
                    ToolButton(Icons.Default.PanTool, mode == TouchMode.PAN) { mode = TouchMode.PAN; gl.touchMode = mode }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Animação", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("%d / %d".format(frame, TOTAL_FRAMES - 1), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.clickable { playing = !playing }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame - 1).coerceAtLeast(0) }.padding(8.dp).size(22.dp))
                Icon(Icons.Default.SkipNext, null, tint = Color.White,
                    modifier = Modifier.clickable { frame = (frame + 1).coerceAtMost(TOTAL_FRAMES - 1) }.padding(8.dp).size(22.dp))
            }
            Timeline(frame, Modifier.fillMaxWidth().height(110.dp).padding(horizontal = 8.dp, vertical = 6.dp)) { frame = it }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(3.dp).size(34.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Accent else Color.Transparent).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(18.dp))
    }
}

/** Régua de frames com playhead arrastável. */
@Composable
private fun Timeline(frame: Int, modifier: Modifier, onSeek: (Int) -> Unit) {
    Canvas(modifier.background(Color(0xFF101114)).pointerInput(Unit) {
        detectTapGestures { onSeek((it.x / size.width * (TOTAL_FRAMES - 1)).toInt().coerceIn(0, TOTAL_FRAMES - 1)) }
    }.pointerInput(Unit) {
        detectDragGestures { c, _ -> onSeek((c.position.x / size.width * (TOTAL_FRAMES - 1)).toInt().coerceIn(0, TOTAL_FRAMES - 1)) }
    }) {
        val step = size.width / (TOTAL_FRAMES / FPS)
        for (s in 0..(TOTAL_FRAMES / FPS)) drawLine(Color(0xFF3A3C42), Offset(s * step, 0f), Offset(s * step, 28f), 2f)
        val x = frame.toFloat() / (TOTAL_FRAMES - 1) * size.width
        drawLine(Accent, Offset(x, 0f), Offset(x, size.height), 3f)
    }
}
