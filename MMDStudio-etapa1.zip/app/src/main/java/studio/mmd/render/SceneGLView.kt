package studio.mmd.render

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

enum class TouchMode { ORBIT, PAN }
enum class ViewPreset(val yaw: Float, val pitch: Float) {
    FRONT(0f, 0f), BACK(180f, 0f), LEFT(-90f, 0f), RIGHT(90f, 0f), TOP(0f, 89f), BOTTOM(0f, -89f)
}

/** Estado da câmera orbital, compartilhado entre a thread de toque e a thread GL. */
class OrbitCamera {
    @Volatile var yaw = 30f
    @Volatile var pitch = 20f
    @Volatile var dist = 12f
    @Volatile var tx = 0f
    @Volatile var ty = 1f
    @Volatile var tz = 0f

    fun reset() { yaw = 30f; pitch = 20f; dist = 12f; tx = 0f; ty = 1f; tz = 0f }
    fun eye(): FloatArray {
        val y = Math.toRadians(yaw.toDouble()); val p = Math.toRadians(pitch.toDouble())
        return floatArrayOf(
            tx + dist * (cos(p) * sin(y)).toFloat(),
            ty + dist * sin(p).toFloat(),
            tz + dist * (cos(p) * cos(y)).toFloat()
        )
    }
}

class SceneGLView(context: Context) : GLSurfaceView(context) {
    val camera = OrbitCamera()
    @Volatile var touchMode = TouchMode.ORBIT
    private val renderer = GridRenderer(camera)
    private var lastX = 0f; private var lastY = 0f; private var lastCount = 0
    private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            camera.dist = (camera.dist / d.scaleFactor).coerceIn(1.5f, 80f); return true
        }
    })

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun applyPreset(p: ViewPreset) { camera.yaw = p.yaw; camera.pitch = p.pitch; requestRender() }
    fun frameAll() { camera.reset(); requestRender() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        val n = e.pointerCount
        val x = (0 until n).map { e.getX(it) }.average().toFloat()
        val y = (0 until n).map { e.getY(it) }.average().toFloat()
        if (e.actionMasked == MotionEvent.ACTION_MOVE && n == lastCount && !scale.isInProgress) {
            val dx = x - lastX; val dy = y - lastY
            if (n >= 2 || touchMode == TouchMode.PAN) {
                val k = camera.dist * 0.0015f
                val yr = Math.toRadians(camera.yaw.toDouble())
                camera.tx -= (cos(yr) * dx).toFloat() * k
                camera.tz += (sin(yr) * dx).toFloat() * k
                camera.ty += dy * k
            } else {
                camera.yaw -= dx * 0.4f
                camera.pitch = (camera.pitch + dy * 0.4f).coerceIn(-89f, 89f)
            }
        }
        lastX = x; lastY = y; lastCount = n
        if (e.actionMasked == MotionEvent.ACTION_UP) lastCount = 0
        requestRender()
        return true
    }
}

private class GridRenderer(private val cam: OrbitCamera) : GLSurfaceView.Renderer {
    private var program = 0; private var aPos = 0; private var uMvp = 0; private var uColor = 0
    private val proj = FloatArray(16); private val view = FloatArray(16); private val mvp = FloatArray(16)
    private lateinit var gridBuf: java.nio.FloatBuffer; private var gridCount = 0
    private lateinit var xAxis: java.nio.FloatBuffer; private lateinit var zAxis: java.nio.FloatBuffer

    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    private fun compile(type: Int, src: String) = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.02f, 0.025f, 1f)
        val vs = compile(GLES20.GL_VERTEX_SHADER, "uniform mat4 uMvp; attribute vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}")
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}")
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        val g = ArrayList<Float>()
        for (i in -10..10) { g += listOf(i.toFloat(), 0f, -10f, i.toFloat(), 0f, 10f, -10f, 0f, i.toFloat(), 10f, 0f, i.toFloat()) }
        gridCount = g.size / 3; gridBuf = fb(g.toFloatArray())
        xAxis = fb(floatArrayOf(-10f, 0f, 0f, 10f, 0f, 0f))
        zAxis = fb(floatArrayOf(0f, 0f, -10f, 0f, 0f, 10f))
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h, 0.1f, 200f)
    }

    private fun draw(buf: java.nio.FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val e = cam.eye()
        val top = cam.pitch > 85f || cam.pitch < -85f
        val upY = if (top) 0f else 1f
        val upZ = if (top) (if (cam.pitch > 0) -1f else 1f) else 0f
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], cam.tx, cam.ty, cam.tz, 0f, upY, upZ)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        draw(gridBuf, gridCount, 0.22f, 0.22f, 0.25f)
        draw(xAxis, 2, 0.9f, 0.2f, 0.2f)   // eixo X (vermelho)
        draw(zAxis, 2, 0.2f, 0.4f, 1f)     // eixo Z (azul)
    }
}
