package studio.mmd.rig

import org.json.JSONArray
import org.json.JSONObject

/** Tipos de restrição (Action Constraints). */
object CType {
    const val LIMIT_ROT = 0   // limita a rotação do osso (graus por eixo, ordem Y·X·Z do MMD)
    const val LIMIT_POS = 1   // limita a posição (unidades MMD por eixo)
    const val LOOK_AT = 2     // o eixo escolhido do osso aponta para outro osso
    const val COPY_ROT = 3    // copia a rotação local de outro osso
    const val COPY_POS = 4    // copia a posição local de outro osso
    val names = listOf("Limitar rotação", "Limitar posição", "Olhar para", "Copiar rotação", "Copiar posição")
}

/** Eixos do "Olhar para": 0 +X, 1 −X, 2 +Y, 3 −Y, 4 +Z, 5 −Z (no MMD a frente do modelo é −Z). */
val AXIS_NAMES = listOf("+X", "−X", "+Y", "−Y", "+Z", "−Z")

/** Uma restrição ligada a um osso (por nome). Imutável: troca-se o objeto com copy(). */
data class Constraint(
    val id: String,
    val bone: String,
    val type: Int,
    val enabled: Boolean = true,
    val target: String = "",
    val axis: Int = 5,
    val weight: Float = 1f,
    val min: List<Float> = listOf(-180f, -180f, -180f),
    val max: List<Float> = listOf(180f, 180f, 180f)
)

/** Lista de restrições em uso pelo projeto aberto. O Animator (prévia e exportações) lê daqui. */
object RigState {
    @Volatile var list: List<Constraint> = emptyList()
}

object RigIo {
    fun toJson(l: List<Constraint>): String {
        val a = JSONArray()
        l.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("bone", c.bone).put("type", c.type).put("on", c.enabled)
                .put("target", c.target).put("axis", c.axis).put("w", c.weight.toDouble())
                .put("min", JSONArray(c.min.map { it.toDouble() })).put("max", JSONArray(c.max.map { it.toDouble() })))
        }
        return a.toString()
    }

    fun fromJson(s: String): List<Constraint> = try {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val j = a.getJSONObject(i)
            fun f3(k: String, d: Float): List<Float> {
                val x = j.optJSONArray(k) ?: return listOf(d, d, d)
                return (0..2).map { x.optDouble(it, d.toDouble()).toFloat() }
            }
            Constraint(j.getString("id"), j.getString("bone"), j.getInt("type"), j.optBoolean("on", true),
                j.optString("target", ""), j.optInt("axis", 5), j.optDouble("w", 1.0).toFloat(), f3("min", -180f), f3("max", 180f))
        }
    } catch (e: Exception) { emptyList() }
}
