package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.scene.CastMeta

/**
 * v1.27.0 (8.3c) — painel "Elenco": personagens EXTRAS animados (cada um com modelo, movimento .vmd e transformação próprios).
 * O personagem principal continua sendo editado pelas abas Animação/Esqueleto; os extras tocam no mesmo relógio (a mesma timeline).
 */
@Composable
fun CastPanel(
    cast: List<CastMeta>, sel: Int, onSel: (Int) -> Unit,
    onAdd: () -> Unit, onRemove: (Int) -> Unit, onMotion: (Int) -> Unit, onClearMotion: (Int) -> Unit,
    onChange: (Int, CastMeta) -> Unit, onDone: () -> Unit,
    modifier: Modifier
) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Elenco (personagens extras)", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("+ Personagem", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Accent, RoundedCornerShape(6.dp)).clickable { onAdd() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (cast.isEmpty()) {
            Text("Importe .pmx, .pmd, .glb, .gltf ou .zip. Cada personagem tem movimento próprio (.vmd ou animação do GLB) e todos tocam juntos na mesma timeline.",
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
        cast.forEachIndexed { i, c ->
            Row(Modifier.fillMaxWidth().padding(top = 6.dp).background(if (i == sel) Color(0xFF4A2226) else Color(0xFF1E2024), RoundedCornerShape(6.dp))
                .clickable { onSel(if (i == sel) -1 else i) }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (c.motion.isEmpty()) "parado (pose de repouso)" else "movimento: " + c.motion, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("Remover", color = Color(0xFFFF6B6B), fontSize = 11.sp, modifier = Modifier.clickable { onRemove(i) }.padding(start = 10.dp))
            }
        }
        val c = cast.getOrNull(sel)
        if (c != null) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Importar movimento (.vmd)", color = Color.White, fontSize = 11.sp, maxLines = 1,
                    modifier = Modifier.background(Color(0xFF26282D), RoundedCornerShape(6.dp)).clickable { onMotion(sel) }.padding(horizontal = 10.dp, vertical = 6.dp))
                if (c.motion.isNotEmpty()) Text("Limpar movimento", color = Color(0xFFFF6B6B), fontSize = 11.sp, maxLines = 1,
                    modifier = Modifier.background(Color(0xFF26282D), RoundedCornerShape(6.dp)).clickable { onClearMotion(sel) }.padding(horizontal = 10.dp, vertical = 6.dp))
            }
            PropSlider("X", c.x, -30f, 30f, { onChange(sel, c.copy(x = it)) }, onDone)
            PropSlider("Y", c.y, -10f, 30f, { onChange(sel, c.copy(y = it)) }, onDone)
            PropSlider("Z", c.z, -30f, 30f, { onChange(sel, c.copy(z = it)) }, onDone)
            PropSlider("Giro", c.ry, -180f, 180f, { onChange(sel, c.copy(ry = it)) }, onDone)
            PropSlider("Esc", c.s, 0.1f, 5f, { onChange(sel, c.copy(s = it)) }, onDone)
        } else if (cast.isNotEmpty()) {
            Text("Toque num personagem para ajustar posição, giro, escala e movimento.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
