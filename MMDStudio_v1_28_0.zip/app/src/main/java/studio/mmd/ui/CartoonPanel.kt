package studio.mmd.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.cartoon.*
import kotlin.math.max
import kotlin.math.roundToInt

private val ChipBg = Color(0xFF26282D)

/**
 * v1.28.0 — "Cartoon": biblioteca de movimentos cartunescos + editor (velocidade, duração, intensidade, repetição, trecho, suavização,
 * combinação por grupos de ossos). Prévia sem alterar o projeto; "Aplicar" grava as keys no quadro atual como 1 passo de desfazer.
 */
@Composable
fun CartoonPanel(
    hasModel: Boolean, modelBones: Set<String>, modelMorphs: Set<String>, atFrame: Int, previewId: String?,
    onPreview: (String, Built, Boolean) -> Unit, onStopPreview: () -> Unit,
    onApply: (CartoonItem, Built) -> Unit, onImport: (CartoonCat) -> Unit,
    modifier: Modifier
) {
    val ctx = LocalContext.current
    var catSel by remember { mutableStateOf<CartoonCat?>(null) }
    var selId by remember { mutableStateOf<String?>(null) }
    var params by remember { mutableStateOf(CartoonParams()) }
    var mixId by remember { mutableStateOf<String?>(null) }
    var mixGroups by remember { mutableStateOf(setOf(BoneGroup.HEAD, BoneGroup.ARMS)) }
    var previewLoop by remember { mutableStateOf(true) }
    var msg by remember { mutableStateOf("") }

    val all = CartoonLibrary.items
    val list = all.filter { catSel == null || it.cat == catSel }
    val sel = all.firstOrNull { it.id == selId }
    val selClip = remember(selId, all.size) { sel?.let { CartoonLibrary.clipOf(ctx, it) } }
    val mix = all.firstOrNull { it.id == mixId }
    val mixClip = remember(mixId, all.size) { mix?.let { CartoonLibrary.clipOf(ctx, it) } }

    fun select(it: CartoonItem) { if (selId != it.id) { selId = it.id; params = CartoonParams(); msg = "" } }

    fun buildFor(it: CartoonItem, forApply: Boolean): Built? {
        val clip = CartoonLibrary.clipOf(ctx, it) ?: run { msg = "Não consegui abrir \"${it.name}\" (arquivo sumiu ou é inválido)."; return null }
        val p = (if (selId == it.id) params else CartoonParams()).copy(atFrame = if (forApply) atFrame else 0)
        val over = if (selId == it.id && mix != null && mix.id != it.id) mixClip else null
        val pOver = CartoonParams(speed = p.speed, intensity = p.intensity, smooth = p.smooth)
        val b = CartoonMath.combine(clip, p, over, pOver, mixGroups)
        if (b.isEmpty) { msg = "O trecho escolhido não tem movimento."; return null }
        return b
    }

    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Cartoon Motion Library", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("+ Importar VMD", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Accent, RoundedCornerShape(6.dp)).clickable { onImport(catSel ?: CartoonCat.BODY) }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip2("Todas", catSel == null) { catSel = null }
            CartoonCat.values().forEach { c -> Chip2(c.label, catSel == c) { catSel = c } }
        }
        if (!hasModel) Text("Importe um modelo para aplicar. A prévia e a lista funcionam sem modelo, mas a compatibilidade só aparece com um modelo aberto.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        if (catSel != null) Text("O VMD importado entra na categoria ${catSel!!.label}.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))

        list.forEach { it ->
            val clip = remember(it.id) { CartoonLibrary.clipOf(ctx, it) }
            val compat = if (clip != null && hasModel) clip.compat(modelBones, modelMorphs) else -1f
            val isSel = it.id == selId
            Row(Modifier.fillMaxWidth().padding(top = 6.dp).background(if (isSel) Color(0xFF4A2226) else Color(0xFF1E2024), RoundedCornerShape(6.dp))
                .clickable { if (isSel) selId = null else select(it) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Thumb(remember(it.id) { clip?.energy(20) ?: FloatArray(20) }, isSel || previewId == it.id)
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(it.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(it.cat.label + " · %d fr (%.1fs)".format(it.frames, it.seconds) + (if (!it.builtin) " · meu" else ""), color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (compat < 0f) "compatibilidade: abra um modelo" else "compat. ${(compat * 100).roundToInt()}% dos ossos",
                        color = if (compat in 0f..0.001f) Color(0xFFFF6B6B) else if (compat in 0f..0.6f) Color(0xFFFFB74D) else Muted, fontSize = 9.sp, maxLines = 1)
                }
                Text(if (previewId == it.id) "■ Parar" else "▶ Prévia", color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.background(ChipBg, RoundedCornerShape(6.dp)).clickable {
                        if (previewId == it.id) onStopPreview() else { select(it); buildFor(it, false)?.let { b -> onPreview(it.id, b, previewLoop) } }
                    }.padding(horizontal = 8.dp, vertical = 6.dp))
                Text("Aplicar", color = if (hasModel && compat != 0f) Color.White else Muted, fontSize = 11.sp,
                    modifier = Modifier.padding(start = 6.dp).background(if (hasModel && compat != 0f) Accent else ChipBg, RoundedCornerShape(6.dp)).clickable {
                        if (!hasModel) msg = "Importe um modelo antes de aplicar."
                        else if (compat == 0f) msg = "Nenhum osso deste movimento existe no modelo."
                        else { select(it); buildFor(it, true)?.let { b -> onApply(it, b) } }
                    }.padding(horizontal = 8.dp, vertical = 6.dp))
            }
        }
        if (list.isEmpty()) Text("Nenhum movimento nesta categoria. Use \"+ Importar VMD\".", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFB74D), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))

        if (sel != null && selClip != null) {
            val len = max(selClip.length, 1)
            val (s0, e0) = CartoonMath.range(selClip, params)
            val srcLen = max(e0 - s0, 1)
            val cyc = CartoonMath.cycleFrames(selClip, params)
            val total = cyc * params.loops
            Text("Editor — ${sel.name}", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            CSlider("Velocidade", "×%.2f".format(params.speed), params.speed, 0.25f, 3f) { params = params.copy(speed = it) }
            CSlider("Duração do ciclo", "$cyc fr", (srcLen / params.speed), 4f, max(srcLen * 4f, 30f)) { params = params.copy(speed = (srcLen / it).coerceIn(0.1f, 8f)) }
            CSlider("Intensidade", "%d%%".format((params.intensity * 100).roundToInt()), params.intensity, 0f, 2f) { params = params.copy(intensity = it) }
            CSlider("Repetições", "${params.loops}×", params.loops.toFloat(), 1f, 8f) { params = params.copy(loops = it.roundToInt().coerceIn(1, 8)) }
            CSlider("Quadro inicial", "$s0", s0.toFloat(), 0f, (len - 1).toFloat()) { params = params.copy(srcStart = it.roundToInt(), srcEnd = if (params.srcEnd in 0..it.roundToInt()) -1 else params.srcEnd) }
            CSlider("Quadro final", "$e0", e0.toFloat(), 1f, len.toFloat()) { v -> params = params.copy(srcEnd = if (v.roundToInt() >= len) -1 else max(v.roundToInt(), s0 + 1)) }
            CSlider("Suavização", "%d%%".format((params.smooth * 100).roundToInt()), params.smooth, 0f, 1f) { params = params.copy(smooth = it) }
            Text("Resultado: $total quadros (%.1fs) a partir do quadro $atFrame ao aplicar. Intensidade acima de 100% exagera, abaixo suaviza.".format(total / 30f), color = Muted, fontSize = 10.sp)
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip2(if (previewLoop) "Prévia em loop: sim" else "Prévia em loop: não", previewLoop) { previewLoop = !previewLoop }
                Text("Restaurar", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp).background(ChipBg, RoundedCornerShape(6.dp)).clickable { params = CartoonParams() }.padding(horizontal = 10.dp, vertical = 6.dp))
                if (!sel.builtin) Text("Excluir da biblioteca", color = Color(0xFFFF6B6B), fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp).background(ChipBg, RoundedCornerShape(6.dp)).clickable {
                    if (previewId == sel.id) onStopPreview(); CartoonLibrary.remove(ctx, sel); selId = null; mixId = null
                }.padding(horizontal = 10.dp, vertical = 6.dp))
            }
            Text("Combinar com outro movimento", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            Text("O outro movimento assume só os grupos marcados (e repete para cobrir a duração); o principal fica com o resto. Cada osso vem de uma única fonte: sem conflito.", color = Muted, fontSize = 10.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip2("Nenhum", mixId == null) { mixId = null }
                all.filter { it.id != sel.id }.forEach { o -> Chip2(o.name, mixId == o.id) { mixId = o.id } }
            }
            if (mix != null) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BoneGroup.values().forEach { g -> Chip2(g.label, g in mixGroups) { mixGroups = if (g in mixGroups) mixGroups - g else mixGroups + g } }
            }
            if (mix != null && mixClip == null) Text("O movimento escolhido para combinar não abriu.", color = Color(0xFFFF6B6B), fontSize = 10.sp)
        }
    }
}

@Composable private fun Chip2(text: String, active: Boolean, onClick: () -> Unit) {
    Text(text, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.background(if (active) Accent else ChipBg, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp))
}

@Composable private fun CSlider(label: String, shown: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(36.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.width(96.dp), maxLines = 1)
        Slider(value.coerceIn(min, max), onChange, valueRange = min..max, modifier = Modifier.weight(1f))
        Text(shown, color = Color.White, fontSize = 11.sp, modifier = Modifier.width(48.dp), maxLines = 1)
    }
}

/** Miniatura: perfil de "energia" do movimento ao longo do tempo (barras). Não é um render 3D do personagem. */
@Composable private fun Thumb(e: FloatArray, hot: Boolean) {
    Canvas(Modifier.size(width = 54.dp, height = 34.dp).background(Color(0xFF111214), RoundedCornerShape(4.dp))) {
        val bw = size.width / e.size
        for (i in e.indices) {
            val h = (e[i].coerceIn(0f, 1f) * (size.height - 6f)) + 3f
            drawRect(if (hot) Accent else Color(0xFF6B7280), Offset(i * bw + 1f, size.height - h), Size(bw - 2f, h))
        }
    }
}
