package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.project.PropMeta

/** Painel "Cena": cenário e acessórios extras (modelos PMX estáticos) com posição e escala. */
@Composable
fun ScenePanel(
    props: List<PropMeta>, sel: Int, onSel: (Int) -> Unit, boneNames: List<String>,
    onAdd: () -> Unit, onRemove: (Int) -> Unit,
    onChange: (Int, PropMeta) -> Unit, onDone: () -> Unit,
    modifier: Modifier
) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Cenário e acessórios", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("+ Adicionar", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.background(Accent, RoundedCornerShape(6.dp)).clickable { onAdd() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (props.isEmpty()) {
            Text("Importe .pmx, .pmd, .x (texto) ou .zip (cenário, palco, objeto).", color = Muted, fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp))
        }
        props.forEachIndexed { i, p ->
            Row(Modifier.fillMaxWidth().padding(top = 6.dp).background(if (i == sel) Color(0xFF4A2226) else Color(0xFF1E2024), RoundedCornerShape(6.dp))
                .clickable { onSel(if (i == sel) -1 else i) }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("Remover", color = Color(0xFFFF6B6B), fontSize = 11.sp, modifier = Modifier.clickable { onRemove(i) }.padding(start = 10.dp))
            }
        }
        val p = props.getOrNull(sel)
        var choosing by remember { mutableStateOf(false) }
        var q by remember { mutableStateOf("") }
        if (p != null) {
            val attached = p.bone.isNotEmpty()
            // ---- Parenting: prender o objeto a um osso do modelo principal
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (attached) "Preso ao osso: ${p.bone}" else "Solto no mundo", color = Color.White, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (boneNames.isNotEmpty()) {
                    Text(if (choosing) "Fechar" else "Prender a osso", color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.background(Color(0xFF26282D), RoundedCornerShape(6.dp)).clickable { choosing = !choosing }.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                if (attached) Text("Soltar", color = Color(0xFFFF6B6B), fontSize = 11.sp,
                    modifier = Modifier.padding(start = 8.dp).background(Color(0xFF26282D), RoundedCornerShape(6.dp))
                        .clickable { onChange(sel, p.copy(bone = "", x = 0f, y = 0f, z = 0f, rx = 0f, ry = 0f, rz = 0f)); onDone() }.padding(horizontal = 10.dp, vertical = 6.dp))
            }
            if (boneNames.isEmpty()) Text("Importe um modelo animado para poder prender o objeto a um osso (mão, cabeça...).", color = Muted, fontSize = 11.sp)
            if (choosing && boneNames.isNotEmpty()) {
                val quick = listOf("右手首" to "Mão D", "左手首" to "Mão E", "頭" to "Cabeça", "上半身" to "Costas", "センター" to "Centro").filter { it.first in boneNames }
                if (quick.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp)) {
                    quick.forEach { (n, label) ->
                        Text(label, color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.padding(end = 6.dp).background(Accent, RoundedCornerShape(6.dp))
                                .clickable { onChange(sel, p.copy(bone = n, x = 0f, y = 0f, z = 0f)); onDone(); choosing = false }.padding(horizontal = 12.dp, vertical = 6.dp))
                    }
                }
                SearchBox(q, "Buscar osso") { q = it }
                val list = remember(q, boneNames) { boneNames.filter { q.isBlank() || it.contains(q, true) } }
                LazyColumn(Modifier.fillMaxWidth().height(150.dp)) {
                    items(list) { n ->
                        Text(n, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth().clickable { onChange(sel, p.copy(bone = n, x = 0f, y = 0f, z = 0f)); onDone(); choosing = false; q = "" }.padding(vertical = 8.dp, horizontal = 6.dp))
                    }
                }
            }
            val r = if (attached) 10f else 30f
            PropSlider("X", p.x, -r, r, { onChange(sel, p.copy(x = it)) }, onDone)
            PropSlider("Y", p.y, -r, r, { onChange(sel, p.copy(y = it)) }, onDone)
            PropSlider("Z", p.z, -r, r, { onChange(sel, p.copy(z = it)) }, onDone)
            if (attached) {
                PropSlider("RX", p.rx, -180f, 180f, { onChange(sel, p.copy(rx = it)) }, onDone)
                PropSlider("RY", p.ry, -180f, 180f, { onChange(sel, p.copy(ry = it)) }, onDone)
                PropSlider("RZ", p.rz, -180f, 180f, { onChange(sel, p.copy(rz = it)) }, onDone)
            }
            PropSlider("Esc", p.s, 0.1f, 5f, { onChange(sel, p.copy(s = it)) }, onDone)
        } else if (props.isNotEmpty()) {
            Text("Toque num objeto para ajustar posição e escala.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
internal fun PropSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(26.dp))
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, onValueChangeFinished = onDone, valueRange = min..max, modifier = Modifier.weight(1f))
        Text("%.1f".format(value), color = Color.White, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.width(40.dp))
    }
}
