package studio.mmd.cartoon

import studio.mmd.mmd.VmdMorphTrack
import studio.mmd.mmd.VmdMotion
import studio.mmd.mmd.VmdTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/**
 * v1.29.2 — Cartoon em personagens EXTRAS do Elenco (pendência da IA anterior).
 * Extras não têm `Editor`: o movimento deles é um `VmdMotion` guardado em `cast/<id>.vmd`. Esta parte é PURA (sem Android):
 * mescla um movimento Cartoon (`Built`) dentro do movimento atual do extra e grava o resultado como VMD.
 */
object CartoonMerge {
    class Result(val motion: VmdMotion, val boneKeys: Int, val morphKeys: Int) { val written: Int get() = boneKeys + morphKeys }

    /**
     * Mescla [b] em [old] (pode ser null = extra parado). Nas trilhas que o Cartoon escreve, as keys entre b.first e b.last
     * são substituídas (mesma regra de `Editor.applyKeys`); o resto do movimento fica intacto.
     * [validBones]/[validMorphs]: nomes que o modelo do extra tem (null = não filtrar). Trilhas inexistentes no modelo são ignoradas.
     */
    fun merge(old: VmdMotion?, b: Built, validBones: Set<String>?, validMorphs: Set<String>?): Result {
        val bones = HashMap<String, VmdTrack>(old?.bones ?: emptyMap())
        val morphs = HashMap<String, VmdMorphTrack>(old?.morphs ?: emptyMap())
        var nb = 0; var nm = 0
        for ((name, keys) in b.bones) {
            if (validBones != null && name !in validBones) continue
            if (keys.isEmpty()) continue
            val frames = ArrayList<Int>(); val v = ArrayList<FloatArray>(); val ip = ArrayList<ByteArray>()
            val o = bones[name]
            if (o != null) for (i in o.frames.indices) {
                val f = o.frames[i]
                if (f in b.first..b.last) continue
                frames.add(f); v.add(o.v.copyOfRange(i * 7, i * 7 + 7)); ip.add(o.ip.copyOfRange(i * 16, i * 16 + 16))
            }
            for (k in keys) { frames.add(k.frame); v.add(k.v.copyOf()); ip.add(k.ip.copyOf()); nb++ }
            val order = frames.indices.sortedBy { frames[it] }   // estável: em quadro repetido, a ordem de inserção decide
            val fv = FloatArray(order.size * 7); val fi = ByteArray(order.size * 16)
            order.forEachIndexed { n, idx -> v[idx].copyInto(fv, n * 7); ip[idx].copyInto(fi, n * 16) }
            bones[name] = VmdTrack(IntArray(order.size) { frames[order[it]] }, fv, fi)
        }
        for ((name, keys) in b.morphs) {
            if (validMorphs != null && name !in validMorphs) continue
            if (keys.isEmpty()) continue
            val frames = ArrayList<Int>(); val w = ArrayList<Float>()
            val o = morphs[name]
            if (o != null) for (i in o.frames.indices) { if (o.frames[i] in b.first..b.last) continue; frames.add(o.frames[i]); w.add(o.w[i]) }
            for (k in keys) { frames.add(k.frame); w.add(k.w); nm++ }
            val order = frames.indices.sortedBy { frames[it] }
            morphs[name] = VmdMorphTrack(IntArray(order.size) { frames[order[it]] }, FloatArray(order.size) { w[order[it]] })
        }
        val maxF = maxOf(old?.maxFrame ?: 0, if (nb + nm > 0) b.last else 0)
        val mo = VmdMotion(old?.modelName ?: "cartoon", bones, morphs, maxF, emptyList(), old?.extras ?: studio.mmd.mmd.VmdExtras.EMPTY)
        return Result(mo, nb, nm)
    }

    /** VMD v2 com ossos e morphs de [mo] (nomes em Shift_JIS, 15 bytes), sem câmera; luz/sombra/IK de [mo].extras são preservados. */
    fun toVmdBytes(mo: VmdMotion, modelName: String): ByteArray {
        val sj = Charset.forName("Shift_JIS")
        class BRow(val n: String, val f: Int, val v: FloatArray, val ip: ByteArray)
        val bl = ArrayList<BRow>()
        for ((n, t) in mo.bones) for (i in t.frames.indices) bl.add(BRow(n, t.frames[i], t.v.copyOfRange(i * 7, i * 7 + 7), t.ip.copyOfRange(i * 16, i * 16 + 16)))
        bl.sortBy { it.f }
        class MRow(val n: String, val f: Int, val w: Float)
        val ml = ArrayList<MRow>()
        for ((n, t) in mo.morphs) for (i in t.frames.indices) ml.add(MRow(n, t.frames[i], t.w[i]))
        ml.sortBy { it.f }
        val b = ByteBuffer.allocate(30 + 20 + 4 + bl.size * 111 + 4 + ml.size * 23 + 4 + mo.extras.byteSize()).order(ByteOrder.LITTLE_ENDIAN)
        fun fixed(s: String, n: Int) {
            val e = s.toByteArray(sj); val a = ByteArray(n)
            System.arraycopy(e, 0, a, 0, minOf(e.size, n)); b.put(a)
        }
        fixed("Vocaloid Motion Data 0002", 30)
        fixed(modelName, 20)
        b.putInt(bl.size)
        for (r in bl) {
            fixed(r.n, 15); b.putInt(r.f)
            for (i in 0..6) b.putFloat(r.v[i])
            for (row in 0..3) for (j in 0 until 16) {   // mesmo layout de 64 bytes do Editor.toVmd
                val idx = j + row
                b.put(if (idx < 16) r.ip[idx] else if (idx == 16) 1.toByte() else 0.toByte())
            }
        }
        b.putInt(ml.size)
        for (r in ml) { fixed(r.n, 15); b.putInt(r.f); b.putFloat(r.w) }
        b.putInt(0)   // câmera
        mo.extras.write(b)
        return b.array()
    }
}
