# CHANGELOG
Estados: implementado / parcial / planejado / validado (escala 0–5 no roadmap, seção 13.1). Só 'validado' com build + teste no aparelho.

## 1.29.3 — Outliner: seleção múltipla + agrupar (8.4b; escrita, NÃO compilada)
## 1.29.2 — Cartoon em personagens extras (escrita; UI NÃO compilada; lógica pura testada em JVM)
- Alvo "Aplicar em" no painel Cartoon; prévia e aplicar no extra; `CartoonMerge` (mescla + grava VMD); "Desfazer no extra" (até 20 passos). 21/21 testes JVM (CartoonMerge 7 + Cartoon 14) executados.
## 1.29.1 — Undo/Redo do Outliner (8.4b-1; escrita, NÃO compilada)
- `History<T>` + botões desfazer/refazer no painel Layers; snapshot de organização + nomes de props/extras. Excluir/duplicar fora do histórico.
## 1.29.0 — Outliner funcional, fatia 8.4a (escrita, NÃO compilada, NÃO testada no aparelho)
- Renomear, mover, bloquear, visível no render, grupos, duplicar, excluir; persistência em `outliner.json`. Nível 3 (interface) no papel; 4 (persistência) só após teste. Sem Undo/Redo; Scene Graph ainda não ligado.
## 1.28.2 — segurança/documentação (escrita, NÃO compilada)
- Senhas de assinatura removidas do Gradle; `.jks` fora do zip; `.gitignore`; este changelog.
## 1.28.1 — correção de crash na Cartoon (texto com '100%' em format). Não validada.
## 1.28.0 — Cartoon Motion Library P1–P3 (nível 2–3; sem build confirmado).
## 1.27.0 — Elenco (8.3c) (nível 2; sem build confirmado).
## 1.26.0 / 1.25.0 — RigConfig por personagem / renderer por instância (sem build confirmado).
## 1.24.2 — correção visual do painel Luz (visto em print do aparelho).
## 1.24.1 — correção de build (`mainChar.shBone`); primeiro build que abriu no aparelho.
## 1.24.0 — troca de clip GLB desfazível.
## 1.14.0–1.23.0 — D/G (física/importação), Releases 5, 7, 8.1–8.2, 9.1–9.4. Compilaram e abriram (v1.24.1); funções sem teste explícito.
## Até 1.12.x — ver seção 6 do md de contexto (várias confirmadas no aparelho).
