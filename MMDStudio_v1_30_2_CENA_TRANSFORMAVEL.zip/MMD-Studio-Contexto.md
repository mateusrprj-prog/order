# MMD Studio — Contexto técnico da entrega v1.30.2

## Identificação
- Projeto: MMD Studio para Android, Kotlin + Jetpack Compose + OpenGL ES.
- Versão Gradle: **1.30.2** (`versionCode 72`).
- Base de trabalho: `MMDStudio_v1_30_1_ROTACAO_PERSONAGEM.zip` (derivada do ZIP v1.30.0 já atualizado para v1.30.1).
- Objetivo: integrar todos os itens importados em **Cena → Cenário e acessórios** ao painel **Transformar**, com rotação XYZ real, posição, escala e keyframes individuais.

## Problema reproduzido no vídeo
O usuário importou um palco de música em Cena. O palco aparece na lista `Cenário e acessórios`, mas o seletor `Transformar → Alvo` mostrava apenas `Personagem principal` e personagens extras. Assim o palco não podia ser escolhido no painel de transformação. O vídeo também mostra que a aba Cena oferecia sliders X/Y/Z de posição e escala, sem oferecer o mesmo controle completo XYZ de rotação do painel Transformar.

## O que mudou em v1.30.2
1. `ui/SceneScreen.kt`
   - O seletor Transformar agora monta os alvos a partir de personagem principal (`model`), extras (`char:<id>`) e todos os itens importados de Cena (`prop:<id>`).
   - Ao clicar num item na lista Cena, o `layerSel` passa a apontar para esse `prop:<id>`. Selecionar no dropdown também atualiza o item selecionado na lista Cena.
   - `updateRootTransform()` agora sincroniza objetos `prop:` com o estado de transformação persistente e com `SceneGLView.setProp()`.
   - `applyRootTransformsAt()` aplica no quadro atual as transformações amostradas de cada objeto Cena, incluindo posição, rotação, escala e o vínculo opcional a osso. `setPropTransforms()` envia o conjunto em lote à thread GL. Isso alcança prévia e rotinas de captura/exportação que já usam o método.
   - Projetos existentes inicializam tracks ausentes com os valores antigos de `props.json`; as tracks são preservadas por ID.
   - Duplicar um prop duplica também sua track para um ID independente; remover um prop remove a track antiga.
   - `props.json` é sincronizado e salvo com debounce e no salvamento/fechamento do projeto.
2. `render/SceneGLView.kt`
   - Corrigido o caminho de renderização de props soltos: agora aplica `T * Ry * Rx * Rz * S`. Antes, a rotação só era aplicada no caminho de objetos anexados a ossos.
   - Objetos anexados continuam recebendo rotação local do osso e offset, sem mudar o sistema da câmera.
3. `ui/TransformPanel.kt`
   - Título e texto mudam conforme o alvo: personagem principal, personagem ou objeto da cena.
   - A UI deixa explícito que rotação XYZ, posição e escala pertencem ao item selecionado.
4. `ui/ScenePanel.kt` e `scene/RootTransform.kt`
   - Documentação interna atualizada para refletir o vínculo com o painel Transformar e o suporte de IDs `prop:<id>`.
5. `app/src/test/java/studio/mmd/RootTransformTest.kt`
   - Novo teste cobre transformação independente, keyframes, interpolação e codec para `prop:music-stage`.

## Como usar após instalar a versão compilada
1. Importe o palco em **Cena → + Adicionar**.
2. Toque no nome dele na lista **Cenário e acessórios** ou abra **Transformar**.
3. Em **Alvo**, escolha `Cena · <nome do objeto>`.
4. Ajuste rotação X/Y/Z nos campos numéricos (ou X/Y no controle circular), posição e escala.
5. Use Criar keyframe no quadro desejado para animar aquele objeto independentemente.

## Escopo e limites
- Inclui qualquer elemento importado que seja adicionado à lista Cena e renderizado pelo fluxo de `PropMeta`/`SceneGLView` (ex.: PMX, PMD, X, ZIP, GLB, glTF e OBJ, conforme o importador aceitar o arquivo).
- Cada item é transformado individualmente. Esta entrega **não** cria um controle global para girar todos os objetos/personagens da cena em conjunto.
- Luz e câmera continuam sendo alvos dos painéis próprios; não são `PropMeta` da lista Cena.
- O SceneGraph genérico legado ainda não substitui os dados reais de `PropMeta` nesta integração.
- Transformações de props são aplicadas na prévia/captura/exportação que já chama `applyRootTransformsAt()`. A conversão/bake destas tracks para arquivos VMD/GLB/FBX não faz parte desta entrega.

## Estado de validação
- Código-fonte alterado: SIM.
- ZIP criado e integridade testada: SIM (ver arquivo de entrega).
- Teste novo escrito: SIM.
- Testes JVM executados: NÃO.
- Build Android executado: NÃO.
- Teste no dispositivo: NÃO.

Motivo: este ambiente não contém Gradle, Gradle Wrapper ou Android SDK. O passo obrigatório seguinte é executar o workflow **Build Android APK** no GitHub Actions, corrigir eventuais erros de compilação e testar no POCO X7 Pro os critérios de aceitação descritos na nota v1.30.2 dos roadmaps.

## Histórico imediato
- **v1.30.1:** transformação da personagem inteira: rotação XYZ, posição, escala, painel circular, keyframes e persistência em `root_transforms.json`. Não compilada/testada neste ambiente.
- **v1.30.0:** navegação de viewport (orbit/pan/zoom/foco/gizmo); não compilada/testada neste ambiente.
