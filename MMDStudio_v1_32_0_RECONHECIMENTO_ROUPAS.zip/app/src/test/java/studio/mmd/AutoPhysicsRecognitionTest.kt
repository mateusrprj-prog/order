package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxMaterial
import studio.mmd.mmd.PmxModel
import studio.mmd.rig.AutoPhysics

class AutoPhysicsRecognitionTest {
    private fun bone(name: String, parent: Int = -1) = PmxBone(
        name, "", 0f, 0f, 0f, parent, 0, 0, -1, -1, 0f, null
    )

    private fun material(name: String, indexCount: Int = 3) = PmxMaterial(
        name, "", floatArrayOf(1f, 1f, 1f, 1f), floatArrayOf(0f, 0f, 0f), 0f,
        floatArrayOf(0f, 0f, 0f), 0, floatArrayOf(0f, 0f, 0f, 1f), 0f,
        -1, -1, 0, false, -1, indexCount
    )

    private fun model(materialName: String, boneName: String = "deform_01") = PmxModel(
        name = "Test", version = 2.1f,
        positions = floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f),
        normals = FloatArray(9), uvs = FloatArray(6),
        boneIndices = intArrayOf(1, -1, -1, -1, 1, -1, -1, -1, 1, -1, -1, -1),
        boneWeights = floatArrayOf(1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f),
        indices = intArrayOf(0,1,2), textures = emptyList(),
        materials = listOf(material(materialName)),
        bones = listOf(bone("センター"), bone(boneName, 0)), morphs = emptyList()
    )

    @Test fun recognizesClothingMaterialThroughVertexSkinWeights() {
        val result = AutoPhysics.detect(model("Skirt_Material"))
        assertTrue(result.fromMaterials)
        assertTrue(result.recognizedMaterials.any { it.contains("Saia") })
        val skirt = result.groups.firstOrNull { it.name.startsWith("Saia") }
        assertNotNull(skirt)
        assertTrue(skirt!!.bones.contains("deform_01"))
    }

    @Test fun recognizesHairMaterialWithoutNamedHairBones() {
        val result = AutoPhysics.detect(model("Hair"))
        assertTrue(result.groups.any { it.name.startsWith("Cabelo") })
    }

    @Test fun genericBodyMaterialDoesNotInventClothingGroup() {
        val result = AutoPhysics.detect(model("Body"))
        assertFalse(result.groups.any { it.name.startsWith("Saia") || it.name.startsWith("Roupa") })
    }
}
