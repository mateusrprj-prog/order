package studio.mmd.rig

import org.json.JSONObject

/**
 * Persistência de um perfil de rig/física pertencente a UM personagem extra do Elenco.
 * O principal continua usando rig.json/secondary.json/physics.json por compatibilidade.
 * O cache de física é intencionalmente transitório (memória), como no perfil principal.
 */
object CharacterRigProfileCodec {
    const val VERSION = 1

    fun encode(config: RigConfig): String = JSONObject()
        .put("formatVersion", VERSION)
        .put("constraints", RigIo.toJson(config.list))
        .put("secondary", SecIo.toJson(config.secondary))
        .put("physics", PhysIo.toJson(config.phys))
        .toString()

    fun decode(text: String): RigConfig {
        val root = JSONObject(text)
        val version = root.optInt("formatVersion", 0)
        require(version <= VERSION) { "Perfil de rig de uma versão mais nova ($version)" }
        return RigConfig().apply {
            list = RigIo.fromJson(root.optString("constraints", "[]"))
            secondary = SecIo.fromJson(root.optString("secondary", "[]"))
            phys = PhysIo.fromJson(root.optString("physics", "{}"))
        }
    }

    fun safeDecode(text: String): RigConfig = try { decode(text) } catch (_: Throwable) { RigConfig() }
}