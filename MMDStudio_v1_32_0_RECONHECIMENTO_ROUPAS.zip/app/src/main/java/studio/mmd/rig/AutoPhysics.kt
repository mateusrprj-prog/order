package studio.mmd.rig

import studio.mmd.mmd.PmxBone
import studio.mmd.mmd.PmxModel
import kotlin.math.max

/**
 * Reconhecimento heurístico de partes dinâmicas PMX.
 * Combina nomes de ossos/corpos rígidos com materiais e pesos de skinning dos vértices
 * usados por cada material. Não afirma identificar tecido por geometria: isso exige
 * segmentação/colisão de malha, que é uma etapa separada do solver.
 */
object AutoPhysics {
    data class Result(
        val groups: List<Secondary>,
        val summary: String,
        val fromPhysics: Boolean,
        val fromMaterials: Boolean = false,
        val recognizedMaterials: List<String> = emptyList(),
        val unclassifiedMaterials: List<String> = emptyList()
    )

    private data class Cat(val label: String, val preset: Int, val keys: List<String>)
    private val cats = listOf(
        Cat("Cabelo", 0, listOf("髪", "hair", "ヘア", "ahoge", "アホ毛", "ポニテ", "ponytail", "twintail", "ツイン", "前髪", "横髪", "後髪", "bangs", "fringe")),
        Cat("Saia", 1, listOf("スカート", "skirt", "petticoat", "underskirt", "hem", "裾", "フレア", "flare", "jupe")),
        Cat("Roupa superior", 1, listOf("上着", "衣装", "服", "制服", "トップス", "shirt", "blouse", "top", "bodice", "jacket", "coat", "hoodie", "sweater", "dress", "ドレス", "袖", "sleeve", "cape", "cloak", "マント", "collar", "襟", "ネクタイ", "necktie", "scarf", "マフラー", "shawl", "frill", "フリル", "apron", "エプロン")),
        Cat("Roupa inferior", 1, listOf("ズボン", "パンツ", "shorts", "trousers", "pants", "leggings", "stocking", "tights", "靴下", "ソックス", "スパッツ")),
        Cat("Cauda/orelha", 6, listOf("尻尾", "しっぽ", "tail", "耳", "ケモ", "wing", "feather", "羽")),
        Cat("Peito", 5, listOf("乳", "おっぱい", "oppai", "breast", "bust", "boob", "ちち")),
        Cat("Acessório", 2, listOf("リボン", "ribbon", "アクセ", "accessor", "飾", "ピアス", "イヤリング", "earring", "鈴", "chain", "チェーン", "紐", "himo", "string", "strap", "タッセル", "tassel", "ケーブル", "cable", "ヘッドホン", "headphone", "belt", "ベルト", "バッグ", "bag"))
    )

    private fun isIk(b: PmxBone) = b.ik != null || b.name.contains("IK") || b.name.contains("ＩＫ")
    private fun normalized(s: String) = s.lowercase().replace('_', ' ').replace('-', ' ')
    private fun category(text: String): Cat? {
        val t = normalized(text)
        return cats.firstOrNull { c -> c.keys.any { key ->
            val k = normalized(key)
            if (k.any { it.code > 127 }) t.contains(k)
            else Regex("(?<![a-z0-9])${Regex.escape(k)}(?![a-z0-9])").containsMatchIn(t)
        } }
    }

    fun detect(model: PmxModel): Result {
        val bones = model.bones
        if (bones.isEmpty()) return Result(emptyList(), "Modelo sem ossos para criar movimento secundário", false)

        val scores = Array(bones.size) { FloatArray(cats.size) }
        val evidence = Array(bones.size) { ArrayList<String>() }
        val physByBone = HashMap<Int, MutableList<studio.mmd.mmd.PmxRigid>>()
        for (rb in model.rigidBodies) {
            if ((rb.mode == 1 || rb.mode == 2) && rb.bone in bones.indices && !isIk(bones[rb.bone])) {
                physByBone.getOrPut(rb.bone) { ArrayList() }.add(rb)
                val text = "${rb.name} ${rb.nameEn}"
                category(text)?.let { c ->
                    val ci = cats.indexOf(c); scores[rb.bone][ci] += 3f; evidence[rb.bone].add("corpo rígido")
                }
            }
        }
        val fromPhysics = physByBone.isNotEmpty()

        // Evidência pelos nomes dos ossos. Usa correspondência longa/idiomas japoneses para reduzir falsos positivos.
        for (i in bones.indices) {
            val b = bones[i]
            if (isIk(b)) continue
            category("${b.name} ${b.nameEn}")?.let { c ->
                scores[i][cats.indexOf(c)] += 2.2f
                evidence[i].add("nome do osso")
            }
        }

        // Cada material ocupa um intervalo contíguo de índices PMX. Os pesos BDEF/SDEF/QDEF
        // dos vértices desse intervalo apontam quais ossos realmente deformam aquela parte.
        var indexStart = 0
        val recognizedMaterials = ArrayList<String>()
        val unclassifiedMaterials = ArrayList<String>()
        var materialEvidence = false
        for (mat in model.materials) {
            val end = (indexStart.toLong() + mat.indexCount.toLong()).coerceAtMost(model.indices.size.toLong()).toInt()
            val texture = model.textures.getOrNull(mat.textureIndex).orEmpty()
            val labelText = "${mat.name} ${mat.nameEn} ${mat.memo} $texture"
            val cat = category(labelText)
            if (cat != null && end > indexStart) {
                materialEvidence = true
                recognizedMaterials.add("${mat.name.ifBlank { mat.nameEn }} → ${cat.label}")
                val ci = cats.indexOf(cat)
                val vertexWeight = HashMap<Int, Float>()
                var validCorners = 0
                var p = indexStart
                while (p < end) {
                    val vi = model.indices[p]
                    if (vi in 0 until model.vertexCount) {
                        validCorners++
                        val base = vi * 4
                        for (slot in 0..3) {
                            val bi = model.boneIndices.getOrNull(base + slot) ?: -1
                            val w = model.boneWeights.getOrNull(base + slot) ?: 0f
                            if (bi in bones.indices && w > 0f && !isIk(bones[bi]))
                                vertexWeight[bi] = (vertexWeight[bi] ?: 0f) + w
                        }
                    }
                    p++
                }
                for ((bi, weight) in vertexWeight) {
                    // Média de influência por canto do material; independe do tamanho absoluto da malha.
                    val averageInfluence = weight / validCorners.coerceAtLeast(1)
                    if (averageInfluence >= 0.08f) {
                        scores[bi][ci] += 3.0f * averageInfluence
                        evidence[bi].add("material ${mat.name.ifBlank { mat.nameEn }}")
                    }
                }
            } else if (mat.indexCount > 0) {
                unclassifiedMaterials.add(mat.name.ifBlank { mat.nameEn.ifBlank { "Material ${model.materials.indexOf(mat) + 1}" } })
            }
            indexStart = end
        }

        // Sem material identificável, mantém compatibilidade com rigs nomeados. Corpos rígidos
        // sem nome reconhecível ficam em Outros apenas quando o modelo realmente tem física.
        val byCategory = LinkedHashMap<Int, MutableList<Int>>()
        for (bi in bones.indices) {
            if (isIk(bones[bi])) continue
            val best = scores[bi].indices.maxByOrNull { scores[bi][it] }
            if (best != null && scores[bi][best] >= 0.25f) byCategory.getOrPut(best) { ArrayList() }.add(bi)
            else if (fromPhysics && physByBone.containsKey(bi)) byCategory.getOrPut(-1) { ArrayList() }.add(bi)
        }

        val groups = ArrayList<Secondary>()
        for ((ci, list) in byCategory) {
            val cat = cats.getOrNull(ci)
            val label = cat?.label ?: "Outros com física"
            val preset = cat?.preset ?: 2
            var g = SecPreset.apply(Secondary(java.util.UUID.randomUUID().toString(), "$label (auto)", list.map { bones[it].name }.distinct()), preset)
            val rbs = list.flatMap { physByBone[it] ?: emptyList() }
            if (rbs.isNotEmpty()) {
                val mass = rbs.map { it.mass }.average().toFloat()
                val ang = rbs.map { it.angularDamping }.average().toFloat()
                g = g.copy(
                    damping = (g.damping + (ang - 0.7f) * 0.3f).coerceIn(0.15f, 1.2f),
                    stiffness = (g.stiffness * (1.4f / (0.8f + max(mass, 0.01f))).coerceIn(0.6f, 1.4f)).coerceIn(30f, 500f)
                )
            }
            groups.add(g)
        }
        val summary = if (groups.isEmpty()) "Nenhuma parte dinâmica reconhecida. Verifique nomes de materiais/ossos ou adicione uma cadeia manualmente." else {
            val source = buildList {
                if (fromPhysics) add("corpos rígidos")
                if (materialEvidence) add("materiais + pesos dos vértices")
                if (!fromPhysics && !materialEvidence) add("nomes dos ossos")
            }.joinToString(" e ")
            "Reconhecido por $source: " + groups.joinToString(" · ") { "${it.name.substringBefore(" (")} ${it.bones.size}" }
        }
        return Result(groups, summary, fromPhysics, materialEvidence, recognizedMaterials, unclassifiedMaterials)
    }
}
