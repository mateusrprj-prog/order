# Changelog

## [1.32.0] — 2026-11-20

### Melhorado — reconhecimento de partes para física/movimento secundário
- `AutoPhysics` agora combina três fontes de evidência: nomes dos ossos, nomes dos corpos rígidos PMX e materiais/nomes de textura associados aos pesos de skinning dos vértices usados por cada material.
- Materiais identificados como cabelo, saia, roupa superior/inferior, cauda/orelhas, peito e acessórios geram grupos usando os ossos que realmente deformam aquela região, em vez de depender exclusivamente do nome do osso.
- A média de influência por vértice reduz o viés de materiais com mais triângulos; correspondência ASCII usa limites de palavra para evitar falsos positivos simples (ex.: `top` dentro de outra palavra).
- Relatório da detecção mostra os materiais reconhecidos e uma amostra dos materiais ainda sem categoria.
- Texto da UI esclarece que o recurso cria grupos de movimento secundário sobre ossos; não é colisão de tecido e não impede a perna de atravessar a saia.
- Testes adicionados para reconhecimento por material + skinning, cabelo e material genérico de corpo.

### Limites conhecidos
- É uma heurística: nomes genéricos (`Material 01`, `Object`, etc.), texturas sem nome útil ou skinning distribuído por todo o corpo podem exigir criação manual de cadeia.
- A detecção não segmenta a malha por aparência nem cria colisores tecido–corpo. A física de tecido/Soft Body e colisão da roupa continua como prioridade P0 separada.
- Testes JVM e build Android NÃO executados neste ambiente; executar GitHub Actions e validar com os modelos PMX reais do usuário.


## [1.31.0] — 2026-11-20

### Adicionado
- Outliner da Cena aberto por padrão ao entrar no viewport, inspirado no seletor hierárquico do Blender. Reúne modelo principal, objetos importados em Cena, personagens do Elenco, luz, câmera e áudio; mantém seleção destacada e ações existentes de grupos, visibilidade e bloqueio.
- Selecionar um personagem no Outliner ativa a sessão de edição correspondente e abre o painel Rig desse personagem. O cabeçalho identifica explicitamente o dono da configuração (`CONFIGURAÇÃO DE RIG · <nome>`).
- Perfil independente de rig/física para cada personagem extra (`cast/<id>.rig.json`): restrições, movimento secundário e configuração de física real PMX. O personagem principal continua compatível com seus arquivos legados.
- Duplicar personagem copia o perfil para um novo ID; excluir personagem remove somente o seu perfil.
- Status resumido por personagem no Outliner (física real ligada/desligada e número de grupos de movimento secundário).

### Corrigido
- O renderer agora recebe e conserva o `RigConfig` próprio de cada personagem extra ao criar/recriar a instância; alteração de perfil atualiza somente o Animator correspondente e reinicia a dinâmica daquele personagem.
- Bake do movimento secundário e bake da física real aceitam o perfil ativo, sem cair no `RigState.main` para personagens do Elenco.
- Ações “Editar este personagem” e “Editar personagem principal” do painel Elenco agora atualizam seleção do Outliner, alvo ativo e painel Rig de forma consistente.

### Testes / validação
- Adicionado `CharacterRigProfileTest` com 3 casos: round-trip de dados, independência entre dois perfis e fallback seguro de versão desconhecida.
- Testes JVM e build Android NÃO executados neste ambiente; requer workflow GitHub Actions e teste no aparelho.
- Física de tecido/colisão corpo–saia NÃO faz parte desta versão e continua planejada separadamente.


## 1.30.2 — P0 URGENTE: transformar qualquer objeto adicionado em Cena (código-fonte atualizado; build não executado)
- O seletor de **Transformar** agora lista o personagem principal, personagens extras do Elenco e todos os objetos importados na aba **Cena** (`prop:<id>`), identificados como `Cena · <nome>`.
- Ao selecionar um item na lista de Cena, ele também passa a ser o alvo ativo do painel Transformar. Selecionar um objeto no menu Alvo atualiza a seleção correspondente da aba Cena.
- Objetos de Cena recebem transformação independente: posição X/Y/Z, rotação X/Y/Z, escala uniforme e keyframes interpolados na mesma timeline; cada objeto usa sua própria chave persistente `prop:<id>` em `root_transforms.json`.
- Projetos antigos são migrados automaticamente usando os valores já salvos em `props.json`. Ao duplicar um objeto, a trilha de transformação é duplicada com ID independente; ao excluir, sua trilha é removida.
- `applyRootTransformsAt()` agora aplica as transformações de todos os objetos de Cena na prévia e nos caminhos de captura/exportação que já chamam esse método; `setPropTransforms()` envia todos os props em um único evento para a thread GL por quadro.
- Corrigido `SceneGLView`: a rotação RX/RY/RZ agora também é aplicada a objetos soltos no mundo. Antes, o renderer aplicava esses ângulos apenas no caminho de objetos presos a ossos.
- Atualizados `TransformPanel`, `ScenePanel`, `SceneScreen`, `RootTransform` e testes de transformação.
- Validação: revisão estática e integridade do ZIP; testes JVM e build Android NÃO executados neste ambiente (sem Gradle, Gradle Wrapper e Android SDK). Teste em dispositivo ainda necessário.

# CHANGELOG
Estados: implementado / parcial / planejado / validado (escala 0–5 no roadmap, seção 13.1). Só 'validado' com build + teste no aparelho.

## 1.30.1 — P0 URGENTE: Transformação/rotação da personagem inteira. IMPLEMENTADA NO CÓDIGO-FONTE; BUILD ANDROID NÃO EXECUTADO
- Novo `scene/RootTransform.kt`: transformação raiz por alvo (personagem principal `model` ou extra `char:<id>`), com posição X/Y/Z, rotação X/Y/Z e escala; dados persistidos em `root_transforms.json` por projeto.
- Novo painel **Transformar** no SceneScreen: seletor de personagem, controle circular de rotação, campos numéricos de graus X/Y/Z, posição, escala, zerar rotação e criação/remoção de keyframes no quadro atual.
- O renderer agora aplica matriz de raiz `T * Rz * Ry * Rx * S` antes da projeção, tanto no principal quanto nos extras. Skinning/animação dos ossos continua separado; a câmera de viewport e a câmera VMD não são alteradas.
- A transformação é amostrada pela timeline e aplicada antes das capturas/exportações PNG, sequência e MP4; transformações dos extras sincronizam os valores legados de posição/giro/escala no `cast.json` para compatibilidade.
- Ângulos permanecem contínuos (ex.: 350° → 710°), permitindo giros completos animados; não são truncados para ±180°.
- Teste JVM adicionado/ajustado: `RootTransformTest` (codec round-trip, interpolação contínua, edição de keyframe). **Não executado neste ambiente.**
- **Status honesto:** código-fonte e documentação atualizados; não há Gradle wrapper, Gradle instalado nem Android SDK neste ambiente. Portanto, não foi possível compilar, executar testes JUnit Android/JVM completos nem validar o toque/render no aparelho. Verificar no GitHub Actions antes de instalar.
- Limites conhecidos: o controle circular manipula X/Y; Z é ajustado numericamente. Duplicar extra copia base e keyframes da transformação; remover extra limpa sua trilha. Não existe ainda rotação relativa à câmera, gizmo de anel 3D no viewport, Undo/Redo próprio, nem bake da transformação raiz para exportação VMD/GLB/FBX.

## 1.30.0 — P0 URGENTE: Navegação Livre da Viewport (Free Orbit Camera). ESCRITA, NÃO COMPILADA, NÃO TESTADA NO APARELHO
- **Câmera de viewport extraída** para `render/OrbitCamera.kt` (matemática pura, sem Android): orbit, pan em espaço de câmera, zoom com limites (0,3–400), foco, enquadrar esfera/caixa, `presetLabel`. Não toca em modelo, osso, keyframe, IK nem Undo.
- **Orbit livre**: 1 dedo gira em qualquer ângulo (yaw sem limite, pitch ±89° sem inversão). Nas ferramentas Girar/Mover o dedo só edita o osso se o toque COMEÇAR a ≤56 dp do osso selecionado; fora disso orbita (antes ficava preso editando o osso).
- **Pan corrigido**: 2 dedos movem o foco no plano da câmera (antes ignorava a elevação) e a velocidade acompanha a distância/FOV.
- **Zoom por pinça** via `OrbitCamera.zoom` (limites seguros, ignora NaN/≤0).
- **Foco**: menu do viewport ganhou "Focar personagem ativo" e "Focar item selecionado"; "Enquadrar tudo" agora enquadra a caixa real da cena (extras e acessórios) em vez de só resetar. Mantém yaw/pitch e passa a orbitar o novo ponto.
- **Gizmo de orientação** (`ui/OrientationGizmo.kt`, canto superior direito): eixos ±X/±Y/±Z projetados pela câmera; tocar num eixo vai para Direita/Esquerda/Topo/Base/Frente/Trás e continua orbitável. Presets do menu/Outliner mantidos (viram atalhos).
- Testes JVM novos: `ViewportNavigationTest` (20 testes: base ortonormal, pitch/yaw, distância constante na órbita, pan sem andar na visada, zoom limitado, foco, enquadrar caixa com pivô distante, presets, gizmo). **Não executados aqui (sem Gradle/kotlinc no ambiente).**
- Pendente (P2): sensibilidade configurável, inércia, persistência da vista no projeto, ponto de órbita escolhido por toque.
## 1.29.13 — 8.3d-B3: renderer no personagem ativo (esqueleto desenhado, seleção e arrasto de ossos no extra; escrita, NÃO compilada). Fecha a 8.3d-B
## 1.29.12 — 8.3d-B2: personagem ativo editável pela UI (botão "Editar este personagem" no Elenco; Esqueleto/Keys/Dope Sheet/Desfazer/Key apontam para o ativo; salva em cast/<id>.vmd; escrita, NÃO compilada)
## 1.29.11 — 8.3d-B1: base lógica do personagem ativo (ActiveCharacter + EditSessions; 5 testes JVM OK; sem mudança de UI)
## 1.29.10 — 8.3d-C: exportar todos os personagens em .zip (CastExport; 3 testes JVM OK; UI NÃO compilada)
## 1.29.9 — 8.3d-A: copiar/colar poses entre personagens (PoseTransfer; 6 testes JVM OK; UI NÃO compilada)
## 1.29.8 — 8.4b final: Outliner lê a hierarquia do Scene Graph (SceneHierarchy; 7 testes JVM OK; UI NÃO compilada)
## 1.29.7 — Seleção por toque na viewport (8.4b; escrita, NÃO compilada)
## 1.29.6 — Cartoon: sinais de eixo corrigidos + IK das pernas desligado no trecho (30 testes JVM OK; UI NÃO compilada)
## 1.29.5 — Cartoon: editor acima da lista, barra de prévia, nomes sem corte, painel 380 dp; GLB: lista de animações volta ao reabrir (escrita, NÃO compilada)
## 1.29.4 — correção de build: `import java.util.Properties` no build.gradle.kts (erro 'Unresolved reference: util/load' no CI, vindo da v1.28.2)
## 1.29.3 — Outliner: seleção múltipla + agrupar (8.4b; escrita, NÃO compilada)
## 1.29.2 — Cartoon em personagens extras (escrita; UI NÃO compilada; lógica pura testada em JVM)
- Alvo "Aplicar em" no painel Cartoon; prévia e aplicar no extra; `CartoonMerge` (mescla + grava VMD); "Desfazer no extra" (até 20 passos). 21/21 testes JVM (CartoonMerge 7 + Cartoon 14) executados.
## 1.29.1 — Undo/Redo do Outliner (8.4b-1; escrita, NÃO compilada)
- `History<T>` + botões desfazer/refazer no painel Layers; snapshot de organização + nomes de props/extras. Excluir/duplicar fora do histórico.
## 1.29.0 — Outliner funcional, fatia 8.4a (escrita, NÃO compilada, NÃO testada no aparelho)
- Renomear, mover, bloquear, visível no render, grupos, duplicar, excluir; persistência em `outliner.json`. Nível 3 (interface) no papel; 4 (persistência) só após teste. Sem Undo/Redo; Scene Graph ainda não ligado.
## 1.28.2 — segurança/documentação (escrita, NÃO compilada)
- Senhas de assinatura removidas do Gradle; `.jks` fora do zip; `.gitignore`; este changelog.
## 1.28.1 — correção de crash na Cartoon (texto com '100%' em format). Não validada.
## 1.28.0 — Cartoon Motion Library P1–P3 (nível 2–3; sem build confirmado).
## 1.27.0 — Elenco (8.3c) (nível 2; sem build confirmado).
## 1.26.0 / 1.25.0 — RigConfig por personagem / renderer por instância (sem build confirmado).
## 1.24.2 — correção visual do painel Luz (visto em print do aparelho).
## 1.24.1 — correção de build (`mainChar.shBone`); primeiro build que abriu no aparelho.
## 1.24.0 — troca de clip GLB desfazível.
## 1.14.0–1.23.0 — D/G (física/importação), Releases 5, 7, 8.1–8.2, 9.1–9.4. Compilaram e abriram (v1.24.1); funções sem teste explícito.
## Até 1.12.x — ver seção 6 do md de contexto (várias confirmadas no aparelho).

## Nota de planejamento — Física de roupas (20/11/2026; sem mudança de versão/código)
- Auditada a física da v1.30.2 diante do vídeo `1000243628.mp4`.
- Confirmado: colisões atuais são entre corpos rígidos PMX; movimento secundário aplica molas às rotações dos ossos; dados Soft Body PMX 2.1 são preservados sem simulação; cache guarda poses de ossos, não estado do tecido.
- Criada especificação P0 para colisores corporais cinemáticos + simulação de roupa PBD/XPBD + bake determinístico, começando pela saia e pernas.
- **Esta nota não implementa física de tecido e não altera a versão 1.30.2.** Ver `docs/P0_Fisica_Roupas_Colisoes.md`.
