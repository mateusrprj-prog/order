package studio.mmd.rig

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

/** Bake de tecido independente da GPU, com um snapshot XYZ por vértice e por quadro. */
data class ClothBakeCache(val vertexCount: Int, val fps: Int, val frames: List<FloatArray>, val modelHash: Long = 0L) {
    init {
        require(vertexCount >= 0)
        require(fps in 1..240)
        require(frames.all { it.size == vertexCount * 3 })
    }
}

/** Codec binário versionado para caches XPBD. Rejeita tamanhos inconsistentes, NaN/Inf e CRC inválido. */
object ClothCacheCodec {
    private val magic = byteArrayOf(77, 77, 68, 67, 76, 84, 72, 49) // MMDCLTH1
    private const val HEADER_V1 = 8 + 4 * 4 + 8
    private const val HEADER_V2 = HEADER_V1 + 8
    private const val MAX_BYTES = 512L * 1024 * 1024
    private const val MAX_VERTICES = 2_000_000
    private const val MAX_FRAMES = 100_000

    fun encode(cache: ClothBakeCache): ByteArray {
        require(cache.vertexCount <= MAX_VERTICES && cache.frames.size <= MAX_FRAMES) { "Bake de tecido excede os limites do cache" }
        val floatCount = cache.vertexCount.toLong() * 3L * cache.frames.size.toLong()
        val payloadBytes = floatCount * 4L
        val total = HEADER_V2.toLong() + payloadBytes + 4L
        require(total <= MAX_BYTES && total <= Int.MAX_VALUE) { "Cache de tecido grande demais" }
        val out = ByteBuffer.allocate(total.toInt()).order(ByteOrder.LITTLE_ENDIAN)
        out.put(magic); out.putInt(2); out.putInt(cache.vertexCount); out.putInt(cache.fps); out.putInt(cache.frames.size); out.putLong(payloadBytes); out.putLong(cache.modelHash)
        for (frame in cache.frames) for (v in frame) {
            require(v.isFinite()) { "Cache contém posição não finita" }
            out.putFloat(v)
        }
        val crc = CRC32(); crc.update(out.array(), 0, out.position())
        out.putInt(crc.value.toInt())
        return out.array()
    }

    fun decode(bytes: ByteArray): ClothBakeCache {
        require(bytes.size >= HEADER_V1 + 4 && bytes.size.toLong() <= MAX_BYTES) { "Cache de tecido truncado ou grande demais" }
        val input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val got = ByteArray(magic.size); input.get(got)
        require(got.contentEquals(magic)) { "Assinatura de cache XPBD inválida" }
        val version = input.int
        require(version in 1..2) { "Versão de cache XPBD não suportada: $version" }
        val vertices = input.int; val fps = input.int; val count = input.int; val payload = input.long
        val modelHash = if (version >= 2) input.long else 0L
        val header = if (version >= 2) HEADER_V2 else HEADER_V1
        require(vertices in 0..MAX_VERTICES && fps in 1..240 && count in 0..MAX_FRAMES) { "Metadados de cache XPBD inválidos" }
        val expected = vertices.toLong() * 3L * count.toLong() * 4L
        require(payload == expected && header.toLong() + payload + 4L == bytes.size.toLong()) { "Tamanho interno do cache XPBD inconsistente" }
        val crc = CRC32(); crc.update(bytes, 0, bytes.size - 4)
        val stored = ByteBuffer.wrap(bytes, bytes.size - 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        require(stored == crc.value.toInt()) { "CRC do cache XPBD não confere" }
        val frames = ArrayList<FloatArray>(count)
        repeat(count) {
            val frame = FloatArray(vertices * 3)
            for (i in frame.indices) {
                val v = input.float
                require(v.isFinite()) { "Cache contém posição não finita" }
                frame[i] = v
            }
            frames.add(frame)
        }
        return ClothBakeCache(vertices, fps, frames, modelHash)
    }

    /** Assinatura estável da geometria PMX usada para invalidar bakes de outro modelo/topologia. */
    fun modelSignature(positions: FloatArray, indices: IntArray): Long {
        val crc = CRC32()
        for (v in positions) {
            val bits = v.toRawBits()
            crc.update(bits); crc.update(bits ushr 8); crc.update(bits ushr 16); crc.update(bits ushr 24)
        }
        for (v in indices) {
            crc.update(v); crc.update(v ushr 8); crc.update(v ushr 16); crc.update(v ushr 24)
        }
        return crc.value
    }

    /** Escreve via temporário + fsync + backup para sobreviver a encerramento abrupto. */
    fun writeAtomic(file: File, cache: ClothBakeCache) {
        val bytes = encode(cache)
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        val bak = File(file.parentFile, file.name + ".bak")
        FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
        if (file.exists()) try { file.copyTo(bak, overwrite = true) } catch (_: Exception) { /* conserva o principal */ }
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }

    fun readWithBackup(file: File): ClothBakeCache {
        fun readChecked(target: File): ClothBakeCache {
            require(target.length() <= MAX_BYTES) { "Cache de tecido grande demais" }
            return decode(target.readBytes())
        }
        try { return readChecked(file) } catch (primary: Exception) {
            val backup = File(file.parentFile, file.name + ".bak")
            if (!backup.exists()) throw primary
            return try { readChecked(backup) } catch (secondary: Exception) {
                throw IllegalArgumentException("Cache principal e backup estão inválidos: ${primary.message}; ${secondary.message}", secondary)
            }
        }
    }
}
