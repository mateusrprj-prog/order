package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.fx.FxConfig
import studio.mmd.fx.FxStyle
import kotlin.math.roundToInt

@Composable
fun FxPanel(config: FxConfig, onChange: (FxConfig) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("VFX STUDIO · PARTÍCULAS", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Switch(checked = config.enabled, onCheckedChange = { onChange(config.copy(enabled = it)) })
        }
        Text("Efeitos procedurais sincronizados ao quadro da timeline e incluídos nas capturas.", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FxStyle.entries.forEach { style ->
                FilterChip(selected = config.style == style, onClick = { onChange(config.copy(style = style)) }, label = {
                    Text(when (style) {
                        FxStyle.SPARKS -> "Faíscas"; FxStyle.RAIN -> "Chuva"; FxStyle.SNOW -> "Neve"; FxStyle.AURA -> "Aura"; FxStyle.CONFETTI -> "Confete"
                        FxStyle.BUBBLES -> "Bolhas"; FxStyle.ORBIT -> "Órbita"; FxStyle.LIGHTNING -> "Raio"; FxStyle.MAGIC -> "Magia"; FxStyle.FIRE -> "Fogo"; FxStyle.SMOKE -> "Fumaça"
                    }, fontSize = 9.sp)
                })
            }
        }
        FxSlider("Partículas", config.count.toFloat(), 1f..400f, { onChange(config.copy(count = it.roundToInt())) }, "")
        FxSlider("Origem X", config.originX, -5f..5f, { onChange(config.copy(originX = it)) })
        FxSlider("Origem Y", config.originY, -5f..8f, { onChange(config.copy(originY = it)) })
        FxSlider("Origem Z", config.originZ, -5f..5f, { onChange(config.copy(originZ = it)) })
        FxSlider("Espalhamento", config.spread, .05f..5f, { onChange(config.copy(spread = it)) })
        FxSlider("Velocidade", config.speed, 0f..10f, { onChange(config.copy(speed = it)) })
        FxSlider("Gravidade", config.gravity, -10f..15f, { onChange(config.copy(gravity = it)) })
        FxSlider("Vida (s)", config.lifeSeconds, .1f..10f, { onChange(config.copy(lifeSeconds = it)) })
        FxSlider("Tamanho", config.size, .005f..0.2f, { onChange(config.copy(size = it)) })
        FxSlider("Opacidade", config.alpha, 0f..1f, { onChange(config.copy(alpha = it)) })
        Text("Cor do efeito", color = Muted, fontSize = 10.sp)
        FxSlider("Vermelho", config.red, 0f..1f, { onChange(config.copy(red = it)) })
        FxSlider("Verde", config.green, 0f..1f, { onChange(config.copy(green = it)) })
        FxSlider("Azul", config.blue, 0f..1f, { onChange(config.copy(blue = it)) })
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(onClick = { onChange(FxConfig(enabled = true, style = FxStyle.SPARKS)) }, modifier = Modifier.weight(1f)) { Text("Resetar") }
            Button(onClick = { onChange(config.copy(enabled = !config.enabled)) }, modifier = Modifier.weight(1f)) { Text(if (config.enabled) "Desativar" else "Ativar") }
        }
        Text("Os efeitos combinam trilhas aditivas e sprites circulares suaves. São determinísticos por quadro/seed e entram nas capturas; não são ainda fumaça/fogo volumétricos nem possuem colisão física.", color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun FxSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, suffix: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(78.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValue, valueRange = range, modifier = Modifier.weight(1f))
        Text("${(value * 100).roundToInt() / 100f}$suffix", color = Color.White, fontSize = 9.sp, modifier = Modifier.width(38.dp))
    }
}
