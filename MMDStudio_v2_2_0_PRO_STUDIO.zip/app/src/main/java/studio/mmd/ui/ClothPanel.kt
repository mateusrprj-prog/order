package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.mmd.PmxModel
import kotlin.math.roundToInt

data class ClothBakeSettings(
    val firstVertex: Int = 0,
    val lastVertex: Int = 0,
    val frames: Int = 90,
    val gravityY: Float = -9.81f,
    val windX: Float = 0f,
    val windY: Float = 0f,
    val windZ: Float = 0f,
    val substeps: Int = 4,
    val iterations: Int = 8,
    val selfCollision: Boolean = false,
    /** -1 intervalo, -2 influência de osso, >=0 material PMX. */
    val materialIndex: Int = -1,
    val boneIndex: Int = 0,
    val boneThreshold: Float = 0.05f,
    val surfaceCollision: Boolean = true,
    val followCharacterAnimation: Boolean = true,
    val boxCollision: Boolean = true,
    val collisionThickness: Float = 0.025f
)

@Composable
fun ClothPanel(
    model: PmxModel,
    settings: ClothBakeSettings,
    busy: Boolean,
    progress: Float,
    cachedFrames: Int,
    onSettings: (ClothBakeSettings) -> Unit,
    onBake: () -> Unit,
    onCancel: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val maxVertex = (model.vertexCount - 1).coerceAtLeast(0)
    val first = settings.firstVertex.coerceIn(0, maxVertex)
    val last = settings.lastVertex.coerceIn(0, maxVertex)
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("CLOTH STUDIO · XPBD", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("${model.vertexCount} vértices", color = Muted, fontSize = 10.sp)
        }
        Text("Simulação CPU XPBD por quadro. Selecione a roupa por material, intervalo ou influência óssea; o restante fica ancorado. Com superfície corporal e seguimento animado ativos, o bake atualiza skinning/morphs e colisão triangular a cada quadro, usando a pose anterior para preservar a inércia e gravando o cache no espaço local pré-skinning.", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FilterChip(selected = settings.materialIndex == -1, onClick = { onSettings(settings.copy(materialIndex = -1)) }, label = { Text("Intervalo", fontSize = 9.sp) })
            FilterChip(selected = settings.materialIndex == -2, onClick = { onSettings(settings.copy(materialIndex = -2)) }, label = { Text("Por osso", fontSize = 9.sp) })
            model.materials.forEachIndexed { index, material ->
                FilterChip(selected = settings.materialIndex == index, onClick = { onSettings(settings.copy(materialIndex = index)) }, label = { Text(material.name.ifBlank { "Material ${index + 1}" }, fontSize = 9.sp) })
            }
        }
        if (settings.materialIndex == -1) {
            ClothSlider("Primeiro vértice", first.toFloat(), 0f..maxVertex.toFloat(), { onSettings(settings.copy(firstVertex = it.roundToInt().coerceIn(0, maxVertex))) }, "")
            ClothSlider("Último vértice", last.toFloat(), 0f..maxVertex.toFloat(), { onSettings(settings.copy(lastVertex = it.roundToInt().coerceIn(0, maxVertex))) }, "")
            OutlinedButton(onClick = { onSettings(settings.copy(firstVertex = 0, lastVertex = maxVertex)) }, modifier = Modifier.fillMaxWidth()) { Text("Incluir todos os vértices") }
        } else if (settings.materialIndex == -2) {
            Text("Osso de referência", color = Muted, fontSize = 9.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                model.bones.forEachIndexed { index, bone ->
                    FilterChip(selected = settings.boneIndex == index, onClick = { onSettings(settings.copy(boneIndex = index)) }, label = { Text(bone.name.take(14), fontSize = 9.sp) })
                }
            }
            ClothSlider("Peso mínimo", settings.boneThreshold, 0.01f..1f, { onSettings(settings.copy(boneThreshold = it)) })
            Text("Vértices com influência igual ou superior ao limite serão simulados; os demais serão âncoras.", color = Muted, fontSize = 9.sp)
        } else {
            Text("Região por material: ${model.materials.getOrNull(settings.materialIndex)?.name ?: "inválido"} · vértices extraídos dos triângulos desse material.", color = Muted, fontSize = 9.sp)
        }
        ClothSlider("Quadros do bake", settings.frames.toFloat(), 1f..240f, { onSettings(settings.copy(frames = it.roundToInt().coerceIn(1, 240))) }, "")
        ClothSlider("Gravidade Y", settings.gravityY, -25f..5f, { onSettings(settings.copy(gravityY = it)) })
        ClothSlider("Vento X", settings.windX, -12f..12f, { onSettings(settings.copy(windX = it)) })
        ClothSlider("Vento Y", settings.windY, -12f..12f, { onSettings(settings.copy(windY = it)) })
        ClothSlider("Vento Z", settings.windZ, -12f..12f, { onSettings(settings.copy(windZ = it)) })
        ClothSlider("Subpassos", settings.substeps.toFloat(), 1f..12f, { onSettings(settings.copy(substeps = it.roundToInt().coerceIn(1, 12))) }, "")
        ClothSlider("Iterações", settings.iterations.toFloat(), 1f..24f, { onSettings(settings.copy(iterations = it.roundToInt().coerceIn(1, 24))) }, "")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Auto-colisão (até 2.048 vértices)", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.selfCollision, onCheckedChange = { onSettings(settings.copy(selfCollision = it)) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Colisão com superfície do corpo", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.surfaceCollision, onCheckedChange = { onSettings(settings.copy(surfaceCollision = it)) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Seguir animação, IK e morphs", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.followCharacterAnimation, onCheckedChange = { onSettings(settings.copy(followCharacterAnimation = it)) })
        }
        Text("No modo animado, a superfície da malha e colisores PMX ligados a ossos são atualizados por quadro. Corpos PMX dinâmicos (modos 1/2) não são re-simulados pelo bake de tecido; desligar colisão de superfície ou seguimento retorna ao modo local estático.", color = Muted, fontSize = 9.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Colisores caixa PMX", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Switch(checked = settings.boxCollision, onCheckedChange = { onSettings(settings.copy(boxCollision = it)) })
        }
        ClothSlider("Espessura colisão", settings.collisionThickness, 0.005f..0.12f, { onSettings(settings.copy(collisionThickness = it)) })
        Text("Cache atual: $cachedFrames quadros · limite: 20.000 vértices / 240 quadros", color = Muted, fontSize = 9.sp)
        if (busy) {
            LinearProgressIndicator(progress = progress.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
            Text("Bake ${(progress * 100f).toInt()}%", color = Muted, fontSize = 9.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(enabled = !busy && model.vertexCount in 3..20_000 && model.indices.size >= 3, onClick = onBake, modifier = Modifier.weight(1.4f)) {
                Text("Gerar bake XPBD")
            }
            if (busy) OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancelar") }
            else OutlinedButton(enabled = cachedFrames > 0, onClick = onClear, modifier = Modifier.weight(1f)) { Text("Limpar bake") }
        }
        Text("O bake é armazenado no espaço local pré-skinning. Com Seguir animação ativo, o solver transforma partículas e colisores por quadro, incluindo skinning e morphs, e converte o resultado de volta ao espaço local. Caixas, esferas e cápsulas PMX são mantidas como colisores auxiliares.", color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun ClothSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, suffix: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(94.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValue, valueRange = range, modifier = Modifier.weight(1f))
        Text("${(value * 100f).roundToInt() / 100f}$suffix", color = Color.White, fontSize = 9.sp, modifier = Modifier.width(42.dp))
    }
}
