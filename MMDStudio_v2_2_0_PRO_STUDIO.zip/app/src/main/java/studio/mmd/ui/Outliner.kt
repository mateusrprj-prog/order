package studio.mmd.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.mmd.render.ViewPreset
import studio.mmd.mmd.CameraPose
import studio.mmd.mmd.CameraMotionTools
import studio.mmd.mmd.VmdCamera

/**
 * Uma linha da hierarquia. [visible] = null: sem olho (não dá para ocultar).
 * v1.29.0: [group] = cabeçalho de grupo; [locked]/[renderOff] só têm efeito em objetos (prop/personagem) e grupos.
 */
class Layer(val key: String, val name: String, val icon: ImageVector, val sub: String, val indent: Int, val visible: Boolean?,
            val group: Boolean = false, val collapsed: Boolean = false, val locked: Boolean = false, val renderOff: Boolean = false)

/** Ações do Outliner (v1.29.0, fatia 8.4a). Cada uma é tratada em SceneScreen e persistida no projeto. */
class OutlinerActions(
    val onRename: (String, String) -> Unit, val onMove: (String, Int) -> Unit, val onLock: (String) -> Unit,
    val onRenderOff: (String) -> Unit, val onNewGroup: (String) -> Unit, val onAddToGroup: (String, String) -> Unit,
    val onRemoveFromGroup: (String) -> Unit, val onUngroup: (String) -> Unit, val onDuplicate: (String) -> Unit,
    val onDelete: (String) -> Unit, val onCollapse: (String) -> Unit,
    /** v1.29.3: agrupa vários itens de uma vez (seleção múltipla). */
    val onGroupMany: (List<String>) -> Unit = {},
    val canUndo: Boolean = false, val canRedo: Boolean = false, val onUndo: () -> Unit = {}, val onRedo: () -> Unit = {}
)

/**
 * Hierarquia da cena (modelo, objetos presos/soltos, personagens extras, grupos, luz, câmera, áudio).
 * Tocar numa linha seleciona e abre o painel de propriedades dela; com uma linha selecionada aparece a barra de ações
 * (renomear, mover, bloquear, visível no render, agrupar, duplicar, excluir) — só as que valem para aquele tipo de linha.
 */
@Composable
fun LayersPanel(layers: List<Layer>, selected: String, groups: List<Pair<String, String>>, actions: OutlinerActions,
                onSelect: (String) -> Unit, onToggle: (String) -> Unit, modifier: Modifier) {
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<String?>(null) }
    var groupMenu by remember { mutableStateOf(false) }
    var multi by remember { mutableStateOf(false) }                 // v1.29.3: modo seleção múltipla
    var picked by remember { mutableStateOf(setOf<String>()) }
    val sel = layers.firstOrNull { it.key == selected }
    val isObj = sel != null && !sel.group && (sel.key.startsWith("prop:") || sel.key.startsWith("char:"))
    val isModel = sel != null && sel.key == "model"
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Panel.copy(alpha = .94f)).padding(6.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("CENA · OUTLINER", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text(if (multi) "☑ Vários" else "☐ Vários", color = if (multi) Color.White else Muted, fontSize = 10.sp,
                modifier = Modifier.clickable { multi = !multi; picked = emptySet() }.padding(horizontal = 6.dp, vertical = 4.dp))
            Icon(Icons.AutoMirrored.Filled.Undo, null, tint = if (actions.canUndo) Color.White else Muted.copy(alpha = .4f),
                modifier = Modifier.clickable(enabled = actions.canUndo) { actions.onUndo() }.padding(4.dp).size(18.dp))
            Icon(Icons.AutoMirrored.Filled.Redo, null, tint = if (actions.canRedo) Color.White else Muted.copy(alpha = .4f),
                modifier = Modifier.clickable(enabled = actions.canRedo) { actions.onRedo() }.padding(4.dp).size(18.dp))
        }
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            for (l in layers) {
                val on = if (multi) l.key in picked else l.key == selected
                Row(Modifier.fillMaxWidth().padding(vertical = 1.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (on) Accent.copy(alpha = .28f) else Color.Transparent)
                    .clickable { if (multi) { if (l.key == "model" || l.key.startsWith("prop:") || l.key.startsWith("char:")) picked = if (l.key in picked) picked - l.key else picked + l.key } else onSelect(l.key) }.padding(start = (6 + 12 * l.indent).dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (l.group) Icon(if (l.collapsed) Icons.Default.KeyboardArrowRight else Icons.Default.KeyboardArrowDown, null, tint = Color.White,
                        modifier = Modifier.clickable { actions.onCollapse(l.key) }.padding(end = 2.dp).size(18.dp))
                    Icon(l.icon, null, tint = if (on) Color.White else Muted, modifier = Modifier.size(16.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 7.dp)) {
                        Text(l.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(l.sub, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (l.locked) Icon(Icons.Default.Lock, null, tint = Muted, modifier = Modifier.padding(end = 2.dp).size(12.dp))
                    if (l.renderOff) Icon(Icons.Default.Movie, null, tint = Color(0xFFE05050), modifier = Modifier.padding(end = 2.dp).size(12.dp))
                    val v = l.visible
                    if (v != null) Icon(if (v) Icons.Default.Visibility else Icons.Default.VisibilityOff, null,
                        tint = if (v) Color.White else Muted,
                        modifier = Modifier.clickable { onToggle(l.key) }.padding(4.dp).size(18.dp))
                }
            }
        }
        if (multi) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (picked.isEmpty()) "Toque nos itens (modelo, objetos, personagens) para marcar" else "${picked.size} marcado(s)", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                Text("Agrupar", color = if (picked.isEmpty()) Muted else Color.White, fontSize = 11.sp,
                    modifier = Modifier.background(if (picked.isEmpty()) Color(0xFF26282D) else Accent, RoundedCornerShape(6.dp))
                        .clickable(enabled = picked.isNotEmpty()) { actions.onGroupMany(layers.map { it.key }.filter { it in picked }); picked = emptySet(); multi = false }
                        .padding(horizontal = 10.dp, vertical = 6.dp))
            }
        } else if (sel != null && (isObj || isModel || sel.group)) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                @Composable fun act(icon: ImageVector, tint: Color = Color.White, f: () -> Unit) =
                    Icon(icon, null, tint = tint, modifier = Modifier.clickable { f() }.padding(5.dp).size(20.dp))
                act(Icons.Default.Edit) { renameText = sel.name; renaming = sel.key }
                act(Icons.Default.ArrowUpward) { actions.onMove(sel.key, -1) }
                act(Icons.Default.ArrowDownward) { actions.onMove(sel.key, 1) }
                if (isObj || sel.group) act(if (sel.locked) Icons.Default.Lock else Icons.Default.LockOpen, if (sel.locked) Accent else Color.White) { actions.onLock(sel.key) }
                act(Icons.Default.Movie, if (sel.renderOff) Color(0xFFE05050) else Color.White) { actions.onRenderOff(sel.key) }
                if (isObj || isModel) {
                    Box {
                        act(Icons.Default.CreateNewFolder) { groupMenu = true }
                        DropdownMenu(expanded = groupMenu, onDismissRequest = { groupMenu = false }) {
                            DropdownMenuItem(text = { Text("Novo grupo") }, onClick = { groupMenu = false; actions.onNewGroup(sel.key) })
                            groups.forEach { (gid, gname) -> DropdownMenuItem(text = { Text("Para: $gname") }, onClick = { groupMenu = false; actions.onAddToGroup(sel.key, gid) }) }
                            if (sel.indent > 0) DropdownMenuItem(text = { Text("Tirar do grupo") }, onClick = { groupMenu = false; actions.onRemoveFromGroup(sel.key) })
                        }
                    }
                }
                if (sel.group) act(Icons.Default.FolderOff) { actions.onUngroup(sel.key) }
                if (isObj) act(Icons.Default.ContentCopy) { actions.onDuplicate(sel.key) }
                if (isObj) act(Icons.Default.Delete, Color(0xFFE05050)) { deleting = sel.key }
            }
        }
    }
    renaming?.let { k ->
        AlertDialog(onDismissRequest = { renaming = null },
            title = { Text("Renomear") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { actions.onRename(k, renameText); renaming = null }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancelar") } })
    }
    deleting?.let { k ->
        AlertDialog(onDismissRequest = { deleting = null },
            title = { Text("Excluir da cena?") },
            text = { Text("O objeto e os arquivos dele neste projeto serão apagados. Não dá para desfazer.") },
            confirmButton = { TextButton(onClick = { actions.onDelete(k); deleting = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } })
    }
}

/** Painel de câmera: vistas de viewport, controle do VMD e edição de keyframes cinematográficos. */
@Composable
fun CameraPanel(
    hasVmd: Boolean, on: Boolean, flip: Boolean, onOn: () -> Unit, onFlip: () -> Unit, onRemove: () -> Unit,
    onPreset: (ViewPreset) -> Unit, onFrameAll: () -> Unit, modifier: Modifier,
    camera: VmdCamera? = null, frame: Int = 0,
    onSaveKey: (CameraPose) -> Unit = {}, onRemoveKey: () -> Unit = {}, onLinearize: () -> Unit = {},
    onSmooth: () -> Unit = {}, onReverse: () -> Unit = {}
) {
    val sampled = remember(camera, frame) { CameraMotionTools.sample(camera, frame) }
    var distance by remember(camera, frame) { mutableFloatStateOf(sampled.distance) }
    var x by remember(camera, frame) { mutableFloatStateOf(sampled.x) }
    var y by remember(camera, frame) { mutableFloatStateOf(sampled.y) }
    var z by remember(camera, frame) { mutableFloatStateOf(sampled.z) }
    var rx by remember(camera, frame) { mutableFloatStateOf(Math.toDegrees(sampled.rx.toDouble()).toFloat()) }
    var ry by remember(camera, frame) { mutableFloatStateOf(Math.toDegrees(sampled.ry.toDouble()).toFloat()) }
    var rz by remember(camera, frame) { mutableFloatStateOf(Math.toDegrees(sampled.rz.toDouble()).toFloat()) }
    var fov by remember(camera, frame) { mutableFloatStateOf(sampled.fov) }
    val exact = CameraMotionTools.hasKey(camera, frame)
    Column(modifier.background(Panel, RoundedCornerShape(8.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
        Text("Câmera", color = Color.White, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("Vistas", color = Muted, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Frente" to ViewPreset.FRONT, "Trás" to ViewPreset.BACK, "Esq." to ViewPreset.LEFT).forEach { (n, p) ->
                OutlinedButton(onClick = { onPreset(p) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(n, fontSize = 11.sp, maxLines = 1) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Dir." to ViewPreset.RIGHT, "Topo" to ViewPreset.TOP, "Base" to ViewPreset.BOTTOM).forEach { (n, p) ->
                OutlinedButton(onClick = { onPreset(p) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(n, fontSize = 11.sp, maxLines = 1) }
            }
        }
        OutlinedButton(onClick = onFrameAll, modifier = Modifier.fillMaxWidth()) { Text("Enquadrar tudo", fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))
        Text("Câmera do VMD", color = Muted, fontSize = 10.sp)
        if (!hasVmd) Text("Sem movimento de câmera. Você pode criar a primeira key abaixo.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        else Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(onClick = onOn, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(if (on) "Ligada" else "Desligada", fontSize = 11.sp, maxLines = 1) }
            OutlinedButton(onClick = onFlip, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text(if (flip) "Inclin. invertida" else "Inverter inclin.", fontSize = 11.sp, maxLines = 1) }
            OutlinedButton(onClick = onRemove, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.weight(1f)) { Text("Remover", fontSize = 11.sp, maxLines = 1) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ANIMAÇÃO · quadro $frame", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("${camera?.frames?.size ?: 0} keys", color = Muted, fontSize = 10.sp)
        }
        CameraValueSlider("Distância", distance, 0.1f..300f) { distance = it }
        CameraValueSlider("Centro X", x, -100f..100f) { x = it }
        CameraValueSlider("Centro Y", y, -100f..100f) { y = it }
        CameraValueSlider("Centro Z", z, -100f..100f) { z = it }
        CameraValueSlider("Rotação X", rx, -180f..180f, "°") { rx = it }
        CameraValueSlider("Rotação Y", ry, -180f..180f, "°") { ry = it }
        CameraValueSlider("Rotação Z", rz, -180f..180f, "°") { rz = it }
        CameraValueSlider("Campo de visão", fov, 1f..120f, "°") { fov = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { onSaveKey(CameraPose(distance, x, y, z, Math.toRadians(rx.toDouble()).toFloat(), Math.toRadians(ry.toDouble()).toFloat(), Math.toRadians(rz.toDouble()).toFloat(), fov)) }, modifier = Modifier.weight(1f)) {
                Text(if (exact) "Atualizar key" else "Gravar key", fontSize = 11.sp)
            }
            OutlinedButton(onClick = onRemoveKey, enabled = exact, modifier = Modifier.weight(1f)) { Text("Excluir key", fontSize = 11.sp) }
        }
        OutlinedButton(onClick = onLinearize, enabled = camera != null, modifier = Modifier.fillMaxWidth()) { Text("Linearizar curvas da câmera", fontSize = 11.sp) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = onSmooth, enabled = (camera?.frames?.size ?: 0) >= 3, modifier = Modifier.weight(1f)) { Text("Suavizar keys", fontSize = 10.sp) }
            OutlinedButton(onClick = onReverse, enabled = (camera?.frames?.size ?: 0) >= 2, modifier = Modifier.weight(1f)) { Text("Inverter movimento", fontSize = 10.sp) }
        }
        Text("As alterações são salvas no projeto como VMD. Ajuste a câmera no quadro desejado e grave uma key para criar o movimento entre os pontos.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun CameraValueSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String = "", onValue: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 10.sp, modifier = Modifier.width(88.dp), maxLines = 1)
        Slider(value.coerceIn(range.start, range.endInclusive), onValue, valueRange = range, modifier = Modifier.weight(1f))
        Text("%.1f%s".format(value, unit), color = Color.White, fontSize = 9.sp, modifier = Modifier.width(42.dp))
    }
}
