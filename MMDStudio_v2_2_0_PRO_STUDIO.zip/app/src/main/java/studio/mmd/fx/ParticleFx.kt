package studio.mmd.fx

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Efeitos procedurais determinísticos para prévia e captura do renderer. Coordenadas em unidades GL. */
enum class FxStyle { SPARKS, RAIN, SNOW, AURA, CONFETTI, BUBBLES, ORBIT, LIGHTNING, MAGIC, FIRE, SMOKE }

data class FxConfig(
    val enabled: Boolean = false,
    val style: FxStyle = FxStyle.SPARKS,
    val count: Int = 90,
    val originX: Float = 0f,
    val originY: Float = 1.2f,
    val originZ: Float = 0f,
    val spread: Float = 1.2f,
    val speed: Float = 1.8f,
    val gravity: Float = 2.8f,
    val lifeSeconds: Float = 2.4f,
    val size: Float = 0.035f,
    val red: Float = 1f,
    val green: Float = 0.55f,
    val blue: Float = 0.12f,
    val alpha: Float = 0.9f,
    val seed: Int = 721
) {
    fun sanitized() = copy(
        count = count.coerceIn(1, 400),
        spread = spread.takeIf { it.isFinite() }?.coerceIn(0.01f, 20f) ?: 1f,
        speed = speed.takeIf { it.isFinite() }?.coerceIn(0f, 30f) ?: 1f,
        gravity = gravity.takeIf { it.isFinite() }?.coerceIn(-30f, 30f) ?: 0f,
        lifeSeconds = lifeSeconds.takeIf { it.isFinite() }?.coerceIn(0.1f, 30f) ?: 2f,
        size = size.takeIf { it.isFinite() }?.coerceIn(0.002f, 0.5f) ?: 0.03f,
        originX = originX.takeIf { it.isFinite() } ?: 0f,
        originY = originY.takeIf { it.isFinite() } ?: 0f,
        originZ = originZ.takeIf { it.isFinite() } ?: 0f,
        red = red.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f,
        green = green.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f,
        blue = blue.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f,
        alpha = alpha.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 1f
    )
}

object ParticleFx {
    /** Retorna pares XYZ para GL_LINES, com estado reproduzível no mesmo frame/seed. */
    fun buildLines(config: FxConfig, frame: Float, fps: Float = 30f): FloatArray {
        val c = config.sanitized()
        if (!c.enabled || !frame.isFinite() || c.count <= 0) return FloatArray(0)
        val time = frame.coerceAtLeast(0f) / fps.coerceIn(1f, 240f)
        val out = FloatArray(c.count * 6)
        var p = 0
        for (i in 0 until c.count) {
            val r1 = random01(i, c.seed, 1); val r2 = random01(i, c.seed, 2); val r3 = random01(i, c.seed, 3)
            val phase = r1 * c.lifeSeconds
            val age = (time + phase) % c.lifeSeconds
            val angle = r2 * (2f * PI.toFloat())
            val radial = (0.15f + r3 * 0.85f) * c.spread
            val ox = c.originX + cos(angle) * radial
            val oz = c.originZ + sin(angle) * radial
            val oy = c.originY + (random01(i, c.seed, 4) - .5f) * c.spread
            val x: Float; val y: Float; val z: Float; val dx: Float; val dy: Float; val dz: Float
            when (c.style) {
                FxStyle.SPARKS -> {
                    val vx = (r2 - .5f) * c.speed * 1.3f
                    val vy = (.35f + r3 * .9f) * c.speed
                    val vz = (random01(i, c.seed, 5) - .5f) * c.speed
                    x = ox + vx * age; y = oy + vy * age - .5f * c.gravity * age * age; z = oz + vz * age
                    dx = -vx * c.size * 3f; dy = -vy * c.size * 3f + c.gravity * age * c.size * 3f; dz = -vz * c.size * 3f
                }
                FxStyle.RAIN -> {
                    val fall = (age * c.speed) % (c.spread * 2.8f + 0.25f)
                    x = ox + sin(time * 1.7f + i) * c.size; y = oy + c.spread - fall; z = oz
                    dx = 0f; dy = c.size * 6f; dz = 0f
                }
                FxStyle.SNOW -> {
                    val fall = (age * c.speed * .35f) % (c.spread * 2f + .2f)
                    x = ox + sin(time + i * .7f) * c.spread * .15f; y = oy + c.spread - fall; z = oz + cos(time * .8f + i) * c.spread * .1f
                    dx = c.size; dy = c.size * .4f; dz = 0f
                }
                FxStyle.AURA -> {
                    val a = angle + time * c.speed + i * .17f
                    val rr = c.spread * (.45f + .12f * sin(time * 2f + i))
                    x = c.originX + cos(a) * rr; y = c.originY + sin(time * 2f + i * .23f) * c.spread * .22f; z = c.originZ + sin(a) * rr
                    dx = -sin(a) * c.size * 2f; dy = c.size * 2f; dz = cos(a) * c.size * 2f
                }
                FxStyle.CONFETTI -> {
                    val vx = (r2 - .5f) * c.speed
                    val vy = (.3f + r3) * c.speed
                    val spin = time * (2f + r3 * 5f) + phase
                    x = ox + vx * age + sin(spin) * c.size * 2f
                    y = oy + vy * age - .5f * c.gravity * age * age
                    z = oz + (r1 - .5f) * c.speed * age
                    dx = cos(spin) * c.size * 2f; dy = sin(spin) * c.size; dz = c.size
                }
                FxStyle.BUBBLES -> {
                    val rise = (age * c.speed * .45f) % (c.spread * 2.5f + .2f)
                    x = ox + sin(time * 1.8f + i * .73f) * c.spread * .18f
                    y = oy - c.spread + rise
                    z = oz + cos(time * 1.2f + i) * c.spread * .12f
                    dx = c.size * (0.35f + r3); dy = c.size * 0.2f; dz = 0f
                }
                FxStyle.ORBIT -> {
                    val a = angle + time * c.speed + phase * 2f
                    val rr = c.spread * (0.35f + 0.55f * r3)
                    x = c.originX + cos(a) * rr
                    y = c.originY + sin(a * 1.7f + i) * c.spread * .28f
                    z = c.originZ + sin(a) * rr
                    dx = -sin(a) * c.size * 2f; dy = c.size; dz = cos(a) * c.size * 2f
                }
                FxStyle.LIGHTNING -> {
                    val segment = (time * c.speed * 5f + phase).toInt()
                    val jitter = random01(i, c.seed, segment + 31) - .5f
                    x = ox + (r2 - .5f) * c.spread
                    y = oy + (r3 - .5f) * c.spread
                    z = oz + (r1 - .5f) * c.spread
                    dx = jitter * c.spread * .55f
                    dy = (random01(i, c.seed, segment + 47) - .5f) * c.spread * .8f
                    dz = (random01(i, c.seed, segment + 59) - .5f) * c.spread * .55f
                }
                FxStyle.MAGIC -> {
                    val progress = (age / c.lifeSeconds).coerceIn(0f, 1f)
                    val a = angle + time * c.speed * 1.4f + progress * 2f * PI.toFloat()
                    val rr = c.spread * (0.08f + progress * 0.9f)
                    x = ox + cos(a) * rr
                    y = oy + (progress - .5f) * c.spread * .7f
                    z = oz + sin(a) * rr
                    dx = -sin(a) * c.size * 2f; dy = c.size * 1.5f; dz = cos(a) * c.size * 2f
                }
                FxStyle.FIRE -> {
                    val rise = age * c.speed
                    val flicker = sin(time * 17f + i * 2.31f) * .22f + sin(time * 31f + i) * .09f
                    val width = c.spread * (.08f + .32f * (age / c.lifeSeconds))
                    x = c.originX + (r2 - .5f) * width + flicker * width
                    y = c.originY + rise - .5f * c.gravity * age * age * .12f
                    z = c.originZ + (r3 - .5f) * width
                    dx = flicker * c.size * 2f; dy = -c.size * (2f + r1); dz = (r2 - .5f) * c.size
                }
                FxStyle.SMOKE -> {
                    val progress = (age / c.lifeSeconds).coerceIn(0f, 1f)
                    val drift = sin(time * .8f + i * .71f) * c.spread * (.08f + progress * .22f)
                    val puff = c.spread * (.08f + progress * .32f)
                    x = ox + drift + (r2 - .5f) * puff
                    y = oy + age * c.speed * .32f
                    z = oz + cos(time * .6f + i) * c.spread * .12f + (r3 - .5f) * puff
                    dx = puff * .22f; dy = c.size * .25f; dz = puff * .18f
                }
            }
            out[p++] = x; out[p++] = y; out[p++] = z
            out[p++] = x + dx; out[p++] = y + dy; out[p++] = z + dz
        }
        return out
    }

    /** Um ponto XYZ por partícula, destinado a GL_POINTS com fragment shader circular suave. */
    fun buildPoints(config: FxConfig, frame: Float, fps: Float = 30f): FloatArray {
        val lines = buildLines(config, frame, fps)
        if (lines.isEmpty()) return FloatArray(0)
        val out = FloatArray(lines.size / 2)
        var dst = 0
        for (i in 0 until lines.size step 6) {
            out[dst++] = lines[i]
            out[dst++] = lines[i + 1]
            out[dst++] = lines[i + 2]
        }
        return out
    }

    private fun random01(index: Int, seed: Int, salt: Int): Float {
        var x = index * 0x45d9f3b + seed * 0x119de1f3 + salt * 0x3449
        x = (x xor (x ushr 16)) * 0x45d9f3b
        x = (x xor (x ushr 16)) * 0x45d9f3b
        x = x xor (x ushr 16)
        return (x ushr 8).toFloat() / 16777215f
    }
}
