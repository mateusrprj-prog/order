package studio.mmd

import org.junit.Assert.*
import org.junit.Test
import studio.mmd.export.FrameSequenceCache
import studio.mmd.export.PixelCompositor
import studio.mmd.export.PostFxConfig
import studio.mmd.edit.WeightPaintMode
import studio.mmd.edit.WeightPaintSession
import studio.mmd.edit.ModelToolsSession
import studio.mmd.edit.SculptBrushMode
import studio.mmd.fx.FxConfig
import studio.mmd.fx.FxStyle
import studio.mmd.fx.ParticleFx
import studio.mmd.mmd.*
import java.io.File

class ProductionV200Test {
    private fun model(): PmxModel {
        val bones = listOf(
            PmxBone("root", "root", 0f, 0f, 0f, -1, 0, 0x001F, -1, -1, 0f, null),
            PmxBone("arm", "arm", 0f, 1f, 0f, 0, 0, 0x001F, -1, -1, 0f, null)
        )
        return PmxModel("stroke", 2.1f,
            floatArrayOf(0f,0f,0f, 1f,0f,0f, 0f,1f,0f), FloatArray(9), FloatArray(6),
            intArrayOf(0,-1,-1,-1, 0,-1,-1,-1, 0,-1,-1,-1),
            floatArrayOf(1f,0f,0f,0f, 1f,0f,0f,0f, 1f,0f,0f,0f), intArrayOf(0,1,2), emptyList(), emptyList(), bones, emptyList())
    }

    @Test fun viewportWeightStrokeIsOneUndoOperation() {
        val session = WeightPaintSession(model())
        val before = session.buildModel().boneWeights.copyOf()
        val result = session.paintStroke(listOf(floatArrayOf(0f,0f,0f), floatArrayOf(.5f,0f,0f), floatArrayOf(1f,0f,0f)),
            radius = .65f, targetBone = 1, targetWeight = 1f, strength = 1f, mode = WeightPaintMode.REPLACE)
        assertTrue(result.changed > 0)
        assertTrue(session.influenceAt(0, 1) > 0f)
        assertTrue(session.canUndo)
        assertTrue(session.undo())
        assertArrayEquals(before, session.buildModel().boneWeights, .0001f)
        assertFalse(session.canUndo)
    }

    @Test fun spatialSculptBrushSupportsInflateSmoothPinchMoveAndUndo() {
        for (mode in SculptBrushMode.entries) {
            val m = model()
            val session = ModelToolsSession(m)
            val before = session.buildModel().positions.copyOf()
            val report = session.sculptBrush(.25f, .1f, 0f, 1.5f, .8f, mode, .12f, 0f, 0f)
            assertTrue("$mode did not touch vertices", report.changed > 0)
            assertTrue(session.canUndo)
            assertTrue(session.undo())
            assertArrayEquals(before, session.buildModel().positions, .0001f)
        }
    }

    @Test fun compositorIsDeterministicAndPreservesAlpha() {
        val source = intArrayOf(0xFF202020.toInt(), 0x80202020.toInt(), 0xFF808080.toInt(), 0xFFFFFFFF.toInt())
        val config = PostFxConfig(enabled = true, exposure = .5f, contrast = 1.15f, saturation = .8f, vignette = .35f, grain = .02f, seed = 99)
        val a = PixelCompositor.apply(2, 2, source, config)
        val b = PixelCompositor.apply(2, 2, source, config)
        assertArrayEquals(a, b)
        assertEquals(source.map { it ushr 24 }, a.map { it ushr 24 })
        assertFalse(source.contentEquals(a))
        assertArrayEquals(source, PixelCompositor.apply(2, 2, source, config.copy(enabled = false)))
    }

    @Test fun compositorRejectsMismatchedBufferAndSanitizesNan() {
        assertTrue(runCatching { PixelCompositor.apply(2, 2, intArrayOf(0), PostFxConfig(enabled = true)) }.isFailure)
        val source = intArrayOf(-1)
        val result = PixelCompositor.apply(1, 1, source, PostFxConfig(enabled = true, exposure = Float.NaN, grain = Float.POSITIVE_INFINITY))
        assertEquals(1, result.size)
    }

    @Test fun frameCacheWritesReadsAndVerifiesPngChecksum() {
        val dir = java.nio.file.Files.createTempDirectory("mmdstudio_render_test_").toFile()
        try {
            val cache = FrameSequenceCache(dir, "projectA|frames=2|fps=30")
            val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 13, 10, 26, 10, 1, 2, 3)
            cache.writeFrame(0, png)
            assertArrayEquals(png, cache.readFrame(0))
            assertEquals(1, cache.completedFrames(2))
            File(dir, "frame_000000.png").writeBytes(png.copyOf().also { it[it.lastIndex] = 99 })
            assertNull(cache.readFrame(0))
        } finally { dir.deleteRecursively() }
    }

    @Test fun frameCacheInvalidatesWhenRenderSignatureChanges() {
        val dir = java.nio.file.Files.createTempDirectory("mmdstudio_signature_test_").toFile()
        try {
            val first = FrameSequenceCache(dir, "settings-A")
            first.writeFrame(1, byteArrayOf(0x89.toByte(), 0x50, 1, 2, 3, 4, 5, 6))
            assertNotNull(first.readFrame(1))
            val second = FrameSequenceCache(dir, "settings-B")
            assertNull(second.readFrame(1))
            assertEquals(0, second.completedFrames(3))
        } finally { dir.deleteRecursively() }
    }

    @Test fun fireAndSmokeEffectsProduceFiniteDeterministicParticles() {
        for (style in listOf(FxStyle.FIRE, FxStyle.SMOKE)) {
            val config = FxConfig(enabled = true, style = style, count = 80, seed = 121)
            val a = ParticleFx.buildLines(config, 27f, 30f)
            val b = ParticleFx.buildLines(config, 27f, 30f)
            assertEquals(80 * 6, a.size)
            assertArrayEquals(a, b, 0f)
            assertTrue(a.all { it.isFinite() })
            assertTrue(ParticleFx.buildPoints(config, 27f).all { it.isFinite() })
        }
    }
}
